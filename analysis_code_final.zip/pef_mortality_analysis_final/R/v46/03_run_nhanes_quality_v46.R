#!/usr/bin/env Rscript

# Restricted V46.0 NHANES A/B spirometry-quality sensitivity.
# No public coefficient release occurs before independent validation.

options(stringsAsFactors = FALSE, warn = 1)

v460_root <- function() {
  args <- commandArgs(trailingOnly = FALSE)
  file_arg <- grep("^--file=", args, value = TRUE)
  if (!length(file_arg)) return(normalizePath(getwd(), mustWork = TRUE))
  script <- sub("^--file=", "", file_arg[[1L]])
  normalizePath(file.path(dirname(script), "..", ".."), mustWork = TRUE)
}

root <- v460_root()
source(file.path(root, "R", "v45", "01_nhanes_common_utilities_v45.R"))
source(file.path(root, "R", "v45", "02_gli_functions_v45.R"))
source(file.path(root, "R", "v45", "11_nhanes_outcome_utilities_v45.R"))
v45_require_packages(root)
options(
  survey.lonely.psu = "adjust",
  survey.adjust.domain.lonely = TRUE,
  survey.replicates.mse = TRUE,
  survey.multicore = FALSE
)

args <- commandArgs(trailingOnly = TRUE)
arg_value <- function(prefix, default = NULL) {
  hit <- grep(paste0("^", prefix, "="), args, value = TRUE)
  if (!length(hit)) return(default)
  sub(paste0("^", prefix, "="), "", tail(hit, 1L))
}
module_requested <- arg_value("--module", "all")
if (!module_requested %in% c("prefix", "full", "all")) {
  stop("--module must be prefix, full, or all.", call. = FALSE)
}
workers <- suppressWarnings(as.integer(arg_value("--workers", "4")))
if (!is.finite(workers) || workers < 1L || workers > 8L) {
  stop("--workers must be an integer from 1 through 8.", call. = FALSE)
}
workers <- min(workers, max(1L, parallel::detectCores() - 1L))

read_tsv <- function(path) {
  utils::read.delim(
    path, stringsAsFactors = FALSE, check.names = FALSE,
    na.strings = c("", "NA")
  )
}

expected <- list(
  protocol =
    "c87545ae0ea129bb9e9894dd02f3890d9ff74e2d83eb75b4ae1010c829a6dd6d",
  mig =
    "41bcc3e5fbfd8f19501682e93354856ffc06adf6e426937327e07138d17733d3",
  rw =
    "2d795d61aabcce42603b1cfa7b254239a716980821ad1865347a8a8327c9f152",
  abc_anchor =
    "63804066d87a6af0e1a9b61d57d5a318ca4c0d13417f6fee4bfea601272e2daf",
  m = 50L,
  replicates = 500L,
  n = 5925L,
  deaths = 758L,
  strata = 45L,
  psu = 94L,
  design_df = 49L
)

paths <- list(
  protocol = file.path(
    root, "protocol", "pef_mortality_analysis_plan_v46_0_revision.md"
  ),
  preflight_status = file.path(
    root, "results", "v46", "structural_preflight",
    "v46_0_preflight_status.tsv"
  ),
  preflight_checks = file.path(
    root, "results", "v46", "structural_preflight",
    "v46_0_structural_checks.tsv"
  ),
  preflight_manifest = file.path(
    root, "results", "v46", "structural_preflight",
    "v46_0_input_manifest.tsv"
  ),
  preflight_nhanes = file.path(
    root, "results", "v46", "structural_preflight",
    "v46_0_nhanes_matrix_diagnostics.tsv"
  ),
  mig_pointer = file.path(
    root, "results", "v45", "production_mi", "MI_G_m50_current.tsv"
  ),
  rw = file.path(
    root, "derived_sensitive", "v45", "v45_rao_wu_replicate_contract.rds"
  ),
  abc_anchor = file.path(
    root, "derived_sensitive", "v45", "outcome_execution", "m50",
    "v45_nhanes_outcome_m50_20260725T150659_pid55259",
    "paired_full_restricted.rds"
  ),
  runner = file.path(root, "R", "v46", "03_run_nhanes_quality_v46.R")
)

preflight_status <- read_tsv(paths$preflight_status)
preflight_checks <- read_tsv(paths$preflight_checks)
preflight_manifest <- read_tsv(paths$preflight_manifest)
preflight_nhanes <- read_tsv(paths$preflight_nhanes)
if (nrow(preflight_status) != 1L ||
    !identical(preflight_status$status[[1L]],
               "STRUCTURAL_PREFLIGHT_PASS") ||
    any(preflight_checks$status != "PASS") ||
    any(preflight_nhanes$status != "PASS") ||
    !identical(v45_sha256_file(paths$protocol), expected$protocol)) {
  stop("V46.0 structural preflight is absent, failed, or stale.",
       call. = FALSE)
}
manifest_current <- vapply(
  file.path(root, preflight_manifest$path_alias),
  v45_sha256_file, character(1)
)
if (anyNA(manifest_current) ||
    !identical(unname(manifest_current),
               as.character(preflight_manifest$sha256))) {
  stop("A V46.0 preflight-frozen input changed.", call. = FALSE)
}

mig_pointer <- read_tsv(paths$mig_pointer)
if (nrow(mig_pointer) != 1L ||
    !identical(mig_pointer$object_id[[1L]], "MI-G") ||
    mig_pointer$requested_m[[1L]] != expected$m ||
    !identical(mig_pointer$status[[1L]],
               "INDEPENDENT_VALIDATION_PASS") ||
    !identical(mig_pointer$mids_sha256[[1L]], expected$mig)) {
  stop("The frozen MI-G pointer failed identity checks.", call. = FALSE)
}
mig_path <- file.path(root, mig_pointer$mids_path_alias[[1L]])
if (!identical(v45_sha256_file(mig_path), expected$mig) ||
    !identical(v45_sha256_file(paths$rw), expected$rw) ||
    !identical(v45_sha256_file(paths$abc_anchor), expected$abc_anchor)) {
  stop("A frozen NHANES input failed identity checks.", call. = FALSE)
}

public_root <- file.path(root, "results", "v46", "nhanes_quality")
restricted_root <- file.path(root, "derived_sensitive", "v46", "nhanes_quality")
log_root <- file.path(root, "logs", "v46", "nhanes_quality")
dir.create(public_root, recursive = TRUE, showWarnings = FALSE)
dir.create(restricted_root, recursive = TRUE, showWarnings = FALSE)
dir.create(log_root, recursive = TRUE, showWarnings = FALSE)

current_path <- file.path(public_root, "v46_nhanes_restricted_current.tsv")
run_id_arg <- arg_value("--run-id", NULL)
if (!is.null(run_id_arg) && !grepl(
  "^v46_nhanes_quality_m50_[0-9]{8}T[0-9]{6}_pid[0-9]+$",
  run_id_arg
)) {
  stop("Unsafe or invalid --run-id.", call. = FALSE)
}
if (!is.null(run_id_arg)) {
  run_id <- run_id_arg
} else if (file.exists(current_path)) {
  current <- read_tsv(current_path)
  if (nrow(current) != 1L ||
      !grepl("^v46_nhanes_quality_m50_", current$run_id[[1L]])) {
    stop("The V46 NHANES current pointer is invalid.", call. = FALSE)
  }
  run_id <- current$run_id[[1L]]
} else {
  run_id <- paste0(
    "v46_nhanes_quality_m50_",
    format(Sys.time(), "%Y%m%dT%H%M%S"), "_pid", Sys.getpid()
  )
}

run_dir <- file.path(restricted_root, run_id)
state_dir <- file.path(public_root, run_id)
dir.create(run_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(state_dir, recursive = TRUE, showWarnings = FALSE)
state_path <- file.path(state_dir, "module_state.tsv")
log_path <- file.path(log_root, paste0(run_id, ".log"))
state <- if (file.exists(state_path)) read_tsv(state_path) else data.frame(
  module = c("prefix", "full"), status = "NOT_RUN",
  output_path_alias = NA_character_, output_sha256 = NA_character_,
  completed_at = NA_character_, stringsAsFactors = FALSE
)
if (!identical(state$module, c("prefix", "full")) ||
    any(!state$status %in% c("NOT_RUN", "RUNNING", "RESTRICTED_COMPLETE"))) {
  stop("V46 NHANES module state is invalid.", call. = FALSE)
}
if (any(state$status == "RUNNING")) {
  stop("Interrupted RUNNING state requires audit and a new run ID.",
       call. = FALSE)
}
log_lines <- if (file.exists(log_path)) readLines(log_path, warn = FALSE) else c(
  paste0("run_id: ", run_id),
  "coefficient_visibility: restricted",
  "participant_level_output: forbidden",
  paste0("workers: ", workers)
)
append_log <- function(value) {
  line <- paste0(format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z"), " ", value)
  log_lines <<- c(log_lines, line)
  v45_atomic_write_lines(log_lines, log_path)
  message(value)
}
write_state <- function() {
  v45_atomic_write_tsv(state, state_path)
  v45_atomic_write_tsv(data.frame(
    run_id = run_id,
    state_path_alias = substring(state_path, nchar(root) + 2L),
    state_sha256 = v45_sha256_file(state_path),
    coefficient_visibility = "RESTRICTED",
    independent_validation_status = "NOT_RUN",
    stringsAsFactors = FALSE
  ), current_path)
}
write_state()

module_alias <- function(module) file.path(
  "derived_sensitive", "v46", "nhanes_quality", run_id,
  paste0(module, "_restricted.rds")
)
module_path <- function(module) file.path(root, module_alias(module))
input_hashes <- list(
  protocol = v45_sha256_file(paths$protocol),
  preflight_status = v45_sha256_file(paths$preflight_status),
  preflight_checks = v45_sha256_file(paths$preflight_checks),
  preflight_manifest = v45_sha256_file(paths$preflight_manifest),
  preflight_nhanes = v45_sha256_file(paths$preflight_nhanes),
  mi_g_m50 = v45_sha256_file(mig_path),
  rao_wu_contract = v45_sha256_file(paths$rw),
  abc_anchor = v45_sha256_file(paths$abc_anchor),
  execution_script = v45_sha256_file(paths$runner)
)
publish_module <- function(module, object) {
  row <- match(module, state$module)
  if (is.na(row) || state$status[[row]] != "RUNNING") {
    stop(module, " is not RUNNING.", call. = FALSE)
  }
  path <- module_path(module)
  if (file.exists(path)) stop("Refusing to overwrite restricted output.",
                              call. = FALSE)
  object$schema_version <- paste0(
    "v46_0_nhanes_quality_", module, "_restricted"
  )
  object$run_id <- run_id
  object$created_at_utc <- format(
    Sys.time(), "%Y-%m-%dT%H:%M:%SZ", tz = "UTC"
  )
  object$input_hashes <- input_hashes
  object$coefficient_visibility <- "RESTRICTED"
  object$participant_level_data_saved <- FALSE
  object$completed_dataset_saved <- FALSE
  object$fit_objects_saved <- FALSE
  object$individual_weights_or_predictions_saved <- FALSE
  object$independent_validation_status <- "NOT_RUN"
  v45_atomic_save_rds(object, path)
  state$status[[row]] <<- "RESTRICTED_COMPLETE"
  state$output_path_alias[[row]] <<- module_alias(module)
  state$output_sha256[[row]] <<- v45_sha256_file(path)
  state$completed_at[[row]] <<- format(
    Sys.time(), "%Y-%m-%dT%H:%M:%S%z"
  )
  write_state()
  append_log(paste0(module, " completed; restricted SHA-256=",
                    state$output_sha256[[row]]))
}
read_module <- function(module) {
  row <- match(module, state$module)
  if (is.na(row) || state$status[[row]] != "RESTRICTED_COMPLETE") {
    stop(module, " prerequisite is incomplete.", call. = FALSE)
  }
  path <- file.path(root, state$output_path_alias[[row]])
  if (!identical(v45_sha256_file(path), state$output_sha256[[row]])) {
    stop(module, " restricted hash failed.", call. = FALSE)
  }
  value <- readRDS(path)
  if (!identical(value$input_hashes, input_hashes)) {
    stop(module, " input hashes drifted.", call. = FALSE)
  }
  value
}

parallel_map <- function(indices, fun, label) {
  append_log(paste0(label, " started with ", workers, " worker(s)."))
  wrapper <- function(i) tryCatch(
    list(ok = TRUE, value = fun(i), error = ""),
    error = function(e) list(ok = FALSE, value = NULL,
                             error = conditionMessage(e))
  )
  result <- if (workers == 1L) lapply(indices, wrapper) else
    parallel::mclapply(
      indices, wrapper, mc.cores = workers,
      mc.preschedule = FALSE, mc.set.seed = FALSE
    )
  failed <- !vapply(result, `[[`, logical(1), "ok")
  if (any(failed)) {
    stop(label, " failed for imputation(s) ",
         paste(indices[failed], collapse = ","), ": ",
         paste(vapply(result[failed], `[[`, character(1), "error"),
               collapse = " | "), call. = FALSE)
  }
  append_log(paste0(label, " finished for all imputations."))
  lapply(result, `[[`, "value")
}

mig <- readRDS(mig_path)
if (!inherits(mig, "mids") || mig$m != expected$m) {
  stop("MI-G is not the frozen m=50 object.", call. = FALSE)
}
ledger <- v45_read_nhanes_ledger(root)
v43 <- v45_load_v43_nhanes_functions(root)
rw <- readRDS(paths$rw)
design_data <- v45_outcome_design_data(ledger, rw)
abc_anchor <- readRDS(paths$abc_anchor)
quality_map <- ledger$person_master[c("SEQN", "spirometry_ab")]
if (anyDuplicated(quality_map$SEQN) || anyNA(quality_map$spirometry_ab)) {
  stop("The strict-quality membership map is invalid.", call. = FALSE)
}
formulas <- list(
  AB_separate = v45_outcome_formula("E0", "A1"),
  AB_conditional = v45_outcome_formula(
    c("E0", "L_FEV1", "L_RATIO"), "A1"
  )
)
column_names <- c(
  "AB_separate", "AB_conditional", "ABC_conditional",
  "AB_conditional_minus_AB_separate",
  "AB_conditional_minus_ABC_conditional"
)

domain_weights <- function(completed) {
  merged <- v45_merge_completed_design(design_data, completed)
  index <- match(merged$SEQN, quality_map$SEQN)
  if (anyNA(index)) stop("Strict-quality join failed.", call. = FALSE)
  strict <- as.logical(quality_map$spirometry_ab[index])
  rows <- which(as.logical(merged$analysis_domain) & strict)
  cluster_index <- as.integer(rw$full_design_cluster_index[rows])
  base_weight <- as.numeric(rw$full_design_pweights[rows])
  local <- merged[rows, , drop = FALSE]
  if (nrow(local) != expected$n ||
      sum(as.integer(local$death) == 1L) != expected$deaths ||
      length(unique(local$design_strata)) != expected$strata ||
      length(unique(local$design_psu)) != expected$psu ||
      any(cluster_index < 1L | cluster_index > expected$psu) ||
      any(!is.finite(base_weight) | base_weight <= 0)) {
    stop("The strict A/B Rao-Wu domain drifted.", call. = FALSE)
  }
  list(data = local, cluster_index = cluster_index,
       base_weight = base_weight)
}

make_group <- function(point, replicates, compute_covariance) {
  valid <- apply(replicates, 1L, function(value) all(is.finite(value)))
  valid_n <- sum(valid)
  valid_fraction <- mean(valid)
  covariance <- matrix(
    NA_real_, length(point), length(point),
    dimnames = list(names(point), names(point))
  )
  if (compute_covariance && valid_n >= 2L) {
    centered <- sweep(
      replicates[valid, , drop = FALSE], 2L, point, FUN = "-"
    )
    covariance <- crossprod(centered) / (valid_n - 1L)
  }
  list(
    point = point,
    replicates = replicates,
    common_valid_mask = valid,
    within_covariance = covariance,
    valid_replicate_n = valid_n,
    valid_replicate_fraction = valid_fraction,
    failure_count = sum(!valid),
    variance_rule = "1/(B_valid-1)",
    covariance_computed = compute_covariance
  )
}

one_imputation <- function(imputation, replicate_indices, prefix_result = NULL) {
  completed <- v45_prepare_mig_completed(
    mice::complete(mig, action = imputation), ledger, v43
  )
  domain <- domain_weights(completed)
  if (is.null(prefix_result)) {
    ab_separate <- v45_weighted_cox_coefficients(
      domain$data, domain$base_weight, formulas$AB_separate, "E0",
      paste0("v46_AB_separate_point_imp", imputation)
    )[[1L]]
    ab_conditional <- v45_weighted_cox_coefficients(
      domain$data, domain$base_weight, formulas$AB_conditional, "E0",
      paste0("v46_AB_conditional_point_imp", imputation)
    )[[1L]]
    abc_conditional <- abc_anchor$results[[imputation]]$point[["G6a_E0"]]
    point <- c(
      AB_separate = ab_separate,
      AB_conditional = ab_conditional,
      ABC_conditional = abc_conditional,
      AB_conditional_minus_AB_separate = ab_conditional - ab_separate,
      AB_conditional_minus_ABC_conditional =
        ab_conditional - abc_conditional
    )
  } else {
    point <- prefix_result$group$point
  }
  if (!identical(names(point), column_names) || any(!is.finite(point))) {
    stop("NHANES strict-quality point interface failed.", call. = FALSE)
  }
  replicate_names <- paste0("rep", replicate_indices)
  new_replicates <- matrix(
    NA_real_, nrow = length(replicate_indices), ncol = length(point),
    dimnames = list(replicate_names, names(point))
  )
  errors <- character()
  for (j in seq_along(replicate_indices)) {
    r <- replicate_indices[[j]]
    weight <- domain$base_weight *
      rw$modules[["RW-GLI"]]$matrix[domain$cluster_index, r]
    value <- tryCatch({
      ab_separate <- v45_weighted_cox_coefficients(
        domain$data, weight, formulas$AB_separate, "E0",
        paste0("v46_AB_separate_imp", imputation, "_rep", r)
      )[[1L]]
      ab_conditional <- v45_weighted_cox_coefficients(
        domain$data, weight, formulas$AB_conditional, "E0",
        paste0("v46_AB_conditional_imp", imputation, "_rep", r)
      )[[1L]]
      abc_conditional <- abc_anchor$results[[imputation]]$replicates[
        paste0("rep", r), "G6a_E0"
      ]
      c(
        AB_separate = ab_separate,
        AB_conditional = ab_conditional,
        ABC_conditional = abc_conditional,
        AB_conditional_minus_AB_separate = ab_conditional - ab_separate,
        AB_conditional_minus_ABC_conditional =
          ab_conditional - abc_conditional
      )
    }, error = function(e) {
      errors <<- c(errors, conditionMessage(e))
      setNames(rep(NA_real_, length(point)), names(point))
    })
    new_replicates[j, ] <- value
  }
  if (is.null(prefix_result)) {
    all_replicates <- new_replicates
  } else {
    if (!identical(rownames(prefix_result$group$replicates),
                   paste0("rep", seq_len(250L))) ||
        !identical(colnames(prefix_result$group$replicates), names(point)) ||
        !identical(prefix_result$group$point, point)) {
      stop("NHANES prefix/full interface failed.", call. = FALSE)
    }
    all_replicates <- rbind(prefix_result$group$replicates, new_replicates)
  }
  list(
    imputation = as.integer(imputation),
    group = make_group(
      point, all_replicates,
      compute_covariance = nrow(all_replicates) == expected$replicates
    ),
    error_count = length(errors),
    unique_error_count = length(unique(errors)),
    sample_anchor = data.frame(
      imputation = as.integer(imputation), n = expected$n,
      deaths = expected$deaths, design_strata = expected$strata,
      design_psu = expected$psu, design_df = expected$design_df,
      stringsAsFactors = FALSE
    )
  )
}

pool_scalar <- function(q, u) {
  pooled <- mice::pool.scalar(
    Q = as.numeric(q), U = as.numeric(u), n = expected$design_df + 1,
    k = 1, rule = "rubin1987"
  )
  se <- sqrt(pooled$t)
  critical <- stats::qt(0.975, df = pooled$df)
  p_value <- 2 * stats::pt(
    abs(pooled$qbar / se), df = pooled$df, lower.tail = FALSE
  )
  data.frame(
    m = pooled$m, estimate = pooled$qbar, standard_error = se,
    ci_low = pooled$qbar - critical * se,
    ci_high = pooled$qbar + critical * se,
    p_value = p_value, within_variance = pooled$ubar,
    between_variance = pooled$b, total_variance = pooled$t,
    df = pooled$df, complete_data_design_df = expected$design_df,
    fraction_missing_information = pooled$fmi,
    relative_efficiency = 1 / (1 + pooled$fmi / pooled$m),
    monte_carlo_error = sqrt(pooled$b / pooled$m),
    monte_carlo_error_fraction = sqrt(pooled$b / pooled$m) / se,
    stringsAsFactors = FALSE
  )
}

run_module <- function(module) {
  row <- match(module, state$module)
  if (state$status[[row]] == "RESTRICTED_COMPLETE") {
    append_log(paste0(module, " already complete; verified and skipped."))
    return(invisible(read_module(module)))
  }
  prefix <- NULL
  if (module == "full") {
    prefix <- read_module("prefix")
    if (!prefix$prefix_gate %in% c("GO", "CAUTION") ||
        !identical(prefix$replicate_indices, seq_len(250L))) {
      stop("NHANES prefix did not authorize full execution.",
           call. = FALSE)
    }
  }
  state$status[[row]] <<- "RUNNING"
  write_state()
  append_log(paste0(module, " restricted transaction started."))
  indices <- if (module == "prefix") seq_len(250L) else 251:500
  results <- parallel_map(seq_len(expected$m), function(i) {
    one_imputation(
      i, indices, if (is.null(prefix)) NULL else prefix$results[[i]]
    )
  }, paste0("V46 NHANES ", module, " literal replicate columns"))
  minimum_valid <- min(vapply(
    results, function(x) x$group$valid_replicate_fraction, numeric(1)
  ))
  gate <- if (minimum_valid >= 0.90) "GO" else if (
    minimum_valid >= 0.80
  ) "CAUTION" else "STOP"
  object <- list(
    module = module, mi_object = "MI-G", requested_m = expected$m,
    replicate_indices = if (module == "prefix") seq_len(250L) else
      seq_len(expected$replicates),
    executed_in_this_transaction = indices,
    prefix_sha256 = if (module == "full")
      state$output_sha256[state$module == "prefix"] else NA_character_,
    literal_prefix_identity = if (module == "full") all(vapply(
      seq_len(expected$m), function(i) identical(
        prefix$results[[i]]$group$replicates,
        results[[i]]$group$replicates[seq_len(250L), , drop = FALSE]
      ), logical(1)
    )) else NA,
    results = results,
    sample_anchors = do.call(rbind, lapply(results, `[[`, "sample_anchor")),
    minimum_valid_replicate_fraction = minimum_valid,
    prefix_gate = if (module == "prefix") gate else NA_character_,
    full_gate = if (module == "full") gate else NA_character_,
    coefficient_blind_prefix_gate = module == "prefix",
    prefix_pooling_or_release_performed = FALSE,
    variance_rule = "1/(B_valid-1)", no_replacement_replicates = TRUE
  )
  if (module == "full" && !isTRUE(object$literal_prefix_identity)) {
    stop("NHANES full object failed prefix identity.", call. = FALSE)
  }
  if (module == "full" && gate != "STOP") {
    pooled <- do.call(rbind, lapply(column_names, function(column) {
      q <- vapply(results, function(x) x$group$point[[column]], numeric(1))
      u <- vapply(results, function(x) {
        x$group$within_covariance[column, column]
      }, numeric(1))
      cbind(data.frame(estimand = column, stringsAsFactors = FALSE),
            pool_scalar(q, u))
    }))
    object$pooled_scalar <- pooled
    object$pooling_status <- "COMPLETE"
    object$m100_trigger_metadata <- list(
      policy = "WHOLE_MI_OBJECT_NO_SELECTIVE_MODEL_UPGRADE",
      trigger = any(pooled$monte_carlo_error_fraction >= 0.10),
      threshold = 0.10,
      automatic_m100_execution = FALSE
    )
  } else if (module == "full") {
    object$pooling_status <- "NOT_PERFORMED_FULL_GATE_STOP"
  } else {
    object$pooling_status <- "NOT_APPLICABLE_PREFIX"
  }
  publish_module(module, object)
  if (gate == "STOP") stop(module, " valid-fraction gate is STOP.",
                           call. = FALSE)
  invisible(object)
}

requested <- if (module_requested == "all") c("prefix", "full") else
  module_requested
append_log(paste0("Requested module: ", module_requested))
for (module in requested) run_module(module)
append_log("Requested V46 NHANES restricted execution completed.")
cat("V46_NHANES_RESTRICTED_EXECUTION_COMPLETE\n")
cat("run_id=", run_id, "\n", sep = "")
cat("coefficient_visibility=RESTRICTED\n")
cat("independent_validation_status=NOT_RUN\n")
