#!/usr/bin/env Rscript

# Independent aggregate validator and release gate for the V46.0 NHANES
# strict A/B spirometry-quality sensitivity.

options(stringsAsFactors = FALSE, warn = 1)

v460_root <- function() {
  args <- commandArgs(trailingOnly = FALSE)
  file_arg <- grep("^--file=", args, value = TRUE)
  if (!length(file_arg)) return(normalizePath(getwd(), mustWork = TRUE))
  script <- sub("^--file=", "", file_arg[[1L]])
  normalizePath(file.path(dirname(script), "..", ".."), mustWork = TRUE)
}

root <- v460_root()
source(file.path(root, "R", "v45", "01_nhanes_common_utilities_v45.R"))
v45_require_packages(root)

read_tsv <- function(path) {
  utils::read.delim(
    path, stringsAsFactors = FALSE, check.names = FALSE,
    na.strings = c("", "NA")
  )
}

expected <- list(
  protocol =
    "c87545ae0ea129bb9e9894dd02f3890d9ff74e2d83eb75b4ae1010c829a6dd6d",
  mig =
    "41bcc3e5fbfd8f19501682e93354856ffc06adf6e426937327e07138d17733d3",
  rw =
    "2d795d61aabcce42603b1cfa7b254239a716980821ad1865347a8a8327c9f152",
  abc_anchor =
    "63804066d87a6af0e1a9b61d57d5a318ca4c0d13417f6fee4bfea601272e2daf",
  m = 50L,
  replicates = 500L,
  n = 5925L,
  deaths = 758L,
  strata = 45L,
  psu = 94L,
  design_df = 49L,
  abc_n = 6540L,
  abc_deaths = 885L,
  valid_fraction_stop = 0.80,
  numeric_tolerance = 1e-10,
  covariance_tolerance = 1e-10,
  mce_fraction_max = 0.10
)

public_root <- file.path(root, "results", "v46", "nhanes_quality")
current_path <- file.path(public_root, "v46_nhanes_restricted_current.tsv")
current <- read_tsv(current_path)
if (nrow(current) != 1L ||
    !identical(current$coefficient_visibility[[1L]], "RESTRICTED") ||
    !identical(current$independent_validation_status[[1L]], "NOT_RUN") ||
    !identical(
      v45_sha256_file(file.path(root, current$state_path_alias[[1L]])),
      current$state_sha256[[1L]]
    )) {
  stop("The V46 NHANES restricted-run pointer is invalid.", call. = FALSE)
}
run_id <- current$run_id[[1L]]
state_path <- file.path(root, current$state_path_alias[[1L]])
state <- read_tsv(state_path)
if (!identical(state$module, c("prefix", "full")) ||
    any(state$status != "RESTRICTED_COMPLETE")) {
  stop("Both V46 NHANES restricted modules are required.", call. = FALSE)
}
module_paths <- file.path(root, state$output_path_alias)
module_hashes <- vapply(module_paths, v45_sha256_file, character(1))
if (!identical(unname(module_hashes), as.character(state$output_sha256))) {
  stop("A V46 NHANES restricted-module hash failed.", call. = FALSE)
}
objects <- setNames(lapply(module_paths, readRDS), state$module)
prefix <- objects$prefix
full <- objects$full

checks <- list()
add_check <- function(check, pass, observed, expected_value) {
  checks[[length(checks) + 1L]] <<- data.frame(
    check = check,
    status = if (isTRUE(pass)) "PASS" else "FAIL",
    observed = as.character(observed),
    expected = as.character(expected_value),
    stringsAsFactors = FALSE
  )
}

add_check(
  "restricted_module_hashes", all(!is.na(module_hashes)),
  paste(module_hashes, collapse = ";"), "two exact hashes"
)
schema_ok <- identical(
  prefix$schema_version, "v46_0_nhanes_quality_prefix_restricted"
) && identical(
  full$schema_version, "v46_0_nhanes_quality_full_restricted"
)
add_check(
  "restricted_schemas", schema_ok,
  paste(prefix$schema_version, full$schema_version, sep = ";"),
  "two V46.0 NHANES schemas"
)
privacy_ok <- all(vapply(objects, function(x) {
  identical(x$coefficient_visibility, "RESTRICTED") &&
    identical(x$participant_level_data_saved, FALSE) &&
    identical(x$completed_dataset_saved, FALSE) &&
    identical(x$fit_objects_saved, FALSE) &&
    identical(x$individual_weights_or_predictions_saved, FALSE)
}, logical(1)))
add_check("restricted_privacy_flags", privacy_ok, privacy_ok, TRUE)

mig_pointer <- read_tsv(file.path(
  root, "results", "v45", "production_mi", "MI_G_m50_current.tsv"
))
mig_path <- file.path(root, mig_pointer$mids_path_alias[[1L]])
protocol_path <- file.path(
  root, "protocol", "pef_mortality_analysis_plan_v46_0_revision.md"
)
rw_path <- file.path(
  root, "derived_sensitive", "v45", "v45_rao_wu_replicate_contract.rds"
)
anchor_path <- file.path(
  root, "derived_sensitive", "v45", "outcome_execution", "m50",
  "v45_nhanes_outcome_m50_20260725T150659_pid55259",
  "paired_full_restricted.rds"
)
runner_path <- file.path(root, "R", "v46", "03_run_nhanes_quality_v46.R")
current_input_hashes <- list(
  protocol = v45_sha256_file(protocol_path),
  preflight_status = v45_sha256_file(file.path(
    root, "results", "v46", "structural_preflight",
    "v46_0_preflight_status.tsv"
  )),
  preflight_checks = v45_sha256_file(file.path(
    root, "results", "v46", "structural_preflight",
    "v46_0_structural_checks.tsv"
  )),
  preflight_manifest = v45_sha256_file(file.path(
    root, "results", "v46", "structural_preflight",
    "v46_0_input_manifest.tsv"
  )),
  preflight_nhanes = v45_sha256_file(file.path(
    root, "results", "v46", "structural_preflight",
    "v46_0_nhanes_matrix_diagnostics.tsv"
  )),
  mi_g_m50 = v45_sha256_file(mig_path),
  rao_wu_contract = v45_sha256_file(rw_path),
  abc_anchor = v45_sha256_file(anchor_path),
  execution_script = v45_sha256_file(runner_path)
)
inputs_current <- identical(prefix$input_hashes, full$input_hashes) &&
  identical(full$input_hashes, current_input_hashes) &&
  identical(current_input_hashes$protocol, expected$protocol) &&
  identical(current_input_hashes$mi_g_m50, expected$mig) &&
  identical(current_input_hashes$rao_wu_contract, expected$rw) &&
  identical(current_input_hashes$abc_anchor, expected$abc_anchor)
add_check(
  "frozen_input_hashes_current", inputs_current,
  if (inputs_current) "all exact" else "mismatch", "all exact"
)

abc_anchor <- readRDS(anchor_path)
abc_literal_identity <- length(abc_anchor$results) == expected$m &&
  all(vapply(seq_len(expected$m), function(i) {
    identical(
      full$results[[i]]$group$point[["ABC_conditional"]],
      abc_anchor$results[[i]]$point[["G6a_E0"]]
    ) && identical(
      full$results[[i]]$group$replicates[, "ABC_conditional"],
      abc_anchor$results[[i]]$replicates[, "G6a_E0"]
    )
  }, logical(1)))
add_check(
  "frozen_ABC_point_and_replicate_identity", abc_literal_identity,
  abc_literal_identity, TRUE
)

column_names <- c(
  "AB_separate", "AB_conditional", "ABC_conditional",
  "AB_conditional_minus_AB_separate",
  "AB_conditional_minus_ABC_conditional"
)
prefix_complete <- length(prefix$results) == expected$m &&
  identical(prefix$replicate_indices, seq_len(250L)) &&
  all(vapply(seq_len(expected$m), function(i) {
    result <- prefix$results[[i]]
    identical(result$imputation, as.integer(i)) &&
      identical(names(result$group$point), column_names) &&
      identical(dim(result$group$replicates), c(250L, 5L)) &&
      identical(colnames(result$group$replicates), column_names) &&
      all(is.finite(result$group$point)) &&
      all(is.finite(result$group$replicates) |
            is.na(result$group$replicates))
  }, logical(1)))
full_complete <- length(full$results) == expected$m &&
  identical(full$replicate_indices, seq_len(expected$replicates)) &&
  all(vapply(seq_len(expected$m), function(i) {
    result <- full$results[[i]]
    identical(result$imputation, as.integer(i)) &&
      identical(names(result$group$point), column_names) &&
      identical(dim(result$group$replicates), c(expected$replicates, 5L)) &&
      identical(colnames(result$group$replicates), column_names) &&
      all(is.finite(result$group$point)) &&
      all(is.finite(result$group$replicates) |
            is.na(result$group$replicates))
  }, logical(1)))
add_check(
  "prefix_result_completeness", prefix_complete,
  paste(length(prefix$results), "imputations"), "50 complete imputations"
)
add_check(
  "full_result_completeness", full_complete,
  paste(length(full$results), "imputations"), "50 complete imputations"
)

prefix_identity <- isTRUE(full$literal_prefix_identity) &&
  all(vapply(seq_len(expected$m), function(i) {
    p <- prefix$results[[i]]$group
    f <- full$results[[i]]$group
    identical(p$point, f$point) &&
      identical(p$replicates,
                f$replicates[seq_len(250L), , drop = FALSE])
  }, logical(1)))
add_check("literal_prefix_identity", prefix_identity,
          prefix_identity, TRUE)

anchors <- full$sample_anchors
anchors_ok <- nrow(anchors) == expected$m &&
  identical(as.integer(anchors$imputation), seq_len(expected$m)) &&
  all(anchors$n == expected$n) && all(anchors$deaths == expected$deaths) &&
  all(anchors$design_strata == expected$strata) &&
  all(anchors$design_psu == expected$psu) &&
  all(anchors$design_df == expected$design_df)
add_check(
  "strict_quality_sample_anchors", anchors_ok,
  paste(nrow(anchors), "rows"), "50 exact A/B-domain anchors"
)

valid_fractions <- vapply(full$results, function(x) {
  x$group$valid_replicate_fraction
}, numeric(1))
valid_gate_ok <- all(is.finite(valid_fractions)) &&
  min(valid_fractions) >= expected$valid_fraction_stop &&
  full$full_gate %in% c("GO", "CAUTION")
add_check(
  "full_valid_replicate_gate", valid_gate_ok,
  paste0("minimum=", min(valid_fractions), ";gate=", full$full_gate),
  "minimum>=0.80 and gate GO/CAUTION"
)

independent_covariance <- function(point, replicates) {
  valid <- apply(replicates, 1L, function(value) all(is.finite(value)))
  centered <- sweep(
    replicates[valid, , drop = FALSE], 2L, point, FUN = "-"
  )
  covariance <- crossprod(centered) / (sum(valid) - 1L)
  dimnames(covariance) <- list(names(point), names(point))
  list(covariance = covariance, valid = valid)
}
covariance_differences <- vapply(full$results, function(x) {
  independent <- independent_covariance(
    x$group$point, x$group$replicates
  )
  if (!identical(independent$valid, x$group$common_valid_mask)) return(Inf)
  max(abs(independent$covariance - x$group$within_covariance))
}, numeric(1))
covariance_ok <- all(is.finite(covariance_differences)) &&
  max(covariance_differences) <= expected$covariance_tolerance
add_check(
  "independent_replicate_covariance", covariance_ok,
  paste0("maximum absolute difference=", max(covariance_differences)),
  paste0("<=", expected$covariance_tolerance)
)

independent_pool <- function(q, u) {
  pooled <- mice::pool.scalar(
    Q = as.numeric(q), U = as.numeric(u), n = expected$design_df + 1,
    k = 1, rule = "rubin1987"
  )
  se <- sqrt(pooled$t)
  critical <- stats::qt(0.975, df = pooled$df)
  p_value <- 2 * stats::pt(
    abs(pooled$qbar / se), df = pooled$df, lower.tail = FALSE
  )
  data.frame(
    m = pooled$m, estimate = pooled$qbar, standard_error = se,
    ci_low = pooled$qbar - critical * se,
    ci_high = pooled$qbar + critical * se,
    p_value = p_value, within_variance = pooled$ubar,
    between_variance = pooled$b, total_variance = pooled$t,
    df = pooled$df, complete_data_design_df = expected$design_df,
    fraction_missing_information = pooled$fmi,
    relative_efficiency = 1 / (1 + pooled$fmi / pooled$m),
    monte_carlo_error = sqrt(pooled$b / pooled$m),
    monte_carlo_error_fraction = sqrt(pooled$b / pooled$m) / se,
    stringsAsFactors = FALSE
  )
}
independent_scalar <- do.call(rbind, lapply(column_names, function(column) {
  q <- vapply(full$results, function(x) x$group$point[[column]], numeric(1))
  u <- vapply(full$results, function(x) {
    x$group$within_covariance[column, column]
  }, numeric(1))
  cbind(data.frame(estimand = column, stringsAsFactors = FALSE),
        independent_pool(q, u))
}))
rownames(independent_scalar) <- NULL
stored_scalar <- full$pooled_scalar
fields <- c(
  "m", "estimate", "standard_error", "ci_low", "ci_high", "p_value",
  "within_variance", "between_variance", "total_variance", "df",
  "complete_data_design_df", "fraction_missing_information",
  "relative_efficiency", "monte_carlo_error",
  "monte_carlo_error_fraction"
)
pool_differences <- vapply(column_names, function(column) {
  independent <- independent_scalar[
    independent_scalar$estimand == column, , drop = FALSE
  ]
  stored <- stored_scalar[stored_scalar$estimand == column, , drop = FALSE]
  if (nrow(independent) != 1L || nrow(stored) != 1L) return(Inf)
  max(abs(
    as.numeric(unlist(independent[1L, fields], use.names = FALSE)) -
      as.numeric(unlist(stored[1L, fields], use.names = FALSE))
  ))
}, numeric(1))
pool_ok <- all(is.finite(pool_differences)) &&
  max(pool_differences) <= expected$numeric_tolerance
add_check(
  "independent_Rubin_pooling", pool_ok,
  paste0("maximum absolute difference=", max(pool_differences)),
  paste0("<=", expected$numeric_tolerance)
)

mce_ok <- all(is.finite(stored_scalar$monte_carlo_error_fraction)) &&
  all(stored_scalar$monte_carlo_error_fraction <
        expected$mce_fraction_max) &&
  !isTRUE(full$m100_trigger_metadata$trigger)
add_check(
  "m50_Monte_Carlo_error_gate", mce_ok,
  paste0("maximum fraction=",
         max(stored_scalar$monte_carlo_error_fraction)),
  paste0("<", expected$mce_fraction_max)
)

old_release <- read_tsv(file.path(
  root, "results", "v45", "outcome_execution",
  "v45_nhanes_released_results.tsv"
))
old_abc <- old_release[
  old_release$analysis_id == "v45_g6a" & old_release$term == "E0",
  , drop = FALSE
]
new_abc <- stored_scalar[
  stored_scalar$estimand == "ABC_conditional", , drop = FALSE
]
abc_difference <- if (nrow(old_abc) == 1L && nrow(new_abc) == 1L) {
  abs(old_abc$estimate[[1L]] - new_abc$estimate[[1L]])
} else Inf
abc_anchor_ok <- is.finite(abc_difference) &&
  abc_difference <= expected$numeric_tolerance
add_check(
  "frozen_ABC_conditional_point_reproduction", abc_anchor_ok,
  paste0("absolute point-estimate difference=", abc_difference),
  paste0("<=", expected$numeric_tolerance)
)

checks_table <- do.call(rbind, checks)
rownames(checks_table) <- NULL
validation_path <- file.path(
  public_root, "v46_nhanes_independent_validation_checks.tsv"
)
v45_atomic_write_tsv(checks_table, validation_path)
if (!all(checks_table$status == "PASS")) {
  stop("V46 NHANES independent validation failed; release blocked.",
       call. = FALSE)
}

metadata <- data.frame(
  estimand = column_names,
  analysis_id = c(
    "v46_nhanes_ab_a1_separate",
    "v46_nhanes_ab_a1_conditional",
    "v46_nhanes_abc_a1_conditional_anchor",
    "v46_nhanes_ab_conditional_minus_separate",
    "v46_nhanes_ab_minus_abc_conditional"
  ),
  term = c("E0", "E0", "E0", "beta_difference", "beta_difference"),
  sample_id = c(
    "nhanes_pef_A_x_spirometry_AB",
    "nhanes_pef_A_x_spirometry_AB",
    "nhanes_pef_A_x_spirometry_ABC",
    "nhanes_pef_A_x_spirometry_AB",
    "AB_vs_ABC_overlapping_domains"
  ),
  role = c(
    "strict_quality_sensitivity", "strict_quality_sensitivity",
    "frozen_reference_anchor", "paired_conditioning_contrast",
    "paired_quality_domain_contrast"
  ),
  effect_measure = c(
    "hazard_ratio", "hazard_ratio", "hazard_ratio",
    "ratio_of_hazard_ratios", "ratio_of_hazard_ratios"
  ),
  stringsAsFactors = FALSE
)
release <- merge(metadata, stored_scalar, by = "estimand", sort = FALSE)
release <- release[match(column_names, release$estimand), , drop = FALSE]
release$cohort <- "NHANES"
release$strict_quality_n <- expected$n
release$strict_quality_deaths <- expected$deaths
release$reference_abc_n <- expected$abc_n
release$reference_abc_deaths <- expected$abc_deaths
release$design_strata <- expected$strata
release$design_psu <- expected$psu
release$effect <- exp(release$estimate)
release$effect_ci_low <- exp(release$ci_low)
release$effect_ci_high <- exp(release$ci_high)
release$independent_validation_status <- "PASS"
release_path <- file.path(
  public_root, "v46_nhanes_quality_released_results.tsv"
)
v45_atomic_write_tsv(release, release_path)

manifest <- data.frame(
  artifact = c(
    "released_results", "validation_checks", "prefix_restricted",
    "full_restricted", "validator_script"
  ),
  path_alias = c(
    substring(release_path, nchar(root) + 2L),
    substring(validation_path, nchar(root) + 2L),
    state$output_path_alias[state$module == "prefix"],
    state$output_path_alias[state$module == "full"],
    "R/v46/04_validate_nhanes_quality_v46.R"
  ),
  sha256 = c(
    v45_sha256_file(release_path), v45_sha256_file(validation_path),
    state$output_sha256[state$module == "prefix"],
    state$output_sha256[state$module == "full"],
    v45_sha256_file(file.path(
      root, "R", "v46", "04_validate_nhanes_quality_v46.R"
    ))
  ),
  stringsAsFactors = FALSE
)
manifest_path <- file.path(
  public_root, "v46_nhanes_release_manifest.tsv"
)
v45_atomic_write_tsv(manifest, manifest_path)
validated_pointer <- data.frame(
  run_id = run_id,
  release_path_alias = substring(release_path, nchar(root) + 2L),
  release_sha256 = v45_sha256_file(release_path),
  validation_path_alias = substring(validation_path, nchar(root) + 2L),
  validation_sha256 = v45_sha256_file(validation_path),
  release_manifest_path_alias = substring(manifest_path, nchar(root) + 2L),
  release_manifest_sha256 = v45_sha256_file(manifest_path),
  status = "INDEPENDENT_VALIDATION_PASS",
  validated_at_utc = format(
    Sys.time(), "%Y-%m-%dT%H:%M:%SZ", tz = "UTC"
  ),
  stringsAsFactors = FALSE
)
v45_atomic_write_tsv(
  validated_pointer,
  file.path(public_root, "v46_nhanes_validated_current.tsv")
)
cat("V46_NHANES_INDEPENDENT_VALIDATION_PASS\n")
cat("run_id=", run_id, "\n", sep = "")
cat("public_aggregate_release=complete\n")
