#!/usr/bin/env Rscript

# Restricted V46.0 CHARLS adjacent-transition primary analysis.
# Prefix columns 1-250 are evaluated without pooling or public coefficient
# release. Columns 251-500 run only after the prefix numerical gate permits it.

options(stringsAsFactors = FALSE, warn = 1)

v460_root <- function() {
  args <- commandArgs(trailingOnly = FALSE)
  file_arg <- grep("^--file=", args, value = TRUE)
  if (!length(file_arg)) return(normalizePath(getwd(), mustWork = TRUE))
  script <- sub("^--file=", "", file_arg[[1L]])
  normalizePath(file.path(dirname(script), "..", ".."), mustWork = TRUE)
}

root <- v460_root()
Sys.setenv(V45_CHARLS_OUTCOME_LIBRARY_ONLY = "yes")
sys.source(
  file.path(
    root, "R", "v45", "charls_addendum_v45_1",
    "12_run_charls_outcome_execution_v45_1.R"
  ),
  envir = .GlobalEnv
)
v45c_validate_runtime(root)

args <- commandArgs(trailingOnly = TRUE)
arg_value <- function(prefix, default = NULL) {
  hit <- grep(paste0("^", prefix, "="), args, value = TRUE)
  if (!length(hit)) return(default)
  sub(paste0("^", prefix, "="), "", tail(hit, 1L))
}
module_requested <- arg_value("--module", "all")
if (!module_requested %in% c("prefix", "full", "all")) {
  stop("--module must be prefix, full, or all.", call. = FALSE)
}
workers <- suppressWarnings(as.integer(arg_value("--workers", "4")))
if (!is.finite(workers) || workers < 1L || workers > 8L) {
  stop("--workers must be an integer from 1 through 8.", call. = FALSE)
}
workers <- min(workers, max(1L, parallel::detectCores() - 1L))

read_tsv <- function(path) {
  utils::read.delim(
    path, stringsAsFactors = FALSE, check.names = FALSE,
    na.strings = c("", "NA")
  )
}

expected <- list(
  protocol =
    "c87545ae0ea129bb9e9894dd02f3890d9ff74e2d83eb75b4ae1010c829a6dd6d",
  mic0 =
    "8d7d0b16cf6028ac6ba1c7566d5957c650398c612138fdf1c2aae96424fb2f9e",
  actual =
    "2e80186cacd93d8f9c29aac1dc02168d545e4f43a4cded86542565bb7a01937c",
  adjacent_anchor =
    "83a50c89d5cb2023eae6c39a5b0084b7cda45713d6100eab034dcc9612a69477",
  m = 50L,
  replicates = 500L,
  n = 12427L,
  deaths = 1539L,
  period_rows = 44778L,
  psu = 432L,
  design_df = 431L,
  identity_tolerance = 1e-8
)

paths <- list(
  protocol = file.path(
    root, "protocol", "pef_mortality_analysis_plan_v46_0_revision.md"
  ),
  preflight_status = file.path(
    root, "results", "v46", "structural_preflight",
    "v46_0_preflight_status.tsv"
  ),
  preflight_checks = file.path(
    root, "results", "v46", "structural_preflight",
    "v46_0_structural_checks.tsv"
  ),
  preflight_manifest = file.path(
    root, "results", "v46", "structural_preflight",
    "v46_0_input_manifest.tsv"
  ),
  preflight_charls = file.path(
    root, "results", "v46", "structural_preflight",
    "v46_0_charls_matrix_diagnostics.tsv"
  ),
  mic0_pointer = file.path(
    root, "results", "v45", "charls_addendum_v45_1", "production_mi",
    "MI_C0_m50_validated.tsv"
  ),
  adjacent_anchor = file.path(
    root, "derived_sensitive", "v45", "charls_addendum_v45_1",
    "outcome_execution", "m50",
    "charls_v45_1_outcome_m50_20260726T173101_pid11793",
    "adjacent_full_restricted.rds"
  ),
  runner = file.path(
    root, "R", "v46", "01_run_charls_adjacent_primary_v46.R"
  )
)

preflight_status <- read_tsv(paths$preflight_status)
preflight_checks <- read_tsv(paths$preflight_checks)
preflight_manifest <- read_tsv(paths$preflight_manifest)
preflight_charls <- read_tsv(paths$preflight_charls)
if (nrow(preflight_status) != 1L ||
    !identical(
      preflight_status$status[[1L]], "STRUCTURAL_PREFLIGHT_PASS"
    ) ||
    any(preflight_checks$status != "PASS") ||
    any(preflight_charls$status != "PASS") ||
    !identical(v45c_sha256_file(paths$protocol), expected$protocol)) {
  stop("V46.0 structural preflight is absent, failed, or stale.",
       call. = FALSE)
}
manifest_current <- vapply(
  file.path(root, preflight_manifest$path_alias),
  v45c_sha256_file, character(1)
)
if (anyNA(manifest_current) ||
    !identical(unname(manifest_current),
               as.character(preflight_manifest$sha256))) {
  stop("A V46.0 preflight-frozen input changed.", call. = FALSE)
}

mic0_pointer <- read_tsv(paths$mic0_pointer)
if (nrow(mic0_pointer) != 1L ||
    !identical(mic0_pointer$object_id[[1L]], "MI-C0") ||
    mic0_pointer$requested_m[[1L]] != expected$m ||
    !identical(
      mic0_pointer$status[[1L]], "INDEPENDENT_VALIDATION_PASS"
    ) ||
    !identical(mic0_pointer$mids_sha256[[1L]], expected$mic0)) {
  stop("The frozen MI-C0 pointer failed identity checks.", call. = FALSE)
}
mic0_path <- file.path(root, mic0_pointer$mids_path_alias[[1L]])
if (!identical(v45c_sha256_file(mic0_path), expected$mic0) ||
    !identical(
      v45c_sha256_file(paths$adjacent_anchor), expected$adjacent_anchor
    )) {
  stop("A frozen CHARLS execution input failed identity checks.",
       call. = FALSE)
}

public_root <- file.path(root, "results", "v46", "charls_adjacent_primary")
restricted_root <- file.path(
  root, "derived_sensitive", "v46", "charls_adjacent_primary"
)
log_root <- file.path(root, "logs", "v46", "charls_adjacent_primary")
dir.create(public_root, recursive = TRUE, showWarnings = FALSE)
dir.create(restricted_root, recursive = TRUE, showWarnings = FALSE)
dir.create(log_root, recursive = TRUE, showWarnings = FALSE)

current_path <- file.path(public_root, "v46_charls_restricted_current.tsv")
run_id_arg <- arg_value("--run-id", NULL)
if (!is.null(run_id_arg) && !grepl(
  "^v46_charls_adjacent_m50_[0-9]{8}T[0-9]{6}_pid[0-9]+$",
  run_id_arg
)) {
  stop("Unsafe or invalid --run-id.", call. = FALSE)
}
if (!is.null(run_id_arg)) {
  run_id <- run_id_arg
} else if (file.exists(current_path)) {
  current <- read_tsv(current_path)
  if (nrow(current) != 1L ||
      !grepl("^v46_charls_adjacent_m50_", current$run_id[[1L]])) {
    stop("The V46 CHARLS current-run pointer is invalid.", call. = FALSE)
  }
  run_id <- current$run_id[[1L]]
} else {
  run_id <- paste0(
    "v46_charls_adjacent_m50_",
    format(Sys.time(), "%Y%m%dT%H%M%S"), "_pid", Sys.getpid()
  )
}

run_dir <- file.path(restricted_root, run_id)
state_dir <- file.path(public_root, run_id)
dir.create(run_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(state_dir, recursive = TRUE, showWarnings = FALSE)
state_path <- file.path(state_dir, "module_state.tsv")
log_path <- file.path(log_root, paste0(run_id, ".log"))
state <- if (file.exists(state_path)) {
  read_tsv(state_path)
} else {
  data.frame(
    module = c("prefix", "full"),
    status = "NOT_RUN",
    output_path_alias = NA_character_,
    output_sha256 = NA_character_,
    completed_at = NA_character_,
    stringsAsFactors = FALSE
  )
}
if (!identical(state$module, c("prefix", "full")) ||
    any(!state$status %in% c("NOT_RUN", "RUNNING", "RESTRICTED_COMPLETE"))) {
  stop("V46 CHARLS module state is invalid.", call. = FALSE)
}
if (any(state$status == "RUNNING")) {
  stop("Interrupted RUNNING state requires audit and a new run ID.",
       call. = FALSE)
}

log_lines <- if (file.exists(log_path)) {
  readLines(log_path, warn = FALSE)
} else {
  c(
    paste0("run_id: ", run_id),
    "coefficient_visibility: restricted",
    "participant_level_output: forbidden",
    paste0("workers: ", workers)
  )
}
append_log <- function(value) {
  line <- paste0(
    format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z"), " ", value
  )
  log_lines <<- c(log_lines, line)
  v45c_atomic_write_lines(log_lines, log_path)
  message(value)
}

write_state <- function() {
  v45c_atomic_write_tsv(state, state_path)
  pointer <- data.frame(
    run_id = run_id,
    state_path_alias = substring(state_path, nchar(root) + 2L),
    state_sha256 = v45c_sha256_file(state_path),
    coefficient_visibility = "RESTRICTED",
    independent_validation_status = "NOT_RUN",
    stringsAsFactors = FALSE
  )
  v45c_atomic_write_tsv(pointer, current_path)
  invisible(TRUE)
}
write_state()

module_alias <- function(module) {
  file.path(
    "derived_sensitive", "v46", "charls_adjacent_primary", run_id,
    paste0(module, "_restricted.rds")
  )
}
module_path <- function(module) file.path(root, module_alias(module))

input_hashes <- list(
  protocol = v45c_sha256_file(paths$protocol),
  preflight_status = v45c_sha256_file(paths$preflight_status),
  preflight_checks = v45c_sha256_file(paths$preflight_checks),
  preflight_manifest = v45c_sha256_file(paths$preflight_manifest),
  preflight_charls = v45c_sha256_file(paths$preflight_charls),
  mic0_m50 = v45c_sha256_file(mic0_path),
  adjacent_anchor = v45c_sha256_file(paths$adjacent_anchor),
  execution_script = v45c_sha256_file(paths$runner)
)

publish_module <- function(module, object) {
  row <- match(module, state$module)
  if (is.na(row) || state$status[[row]] != "RUNNING") {
    stop(module, " is not in RUNNING state.", call. = FALSE)
  }
  path <- module_path(module)
  if (file.exists(path)) {
    stop("Refusing to overwrite restricted output: ", path, call. = FALSE)
  }
  object$schema_version <- paste0(
    "v46_0_charls_adjacent_", module, "_restricted"
  )
  object$run_id <- run_id
  object$created_at_utc <- format(
    Sys.time(), "%Y-%m-%dT%H:%M:%SZ", tz = "UTC"
  )
  object$input_hashes <- input_hashes
  object$coefficient_visibility <- "RESTRICTED"
  object$participant_level_data_saved <- FALSE
  object$completed_dataset_saved <- FALSE
  object$fit_objects_saved <- FALSE
  object$individual_weights_or_predictions_saved <- FALSE
  object$independent_validation_status <- "NOT_RUN"
  v45c_atomic_save_rds(object, path)
  state$status[[row]] <<- "RESTRICTED_COMPLETE"
  state$output_path_alias[[row]] <<- module_alias(module)
  state$output_sha256[[row]] <<- v45c_sha256_file(path)
  state$completed_at[[row]] <<- format(
    Sys.time(), "%Y-%m-%dT%H:%M:%S%z"
  )
  write_state()
  append_log(paste0(
    module, " completed; restricted SHA-256=",
    state$output_sha256[[row]]
  ))
  invisible(path)
}

read_module <- function(module) {
  row <- match(module, state$module)
  if (is.na(row) || state$status[[row]] != "RESTRICTED_COMPLETE") {
    stop(module, " prerequisite is incomplete.", call. = FALSE)
  }
  path <- file.path(root, state$output_path_alias[[row]])
  if (!file.exists(path) ||
      !identical(v45c_sha256_file(path), state$output_sha256[[row]])) {
    stop(module, " restricted output hash failed.", call. = FALSE)
  }
  value <- readRDS(path)
  if (!identical(value$input_hashes, input_hashes) ||
      !identical(value$coefficient_visibility, "RESTRICTED") ||
      !identical(value$independent_validation_status, "NOT_RUN")) {
    stop(module, " restricted metadata drifted.", call. = FALSE)
  }
  value
}

mic0 <- readRDS(mic0_path)
if (!inherits(mic0, "mids") || mic0$m != expected$m) {
  stop("MI-C0 is not the frozen m=50 object.", call. = FALSE)
}
context <- v45c_load_context(
  root, list(actual_design_contract_sha256 = expected$actual)
)
anchor <- readRDS(paths$adjacent_anchor)
if (length(anchor$results) != expected$m) {
  stop("Existing adjacent anchor lacks exact m=50.", call. = FALSE)
}

formulas <- list(
  E0_A0 = context$v43$model_formulas("E0", FALSE)$A0,
  E0_A1 = context$v43$model_formulas("E0", FALSE)$A1,
  E0_A2 = context$v43$model_formulas("E0", FALSE)$A2,
  E0b_A0 = context$v43$model_formulas("E0b", FALSE)$A0,
  E0b_A1 = context$v43$model_formulas("E0b", FALSE)$A1,
  E0b_A2 = context$v43$model_formulas("E0b", FALSE)$A2,
  E0_spline_A1 = context$v43$model_formulas("E0", TRUE)$A1
)
focal <- list(
  E0_A0 = "E0", E0_A1 = "E0", E0_A2 = "E0",
  E0b_A0 = "E0b", E0b_A1 = "E0b", E0b_A2 = "E0b",
  E0_spline_A1 = c(
    "E0_linear", "E0_nonlinear1", "E0_nonlinear2"
  )
)
column_names <- c(
  "E0_A0", "E0_A1", "E0_A2",
  "E0b_A0", "E0b_A1", "E0b_A2",
  "E0_linear", "E0_nonlinear1", "E0_nonlinear2"
)

fit_point <- function(period, model_id) {
  v45c_fit_cloglog(
    period, period$weight_biomarker_w1,
    formulas[[model_id]], focal[[model_id]],
    paste0("v46_", model_id, "_point"), point_survey = TRUE
  )$coefficients
}

one_imputation <- function(imputation, replicate_indices, prefix_result = NULL) {
  completed <- mice::complete(mic0, action = imputation)
  person <- v45c_prepare_person(
    completed, context$ledger, context$actual, context$v43, "MI-C0"
  )
  period <- v45c_build_period(
    person, context$ledger, context$actual,
    rep(TRUE, nrow(person)), adjacent = TRUE
  )
  v45c_assert_anchor(
    period, expected$n, expected$deaths, expected$period_rows,
    expected$psu, paste0("V46 adjacent imputation ", imputation)
  )
  existing <- anchor$results[[imputation]]$groups$ADJACENT_PAIRED
  if (!identical(dim(existing$replicates), c(expected$replicates, 3L))) {
    stop("Existing adjacent replicate anchor is malformed.", call. = FALSE)
  }
  caches <- list(
    E0_A0 = v45c_build_glm_cache(
      period, formulas$E0_A0, focal$E0_A0,
      paste0("v46_E0_A0_imp", imputation)
    ),
    E0_A2 = v45c_build_glm_cache(
      period, formulas$E0_A2, focal$E0_A2,
      paste0("v46_E0_A2_imp", imputation)
    ),
    E0b_A0 = v45c_build_glm_cache(
      period, formulas$E0b_A0, focal$E0b_A0,
      paste0("v46_E0b_A0_imp", imputation)
    ),
    E0b_A1 = v45c_build_glm_cache(
      period, formulas$E0b_A1, focal$E0b_A1,
      paste0("v46_E0b_A1_imp", imputation)
    ),
    E0b_A2 = v45c_build_glm_cache(
      period, formulas$E0b_A2, focal$E0b_A2,
      paste0("v46_E0b_A2_imp", imputation)
    ),
    E0_spline_A1 = v45c_build_glm_cache(
      period, formulas$E0_spline_A1, focal$E0_spline_A1,
      paste0("v46_E0_spline_A1_imp", imputation)
    )
  )
  if (is.null(prefix_result)) {
    point_e0_a0 <- fit_point(period, "E0_A0")[[1L]]
    point_e0_a1_fresh <- fit_point(period, "E0_A1")[[1L]]
    point_e0_a1_anchor <- existing$point[["adjacent_only"]]
    identity_difference <- abs(point_e0_a1_fresh - point_e0_a1_anchor)
    if (!is.finite(identity_difference) ||
        identity_difference > expected$identity_tolerance) {
      v45c_numeric_failure(
        paste0("A1-E0 adjacent point identity failed in imputation ",
               imputation, "."),
        "A1_POINT_IDENTITY_FAIL"
      )
    }
    point_e0_a2 <- fit_point(period, "E0_A2")[[1L]]
    point_e0b_a0 <- fit_point(period, "E0b_A0")[[1L]]
    point_e0b_a1 <- fit_point(period, "E0b_A1")[[1L]]
    point_e0b_a2 <- fit_point(period, "E0b_A2")[[1L]]
    point_spline <- fit_point(period, "E0_spline_A1")
    point <- c(
      E0_A0 = point_e0_a0,
      E0_A1 = point_e0_a1_anchor,
      E0_A2 = point_e0_a2,
      E0b_A0 = point_e0b_a0,
      E0b_A1 = point_e0b_a1,
      E0b_A2 = point_e0b_a2,
      E0_linear = point_spline[["E0_linear"]],
      E0_nonlinear1 = point_spline[["E0_nonlinear1"]],
      E0_nonlinear2 = point_spline[["E0_nonlinear2"]]
    )
  } else {
    point <- prefix_result$groups$CHARLS_ADJACENT_PRIMARY$point
    identity_difference <- prefix_result$point_identity_absolute_difference
  }
  if (!identical(names(point), column_names) || any(!is.finite(point))) {
    stop("V46 CHARLS point-vector interface failed.", call. = FALSE)
  }

  replicate_names <- v45c_literal_replicate_names(replicate_indices)
  replicates <- matrix(
    NA_real_, nrow = length(replicate_indices), ncol = length(point),
    dimnames = list(replicate_names, names(point))
  )
  failures <- character(length(replicate_indices))
  for (row in seq_along(replicate_indices)) {
    replicate_index <- replicate_indices[[row]]
    weights <- period$weight_biomarker_w1 *
      v45c_replicate_multiplier(
        period$community_id, context$actual$modules$adjacent,
        replicate_index
      )
    attempt <- v45c_try_replicate_fit({
      e0_a0 <- v45c_fit_cached_glm(
        caches$E0_A0, weights,
        paste0("v46_E0_A0_imp", imputation, "_", replicate_names[[row]])
      )$coefficients[[1L]]
      e0_a2 <- v45c_fit_cached_glm(
        caches$E0_A2, weights,
        paste0("v46_E0_A2_imp", imputation, "_", replicate_names[[row]])
      )$coefficients[[1L]]
      e0b_a0 <- v45c_fit_cached_glm(
        caches$E0b_A0, weights,
        paste0("v46_E0b_A0_imp", imputation, "_", replicate_names[[row]])
      )$coefficients[[1L]]
      e0b_a1 <- v45c_fit_cached_glm(
        caches$E0b_A1, weights,
        paste0("v46_E0b_A1_imp", imputation, "_", replicate_names[[row]])
      )$coefficients[[1L]]
      e0b_a2 <- v45c_fit_cached_glm(
        caches$E0b_A2, weights,
        paste0("v46_E0b_A2_imp", imputation, "_", replicate_names[[row]])
      )$coefficients[[1L]]
      spline <- v45c_fit_cached_glm(
        caches$E0_spline_A1, weights,
        paste0("v46_E0_spline_A1_imp", imputation, "_",
               replicate_names[[row]])
      )$coefficients
      c(
        E0_A0 = e0_a0,
        E0_A1 = existing$replicates[replicate_names[[row]],
                                    "adjacent_only"],
        E0_A2 = e0_a2,
        E0b_A0 = e0b_a0,
        E0b_A1 = e0b_a1,
        E0b_A2 = e0b_a2,
        E0_linear = spline[["E0_linear"]],
        E0_nonlinear1 = spline[["E0_nonlinear1"]],
        E0_nonlinear2 = spline[["E0_nonlinear2"]]
      )
    }, length(point), names(point))
    replicates[row, ] <- attempt$value
    failures[[row]] <- attempt$failure_class
  }
  group <- if (is.null(prefix_result)) {
    v45c_make_group(
      "CHARLS_ADJACENT_PRIMARY", point, replicates,
      setNames(rep(expected$design_df, length(point)), names(point)),
      failures, compute_covariance = FALSE
    )
  } else {
    v45c_extend_group(
      prefix_result$groups$CHARLS_ADJACENT_PRIMARY,
      replicates, failures
    )
  }
  rm(completed, person, period, caches)
  list(
    imputation = as.integer(imputation),
    groups = list(CHARLS_ADJACENT_PRIMARY = group),
    point_identity_absolute_difference = identity_difference,
    sample_anchors = data.frame(
      sample_id = "charls_primary_adjacent_windows",
      imputation = as.integer(imputation),
      n = expected$n,
      events_or_responses = expected$deaths,
      period_rows = expected$period_rows,
      psu = expected$psu,
      dfcom = expected$design_df,
      stringsAsFactors = FALSE
    )
  )
}

scalar_map <- data.frame(
  group_id = "CHARLS_ADJACENT_PRIMARY",
  column = column_names,
  analysis_id = c(
    "v46_charls_adjacent_e0_a0",
    "v46_charls_adjacent_e0_a1",
    "v46_charls_adjacent_e0_a2",
    "v46_charls_adjacent_e0b_a0",
    "v46_charls_adjacent_e0b_a1",
    "v46_charls_adjacent_e0b_a2",
    rep("v46_charls_adjacent_e0_spline_a1", 3L)
  ),
  term = c(
    "E0", "E0", "E0", "E0b", "E0b", "E0b",
    "E0_linear", "E0_nonlinear1", "E0_nonlinear2"
  ),
  MCE_trigger = TRUE,
  stringsAsFactors = FALSE
)
joint_definitions <- list(
  list(
    group_id = "CHARLS_ADJACENT_PRIMARY",
    test_id = "v46_charls_adjacent_e0_spline_overall",
    columns = c("E0_linear", "E0_nonlinear1", "E0_nonlinear2")
  ),
  list(
    group_id = "CHARLS_ADJACENT_PRIMARY",
    test_id = "v46_charls_adjacent_e0_spline_nonlinear",
    columns = c("E0_nonlinear1", "E0_nonlinear2")
  )
)

run_module <- function(module) {
  row <- match(module, state$module)
  if (state$status[[row]] == "RESTRICTED_COMPLETE") {
    append_log(paste0(module, " already complete; verified and skipped."))
    return(invisible(read_module(module)))
  }
  if (state$status[[row]] != "NOT_RUN") {
    stop(module, " cannot start from its current state.", call. = FALSE)
  }
  prefix <- NULL
  if (module == "full") {
    prefix <- read_module("prefix")
    if (!identical(prefix$replicate_indices, seq_len(250L)) ||
        !prefix$prefix_gate %in% c("GO", "CAUTION")) {
      stop("Prefix did not authorize full execution.", call. = FALSE)
    }
  }
  state$status[[row]] <<- "RUNNING"
  write_state()
  append_log(paste0(module, " restricted transaction started."))
  indices <- if (module == "prefix") seq_len(250L) else 251:500
  results <- v45c_parallel_map(
    seq_len(expected$m),
    function(i) one_imputation(
      i, indices, if (is.null(prefix)) NULL else prefix$results[[i]]
    ),
    workers,
    paste0("V46 CHARLS ", module, " literal replicate columns"),
    append_log
  )
  gate <- v45c_module_gate(results)
  object <- list(
    module = module,
    mi_object = "MI-C0",
    requested_m = expected$m,
    replicate_indices = if (module == "prefix") seq_len(250L) else
      seq_len(500L),
    executed_in_this_transaction = indices,
    prefix_sha256 = if (module == "full")
      state$output_sha256[state$module == "prefix"] else NA_character_,
    literal_prefix_identity = if (module == "full") {
      all(vapply(seq_len(expected$m), function(i) {
        identical(
          prefix$results[[i]]$groups$CHARLS_ADJACENT_PRIMARY$replicates,
          results[[i]]$groups$CHARLS_ADJACENT_PRIMARY$replicates[
            seq_len(250L), , drop = FALSE
          ]
        )
      }, logical(1)))
    } else NA,
    results = results,
    sample_anchors = do.call(rbind, lapply(results, `[[`, "sample_anchors")),
    point_identity_maximum_absolute_difference = max(vapply(
      results, `[[`, numeric(1), "point_identity_absolute_difference"
    )),
    minimum_valid_replicate_fraction = gate$minimum_valid_fraction,
    prefix_gate = if (module == "prefix") gate$gate else NA_character_,
    full_gate = if (module == "full") gate$gate else NA_character_,
    coefficient_blind_prefix_gate = module == "prefix",
    prefix_pooling_or_release_performed = FALSE,
    no_replacement_replicates = TRUE,
    variance_rule = "1/(B_valid-1)",
    common_failure_masks_preserved = TRUE
  )
  if (module == "full" && !isTRUE(object$literal_prefix_identity)) {
    stop("Full object failed literal prefix identity.", call. = FALSE)
  }
  if (module == "full" && gate$gate != "STOP") {
    pooled <- v45c_pool_full_module(
      results, scalar_map, joint_definitions
    )
    object$pooling_status <- "COMPLETE"
    object$per_imputation <- pooled$per_imputation
    object$pooled_scalar <- pooled$pooled_scalar
    object$joint_results <- pooled$joint_results
    object$m100_trigger_metadata <- pooled$m100_trigger_metadata
  } else if (module == "full") {
    object$pooling_status <- "NOT_PERFORMED_FULL_GATE_STOP"
  } else {
    object$pooling_status <- "NOT_APPLICABLE_PREFIX"
  }
  publish_module(module, object)
  if (gate$gate == "STOP") {
    stop(module, " valid-replicate fraction gate is STOP.", call. = FALSE)
  }
  if (module == "full" && object$pooling_status != "COMPLETE") {
    stop("Full CHARLS pooling did not complete.", call. = FALSE)
  }
  invisible(object)
}

requested <- if (module_requested == "all") c("prefix", "full") else
  module_requested
append_log(paste0("Requested module: ", module_requested))
for (module in requested) run_module(module)
append_log("Requested V46 CHARLS restricted execution completed.")
cat("V46_CHARLS_RESTRICTED_EXECUTION_COMPLETE\n")
cat("run_id=", run_id, "\n", sep = "")
cat("coefficient_visibility=RESTRICTED\n")
cat("independent_validation_status=NOT_RUN\n")
