#!/usr/bin/env Rscript

# Aggregate-only CHARLS baseline characteristics for the V46.0 adjacent-
# transition primary population. Reuses the frozen V44.2 descriptive rules.

options(stringsAsFactors = FALSE, warn = 1)

v460_root <- function() {
  args <- commandArgs(trailingOnly = FALSE)
  file_arg <- grep("^--file=", args, value = TRUE)
  if (!length(file_arg)) return(normalizePath(getwd(), mustWork = TRUE))
  script <- sub("^--file=", "", file_arg[[1L]])
  normalizePath(file.path(dirname(script), "..", ".."), mustWork = TRUE)
}

root <- v460_root()
source(file.path(
  root, "R", "v45", "charls_addendum_v45_1",
  "charls_structural_utilities_v45_1.R"
))
v45_charls_activate_project_library(root)
required <- c("digest", "survey", "yaml")
missing <- required[!vapply(
  required, requireNamespace, logical(1), quietly = TRUE
)]
if (length(missing)) {
  stop("Baseline runtime lacks: ", paste(missing, collapse = ", "),
       call. = FALSE)
}
sys.source(
  file.path(root, "R", "v44", "06_baseline_characteristics_v44_2.R"),
  envir = .GlobalEnv
)
options(
  survey.lonely.psu = "adjust",
  survey.adjust.domain.lonely = TRUE
)

expected <- list(
  n = 12427L, deaths = 1539L, period_rows = 44778L,
  psu = 432L, design_df = 431L,
  ledger =
    "500e923e8793d1925823c73ff1039591dd9a23f84d57a31a80a33f4f49e0ea0b",
  actual =
    "2e80186cacd93d8f9c29aac1dc02168d545e4f43a4cded86542565bb7a01937c"
)
paths <- list(
  spec = file.path(root, "work_v44", "baseline_characteristics_spec_v44_2.yml"),
  ledger = file.path(
    root, "derived_sensitive", "v43", "charls_stage3_analysis_ledger_v43.rds"
  ),
  actual = file.path(
    root, "derived_sensitive", "v45", "charls_addendum_v45_1",
    "charls_actual_keys_mi_contract_v45_1.rds"
  ),
  v44_script = file.path(root, "R", "v44", "06_baseline_characteristics_v44_2.R"),
  script = file.path(
    root, "R", "v46", "05_build_charls_adjacent_baseline_v46.R"
  )
)
if (!identical(sha256_file(paths$ledger), expected$ledger) ||
    !identical(sha256_file(paths$actual), expected$actual)) {
  stop("A frozen CHARLS descriptive input drifted.", call. = FALSE)
}

spec <- yaml::read_yaml(paths$spec)
spec$frozen_population_anchors$CHARLS$sample_n <- expected$n
spec$frozen_population_anchors$CHARLS$deaths <- expected$deaths
data <- prepare_charls(root, spec)
ledger <- readRDS(paths$ledger)
actual <- readRDS(paths$actual)
skeleton <- as.data.frame(
  ledger$person_period_skeleton, stringsAsFactors = FALSE
)
key_map <- as.data.frame(
  actual$outcome_free_period_key_map, stringsAsFactors = FALSE
)
key <- paste(
  skeleton$participant_id, skeleton$start_wave, skeleton$end_wave,
  sep = "\u241f"
)
frozen_key <- paste(
  key_map$participant_id, key_map$start_wave, key_map$end_wave,
  sep = "\u241f"
)
if (!identical(key, frozen_key) || anyDuplicated(key) ||
    !"adjacent_transition" %in% names(key_map)) {
  stop("The CHARLS adjacent period-key authority drifted.", call. = FALSE)
}
adjacent <- key_map$adjacent_transition %in% TRUE
adjacent_skeleton <- skeleton[adjacent, , drop = FALSE]
adjacent_ids <- unique(as.character(adjacent_skeleton$participant_id))
event_by_id <- tapply(
  as.integer(adjacent_skeleton$period_event),
  as.character(adjacent_skeleton$participant_id), max
)
domain_index <- as.character(data$participant_key) %in% adjacent_ids
event_index <- match(as.character(data$participant_key), names(event_by_id))
data$analysis_domain <- domain_index
data$event_anchor[domain_index] <- as.integer(event_by_id[event_index[domain_index]])
if (sum(domain_index) != expected$n ||
    sum(data$event_anchor[domain_index]) != expected$deaths ||
    nrow(adjacent_skeleton) != expected$period_rows ||
    length(unique(data$community_id[domain_index])) != expected$psu) {
  stop("The CHARLS adjacent descriptive anchors failed.", call. = FALSE)
}

design <- make_design(data, "CHARLS")
summary <- summarize_cohort(
  "CHARLS", data, spec$variables$CHARLS, design, spec
)
long <- summary$long
missingness <- summary$missingness
design_audit <- summary$design_audit
main <- long[long$display_role == "main", , drop = FALSE]

checks <- data.frame(
  check = c(
    "participant_anchor", "death_anchor", "period_row_anchor",
    "community_psu_anchor", "design_df_anchor", "all_output_finite_or_suppressed",
    "no_participant_level_output"
  ),
  status = c(
    sum(domain_index) == expected$n,
    sum(data$event_anchor[domain_index]) == expected$deaths,
    nrow(adjacent_skeleton) == expected$period_rows,
    length(unique(data$community_id[domain_index])) == expected$psu,
    design_audit$design_df[[1L]] == expected$design_df,
    all(is.finite(main$estimate) | main$display_value == "Suppressed"),
    TRUE
  ),
  observed = c(
    sum(domain_index), sum(data$event_anchor[domain_index]),
    nrow(adjacent_skeleton),
    length(unique(data$community_id[domain_index])),
    design_audit$design_df[[1L]], nrow(main), "aggregate tables only"
  ),
  expected = c(
    expected$n, expected$deaths, expected$period_rows, expected$psu,
    expected$design_df, nrow(main), "aggregate tables only"
  ),
  stringsAsFactors = FALSE
)
checks$status <- ifelse(checks$status, "PASS", "FAIL")
if (any(checks$status != "PASS")) {
  stop("CHARLS adjacent baseline validation failed.", call. = FALSE)
}

out_dir <- file.path(root, "results", "v46", "charls_adjacent_primary")
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)
long_path <- file.path(out_dir, "v46_charls_adjacent_baseline_long.csv")
main_path <- file.path(out_dir, "v46_charls_adjacent_table1_source.csv")
missing_path <- file.path(out_dir, "v46_charls_adjacent_missingness.csv")
audit_path <- file.path(out_dir, "v46_charls_adjacent_baseline_design_audit.csv")
checks_path <- file.path(out_dir, "v46_charls_adjacent_baseline_checks.csv")
utils::write.csv(long, long_path, row.names = FALSE, na = "")
utils::write.csv(main, main_path, row.names = FALSE, na = "")
utils::write.csv(missingness, missing_path, row.names = FALSE, na = "")
utils::write.csv(design_audit, audit_path, row.names = FALSE, na = "")
utils::write.csv(checks, checks_path, row.names = FALSE, na = "")
manifest <- data.frame(
  artifact = c(
    "baseline_long", "table1_source", "missingness", "design_audit",
    "validation_checks", "v44_descriptive_authority", "execution_script"
  ),
  path_alias = c(
    substring(long_path, nchar(root) + 2L),
    substring(main_path, nchar(root) + 2L),
    substring(missing_path, nchar(root) + 2L),
    substring(audit_path, nchar(root) + 2L),
    substring(checks_path, nchar(root) + 2L),
    substring(paths$v44_script, nchar(root) + 2L),
    substring(paths$script, nchar(root) + 2L)
  ),
  sha256 = vapply(c(
    long_path, main_path, missing_path, audit_path, checks_path,
    paths$v44_script, paths$script
  ), sha256_file, character(1)),
  stringsAsFactors = FALSE
)
utils::write.csv(
  manifest,
  file.path(out_dir, "v46_charls_adjacent_baseline_manifest.csv"),
  row.names = FALSE, na = ""
)
cat("V46_CHARLS_ADJACENT_BASELINE_PASS\n")
cat("participant_level_output=no\n")
