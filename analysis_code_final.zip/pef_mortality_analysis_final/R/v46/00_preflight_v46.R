#!/usr/bin/env Rscript

# Outcome-coefficient-blind structural preflight for V46.0.
# This script may inspect outcomes only to verify frozen sample/event anchors.
# It builds model frames and matrices but does not fit any outcome model.

options(stringsAsFactors = FALSE, warn = 1)

v460_root <- function() {
  args <- commandArgs(trailingOnly = FALSE)
  file_arg <- grep("^--file=", args, value = TRUE)
  if (!length(file_arg)) return(normalizePath(getwd(), mustWork = TRUE))
  script <- sub("^--file=", "", file_arg[[1L]])
  normalizePath(file.path(dirname(script), "..", ".."), mustWork = TRUE)
}

root <- v460_root()
Sys.setenv(V45_CHARLS_OUTCOME_LIBRARY_ONLY = "yes")
sys.source(
  file.path(
    root, "R", "v45", "charls_addendum_v45_1",
    "12_run_charls_outcome_execution_v45_1.R"
  ),
  envir = .GlobalEnv
)
source(file.path(root, "R", "v45", "01_nhanes_common_utilities_v45.R"))
source(file.path(root, "R", "v45", "02_gli_functions_v45.R"))
source(file.path(root, "R", "v45", "11_nhanes_outcome_utilities_v45.R"))
v45c_validate_runtime(root)
v45_require_packages(root)
options(
  survey.lonely.psu = "adjust",
  survey.adjust.domain.lonely = TRUE,
  survey.replicates.mse = TRUE,
  survey.multicore = FALSE
)

expected <- list(
  protocol =
    "c87545ae0ea129bb9e9894dd02f3890d9ff74e2d83eb75b4ae1010c829a6dd6d",
  freeze_record =
    "6ba4a49b3cc42974366ad4b1c554aaf3c1dfe619eff68616b244d4b71335a47d",
  charls_mic0 =
    "8d7d0b16cf6028ac6ba1c7566d5957c650398c612138fdf1c2aae96424fb2f9e",
  charls_ledger =
    "500e923e8793d1925823c73ff1039591dd9a23f84d57a31a80a33f4f49e0ea0b",
  charls_actual =
    "2e80186cacd93d8f9c29aac1dc02168d545e4f43a4cded86542565bb7a01937c",
  charls_v43 =
    "bc759aab44691deb5a920a4017c7b51bfe7c5694959b27ae9aa95462fba5908d",
  charls_runner =
    "070b5bb27e1877832dc0f6ea7adc2589be055952311e81e50946e5e125834f81",
  charls_adjacent_anchor =
    "83a50c89d5cb2023eae6c39a5b0084b7cda45713d6100eab034dcc9612a69477",
  nhanes_mig =
    "41bcc3e5fbfd8f19501682e93354856ffc06adf6e426937327e07138d17733d3",
  nhanes_rw =
    "2d795d61aabcce42603b1cfa7b254239a716980821ad1865347a8a8327c9f152",
  nhanes_common =
    "5dd8519d0236c57b2cda97393d2543494afbec286d8433ab7b75ae5ebe32e8b4",
  nhanes_gli =
    "ff5d1526dc504858895fd40d9ea44be7894830745ed61071e739b039c52cdf66",
  nhanes_outcome =
    "24339325545eed72643a7cd2329796dafa2a4930c183104426eacad04de48dc8",
  nhanes_abc_anchor =
    "63804066d87a6af0e1a9b61d57d5a318ca4c0d13417f6fee4bfea601272e2daf",
  m = 50L,
  replicates = 500L,
  charls_n = 12427L,
  charls_deaths = 1539L,
  charls_rows = 44778L,
  charls_psu = 432L,
  charls_df = 431L,
  nhanes_n = 5925L,
  nhanes_deaths = 758L,
  nhanes_strata = 45L,
  nhanes_psu = 94L,
  nhanes_df = 49L
)

paths <- list(
  protocol = file.path(
    root, "protocol", "pef_mortality_analysis_plan_v46_0_revision.md"
  ),
  freeze_record = file.path(
    root, "work_v46", "V46_0_ANALYSIS_FREEZE_2026-08-01.md"
  ),
  preflight_script = file.path(root, "R", "v46", "00_preflight_v46.R"),
  charls_mic0_pointer = file.path(
    root, "results", "v45", "charls_addendum_v45_1", "production_mi",
    "MI_C0_m50_validated.tsv"
  ),
  charls_ledger = file.path(
    root, "derived_sensitive", "v43", "charls_stage3_analysis_ledger_v43.rds"
  ),
  charls_actual = file.path(
    root, "derived_sensitive", "v45", "charls_addendum_v45_1",
    "charls_actual_keys_mi_contract_v45_1.rds"
  ),
  charls_v43 = file.path(root, "R", "v43", "04_charls_stage3_primary_mortality.R"),
  charls_runner = file.path(
    root, "R", "v45", "charls_addendum_v45_1",
    "12_run_charls_outcome_execution_v45_1.R"
  ),
  charls_adjacent_anchor = file.path(
    root, "derived_sensitive", "v45", "charls_addendum_v45_1",
    "outcome_execution", "m50",
    "charls_v45_1_outcome_m50_20260726T173101_pid11793",
    "adjacent_full_restricted.rds"
  ),
  nhanes_mig_pointer = file.path(
    root, "results", "v45", "production_mi", "MI_G_m50_current.tsv"
  ),
  nhanes_rw = file.path(
    root, "derived_sensitive", "v45", "v45_rao_wu_replicate_contract.rds"
  ),
  nhanes_common = file.path(root, "R", "v45", "01_nhanes_common_utilities_v45.R"),
  nhanes_gli = file.path(root, "R", "v45", "02_gli_functions_v45.R"),
  nhanes_outcome = file.path(root, "R", "v45", "11_nhanes_outcome_utilities_v45.R"),
  nhanes_abc_anchor = file.path(
    root, "derived_sensitive", "v45", "outcome_execution", "m50",
    "v45_nhanes_outcome_m50_20260725T150659_pid55259",
    "paired_full_restricted.rds"
  )
)

read_tsv <- function(path) {
  utils::read.delim(
    path, stringsAsFactors = FALSE, check.names = FALSE,
    na.strings = c("", "NA")
  )
}

checks <- list()
add_check <- function(check, pass, observed, expected_value) {
  checks[[length(checks) + 1L]] <<- data.frame(
    check = check,
    status = if (isTRUE(pass)) "PASS" else "FAIL",
    observed = as.character(observed),
    expected = as.character(expected_value),
    stringsAsFactors = FALSE
  )
}

hash_expectations <- c(
  protocol = expected$protocol,
  freeze_record = expected$freeze_record,
  charls_ledger = expected$charls_ledger,
  charls_actual = expected$charls_actual,
  charls_v43 = expected$charls_v43,
  charls_runner = expected$charls_runner,
  charls_adjacent_anchor = expected$charls_adjacent_anchor,
  nhanes_rw = expected$nhanes_rw,
  nhanes_common = expected$nhanes_common,
  nhanes_gli = expected$nhanes_gli,
  nhanes_outcome = expected$nhanes_outcome,
  nhanes_abc_anchor = expected$nhanes_abc_anchor
)
for (name in names(hash_expectations)) {
  observed <- v45c_sha256_file(paths[[name]])
  add_check(
    paste0(name, "_hash"),
    identical(observed, hash_expectations[[name]]),
    observed, hash_expectations[[name]]
  )
}

mic0_pointer <- read_tsv(paths$charls_mic0_pointer)
mic0_pointer_ok <- nrow(mic0_pointer) == 1L &&
  identical(mic0_pointer$object_id[[1L]], "MI-C0") &&
  mic0_pointer$requested_m[[1L]] == expected$m &&
  identical(
    mic0_pointer$status[[1L]], "INDEPENDENT_VALIDATION_PASS"
  ) &&
  identical(mic0_pointer$mids_sha256[[1L]], expected$charls_mic0)
add_check(
  "charls_mic0_pointer", mic0_pointer_ok,
  paste(
    mic0_pointer$object_id[[1L]], mic0_pointer$requested_m[[1L]],
    mic0_pointer$status[[1L]], mic0_pointer$mids_sha256[[1L]], sep = "|"
  ),
  paste("MI-C0", expected$m, "INDEPENDENT_VALIDATION_PASS",
        expected$charls_mic0, sep = "|")
)
mic0_path <- file.path(root, mic0_pointer$mids_path_alias[[1L]])
add_check(
  "charls_mic0_object_hash",
  identical(v45c_sha256_file(mic0_path), expected$charls_mic0),
  v45c_sha256_file(mic0_path), expected$charls_mic0
)

mig_pointer <- read_tsv(paths$nhanes_mig_pointer)
mig_pointer_ok <- nrow(mig_pointer) == 1L &&
  identical(mig_pointer$object_id[[1L]], "MI-G") &&
  mig_pointer$requested_m[[1L]] == expected$m &&
  identical(mig_pointer$status[[1L]], "INDEPENDENT_VALIDATION_PASS") &&
  identical(mig_pointer$mids_sha256[[1L]], expected$nhanes_mig)
add_check(
  "nhanes_mig_pointer", mig_pointer_ok,
  paste(
    mig_pointer$object_id[[1L]], mig_pointer$requested_m[[1L]],
    mig_pointer$status[[1L]], mig_pointer$mids_sha256[[1L]], sep = "|"
  ),
  paste("MI-G", expected$m, "INDEPENDENT_VALIDATION_PASS",
        expected$nhanes_mig, sep = "|")
)
mig_path <- file.path(root, mig_pointer$mids_path_alias[[1L]])
add_check(
  "nhanes_mig_object_hash",
  identical(v45c_sha256_file(mig_path), expected$nhanes_mig),
  v45c_sha256_file(mig_path), expected$nhanes_mig
)

charls_anchor <- readRDS(paths$charls_adjacent_anchor)
charls_anchor_ok <-
  identical(charls_anchor$schema_version,
            "v45_1_charls_adjacent_full_restricted") &&
  length(charls_anchor$results) == expected$m &&
  all(vapply(seq_len(expected$m), function(i) {
    result <- charls_anchor$results[[i]]
    group <- result$groups$ADJACENT_PAIRED
    identical(result$imputation, as.integer(i)) &&
      identical(names(group$point),
                c("adjacent_all", "adjacent_only", "adjacent_delta")) &&
      identical(dim(group$replicates), c(expected$replicates, 3L)) &&
      identical(colnames(group$replicates), names(group$point)) &&
      all(is.finite(group$point)) && all(is.finite(group$replicates))
  }, logical(1)))
add_check(
  "charls_existing_adjacent_anchor_structure",
  charls_anchor_ok,
  if (charls_anchor_ok) "50 imputations x 500 replicates" else "invalid",
  "50 imputations x 500 replicates"
)

nhanes_anchor <- readRDS(paths$nhanes_abc_anchor)
nhanes_anchor_ok <-
  identical(nhanes_anchor$schema_version,
            "v45_0_stage4_paired_full_restricted") &&
  length(nhanes_anchor$results) == expected$m &&
  all(vapply(seq_len(expected$m), function(i) {
    result <- nhanes_anchor$results[[i]]
    identical(result$imputation, as.integer(i)) &&
      identical(names(result$point),
                c("G1_E0", "G6a_E0", "G6a_minus_G1")) &&
      identical(dim(result$replicates), c(expected$replicates, 3L)) &&
      identical(colnames(result$replicates), names(result$point)) &&
      all(is.finite(result$point)) && all(is.finite(result$replicates))
  }, logical(1)))
add_check(
  "nhanes_existing_abc_anchor_structure",
  nhanes_anchor_ok,
  if (nhanes_anchor_ok) "50 imputations x 500 replicates" else "invalid",
  "50 imputations x 500 replicates"
)

# CHARLS outcome-blind matrix preflight.
mic0 <- readRDS(mic0_path)
if (!inherits(mic0, "mids") || mic0$m != expected$m) {
  stop("Frozen MI-C0 is not an m=50 mids object.", call. = FALSE)
}
charls_context <- v45c_load_context(
  root, list(actual_design_contract_sha256 = expected$charls_actual)
)
charls_formulas <- c(
  setNames(charls_context$v43$model_formulas("E0", FALSE),
           paste0("E0_", c("A0", "A1", "A2"))),
  setNames(charls_context$v43$model_formulas("E0b", FALSE),
           paste0("E0b_", c("A0", "A1", "A2"))),
  list(E0_spline_A1 =
         charls_context$v43$model_formulas("E0", TRUE)$A1)
)
charls_rows <- list()
charls_reference_ids <- NULL
for (i in seq_len(expected$m)) {
  completed <- mice::complete(mic0, action = i)
  person <- v45c_prepare_person(
    completed, charls_context$ledger, charls_context$actual,
    charls_context$v43, "MI-C0"
  )
  period <- v45c_build_period(
    person, charls_context$ledger, charls_context$actual,
    rep(TRUE, nrow(person)), adjacent = TRUE
  )
  v45c_assert_anchor(
    period, expected$charls_n, expected$charls_deaths,
    expected$charls_rows, expected$charls_psu,
    paste0("V46 CHARLS adjacent imputation ", i)
  )
  ids <- unique(as.character(period$participant_id))
  if (is.null(charls_reference_ids)) charls_reference_ids <- ids
  membership_ok <- identical(ids, charls_reference_ids)
  for (model_id in names(charls_formulas)) {
    formula <- charls_formulas[[model_id]]
    frame <- stats::model.frame(
      formula, data = period, na.action = stats::na.fail
    )
    matrix <- stats::model.matrix(
      stats::delete.response(stats::terms(formula)), data = frame
    )
    rank <- qr(matrix)$rank
    row_ok <- nrow(frame) == expected$charls_rows &&
      membership_ok && all(is.finite(matrix)) && rank == ncol(matrix)
    charls_rows[[length(charls_rows) + 1L]] <- data.frame(
      imputation = i,
      model_id = model_id,
      n = length(ids),
      deaths = sum(as.integer(period$period_event) == 1L),
      period_rows = nrow(period),
      psu = length(unique(as.character(period$community_id))),
      design_df = expected$charls_df,
      matrix_columns = ncol(matrix),
      matrix_rank = rank,
      finite_matrix = all(is.finite(matrix)),
      identical_membership = membership_ok,
      status = if (row_ok) "PASS" else "FAIL",
      stringsAsFactors = FALSE
    )
  }
  rm(completed, person, period)
  if (i %% 10L == 0L) {
    message("CHARLS structural preflight ", i, "/50 complete.")
    invisible(gc(verbose = FALSE))
  }
}
charls_diagnostics <- dplyr::bind_rows(charls_rows)
add_check(
  "charls_all_50_memberships_identical",
  all(charls_diagnostics$identical_membership),
  sum(charls_diagnostics$identical_membership), nrow(charls_diagnostics)
)
add_check(
  "charls_all_matrices_full_rank_finite",
  all(charls_diagnostics$status == "PASS"),
  paste(sum(charls_diagnostics$status == "PASS"),
        nrow(charls_diagnostics), sep = "/"),
  paste(nrow(charls_diagnostics), nrow(charls_diagnostics), sep = "/")
)

# NHANES outcome-blind strict A/B quality-domain matrix preflight.
mig <- readRDS(mig_path)
if (!inherits(mig, "mids") || mig$m != expected$m) {
  stop("Frozen MI-G is not an m=50 mids object.", call. = FALSE)
}
nhanes_ledger <- v45_read_nhanes_ledger(root)
nhanes_v43 <- v45_load_v43_nhanes_functions(root)
nhanes_rw <- readRDS(paths$nhanes_rw)
nhanes_design_data <- v45_outcome_design_data(nhanes_ledger, nhanes_rw)
nhanes_formulas <- list(
  AB_A1_separate = v45_outcome_formula("E0", "A1"),
  AB_A1_conditional = v45_outcome_formula(
    c("E0", "L_FEV1", "L_RATIO"), "A1"
  )
)
quality_map <- nhanes_ledger$person_master[c("SEQN", "spirometry_ab")]
if (anyDuplicated(quality_map$SEQN) || anyNA(quality_map$SEQN) ||
    anyNA(quality_map$spirometry_ab)) {
  stop("NHANES strict-quality map is invalid.", call. = FALSE)
}
nhanes_rows <- list()
nhanes_reference_ids <- NULL
for (i in seq_len(expected$m)) {
  completed <- v45_prepare_mig_completed(
    mice::complete(mig, action = i), nhanes_ledger, nhanes_v43
  )
  merged <- v45_merge_completed_design(nhanes_design_data, completed)
  quality_index <- match(merged$SEQN, quality_map$SEQN)
  if (anyNA(quality_index)) {
    stop("NHANES quality-map join failed.", call. = FALSE)
  }
  merged$spirometry_ab <- as.logical(
    quality_map$spirometry_ab[quality_index]
  )
  domain_index <- as.logical(merged$analysis_domain) & merged$spirometry_ab
  domain <- merged[domain_index, , drop = FALSE]
  ids <- as.integer(domain$SEQN)
  if (is.null(nhanes_reference_ids)) nhanes_reference_ids <- ids
  membership_ok <- identical(ids, nhanes_reference_ids)
  design <- v45_make_taylor_design(merged)
  design_df <- as.integer(survey::degf(design[domain_index, ]))
  anchor_ok <- nrow(domain) == expected$nhanes_n &&
    sum(as.integer(domain$death) == 1L) == expected$nhanes_deaths &&
    length(unique(domain$design_strata)) == expected$nhanes_strata &&
    length(unique(domain$design_psu)) == expected$nhanes_psu &&
    design_df == expected$nhanes_df
  for (model_id in names(nhanes_formulas)) {
    formula <- nhanes_formulas[[model_id]]
    frame <- stats::model.frame(
      formula, data = domain, na.action = stats::na.fail
    )
    matrix <- stats::model.matrix(
      stats::delete.response(stats::terms(formula)), data = frame
    )
    rank <- qr(matrix)$rank
    row_ok <- anchor_ok && membership_ok &&
      nrow(frame) == expected$nhanes_n &&
      all(is.finite(matrix)) && rank == ncol(matrix)
    nhanes_rows[[length(nhanes_rows) + 1L]] <- data.frame(
      imputation = i,
      model_id = model_id,
      n = nrow(domain),
      deaths = sum(as.integer(domain$death) == 1L),
      design_strata = length(unique(domain$design_strata)),
      design_psu = length(unique(domain$design_psu)),
      design_df = design_df,
      matrix_columns = ncol(matrix),
      matrix_rank = rank,
      finite_matrix = all(is.finite(matrix)),
      identical_membership = membership_ok,
      status = if (row_ok) "PASS" else "FAIL",
      stringsAsFactors = FALSE
    )
  }
  rm(completed, merged, domain, design)
  if (i %% 10L == 0L) {
    message("NHANES structural preflight ", i, "/50 complete.")
    invisible(gc(verbose = FALSE))
  }
}
nhanes_diagnostics <- dplyr::bind_rows(nhanes_rows)
add_check(
  "nhanes_all_50_memberships_identical",
  all(nhanes_diagnostics$identical_membership),
  sum(nhanes_diagnostics$identical_membership), nrow(nhanes_diagnostics)
)
add_check(
  "nhanes_all_matrices_full_rank_finite",
  all(nhanes_diagnostics$status == "PASS"),
  paste(sum(nhanes_diagnostics$status == "PASS"),
        nrow(nhanes_diagnostics), sep = "/"),
  paste(nrow(nhanes_diagnostics), nrow(nhanes_diagnostics), sep = "/")
)

out_dir <- file.path(root, "results", "v46", "structural_preflight")
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)
checks_table <- dplyr::bind_rows(checks)
manifest_paths <- c(
  paths,
  list(charls_mic0 = mic0_path, nhanes_mig = mig_path)
)
manifest <- data.frame(
  input_id = names(manifest_paths),
  path_alias = vapply(manifest_paths, function(path) {
    substring(normalizePath(path, mustWork = TRUE), nchar(root) + 2L)
  }, character(1)),
  sha256 = vapply(manifest_paths, v45c_sha256_file, character(1)),
  stringsAsFactors = FALSE
)
v45c_atomic_write_tsv(
  charls_diagnostics,
  file.path(out_dir, "v46_0_charls_matrix_diagnostics.tsv")
)
v45c_atomic_write_tsv(
  nhanes_diagnostics,
  file.path(out_dir, "v46_0_nhanes_matrix_diagnostics.tsv")
)
v45c_atomic_write_tsv(
  checks_table, file.path(out_dir, "v46_0_structural_checks.tsv")
)
v45c_atomic_write_tsv(
  manifest, file.path(out_dir, "v46_0_input_manifest.tsv")
)

all_pass <- nrow(checks_table) > 0L && all(checks_table$status == "PASS") &&
  all(charls_diagnostics$status == "PASS") &&
  all(nhanes_diagnostics$status == "PASS")
status <- data.frame(
  preflight_id = paste0(
    "v46_0_structural_", format(Sys.time(), "%Y%m%dT%H%M%S"),
    "_pid", Sys.getpid()
  ),
  status = if (all_pass) "STRUCTURAL_PREFLIGHT_PASS" else
    "STRUCTURAL_PREFLIGHT_FAIL",
  coefficient_model_fitted = "no",
  coefficient_or_direction_released = "no",
  participant_level_output_written = "no",
  charls_models_checked = length(charls_formulas),
  nhanes_models_checked = length(nhanes_formulas),
  imputations = expected$m,
  completed_at_utc = format(Sys.time(), "%Y-%m-%dT%H:%M:%SZ", tz = "UTC"),
  stringsAsFactors = FALSE
)
v45c_atomic_write_tsv(
  status, file.path(out_dir, "v46_0_preflight_status.tsv")
)

if (!all_pass) {
  stop("V46.0 structural preflight failed; outcome execution is blocked.",
       call. = FALSE)
}
cat("V46_0_STRUCTURAL_PREFLIGHT_PASS\n")
cat("coefficient_model_fitted=no\n")
cat("coefficient_or_direction_released=no\n")
