#!/usr/bin/env Rscript

# Independent aggregate validator and release gate for the V46.0 CHARLS
# adjacent-transition primary analysis. Participant-level completed data and
# fitted model objects are neither read from nor written by this script.

options(stringsAsFactors = FALSE, warn = 1)

v460_root <- function() {
  args <- commandArgs(trailingOnly = FALSE)
  file_arg <- grep("^--file=", args, value = TRUE)
  if (!length(file_arg)) return(normalizePath(getwd(), mustWork = TRUE))
  script <- sub("^--file=", "", file_arg[[1L]])
  normalizePath(file.path(dirname(script), "..", ".."), mustWork = TRUE)
}

root <- v460_root()
source(file.path(
  root, "R", "v45", "charls_addendum_v45_1",
  "charls_structural_utilities_v45_1.R"
))
v45_charls_activate_project_library(root)
required <- c("digest", "mice")
missing <- required[!vapply(
  required, requireNamespace, logical(1), quietly = TRUE
)]
if (length(missing)) {
  stop("Validator runtime lacks: ", paste(missing, collapse = ", "),
       call. = FALSE)
}

sha256_file <- function(path) {
  if (!file.exists(path) || dir.exists(path) || nzchar(Sys.readlink(path))) {
    return(NA_character_)
  }
  digest::digest(path, algo = "sha256", file = TRUE)
}
read_tsv <- function(path) {
  utils::read.delim(
    path, stringsAsFactors = FALSE, check.names = FALSE,
    na.strings = c("", "NA")
  )
}
atomic_write_tsv <- function(data, path) {
  dir.create(dirname(path), recursive = TRUE, showWarnings = FALSE)
  tmp <- tempfile(paste0(".", basename(path), "."), tmpdir = dirname(path))
  on.exit(if (file.exists(tmp)) unlink(tmp, force = TRUE), add = TRUE)
  utils::write.table(
    data, tmp, sep = "\t", row.names = FALSE, quote = FALSE, na = ""
  )
  if (!file.rename(tmp, path)) {
    stop("Atomic validator write failed.", call. = FALSE)
  }
  invisible(path)
}

expected <- list(
  protocol =
    "c87545ae0ea129bb9e9894dd02f3890d9ff74e2d83eb75b4ae1010c829a6dd6d",
  mic0 =
    "8d7d0b16cf6028ac6ba1c7566d5957c650398c612138fdf1c2aae96424fb2f9e",
  adjacent_anchor =
    "83a50c89d5cb2023eae6c39a5b0084b7cda45713d6100eab034dcc9612a69477",
  m = 50L,
  replicates = 500L,
  n = 12427L,
  deaths = 1539L,
  period_rows = 44778L,
  psu = 432L,
  design_df = 431L,
  identity_tolerance = 1e-8,
  numeric_tolerance = 1e-10,
  covariance_tolerance = 1e-10,
  valid_fraction_stop = 0.80,
  mce_fraction_max = 0.10
)

public_root <- file.path(root, "results", "v46", "charls_adjacent_primary")
current_path <- file.path(public_root, "v46_charls_restricted_current.tsv")
current <- read_tsv(current_path)
if (nrow(current) != 1L ||
    !identical(current$coefficient_visibility[[1L]], "RESTRICTED") ||
    !identical(current$independent_validation_status[[1L]], "NOT_RUN") ||
    !identical(
      sha256_file(file.path(root, current$state_path_alias[[1L]])),
      current$state_sha256[[1L]]
    )) {
  stop("The V46 CHARLS restricted-run pointer is invalid.", call. = FALSE)
}
run_id <- current$run_id[[1L]]
state_path <- file.path(root, current$state_path_alias[[1L]])
state <- read_tsv(state_path)
if (!identical(state$module, c("prefix", "full")) ||
    any(state$status != "RESTRICTED_COMPLETE")) {
  stop("Both V46 CHARLS restricted modules are required.", call. = FALSE)
}
module_paths <- file.path(root, state$output_path_alias)
module_hashes <- vapply(module_paths, sha256_file, character(1))
if (!identical(unname(module_hashes), as.character(state$output_sha256))) {
  stop("A V46 CHARLS restricted-module hash failed.", call. = FALSE)
}
objects <- setNames(lapply(module_paths, readRDS), state$module)
prefix <- objects$prefix
full <- objects$full

checks <- list()
add_check <- function(check, pass, observed, expected_value) {
  checks[[length(checks) + 1L]] <<- data.frame(
    check = check,
    status = if (isTRUE(pass)) "PASS" else "FAIL",
    observed = as.character(observed),
    expected = as.character(expected_value),
    stringsAsFactors = FALSE
  )
}

add_check(
  "restricted_module_hashes", all(!is.na(module_hashes)),
  paste(module_hashes, collapse = ";"), "two exact hashes"
)
schema_ok <- identical(
  prefix$schema_version, "v46_0_charls_adjacent_prefix_restricted"
) && identical(
  full$schema_version, "v46_0_charls_adjacent_full_restricted"
)
add_check(
  "restricted_schemas", schema_ok,
  paste(prefix$schema_version, full$schema_version, sep = ";"),
  "two V46.0 CHARLS schemas"
)
privacy_ok <- all(vapply(objects, function(x) {
  identical(x$coefficient_visibility, "RESTRICTED") &&
    identical(x$participant_level_data_saved, FALSE) &&
    identical(x$completed_dataset_saved, FALSE) &&
    identical(x$fit_objects_saved, FALSE) &&
    identical(x$individual_weights_or_predictions_saved, FALSE)
}, logical(1)))
add_check(
  "restricted_privacy_flags", privacy_ok, privacy_ok, TRUE
)

protocol_path <- file.path(
  root, "protocol", "pef_mortality_analysis_plan_v46_0_revision.md"
)
mic0_pointer <- read_tsv(file.path(
  root, "results", "v45", "charls_addendum_v45_1", "production_mi",
  "MI_C0_m50_validated.tsv"
))
mic0_path <- file.path(root, mic0_pointer$mids_path_alias[[1L]])
anchor_path <- file.path(
  root, "derived_sensitive", "v45", "charls_addendum_v45_1",
  "outcome_execution", "m50",
  "charls_v45_1_outcome_m50_20260726T173101_pid11793",
  "adjacent_full_restricted.rds"
)
runner_path <- file.path(
  root, "R", "v46", "01_run_charls_adjacent_primary_v46.R"
)
current_input_hashes <- list(
  protocol = sha256_file(protocol_path),
  preflight_status = sha256_file(file.path(
    root, "results", "v46", "structural_preflight",
    "v46_0_preflight_status.tsv"
  )),
  preflight_checks = sha256_file(file.path(
    root, "results", "v46", "structural_preflight",
    "v46_0_structural_checks.tsv"
  )),
  preflight_manifest = sha256_file(file.path(
    root, "results", "v46", "structural_preflight",
    "v46_0_input_manifest.tsv"
  )),
  preflight_charls = sha256_file(file.path(
    root, "results", "v46", "structural_preflight",
    "v46_0_charls_matrix_diagnostics.tsv"
  )),
  mic0_m50 = sha256_file(mic0_path),
  adjacent_anchor = sha256_file(anchor_path),
  execution_script = sha256_file(runner_path)
)
inputs_current <- identical(prefix$input_hashes, full$input_hashes) &&
  identical(full$input_hashes, current_input_hashes) &&
  identical(current_input_hashes$protocol, expected$protocol) &&
  identical(current_input_hashes$mic0_m50, expected$mic0) &&
  identical(current_input_hashes$adjacent_anchor,
            expected$adjacent_anchor)
add_check(
  "frozen_input_hashes_current", inputs_current,
  if (inputs_current) "all exact" else "mismatch", "all exact"
)

column_names <- c(
  "E0_A0", "E0_A1", "E0_A2",
  "E0b_A0", "E0b_A1", "E0b_A2",
  "E0_linear", "E0_nonlinear1", "E0_nonlinear2"
)
scalar_identity <- data.frame(
  column = column_names,
  analysis_id = c(
    "v46_charls_adjacent_e0_a0",
    "v46_charls_adjacent_e0_a1",
    "v46_charls_adjacent_e0_a2",
    "v46_charls_adjacent_e0b_a0",
    "v46_charls_adjacent_e0b_a1",
    "v46_charls_adjacent_e0b_a2",
    rep("v46_charls_adjacent_e0_spline_a1", 3L)
  ),
  term = c(
    "E0", "E0", "E0", "E0b", "E0b", "E0b",
    "E0_linear", "E0_nonlinear1", "E0_nonlinear2"
  ),
  stringsAsFactors = FALSE
)
prefix_complete <- length(prefix$results) == expected$m &&
  identical(prefix$replicate_indices, seq_len(250L)) &&
  all(vapply(seq_len(expected$m), function(i) {
    result <- prefix$results[[i]]
    group <- result$groups$CHARLS_ADJACENT_PRIMARY
    identical(result$imputation, as.integer(i)) &&
      identical(names(group$point), column_names) &&
      identical(dim(group$replicates), c(250L, length(column_names))) &&
      identical(colnames(group$replicates), column_names) &&
      all(is.finite(group$point)) &&
      all(is.finite(group$replicates) | is.na(group$replicates))
  }, logical(1)))
full_complete <- length(full$results) == expected$m &&
  identical(full$replicate_indices, seq_len(expected$replicates)) &&
  all(vapply(seq_len(expected$m), function(i) {
    result <- full$results[[i]]
    group <- result$groups$CHARLS_ADJACENT_PRIMARY
    identical(result$imputation, as.integer(i)) &&
      identical(names(group$point), column_names) &&
      identical(dim(group$replicates),
                c(expected$replicates, length(column_names))) &&
      identical(colnames(group$replicates), column_names) &&
      all(is.finite(group$point)) &&
      all(is.finite(group$replicates) | is.na(group$replicates))
  }, logical(1)))
add_check(
  "prefix_result_completeness", prefix_complete,
  paste(length(prefix$results), "imputations"), "50 complete imputations"
)
add_check(
  "full_result_completeness", full_complete,
  paste(length(full$results), "imputations"), "50 complete imputations"
)

prefix_identity <- all(vapply(seq_len(expected$m), function(i) {
  p <- prefix$results[[i]]$groups$CHARLS_ADJACENT_PRIMARY
  f <- full$results[[i]]$groups$CHARLS_ADJACENT_PRIMARY
  identical(p$point, f$point) &&
    identical(p$replicates,
              f$replicates[seq_len(250L), , drop = FALSE]) &&
    identical(p$failure_class_by_replicate,
              f$failure_class_by_replicate[seq_len(250L)])
}, logical(1))) && isTRUE(full$literal_prefix_identity)
add_check(
  "literal_prefix_identity", prefix_identity,
  prefix_identity, TRUE
)

anchors <- full$sample_anchors
anchors_ok <- nrow(anchors) == expected$m &&
  identical(as.integer(anchors$imputation), seq_len(expected$m)) &&
  all(anchors$n == expected$n) &&
  all(anchors$events_or_responses == expected$deaths) &&
  all(anchors$period_rows == expected$period_rows) &&
  all(anchors$psu == expected$psu) &&
  all(anchors$dfcom == expected$design_df)
add_check(
  "sample_anchor_identity", anchors_ok,
  paste(nrow(anchors), "rows"), "50 exact adjacent-domain anchors"
)
identity_ok <- is.finite(
  full$point_identity_maximum_absolute_difference
) && full$point_identity_maximum_absolute_difference <=
  expected$identity_tolerance
add_check(
  "reused_A1_point_identity", identity_ok,
  full$point_identity_maximum_absolute_difference,
  paste0("<=", expected$identity_tolerance)
)

valid_fractions <- vapply(seq_len(expected$m), function(i) {
  full$results[[i]]$groups$CHARLS_ADJACENT_PRIMARY$
    valid_replicate_fraction
}, numeric(1))
valid_gate_ok <- all(is.finite(valid_fractions)) &&
  min(valid_fractions) >= expected$valid_fraction_stop &&
  full$full_gate %in% c("GO", "CAUTION")
add_check(
  "full_valid_replicate_gate", valid_gate_ok,
  paste0("minimum=", min(valid_fractions), ";gate=", full$full_gate),
  "minimum>=0.80 and gate GO/CAUTION"
)

independent_covariance <- function(point, replicates) {
  valid <- apply(replicates, 1L, function(value) all(is.finite(value)))
  if (sum(valid) < 2L) stop("Too few valid replicate rows.", call. = FALSE)
  centered <- sweep(
    replicates[valid, , drop = FALSE], 2L, point, FUN = "-"
  )
  covariance <- crossprod(centered) / (sum(valid) - 1L)
  dimnames(covariance) <- list(names(point), names(point))
  list(covariance = covariance, valid = valid)
}
covariance_differences <- vapply(seq_len(expected$m), function(i) {
  group <- full$results[[i]]$groups$CHARLS_ADJACENT_PRIMARY
  independent <- independent_covariance(group$point, group$replicates)
  if (!identical(independent$valid, group$common_valid_mask)) return(Inf)
  max(abs(independent$covariance - group$within_covariance))
}, numeric(1))
covariance_ok <- all(is.finite(covariance_differences)) &&
  max(covariance_differences) <= expected$covariance_tolerance
add_check(
  "independent_replicate_covariance", covariance_ok,
  paste0("maximum absolute difference=", max(covariance_differences)),
  paste0("<=", expected$covariance_tolerance)
)

independent_pool <- function(estimates, variances, dfcom) {
  pooled <- mice::pool.scalar(
    Q = as.numeric(estimates), U = as.numeric(variances),
    n = as.numeric(dfcom) + 1, k = 1, rule = "rubin1987"
  )
  critical <- stats::qt(0.975, df = pooled$df)
  se <- sqrt(pooled$t)
  statistic <- pooled$qbar / se
  p_value <- 2 * stats::pt(
    abs(statistic), df = pooled$df, lower.tail = FALSE
  )
  data.frame(
    m = as.integer(pooled$m),
    estimate = pooled$qbar,
    standard_error = se,
    ci_low = pooled$qbar - critical * se,
    ci_high = pooled$qbar + critical * se,
    p_value = p_value,
    within_variance = pooled$ubar,
    between_variance = pooled$b,
    total_variance = pooled$t,
    df = pooled$df,
    dfcom = dfcom,
    FMI = pooled$fmi,
    MCE = sqrt(pooled$b / pooled$m),
    MCE_fraction = sqrt(pooled$b / pooled$m) / se,
    stringsAsFactors = FALSE
  )
}

independent_rows <- lapply(column_names, function(column) {
  q <- vapply(seq_len(expected$m), function(i) {
    full$results[[i]]$groups$CHARLS_ADJACENT_PRIMARY$point[[column]]
  }, numeric(1))
  u <- vapply(seq_len(expected$m), function(i) {
    covariance <- full$results[[i]]$groups$CHARLS_ADJACENT_PRIMARY$
      within_covariance
    covariance[column, column]
  }, numeric(1))
  cbind(
    data.frame(column = column, stringsAsFactors = FALSE),
    independent_pool(q, u, expected$design_df)
  )
})
independent_scalar <- do.call(rbind, independent_rows)
rownames(independent_scalar) <- NULL
released_scalar <- full$pooled_scalar
identity_key <- paste(
  scalar_identity$analysis_id, scalar_identity$term, sep = "\u241f"
)
released_key <- paste(
  released_scalar$analysis_id, released_scalar$term, sep = "\u241f"
)
identity_index <- match(released_key, identity_key)
if (anyNA(identity_index) || anyDuplicated(released_key) ||
    !setequal(identity_index, seq_len(nrow(scalar_identity)))) {
  stop("Stored scalar pooling identities are incomplete or duplicated.",
       call. = FALSE)
}
released_scalar$column <- scalar_identity$column[identity_index]
scalar_differences <- lapply(column_names, function(column) {
  old <- independent_scalar[independent_scalar$column == column, , drop = FALSE]
  new <- released_scalar[released_scalar$column == column, , drop = FALSE]
  fields <- c(
    "m", "estimate", "standard_error", "ci_low", "ci_high", "p_value",
    "within_variance", "between_variance", "total_variance", "df",
    "dfcom", "FMI", "MCE", "MCE_fraction"
  )
  if (nrow(old) != 1L || nrow(new) != 1L) return(Inf)
  max(abs(
    as.numeric(unlist(old[1L, fields], use.names = FALSE)) -
      as.numeric(unlist(new[1L, fields], use.names = FALSE))
  ))
})
maximum_scalar_difference <- max(unlist(scalar_differences))
scalar_pool_ok <- is.finite(maximum_scalar_difference) &&
  maximum_scalar_difference <= expected$numeric_tolerance
add_check(
  "independent_scalar_Rubin_pooling", scalar_pool_ok,
  paste0("maximum absolute difference=", maximum_scalar_difference),
  paste0("<=", expected$numeric_tolerance)
)

independent_joint <- function(columns, test_id) {
  q <- do.call(rbind, lapply(seq_len(expected$m), function(i) {
    full$results[[i]]$groups$CHARLS_ADJACENT_PRIMARY$point[columns]
  }))
  colnames(q) <- columns
  u <- lapply(seq_len(expected$m), function(i) {
    full$results[[i]]$groups$CHARLS_ADJACENT_PRIMARY$within_covariance[
      columns, columns, drop = FALSE
    ]
  })
  qbar <- colMeans(q)
  ubar <- Reduce("+", u) / length(u)
  between <- stats::cov(q)
  total <- ubar + (1 + 1 / nrow(q)) * between
  statistic <- as.numeric(crossprod(qbar, solve(total, qbar)))
  list(
    test_id = test_id, dimension = length(columns),
    statistic = statistic,
    p_value = stats::pchisq(statistic, df = length(columns),
                            lower.tail = FALSE),
    qbar = qbar, within_covariance = ubar,
    between_covariance = between, total_covariance = total
  )
}
joint_definitions <- list(
  v46_charls_adjacent_e0_spline_overall =
    c("E0_linear", "E0_nonlinear1", "E0_nonlinear2"),
  v46_charls_adjacent_e0_spline_nonlinear =
    c("E0_nonlinear1", "E0_nonlinear2")
)
independent_joints <- lapply(names(joint_definitions), function(test_id) {
  independent_joint(joint_definitions[[test_id]], test_id)
})
names(independent_joints) <- names(joint_definitions)
joint_differences <- vapply(names(joint_definitions), function(test_id) {
  independent <- independent_joints[[test_id]]
  stored <- full$joint_results[[test_id]]
  max(c(
    abs(independent$statistic - stored$statistic),
    abs(independent$p_value - stored$p_value),
    abs(independent$qbar - stored$qbar),
    abs(independent$total_covariance - stored$total_covariance)
  ))
}, numeric(1))
joint_ok <- all(is.finite(joint_differences)) &&
  max(joint_differences) <= expected$numeric_tolerance
add_check(
  "independent_multivariate_pooling", joint_ok,
  paste0("maximum absolute difference=", max(joint_differences)),
  paste0("<=", expected$numeric_tolerance)
)

mce_ok <- all(is.finite(released_scalar$MCE_fraction)) &&
  all(released_scalar$MCE_fraction < expected$mce_fraction_max) &&
  !isTRUE(full$m100_trigger_metadata$trigger)
add_check(
  "m50_Monte_Carlo_error_gate", mce_ok,
  paste0("maximum fraction=", max(released_scalar$MCE_fraction)),
  paste0("<", expected$mce_fraction_max)
)

old_release <- read_tsv(file.path(
  root, "results", "v45", "charls_addendum_v45_1", "outcome_execution",
  "charls_outcome_released_results_v45_1.tsv"
))
old_a1 <- old_release[
  old_release$analysis_id == "v45_c_adjacent_only_a1" &
    old_release$term == "E0", , drop = FALSE
]
new_a1 <- released_scalar[
  released_scalar$column == "E0_A1", , drop = FALSE
]
anchor_difference <- if (nrow(old_a1) == 1L && nrow(new_a1) == 1L) {
  old_values <- c(
    beta = old_a1$beta[[1L]],
    standard_error = old_a1$standard_error[[1L]],
    HR = old_a1$HR[[1L]],
    CI_low = old_a1$CI_low[[1L]],
    CI_high = old_a1$CI_high[[1L]],
    P_value = old_a1$P_value[[1L]],
    Rubin_df = old_a1$Rubin_df[[1L]],
    FMI = old_a1$FMI[[1L]],
    MCE = old_a1$MCE[[1L]],
    MCE_fraction = old_a1$MCE_fraction[[1L]]
  )
  new_values <- c(
    beta = new_a1$estimate[[1L]],
    standard_error = new_a1$standard_error[[1L]],
    HR = exp(new_a1$estimate[[1L]]),
    CI_low = exp(new_a1$ci_low[[1L]]),
    CI_high = exp(new_a1$ci_high[[1L]]),
    P_value = new_a1$p_value[[1L]],
    Rubin_df = new_a1$df[[1L]],
    FMI = new_a1$FMI[[1L]],
    MCE = new_a1$MCE[[1L]],
    MCE_fraction = new_a1$MCE_fraction[[1L]]
  )
  max(abs(old_values - new_values))
} else Inf
anchor_release_ok <- is.finite(anchor_difference) &&
  anchor_difference <= expected$numeric_tolerance
add_check(
  "frozen_adjacent_A1_release_reproduction", anchor_release_ok,
  paste0("maximum absolute difference=", anchor_difference),
  paste0("<=", expected$numeric_tolerance)
)

checks_table <- do.call(rbind, checks)
rownames(checks_table) <- NULL
all_pass <- nrow(checks_table) > 0L && all(checks_table$status == "PASS")
validation_path <- file.path(
  public_root, "v46_charls_independent_validation_checks.tsv"
)
atomic_write_tsv(checks_table, validation_path)
if (!all_pass) {
  stop("V46 CHARLS independent validation failed; release blocked.",
       call. = FALSE)
}

model_metadata <- data.frame(
  column = column_names,
  analysis_id = c(
    "v46_charls_adjacent_e0_a0",
    "v46_charls_adjacent_e0_a1",
    "v46_charls_adjacent_e0_a2",
    "v46_charls_adjacent_e0b_a0",
    "v46_charls_adjacent_e0b_a1",
    "v46_charls_adjacent_e0b_a2",
    rep("v46_charls_adjacent_e0_spline_a1", 3L)
  ),
  term = c(
    "E0", "E0", "E0", "E0b", "E0b", "E0b",
    "E0_linear", "E0_nonlinear1", "E0_nonlinear2"
  ),
  adjustment = c("A0", "A1", "A2", "A0", "A1", "A2",
                 "A1", "A1", "A1"),
  exposure_definition = c(rep("primary_E0", 3L), rep("alternative_E0b", 3L),
                          rep("primary_E0_spline", 3L)),
  role = c("supporting", "primary", rep("supporting", 7L)),
  stringsAsFactors = FALSE
)
release <- merge(
  model_metadata, released_scalar,
  by = c("column", "analysis_id", "term"), sort = FALSE
)
release <- release[match(column_names, release$column), , drop = FALSE]
release$cohort <- "CHARLS"
release$sample_id <- "charls_primary_adjacent_windows"
release$n <- expected$n
release$deaths <- expected$deaths
release$period_rows <- expected$period_rows
release$psu <- expected$psu
release$complete_data_design_df <- expected$design_df
release$hazard_ratio <- ifelse(
  grepl("^E0(_|b_|$)", release$column) &
    !grepl("linear|nonlinear", release$column),
  exp(release$estimate), NA_real_
)
release$hazard_ratio_ci_low <- ifelse(
  is.finite(release$hazard_ratio), exp(release$ci_low), NA_real_
)
release$hazard_ratio_ci_high <- ifelse(
  is.finite(release$hazard_ratio), exp(release$ci_high), NA_real_
)
release$independent_validation_status <- "PASS"

joint_release <- do.call(rbind, lapply(independent_joints, function(x) {
  data.frame(
    test_id = x$test_id,
    dimension = x$dimension,
    statistic = x$statistic,
    p_value = x$p_value,
    cohort = "CHARLS",
    sample_id = "charls_primary_adjacent_windows",
    adjustment = "A1",
    n = expected$n,
    deaths = expected$deaths,
    period_rows = expected$period_rows,
    independent_validation_status = "PASS",
    stringsAsFactors = FALSE
  )
}))
overall_joint <- independent_joints[[
  "v46_charls_adjacent_e0_spline_overall"
]]
covariance_release <- as.data.frame(as.table(
  overall_joint$total_covariance
), stringsAsFactors = FALSE)
names(covariance_release) <- c("row_term", "column_term", "covariance")
covariance_release$covariance_type <- "Rubin_total"
covariance_release$independent_validation_status <- "PASS"

release_path <- file.path(
  public_root, "v46_charls_adjacent_released_results.tsv"
)
joint_path <- file.path(
  public_root, "v46_charls_adjacent_spline_joint_tests.tsv"
)
covariance_path <- file.path(
  public_root, "v46_charls_adjacent_spline_total_covariance.tsv"
)
atomic_write_tsv(release, release_path)
atomic_write_tsv(joint_release, joint_path)
atomic_write_tsv(covariance_release, covariance_path)

release_manifest <- data.frame(
  artifact = c(
    "released_results", "spline_joint_tests", "spline_total_covariance",
    "validation_checks", "prefix_restricted", "full_restricted",
    "validator_script"
  ),
  path_alias = c(
    substring(release_path, nchar(root) + 2L),
    substring(joint_path, nchar(root) + 2L),
    substring(covariance_path, nchar(root) + 2L),
    substring(validation_path, nchar(root) + 2L),
    state$output_path_alias[state$module == "prefix"],
    state$output_path_alias[state$module == "full"],
    "R/v46/02_validate_charls_adjacent_primary_v46.R"
  ),
  sha256 = c(
    sha256_file(release_path), sha256_file(joint_path),
    sha256_file(covariance_path), sha256_file(validation_path),
    state$output_sha256[state$module == "prefix"],
    state$output_sha256[state$module == "full"],
    sha256_file(file.path(
      root, "R", "v46", "02_validate_charls_adjacent_primary_v46.R"
    ))
  ),
  stringsAsFactors = FALSE
)
manifest_path <- file.path(
  public_root, "v46_charls_release_manifest.tsv"
)
atomic_write_tsv(release_manifest, manifest_path)
validated_pointer <- data.frame(
  run_id = run_id,
  release_path_alias = substring(release_path, nchar(root) + 2L),
  release_sha256 = sha256_file(release_path),
  validation_path_alias = substring(validation_path, nchar(root) + 2L),
  validation_sha256 = sha256_file(validation_path),
  release_manifest_path_alias = substring(manifest_path, nchar(root) + 2L),
  release_manifest_sha256 = sha256_file(manifest_path),
  status = "INDEPENDENT_VALIDATION_PASS",
  validated_at_utc = format(
    Sys.time(), "%Y-%m-%dT%H:%M:%SZ", tz = "UTC"
  ),
  stringsAsFactors = FALSE
)
atomic_write_tsv(
  validated_pointer,
  file.path(public_root, "v46_charls_validated_current.tsv")
)
cat("V46_CHARLS_INDEPENDENT_VALIDATION_PASS\n")
cat("run_id=", run_id, "\n", sep = "")
cat("public_aggregate_release=complete\n")
