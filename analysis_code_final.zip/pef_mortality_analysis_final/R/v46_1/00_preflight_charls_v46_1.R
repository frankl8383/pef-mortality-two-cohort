#!/usr/bin/env Rscript

# Outcome-coefficient-blind structural preflight for V46.1.

options(stringsAsFactors = FALSE, warn = 1)

v461_root <- function() {
  args <- commandArgs(trailingOnly = FALSE)
  file_arg <- grep("^--file=", args, value = TRUE)
  if (!length(file_arg)) return(normalizePath(getwd(), mustWork = TRUE))
  script <- sub("^--file=", "", file_arg[[1L]])
  normalizePath(file.path(dirname(script), "..", ".."), mustWork = TRUE)
}

root <- v461_root()
Sys.setenv(V45_CHARLS_OUTCOME_LIBRARY_ONLY = "yes")
sys.source(file.path(
  root, "R", "v45", "charls_addendum_v45_1",
  "12_run_charls_outcome_execution_v45_1.R"
), envir = .GlobalEnv)
source(file.path(root, "R", "v46_1", "charls_v46_1_utilities.R"))
v45c_validate_runtime(root)

expected <- list(
  mic0 =
    "8d7d0b16cf6028ac6ba1c7566d5957c650398c612138fdf1c2aae96424fb2f9e",
  ledger =
    "500e923e8793d1925823c73ff1039591dd9a23f84d57a31a80a33f4f49e0ea0b",
  actual =
    "2e80186cacd93d8f9c29aac1dc02168d545e4f43a4cded86542565bb7a01937c",
  v46_release =
    "9bd267d321fa02df8fbef7193f6ddc409a3b4d08d32022101bb93ec5e046482d",
  m = 50L,
  primary_n = 12427L,
  primary_deaths = 1539L,
  primary_rows = 44778L,
  primary_psu = 432L,
  all_window_n = 12555L,
  nonconsecutive_rows = 725L,
  nonconsecutive_deaths = 196L
)

paths <- list(
  protocol = file.path(
    root, "protocol", "pef_mortality_analysis_plan_v46_1_revision.md"
  ),
  utility = file.path(
    root, "R", "v46_1", "charls_v46_1_utilities.R"
  ),
  preflight = file.path(
    root, "R", "v46_1", "00_preflight_charls_v46_1.R"
  ),
  runner = file.path(
    root, "R", "v46_1", "01_run_charls_sensitivity_v46_1.R"
  ),
  validator = file.path(
    root, "R", "v46_1", "02_validate_charls_sensitivity_v46_1.R"
  ),
  ledger = file.path(
    root, "derived_sensitive", "v43", "charls_stage3_analysis_ledger_v43.rds"
  ),
  actual = file.path(
    root, "derived_sensitive", "v45", "charls_addendum_v45_1",
    "charls_actual_keys_mi_contract_v45_1.rds"
  ),
  v46_release = file.path(
    root, "results", "v46", "charls_adjacent_primary",
    "v46_charls_adjacent_released_results.tsv"
  ),
  all_window_release = file.path(
    root, "results", "v45", "charls_addendum_v45_1",
    "outcome_execution", "charls_outcome_released_results_v45_1.tsv"
  )
)

mic0_pointer <- utils::read.delim(file.path(
  root, "results", "v45", "charls_addendum_v45_1", "production_mi",
  "MI_C0_m50_validated.tsv"
), stringsAsFactors = FALSE, check.names = FALSE)
if (nrow(mic0_pointer) != 1L ||
    !identical(mic0_pointer$status[[1L]], "INDEPENDENT_VALIDATION_PASS")) {
  stop("The validated MI-C0 pointer is absent or invalid.", call. = FALSE)
}
paths$mic0 <- file.path(root, mic0_pointer$mids_path_alias[[1L]])

if (any(!vapply(paths, file.exists, logical(1)))) {
  missing <- names(paths)[!vapply(paths, file.exists, logical(1))]
  stop("V46.1 preflight input is missing: ", paste(missing, collapse = ", "),
       call. = FALSE)
}

hashes <- vapply(paths, v45c_sha256_file, character(1))
if (!identical(hashes[["mic0"]], expected$mic0) ||
    !identical(hashes[["ledger"]], expected$ledger) ||
    !identical(hashes[["actual"]], expected$actual) ||
    !identical(hashes[["v46_release"]], expected$v46_release)) {
  stop("A fixed V46.1 authority hash failed.", call. = FALSE)
}

mic0 <- readRDS(paths$mic0)
if (!inherits(mic0, "mids") || mic0$m != expected$m) {
  stop("MI-C0 is not the validated m=50 object.", call. = FALSE)
}
context <- v45c_load_context(
  root, list(actual_design_contract_sha256 = expected$actual)
)
complete_case_ids <- v461_complete_case_ids(mic0)
formula <- context$v43$model_formulas("E0", FALSE)$A1

anchors <- list()
matrix_audits <- list()
membership_hashes <- list()
complete_matrix_hashes <- character(expected$m)
for (imputation in seq_len(expected$m)) {
  completed <- mice::complete(mic0, action = imputation)
  person <- v45c_prepare_person(
    completed, context$ledger, context$actual, context$v43, "MI-C0"
  )
  domains <- v461_domain_periods(person, context, complete_case_ids)
  anchors[[imputation]] <- do.call(rbind, lapply(names(domains), function(id) {
    row <- v461_anchor_row(domains[[id]], id)
    row$imputation <- as.integer(imputation)
    row[, c("sample_id", "imputation", setdiff(names(row),
                                                  c("sample_id", "imputation")))]
  }))
  matrix_audits[[imputation]] <- do.call(rbind, lapply(
    c("complete_case", "boundary_excluded", "strict_measurement"),
    function(id) v461_matrix_audit(
      domains[[id]], formula, id, imputation
    )
  ))
  membership_hashes[[imputation]] <- data.frame(
    imputation = as.integer(imputation),
    complete_case = digest::digest(
      sort(unique(as.character(domains$complete_case$participant_id))),
      algo = "sha256"
    ),
    boundary_excluded = digest::digest(
      sort(unique(as.character(domains$boundary_excluded$participant_id))),
      algo = "sha256"
    ),
    strict_measurement = digest::digest(
      sort(unique(as.character(domains$strict_measurement$participant_id))),
      algo = "sha256"
    ),
    stringsAsFactors = FALSE
  )
  complete_frame <- stats::model.frame(
    formula, data = domains$complete_case, na.action = stats::na.fail
  )
  complete_matrix <- stats::model.matrix(
    stats::delete.response(stats::terms(formula)), data = complete_frame
  )
  complete_matrix_hashes[[imputation]] <- digest::digest(list(
    participant_id = as.character(domains$complete_case$participant_id),
    start_wave = as.integer(domains$complete_case$start_wave),
    end_wave = as.character(domains$complete_case$end_wave),
    period_event = as.integer(domains$complete_case$period_event),
    matrix = unname(complete_matrix)
  ), algo = "sha256")
  rm(completed, person, domains, complete_frame, complete_matrix)
}
anchors <- do.call(rbind, anchors)
matrix_audits <- do.call(rbind, matrix_audits)
membership_hashes <- do.call(rbind, membership_hashes)

anchor_unique <- unique(anchors[setdiff(names(anchors), "imputation")])
primary <- anchor_unique[anchor_unique$sample_id == "primary", , drop = FALSE]
membership <- v461_observation_membership(context)
observation_counts <- v461_observation_count_rows(membership)

checks <- list()
add_check <- function(check, pass, observed, expected_value) {
  checks[[length(checks) + 1L]] <<- data.frame(
    check = check,
    status = if (isTRUE(pass)) "PASS" else "FAIL",
    observed = as.character(observed),
    expected = as.character(expected_value),
    stringsAsFactors = FALSE
  )
}
add_check(
  "authority_hashes",
  identical(hashes[["mic0"]], expected$mic0) &&
    identical(hashes[["ledger"]], expected$ledger) &&
    identical(hashes[["actual"]], expected$actual) &&
    identical(hashes[["v46_release"]], expected$v46_release),
  "four exact hashes", "four exact hashes"
)
add_check(
  "primary_anchor_identity",
  nrow(primary) == 1L && primary$n == expected$primary_n &&
    primary$deaths == expected$primary_deaths &&
    primary$period_rows == expected$primary_rows &&
    primary$psu == expected$primary_psu,
  if (nrow(primary)) paste(primary[c("n", "deaths", "period_rows", "psu")],
                           collapse = "|") else "absent",
  paste(expected$primary_n, expected$primary_deaths,
        expected$primary_rows, expected$primary_psu, sep = "|")
)
add_check(
  "all_sample_anchors_invariant_across_m50",
  nrow(anchor_unique) == 4L,
  nrow(anchor_unique), 4L
)
add_check(
  "domain_membership_invariant_across_m50",
  all(vapply(membership_hashes[-1L], function(x) length(unique(x)) == 1L,
             logical(1))),
  paste(vapply(membership_hashes[-1L], function(x) length(unique(x)),
               integer(1)), collapse = "|"),
  "1|1|1"
)
add_check(
  "complete_case_model_payload_invariant_across_m50",
  length(unique(complete_matrix_hashes)) == 1L,
  length(unique(complete_matrix_hashes)), 1L
)
add_check(
  "all_model_matrices_finite_full_rank",
  all(matrix_audits$finite & matrix_audits$full_rank),
  paste(sum(matrix_audits$finite & matrix_audits$full_rank),
        nrow(matrix_audits), sep = "/"),
  paste(nrow(matrix_audits), nrow(matrix_audits), sep = "/")
)
add_check(
  "observation_population_partition",
  nrow(membership) == expected$all_window_n &&
    sum(membership$adjacent_contributor) == expected$primary_n &&
    sum(membership$nonconsecutive_only) ==
      expected$all_window_n - expected$primary_n,
  paste(nrow(membership), sum(membership$adjacent_contributor),
        sum(membership$nonconsecutive_only), sep = "|"),
  paste(expected$all_window_n, expected$primary_n,
        expected$all_window_n - expected$primary_n, sep = "|")
)
add_check(
  "nonconsecutive_row_event_anchors",
  sum(membership$nonconsecutive_rows) == expected$nonconsecutive_rows &&
    sum(membership$nonconsecutive_deaths) == expected$nonconsecutive_deaths,
  paste(sum(membership$nonconsecutive_rows),
        sum(membership$nonconsecutive_deaths), sep = "|"),
  paste(expected$nonconsecutive_rows,
        expected$nonconsecutive_deaths, sep = "|")
)
add_check(
  "no_outcome_model_fitted_or_coefficient_released",
  TRUE, "structural operations only", "structural operations only"
)
checks <- do.call(rbind, checks)

out_dir <- file.path(root, "results", "v46_1", "structural_preflight")
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)
manifest <- data.frame(
  name = names(paths),
  path_alias = substring(unname(unlist(paths)), nchar(root) + 2L),
  sha256 = unname(hashes),
  stringsAsFactors = FALSE
)
status <- data.frame(
  status = if (all(checks$status == "PASS")) {
    "STRUCTURAL_PREFLIGHT_PASS"
  } else {
    "STRUCTURAL_PREFLIGHT_FAIL"
  },
  coefficient_visibility = "NONE",
  outcome_model_fits = 0L,
  created_at = format(Sys.time(), "%Y-%m-%dT%H:%M:%S%z"),
  stringsAsFactors = FALSE
)
v45c_atomic_write_tsv(
  manifest, file.path(out_dir, "v46_1_input_manifest.tsv")
)
v45c_atomic_write_tsv(
  checks, file.path(out_dir, "v46_1_structural_checks.tsv")
)
v45c_atomic_write_tsv(
  anchors, file.path(out_dir, "v46_1_sample_anchors_m50.tsv")
)
v45c_atomic_write_tsv(
  anchor_unique, file.path(out_dir, "v46_1_sample_anchors.tsv")
)
v45c_atomic_write_tsv(
  matrix_audits, file.path(out_dir, "v46_1_matrix_audits.tsv")
)
v45c_atomic_write_tsv(
  membership_hashes,
  file.path(out_dir, "v46_1_membership_hashes.tsv")
)
v45c_atomic_write_tsv(
  observation_counts,
  file.path(out_dir, "v46_1_observation_group_counts.tsv")
)
v45c_atomic_write_tsv(
  status, file.path(out_dir, "v46_1_preflight_status.tsv")
)
if (any(checks$status != "PASS")) {
  stop("V46.1 structural preflight failed.", call. = FALSE)
}
cat("V46_1_STRUCTURAL_PREFLIGHT_PASS\n")

