#!/usr/bin/env Rscript

# Independent aggregate validator and release gate for V46.1 CHARLS
# adjacent-domain sensitivity analyses and observation-process profiles.

options(stringsAsFactors = FALSE, warn = 1)

v461_root <- function() {
  args <- commandArgs(trailingOnly = FALSE)
  file_arg <- grep("^--file=", args, value = TRUE)
  if (!length(file_arg)) return(normalizePath(getwd(), mustWork = TRUE))
  script <- sub("^--file=", "", file_arg[[1L]])
  normalizePath(file.path(dirname(script), "..", ".."), mustWork = TRUE)
}

root <- v461_root()
source(file.path(
  root, "R", "v45", "charls_addendum_v45_1",
  "charls_structural_utilities_v45_1.R"
))
v45_charls_activate_project_library(root)
required <- c("digest", "mice")
missing <- required[!vapply(
  required, requireNamespace, logical(1), quietly = TRUE
)]
if (length(missing)) {
  stop("Validator runtime lacks: ", paste(missing, collapse = ", "),
       call. = FALSE)
}

sha256_file <- function(path) {
  if (!file.exists(path) || dir.exists(path) || nzchar(Sys.readlink(path))) {
    return(NA_character_)
  }
  digest::digest(path, algo = "sha256", file = TRUE)
}
read_tsv <- function(path) {
  utils::read.delim(
    path, stringsAsFactors = FALSE, check.names = FALSE,
    na.strings = c("", "NA")
  )
}
atomic_write_tsv <- function(data, path) {
  dir.create(dirname(path), recursive = TRUE, showWarnings = FALSE)
  tmp <- tempfile(paste0(".", basename(path), "."), tmpdir = dirname(path))
  on.exit(if (file.exists(tmp)) unlink(tmp, force = TRUE), add = TRUE)
  utils::write.table(
    data, tmp, sep = "\t", row.names = FALSE, quote = FALSE, na = ""
  )
  if (!file.rename(tmp, path)) {
    stop("Atomic validator write failed.", call. = FALSE)
  }
  invisible(path)
}

expected <- list(
  actual =
    "2e80186cacd93d8f9c29aac1dc02168d545e4f43a4cded86542565bb7a01937c",
  m = 50L,
  replicates = 500L,
  numeric_tolerance = 1e-10,
  covariance_tolerance = 1e-10,
  valid_fraction_stop = 0.80,
  mce_fraction_max = 0.10
)

public_root <- file.path(root, "results", "v46_1", "charls_sensitivity")
current_path <- file.path(public_root, "v46_1_charls_restricted_current.tsv")
current <- read_tsv(current_path)
if (nrow(current) != 1L ||
    !identical(current$coefficient_visibility[[1L]], "RESTRICTED") ||
    !identical(current$independent_validation_status[[1L]], "NOT_RUN") ||
    !identical(
      sha256_file(file.path(root, current$state_path_alias[[1L]])),
      current$state_sha256[[1L]]
    )) {
  stop("The V46.1 restricted-run pointer is invalid.", call. = FALSE)
}
run_id <- current$run_id[[1L]]
state_path <- file.path(root, current$state_path_alias[[1L]])
state <- read_tsv(state_path)
if (!identical(state$module, c("prefix", "full")) ||
    any(state$status != "RESTRICTED_COMPLETE")) {
  stop("Both V46.1 restricted modules are required.", call. = FALSE)
}
module_paths <- file.path(root, state$output_path_alias)
module_hashes <- vapply(module_paths, sha256_file, character(1))
if (!identical(unname(module_hashes), as.character(state$output_sha256))) {
  stop("A V46.1 restricted-module hash failed.", call. = FALSE)
}
objects <- setNames(lapply(module_paths, readRDS), state$module)
prefix <- objects$prefix
full <- objects$full

checks <- list()
add_check <- function(check, pass, observed, expected_value) {
  checks[[length(checks) + 1L]] <<- data.frame(
    check = check,
    status = if (isTRUE(pass)) "PASS" else "FAIL",
    observed = as.character(observed),
    expected = as.character(expected_value),
    stringsAsFactors = FALSE
  )
}

add_check(
  "restricted_module_hashes", all(!is.na(module_hashes)),
  paste(module_hashes, collapse = ";"), "two exact hashes"
)
schema_ok <- identical(
  prefix$schema_version, "v46_1_charls_sensitivity_prefix_restricted"
) && identical(
  full$schema_version, "v46_1_charls_sensitivity_full_restricted"
)
add_check(
  "restricted_schemas", schema_ok,
  paste(prefix$schema_version, full$schema_version, sep = ";"),
  "two V46.1 schemas"
)
privacy_ok <- all(vapply(objects, function(x) {
  identical(x$coefficient_visibility, "RESTRICTED") &&
    identical(x$participant_level_data_saved, FALSE) &&
    identical(x$completed_dataset_saved, FALSE) &&
    identical(x$fit_objects_saved, FALSE) &&
    identical(x$individual_weights_or_predictions_saved, FALSE)
}, logical(1)))
add_check("restricted_privacy_flags", privacy_ok, privacy_ok, TRUE)

preflight_root <- file.path(root, "results", "v46_1", "structural_preflight")
preflight_paths <- list(
  status = file.path(preflight_root, "v46_1_preflight_status.tsv"),
  checks = file.path(preflight_root, "v46_1_structural_checks.tsv"),
  manifest = file.path(preflight_root, "v46_1_input_manifest.tsv"),
  anchors = file.path(preflight_root, "v46_1_sample_anchors.tsv"),
  observation_counts =
    file.path(preflight_root, "v46_1_observation_group_counts.tsv")
)
manifest <- read_tsv(preflight_paths$manifest)
current_manifest_hashes <- vapply(
  file.path(root, manifest$path_alias), sha256_file, character(1)
)
current_input_hashes <- c(
  setNames(as.character(manifest$sha256), paste0("manifest::", manifest$name)),
  preflight_status = sha256_file(preflight_paths$status),
  preflight_checks = sha256_file(preflight_paths$checks),
  preflight_manifest = sha256_file(preflight_paths$manifest),
  preflight_anchors = sha256_file(preflight_paths$anchors),
  preflight_observation_counts = sha256_file(preflight_paths$observation_counts)
)
inputs_current <-
  identical(unname(current_manifest_hashes), as.character(manifest$sha256)) &&
  identical(prefix$input_hashes, full$input_hashes) &&
  identical(full$input_hashes, current_input_hashes)
add_check(
  "frozen_input_hashes_current", inputs_current,
  if (inputs_current) "all exact" else "mismatch", "all exact"
)

mi_columns <- c("boundary_E0_A1", "strict_E0_A1")
prefix_complete <- length(prefix$mi_results) == expected$m &&
  identical(prefix$replicate_indices, seq_len(250L)) &&
  all(vapply(seq_len(expected$m), function(i) {
    group <- prefix$mi_results[[i]]$groups$
      CHARLS_ADJACENT_MI_SENSITIVITIES
    identical(prefix$mi_results[[i]]$imputation, as.integer(i)) &&
      identical(names(group$point), mi_columns) &&
      identical(dim(group$replicates), c(250L, 2L)) &&
      all(is.finite(group$point)) &&
      all(is.finite(group$replicates) | is.na(group$replicates))
  }, logical(1))) &&
  identical(dim(prefix$complete_case_group$replicates), c(250L, 1L))
full_complete <- length(full$mi_results) == expected$m &&
  identical(full$replicate_indices, seq_len(expected$replicates)) &&
  all(vapply(seq_len(expected$m), function(i) {
    group <- full$mi_results[[i]]$groups$
      CHARLS_ADJACENT_MI_SENSITIVITIES
    identical(full$mi_results[[i]]$imputation, as.integer(i)) &&
      identical(names(group$point), mi_columns) &&
      identical(dim(group$replicates), c(expected$replicates, 2L)) &&
      all(is.finite(group$point)) &&
      all(is.finite(group$replicates) | is.na(group$replicates))
  }, logical(1))) &&
  identical(dim(full$complete_case_group$replicates),
            c(expected$replicates, 1L))
add_check(
  "prefix_result_completeness", prefix_complete,
  paste(length(prefix$mi_results), "MI plus complete-case"),
  "50 MI plus complete-case"
)
add_check(
  "full_result_completeness", full_complete,
  paste(length(full$mi_results), "MI plus complete-case"),
  "50 MI plus complete-case"
)

prefix_identity <- all(vapply(seq_len(expected$m), function(i) {
  p <- prefix$mi_results[[i]]$groups$CHARLS_ADJACENT_MI_SENSITIVITIES
  f <- full$mi_results[[i]]$groups$CHARLS_ADJACENT_MI_SENSITIVITIES
  identical(p$point, f$point) &&
    identical(p$replicates, f$replicates[seq_len(250L), , drop = FALSE]) &&
    identical(p$failure_class_by_replicate,
              f$failure_class_by_replicate[seq_len(250L)])
}, logical(1))) &&
  identical(
    prefix$complete_case_group$point, full$complete_case_group$point
  ) && identical(
    prefix$complete_case_group$replicates,
    full$complete_case_group$replicates[seq_len(250L), , drop = FALSE]
  ) && isTRUE(full$literal_prefix_identity)
add_check("literal_prefix_identity", prefix_identity,
          prefix_identity, TRUE)

anchors <- read_tsv(preflight_paths$anchors)
anchor_identity <- identical(
  full$sample_anchors[order(full$sample_anchors$sample_id), ],
  anchors[order(anchors$sample_id), ]
)
add_check(
  "sample_anchor_identity", anchor_identity,
  paste(nrow(full$sample_anchors), "rows"), "four exact anchors"
)

all_groups <- c(
  lapply(full$mi_results, function(x) {
    x$groups$CHARLS_ADJACENT_MI_SENSITIVITIES
  }),
  list(full$complete_case_group)
)
valid_fractions <- vapply(
  all_groups, `[[`, numeric(1), "valid_replicate_fraction"
)
valid_gate_ok <- all(is.finite(valid_fractions)) &&
  min(valid_fractions) >= expected$valid_fraction_stop &&
  full$full_gate %in% c("GO", "CAUTION")
add_check(
  "full_valid_replicate_gate", valid_gate_ok,
  paste0("minimum=", min(valid_fractions), ";gate=", full$full_gate),
  "minimum>=0.80 and gate GO/CAUTION"
)

independent_covariance <- function(point, replicates) {
  valid <- apply(replicates, 1L, function(value) all(is.finite(value)))
  if (sum(valid) < 2L) stop("Too few valid replicate rows.", call. = FALSE)
  centered <- sweep(
    replicates[valid, , drop = FALSE], 2L, point, FUN = "-"
  )
  covariance <- crossprod(centered) / (sum(valid) - 1L)
  dimnames(covariance) <- list(names(point), names(point))
  list(covariance = covariance, valid = valid)
}
covariance_differences <- vapply(all_groups, function(group) {
  independent <- independent_covariance(group$point, group$replicates)
  if (!identical(independent$valid, group$common_valid_mask)) return(Inf)
  max(abs(independent$covariance - group$within_covariance))
}, numeric(1))
covariance_ok <- all(is.finite(covariance_differences)) &&
  max(covariance_differences) <= expected$covariance_tolerance
add_check(
  "independent_replicate_covariance", covariance_ok,
  paste0("maximum absolute difference=", max(covariance_differences)),
  paste0("<=", expected$covariance_tolerance)
)

independent_pool <- function(estimates, variances, dfcom) {
  pooled <- mice::pool.scalar(
    Q = as.numeric(estimates), U = as.numeric(variances),
    n = as.numeric(dfcom) + 1, k = 1, rule = "rubin1987"
  )
  critical <- stats::qt(0.975, df = pooled$df)
  se <- sqrt(pooled$t)
  statistic <- pooled$qbar / se
  data.frame(
    m = as.integer(pooled$m), estimate = pooled$qbar,
    standard_error = se,
    ci_low = pooled$qbar - critical * se,
    ci_high = pooled$qbar + critical * se,
    p_value = 2 * stats::pt(abs(statistic), df = pooled$df,
                            lower.tail = FALSE),
    within_variance = pooled$ubar,
    between_variance = pooled$b,
    total_variance = pooled$t,
    df = pooled$df, dfcom = dfcom, FMI = pooled$fmi,
    MCE = sqrt(pooled$b / pooled$m),
    MCE_fraction = sqrt(pooled$b / pooled$m) / se,
    stringsAsFactors = FALSE
  )
}

metadata <- data.frame(
  column = mi_columns,
  analysis_id = c(
    "v46_1_charls_adjacent_boundary_excluded_a1",
    "v46_1_charls_adjacent_strict_measurement_a1"
  ),
  sample_id = c("boundary_excluded", "strict_measurement"),
  stringsAsFactors = FALSE
)
independent_rows <- lapply(seq_len(nrow(metadata)), function(index) {
  column <- metadata$column[[index]]
  q <- vapply(seq_len(expected$m), function(i) {
    full$mi_results[[i]]$groups$CHARLS_ADJACENT_MI_SENSITIVITIES$
      point[[column]]
  }, numeric(1))
  u <- vapply(seq_len(expected$m), function(i) {
    covariance <- full$mi_results[[i]]$groups$
      CHARLS_ADJACENT_MI_SENSITIVITIES$within_covariance
    covariance[column, column]
  }, numeric(1))
  anchor <- anchors[anchors$sample_id == metadata$sample_id[[index]],
                    , drop = FALSE]
  cbind(metadata[index, , drop = FALSE],
        independent_pool(q, u, anchor$dfcom[[1L]]))
})
independent_scalar <- do.call(rbind, independent_rows)
stored <- full$pooled_scalar
stored_key <- paste(stored$analysis_id, stored$term, sep = "\u241f")
independent_key <- paste(
  independent_scalar$analysis_id, "E0", sep = "\u241f"
)
index <- match(stored_key, independent_key)
fields <- c(
  "m", "estimate", "standard_error", "ci_low", "ci_high", "p_value",
  "within_variance", "between_variance", "total_variance", "df",
  "dfcom", "FMI", "MCE", "MCE_fraction"
)
scalar_difference <- if (anyNA(index) || anyDuplicated(index)) Inf else max(abs(
  as.matrix(stored[, fields]) -
    as.matrix(independent_scalar[index, fields])
))
scalar_pool_ok <- is.finite(scalar_difference) &&
  scalar_difference <= expected$numeric_tolerance
add_check(
  "independent_scalar_Rubin_pooling", scalar_pool_ok,
  paste0("maximum absolute difference=", scalar_difference),
  paste0("<=", expected$numeric_tolerance)
)

cc_group <- full$complete_case_group
cc_anchor <- anchors[anchors$sample_id == "complete_case", , drop = FALSE]
cc_independent_variance <- independent_covariance(
  cc_group$point, cc_group$replicates
)$covariance[[1L]]
cc_estimate <- cc_group$point[[1L]]
cc_se <- sqrt(cc_independent_variance)
cc_df <- cc_anchor$dfcom[[1L]]
cc_critical <- stats::qt(0.975, df = cc_df)
cc_independent <- data.frame(
  analysis_id = "v46_1_charls_adjacent_complete_case_a1",
  term = "E0", group_id = "CHARLS_ADJACENT_COMPLETE_CASE",
  estimate = cc_estimate,
  within_variance = cc_independent_variance,
  standard_error = cc_se, df = cc_df,
  ci_low = cc_estimate - cc_critical * cc_se,
  ci_high = cc_estimate + cc_critical * cc_se,
  p_value = 2 * stats::pt(abs(cc_estimate / cc_se), df = cc_df,
                          lower.tail = FALSE),
  valid_replicate_n = cc_group$valid_replicate_n,
  valid_replicate_fraction = cc_group$valid_replicate_fraction,
  stringsAsFactors = FALSE
)
cc_fields <- c(
  "estimate", "within_variance", "standard_error", "df", "ci_low",
  "ci_high", "p_value", "valid_replicate_n", "valid_replicate_fraction"
)
cc_difference <- max(abs(
  as.numeric(unlist(
    full$complete_case_scalar[1L, cc_fields], use.names = FALSE
  )) -
    as.numeric(unlist(
      cc_independent[1L, cc_fields], use.names = FALSE
    ))
))
add_check(
  "independent_complete_case_release", is.finite(cc_difference) &&
    cc_difference <= expected$numeric_tolerance,
  paste0("maximum absolute difference=", cc_difference),
  paste0("<=", expected$numeric_tolerance)
)

mce_ok <- all(is.finite(stored$MCE_fraction)) &&
  all(stored$MCE_fraction < expected$mce_fraction_max) &&
  !isTRUE(full$m100_trigger_metadata$trigger)
add_check(
  "m50_Monte_Carlo_error_gate", mce_ok,
  paste0("maximum fraction=", max(stored$MCE_fraction)),
  paste0("<", expected$mce_fraction_max)
)

# Independently reconstruct aggregate observation-process profiles.
Sys.setenv(V45_CHARLS_OUTCOME_LIBRARY_ONLY = "yes")
sys.source(file.path(
  root, "R", "v45", "charls_addendum_v45_1",
  "12_run_charls_outcome_execution_v45_1.R"
), envir = .GlobalEnv)
source(file.path(root, "R", "v46_1", "charls_v46_1_utilities.R"))
manifest_path <- function(name) {
  row <- match(name, manifest$name)
  if (is.na(row)) stop("Manifest lacks ", name, ".", call. = FALSE)
  file.path(root, manifest$path_alias[[row]])
}
mic0 <- readRDS(manifest_path("mic0"))
context <- v45c_load_context(
  root, list(actual_design_contract_sha256 = expected$actual)
)
membership <- v461_observation_membership(context)
count_recomputed <- v461_observation_count_rows(membership)
count_frozen <- read_tsv(preflight_paths$observation_counts)
canonicalize_count_table <- function(value) {
  value <- value[order(value$group_id), , drop = FALSE]
  rownames(value) <- NULL
  numeric_columns <- setdiff(names(value), "group_id")
  value[numeric_columns] <- lapply(
    value[numeric_columns], as.numeric
  )
  value
}
count_identity <- identical(
  canonicalize_count_table(count_recomputed),
  canonicalize_count_table(count_frozen)
)
add_check(
  "observation_group_count_reconstruction", count_identity,
  if (count_identity) "exact" else "mismatch", "exact"
)
profiles <- do.call(rbind, lapply(seq_len(expected$m), function(imputation) {
  completed <- mice::complete(mic0, action = imputation)
  person <- v45c_prepare_person(
    completed, context$ledger, context$actual, context$v43, "MI-C0"
  )
  value <- v461_profile_one_imputation(person, membership, imputation)
  rm(completed, person)
  value
}))
profile_release <- do.call(rbind, lapply(
  split(profiles, profiles$variable_id), function(x) {
    data.frame(
      variable_id = x$variable_id[[1L]],
      variable_type = x$variable_type[[1L]],
      m = nrow(x),
      adjacent_estimate = mean(x$adjacent_estimate),
      nonconsecutive_only_estimate =
        mean(x$nonconsecutive_only_estimate),
      standardized_mean_difference =
        mean(x$standardized_mean_difference),
      absolute_standardized_mean_difference =
        abs(mean(x$standardized_mean_difference)),
      imputation_minimum_smd = min(x$standardized_mean_difference),
      imputation_maximum_smd = max(x$standardized_mean_difference),
      stringsAsFactors = FALSE
    )
  }
))
rownames(profile_release) <- NULL
profile_ok <- nrow(profile_release) == 10L &&
  all(profile_release$m == expected$m) &&
  all(is.finite(as.matrix(profile_release[c(
    "adjacent_estimate", "nonconsecutive_only_estimate",
    "standardized_mean_difference"
  )])))
add_check(
  "observation_profile_aggregate_release", profile_ok,
  paste(nrow(profile_release), "variables"), "10 finite variables"
)

checks_table <- do.call(rbind, checks)
rownames(checks_table) <- NULL
validation_path <- file.path(
  public_root, "v46_1_charls_independent_validation_checks.tsv"
)
atomic_write_tsv(checks_table, validation_path)
if (!all(checks_table$status == "PASS")) {
  stop("V46.1 independent validation failed; release blocked.",
       call. = FALSE)
}

mi_release <- merge(
  metadata, independent_scalar,
  by = c("column", "analysis_id", "sample_id"), sort = FALSE
)
mi_release <- mi_release[match(mi_columns, mi_release$column), , drop = FALSE]
mi_release$term <- "E0"
mi_release$analysis_method <- "multiple_imputation_m50"
cc_release <- cc_independent
cc_release$column <- "complete_case_E0_A1"
cc_release$sample_id <- "complete_case"
cc_release$m <- 0L
cc_release$between_variance <- 0
cc_release$total_variance <- cc_release$within_variance
cc_release$dfcom <- cc_release$df
cc_release$FMI <- 0
cc_release$MCE <- 0
cc_release$MCE_fraction <- 0
cc_release$analysis_method <- "complete_case"
release_fields <- c(
  "column", "analysis_id", "term", "sample_id", "analysis_method",
  "m", "estimate", "standard_error", "ci_low", "ci_high", "p_value",
  "within_variance", "between_variance", "total_variance", "df",
  "dfcom", "FMI", "MCE", "MCE_fraction"
)
release <- rbind(mi_release[release_fields], cc_release[release_fields])
release <- merge(release, anchors, by = "sample_id", sort = FALSE)
release$cohort <- "CHARLS"
release$followup_domain <- "adjacent transitions"
release$adjustment <- "A1"
release$hazard_ratio <- exp(release$estimate)
release$hazard_ratio_ci_low <- exp(release$ci_low)
release$hazard_ratio_ci_high <- exp(release$ci_high)
release$independent_validation_status <- "PASS"

release_path <- file.path(
  public_root, "v46_1_charls_sensitivity_released_results.tsv"
)
profile_path <- file.path(
  public_root, "v46_1_charls_observation_profile.tsv"
)
count_path <- file.path(
  public_root, "v46_1_charls_observation_counts.tsv"
)
atomic_write_tsv(release, release_path)
atomic_write_tsv(profile_release, profile_path)
atomic_write_tsv(count_recomputed, count_path)

release_manifest <- data.frame(
  artifact = c(
    "sensitivity_results", "observation_profile", "observation_counts",
    "validation_checks", "prefix_restricted", "full_restricted",
    "validator_script"
  ),
  path_alias = c(
    substring(release_path, nchar(root) + 2L),
    substring(profile_path, nchar(root) + 2L),
    substring(count_path, nchar(root) + 2L),
    substring(validation_path, nchar(root) + 2L),
    state$output_path_alias[state$module == "prefix"],
    state$output_path_alias[state$module == "full"],
    "R/v46_1/02_validate_charls_sensitivity_v46_1.R"
  ),
  sha256 = c(
    sha256_file(release_path), sha256_file(profile_path),
    sha256_file(count_path), sha256_file(validation_path),
    state$output_sha256[state$module == "prefix"],
    state$output_sha256[state$module == "full"],
    sha256_file(file.path(
      root, "R", "v46_1", "02_validate_charls_sensitivity_v46_1.R"
    ))
  ),
  stringsAsFactors = FALSE
)
manifest_out_path <- file.path(
  public_root, "v46_1_charls_release_manifest.tsv"
)
atomic_write_tsv(release_manifest, manifest_out_path)
validated_pointer <- data.frame(
  run_id = run_id,
  release_path_alias = substring(release_path, nchar(root) + 2L),
  release_sha256 = sha256_file(release_path),
  validation_path_alias = substring(validation_path, nchar(root) + 2L),
  validation_sha256 = sha256_file(validation_path),
  release_manifest_path_alias =
    substring(manifest_out_path, nchar(root) + 2L),
  release_manifest_sha256 = sha256_file(manifest_out_path),
  status = "INDEPENDENT_VALIDATION_PASS",
  validated_at_utc = format(
    Sys.time(), "%Y-%m-%dT%H:%M:%SZ", tz = "UTC"
  ),
  stringsAsFactors = FALSE
)
atomic_write_tsv(
  validated_pointer,
  file.path(public_root, "v46_1_charls_validated_current.tsv")
)
cat("V46_1_CHARLS_INDEPENDENT_VALIDATION_PASS\n")
cat("run_id=", run_id, "\n", sep = "")
cat("public_aggregate_release=complete\n")
