#!/usr/bin/env Rscript

# Restricted V46.1 adjacent-domain CHARLS sensitivity execution.

options(stringsAsFactors = FALSE, warn = 1)

v461_root <- function() {
  args <- commandArgs(trailingOnly = FALSE)
  file_arg <- grep("^--file=", args, value = TRUE)
  if (!length(file_arg)) return(normalizePath(getwd(), mustWork = TRUE))
  script <- sub("^--file=", "", file_arg[[1L]])
  normalizePath(file.path(dirname(script), "..", ".."), mustWork = TRUE)
}

root <- v461_root()
Sys.setenv(V45_CHARLS_OUTCOME_LIBRARY_ONLY = "yes")
sys.source(file.path(
  root, "R", "v45", "charls_addendum_v45_1",
  "12_run_charls_outcome_execution_v45_1.R"
), envir = .GlobalEnv)
source(file.path(root, "R", "v46_1", "charls_v46_1_utilities.R"))
v45c_validate_runtime(root)

args <- commandArgs(trailingOnly = TRUE)
arg_value <- function(prefix, default = NULL) {
  hit <- grep(paste0("^", prefix, "="), args, value = TRUE)
  if (!length(hit)) return(default)
  sub(paste0("^", prefix, "="), "", tail(hit, 1L))
}
module_requested <- arg_value("--module", "all")
if (!module_requested %in% c("prefix", "full", "all")) {
  stop("--module must be prefix, full, or all.", call. = FALSE)
}
workers <- suppressWarnings(as.integer(arg_value("--workers", "4")))
if (!is.finite(workers) || workers < 1L || workers > 8L) {
  stop("--workers must be an integer from 1 through 8.", call. = FALSE)
}
workers <- min(workers, max(1L, parallel::detectCores() - 1L))

read_tsv <- function(path) {
  utils::read.delim(
    path, stringsAsFactors = FALSE, check.names = FALSE,
    na.strings = c("", "NA")
  )
}

expected <- list(
  actual =
    "2e80186cacd93d8f9c29aac1dc02168d545e4f43a4cded86542565bb7a01937c",
  mic0 =
    "8d7d0b16cf6028ac6ba1c7566d5957c650398c612138fdf1c2aae96424fb2f9e",
  m = 50L,
  replicates = 500L
)

preflight_root <- file.path(root, "results", "v46_1", "structural_preflight")
preflight_paths <- list(
  status = file.path(preflight_root, "v46_1_preflight_status.tsv"),
  checks = file.path(preflight_root, "v46_1_structural_checks.tsv"),
  manifest = file.path(preflight_root, "v46_1_input_manifest.tsv"),
  anchors = file.path(preflight_root, "v46_1_sample_anchors.tsv"),
  observation_counts =
    file.path(preflight_root, "v46_1_observation_group_counts.tsv")
)
if (any(!vapply(preflight_paths, file.exists, logical(1)))) {
  stop("V46.1 structural preflight is incomplete.", call. = FALSE)
}
status <- read_tsv(preflight_paths$status)
checks <- read_tsv(preflight_paths$checks)
manifest <- read_tsv(preflight_paths$manifest)
anchors <- read_tsv(preflight_paths$anchors)
if (nrow(status) != 1L ||
    !identical(status$status[[1L]], "STRUCTURAL_PREFLIGHT_PASS") ||
    status$outcome_model_fits[[1L]] != 0L ||
    any(checks$status != "PASS")) {
  stop("V46.1 structural preflight did not authorize execution.",
       call. = FALSE)
}
current_manifest_hashes <- vapply(
  file.path(root, manifest$path_alias), v45c_sha256_file, character(1)
)
if (anyNA(current_manifest_hashes) ||
    !identical(unname(current_manifest_hashes),
               as.character(manifest$sha256))) {
  stop("A V46.1 preflight-bound input changed.", call. = FALSE)
}
manifest_hash <- function(name) {
  row <- match(name, manifest$name)
  if (is.na(row)) stop("Manifest lacks ", name, ".", call. = FALSE)
  manifest$sha256[[row]]
}
manifest_path <- function(name) {
  row <- match(name, manifest$name)
  if (is.na(row)) stop("Manifest lacks ", name, ".", call. = FALSE)
  file.path(root, manifest$path_alias[[row]])
}
if (!identical(manifest_hash("mic0"), expected$mic0) ||
    !identical(manifest_hash("actual"), expected$actual)) {
  stop("The V46.1 MI/design authorities drifted.", call. = FALSE)
}

anchor_for <- function(sample_id) {
  row <- anchors[anchors$sample_id == sample_id, , drop = FALSE]
  if (nrow(row) != 1L) {
    stop("Missing or duplicate sample anchor: ", sample_id, call. = FALSE)
  }
  row
}
anchor_cc <- anchor_for("complete_case")
anchor_boundary <- anchor_for("boundary_excluded")
anchor_strict <- anchor_for("strict_measurement")

public_root <- file.path(root, "results", "v46_1", "charls_sensitivity")
restricted_root <- file.path(
  root, "derived_sensitive", "v46_1", "charls_sensitivity"
)
log_root <- file.path(root, "logs", "v46_1", "charls_sensitivity")
dir.create(public_root, recursive = TRUE, showWarnings = FALSE)
dir.create(restricted_root, recursive = TRUE, showWarnings = FALSE)
dir.create(log_root, recursive = TRUE, showWarnings = FALSE)

current_path <- file.path(public_root, "v46_1_charls_restricted_current.tsv")
run_id_arg <- arg_value("--run-id", NULL)
if (!is.null(run_id_arg) && !grepl(
  "^v46_1_charls_sensitivity_m50_[0-9]{8}T[0-9]{6}_pid[0-9]+$",
  run_id_arg
)) {
  stop("Unsafe or invalid --run-id.", call. = FALSE)
}
if (!is.null(run_id_arg)) {
  run_id <- run_id_arg
} else if (file.exists(current_path)) {
  current <- read_tsv(current_path)
  if (nrow(current) != 1L ||
      !grepl("^v46_1_charls_sensitivity_m50_", current$run_id[[1L]])) {
    stop("The V46.1 current-run pointer is invalid.", call. = FALSE)
  }
  run_id <- current$run_id[[1L]]
} else {
  run_id <- paste0(
    "v46_1_charls_sensitivity_m50_",
    format(Sys.time(), "%Y%m%dT%H%M%S"), "_pid", Sys.getpid()
  )
}

run_dir <- file.path(restricted_root, run_id)
state_dir <- file.path(public_root, run_id)
dir.create(run_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(state_dir, recursive = TRUE, showWarnings = FALSE)
state_path <- file.path(state_dir, "module_state.tsv")
log_path <- file.path(log_root, paste0(run_id, ".log"))
state <- if (file.exists(state_path)) {
  read_tsv(state_path)
} else {
  data.frame(
    module = c("prefix", "full"),
    status = "NOT_RUN",
    output_path_alias = NA_character_,
    output_sha256 = NA_character_,
    completed_at = NA_character_,
    stringsAsFactors = FALSE
  )
}
if (!identical(state$module, c("prefix", "full")) ||
    any(!state$status %in% c("NOT_RUN", "RUNNING", "RESTRICTED_COMPLETE"))) {
  stop("V46.1 module state is invalid.", call. = FALSE)
}
if (any(state$status == "RUNNING")) {
  stop("Interrupted RUNNING state requires audit and a new run ID.",
       call. = FALSE)
}

log_lines <- if (file.exists(log_path)) readLines(log_path, warn = FALSE) else c(
  paste0("run_id: ", run_id),
  "coefficient_visibility: restricted",
  "participant_level_output: forbidden",
  paste0("workers: ", workers)
)
append_log <- function(value) {
  line <- paste0(
    format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z"), " ", value
  )
  log_lines <<- c(log_lines, line)
  v45c_atomic_write_lines(log_lines, log_path)
  message(value)
}
write_state <- function() {
  v45c_atomic_write_tsv(state, state_path)
  pointer <- data.frame(
    run_id = run_id,
    state_path_alias = substring(state_path, nchar(root) + 2L),
    state_sha256 = v45c_sha256_file(state_path),
    coefficient_visibility = "RESTRICTED",
    independent_validation_status = "NOT_RUN",
    stringsAsFactors = FALSE
  )
  v45c_atomic_write_tsv(pointer, current_path)
  invisible(TRUE)
}
write_state()

module_alias <- function(module) file.path(
  "derived_sensitive", "v46_1", "charls_sensitivity", run_id,
  paste0(module, "_restricted.rds")
)
module_path <- function(module) file.path(root, module_alias(module))
input_hashes <- c(
  setNames(as.character(manifest$sha256), paste0("manifest::", manifest$name)),
  preflight_status = v45c_sha256_file(preflight_paths$status),
  preflight_checks = v45c_sha256_file(preflight_paths$checks),
  preflight_manifest = v45c_sha256_file(preflight_paths$manifest),
  preflight_anchors = v45c_sha256_file(preflight_paths$anchors),
  preflight_observation_counts =
    v45c_sha256_file(preflight_paths$observation_counts)
)

publish_module <- function(module, object) {
  row <- match(module, state$module)
  if (is.na(row) || state$status[[row]] != "RUNNING") {
    stop(module, " is not in RUNNING state.", call. = FALSE)
  }
  path <- module_path(module)
  if (file.exists(path)) {
    stop("Refusing to overwrite restricted output: ", path, call. = FALSE)
  }
  object$schema_version <- paste0(
    "v46_1_charls_sensitivity_", module, "_restricted"
  )
  object$run_id <- run_id
  object$created_at_utc <- format(
    Sys.time(), "%Y-%m-%dT%H:%M:%SZ", tz = "UTC"
  )
  object$input_hashes <- input_hashes
  object$coefficient_visibility <- "RESTRICTED"
  object$participant_level_data_saved <- FALSE
  object$completed_dataset_saved <- FALSE
  object$fit_objects_saved <- FALSE
  object$individual_weights_or_predictions_saved <- FALSE
  object$independent_validation_status <- "NOT_RUN"
  v45c_atomic_save_rds(object, path)
  state$status[[row]] <<- "RESTRICTED_COMPLETE"
  state$output_path_alias[[row]] <<- module_alias(module)
  state$output_sha256[[row]] <<- v45c_sha256_file(path)
  state$completed_at[[row]] <<- format(
    Sys.time(), "%Y-%m-%dT%H:%M:%S%z"
  )
  write_state()
  append_log(paste0(
    module, " completed; restricted SHA-256=", state$output_sha256[[row]]
  ))
  invisible(path)
}

read_module <- function(module) {
  row <- match(module, state$module)
  if (is.na(row) || state$status[[row]] != "RESTRICTED_COMPLETE") {
    stop(module, " prerequisite is incomplete.", call. = FALSE)
  }
  path <- file.path(root, state$output_path_alias[[row]])
  if (!file.exists(path) ||
      !identical(v45c_sha256_file(path), state$output_sha256[[row]])) {
    stop(module, " restricted output hash failed.", call. = FALSE)
  }
  value <- readRDS(path)
  if (!identical(value$input_hashes, input_hashes) ||
      !identical(value$coefficient_visibility, "RESTRICTED") ||
      !identical(value$independent_validation_status, "NOT_RUN")) {
    stop(module, " restricted metadata drifted.", call. = FALSE)
  }
  value
}

mic0 <- readRDS(manifest_path("mic0"))
if (!inherits(mic0, "mids") || mic0$m != expected$m) {
  stop("MI-C0 is not the frozen m=50 object.", call. = FALSE)
}
context <- v45c_load_context(
  root, list(actual_design_contract_sha256 = expected$actual)
)
complete_case_ids <- v461_complete_case_ids(mic0)
formula <- context$v43$model_formulas("E0", FALSE)$A1

fit_point <- function(period, model_id) {
  v45c_fit_cloglog(
    period, period$weight_biomarker_w1,
    formula, "E0", model_id, point_survey = TRUE
  )$coefficients[["E0"]]
}

one_imputation <- function(imputation, replicate_indices,
                           prefix_result = NULL) {
  completed <- mice::complete(mic0, action = imputation)
  person <- v45c_prepare_person(
    completed, context$ledger, context$actual, context$v43, "MI-C0"
  )
  domains <- v461_domain_periods(person, context, complete_case_ids)
  v45c_assert_anchor(
    domains$boundary_excluded, anchor_boundary$n,
    anchor_boundary$deaths, anchor_boundary$period_rows,
    anchor_boundary$psu,
    paste0("V46.1 boundary imputation ", imputation)
  )
  v45c_assert_anchor(
    domains$strict_measurement, anchor_strict$n,
    anchor_strict$deaths, anchor_strict$period_rows,
    anchor_strict$psu,
    paste0("V46.1 strict imputation ", imputation)
  )
  caches <- list(
    boundary = v45c_build_glm_cache(
      domains$boundary_excluded, formula, "E0",
      paste0("v46_1_boundary_imp", imputation)
    ),
    strict = v45c_build_glm_cache(
      domains$strict_measurement, formula, "E0",
      paste0("v46_1_strict_imp", imputation)
    )
  )
  if (is.null(prefix_result)) {
    point <- c(
      boundary_E0_A1 = fit_point(
        domains$boundary_excluded,
        paste0("v46_1_boundary_imp", imputation, "_point")
      ),
      strict_E0_A1 = fit_point(
        domains$strict_measurement,
        paste0("v46_1_strict_imp", imputation, "_point")
      )
    )
  } else {
    point <- prefix_result$groups$CHARLS_ADJACENT_MI_SENSITIVITIES$point
  }
  replicate_names <- v45c_literal_replicate_names(replicate_indices)
  replicates <- matrix(
    NA_real_, nrow = length(replicate_indices), ncol = length(point),
    dimnames = list(replicate_names, names(point))
  )
  failures <- character(length(replicate_indices))
  for (row in seq_along(replicate_indices)) {
    replicate_index <- replicate_indices[[row]]
    multiplier_boundary <- v45c_replicate_multiplier(
      domains$boundary_excluded$community_id,
      context$actual$modules$adjacent, replicate_index
    )
    multiplier_strict <- v45c_replicate_multiplier(
      domains$strict_measurement$community_id,
      context$actual$modules$adjacent, replicate_index
    )
    attempt <- v45c_try_replicate_fit({
      boundary <- v45c_fit_cached_glm(
        caches$boundary,
        domains$boundary_excluded$weight_biomarker_w1 * multiplier_boundary,
        paste0("v46_1_boundary_imp", imputation, "_", replicate_names[[row]])
      )$coefficients[["E0"]]
      strict <- v45c_fit_cached_glm(
        caches$strict,
        domains$strict_measurement$weight_biomarker_w1 * multiplier_strict,
        paste0("v46_1_strict_imp", imputation, "_", replicate_names[[row]])
      )$coefficients[["E0"]]
      c(boundary_E0_A1 = boundary, strict_E0_A1 = strict)
    }, length(point), names(point))
    replicates[row, ] <- attempt$value
    failures[[row]] <- attempt$failure_class
  }
  group <- if (is.null(prefix_result)) {
    v45c_make_group(
      "CHARLS_ADJACENT_MI_SENSITIVITIES", point, replicates,
      c(
        boundary_E0_A1 = anchor_boundary$dfcom,
        strict_E0_A1 = anchor_strict$dfcom
      ), failures, compute_covariance = FALSE
    )
  } else {
    v45c_extend_group(
      prefix_result$groups$CHARLS_ADJACENT_MI_SENSITIVITIES,
      replicates, failures
    )
  }
  rm(completed, person, domains, caches)
  list(
    imputation = as.integer(imputation),
    groups = list(CHARLS_ADJACENT_MI_SENSITIVITIES = group)
  )
}

complete_case_group <- function(replicate_indices, prefix_group = NULL) {
  completed <- mice::complete(mic0, action = 1L)
  person <- v45c_prepare_person(
    completed, context$ledger, context$actual, context$v43, "MI-C0"
  )
  period <- v461_domain_periods(
    person, context, complete_case_ids
  )$complete_case
  v45c_assert_anchor(
    period, anchor_cc$n, anchor_cc$deaths, anchor_cc$period_rows,
    anchor_cc$psu, "V46.1 adjacent complete-case"
  )
  cache <- v45c_build_glm_cache(
    period, formula, "E0", "v46_1_complete_case"
  )
  point <- if (is.null(prefix_group)) {
    c(complete_case_E0_A1 = fit_point(
      period, "v46_1_complete_case_point"
    ))
  } else {
    prefix_group$point
  }
  replicate_names <- v45c_literal_replicate_names(replicate_indices)
  replicates <- matrix(
    NA_real_, nrow = length(replicate_indices), ncol = 1L,
    dimnames = list(replicate_names, names(point))
  )
  failures <- character(length(replicate_indices))
  for (row in seq_along(replicate_indices)) {
    replicate_index <- replicate_indices[[row]]
    multiplier <- v45c_replicate_multiplier(
      period$community_id, context$actual$modules$adjacent,
      replicate_index
    )
    attempt <- v45c_try_replicate_fit({
      c(complete_case_E0_A1 = v45c_fit_cached_glm(
        cache, period$weight_biomarker_w1 * multiplier,
        paste0("v46_1_complete_case_", replicate_names[[row]])
      )$coefficients[["E0"]])
    }, 1L, names(point))
    replicates[row, ] <- attempt$value
    failures[[row]] <- attempt$failure_class
  }
  group <- if (is.null(prefix_group)) {
    v45c_make_group(
      "CHARLS_ADJACENT_COMPLETE_CASE", point, replicates,
      c(complete_case_E0_A1 = anchor_cc$dfcom), failures,
      compute_covariance = FALSE
    )
  } else {
    v45c_extend_group(prefix_group, replicates, failures)
  }
  rm(completed, person, period, cache)
  group
}

scalar_map <- data.frame(
  group_id = "CHARLS_ADJACENT_MI_SENSITIVITIES",
  column = c("boundary_E0_A1", "strict_E0_A1"),
  analysis_id = c(
    "v46_1_charls_adjacent_boundary_excluded_a1",
    "v46_1_charls_adjacent_strict_measurement_a1"
  ),
  term = "E0",
  MCE_trigger = TRUE,
  stringsAsFactors = FALSE
)

run_module <- function(module) {
  row <- match(module, state$module)
  if (state$status[[row]] == "RESTRICTED_COMPLETE") {
    append_log(paste0(module, " already complete; verified and skipped."))
    return(invisible(read_module(module)))
  }
  if (state$status[[row]] != "NOT_RUN") {
    stop(module, " cannot start from its current state.", call. = FALSE)
  }
  prefix <- NULL
  if (module == "full") {
    prefix <- read_module("prefix")
    if (!identical(prefix$replicate_indices, seq_len(250L)) ||
        !prefix$prefix_gate %in% c("GO", "CAUTION")) {
      stop("Prefix did not authorize full execution.", call. = FALSE)
    }
  }
  state$status[[row]] <<- "RUNNING"
  write_state()
  append_log(paste0(module, " restricted transaction started."))
  indices <- if (module == "prefix") seq_len(250L) else 251:500
  mi_results <- v45c_parallel_map(
    seq_len(expected$m),
    function(i) one_imputation(
      i, indices, if (is.null(prefix)) NULL else prefix$mi_results[[i]]
    ),
    workers,
    paste0("V46.1 CHARLS ", module, " literal replicate columns"),
    append_log
  )
  cc_group <- complete_case_group(
    indices,
    if (is.null(prefix)) NULL else prefix$complete_case_group
  )
  gate_inputs <- c(
    mi_results,
    list(list(groups = list(CHARLS_ADJACENT_COMPLETE_CASE = cc_group)))
  )
  gate <- v45c_module_gate(gate_inputs)
  object <- list(
    module = module,
    mi_object = "MI-C0",
    requested_m = expected$m,
    replicate_indices = if (module == "prefix") seq_len(250L) else
      seq_len(500L),
    executed_in_this_transaction = indices,
    prefix_sha256 = if (module == "full")
      state$output_sha256[state$module == "prefix"] else NA_character_,
    literal_prefix_identity = if (module == "full") {
      mi_ok <- all(vapply(seq_len(expected$m), function(i) {
        identical(
          prefix$mi_results[[i]]$groups$CHARLS_ADJACENT_MI_SENSITIVITIES$replicates,
          mi_results[[i]]$groups$CHARLS_ADJACENT_MI_SENSITIVITIES$replicates[
            seq_len(250L), , drop = FALSE
          ]
        )
      }, logical(1)))
      cc_ok <- identical(
        prefix$complete_case_group$replicates,
        cc_group$replicates[seq_len(250L), , drop = FALSE]
      )
      mi_ok && cc_ok
    } else NA,
    mi_results = mi_results,
    complete_case_group = cc_group,
    sample_anchors = anchors,
    minimum_valid_replicate_fraction = gate$minimum_valid_fraction,
    prefix_gate = if (module == "prefix") gate$gate else NA_character_,
    full_gate = if (module == "full") gate$gate else NA_character_,
    coefficient_blind_prefix_gate = module == "prefix",
    prefix_pooling_or_release_performed = FALSE,
    no_replacement_replicates = TRUE,
    variance_rule = "1/(B_valid-1)",
    common_failure_masks_preserved = TRUE
  )
  if (module == "full" && !isTRUE(object$literal_prefix_identity)) {
    stop("Full object failed literal prefix identity.", call. = FALSE)
  }
  if (module == "full" && gate$gate != "STOP") {
    pooled <- v45c_pool_full_module(mi_results, scalar_map)
    cc_variance <- cc_group$within_covariance[
      "complete_case_E0_A1", "complete_case_E0_A1"
    ]
    cc_estimate <- cc_group$point[["complete_case_E0_A1"]]
    cc_se <- sqrt(cc_variance)
    cc_df <- cc_group$dfcom_by_column[["complete_case_E0_A1"]]
    cc_critical <- stats::qt(0.975, df = cc_df)
    complete_case_scalar <- data.frame(
      analysis_id = "v46_1_charls_adjacent_complete_case_a1",
      term = "E0",
      group_id = "CHARLS_ADJACENT_COMPLETE_CASE",
      estimate = cc_estimate,
      within_variance = cc_variance,
      standard_error = cc_se,
      df = cc_df,
      ci_low = cc_estimate - cc_critical * cc_se,
      ci_high = cc_estimate + cc_critical * cc_se,
      p_value = 2 * stats::pt(
        abs(cc_estimate / cc_se), df = cc_df, lower.tail = FALSE
      ),
      valid_replicate_n = cc_group$valid_replicate_n,
      valid_replicate_fraction = cc_group$valid_replicate_fraction,
      stringsAsFactors = FALSE
    )
    object$pooling_status <- "COMPLETE"
    object$per_imputation <- pooled$per_imputation
    object$pooled_scalar <- pooled$pooled_scalar
    object$complete_case_scalar <- complete_case_scalar
    object$m100_trigger_metadata <- pooled$m100_trigger_metadata
  } else if (module == "full") {
    object$pooling_status <- "NOT_PERFORMED_FULL_GATE_STOP"
  } else {
    object$pooling_status <- "NOT_APPLICABLE_PREFIX"
  }
  publish_module(module, object)
  if (gate$gate == "STOP") {
    stop(module, " valid-replicate fraction gate is STOP.", call. = FALSE)
  }
  if (module == "full" && object$pooling_status != "COMPLETE") {
    stop("Full V46.1 pooling did not complete.", call. = FALSE)
  }
  invisible(object)
}

requested <- if (module_requested == "all") c("prefix", "full") else
  module_requested
append_log(paste0("Requested module: ", module_requested))
for (module in requested) run_module(module)
append_log("Requested V46.1 CHARLS restricted execution completed.")
cat("V46_1_CHARLS_RESTRICTED_EXECUTION_COMPLETE\n")
cat("run_id=", run_id, "\n", sep = "")
cat("coefficient_visibility=RESTRICTED\n")
cat("independent_validation_status=NOT_RUN\n")

