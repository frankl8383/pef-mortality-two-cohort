# Shared result-blind utilities for the V46.1 CHARLS corrective revision.

v461_complete_case_ids <- function(mic0) {
  if (!inherits(mic0, "mids")) {
    stop("MI-C0 is not a mids object.", call. = FALSE)
  }
  raw <- as.data.frame(mic0$data, stringsAsFactors = FALSE)
  required <- c(
    "participant_id", "height_m_w1", "weight_kg_w1",
    "smoke_ever_w1", "smoke_now_w1", "raeducl", "h1rural",
    "hh1cperc", "lung_w1", "asthma_w1", "r1hibpe", "r1diabe",
    "r1cancre", "r1hearte", "r1stroke", "r1kidneye",
    "frailty_proxy_count_w1"
  )
  if (!all(required %in% names(raw))) {
    stop("MI-C0 lacks a required complete-case field.", call. = FALSE)
  }
  keep <- stats::complete.cases(raw[required])
  ever <- suppressWarnings(as.numeric(as.character(raw$smoke_ever_w1)))
  now <- suppressWarnings(as.numeric(as.character(raw$smoke_now_w1)))
  keep <- keep & ever %in% 0:1 & now %in% 0:1 & !(ever == 0 & now == 1)
  ids <- as.character(raw$participant_id[keep])
  if (!length(ids) || anyNA(ids) || anyDuplicated(ids)) {
    stop("The frozen complete-case ID set is invalid.", call. = FALSE)
  }
  ids
}

v461_domain_periods <- function(person, context, complete_case_ids) {
  adjacent <- v45c_build_period(
    person, context$ledger, context$actual,
    rep(TRUE, nrow(person)), adjacent = TRUE
  )
  cc_member <- as.character(person$participant_id) %in% complete_case_ids
  boundary_member <- !as.logical(person$pef_w1_boundary_any)
  strict_member <- as.logical(person$pef_w1_strict_protocol) &
    as.integer(person$pef_w1_valid_n) >= 2L
  if (anyNA(cc_member) || anyNA(boundary_member) || anyNA(strict_member)) {
    stop("A V46.1 domain mask contains missing membership.", call. = FALSE)
  }
  list(
    primary = adjacent,
    complete_case = adjacent[
      adjacent$participant_id %in% person$participant_id[cc_member],
      , drop = FALSE
    ],
    boundary_excluded = adjacent[
      adjacent$participant_id %in% person$participant_id[boundary_member],
      , drop = FALSE
    ],
    strict_measurement = adjacent[
      adjacent$participant_id %in% person$participant_id[strict_member],
      , drop = FALSE
    ]
  )
}

v461_anchor_row <- function(period, sample_id) {
  if (!is.data.frame(period) || !nrow(period)) {
    stop(sample_id, " has no person-period rows.", call. = FALSE)
  }
  psu <- length(unique(as.character(period$community_id)))
  data.frame(
    sample_id = sample_id,
    n = length(unique(as.character(period$participant_id))),
    deaths = sum(as.integer(period$period_event) == 1L),
    period_rows = nrow(period),
    nominal_person_years = sum(as.numeric(period$nominal_years)),
    psu = psu,
    dfcom = psu - 1L,
    stringsAsFactors = FALSE
  )
}

v461_matrix_audit <- function(period, formula, sample_id, imputation) {
  frame <- stats::model.frame(
    formula, data = period, na.action = stats::na.fail
  )
  matrix <- stats::model.matrix(
    stats::delete.response(stats::terms(formula)), data = frame
  )
  rank <- qr(matrix)$rank
  data.frame(
    sample_id = sample_id,
    imputation = as.integer(imputation),
    rows = nrow(matrix),
    columns = ncol(matrix),
    rank = rank,
    full_rank = identical(as.integer(rank), as.integer(ncol(matrix))),
    finite = all(is.finite(matrix)),
    stringsAsFactors = FALSE
  )
}

v461_observation_membership <- function(context) {
  skeleton <- as.data.frame(
    context$ledger$person_period_skeleton, stringsAsFactors = FALSE
  )
  key_map <- as.data.frame(
    context$actual$outcome_free_period_key_map,
    stringsAsFactors = FALSE
  )
  key <- paste(
    skeleton$participant_id, skeleton$start_wave, skeleton$end_wave,
    sep = "\u241f"
  )
  frozen_key <- paste(
    key_map$participant_id, key_map$start_wave, key_map$end_wave,
    sep = "\u241f"
  )
  if (anyDuplicated(key) || anyDuplicated(frozen_key) ||
      !identical(key, frozen_key)) {
    stop("Observation-path key binding failed.", call. = FALSE)
  }
  adjacent <- as.logical(key_map$adjacent_transition)
  if (anyNA(adjacent)) {
    stop("Observation-path adjacency flag is incomplete.", call. = FALSE)
  }
  internal <- data.frame(
    participant_id = as.character(skeleton$participant_id),
    adjacent = adjacent,
    nonconsecutive = !adjacent,
    period_event = as.integer(skeleton$period_event),
    nominal_years = as.numeric(skeleton$nominal_years),
    stringsAsFactors = FALSE
  )
  split_rows <- split(internal, internal$participant_id)
  participant <- do.call(rbind, lapply(split_rows, function(x) {
    data.frame(
      participant_id = x$participant_id[[1L]],
      has_adjacent = any(x$adjacent),
      has_nonconsecutive = any(x$nonconsecutive),
      adjacent_rows = sum(x$adjacent),
      nonconsecutive_rows = sum(x$nonconsecutive),
      adjacent_deaths = sum(x$period_event[x$adjacent] == 1L),
      nonconsecutive_deaths =
        sum(x$period_event[x$nonconsecutive] == 1L),
      adjacent_years = sum(x$nominal_years[x$adjacent]),
      nonconsecutive_years = sum(x$nominal_years[x$nonconsecutive]),
      stringsAsFactors = FALSE
    )
  }))
  rownames(participant) <- NULL
  participant$adjacent_contributor <- participant$has_adjacent
  participant$nonconsecutive_only <-
    participant$has_nonconsecutive & !participant$has_adjacent
  participant$mixed_path <-
    participant$has_nonconsecutive & participant$has_adjacent
  if (anyNA(participant[c(
    "adjacent_contributor", "nonconsecutive_only", "mixed_path"
  )]) || anyDuplicated(participant$participant_id)) {
    stop("Observation contributor groups are invalid.", call. = FALSE)
  }
  participant
}

v461_observation_count_rows <- function(membership) {
  definitions <- list(
    adjacent_contributors = membership$adjacent_contributor,
    nonconsecutive_only_contributors = membership$nonconsecutive_only,
    mixed_path_contributors = membership$mixed_path,
    any_nonconsecutive_contributors = membership$has_nonconsecutive
  )
  do.call(rbind, lapply(names(definitions), function(group_id) {
    use <- definitions[[group_id]] %in% TRUE
    data.frame(
      group_id = group_id,
      participants = sum(use),
      adjacent_rows = sum(membership$adjacent_rows[use]),
      nonconsecutive_rows = sum(membership$nonconsecutive_rows[use]),
      adjacent_deaths = sum(membership$adjacent_deaths[use]),
      nonconsecutive_deaths =
        sum(membership$nonconsecutive_deaths[use]),
      adjacent_nominal_person_years =
        sum(membership$adjacent_years[use]),
      nonconsecutive_nominal_person_years =
        sum(membership$nonconsecutive_years[use]),
      stringsAsFactors = FALSE
    )
  }))
}

v461_weighted_moments <- function(value, weight) {
  value <- as.numeric(value)
  weight <- as.numeric(weight)
  keep <- is.finite(value) & is.finite(weight) & weight > 0
  if (sum(keep) < 2L) {
    stop("Weighted summary has insufficient support.", call. = FALSE)
  }
  value <- value[keep]
  weight <- weight[keep]
  mean <- sum(weight * value) / sum(weight)
  variance <- sum(weight * (value - mean)^2) / sum(weight)
  c(mean = mean, variance = variance)
}

v461_profile_one_imputation <- function(person, membership, imputation) {
  index <- match(person$participant_id, membership$participant_id)
  if (anyNA(index)) {
    stop("Observation profile join failed.", call. = FALSE)
  }
  group_a <- membership$adjacent_contributor[index]
  group_b <- membership$nonconsecutive_only[index]
  if (sum(group_a) < 100L || sum(group_b) < 20L || any(group_a & group_b)) {
    stop("Observation profile groups lack expected support.", call. = FALSE)
  }
  numeric_factor <- function(x) suppressWarnings(as.numeric(as.character(x)))
  variables <- list(
    age_years = list(value = person$age_w1, type = "continuous"),
    female = list(value = numeric_factor(person$sex_code) == 2, type = "binary"),
    rural_residence = list(
      value = numeric_factor(person$h1rural) == 1, type = "binary"
    ),
    current_smoking = list(
      value = as.character(person$smoking_status_3) == "current",
      type = "binary"
    ),
    less_than_lower_secondary = list(
      value = numeric_factor(person$raeducl) == 1, type = "binary"
    ),
    bmi_kg_m2 = list(value = person$bmi_w1, type = "continuous"),
    lower_pef_sd = list(value = person$E0, type = "continuous"),
    chronic_lung_disease = list(value = person$lung_w1, type = "binary"),
    asthma = list(value = person$asthma_w1, type = "binary"),
    frailty_proxy_count = list(
      value = person$frailty_proxy_count_w1, type = "continuous"
    )
  )
  rows <- lapply(names(variables), function(variable_id) {
    definition <- variables[[variable_id]]
    value <- as.numeric(definition$value)
    a <- v461_weighted_moments(
      value[group_a], person$weight_biomarker_w1[group_a]
    )
    b <- v461_weighted_moments(
      value[group_b], person$weight_biomarker_w1[group_b]
    )
    denominator <- sqrt((a[["variance"]] + b[["variance"]]) / 2)
    smd <- if (is.finite(denominator) && denominator > 0) {
      (a[["mean"]] - b[["mean"]]) / denominator
    } else {
      NA_real_
    }
    data.frame(
      imputation = as.integer(imputation),
      variable_id = variable_id,
      variable_type = definition$type,
      adjacent_estimate = a[["mean"]],
      nonconsecutive_only_estimate = b[["mean"]],
      standardized_mean_difference = smd,
      stringsAsFactors = FALSE
    )
  })
  do.call(rbind, rows)
}

