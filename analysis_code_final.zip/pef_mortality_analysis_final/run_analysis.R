#!/usr/bin/env Rscript
# Single entry point for the final PEF mortality analysis workflow.
#
# Public files use functional module names. During execution only, this script
# creates byte-identical compatibility copies at the original provenance paths
# required by the frozen validation gates. Those temporary copies are removed
# on exit; scientific code and specifications are not rewritten.

sha256_file <- function(path) {
  unname(tools::md5sum(path)) # availability check before SHA-256 below
  if (!requireNamespace("digest", quietly = TRUE)) {
    stop("Package 'digest' is required.", call. = FALSE)
  }
  digest::digest(file = path, algo = "sha256", serialize = FALSE)
}

script_arg <- grep("^--file=", commandArgs(FALSE), value = TRUE)
if (length(script_arg) != 1L) {
  stop("Run with Rscript: Rscript --vanilla run_analysis.R", call. = FALSE)
}
root <- normalizePath(
  dirname(sub("^--file=", "", script_arg)),
  winslash = "/",
  mustWork = TRUE
)

mappings <- do.call(rbind, list(
    c("R/lib/07_nhanes_gli_lln_prism_lock.R", "R/nhanes/07_nhanes_v0_5_gli_lln_prism_lock.R", "d14f7ef67af044056531e9faeb8aa76c2fbde3ca70a66eb6695b124da5093787"),
    c("R/01_cohort/00_freeze_and_manifest.R", "R/v43/00_freeze_and_manifest.R", "f44dfd0c0af747ecf1217ee4c30f7d8d2b2cf71906f38dd02a82f7b3d7c30e4b"),
    c("R/01_cohort/01_charls_stage1_2_flow_measurement_audit.R", "R/v43/01_charls_stage1_2_flow_measurement_audit.R", "c8eb471011c9ad8e41058eae4bce1aa76ba086bdb70b7c76549a0ef76200b101"),
    c("R/01_cohort/02_nhanes_stage1_2_flow_measurement_audit.R", "R/v43/02_nhanes_stage1_2_flow_measurement_audit.R", "160b38c99c58586fc36bfcd5b5cc52bebfbcc1509c1abc75b01952068c7e4d47"),
    c("R/01_cohort/03_validate_stage0_2.R", "R/v43/03_validate_stage0_2.R", "1dd78ef6ff190e0dc9766137e92c1967424e28f486661f1a3af22e1c3b2f45ec"),
    c("R/01_cohort/03b_stage3_preflight.R", "R/v43/03b_stage3_preflight.R", "2adaaf0b2faa43371c52a825638e9c6f303bae0afe1cb1f5b483acbf4c38cd4c"),
    c("R/01_cohort/04_charls_stage3_primary_mortality.R", "R/v43/04_charls_stage3_primary_mortality.R", "bc759aab44691deb5a920a4017c7b51bfe7c5694959b27ae9aa95462fba5908d"),
    c("R/01_cohort/05_nhanes_stage3_primary_mortality.R", "R/v43/05_nhanes_stage3_primary_mortality.R", "fe3c13c9fda0c9036765cd7440c6c2aa43d0498cedc2c988e3b0806a8215e8b5"),
    c("R/01_cohort/06_finalize_stage3_outputs.R", "R/v43/06_finalize_stage3_outputs.R", "cd92bde4ac894ae4a18a746a57073038402c2e68e25f433ce38bb44e2a11908d"),
    c("R/02_anthropometry/05_charls_anthropometric_qc_resolution.R", "R/v44/05_charls_anthropometric_qc_resolution_v44_1_1.R", "b728c35e7c9f648afe0622c7b94ddf1ec6e4cf3850274b661a7bb5afd549097f"),
    c("R/02_anthropometry/06_baseline_characteristics.R", "R/v44/06_baseline_characteristics_v44_2.R", "2cc5de83863791cf4de338e9d8176accd1c9cd30aed80e47308c925f004f4e7a"),
    c("R/03_nhanes/00_freeze_and_manifest.R", "R/v45/00_freeze_and_manifest_v45.R", "8d48ba16fa29aae939157dc87b741c6352aedc5dba0fae2e5fc8d1f1bd224df1"),
    c("R/03_nhanes/01_nhanes_common_utilities.R", "R/v45/01_nhanes_common_utilities_v45.R", "5dd8519d0236c57b2cda97393d2543494afbec286d8433ab7b75ae5ebe32e8b4"),
    c("R/03_nhanes/02_gli_functions.R", "R/v45/02_gli_functions_v45.R", "ff5d1526dc504858895fd40d9ea44be7894830745ed61071e739b039c52cdf66"),
    c("R/03_nhanes/03_nhanes_mi_preflight.R", "R/v45/03_nhanes_mi_preflight_v45.R", "102eac9a19db52c8973b8970b7653852c06b82cba5f143ba42b8791f5e86c0b4"),
    c("R/03_nhanes/04_validate_structural_preflight.R", "R/v45/04_validate_structural_preflight_v45.R", "50b291596979587d1bc784d6a2d3bc08c89c1e202664d92f1d5fff0ec4993b24"),
    c("R/03_nhanes/05_freeze_rao_wu_preflight.R", "R/v45/05_freeze_rao_wu_preflight_v45.R", "eaa76313aaf58b2e638e8336c34fe7462f044422eaa08fe2c107aabac44c44fa"),
    c("R/03_nhanes/06_rao_wu_replicate_preflight.R", "R/v45/06_rao_wu_replicate_preflight_v45.R", "e3cb03601411f558e2081775f72805ff1ed6d9763a8764f2f6abac0789d91e59"),
    c("R/03_nhanes/07_validate_rao_wu_replicate_preflight.R", "R/v45/07_validate_rao_wu_replicate_preflight_v45.R", "57cdd89d11eb6f5effc4a0b0843d904480b2f41cfcbef0bbc453b322abf31b92"),
    c("R/03_nhanes/08_freeze_production_mi.R", "R/v45/08_freeze_production_mi_v45.R", "a224f520cd31321668c8bd33db8f498d324b77e5d8f94bed026092b1259b0ba1"),
    c("R/03_nhanes/09_run_production_mi.R", "R/v45/09_run_production_mi_v45.R", "a79738537c1494003f1c3889477dc2058b44e46b99d030e1ae14b1368b069f35"),
    c("R/03_nhanes/10_validate_production_mi.R", "R/v45/10_validate_production_mi_v45.R", "46acc1dccb8b88642932732e01bfba1b2d18e9d8d87e6d33abe35c7c698066dd"),
    c("R/03_nhanes/11_nhanes_outcome_utilities.R", "R/v45/11_nhanes_outcome_utilities_v45.R", "24339325545eed72643a7cd2329796dafa2a4930c183104426eacad04de48dc8"),
    c("R/03_nhanes/12_freeze_nhanes_outcome_execution.R", "R/v45/12_freeze_nhanes_outcome_execution_v45.R", "596159e3bd43a0549027d827d16f3e80c8fdc9ac13f87b0fd9bd34a2a412e399"),
    c("R/03_nhanes/13_run_nhanes_outcome_execution.R", "R/v45/13_run_nhanes_outcome_execution_v45.R", "38d132eec08c2d10d1e71076d50277cdfd68da5aa9e90c8f335f30bb754789d8"),
    c("R/03_nhanes/14_validate_nhanes_outcome_execution.R", "R/v45/14_validate_nhanes_outcome_execution_v45.R", "788e8a499592d579accddba13505eba582371bd518653a75b15a7406238a76ae"),
    c("R/03_nhanes/15_nhanes_outcome_diagnostics_utilities.R", "R/v45/15_nhanes_outcome_diagnostics_utilities_v45.R", "e46673a31e5892dc4f2fbd4779d0acaa9185169c2dfa5ba91d9e291622951903"),
    c("R/03_nhanes/16_freeze_nhanes_outcome_diagnostics.R", "R/v45/16_freeze_nhanes_outcome_diagnostics_v45.R", "8e2d0dfa0663e7c90e441fa26d1a04fcb6f2cbb563c3b9d95b1b8fc15b18df37"),
    c("R/03_nhanes/17_run_nhanes_outcome_diagnostics.R", "R/v45/17_run_nhanes_outcome_diagnostics_v45.R", "e95cb116484986339c043a78a624712f08b993132e3f77427e6573afc9a3b89f"),
    c("R/03_nhanes/18_validate_nhanes_outcome_diagnostics.R", "R/v45/18_validate_nhanes_outcome_diagnostics_v45.R", "ee557fdcf52c1570075581d49f296efe759eec01a3aa2a67281ad4cc7b05126b"),
    c("R/04_charls/00_freeze_charls_pure_preflight.R", "R/v45/charls_addendum_v45_1/00_freeze_charls_pure_preflight_v45_1.R", "6e9b5330241bd61e3fe1f82a97fd16df011c36dc744d98db10597003942f07de"),
    c("R/04_charls/01_run_charls_structural_preflight.R", "R/v45/charls_addendum_v45_1/01_run_charls_structural_preflight_v45_1.R", "02fac0d70a5dd41c74f11e92a0a1d775f3ce54dff827d0fdf7a94060ad82bfe7"),
    c("R/04_charls/02_validate_charls_structural_preflight.R", "R/v45/charls_addendum_v45_1/02_validate_charls_structural_preflight_v45_1.R", "bc32807ab0504c0d48556bbc0739f1f9ad646831d4ddee4863635f0becadaced"),
    c("R/04_charls/03_charls_actual_keys_mi_utilities.R", "R/v45/charls_addendum_v45_1/03_charls_actual_keys_mi_utilities_v45_1.R", "72e51114db692d306ee84a4c3fb8f80628af0a2d93abfc48340fddd657b52afb"),
    c("R/04_charls/04_freeze_charls_actual_keys_mi.R", "R/v45/charls_addendum_v45_1/04_freeze_charls_actual_keys_mi_v45_1.R", "468770eb0a1bff3c07361b06fd78aa103f4d579e09cec8faf50fc2867c3a4e4b"),
    c("R/04_charls/05_run_charls_actual_keys_mi_preflight.R", "R/v45/charls_addendum_v45_1/05_run_charls_actual_keys_mi_preflight_v45_1.R", "28026d67a8cd4d2f3c34830ecc1c5875f73707a2a652154f40029aa5d1ca8c6a"),
    c("R/04_charls/06_validate_charls_actual_keys_mi_preflight.R", "R/v45/charls_addendum_v45_1/06_validate_charls_actual_keys_mi_preflight_v45_1.R", "88f6d6d855be501ebc5a28d73ea2b790c7fca45897b103c1bba358b283e61e29"),
    c("R/04_charls/07_charls_production_mi_utilities.R", "R/v45/charls_addendum_v45_1/07_charls_production_mi_utilities_v45_1.R", "7e8a701cd9af6ee2cd2e62daf048f1247469feb88c36019797b771817915e856"),
    c("R/04_charls/08_freeze_charls_production_mi.R", "R/v45/charls_addendum_v45_1/08_freeze_charls_production_mi_v45_1.R", "591baee606e0433ee8d491c9e9174c7ed5e278526728aac6328127141f4a0c58"),
    c("R/04_charls/09_run_charls_production_mi.R", "R/v45/charls_addendum_v45_1/09_run_charls_production_mi_v45_1.R", "ff27bc9e60963599e53fa2273ae4e2100fd45fc6c84677efbef6f70838208f70"),
    c("R/04_charls/10_validate_charls_production_mi.R", "R/v45/charls_addendum_v45_1/10_validate_charls_production_mi_v45_1.R", "ba1a0c0bcf2eaf4b42ee434d24742e153fc9eb7eb07db4303cbd93681a0f9d38"),
    c("R/04_charls/11_freeze_charls_outcome_execution.R", "R/v45/charls_addendum_v45_1/11_freeze_charls_outcome_execution_v45_1.R", "2f54545a8ef16431a0fd8852e88e7f1ffa2916e9a0a108747806b74a7c529ecc"),
    c("R/04_charls/12_run_charls_outcome_execution.R", "R/v45/charls_addendum_v45_1/12_run_charls_outcome_execution_v45_1.R", "070b5bb27e1877832dc0f6ea7adc2589be055952311e81e50946e5e125834f81"),
    c("R/04_charls/13_validate_charls_outcome_execution.R", "R/v45/charls_addendum_v45_1/13_validate_charls_outcome_execution_v45_1.R", "9e6dec26057f14afd6a42a91d50deef3f0efe4e9522d25a77b30612783eb0dfa"),
    c("R/04_charls/charls_outcome_utilities.R", "R/v45/charls_addendum_v45_1/charls_outcome_utilities_v45_1.R", "7e0c3630deb953d50080236f6b40d7e0ecd58a090379a3e1287d780ab96b0795"),
    c("R/04_charls/charls_pure_functions.R", "R/v45/charls_addendum_v45_1/charls_pure_functions_v45_1.R", "963cb58df0efa69383aba2c5c08001f1ce64abe358766779efb0f7339b214adf"),
    c("R/04_charls/charls_structural_utilities.R", "R/v45/charls_addendum_v45_1/charls_structural_utilities_v45_1.R", "dc6eccd8876b20ef3abf98ef137a31d09f62c21ca0c1ea7a5d73b3cce17f2e7d"),
    c("R/03_nhanes/independent_mi_validation_helpers.R", "R/v45/independent_mi_validation_helpers_v45.R", "07af7cff0ff2209c1b48c03705f97ec79ae769e31f57f763de1cbb4815e6f59f"),
    c("R/03_nhanes/legacy_gli_reference_pure.R", "R/v45/legacy_gli_reference_pure_v45.R", "005fa83d670c90ca360deb4048c12e64afeabc59d2c5a7157f2a8f87f081bb31"),
    c("R/03_nhanes/production_mi_hashes.R", "R/v45/production_mi_hashes_v45.R", "3800432a66c2702c26def38e1d14657dc2eb81e6089a90b756668b08bc70e253"),
    c("R/05_diagnostics/01_run_reviewer_addendum.R", "R/v45_3/01_run_reviewer_addendum_v45_3.R", "c6239d227676f16b5dd0ca8986061f3def4437d9804709be0cb18c36785f99eb"),
    c("R/05_diagnostics/02_validate_reviewer_addendum.R", "R/v45_3/02_validate_reviewer_addendum_v45_3.R", "600975681c9a43aaa55bd25cc494fcebc87766047edddc853e9ce24074c7543b"),
    c("R/06_sensitivity/00_preflight_review_addendum.R", "R/v45_7/00_preflight_review_addendum_v45_7.R", "8045c1561ee204a5c9f55ee46cae9895c0a2157a84dce9dfac0f4c4bf4724db4"),
    c("R/06_sensitivity/01_run_review_outcome.R", "R/v45_7/01_run_review_outcome_v45_7.R", "2d49d6d092f491f4d8ead3b17112a4ed131abba1d2eac94463f4246b8fdc5488"),
    c("R/06_sensitivity/02_validate_review_outcome.R", "R/v45_7/02_validate_review_outcome_v45_7.R", "1d409950843f54b4d05c8f9a46f75deacf8b620d0c9dd5fba2802df4eb4a6463"),
    c("R/07_validation/01_existing_analysis_specification_audit.R", "R/v45_8/01_existing_analysis_specification_audit_v45_8.R", "be48869d6f3c9c1306c2da50a0335a964fd631de83a2e3d8d228c1009f19ef92"),
    c("protocol/analysis_plan.md", "protocol/pef_mortality_analysis_plan_v45_7_review_addendum.md", "e190e0b30b9f9fd69bf854a74c7d81b93e85119d3e57ab8926e9d732b67cc6ad"),
    c("expected_results/01_primary/charls_outcome_independent_validation.tsv", "validation_targets/v45/charls_outcome_independent_validation_v45_1.tsv", "04f329ceb746d1a316e3c14feb19ecd49e8e7c95c4c6902d97ef19473686cc51"),
    c("expected_results/01_primary/charls_outcome_released_results.tsv", "validation_targets/v45/charls_outcome_released_results_v45_1.tsv", "22d16e748bc64dfc25c5bb192c3e441ca5da9f36a782312c06d1d823bd3f72bf"),
    c("expected_results/01_primary/nhanes_released_results.tsv", "validation_targets/v45/v45_nhanes_released_results.tsv", "7221324e9cb3fd41d8df292b98cb927aec70c69a50cd7d726928483ac30752e8"),
    c("expected_results/01_primary/stage4_independent_validation.tsv", "validation_targets/v45/v45_stage4_independent_validation.tsv", "00ce4da9dbd66c7037503739c4f29156e28b3a6774b727d94a87f411109318af"),
    c("expected_results/02_sensitivity/independent_validation.tsv", "validation_targets/v45_7/v45_7_independent_validation.tsv", "41347f8d97ceeec3b3f3ec14adf5433662ae6f4f75748a44ff64fce1cf934ae1"),
    c("expected_results/02_sensitivity/nhanes_gli_a2_sensitivity.tsv", "validation_targets/v45_7/v45_7_nhanes_gli_a2_sensitivity.tsv", "4ff783d74d1d722bd176e02893646ebdaf59d0b1ca66e1f5b1c8a764d1f58fa8"),
    c("expected_results/03_specification_audit/charls_transition_counts.tsv", "validation_targets/v45_8/v45_8_charls_transition_counts.tsv", "f367b907346ebcfc6120ab98f87abb74efb855d8188e99e5147f8382df6a6320"),
    c("expected_results/03_specification_audit/mi_method_visit_specification.tsv", "validation_targets/v45_8/v45_8_mi_method_visit_specification.tsv", "e507bf0e39453fac7880a167497a7d5b75566f0318de88f665e1f1f2db024a2a"),
    c("expected_results/03_specification_audit/mi_object_summary.tsv", "validation_targets/v45_8/v45_8_mi_object_summary.tsv", "3daab62db965f033807def04f235dafdf137999c17dc86c824747a8ed29399d2"),
    c("expected_results/03_specification_audit/mi_predictor_matrix_long.tsv", "validation_targets/v45_8/v45_8_mi_predictor_matrix_long.tsv", "4ee3f766e2a0be513c24b5c7ad4920392660136b09663295e7c796220ab4a6aa"),
    c("expected_results/03_specification_audit/nhanes_combined_weight_distribution.tsv", "validation_targets/v45_8/v45_8_nhanes_combined_weight_distribution.tsv", "6a2d9d3fe78c861fb99ad3bed6f8b677ac21c5256ef871ff7a569540e94db1c0"),
    c("expected_results/03_specification_audit/nhanes_combined_weight_summary.tsv", "validation_targets/v45_8/v45_8_nhanes_combined_weight_summary.tsv", "1d37c3434a433ae5302a7d4e11da660109c9e07a892aedd83ec241b99e487a6a"),
    c("expected_results/03_specification_audit/specification_audit_manifest.tsv", "validation_targets/v45_8/v45_8_specification_audit_manifest.tsv", "f988cafac0cb5974478ab8c392a1016a00ef252a4b44a7e296e9b1441ffd65dd"),
    c("specs/01_cohort/DESCRIPTION", "work_v43/DESCRIPTION", "8475bed2fe153e0c04b55ddef25d94e716849d0fb2a9d8e77d9978cd45dfbb05"),
    c("LICENSE", "work_v43/LICENSE", "6d9cac1d2d94243a1935b61fe4e7b55370df44922ff2e74f9d59085788c90717"),
    c("specs/01_cohort/analysis_spec.yml", "work_v43/analysis_spec_v43.yml", "6b68ad9ac9b361228337f29b336e4d704b9184cf21b744b2d703754940b05ab2"),
    c("specs/01_cohort/output_contract.yml", "work_v43/output_contract_v43.yml", "186058b782827cbc0d5f43338f0f47f565204ea50131b054feed2ecdf6324786"),
    c("specs/01_cohort/registry_schema.csv", "work_v43/registry_schema_v43.csv", "79e2c4f35742627d81ed748585e9a0395830dd053ddc006a551be6fd98538673"),
    c("environment/renv.lock", "work_v43/renv.lock", "2b7e7dab37e1598634e2a2300d2a496b165eeccaee1e76db8677814a296d2674"),
    c("specs/01_cohort/seed_ledger.csv", "work_v43/seed_ledger_v43.csv", "7f2da74c76f9db8dc05c1cacf5d053029bd208f7e475b1eb68b4c831cef7cc40"),
    c("specs/02_anthropometry/baseline_characteristics_contract.yml", "work_v44/baseline_characteristics_contract_v44_2.yml", "a44bf87dc44dde4023da67cbb1b76b144a620e48eef6c6a445bedf4b8b0fa011"),
    c("specs/02_anthropometry/baseline_characteristics_spec.yml", "work_v44/baseline_characteristics_spec_v44_2.yml", "06612686f8a08cde4db6a019ecae45c4349bd1ab9b67d9f786fa4b50009c0a12"),
    c("specs/02_anthropometry/charls_anthropometric_qc_resolution_contract.yml", "work_v44/charls_anthropometric_qc_resolution_contract_v44_1_1.yml", "ce313ec66151b57f278ce1d747051591b83d0f1cab87e95264733b3b34cca586"),
    c("specs/02_anthropometry/charls_anthropometric_qc_resolution_seed_ledger.csv", "work_v44/charls_anthropometric_qc_resolution_seed_ledger_v44_1_1.csv", "f7483f274d7235151de96648c2de479b66b758c8158e190e4cc869e2cad9d46e"),
    c("specs/02_anthropometry/charls_anthropometric_qc_resolution_spec.yml", "work_v44/charls_anthropometric_qc_resolution_spec_v44_1_1.yml", "d9abf65d03f889c60b8ada3a8c1da225d2c0be478ea2d316d01c893ddcf269b1"),
    c("specs/03_nhanes/analysis_spec.yml", "work_v45/analysis_spec_v45.yml", "af3ba4c03efa57517a1882f17319d1d1f9bdc5b2c2d27f74d603213d4a0279ec"),
    c("specs/04_charls/analysis_registry_addendum.tsv", "work_v45/charls_addendum_v45_1/analysis_registry_addendum_v45_1.tsv", "49040f47923095107346b06cc62e28487335f94a50da0589edba208162f7c413"),
    c("specs/04_charls/charls_actual_keys_mi_gate_state.yml", "work_v45/charls_addendum_v45_1/charls_actual_keys_mi_gate_state_v45_1.yml", "52a34caba6bcc83d51636c2d9ee3c3416e3f86b155dc0e79b3cf70982a0b0a21"),
    c("specs/04_charls/charls_actual_keys_mi_spec.yml", "work_v45/charls_addendum_v45_1/charls_actual_keys_mi_spec_v45_1.yml", "c21a59d9f1b22f14561f889e5062c492e6a94d1a547eed2b263ca567645cbd34"),
    c("specs/04_charls/charls_addendum_gate_state.yml", "work_v45/charls_addendum_v45_1/charls_addendum_gate_state_v45_1.yml", "6ab28d84a73811ba74c58da59ea902d6eee0204e3ae2daa35acc7fab7abf3081"),
    c("specs/04_charls/charls_addendum_spec.yml", "work_v45/charls_addendum_v45_1/charls_addendum_spec_v45_1.yml", "08b0a7558e7f5587f86816aa1a78714a70512df0b203709e37190a2245548797"),
    c("specs/04_charls/charls_outcome_analysis_crosswalk.tsv", "work_v45/charls_addendum_v45_1/charls_outcome_analysis_crosswalk_v45_1.tsv", "b64e868e5235ffe8e7af3def2409385921627ceb4a03b27595ad1ea35206cd7d"),
    c("specs/04_charls/charls_outcome_anchor_registry.tsv", "work_v45/charls_addendum_v45_1/charls_outcome_anchor_registry_v45_1.tsv", "638866007bc063b6a6c93f2f995ebf662d0feefebca363a1b7e30eb6c57e13c8"),
    c("specs/04_charls/charls_outcome_execution_gate_state.yml", "work_v45/charls_addendum_v45_1/charls_outcome_execution_gate_state_v45_1.yml", "852271fc9b07bf90f360f89e0f2bb2b960b44d45f5038eaf39f1730da608ad99"),
    c("specs/04_charls/charls_outcome_execution_spec.yml", "work_v45/charls_addendum_v45_1/charls_outcome_execution_spec_v45_1.yml", "8f97ea7e55f6af921e9cc739d109a6924dad070f418a00ab9464fca0f40a35c6"),
    c("specs/04_charls/charls_outcome_model_registry.tsv", "work_v45/charls_addendum_v45_1/charls_outcome_model_registry_v45_1.tsv", "7af5937ae0a1a2a8972e89df0d5c4d7dcf5e0262984e927bb1c704010272dede"),
    c("specs/04_charls/charls_outcome_threshold_registry.tsv", "work_v45/charls_addendum_v45_1/charls_outcome_threshold_registry_v45_1.tsv", "d8ad807adec1996ee4876a978bfaa90cb1a7e721cb4ac3e9da9121104a47924c"),
    c("specs/04_charls/charls_production_mi_gate_state.yml", "work_v45/charls_addendum_v45_1/charls_production_mi_gate_state_v45_1.yml", "1fb2b60808201f143f7ad2698bd08afaf6bd0aef30be7839a14f21ce62a12a4c"),
    c("specs/04_charls/charls_production_mi_spec.yml", "work_v45/charls_addendum_v45_1/charls_production_mi_spec_v45_1.yml", "ae6655667b66b739964e93160b81653d1b3b7aad5031f6b9a259286278024450"),
    c("specs/04_charls/charls_pure_preflight_spec.yml", "work_v45/charls_addendum_v45_1/charls_pure_preflight_spec_v45_1.yml", "d89371b52643671a0c61003f81d82b162dcdbd4eefc17b91c6010a1a880b38a4"),
    c("specs/04_charls/estimand_registry_addendum.tsv", "work_v45/charls_addendum_v45_1/estimand_registry_addendum_v45_1.tsv", "5f5dcb481aa9298f93c2ee3e9733b06f313a0e67a02f2c9d8c84bc877e0ae5ef"),
    c("specs/04_charls/input_addendum_manifest.tsv", "work_v45/charls_addendum_v45_1/input_addendum_manifest_v45_1.tsv", "3aaf19a21f4f15b4626d51cc94dddaf2902ca57dbd7fcbcb7d4afae5d5d4493f"),
    c("specs/04_charls/seed_addendum.tsv", "work_v45/charls_addendum_v45_1/seed_addendum_v45_1.tsv", "a2467b4fb5c2352ded1601e233c486843e9bd265ae8a005d2a85f217333c5cc9"),
    c("specs/03_nhanes/gate_state.yml", "work_v45/gate_state_v45.yml", "8953d492594b4c414e8c0e12d6b457eabbe42d71ec6612639957e2e903a3b45a"),
    c("specs/03_nhanes/outcome_diagnostics_spec.yml", "work_v45/outcome_diagnostics_spec_v45.yml", "2f29492cc349902a03942e6d8564b6ba7adfea489e4ba702cac57481ca1e11c4"),
    c("specs/03_nhanes/outcome_execution_spec.yml", "work_v45/outcome_execution_spec_v45.yml", "e760b516cb0032b7a2036c5f98169d52f5f4d2a2208355d931e2585472bbfacc"),
    c("specs/03_nhanes/production_mi_spec.yml", "work_v45/production_mi_spec_v45.yml", "8bcfea5fd81db445cdc5883a0b399697ff8e59f7e8b0c4dac5f1b6f30070bb37"),
    c("specs/03_nhanes/rao_wu_preflight_spec.yml", "work_v45/rao_wu_preflight_spec_v45.yml", "a58bba4be098b651962c1d511404b2c4a1a3b348220046d4899008abfd52e404"),
    c("specs/03_nhanes/analysis_registry.tsv", "work_v45/v45_analysis_registry.tsv", "481371d2a78e9807a5c9bcaee52e94a327209b00d2a7747e48c6822432cb408e"),
    c("specs/03_nhanes/estimand_registry.tsv", "work_v45/v45_estimand_registry.tsv", "db5776accbf68c742ba30d67c95598f36418bdb51a761d03bac64442097825e8"),
    c("specs/03_nhanes/fatal_warning_whitelist.yml", "work_v45/v45_fatal_warning_whitelist.yml", "75408bc0372f04986db534a85a24df18272c193c1d76115f5c77294831de9df1"),
    c("specs/03_nhanes/input_manifest_public.tsv", "work_v45/v45_input_manifest_public.tsv", "2c5dbcfc5272222ab9b367d3609bc7780772d418d8badd132c564a40b2291adf"),
    c("specs/03_nhanes/outcome_model_registry.tsv", "work_v45/v45_outcome_model_registry.tsv", "8c57caef9071e337465e918e506a67061186248ecf45735048fc7e869e2a691c"),
    c("specs/03_nhanes/outcome_threshold_registry.tsv", "work_v45/v45_outcome_threshold_registry.tsv", "951df90ac6aa46443aecaac06f51b45fe83e8d301802afe66aab2ca47d173796"),
    c("specs/03_nhanes/reporting_authority_index.yml", "work_v45/v45_reporting_authority_index.yml", "710fa018c602ca3b940318c5345aecfb640fa771e60267ca792af1955b4abc60"),
    c("specs/03_nhanes/seed_ledger.tsv", "work_v45/v45_seed_ledger.tsv", "ae9b6360333174d384c55791623646363b072d421b9f81a9a7dc690b2dd20af5")
))
colnames(mappings) <- c("source", "compatibility_path", "sha256")

commands <- c(
    "R/v43/00_freeze_and_manifest.R",
    "R/v43/01_charls_stage1_2_flow_measurement_audit.R",
    "R/v43/02_nhanes_stage1_2_flow_measurement_audit.R",
    "R/v43/03_validate_stage0_2.R",
    "R/v43/03b_stage3_preflight.R",
    "R/v43/04_charls_stage3_primary_mortality.R",
    "R/v43/05_nhanes_stage3_primary_mortality.R",
    "R/v43/06_finalize_stage3_outputs.R",
    "R/v44/05_charls_anthropometric_qc_resolution_v44_1_1.R",
    "R/v44/06_baseline_characteristics_v44_2.R",
    "R/v45/00_freeze_and_manifest_v45.R",
    "R/v45/01_nhanes_common_utilities_v45.R",
    "R/v45/02_gli_functions_v45.R",
    "R/v45/03_nhanes_mi_preflight_v45.R",
    "R/v45/04_validate_structural_preflight_v45.R",
    "R/v45/05_freeze_rao_wu_preflight_v45.R",
    "R/v45/06_rao_wu_replicate_preflight_v45.R",
    "R/v45/07_validate_rao_wu_replicate_preflight_v45.R",
    "R/v45/08_freeze_production_mi_v45.R",
    "R/v45/09_run_production_mi_v45.R",
    "R/v45/10_validate_production_mi_v45.R",
    "R/v45/11_nhanes_outcome_utilities_v45.R",
    "R/v45/12_freeze_nhanes_outcome_execution_v45.R",
    "R/v45/13_run_nhanes_outcome_execution_v45.R",
    "R/v45/14_validate_nhanes_outcome_execution_v45.R",
    "R/v45/15_nhanes_outcome_diagnostics_utilities_v45.R",
    "R/v45/16_freeze_nhanes_outcome_diagnostics_v45.R",
    "R/v45/17_run_nhanes_outcome_diagnostics_v45.R",
    "R/v45/18_validate_nhanes_outcome_diagnostics_v45.R",
    "R/v45/charls_addendum_v45_1/00_freeze_charls_pure_preflight_v45_1.R",
    "R/v45/charls_addendum_v45_1/01_run_charls_structural_preflight_v45_1.R",
    "R/v45/charls_addendum_v45_1/02_validate_charls_structural_preflight_v45_1.R",
    "R/v45/charls_addendum_v45_1/03_charls_actual_keys_mi_utilities_v45_1.R",
    "R/v45/charls_addendum_v45_1/04_freeze_charls_actual_keys_mi_v45_1.R",
    "R/v45/charls_addendum_v45_1/05_run_charls_actual_keys_mi_preflight_v45_1.R",
    "R/v45/charls_addendum_v45_1/06_validate_charls_actual_keys_mi_preflight_v45_1.R",
    "R/v45/charls_addendum_v45_1/07_charls_production_mi_utilities_v45_1.R",
    "R/v45/charls_addendum_v45_1/08_freeze_charls_production_mi_v45_1.R",
    "R/v45/charls_addendum_v45_1/09_run_charls_production_mi_v45_1.R",
    "R/v45/charls_addendum_v45_1/10_validate_charls_production_mi_v45_1.R",
    "R/v45/charls_addendum_v45_1/11_freeze_charls_outcome_execution_v45_1.R",
    "R/v45/charls_addendum_v45_1/12_run_charls_outcome_execution_v45_1.R",
    "R/v45/charls_addendum_v45_1/13_validate_charls_outcome_execution_v45_1.R",
    "R/v45_3/01_run_reviewer_addendum_v45_3.R",
    "R/v45_3/02_validate_reviewer_addendum_v45_3.R",
    "R/v45_7/00_preflight_review_addendum_v45_7.R",
    "R/v45_7/01_run_review_outcome_v45_7.R",
    "R/v45_7/02_validate_review_outcome_v45_7.R",
    "R/v45_8/01_existing_analysis_specification_audit_v45_8.R"
)

main <- function() {
  created <- character()
  created_dirs <- character()
  on.exit({
    for (path in rev(created)) {
      if (file.exists(path)) unlink(path, force = TRUE)
    }
    for (path in unique(rev(created_dirs))) {
      if (
        dir.exists(path)
        && length(list.files(path, all.files = TRUE, no.. = TRUE)) == 0L
      ) {
        unlink(path, recursive = TRUE, force = TRUE)
      }
    }
  }, add = TRUE)

  for (i in seq_len(nrow(mappings))) {
    source <- file.path(root, mappings[i, "source"])
    target <- file.path(root, mappings[i, "compatibility_path"])
    expected <- mappings[i, "sha256"]
    if (!file.exists(source) || sha256_file(source) != expected) {
      stop("Canonical source failed SHA-256 validation: ", source,
           call. = FALSE)
    }
    if (file.exists(target)) {
      if (sha256_file(target) != expected) {
        stop("Existing compatibility path has unexpected content: ", target,
             call. = FALSE)
      }
      next
    }
    parent <- dirname(target)
    probe <- parent
    new_parents <- character()
    while (!dir.exists(probe) && startsWith(probe, root)) {
      new_parents <- c(new_parents, probe)
      next_probe <- dirname(probe)
      if (identical(next_probe, probe)) break
      probe <- next_probe
    }
    dir.create(parent, recursive = TRUE, showWarnings = FALSE)
    created_dirs <- c(created_dirs, rev(new_parents))
    if (!file.copy(source, target, overwrite = FALSE, copy.mode = TRUE)) {
      stop("Could not create compatibility copy: ", target, call. = FALSE)
    }
    created <- c(created, target)
  }

  args <- commandArgs(trailingOnly = TRUE)
  if ("--prepare-only" %in% args) {
    message("FINAL COMPATIBILITY CHECK PASS")
    return(invisible(TRUE))
  }

  rscript <- file.path(R.home("bin"), "Rscript")
  for (relative in commands) {
    message("Running ", relative)
    status <- system2(
      rscript,
      c("--vanilla", shQuote(file.path(root, relative)))
    )
    if (!identical(status, 0L)) {
      stop("Analysis step failed: ", relative, call. = FALSE)
    }
  }
  message("FINAL ANALYSIS WORKFLOW PASS")
  invisible(TRUE)
}

status <- tryCatch(
  {
    main()
    0L
  },
  error = function(error) {
    message("FINAL ANALYSIS WORKFLOW FAILED: ", conditionMessage(error))
    1L
  }
)
quit(save = "no", status = status)
