# V46.0 analysis freeze record

Status at creation: **definitions frozen; V46 outcome coefficients not yet inspected**.

The governing protocol is `protocol/pef_mortality_analysis_plan_v46_0_revision.md`. Its SHA-256 and all executable-script hashes are captured by the structural preflight before any V46 outcome execution.

Locked decisions:

- V45.9 is immutable and remains the comparison baseline.
- CHARLS adjacent transitions are the V46 primary domain regardless of results.
- CHARLS all-window results are sensitivity results.
- CHARLS A1-E0 is primary; A0/A2, E0b, and spline analyses are supporting.
- NHANES A/B/C remains the original GLI common domain; A/B is a strict quality sensitivity.
- NHANES A/B separate and conditional A1 models use identical membership.
- No new database, outcome, exposure cutoff, machine-learning model, or cause-specific endpoint is introduced.
- Prefix gates are outcome-coefficient blind; public release requires independent aggregate validation.

The first permitted action after this record is an outcome-blind structural preflight. Any deviation requires a dated amendment written before examining the affected result.
