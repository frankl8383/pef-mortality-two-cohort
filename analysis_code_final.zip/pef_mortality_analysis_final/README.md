# PEF mortality analysis

This is the single final code release accompanying the CHARLS and NHANES
manuscript. It includes the V46.0 adjacent-window CHARLS primary analysis
and the NHANES A/B spirometry-quality sensitivity.

## Contents

- `R/01_cohort/`: 8 script(s)
- `R/02_anthropometry/`: 2 script(s)
- `R/03_nhanes/`: 22 script(s)
- `R/04_charls/`: 17 script(s)
- `R/05_diagnostics/`: 2 script(s)
- `R/06_sensitivity/`: 3 script(s)
- `R/07_validation/`: 1 script(s)
- `R/lib/`: 1 script(s)
- `specs/`: final machine-readable analysis specifications
- `expected_results/`: aggregate validation targets
- `environment/renv.lock`: R package snapshot
- `protocol/`: primary plan and the frozen V46.0 revision plan
- `R/v46/`: six V46.0 preflight, analysis, and validation scripts
- `expected_results/04_v46/`: aggregate V46.0 validation targets

The release contains no participant-level data, completed imputations, fitted
models, credentials, or restricted CHARLS files.

## Data

CHARLS files must be obtained by a registered user under the CHARLS data-use
terms. NHANES 2007--2012 public component files and 2019 public-use linked
mortality files must be downloaded from NCHS. Copy
`config/data_paths.example.yml` to `config/data_paths.yml` and enter local
authorized paths.

## Run

Use R 4.5.1 and restore `environment/renv.lock`, then run:

```bash
Rscript --vanilla run_analysis.R
```

The default entry point runs 49 ordered analysis and validation steps.
It creates temporary compatibility copies needed by the frozen provenance
checks and removes those copies on exit. The scientific R scripts and
specifications are byte-identical to the frozen manuscript analysis.

To rerun the added V46.0 analyses after the base workflow, use:

```bash
Rscript --vanilla run_analysis.R --include-v46
```

The public preflight omits only the author-side submission-ZIP checksum; all data, object, protocol, model-matrix, and sample/event gates are retained.

To verify the package layout without accessing participant data:

```bash
Rscript --vanilla run_analysis.R --prepare-only
```

Compare released aggregate outputs with `expected_results/`. Every public file
is covered by `SHA256SUMS.txt`.
