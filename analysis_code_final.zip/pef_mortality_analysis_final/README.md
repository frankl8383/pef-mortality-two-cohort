# PEF mortality analysis

This is the single final code release accompanying the CHARLS and NHANES
manuscript. The public tree is organized by analytic function, not by
development version.

## Contents

- `R/01_cohort/`: 8 script(s)
- `R/02_anthropometry/`: 2 script(s)
- `R/03_nhanes/`: 22 script(s)
- `R/04_charls/`: 17 script(s)
- `R/05_diagnostics/`: 2 script(s)
- `R/06_sensitivity/`: 3 script(s)
- `R/07_validation/`: 1 script(s)
- `R/lib/`: 1 script(s)
- `specs/`: final machine-readable analysis specifications
- `expected_results/`: aggregate validation targets
- `environment/renv.lock`: R package snapshot
- `protocol/analysis_plan.md`: prespecified analysis plan

The release contains no participant-level data, completed imputations, fitted
models, credentials, or restricted CHARLS files.

## Data

CHARLS files must be obtained by a registered user under the CHARLS data-use
terms. NHANES 2007--2012 public component files and 2019 public-use linked
mortality files must be downloaded from NCHS. Copy
`config/data_paths.example.yml` to `config/data_paths.yml` and enter local
authorized paths.

## Run

Use R 4.5.1 and restore `environment/renv.lock`, then run:

```bash
Rscript --vanilla run_analysis.R
```

The entry point runs 49 ordered analysis and validation steps.
It creates temporary compatibility copies needed by the frozen provenance
checks and removes those copies on exit. The scientific R scripts and
specifications are byte-identical to the frozen manuscript analysis.

To verify the package layout without accessing participant data:

```bash
Rscript --vanilla run_analysis.R --prepare-only
```

Compare released aggregate outputs with `expected_results/`. Every public file
is covered by `SHA256SUMS.txt`.
