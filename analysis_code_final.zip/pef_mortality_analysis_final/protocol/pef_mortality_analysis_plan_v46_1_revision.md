# V46.1 locked corrective-revision plan

**Frozen on:** 2026-08-02 (Asia/Shanghai)  
**Purpose:** correct the cross-file inconsistencies identified in the independent V46.0 editorial simulation and align the reported CHARLS sensitivity analyses with the adjacent-transition primary estimand.  
**Immutable baseline:** `output/submission_package_v46_0_FINAL_2026-08-02.zip`, SHA-256 `842789b6e17efc2f39914bfcd75f89cb9df979d454e370d8b6f80c045cf389c2`.

## 1. Governing principle

V46.0 remains unchanged as the reviewed baseline. V46.1 is a separate corrective branch. The definitions below are fixed before any new V46.1 outcome coefficient is fitted or inspected. Analyses will not be added, removed, relabelled, or promoted in response to effect direction, magnitude, confidence interval, or P value.

The V46.0 primary analyses remain authoritative unless an exact identity check fails. V46.1 does not introduce a new cohort, endpoint, exposure, scaling constant, prediction model, causal estimand, or clinical threshold.

## 2. Frozen inputs

The structural preflight must bind and verify the exact hashes of:

1. the V46.0 submission archive;
2. the validated CHARLS MI-C0 `m=50` object;
3. the frozen CHARLS analysis ledger and actual-key Rao-Wu contract;
4. the independently released V46.0 adjacent-primary results;
5. the V46.1 protocol and executable scripts.

No participant-level data may be copied into the public results or submission directories.

## 3. Unchanged primary estimand

The CHARLS primary domain remains the 12,427 participants contributing at least one observed adjacent transition (W1-W2, W2-W3, W3-W4, or W4-W5). The primary A1 complementary-log-log model, frozen exposure scale, end-wave indicators, scheduled-duration offset, community clustering, 500-column Rao-Wu design, and `m=50` Rubin pooling remain unchanged.

The released V46.0 A1-E0 estimate must be carried forward byte-for-byte from the independently validated release. It must not be refitted or selected against the new sensitivity results.

## 4. New estimand-aligned CHARLS sensitivity analyses

All new analyses use only adjacent transitions, the frozen primary-population E0 scaling constants, the V46.0 A1 formula, and the same nominal-duration time basis. E0 is never restandardized after restriction.

### 4.1 Adjacent complete-case analysis

The complete-case population is fixed from the original, pre-imputation MI-C0 data. It requires observed height and weight parents and complete A2 covariates, including the two smoking parent variables. BMI is reconstructed from observed weight and height; it is not taken from the internal MI placeholder. Participants must also contribute at least one adjacent transition.

The point estimate and all 500 Rao-Wu replicate estimates are fitted once because no imputed value enters this analysis. The complete-data reference degrees of freedom equal the number of contributing communities minus one.

### 4.2 Adjacent boundary-value exclusion

Membership excludes participants whose baseline row-maximum PEF equals either prespecified device boundary value (30 or 890 L/min). Membership is fixed and identical across imputations. The A1 model is fitted in each of the 50 completed MI-C0 datasets and pooled with Rubin's rules after Rao-Wu covariance estimation.

### 4.3 Adjacent strict-measurement restriction

Membership requires the frozen baseline strict-protocol indicator and at least two valid baseline PEF trials. Membership is fixed and identical across imputations. The same A1, `m=50`, Rao-Wu, and Rubin procedures are used.

### 4.4 Analyses not re-estimated in V46.1

The Wave-2 conditional-survivor analysis is retained as a distinct landmark analysis and must be labelled as conditional on explicit survival to Wave 2; it is not an adjacent-primary complete-case or measurement sensitivity.

The WHO component-only and PCORnet-style anthropometric-routing results were estimated in the all-window domain. Their alternative completed-data objects were intentionally not persisted. V46.1 will not recreate those imputations solely to retrofit a changed follow-up domain. If retained, these rows must explicitly state `all observed windows` and must not be described as direct robustness analyses of the adjacent-primary estimand.

## 5. Observation-process description

The frozen person-period skeleton defines the following mutually interpretable contributor groups before outcome-model fitting:

- **Adjacent contributor:** at least one adjacent transition, irrespective of whether a nonconsecutive transition is also present.
- **Nonconsecutive-only contributor:** at least one all-window transition but no adjacent transition.
- **Mixed-path contributor:** at least one adjacent and at least one nonconsecutive transition.

V46.1 will report the number of participants, person-period rows, deaths, and scheduled nominal person-years for these groups. It will also compare adjacent contributors with nonconsecutive-only contributors using descriptive, design-weighted baseline summaries for age, sex, rural residence, smoking, education, BMI, E0, chronic lung disease, asthma, and frailty-proxy count.

The comparison is descriptive. No null-hypothesis P values will be calculated. Standardized mean differences will be shown as measures of observed imbalance, not as selection-adjusted causal contrasts. Imputed-variable summaries will be calculated in each of the 50 MI-C0 completions and averaged across imputations; no individual-level completed data will be released.

The Methods and supplement must state explicitly that a death reported after one or more missed survey waves is assigned to the single observed interval from the last explicit known-alive wave to the next explicit death-status wave. The all-window analysis does not recover the unobserved intermediate status or exact within-interval death time.

## 6. Numerical gates and pooling

For the two MI-based sensitivity analyses, literal Rao-Wu columns 1-250 are run first without pooling or public coefficient release. Full execution is permitted only when the minimum common valid-replicate fraction is at least 0.80. Fractions from 0.80 through below 0.90 are `CAUTION`; fractions at least 0.90 are `GO`.

The full object must reproduce the literal first 250 columns exactly. Replicate covariance uses the common valid mask and denominator `B_valid - 1`. Rubin pooling uses `m=50`; an object-level Monte Carlo error to pooled-standard-error fraction at or above 0.10 triggers review of the entire object rather than selective rerunning.

The complete-case analysis requires all 500 finite replicate estimates and a positive finite Rao-Wu variance. Any rank deficiency, non-estimability, prefix `STOP`, prefix-identity failure, non-finite pooled quantity, or independent-validation failure stops release without adaptive model modification.

## 7. Reporting hierarchy

1. The V46.0 CHARLS adjacent A1-E0 and NHANES cohort-specific A1-E0 estimates remain principal.
2. The three new adjacent-domain CHARLS analyses are supporting missing-data and measurement sensitivities.
3. The all-window and Wave-2 landmark analyses address observation-window definitions and delayed entry, respectively.
4. Anthropometric-routing analyses, if retained, are explicitly all-window analyses.
5. NHANES GLI conditioning, reference-range, A/B-quality, selection-weighting, influence, and functional-form analyses remain secondary or exploratory as already defined.
6. The two Holm-adjusted tests constitute only their prespecified two-test family; no text may imply manuscript-wide multiplicity control.

All interpretations remain associational. Conditional PEF models do not identify independent respiratory physiology, mediation, incremental prediction, or clinical utility. The paired conditional-versus-separate ratio crossing one will be described as numerical attenuation with imprecise evidence for a coefficient difference.

## 8. Required document corrections

- Replace the stale CHARLS rows in Supplementary Table S11 with domain-labelled results.
- Correct the all-window value in Table S14 from the duplicated adjacent estimate to the independently released all-window estimate.
- Add the observation-process contributor comparison and source data.
- Correct the outdated STROBE item 10 and 16a locators after final pagination.
- Distinguish the overall effort-quality attribute from FEV1/FVC quality grades and state that the A/B sensitivity addresses only the latter.
- State that released PEF, FEV1, and FVC summaries may arise from different acceptable curves within the same examination session.
- Clarify participant-level imputation followed by person-period expansion and survey outcome modelling.
- State that the NHANES selection weighting targets only the spirometry-safe to strict-PEF-quality contrast, not the GLI common or A/B domains.

## 9. Release boundary

Execution writes coefficient-bearing objects only under `derived_sensitive/v46_1/`. Public aggregate results are written only by a separate validator after exact input-hash, schema, sample-anchor, prefix-identity, numerical, pooling, and privacy checks pass. No completed dataset, fitted model object, participant-level record, individual weight, individual prediction, or participant identifier is released.

