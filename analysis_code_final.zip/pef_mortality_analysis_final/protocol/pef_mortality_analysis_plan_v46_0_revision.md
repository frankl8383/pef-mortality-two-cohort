# V46.0 locked revision plan

**Frozen on:** 2026-08-01 (Asia/Shanghai)  
**Purpose:** resolve the remaining model-structure and spirometry-quality concerns raised during independent editorial simulation without changing the substantive research question.  
**Baseline:** V45.9 remains immutable. V46.0 is a new analysis and manuscript branch.

## 1. Governing principle

The analysis definitions below are fixed before any new V46 outcome coefficient is inspected. The primary/sensitivity hierarchy will not be changed in response to effect direction, magnitude, confidence interval, or P value. A failed structural, numerical, or validation gate will be reported as such; it will not be repaired by selecting a more favorable analysis.

## 2. Frozen inputs

| Input | Role | SHA-256 |
|---|---|---|
| `output/submission_package_v45_9_FINAL_2026-07-29.zip` | immutable submitted-manuscript baseline | `157e743759a0e27754d37c10f5a261b81ec354592811aefe7a894e6be020b61a` |
| CHARLS MI-C0 m=50 object | frozen completed-data object | `8d7d0b16cf6028ac6ba1c7566d5957c650398c612138fdf1c2aae96424fb2f9e` |
| CHARLS analysis ledger | frozen row/design authority | `500e923e8793d1925823c73ff1039591dd9a23f84d57a31a80a33f4f49e0ea0b` |
| CHARLS actual-key Rao-Wu contract | frozen 500-replicate design authority | `2e80186cacd93d8f9c29aac1dc02168d545e4f43a4cded86542565bb7a01937c` |
| Existing CHARLS adjacent full object | exact A1-E0 reuse anchor | `83a50c89d5cb2023eae6c39a5b0084b7cda45713d6100eab034dcc9612a69477` |
| NHANES MI-G m=50 object | frozen GLI completed-data object | `41bcc3e5fbfd8f19501682e93354856ffc06adf6e426937327e07138d17733d3` |
| NHANES Rao-Wu contract | frozen 500-replicate design authority | `2d795d61aabcce42603b1cfa7b254239a716980821ad1865347a8a8327c9f152` |
| Existing NHANES paired full object | exact A/B/C-domain reuse anchor | `63804066d87a6af0e1a9b61d57d5a318ca4c0d13417f6fee4bfea601272e2daf` |

## 3. CHARLS: adjacent-transition primary analysis

### 3.1 Target population and time scale

The V46.0 CHARLS primary domain contains only observed adjacent transitions (wave 1 to 2, 2 to 3, 3 to 4, and 4 to 5) from the frozen person-period skeleton. Each row represents one scheduled adjacent interval. The complementary-log-log model retains end-wave indicators and the log of nominal interval years as an offset.

This domain is primary irrespective of its results because it avoids assigning the full duration of a nonconsecutive observation window to a single end-wave baseline-rate category. The former all-window analysis is retained only as a sensitivity analysis and historical comparison.

Frozen structural anchors, identical in all 50 imputations:

- 12,427 participants;
- 1,539 deaths;
- 44,778 person-period rows;
- 432 communities and complete-data design degrees of freedom 431.

### 3.2 Exposure definitions

- **E0 (primary exposure):** sex-standardized lower-than-expected peak expiratory flow, scaled so that higher values indicate worse respiratory performance and one unit equals one sex-specific standard deviation.
- **E0b (secondary exposure definition):** the prespecified alternative residual construction already present in the frozen MI-C0 object. It is a sensitivity analysis, not a co-primary endpoint.
- Height and BMI are rebuilt passively within each completed data set from the frozen imputed height and the authorized wave-1 core weight. No independent BMI imputation is introduced.

### 3.3 Adjustment sets

- **A0:** E0 (or E0b), restricted-cubic age terms, sex, restricted-cubic height terms, end-wave indicators, and log nominal years offset.
- **A1 (primary):** A0 plus smoking status, restricted-cubic BMI terms, education, rural residence, and log household per-capita consumption.
- **A2:** A1 plus baseline chronic lung disease, asthma, nonpulmonary comorbidity count, and frailty-proxy count.

The primary CHARLS estimand is the A1 hazard ratio per one-unit higher E0. A0 and A2 establish the adjustment ladder. E0b A0/A1/A2 are exposure-definition sensitivities.

### 3.4 Functional form

For E0 under A1, a frozen three-column restricted cubic basis (`E0_linear`, `E0_nonlinear1`, `E0_nonlinear2`) is fitted using the existing outcome-blind knot registry. Two prespecified Rubin-pooled Wald tests are released:

1. overall three-degree-of-freedom association;
2. joint two-degree-of-freedom nonlinear component.

The linear A1-E0 fit reused from the exact frozen adjacent object must match a freshly reconstructed point-fit identity check to tolerance `1e-8` before reuse is permitted.

### 3.5 Variance and pooling

- All analyses use the frozen 500-column community-level Rao-Wu matrix.
- Columns 1-250 are run first as a coefficient-blind numerical gate. No pooling or coefficient release occurs at this stage.
- If the minimum common valid-replicate fraction is below 0.80, execution stops. Fractions from 0.80 through below 0.90 are flagged `CAUTION`; fractions at least 0.90 are `GO`.
- Only after the prefix gate permits continuation are columns 251-500 fitted.
- Replicate covariance uses the common valid mask and denominator `B_valid - 1`.
- The 50 imputation-specific estimates and within-imputation Rao-Wu covariance matrices are combined by Rubin's rules. Scalar Monte Carlo error fractions at or above 0.10 trigger a whole-object review; there is no selective model upgrade.

### 3.6 Required downstream changes

The CHARLS baseline table, cohort flow, primary adjustment ladder, spline display, abstract, Results, Discussion, and supplement must all use the adjacent-transition primary population. The all-window A1 result remains clearly labeled as a sensitivity analysis. Participant counts, event counts, and row counts must not be mixed across domains.

## 4. NHANES: conventional-volume quality sensitivity

### 4.1 Frozen primary GLI domain

The existing GLI common sample with acceptable peak-flow quality and FEV1/FVC quality grades A, B, or C remains the prespecified NHANES primary comparison domain. Grade C is not recoded as invalid retrospectively.

### 4.2 New strict-quality sensitivity

The V46.0 strict domain is a deterministic restriction of MI-G to participants with both FEV1 and FVC quality grades A or B (`spirometry_ab`) while preserving the existing PEF-quality requirement and every other common-sample criterion.

Frozen structural anchors, identical in all 50 imputations:

- 5,925 participants;
- 758 deaths;
- 45 strata and 94 PSUs;
- complete-data design degrees of freedom 49.

Two A1 models are fitted on the identical strict-quality sample:

1. **separate:** E0 plus A1 covariates;
2. **conditional:** E0, lower FEV1, lower FEV1/FVC ratio, plus A1 covariates.

The paired estimand is `beta_conditional - beta_separate`. A second paired domain-contrast estimand compares the strict A/B conditional E0 coefficient with the exact frozen A/B/C conditional E0 coefficient. The latter is descriptive evidence about quality restriction, not a formal interaction test between independent samples.

### 4.3 Variance, pooling, and gates

The frozen NHANES 500-column Rao-Wu design is used. The same prefix/full gate, common-valid-mask covariance, m=50 Rubin pooling, and 0.10 Monte Carlo error fraction review rule specified for CHARLS apply. No new imputation object is created because spirometry-quality membership is fully observed and deterministic.

## 5. Reporting hierarchy and interpretation

1. CHARLS adjacent A1-E0 and the already frozen NHANES A1-E0 association remain the principal cohort-specific results.
2. Adjustment ladders, alternative residual construction, spline tests, GLI conditioning, observation-IPW analyses, and quality restrictions are supporting analyses.
3. The manuscript will describe associations, not causal effects, transportable prediction, or a validated clinical cutoff.
4. A nonsignificant nonlinear test will be reported as absence of material evidence of nonlinearity over the modeled range, not proof of linearity.
5. The strict A/B analysis will be reported regardless of whether it strengthens, attenuates, reverses, or leaves unchanged the A/B/C-domain result.

## 6. Outcome firewall and release

Structural preflight may inspect membership, event counts, design dimensions, model-matrix rank, finite values, factor support, and exact input hashes. It may not fit an outcome model or expose coefficients. Outcome execution writes only aggregate restricted objects under `derived_sensitive/v46/`. Public aggregate tables are written only by a separate validator after exact-hash, schema, sample-anchor, prefix-identity, numerical, pooling, and privacy checks pass. No participant-level completed data, fit objects, individual weights, or individual predictions are released.

## 7. Stop conditions

Execution stops without adaptive model changes if any frozen input hash differs, any imputation changes domain membership, an expected anchor fails, a model matrix is rank deficient or nonfinite, a point fit is not estimable, the prefix gate is `STOP`, the literal prefix is not identical in the full object, pooling fails, or independent validation fails.

