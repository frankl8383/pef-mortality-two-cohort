# PEF mortality analysis code

Version: V45.8  
Prepared: 29 July 2026

This archive contains the R code and machine-readable specifications used for
the CHARLS and NHANES analyses reported in the accompanying manuscript. It
also contains aggregate validation targets for the released analysis.

## Data required

CHARLS files must be obtained by a registered user from the China Health and
Retirement Longitudinal Study under its data-use terms:

- Harmonized CHARLS D (`H_CHARLS_D_Data.zip`, member
  `H_CHARLS_D_Data.dta`);
- CHARLS 2020 (`CHARLS2020r.zip`).

NHANES uses the 2007--2008, 2009--2010, and 2011--2012 public-use component
files and the 2019 public-use linked mortality files:

- `DEMO`, `SPX`, `BMX`, `MCQ`, `SMQ`, `PFQ`, `DPQ`, and `PAQ` component
  files for cycles E, F, and G;
- `NHANES_2007_2008_MORT_2019_PUBLIC.dat`;
- `NHANES_2009_2010_MORT_2019_PUBLIC.dat`;
- `NHANES_2011_2012_MORT_2019_PUBLIC.dat`.

The archive contains no participant-level data, completed imputations,
credentials, or fitted model objects.

## Environment

The production environment was R 4.5.1. Restore the package versions recorded
in `work_v43/renv.lock`; the principal packages were `survey` 4.5,
`survival` 3.8-3, `mice` 3.19.0, and `mitools` 2.4.

## Configuration

Copy `config/data_paths.example.yml` outside version control and replace the
placeholders with local authorized paths. The public analysis specification
uses placeholders rather than author-specific absolute paths.

The production workflow validates input hashes before fitting models. A new
independent rerun must generate its own local input manifest and authorization
hashes from the files obtained by that analyst. Do not substitute the
manuscript's author-side hashes for independently obtained files.

## Sequence

`RUN_ORDER.txt` lists the cohort construction, imputation, survey-design,
model-fitting, pooling, diagnostic, and independent-validation scripts in
order. The scripts write row-level intermediates only to local
`derived_sensitive/` directories. Public outputs are aggregate.

The exact method, visit order, missing-cell count, and predictor-matrix entries
for MI-B, MI-G, MI-S, MI-C0, and MI-C2 are included under
`validation_targets/v45_8/`. GLI values and reference-range membership are
recalculated after completed height in every MI-G dataset.

## Validation

After a rerun, compare aggregate results with the files under
`validation_targets/`. `SHA256SUMS.txt` covers every file in this archive.
The display-reproduction entry point in the parent GitHub repository rebuilds
the submitted tables and figures from disclosure-safe aggregate inputs.

