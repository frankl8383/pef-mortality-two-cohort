#!/usr/bin/env Rscript

# V45.8 aggregate-only audit of analyses already completed and independently
# released. This script does not fit a mortality model or export row-level data.
# It records the exact multiple-imputation specifications, the existing CHARLS
# transition counts, and the distribution of the final NHANES combined
# examination/observation weights.

options(stringsAsFactors = FALSE, warn = 1)

project_root <- function() {
  args <- commandArgs(trailingOnly = FALSE)
  file_arg <- grep("^--file=", args, value = TRUE)
  if (!length(file_arg)) return(normalizePath(getwd(), mustWork = TRUE))
  script <- sub("^--file=", "", file_arg[[1L]])
  normalizePath(file.path(dirname(script), "..", ".."), mustWork = TRUE)
}

root <- project_root()
out_dir <- file.path(root, "results", "v45_8", "specification_audit")
qa_dir <- file.path(root, "output", "qa", "v45_8")
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(qa_dir, recursive = TRUE, showWarnings = FALSE)

source(file.path(root, "R", "v45", "01_nhanes_common_utilities_v45.R"))
source(file.path(root, "R", "v45", "02_gli_functions_v45.R"))
source(file.path(root, "R", "v45", "11_nhanes_outcome_utilities_v45.R"))
v45_require_packages(root)

read_tsv <- function(path) {
  utils::read.delim(
    path,
    stringsAsFactors = FALSE,
    check.names = FALSE,
    na.strings = c("", "NA")
  )
}

write_tsv <- function(x, path) {
  utils::write.table(
    x,
    path,
    sep = "\t",
    quote = FALSE,
    row.names = FALSE,
    na = ""
  )
}

assert <- function(condition, message) {
  if (!isTRUE(condition)) stop(message, call. = FALSE)
}

pointer_path <- function(object_id) {
  if (grepl("^MI-C", object_id)) {
    return(file.path(
      root,
      "results",
      "v45",
      "charls_addendum_v45_1",
      "production_mi",
      paste0(gsub("-", "_", object_id, fixed = TRUE), "_m50_current.tsv")
    ))
  }
  file.path(
    root,
    "results",
    "v45",
    "production_mi",
    paste0(gsub("-", "_", object_id, fixed = TRUE), "_m50_current.tsv")
  )
}

object_ids <- c("MI-B", "MI-G", "MI-S", "MI-C0", "MI-C2")
objects <- setNames(vector("list", length(object_ids)), object_ids)
object_rows <- vector("list", length(object_ids))
method_rows <- list()
matrix_rows <- list()

for (i in seq_along(object_ids)) {
  object_id <- object_ids[[i]]
  pointer <- read_tsv(pointer_path(object_id))
  assert(nrow(pointer) == 1L, paste(object_id, "pointer is not unique."))
  assert(
    identical(as.integer(pointer$requested_m[[1L]]), 50L),
    paste(object_id, "does not point to m=50.")
  )
  mids_path <- file.path(root, pointer$mids_path_alias[[1L]])
  assert(file.exists(mids_path), paste(object_id, "mids file is missing."))
  assert(
    identical(v45_sha256_file(mids_path), pointer$mids_sha256[[1L]]),
    paste(object_id, "mids SHA-256 does not match its pointer.")
  )
  mids <- readRDS(mids_path)
  assert(inherits(mids, "mids"), paste(object_id, "is not a mids object."))
  assert(identical(as.integer(mids$m), 50L), paste(object_id, "m drifted."))
  objects[[object_id]] <- mids

  object_rows[[i]] <- data.frame(
    object_id = object_id,
    participants = nrow(mids$data),
    variables = ncol(mids$data),
    imputations = mids$m,
    iterations = mids$iteration,
    imputed_variables = sum(nzchar(mids$method)),
    imputed_cells = sum(mids$where),
    seed = switch(
      object_id,
      "MI-B" = 430401L,
      "MI-G" = 450201L,
      "MI-S" = 450301L,
      "MI-C0" = 440401L,
      "MI-C2" = 450503L
    ),
    mids_sha256 = pointer$mids_sha256[[1L]],
    stringsAsFactors = FALSE
  )

  active_targets <- names(mids$method)[nzchar(mids$method)]
  for (target in names(mids$method)) {
    predictors <- names(which(mids$predictorMatrix[target, ] != 0))
    method_rows[[length(method_rows) + 1L]] <- data.frame(
      object_id = object_id,
      variable = target,
      method = unname(mids$method[[target]]),
      visit_order = match(target, mids$visitSequence),
      imputed_cells = sum(mids$where[, target]),
      predictor_count = length(predictors),
      predictors = paste(predictors, collapse = ";"),
      active_target = target %in% active_targets,
      stringsAsFactors = FALSE
    )
    for (predictor in colnames(mids$predictorMatrix)) {
      matrix_rows[[length(matrix_rows) + 1L]] <- data.frame(
        object_id = object_id,
        target = target,
        predictor = predictor,
        value = as.integer(mids$predictorMatrix[target, predictor]),
        stringsAsFactors = FALSE
      )
    }
  }
}

object_summary <- do.call(rbind, object_rows)
method_spec <- do.call(rbind, method_rows)
predictor_matrix <- do.call(rbind, matrix_rows)

write_tsv(
  object_summary,
  file.path(out_dir, "v45_8_mi_object_summary.tsv")
)
write_tsv(
  method_spec,
  file.path(out_dir, "v45_8_mi_method_visit_specification.tsv")
)
write_tsv(
  predictor_matrix,
  file.path(out_dir, "v45_8_mi_predictor_matrix_long.tsv")
)

# Existing CHARLS transition counts. Only aggregate rows from the released
# sample/event audit are retained.
transition_source <- utils::read.csv(
  file.path(root, "results", "v43", "stage3_charls_sample_event_audit_v43.csv"),
  stringsAsFactors = FALSE,
  check.names = FALSE
)
transition <- transition_source[
  transition_source$audit_type == "window",
  c(
    "stratum",
    "n_people",
    "transition_rows",
    "deaths",
    "non_deaths",
    "outcome_event_fraction"
  ),
  drop = FALSE
]
transition$adjacent <- transition$stratum %in%
  c("W1_W2", "W2_W3", "W3_W4", "W4_W5")
transition <- transition[
  match(
    c(
      "W1_W2", "W1_W3", "W1_W4", "W1_W5", "W2_W3",
      "W2_W4", "W2_W5", "W3_W4", "W3_W5", "W4_W5"
    ),
    transition$stratum
  ),
  ,
  drop = FALSE
]
scheduled_years <- c(
  W1_W2 = 2,
  W1_W3 = 4,
  W1_W4 = 7,
  W1_W5 = 9,
  W2_W3 = 2,
  W2_W4 = 5,
  W2_W5 = 7,
  W3_W4 = 3,
  W3_W5 = 5,
  W4_W5 = 2
)
transition$scheduled_years <- unname(scheduled_years[transition$stratum])
assert(!anyNA(transition$stratum), "CHARLS transition registry is incomplete.")
assert(!anyNA(transition$scheduled_years), "CHARLS duration registry is incomplete.")
assert(sum(transition$transition_rows) == 45503L, "CHARLS row total drifted.")
assert(sum(transition$deaths) == 1735L, "CHARLS death total drifted.")
assert(
  sum(transition$transition_rows[!transition$adjacent]) == 725L,
  "CHARLS nonconsecutive row total drifted."
)
assert(
  sum(transition$deaths[!transition$adjacent]) == 196L,
  "CHARLS nonconsecutive death total drifted."
)
write_tsv(
  transition,
  file.path(out_dir, "v45_8_charls_transition_counts.tsv")
)

# Aggregate distribution of the final combined NHANES weights. This reproduces
# the already released primary response model in every MI-S completed dataset,
# but deliberately does not fit an outcome model or inspect a mortality
# coefficient.
ledger <- v45_read_nhanes_ledger(root)
v43 <- v45_load_v43_nhanes_functions(root)
rw <- readRDS(file.path(
  root,
  "derived_sensitive",
  "v45",
  "v45_rao_wu_replicate_contract.rds"
))
design_data <- v45_outcome_design_data(ledger, rw)
mis <- objects[["MI-S"]]

weight_rows <- vector("list", 50L)
for (imputation in seq_len(50L)) {
  completed <- v45_prepare_mis_completed(
    mice::complete(mis, action = imputation),
    ledger,
    v43
  )
  full_rows <- match(as.integer(completed$SEQN), design_data$SEQN)
  assert(!anyNA(full_rows), "MI-S IDs are absent from the full MEC design.")
  base_weight <- as.numeric(rw$full_design_pweights[full_rows])
  positive <- is.finite(base_weight) & base_weight > 0
  response_data <- completed[positive, , drop = FALSE]
  response_data$.v45_response_weight <-
    base_weight[positive] / mean(base_weight[positive])
  response_fit <- stats::glm(
    v45_outcome_d1_formula(FALSE),
    data = response_data,
    weights = .v45_response_weight,
    family = quasibinomial()
  )
  probability <- as.numeric(stats::predict(
    response_fit,
    newdata = completed,
    type = "response"
  ))
  assert(
    all(is.finite(probability) & probability > 0 & probability < 1),
    paste("Invalid response probability in imputation", imputation)
  )
  respondent <- as.character(completed$R_A) == "1" & positive
  assert(sum(respondent) == 6719L, "MI-S respondent count drifted.")
  factor_contract <- v45_ipw_factors(
    probability,
    respondent,
    base_weight
  )
  combined <- base_weight[respondent] *
    factor_contract$factors[["uncapped"]]
  normalized <- combined / mean(combined)
  raw_quantiles <- stats::quantile(
    combined,
    probs = c(0, 0.01, 0.5, 0.99, 1),
    names = FALSE,
    type = 7
  )
  normalized_quantiles <- stats::quantile(
    normalized,
    probs = c(0, 0.01, 0.5, 0.99, 1),
    names = FALSE,
    type = 7
  )
  weight_rows[[imputation]] <- data.frame(
    imputation = imputation,
    respondents = sum(respondent),
    combined_weight_min = raw_quantiles[[1L]],
    combined_weight_p01 = raw_quantiles[[2L]],
    combined_weight_median = raw_quantiles[[3L]],
    combined_weight_p99 = raw_quantiles[[4L]],
    combined_weight_max = raw_quantiles[[5L]],
    normalized_weight_min = normalized_quantiles[[1L]],
    normalized_weight_p01 = normalized_quantiles[[2L]],
    normalized_weight_median = normalized_quantiles[[3L]],
    normalized_weight_p99 = normalized_quantiles[[4L]],
    normalized_weight_max = normalized_quantiles[[5L]],
    availability_factor_p99 = stats::quantile(
      factor_contract$availability,
      0.99,
      names = FALSE,
      type = 7
    ),
    stringsAsFactors = FALSE
  )
  rm(completed, response_data, response_fit)
  invisible(gc(verbose = FALSE))
}
weight_distribution <- do.call(rbind, weight_rows)
write_tsv(
  weight_distribution,
  file.path(out_dir, "v45_8_nhanes_combined_weight_distribution.tsv")
)

summary_rows <- lapply(
  setdiff(names(weight_distribution), c("imputation", "respondents")),
  function(metric) {
    values <- weight_distribution[[metric]]
    data.frame(
      metric = metric,
      median_across_imputations = stats::median(values),
      minimum_across_imputations = min(values),
      maximum_across_imputations = max(values),
      stringsAsFactors = FALSE
    )
  }
)
weight_summary <- do.call(rbind, summary_rows)
write_tsv(
  weight_summary,
  file.path(out_dir, "v45_8_nhanes_combined_weight_summary.tsv")
)

output_paths <- c(
  "v45_8_mi_object_summary.tsv",
  "v45_8_mi_method_visit_specification.tsv",
  "v45_8_mi_predictor_matrix_long.tsv",
  "v45_8_charls_transition_counts.tsv",
  "v45_8_nhanes_combined_weight_distribution.tsv",
  "v45_8_nhanes_combined_weight_summary.tsv"
)
manifest <- data.frame(
  file = output_paths,
  sha256 = vapply(
    file.path(out_dir, output_paths),
    v45_sha256_file,
    character(1)
  ),
  stringsAsFactors = FALSE
)
write_tsv(manifest, file.path(out_dir, "v45_8_specification_audit_manifest.tsv"))

qa <- c(
  "# V45.8 existing-analysis specification audit",
  "",
  "Status: PASS",
  "",
  "- No mortality model was fitted and no new mortality coefficient was generated.",
  "- Five validated m=50 imputation objects were read only to export methods, visit order, missing-cell totals, and exact predictor-matrix entries.",
  "- The CHARLS transition registry reconciled to 45,503 rows and 1,735 deaths.",
  "- Nonconsecutive CHARLS transitions reconciled to 725 rows and 196 deaths.",
  "- The primary NHANES response model was repeated within each of the 50 MI-S completed datasets solely to summarize final combined weights.",
  "- No participant-level row, predicted response probability, completed dataset, fitted model, or individual weight was saved.",
  "",
  "## Output hashes",
  "",
  paste0("- `", manifest$file, "`: `", manifest$sha256, "`")
)
qa_path <- file.path(
  qa_dir,
  "EXISTING_ANALYSIS_SPECIFICATION_AUDIT_v45_8.md"
)
writeLines(qa, qa_path, useBytes = TRUE)

cat("V45_8_EXISTING_ANALYSIS_SPECIFICATION_AUDIT_PASS\n")
cat("output_dir=", out_dir, "\n", sep = "")
cat("qa=", qa_path, "\n", sep = "")
