# v44.2 additive, outcome-blind baseline-characteristics module.
#
# PREAUTHORIZATION DRAFT. Formal execution is fail-closed until a distinct
# final authorization registry has been reviewed, frozen, and supplied through
# V44_2_BASELINE_AUTH_SHA256. The preflight-only route never opens an RDS,
# never creates an output directory, and never writes a file.

options(stringsAsFactors = FALSE)

project_root <- function() {
  args <- commandArgs(trailingOnly = FALSE)
  file_arg <- grep("^--file=", args, value = TRUE)
  if (length(file_arg)) {
    script <- sub("^--file=", "", file_arg[[1]])
    return(normalizePath(file.path(dirname(script), "..", ".."), mustWork = TRUE))
  }
  normalizePath(getwd(), mustWork = TRUE)
}

one_line <- function(x, empty = "") {
  x <- trimws(as.character(x))
  x <- x[!is.na(x) & nzchar(x)]
  if (!length(x)) return(empty)
  gsub("[\r\n]+", " ", paste(x, collapse = "; "))
}

as_flag <- function(x) {
  if (is.logical(x)) return(x)
  if (is.numeric(x)) return(ifelse(is.na(x), NA, x != 0))
  y <- toupper(trimws(as.character(x)))
  out <- rep(NA, length(y))
  out[y %in% c("TRUE", "T", "1", "YES", "Y", "PASS", "GO", "OK")] <- TRUE
  out[y %in% c("FALSE", "F", "0", "NO", "N", "FAIL", "NO-GO", "NO_GO", "ERROR")] <- FALSE
  out
}

sha256_file <- function(path) {
  if (!file.exists(path) || dir.exists(path)) return(NA_character_)
  digest::digest(file = path, algo = "sha256", serialize = FALSE)
}

resolve_path <- function(root, path) {
  path <- path.expand(as.character(path))
  if (grepl("^/", path)) path else file.path(root, path)
}

file_record <- function(root, asset, path, role = NA_character_) {
  full <- resolve_path(root, path)
  data.frame(
    asset = asset,
    path = as.character(path),
    exists = file.exists(full) && !dir.exists(full),
    bytes = if (file.exists(full) && !dir.exists(full)) as.numeric(file.info(full)$size) else NA_real_,
    sha256 = sha256_file(full),
    governance_role = role,
    stringsAsFactors = FALSE
  )
}

expected_proposal_assets <- function() {
  c(
    spec = "work_v44/baseline_characteristics_spec_v44_2.yml",
    contract = "work_v44/baseline_characteristics_contract_v44_2.yml",
    decision_log = "work_v44/baseline_characteristics_decision_log_v44_2.md",
    script = "R/v44/06_baseline_characteristics_v44_2.R",
    v44_1_1_authorization_registry =
      "work_v44/charls_anthropometric_qc_resolution_authorization_hashes_v44_1_1.csv",
    v44_1_1_manifest =
      "results/v44_1_1/charls_anthropometric_qc_manifest_v44_1_1.csv",
    v44_1_1_validation =
      "results/v44_1_1/charls_anthropometric_qc_validation_v44_1_1.csv",
    v44_1_1_source_audit =
      "results/v44_1_1/charls_anthropometric_qc_source_audit_v44_1_1.csv",
    v44_1_1_primary_registry =
      "results/v44_1_1/stage3_charls_primary_association_registry_v44_1_1.csv",
    v43_authorization_registry = "work_v43/stage3_authorization_hashes_v43.csv",
    v43_nhanes_completion_manifest =
      "results/v43/stage3_nhanes_completion_manifest_v43.csv",
    v43_nhanes_primary_registry =
      "results/v43/stage3_nhanes_primary_association_registry_v43.csv",
    v43_nhanes_design_audit = "results/v43/stage3_nhanes_design_audit_v43.csv",
    v43_output_finalization_manifest =
      "results/v43/stage3_output_finalization_manifest_v43.csv",
    charls_stage3_ledger =
      "derived_sensitive/v43/charls_stage3_analysis_ledger_v43.rds",
    charls_core_covariate_donor =
      "derived_sensitive/charls/charls_core_harmonized_provisional.rds",
    nhanes_stage3_ledger =
      "derived_sensitive/v43/nhanes_stage3_analysis_ledger_v43.rds",
    charls_public_design_audit = "metadata/charls_survey_design_lock_audit.md",
    renv_lock = "work_v43/renv.lock"
  )
}

expected_final_authorization_assets <- function() {
  c(
    expected_proposal_assets(),
    authorization_proposal =
      "work_v44/baseline_characteristics_authorization_proposal_v44_2.csv"
  )
}

read_csv_exact <- function(path) {
  utils::read.csv(path, stringsAsFactors = FALSE, check.names = FALSE)
}

validate_registry_rows <- function(root, registry, expected_assets, exact_columns) {
  if (!identical(names(registry), exact_columns)) {
    return(list(pass = FALSE, current = 0L, detail = "registry schema mismatch"))
  }
  if (nrow(registry) != length(expected_assets) ||
      anyDuplicated(registry$asset) ||
      !identical(as.character(registry$asset), names(expected_assets))) {
    return(list(pass = FALSE, current = 0L, detail = "registry asset/order mismatch"))
  }
  expected_paths <- unname(expected_assets)
  path_ok <- normalizePath(
    vapply(as.character(registry$path), function(path) resolve_path(root, path), character(1)),
    mustWork = FALSE
  ) == normalizePath(
    vapply(expected_paths, function(path) resolve_path(root, path), character(1)),
    mustWork = FALSE
  )
  if (!all(path_ok)) {
    return(list(pass = FALSE, current = sum(path_ok), detail = "registry path mismatch"))
  }
  validate_row <- function(i) {
    full <- resolve_path(root, registry$path[[i]])
    isTRUE(as_flag(registry$exists[[i]])) &&
      file.exists(full) && !dir.exists(full) &&
      isTRUE(as.numeric(file.info(full)$size) == suppressWarnings(as.numeric(registry$bytes[[i]]))) &&
      identical(tolower(sha256_file(full)), tolower(trimws(as.character(registry$sha256[[i]]))))
  }
  sensitive_rds <- grepl("\\.rds$", as.character(registry$path), ignore.case = TRUE)
  current <- rep(FALSE, nrow(registry))
  non_sensitive_rows <- which(!sensitive_rds)
  current[non_sensitive_rows] <- vapply(non_sensitive_rows, validate_row, logical(1))
  if (!all(current[non_sensitive_rows])) {
    return(list(
      pass = FALSE,
      current = sum(current[non_sensitive_rows]),
      detail = paste0(
        sum(current[non_sensitive_rows]), "/", length(non_sensitive_rows),
        " non-RDS authorization assets current; sensitive RDS not opened"
      )
    ))
  }
  sensitive_rows <- which(sensitive_rds)
  current[sensitive_rows] <- vapply(sensitive_rows, validate_row, logical(1))
  list(
    pass = all(current),
    current = sum(current),
    detail = paste0(sum(current), "/", length(expected_assets), " current")
  )
}

validate_proposal_rows_without_sensitive_reads <- function(
    root, proposal, expected_assets, exact_columns) {
  if (!identical(names(proposal), exact_columns)) {
    return(list(pass = FALSE, current = 0L, detail = "proposal schema mismatch"))
  }
  if (nrow(proposal) != length(expected_assets) ||
      anyDuplicated(proposal$asset) ||
      !identical(as.character(proposal$asset), names(expected_assets))) {
    return(list(pass = FALSE, current = 0L, detail = "proposal asset/order mismatch"))
  }
  expected_paths <- unname(expected_assets)
  path_ok <- normalizePath(
    vapply(as.character(proposal$path), function(path) resolve_path(root, path), character(1)),
    mustWork = FALSE
  ) == normalizePath(
    vapply(expected_paths, function(path) resolve_path(root, path), character(1)),
    mustWork = FALSE
  )
  sensitive_rds <- grepl("\\.rds$", as.character(proposal$path), ignore.case = TRUE)
  format_ok <- as_flag(proposal$exists) %in% TRUE &
    is.finite(suppressWarnings(as.numeric(proposal$bytes))) &
    suppressWarnings(as.numeric(proposal$bytes)) > 0 &
    grepl("^[0-9a-fA-F]{64}$", trimws(as.character(proposal$sha256)))
  metadata_ok <- vapply(seq_len(nrow(proposal)), function(i) {
    full <- resolve_path(root, proposal$path[[i]])
    file.exists(full) && !dir.exists(full) &&
      isTRUE(as.numeric(file.info(full)$size) ==
               suppressWarnings(as.numeric(proposal$bytes[[i]])))
  }, logical(1))
  # Preauthorization paths must not hash/open sensitive RDS bytes. Their
  # recorded SHA-256 values are frozen proposal metadata; current bytewise
  # validation occurs only after the final registry/environment binding passes.
  bytewise_ok <- rep(TRUE, nrow(proposal))
  bytewise_ok[!sensitive_rds] <- vapply(which(!sensitive_rds), function(i) {
    full <- resolve_path(root, proposal$path[[i]])
    identical(
      tolower(sha256_file(full)),
      tolower(trimws(as.character(proposal$sha256[[i]])))
    )
  }, logical(1))
  current <- path_ok & format_ok & metadata_ok & bytewise_ok
  list(
    pass = all(current),
    current = sum(current),
    detail = paste0(
      sum(current), "/", length(expected_assets),
      " proposal rows current; sensitive RDS checked by path/size/hash-format only"
    )
  )
}

validate_recursive_registry <- function(root, path, expected_n) {
  if (!file.exists(path)) return(list(pass = FALSE, current = 0L, detail = "missing"))
  dat <- read_csv_exact(path)
  required <- c("asset", "path", "exists", "bytes", "sha256")
  if (nrow(dat) != expected_n || !all(required %in% names(dat)) ||
      anyDuplicated(dat$asset)) {
    return(list(pass = FALSE, current = 0L, detail = "schema/cardinality mismatch"))
  }
  current <- vapply(seq_len(nrow(dat)), function(i) {
    full <- resolve_path(root, dat$path[[i]])
    isTRUE(as_flag(dat$exists[[i]])) && file.exists(full) && !dir.exists(full) &&
      isTRUE(as.numeric(file.info(full)$size) == suppressWarnings(as.numeric(dat$bytes[[i]]))) &&
      identical(tolower(sha256_file(full)), tolower(trimws(as.character(dat$sha256[[i]]))))
  }, logical(1))
  list(pass = all(current), current = sum(current),
       detail = paste0(sum(current), "/", nrow(dat), " current"))
}

output_paths_from_spec <- function(spec) {
  unlist(spec$outputs$files, use.names = FALSE)
}

namespace_empty <- function(root, spec) {
  paths <- c(
    resolve_path(root, spec$outputs$results_directory),
    resolve_path(root, spec$outputs$qa_directory),
    resolve_path(root, spec$outputs$staging_directory)
  )
  empty <- vapply(paths, function(path) {
    !dir.exists(path) || length(list.files(path, all.files = TRUE, no.. = TRUE, recursive = TRUE)) == 0L
  }, logical(1))
  list(pass = all(empty), detail = paste(basename(paths), empty, sep = "=", collapse = ";"))
}

variable_display_rows <- function(variable) {
  type <- as.character(variable$type)
  if (identical(type, "categorical")) length(variable$levels) else 1L
}

flatten_variable_dictionary <- function(spec) {
  rows <- list()
  for (cohort in c("CHARLS", "NHANES")) {
    vars <- spec$variables[[cohort]]
    for (v in vars) {
      cross_release <- isTRUE(v$cross_release_margin_suppression)
      levels <- if (identical(as.character(v$type), "categorical")) {
        paste(vapply(v$levels, function(x) {
          paste0(as.character(x$value), "=", as.character(x$label))
        }, character(1)), collapse = "|")
      } else if (identical(as.character(v$type), "binary")) {
        paste0(as.character(v$positive_value), "=", as.character(v$positive_label))
      } else {
        ""
      }
      rows[[length(rows) + 1L]] <- data.frame(
        cohort = cohort,
        variable_order = as.integer(v$order),
        variable_id = as.character(v$id),
        variable_label = as.character(v$label),
        source_field = as.character(v$source_field),
        variable_type = as.character(v$type),
        registered_levels = levels,
        summary_rule = as.character(v$summary_rule),
        unit = as.character(v$unit),
        display_role = as.character(v$display_role),
        descriptive_source = "observed_post_routing_or_registered_qc_pre_imputation",
        association_model_handling = as.character(v$association_model_handling),
        denominator_rule = if (cross_release) {
          paste(
            "observed values for distribution; fixed analytic sample for missingness;",
            "exact observed/missing margins withheld for registered cross-release protection"
          )
        } else if (as.character(v$type) == "continuous") {
          "observed values for distribution; fixed analytic sample for missingness"
        } else {
          "nonmissing values for weighted percentage; fixed analytic sample for missingness"
        },
        stringsAsFactors = FALSE
      )
    }
  }
  do.call(rbind, rows)
}

static_preflight <- function(root, spec, contract, require_proposal = TRUE) {
  spec_output_paths <- output_paths_from_spec(spec)
  contract_output_paths <- as.character(unlist(contract$exact_public_file_set, use.names = FALSE))
  schema_path_keys <- setdiff(names(contract$output_schemas), "qa")
  schema_paths <- vapply(schema_path_keys, function(key) {
    as.character(contract$output_schemas[[key]]$path)
  }, character(1))
  schema_columns_all <- as.character(unlist(lapply(
    contract$output_schemas,
    function(schema) schema$required_columns
  ), use.names = FALSE))
  prohibited_columns <- as.character(unlist(
    contract$privacy$prohibited_public_columns, use.names = FALSE
  ))
  checks <- c(
    identical(as.character(spec$version), "v44.2"),
    identical(as.character(contract$version), "v44.2"),
    identical(as.character(spec$analysis_id), "baseline_characteristics_additive_v44_2"),
    identical(as.character(contract$analysis_id), "baseline_characteristics_additive_v44_2"),
    isTRUE(spec$governance$runtime_must_exactly_match_frozen_renv_lock),
    identical(length(spec$groups), 1L),
    identical(as.character(spec$groups[[1]]$id), "overall"),
    length(spec$variables$CHARLS) == 23L,
    length(spec$variables$NHANES) == 20L,
    sum(vapply(spec$variables$CHARLS, variable_display_rows, integer(1))) == 28L,
    sum(vapply(spec$variables$NHANES, variable_display_rows, integer(1))) == 32L,
    sum(vapply(c(spec$variables$CHARLS, spec$variables$NHANES), function(v) {
      if (identical(as.character(v$display_role), "main")) variable_display_rows(v) else 0L
    }, integer(1))) == 44L,
    identical(as.integer(spec$expected_cardinality$characteristics_long), 60L),
    identical(as.integer(spec$expected_cardinality$missingness), 43L),
    identical(as.integer(spec$expected_cardinality$variable_dictionary), 43L),
    identical(as.integer(spec$expected_cardinality$main_table_source), 44L),
    identical(as.integer(spec$expected_cardinality$design_audit), 2L),
    identical(as.integer(spec$expected_cardinality$validation), 20L),
    identical(as.integer(spec$expected_cardinality$manifest), 28L),
    identical(as.integer(spec$expected_cardinality$exact_public_files), 8L),
    identical(as.integer(contract$output_schemas$characteristics_long$rows), 60L),
    identical(as.integer(contract$output_schemas$missingness$rows), 43L),
    identical(as.integer(contract$output_schemas$variable_dictionary$rows), 43L),
    identical(as.integer(contract$output_schemas$main_table_source$rows), 44L),
    identical(as.integer(contract$output_schemas$design_audit$rows), 2L),
    identical(as.integer(contract$output_schemas$validation$rows), 20L),
    identical(as.integer(contract$output_schemas$manifest$rows), 28L),
    identical(as.character(spec$disclosure_control$protected_display_token),
              "Suppressed"),
    identical(spec$disclosure_control$reveal_primary_vs_complementary_role, FALSE),
    isTRUE(contract$privacy$suppress_every_other_positive_partition_cell_when_any_primary_exists),
    identical(as.character(contract$privacy$protected_display_token), "Suppressed"),
    identical(contract$privacy$reveal_primary_vs_complementary_role, FALSE),
    identical(length(spec_output_paths), 8L),
    !anyDuplicated(spec_output_paths),
    setequal(spec_output_paths, contract_output_paths),
    setequal(setdiff(spec_output_paths, as.character(contract$output_schemas$qa$path)),
             schema_paths),
    !any(prohibited_columns %in% schema_columns_all),
    !any(grepl("event_stratified|no_observed_death|observed_death",
               spec_output_paths, ignore.case = TRUE)),
    !any(vapply(c(spec$variables$CHARLS, spec$variables$NHANES), function(v) {
      as.character(v$source_field) %in% c("event_any", "death", "event_anchor")
    }, logical(1))),
    all(vapply(c(spec$variables$CHARLS, spec$variables$NHANES), function(v) {
      nzchar(as.character(v$id)) && nzchar(as.character(v$source_field)) &&
        as.character(v$type) %in% c("continuous", "binary", "categorical") &&
        as.character(v$display_role) %in% c("main", "supplement")
    }, logical(1))),
    all(vapply(c(spec$variables$CHARLS, spec$variables$NHANES), function(v) {
      type <- as.character(v$type)
      if (type == "categorical") {
        values <- vapply(v$levels, function(level) as.character(level$value), character(1))
        labels <- vapply(v$levels, function(level) as.character(level$label), character(1))
        length(values) >= 2L && !anyDuplicated(values) &&
          all(nzchar(values)) && all(nzchar(labels))
      } else if (type == "binary") {
        isTRUE(suppressWarnings(as.numeric(v$positive_value)) %in% 0:1) &&
          nzchar(as.character(v$positive_label))
      } else {
        TRUE
      }
    }, logical(1))),
    sum(vapply(c(spec$variables$CHARLS, spec$variables$NHANES), function(v) {
      identical(as.character(v$id), "lower_pef_sex_sd") &&
        identical(as.character(v$display_role), "supplement")
    }, logical(1))) == 2L,
    identical(
      vapply(spec$variables$CHARLS, function(v) {
        isTRUE(v$cross_release_margin_suppression)
      }, logical(1)),
      vapply(spec$variables$CHARLS, function(v) {
        as.character(v$id) %in% c("height_cm", "bmi_kg_m2")
      }, logical(1))
    ),
    !any(vapply(spec$variables$NHANES, function(v) {
      isTRUE(v$cross_release_margin_suppression)
    }, logical(1))),
    all(vapply(c("digest", "survey", "yaml"), requireNamespace, logical(1), quietly = TRUE))
  )
  if (!all(checks)) stop("v44.2 static specification/contract preflight failed.", call. = FALSE)

  dict <- flatten_variable_dictionary(spec)
  if (nrow(dict) != 43L || anyDuplicated(paste(dict$cohort, dict$variable_id)) ||
      anyDuplicated(paste(dict$cohort, dict$variable_order))) {
    stop("v44.2 variable dictionary is not the exact 43-row unique contract.", call. = FALSE)
  }

  if (isTRUE(require_proposal)) {
    proposal_path <- resolve_path(root, spec$governance$authorization_proposal)
    if (!file.exists(proposal_path)) {
      stop("v44.2 authorization proposal is missing.", call. = FALSE)
    }
    proposal <- read_csv_exact(proposal_path)
    proposal_check <- validate_proposal_rows_without_sensitive_reads(
      root,
      proposal,
      expected_proposal_assets(),
      c("asset", "path", "exists", "bytes", "sha256", "governance_role", "proposal_status")
    )
    if (!proposal_check$pass ||
        !all(proposal$proposal_status == "PROPOSED_NOT_AUTHORIZED")) {
      stop("v44.2 authorization proposal is not current: ", proposal_check$detail, call. = FALSE)
    }
  }
  invisible(TRUE)
}

validate_formal_authorization <- function(root, spec) {
  registry_path <- resolve_path(root, spec$governance$formal_authorization_registry)
  if (!file.exists(registry_path)) {
    stop("v44.2 is not authorized: final authorization registry is absent.", call. = FALSE)
  }
  supplied <- trimws(Sys.getenv(spec$governance$authorization_environment_variable, unset = ""))
  current_root <- sha256_file(registry_path)
  if (!grepl("^[0-9a-fA-F]{64}$", supplied) ||
      !identical(tolower(supplied), tolower(current_root))) {
    stop("v44.2 is not authorized: registry SHA-256 environment binding failed.", call. = FALSE)
  }
  registry <- read_csv_exact(registry_path)
  registry_check <- validate_registry_rows(
    root,
    registry,
    expected_final_authorization_assets(),
    c("asset", "path", "exists", "bytes", "sha256", "frozen_at", "governance_role")
  )
  if (!registry_check$pass) {
    stop("v44.2 final authorization registry is not current: ", registry_check$detail, call. = FALSE)
  }
  list(registry = registry, registry_path = registry_path, registry_sha256 = current_root)
}

validate_runtime_lock <- function(root, spec) {
  packages <- c("digest", "survey", "yaml")
  lock_path <- resolve_path(root, spec$inputs$renv_lock)
  lock <- tryCatch(yaml::read_yaml(lock_path), error = function(e) NULL)
  locked_versions <- vapply(packages, function(package) {
    if (is.null(lock) || is.null(lock$Packages[[package]]$Version)) NA_character_
    else as.character(lock$Packages[[package]]$Version)
  }, character(1))
  installed_versions <- vapply(packages, function(package) {
    if (!requireNamespace(package, quietly = TRUE)) NA_character_
    else as.character(utils::packageVersion(package))
  }, character(1))
  package_match <- !is.na(locked_versions) & !is.na(installed_versions) &
    locked_versions == installed_versions
  locked_r <- if (is.null(lock) || is.null(lock$R$Version)) {
    NA_character_
  } else {
    as.character(lock$R$Version)
  }
  installed_r <- as.character(getRversion())
  r_match <- !is.na(locked_r) && identical(locked_r, installed_r)
  list(
    pass = isTRUE(r_match) && all(package_match),
    detail = paste0(
      "R=", locked_r, "/", installed_r, "=", r_match, "; ",
      paste0(
        packages, "=", locked_versions, "/", installed_versions, "=", package_match,
        collapse = "; "
      )
    )
  )
}

numeric_clean <- function(x) {
  source <- if (is.factor(x)) as.character(x) else x
  out <- suppressWarnings(as.numeric(source))
  out[!is.finite(out)] <- NA_real_
  out
}

binary_clean <- function(x, field = "binary field") {
  source <- if (is.factor(x)) as.character(x) else x
  out <- numeric_clean(x)
  observed_input <- !is.na(source) & nzchar(trimws(as.character(source)))
  invalid <- observed_input & (is.na(out) | !(out %in% 0:1))
  if (any(invalid)) {
    stop(field, " contains a nonbinary observed value.", call. = FALSE)
  }
  out
}

char_clean <- function(x) {
  out <- trimws(as.character(x))
  out[is.na(out) | !nzchar(out)] <- NA_character_
  out
}

assert_unique_id <- function(dat, field, source) {
  if (!field %in% names(dat)) {
    stop(source, " lacks required identifier ", field, call. = FALSE)
  }
  clean_id <- char_clean(dat[[field]])
  if (anyNA(clean_id) || anyDuplicated(clean_id)) {
    stop(source, " does not contain one unique nonmissing row per ", field, call. = FALSE)
  }
  invisible(TRUE)
}

derive_charls_smoking <- function(ever, current) {
  ever <- binary_clean(ever)
  current <- binary_clean(current)
  ever[is.na(ever) & current == 1] <- 1
  current[ever == 0] <- 0
  out <- rep(NA_character_, length(ever))
  out[ever == 0 & current == 0] <- "never"
  out[ever == 1 & current == 0] <- "former"
  out[ever == 1 & current == 1] <- "current"
  out
}

prepare_charls <- function(root, spec) {
  ledger <- readRDS(resolve_path(root, spec$inputs$charls_stage3_ledger))
  core <- readRDS(resolve_path(root, spec$inputs$charls_core_covariate_donor))
  if (!is.list(ledger) || !is.data.frame(ledger$person_master) ||
      !is.data.frame(core)) {
    stop("CHARLS Stage 3 ledger structure is invalid.", call. = FALSE)
  }
  master <- ledger$person_master
  assert_unique_id(master, "participant_id", "CHARLS Stage 3 person_master")
  assert_unique_id(core, "participant_id", "CHARLS derived-sensitive core")
  required_master <- c(
    "participant_id", "community_id", "sex_code", "age_w1", "height_m_w1",
    "weight_biomarker_w1", "pef_w1_rowmax", "E0",
    "E0_lower_pef_sex_specific_sd", "event_any", "smoke_ever_w1",
    "smoke_now_w1", "raeducl", "h1rural", "hh1cperc", "lung_w1",
    "asthma_w1", "r1hibpe", "r1diabe", "r1cancre", "r1hearte",
    "r1stroke", "r1kidneye", "frailty_proxy_count_w1", "grip_kg_w1",
    "adl6_score_w1", "cesd10_w1"
  )
  if (length(setdiff(required_master, names(master))) ||
      !all(c("participant_id", "weight_kg_w1") %in% names(core))) {
    stop("CHARLS ledgers lack one or more frozen baseline fields.", call. = FALSE)
  }
  core <- core[, c("participant_id", "weight_kg_w1"), drop = FALSE]
  core_match <- match(master$participant_id, core$participant_id)
  if (anyNA(core_match)) stop("CHARLS core donor join is incomplete.", call. = FALSE)

  raw_height <- numeric_clean(master$height_m_w1)
  raw_weight <- numeric_clean(core$weight_kg_w1[core_match])
  raw_bmi <- ifelse(
    is.finite(raw_height) & raw_height > 0 & is.finite(raw_weight),
    raw_weight / raw_height^2,
    NA_real_
  )
  h_flag <- is.finite(raw_height) & (raw_height < 1.0 | raw_height > 2.7)
  w_flag <- is.finite(raw_weight) & (raw_weight < 20.0 | raw_weight > 350.0)
  b_flag <- is.finite(raw_bmi) & (raw_bmi < 11.0 | raw_bmi > 75.0)
  any_flag <- h_flag | w_flag | b_flag
  clean_height <- ifelse(any_flag, NA_real_, raw_height)
  clean_weight <- ifelse(any_flag, NA_real_, raw_weight)
  clean_bmi <- ifelse(
    is.finite(clean_height) & clean_height > 0 & is.finite(clean_weight),
    clean_weight / clean_height^2,
    NA_real_
  )

  e0 <- numeric_clean(master$E0)
  e0_alias <- numeric_clean(master$E0_lower_pef_sex_specific_sd)
  alias_ok <- identical(is.na(e0), is.na(e0_alias)) &&
    all(abs(e0[!is.na(e0)] - e0_alias[!is.na(e0_alias)]) <= 1e-12)
  if (!alias_ok) stop("CHARLS E0 aliases are not identical.", call. = FALSE)

  education_code <- numeric_clean(master$raeducl)
  education <- rep(NA_character_, nrow(master))
  education[education_code == 0] <- "none"
  education[education_code == 1] <- "less_than_lower_secondary"
  education[education_code == 2] <- "upper_secondary_vocational"
  education[education_code == 3] <- "tertiary"
  cesd <- numeric_clean(master$cesd10_w1)
  frailty <- numeric_clean(master$frailty_proxy_count_w1)
  frailty[!is.na(frailty) & (frailty < 0 | frailty > 5)] <- NA_real_
  sex_code <- numeric_clean(master$sex_code)
  if (any(is.na(sex_code) | !(sex_code %in% 1:2))) {
    stop("CHARLS frozen analytic rows do not all have registered sex codes.",
         call. = FALSE)
  }

  dat <- data.frame(
    participant_key = char_clean(master$participant_id),
    community_id = char_clean(master$community_id),
    analysis_domain = TRUE,
    event_anchor = binary_clean(master$event_any),
    analysis_weight = numeric_clean(master$weight_biomarker_w1),
    age_years = numeric_clean(master$age_w1),
    female = as.numeric(sex_code == 2),
    height_cm = clean_height * 100,
    bmi_kg_m2 = clean_bmi,
    pef_l_min = numeric_clean(master$pef_w1_rowmax),
    lower_pef_sex_sd = e0,
    smoking_status = derive_charls_smoking(master$smoke_ever_w1, master$smoke_now_w1),
    education = education,
    rural_residence = binary_clean(master$h1rural),
    household_consumption_per_capita = numeric_clean(master$hh1cperc),
    chronic_lung_disease = binary_clean(master$lung_w1),
    asthma = binary_clean(master$asthma_w1),
    hypertension = binary_clean(master$r1hibpe),
    diabetes = binary_clean(master$r1diabe),
    cancer = binary_clean(master$r1cancre),
    heart_disease = binary_clean(master$r1hearte),
    stroke = binary_clean(master$r1stroke),
    kidney_disease = binary_clean(master$r1kidneye),
    frailty_proxy_count = frailty,
    grip_strength_kg = numeric_clean(master$grip_kg_w1),
    adl6_score = numeric_clean(master$adl6_score_w1),
    cesd10_score = cesd,
    depressive_symptoms = ifelse(is.finite(cesd), as.numeric(cesd >= 10), NA_real_),
    stringsAsFactors = FALSE
  )
  if (any(!is.na(dat$household_consumption_per_capita) &
          dat$household_consumption_per_capita < 0)) {
    stop("CHARLS household consumption contains a negative observed value.", call. = FALSE)
  }
  attr(dat, "anthropometric_internal") <- list(
    raw_height_observed = sum(is.finite(raw_height)),
    raw_weight_observed = sum(is.finite(raw_weight)),
    height_flag_n = sum(h_flag),
    weight_flag_n = sum(w_flag),
    bmi_flag_n = sum(b_flag),
    any_flag_n = sum(any_flag),
    postclean_height_missing_n = sum(!is.finite(clean_height)),
    postclean_weight_missing_n = sum(!is.finite(clean_weight))
  )
  dat
}

prepare_nhanes <- function(root, spec) {
  ledger <- readRDS(resolve_path(root, spec$inputs$nhanes_stage3_ledger))
  if (!is.list(ledger) || !is.data.frame(ledger$full_mec_design_backbone) ||
      is.null(ledger$primary_domain_ids)) {
    stop("NHANES Stage 3 ledger structure is invalid.", call. = FALSE)
  }
  master <- ledger$full_mec_design_backbone
  assert_unique_id(master, "SEQN", "NHANES full MEC design backbone")
  required <- c(
    "SEQN", "design_psu", "design_strata", "wtmec6yr", "primary_domain",
    "death", "RIDAGEYR", "RIAGENDR", "race_ethnicity", "height_cm",
    "bmi", "pef_l_min", "E0", "smoking_status", "education",
    "income_poverty_ratio", "self_reported_emphysema_or_bronchitis",
    "ever_asthma", "waist_cm", "phq9_score", "low_physical_activity",
    "mobility_difficulty_routed", "adl_iadl_difficulty_routed", "cycle_label"
  )
  if (length(setdiff(required, names(master)))) {
    stop("NHANES design backbone lacks one or more frozen baseline fields.", call. = FALSE)
  }
  domain_ids <- numeric_clean(ledger$primary_domain_ids)
  local_ids <- numeric_clean(master$SEQN[master$primary_domain %in% TRUE])
  if (!setequal(domain_ids, local_ids) || length(domain_ids) != length(local_ids)) {
    stop("NHANES primary-domain IDs do not match the frozen ledger domain flag.", call. = FALSE)
  }
  phq <- numeric_clean(master$phq9_score)
  low_activity <- binary_clean(master$low_physical_activity)
  mobility <- binary_clean(master$mobility_difficulty_routed)
  adl <- binary_clean(master$adl_iadl_difficulty_routed)
  depressive <- ifelse(is.finite(phq), as.numeric(phq >= 10), NA_real_)
  component_matrix <- cbind(low_activity, mobility, adl, depressive)
  function_count <- ifelse(
    rowSums(is.na(component_matrix)) == 0L,
    rowSums(component_matrix),
    NA_real_
  )
  sex_code <- numeric_clean(master$RIAGENDR)
  if (any(is.na(sex_code) | !(sex_code %in% 1:2))) {
    stop("NHANES full MEC backbone does not have registered sex codes.",
         call. = FALSE)
  }
  seqn <- numeric_clean(master$SEQN)
  if (anyNA(seqn) || anyDuplicated(seqn)) {
    stop("NHANES SEQN is not an exact unique numeric participant key.",
         call. = FALSE)
  }
  dat <- data.frame(
    participant_key = seqn,
    design_psu = factor(master$design_psu),
    design_strata = factor(master$design_strata),
    analysis_domain = master$primary_domain %in% TRUE,
    event_anchor = binary_clean(master$death),
    analysis_weight = numeric_clean(master$wtmec6yr),
    age_years = numeric_clean(master$RIDAGEYR),
    female = as.numeric(sex_code == 2),
    race_ethnicity = char_clean(master$race_ethnicity),
    height_cm = numeric_clean(master$height_cm),
    bmi_kg_m2 = numeric_clean(master$bmi),
    pef_l_min = numeric_clean(master$pef_l_min),
    lower_pef_sex_sd = numeric_clean(master$E0),
    smoking_status = char_clean(master$smoking_status),
    education = char_clean(master$education),
    income_poverty_ratio = numeric_clean(master$income_poverty_ratio),
    emphysema_or_chronic_bronchitis =
      binary_clean(master$self_reported_emphysema_or_bronchitis),
    ever_asthma = binary_clean(master$ever_asthma),
    waist_cm = numeric_clean(master$waist_cm),
    phq9_score = phq,
    depressive_symptoms = depressive,
    low_physical_activity = low_activity,
    mobility_difficulty = mobility,
    adl_iadl_difficulty = adl,
    function_health_proxy_count = function_count,
    survey_cycle = char_clean(master$cycle_label),
    stringsAsFactors = FALSE
  )
  dat
}

make_design <- function(dat, cohort) {
  if (any(!is.finite(dat$analysis_weight)) || any(dat$analysis_weight <= 0)) {
    stop(cohort, " descriptive design contains an invalid sampling weight.",
         call. = FALSE)
  }
  if (cohort == "CHARLS") {
    if (anyNA(dat$community_id) || any(!nzchar(dat$community_id))) {
      stop("CHARLS descriptive design contains a missing community PSU.",
           call. = FALSE)
    }
    survey::svydesign(
      ids = ~community_id,
      weights = ~analysis_weight,
      data = dat,
      nest = TRUE
    )
  } else if (cohort == "NHANES") {
    if (anyNA(dat$design_psu) || anyNA(dat$design_strata)) {
      stop("NHANES full MEC design contains a missing PSU or stratum.",
           call. = FALSE)
    }
    survey::svydesign(
      ids = ~design_psu,
      strata = ~design_strata,
      weights = ~analysis_weight,
      data = dat,
      nest = TRUE
    )
  } else {
    stop("Unknown cohort for survey design.", call. = FALSE)
  }
}

critical_value <- function(design) {
  df <- suppressWarnings(as.numeric(survey::degf(design)))
  if (length(df) == 1L && is.finite(df) && df > 0) stats::qt(0.975, df) else stats::qnorm(0.975)
}

survey_continuous <- function(design, data, index, field) {
  observed <- index & is.finite(data[[field]])
  n_observed <- sum(observed)
  if (n_observed == 0L) {
    return(c(
      estimate = NA_real_, standard_error = NA_real_, standard_deviation = NA_real_,
      ci_low = NA_real_, ci_high = NA_real_, weighted_q25 = NA_real_,
      weighted_median = NA_real_, weighted_q75 = NA_real_
    ))
  }
  obs_design <- design[observed, ]
  formula <- stats::reformulate(field)
  mean_obj <- survey::svymean(formula, obs_design, na.rm = TRUE)
  variance_obj <- survey::svyvar(formula, obs_design, na.rm = TRUE)
  quantile_obj <- survey::svyquantile(
    formula, obs_design, quantiles = c(0.25, 0.5, 0.75),
    ci = FALSE, na.rm = TRUE
  )
  estimate <- unname(as.numeric(stats::coef(mean_obj)[[1]]))
  se <- unname(as.numeric(survey::SE(mean_obj)[[1]]))
  variance <- unname(as.numeric(variance_obj)[[1]])
  quantiles <- as.numeric(quantile_obj[[1]])
  if (length(quantiles) != 3L) {
    stop("Survey quantile did not return exactly Q1/median/Q3 for ", field, call. = FALSE)
  }
  critical <- critical_value(obs_design)
  c(
    estimate = estimate,
    standard_error = se,
    standard_deviation = sqrt(max(0, variance)),
    ci_low = estimate - critical * se,
    ci_high = estimate + critical * se,
    weighted_q25 = quantiles[[1]],
    weighted_median = quantiles[[2]],
    weighted_q75 = quantiles[[3]]
  )
}

survey_indicator <- function(design, data, index, field, target) {
  observed <- index & !is.na(data[[field]])
  n_observed <- sum(observed)
  if (n_observed == 0L) {
    return(c(estimate = NA_real_, standard_error = NA_real_, ci_low = NA_real_, ci_high = NA_real_))
  }
  indicator <- rep(NA_real_, nrow(data))
  indicator[observed] <- as.numeric(as.character(data[[field]][observed]) == as.character(target))
  local_data <- data
  local_data$.v44_2_indicator <- indicator
  # Rebuild only the variable column inside the already specified design; the
  # design topology and weights are unchanged, and the observed-value subset
  # remains a survey domain of the original design.
  indicator_design <- design
  indicator_design$variables$.v44_2_indicator <- local_data$.v44_2_indicator
  obs_design <- indicator_design[observed, ]
  mean_obj <- survey::svymean(~.v44_2_indicator, obs_design, na.rm = TRUE)
  estimate <- unname(as.numeric(stats::coef(mean_obj)[[1]]))
  se <- unname(as.numeric(survey::SE(mean_obj)[[1]]))
  critical <- critical_value(obs_design)
  c(
    estimate = estimate,
    standard_error = se,
    ci_low = max(0, estimate - critical * se),
    ci_high = min(1, estimate + critical * se)
  )
}

weighted_missing_percent <- function(design, index, missing) {
  weights <- suppressWarnings(as.numeric(stats::weights(design, type = "sampling")))
  if (length(weights) != length(index) || any(!is.finite(weights[index])) ||
      any(weights[index] <= 0)) {
    stop("Survey weights are invalid in a requested descriptive domain.", call. = FALSE)
  }
  100 * sum(weights[index & missing]) / sum(weights[index])
}

cell_suppression <- function(counts, threshold = 5L) {
  if (is.null(names(counts)) || anyNA(counts) || any(counts < 0)) {
    stop("Disclosure-control counts are invalid.", call. = FALSE)
  }
  primary <- counts > 0 & counts < threshold
  complementary <- rep(FALSE, length(counts))
  names(complementary) <- names(counts)
  if (any(primary)) {
    complementary[counts > 0 & !primary] <- TRUE
    if (!any(complementary) && sum(counts) >= threshold) {
      stop("Disclosure partition has primary cells but no eligible complement.",
           call. = FALSE)
    }
  }
  suppressed <- primary | complementary
  if (any(primary) && !all(suppressed[counts > 0])) {
    stop("Positive disclosure cells remain visible beside a primary cell.",
         call. = FALSE)
  }
  list(primary = primary, complementary = complementary, suppressed = suppressed)
}

format_number <- function(x, digits = 2L) {
  if (!is.finite(x)) return(NA_character_)
  formatC(x, format = "f", digits = digits, big.mark = ",")
}

format_count <- function(n, suppressed = FALSE) {
  if (isTRUE(suppressed)) return("Suppressed")
  if (!is.finite(n)) return(NA_character_)
  format(as.integer(n), scientific = FALSE, trim = TRUE, big.mark = ",")
}

missing_disclosure <- function(n_total, n_observed, variable_type, level_counts = NULL,
                               threshold = 5L) {
  missing_n <- n_total - n_observed
  if (variable_type == "continuous") {
    observed_small <- n_observed > 0L && n_observed < threshold
    missing_small <- missing_n > 0L && missing_n < threshold
    protected <- observed_small || missing_small
    return(list(
      n_observed_suppressed = protected,
      n_observed_primary = observed_small,
      missing_suppressed = protected,
      missing_primary = missing_small,
      missing_complementary = observed_small && !missing_small,
      level_suppression = NULL
    ))
  }
  counts <- c(level_counts, missing = missing_n)
  suppression <- cell_suppression(counts, threshold)
  list(
    n_observed_suppressed = any(suppression$suppressed[names(level_counts)]),
    n_observed_primary = FALSE,
    missing_suppressed = isTRUE(suppression$suppressed[["missing"]]),
    missing_primary = isTRUE(suppression$primary[["missing"]]),
    missing_complementary = isTRUE(suppression$complementary[["missing"]]),
    level_suppression = suppression
  )
}

summary_row_template <- function(cohort, n_total, events, variable, level_order,
                                 level_id, level_label) {
  data.frame(
    cohort = cohort,
    group_id = "overall",
    group_label = "Overall",
    group_n_unweighted = as.integer(n_total),
    group_events_unweighted = as.integer(events),
    variable_order = as.integer(variable$order),
    variable_id = as.character(variable$id),
    variable_label = as.character(variable$label),
    level_order = as.integer(level_order),
    level_id = as.character(level_id),
    level_label = as.character(level_label),
    variable_type = as.character(variable$type),
    display_role = as.character(variable$display_role),
    summary_rule = as.character(variable$summary_rule),
    estimate = NA_real_,
    standard_error = NA_real_,
    standard_deviation = NA_real_,
    ci_low = NA_real_,
    ci_high = NA_real_,
    weighted_q25 = NA_real_,
    weighted_median = NA_real_,
    weighted_q75 = NA_real_,
    unit = as.character(variable$unit),
    n_observed_unweighted = NA_integer_,
    n_observed_display = NA_character_,
    missing_n_unweighted = NA_integer_,
    missing_n_display = NA_character_,
    display_value = NA_character_,
    descriptive_source = "observed_post_routing_or_registered_qc_pre_imputation",
    association_model_handling = as.character(variable$association_model_handling),
    denominator_rule = if (isTRUE(variable$cross_release_margin_suppression)) {
      paste(
        "observed values for distribution; fixed analytic sample for missingness;",
        "exact observed/missing margins withheld for registered cross-release protection"
      )
    } else if (as.character(variable$type) == "continuous") {
      "observed values for distribution; fixed analytic sample for missingness"
    } else {
      "nonmissing values for weighted percentage; fixed analytic sample for missingness"
    },
    design_rule = if (cohort == "CHARLS") {
      "biomarker weight; community PSU; no invented public stratum"
    } else {
      "full positive-weight MEC design before A-only and observed-value domains"
    },
    disclosure_status = "OK",
    reliability_status = "OK",
    stringsAsFactors = FALSE
  )
}

summarize_variable <- function(cohort, variable, data, design, index, threshold,
                               nhanes_reliability_n) {
  field <- as.character(variable$source_field)
  if (!field %in% names(data)) {
    stop(cohort, " prepared data lack registered field ", field, call. = FALSE)
  }
  n_total <- sum(index)
  events <- sum(data$event_anchor[index] == 1, na.rm = TRUE)
  type <- as.character(variable$type)
  x <- data[[field]]
  observed <- index & !is.na(x)
  if (type == "continuous") observed <- index & is.finite(x)
  n_observed <- sum(observed)
  missing_n <- n_total - n_observed

  if (type == "categorical") {
    registered_values <- vapply(variable$levels, function(level) as.character(level$value), character(1))
    unexpected <- unique(as.character(x[index & !is.na(x)]))
    unexpected <- setdiff(unexpected, registered_values)
    if (length(unexpected)) {
      stop(cohort, "/", variable$id, " contains an unregistered category.", call. = FALSE)
    }
    level_counts <- vapply(registered_values, function(value) {
      sum(index & !is.na(x) & as.character(x) == value)
    }, integer(1))
    names(level_counts) <- paste0("level_", seq_along(level_counts))
  } else if (type == "binary") {
    invalid <- index & !is.na(x) & !(numeric_clean(x) %in% 0:1)
    if (any(invalid)) stop(cohort, "/", variable$id, " contains a nonbinary value.", call. = FALSE)
    positive <- as.character(variable$positive_value)
    level_counts <- c(
      positive = sum(index & !is.na(x) & as.character(x) == positive),
      negative = sum(index & !is.na(x) & as.character(x) != positive)
    )
  } else {
    level_counts <- NULL
  }
  disclosure <- missing_disclosure(
    n_total, n_observed, type, level_counts, threshold
  )
  cross_release <- isTRUE(variable$cross_release_margin_suppression)
  if (cross_release && type != "continuous") {
    stop("Cross-release margin suppression is registered only for continuous variables.",
         call. = FALSE)
  }
  if (cross_release) {
    disclosure$n_observed_suppressed <- TRUE
    disclosure$missing_suppressed <- TRUE
    disclosure$missing_primary <- FALSE
    disclosure$missing_complementary <- FALSE
  }
  missing_percent <- weighted_missing_percent(design, index, !observed)
  if (disclosure$missing_suppressed) missing_percent <- NA_real_

  missing_status <- if (cross_release) {
    "REGISTERED_CROSS_RELEASE_MARGIN_SUPPRESSION"
  } else if (disclosure$n_observed_suppressed || disclosure$missing_suppressed) {
    "REGISTERED_CELL_SUPPRESSION"
  } else {
    "OK"
  }
  missing_row <- data.frame(
    cohort = cohort,
    group_id = "overall",
    group_label = "Overall",
    group_n_unweighted = as.integer(n_total),
    variable_order = as.integer(variable$order),
    variable_id = as.character(variable$id),
    variable_label = as.character(variable$label),
    variable_type = type,
    display_role = as.character(variable$display_role),
    n_observed_unweighted = if (disclosure$n_observed_suppressed) NA_integer_ else as.integer(n_observed),
    n_observed_display = format_count(
      n_observed, disclosure$n_observed_suppressed
    ),
    missing_n_unweighted = if (disclosure$missing_suppressed) NA_integer_ else as.integer(missing_n),
    missing_n_display = format_count(
      missing_n, disclosure$missing_suppressed
    ),
    weighted_missing_percent = missing_percent,
    descriptive_source = "observed_post_routing_or_registered_qc_pre_imputation",
    association_model_handling = as.character(variable$association_model_handling),
    denominator_rule = "fixed analytic sample",
    disclosure_status = missing_status,
    stringsAsFactors = FALSE
  )

  if (type == "continuous") {
    row <- summary_row_template(cohort, n_total, events, variable, 1L, "", "")
    stats <- survey_continuous(design, data, index, field)
    estimate_suppressed <- n_observed > 0L && n_observed < threshold
    if (!estimate_suppressed) {
      row[names(stats)] <- as.list(unname(stats))
    }
    row$n_observed_unweighted <- if (disclosure$n_observed_suppressed) NA_integer_ else as.integer(n_observed)
    row$n_observed_display <- format_count(
      n_observed, disclosure$n_observed_suppressed
    )
    row$missing_n_unweighted <- if (disclosure$missing_suppressed) NA_integer_ else as.integer(missing_n)
    row$missing_n_display <- format_count(
      missing_n, disclosure$missing_suppressed
    )
    if (estimate_suppressed) {
      row$display_value <- "Suppressed"
      row$disclosure_status <- "REGISTERED_CELL_SUPPRESSION"
      row$reliability_status <- "SUPPRESSED"
    } else {
      if (identical(as.character(variable$summary_rule), "weighted_median_iqr")) {
        row$display_value <- paste0(
          format_number(row$weighted_median), " [",
          format_number(row$weighted_q25), ", ", format_number(row$weighted_q75), "]"
        )
      } else {
        row$display_value <- paste0(
          format_number(row$estimate), " (", format_number(row$standard_deviation), ")"
        )
      }
      if (cross_release) {
        row$disclosure_status <- "REGISTERED_CROSS_RELEASE_MARGIN_SUPPRESSION"
      } else if (disclosure$n_observed_suppressed || disclosure$missing_suppressed) {
        row$disclosure_status <- "REGISTERED_MARGIN_SUPPRESSION"
      }
      row$reliability_status <- if (cohort == "NHANES" && n_observed < nhanes_reliability_n) {
        "CAUTION_N_LT30"
      } else {
        "OK"
      }
    }
    return(list(rows = row, missingness = missing_row))
  }

  displayed <- if (type == "binary") {
    list(list(
      value = as.character(variable$positive_value),
      label = as.character(variable$positive_label),
      suppression_name = "positive"
    ))
  } else {
    lapply(seq_along(variable$levels), function(i) list(
      value = as.character(variable$levels[[i]]$value),
      label = as.character(variable$levels[[i]]$label),
      suppression_name = paste0("level_", i)
    ))
  }
  rows <- lapply(seq_along(displayed), function(i) {
    level <- displayed[[i]]
    row <- summary_row_template(
      cohort, n_total, events, variable, i, level$value, level$label
    )
    suppression <- disclosure$level_suppression
    suppressed <- isTRUE(suppression$suppressed[[level$suppression_name]])
    level_n <- sum(index & !is.na(x) & as.character(x) == level$value)
    stats <- survey_indicator(design, data, index, field, level$value)
    if (!suppressed) {
      row$estimate <- 100 * stats[["estimate"]]
      row$standard_error <- 100 * stats[["standard_error"]]
      row$ci_low <- 100 * stats[["ci_low"]]
      row$ci_high <- 100 * stats[["ci_high"]]
      row$n_observed_unweighted <- if (disclosure$n_observed_suppressed) NA_integer_ else as.integer(n_observed)
      row$n_observed_display <- format_count(
        n_observed, disclosure$n_observed_suppressed
      )
      row$display_value <- paste0(
        format_count(level_n, FALSE), " (", format_number(row$estimate, 1L), "%)"
      )
    } else {
      row$n_observed_unweighted <- NA_integer_
      row$n_observed_display <- "Suppressed"
      row$display_value <- "Suppressed"
      row$disclosure_status <- "REGISTERED_CELL_SUPPRESSION"
    }
    row$missing_n_unweighted <- if (disclosure$missing_suppressed) NA_integer_ else as.integer(missing_n)
    row$missing_n_display <- format_count(
      missing_n, disclosure$missing_suppressed
    )
    row$reliability_status <- if (suppressed) {
      "SUPPRESSED"
    } else if (cohort == "NHANES" && level_n < nhanes_reliability_n) {
      "CAUTION_N_LT30"
    } else {
      "OK"
    }
    row
  })
  list(rows = do.call(rbind, rows), missingness = missing_row)
}

summarize_cohort <- function(cohort, data, variables, design, spec) {
  index <- data$analysis_domain %in% TRUE
  n <- sum(index)
  events <- sum(data$event_anchor[index] == 1, na.rm = TRUE)
  expected <- spec$frozen_population_anchors[[cohort]]
  if (n != as.integer(expected$sample_n) || events != as.integer(expected$deaths) ||
      anyNA(data$event_anchor[index]) || any(!data$event_anchor[index] %in% 0:1)) {
    stop(cohort, " frozen N/event anchor failed.", call. = FALSE)
  }
  results <- lapply(variables, function(variable) {
    summarize_variable(
      cohort = cohort,
      variable = variable,
      data = data,
      design = design,
      index = index,
      threshold = as.integer(spec$disclosure_control$primary_threshold),
      nhanes_reliability_n = as.integer(spec$disclosure_control$nhanes_reliability_flag_n)
    )
  })
  long <- do.call(rbind, lapply(results, `[[`, "rows"))
  missingness <- do.call(rbind, lapply(results, `[[`, "missingness"))
  long <- long[order(long$variable_order, long$level_order), , drop = FALSE]
  missingness <- missingness[order(missingness$variable_order), , drop = FALSE]

  domain_design <- design[index, ]
  design_df <- suppressWarnings(as.numeric(survey::degf(domain_design)))
  if (length(design_df) != 1L || !is.finite(design_df) || design_df <= 0) {
    stop(cohort, " overall descriptive design has invalid degrees of freedom.", call. = FALSE)
  }
  sampling_weights <- as.numeric(stats::weights(design, type = "sampling"))
  if (cohort == "CHARLS") {
    strata_n <- NA_integer_
    psu_n <- length(unique(data$community_id[index]))
    weight_name <- "weight_biomarker_w1"
    ids_text <- "community_id"
    construction <- "design constructed in frozen primary sample"
    interpretation <- paste(
      "biomarker-weighted community-PSU-clustered analytic-sample description;",
      "explicit public strata unavailable"
    )
  } else {
    strata_n <- length(unique(data$design_strata[index]))
    psu_n <- length(unique(data$design_psu[index]))
    weight_name <- "wtmec6yr"
    ids_text <- "cycle-specific design_psu"
    construction <- "full positive-weight MEC design constructed before A-only domain subset"
    interpretation <- "full NHANES complex-survey domain description of frozen A-only analytic population"
  }
  design_audit <- data.frame(
    cohort = cohort,
    group_id = "overall",
    group_label = "Overall",
    group_n_unweighted = as.integer(n),
    group_events_unweighted = as.integer(events),
    weighted_population_total = sum(sampling_weights[index]),
    design_weight = weight_name,
    design_ids = ids_text,
    design_strata_n = strata_n,
    design_psu_n = as.integer(psu_n),
    design_df = design_df,
    construction_order = construction,
    target_interpretation = interpretation,
    stringsAsFactors = FALSE
  )
  list(long = long, missingness = missingness, design_audit = design_audit)
}

validate_nhanes_completion_binding <- function(root, spec) {
  manifest <- read_csv_exact(resolve_path(root, spec$inputs$v43_nhanes_completion_manifest))
  required <- c("status", "artifact", "path", "bytes", "sha256")
  if (!all(required %in% names(manifest)) || !all(manifest$status == "COMPLETE")) {
    return(FALSE)
  }
  target <- normalizePath(resolve_path(root, spec$inputs$nhanes_stage3_ledger), mustWork = FALSE)
  manifest_paths <- vapply(as.character(manifest$path), function(path) {
    normalizePath(resolve_path(root, path), mustWork = FALSE)
  }, character(1))
  rows <- which(manifest_paths == target)
  if (length(rows) != 1L) return(FALSE)
  full <- resolve_path(root, manifest$path[[rows]])
  file.exists(full) && !dir.exists(full) &&
    as.numeric(file.info(full)$size) == suppressWarnings(as.numeric(manifest$bytes[[rows]])) &&
    identical(tolower(sha256_file(full)), tolower(as.character(manifest$sha256[[rows]])))
}

validate_v44_completion <- function(root, spec) {
  validation <- read_csv_exact(resolve_path(root, spec$inputs$v44_1_1_validation))
  manifest <- read_csv_exact(resolve_path(root, spec$inputs$v44_1_1_manifest))
  validation_ok <- nrow(validation) == 23L &&
    identical(names(validation), c("check_id", "status", "observed", "expected", "detail")) &&
    all(validation$status == "PASS")
  required <- c("asset", "path", "exists", "bytes", "sha256")
  manifest_ok <- nrow(manifest) == 42L && all(required %in% names(manifest)) &&
    !anyDuplicated(manifest$asset)
  current <- if (manifest_ok) vapply(seq_len(nrow(manifest)), function(i) {
    full <- resolve_path(root, manifest$path[[i]])
    isTRUE(as_flag(manifest$exists[[i]])) && file.exists(full) && !dir.exists(full) &&
      as.numeric(file.info(full)$size) == suppressWarnings(as.numeric(manifest$bytes[[i]])) &&
      identical(tolower(sha256_file(full)), tolower(as.character(manifest$sha256[[i]])))
  }, logical(1)) else FALSE
  list(pass = validation_ok && manifest_ok && all(current),
       detail = paste0("validation=", sum(validation$status == "PASS"), "/", nrow(validation),
                       "; manifest=", if (length(current)) sum(current) else 0L, "/", nrow(manifest)))
}

validate_charls_anthropometric_reconstruction <- function(root, spec, charls_data) {
  audit <- read_csv_exact(resolve_path(root, spec$inputs$v44_1_1_source_audit))
  row <- audit[audit$variant_id == "who_block_no_later_aux", , drop = FALSE]
  internal <- attr(charls_data, "anthropometric_internal", exact = TRUE)
  required <- c(
    "raw_height_observed", "raw_weight_observed", "height_flag_n",
    "weight_flag_n", "bmi_flag_n", "any_flag_n", "postclean_height_missing_n",
    "postclean_weight_missing_n"
  )
  if (nrow(row) != 1L || is.null(internal) || !all(required %in% names(row))) return(FALSE)
  compare_public <- vapply(required, function(field) {
    published <- suppressWarnings(as.numeric(row[[field]][[1]]))
    is.na(published) || identical(as.numeric(internal[[field]]), published)
  }, logical(1))
  published_fields <- suppressWarnings(as.numeric(unlist(row[required], use.names = FALSE)))
  all(compare_public) && isTRUE(as_flag(row$small_cell_suppressed[[1]])) &&
    sum(!is.na(published_fields)) < length(required)
}

validate_nhanes_design_anchor <- function(data, spec) {
  nrow(data) == as.integer(spec$survey_design$NHANES$expected_backbone_n) &&
    length(unique(data$design_strata)) == as.integer(spec$survey_design$NHANES$expected_strata) &&
    length(unique(data$design_psu)) == as.integer(spec$survey_design$NHANES$expected_psu) &&
    all(is.finite(data$analysis_weight) & data$analysis_weight > 0)
}

schema_columns <- function(contract, key) {
  as.character(unlist(contract$output_schemas[[key]]$required_columns, use.names = FALSE))
}

validate_output_schema <- function(dat, contract, key, rows) {
  identical(names(dat), schema_columns(contract, key)) && nrow(dat) == rows
}

privacy_pass <- function(long, missingness, dictionary, main_table, design_audit,
                         contract) {
  protected_rows <- long$disclosure_status == "REGISTERED_CELL_SUPPRESSION"
  protected_estimates_blank <- all(
    is.na(long$estimate[protected_rows]) &
      is.na(long$standard_error[protected_rows]) &
      is.na(long$n_observed_unweighted[protected_rows]) &
      long$display_value[protected_rows] == "Suppressed"
  )
  neutral_suppression_tokens <- all(
    long$display_value[protected_rows] == "Suppressed"
  )
  protected_keys <- unique(paste(
    long$cohort[protected_rows], long$group_id[protected_rows],
    long$variable_id[protected_rows], sep = "|"
  ))
  public_keys <- paste(long$cohort, long$group_id, long$variable_id, sep = "|")
  remaining_partition_rows <- public_keys %in% protected_keys &
    long$variable_type %in% c("binary", "categorical") & !protected_rows
  only_zero_cells_remain_visible <- all(
    grepl("^0 \\(", long$display_value[remaining_partition_rows])
  )
  protected_missing <- missingness$disclosure_status != "OK"
  protected_missing_blank <- all(
    is.na(missingness$missing_n_unweighted[protected_missing]) |
      is.na(missingness$n_observed_unweighted[protected_missing])
  )
  cross_missing <- missingness$disclosure_status ==
    "REGISTERED_CROSS_RELEASE_MARGIN_SUPPRESSION"
  cross_long <- long$disclosure_status ==
    "REGISTERED_CROSS_RELEASE_MARGIN_SUPPRESSION"
  cross_release_blank <- sum(cross_missing) == 2L && sum(cross_long) == 2L &&
    all(missingness$cohort[cross_missing] == "CHARLS") &&
    setequal(missingness$variable_id[cross_missing], c("height_cm", "bmi_kg_m2")) &&
    all(is.na(missingness$n_observed_unweighted[cross_missing])) &&
    all(is.na(missingness$missing_n_unweighted[cross_missing])) &&
    all(is.na(missingness$weighted_missing_percent[cross_missing])) &&
    all(is.na(long$n_observed_unweighted[cross_long])) &&
    all(is.na(long$missing_n_unweighted[cross_long]))
  prohibited <- as.character(unlist(contract$privacy$prohibited_public_columns, use.names = FALSE))
  all_public_names <- c(
    names(long), names(missingness), names(dictionary), names(main_table),
    names(design_audit)
  )
  no_prohibited_columns <- !any(prohibited %in% all_public_names)
  no_inferential_columns <- !any(grepl(
    "(^p(_|$)|p_value|standardized|smd|hazard|odds|effect)",
    all_public_names, ignore.case = TRUE
  ))
  protected_estimates_blank && neutral_suppression_tokens &&
    only_zero_cells_remain_visible &&
    protected_missing_blank && cross_release_blank && no_prohibited_columns &&
    no_inferential_columns
}

finite_range_pass <- function(long) {
  continuous <- long$variable_type == "continuous" & is.finite(long$estimate)
  categorical <- long$variable_type %in% c("binary", "categorical") & is.finite(long$estimate)
  all(is.finite(long$standard_error[continuous]) & long$standard_error[continuous] >= 0) &&
    all(is.finite(long$standard_deviation[continuous]) & long$standard_deviation[continuous] >= 0) &&
    all(is.finite(long$weighted_q25[continuous]) &
          is.finite(long$weighted_median[continuous]) &
          is.finite(long$weighted_q75[continuous]) &
          long$weighted_q25[continuous] <= long$weighted_median[continuous] &
          long$weighted_median[continuous] <= long$weighted_q75[continuous]) &&
    all(long$estimate[categorical] >= 0 & long$estimate[categorical] <= 100) &&
    all(long$ci_low[categorical] >= 0 & long$ci_high[categorical] <= 100)
}

missing_identity_pass <- function(long, missingness) {
  visible <- !is.na(missingness$n_observed_unweighted) &
    !is.na(missingness$missing_n_unweighted)
  visible_ok <- all(
    missingness$n_observed_unweighted[visible] +
      missingness$missing_n_unweighted[visible] ==
      missingness$group_n_unweighted[visible]
  )
  keys_long <- unique(paste(long$cohort, long$group_id, long$variable_id, sep = "|"))
  keys_missing <- paste(missingness$cohort, missingness$group_id,
                        missingness$variable_id, sep = "|")
  visible_ok && setequal(keys_long, keys_missing) && !anyDuplicated(keys_missing)
}

validation_row <- function(check_id, pass, observed, expected, detail) {
  data.frame(
    check_id = check_id,
    status = if (isTRUE(pass)) "PASS" else "FAIL",
    observed = one_line(observed),
    expected = one_line(expected),
    detail = one_line(detail),
    stringsAsFactors = FALSE
  )
}

build_validation <- function(
    root, authorization, runtime_lock, predecessor_v44, predecessor_v43, completion_v44,
    completion_nhanes, charls_data, nhanes_data, charls_design, nhanes_design,
    long, missingness, dictionary, main_table, design_audit, contract, spec) {
  charls_index <- charls_data$analysis_domain %in% TRUE
  nhanes_index <- nhanes_data$analysis_domain %in% TRUE
  charls_anchor <- sum(charls_index) == 12555L &&
    sum(charls_data$event_anchor[charls_index] == 1L) == 1735L
  nhanes_anchor <- sum(nhanes_index) == 6719L &&
    sum(nhanes_data$event_anchor[nhanes_index] == 1L) == 925L
  exact_variables <- nrow(dictionary) == 43L &&
    any(dictionary$variable_id == "lower_pef_sex_sd" &
          dictionary$display_role == "supplement") &&
    !any(dictionary$variable_id == "lower_pef_marker_sd")
  row_counts <- nrow(long) == 60L && nrow(missingness) == 43L &&
    nrow(dictionary) == 43L && nrow(main_table) == 44L &&
    nrow(design_audit) == 2L
  main_exact <- all(main_table$display_role == "main") &&
    all(main_table$group_id == "overall") &&
    !any(main_table$variable_id == "lower_pef_sex_sd") &&
    !any(grepl("death", main_table$group_id, ignore.case = TRUE))
  observed_boundary <- all(
    long$descriptive_source == "observed_post_routing_or_registered_qc_pre_imputation"
  ) && all(nzchar(long$association_model_handling))
  design_ok <- nrow(design_audit) == 2L &&
    all(is.finite(design_audit$weighted_population_total) &
          design_audit$weighted_population_total > 0) &&
    all(design_audit$design_psu_n >= 2L) &&
    all(design_audit$design_df > 0)

  rows <- list(
    validation_row(
      "v44_2_authorization_and_runtime_current", runtime_lock$pass,
      paste("20/20 final authorization assets current;", runtime_lock$detail),
      "20/20 current and environment-bound; R/digest/survey/yaml exactly match renv.lock",
      "Authorization and software-version gates passed before sensitive RDS deserialization."
    ),
    validation_row("v44_1_1_recursive_registry_current", predecessor_v44$pass,
                   predecessor_v44$detail, "29/29 current", "Frozen CHARLS predecessor remains immutable."),
    validation_row("v43_recursive_registry_current", predecessor_v43$pass,
                   predecessor_v43$detail, "25/25 current", "Frozen Stage 3 predecessor remains immutable."),
    validation_row("v44_1_1_completion_bundle_current", completion_v44$pass,
                   completion_v44$detail, "23/23 validation PASS; 42/42 manifest current",
                   "Baseline module is downstream of the accepted CHARLS rerun."),
    validation_row("nhanes_completion_ledger_binding", completion_nhanes,
                   if (completion_nhanes) "current completion-bound ledger" else "binding failure",
                   "one exact current NHANES ledger row", "No source reconstruction from raw XPT files."),
    validation_row("sensitive_object_schema", is.data.frame(charls_data) && is.data.frame(nhanes_data),
                   "two prepared in-memory frames", "two governed inputs", "No participant object is persisted."),
    validation_row("participant_keys_unique", !anyNA(charls_data$participant_key) &&
                     !anyNA(nhanes_data$participant_key) &&
                     !anyDuplicated(charls_data$participant_key) &&
                     !anyDuplicated(nhanes_data$participant_key),
                   "unique within each governed input", "zero duplicates", "Keys never enter public objects."),
    validation_row("frozen_population_event_anchors", charls_anchor && nhanes_anchor,
                   "CHARLS and NHANES N/event anchors matched", "12555/1735 and 6719/925",
                   "Events are used only for this aggregate anchor, never for stratification."),
    validation_row("charls_v44_1_1_who_block_reconstruction",
                   validate_charls_anthropometric_reconstruction(root, spec, charls_data),
                   "internal reconstruction matched; protected counts not emitted",
                   "frozen WHO-block observed state", "Core donor contributes only the weight parent."),
    validation_row("charls_overall_design", survey::degf(charls_design[charls_index, ]) > 0,
                   "positive design df; biomarker weight and community PSU",
                   "overall analytic-sample design", "No public stratum is invented."),
    validation_row("nhanes_full_design_before_domain", validate_nhanes_design_anchor(nhanes_data, spec),
                   "29353-row backbone; 45 strata; 94 PSUs",
                   "full design before A-only domain", "Observed-value summaries use domains of this design."),
    validation_row("registered_variable_contract", exact_variables,
                   "43 fixed variables; neutral lower-PEF audit label",
                   "23 CHARLS + 20 NHANES", "No result-dependent row selection."),
    validation_row("aggregate_row_cardinalities", row_counts,
                   paste0(nrow(long), "/", nrow(missingness), "/", nrow(dictionary),
                          "/", nrow(main_table), "/", nrow(design_audit)),
                   "60/43/43/44/2", "Exact fixed row counts."),
    validation_row("missingness_count_identities", missing_identity_pass(long, missingness),
                   "all internally visible margins reconciled", "observed + missing = group N",
                   "Protected margins remain blank."),
    validation_row("finite_descriptive_estimates", finite_range_pass(long),
                   "finite continuous summaries and bounded percentages",
                   "finite/ordered/bounded when estimable", "Suppressed rows are excluded from numeric checks."),
    validation_row(
      "small_cell_and_complementary_suppression",
      privacy_pass(long, missingness, dictionary, main_table, design_audit, contract),
                   "all protected public payloads blanked",
                   "n=1-4 and all other positive partition cells suppressed with one neutral token",
                   "Missingness participates; every positive cell is neutralized when a primary exists."),
    validation_row(
      "no_inferential_or_identifier_payload",
      privacy_pass(long, missingness, dictionary, main_table, design_audit, contract),
                   "no P/SMD/effect/ID fields", "aggregate descriptive fields only",
                   "The module cannot support result-based baseline testing."),
    validation_row("observed_preimputation_boundary", observed_boundary,
                   "observed available-case summaries with model-handling labels",
                   "no MI-pooled descriptive value", "No imputation or RNG is invoked."),
    validation_row("main_table_outcome_blind_exact", main_exact,
                   "44 overall main rows; raw PEF retained; standardized row omitted",
                   "overall only; no outcome stratum", "Standardized lower PEF remains in audit long output."),
    validation_row("publication_bundle_ready", design_ok && row_counts,
                   "seven non-manifest aggregate assets ready for staging",
                   "exact eight-file bundle after manifest",
                   "Per-file atomic renames and same-run rollback occur only after all gates pass.")
  )
  out <- do.call(rbind, rows)
  if (nrow(out) != 20L || anyDuplicated(out$check_id) || !all(out$status == "PASS")) {
    stop("One or more v44.2 validation hard gates failed.", call. = FALSE)
  }
  out
}

write_csv_stage <- function(dat, path) {
  dir.create(dirname(path), recursive = TRUE, showWarnings = FALSE)
  utils::write.csv(dat, path, row.names = FALSE, na = "")
  if (!file.exists(path) || file.info(path)$size <= 0) {
    stop("Could not write nonempty staged CSV: ", path, call. = FALSE)
  }
  invisible(path)
}

write_lines_stage <- function(lines, path) {
  dir.create(dirname(path), recursive = TRUE, showWarnings = FALSE)
  writeLines(lines, path, useBytes = TRUE)
  if (!file.exists(path) || file.info(path)$size <= 0) {
    stop("Could not write nonempty staged text: ", path, call. = FALSE)
  }
  invisible(path)
}

qa_lines <- function(validation, design_audit, long, missingness, authorization_sha, run_id) {
  suppressed_characteristics <- sum(long$disclosure_status != "OK")
  protected_missingness <- sum(missingness$disclosure_status != "OK")
  c(
    "# v44.2 baseline-characteristics aggregate QA",
    "",
    paste0("Run ID: `", run_id, "`  "),
    paste0("Authorization registry SHA-256: `", authorization_sha, "`"),
    "",
    "## Scope",
    "",
    paste(
      "This additive module supplies the manuscript baseline Table 1 for the",
      "frozen CHARLS v44.1.1 and NHANES v43 primary mortality populations."
    ),
    paste(
      "It reports observed/pre-imputation available-case descriptions and",
      "explicit missingness. It does not fit a model, run imputation, generate",
      "a P value, calculate an SMD, or stratify any characteristic by outcome."
    ),
    "",
    "## Frozen anchors and design",
    "",
    paste0(
      "- CHARLS: N=", design_audit$group_n_unweighted[design_audit$cohort == "CHARLS"],
      "; events=", design_audit$group_events_unweighted[design_audit$cohort == "CHARLS"],
      "; biomarker weight; community PSU; no invented public stratum."
    ),
    paste0(
      "- NHANES: N=", design_audit$group_n_unweighted[design_audit$cohort == "NHANES"],
      "; events=", design_audit$group_events_unweighted[design_audit$cohort == "NHANES"],
      "; full 29,353-row positive-weight MEC design before A-only domain; 45 strata and 94 PSUs."
    ),
    "",
    "## Reporting boundary",
    "",
    "- Main Table 1 contains exactly 44 fixed overall rows.",
    "- Raw PEF remains in the main table. The standardized lower-PEF quantity is retained only in the audit aggregate and dictionary.",
    "- Continuous display values are weighted mean (weighted SD), except prespecified skewed variables shown as weighted median [Q1, Q3].",
    "- Categorical display values are unweighted n (design-weighted %), using nonmissing values as the percentage denominator.",
    "- Association-model missing-data handling is labeled separately; no completed dataset is summarized here.",
    "",
    "## Disclosure control",
    "",
    paste0("- Characteristic rows with a disclosure action: ", suppressed_characteristics, "."),
    paste0("- Variable missingness rows with a disclosure action: ", protected_missingness, "."),
    paste(
      "- If any categorical partition cell is 1-4, all positive cells in that",
      "partition use the neutral token Suppressed; primary/complement roles are not disclosed."
    ),
    "- Registered CHARLS post-QC height/BMI margins are withheld for cross-release protection.",
    "- No participant-level object is persisted.",
    "",
    "## Validation",
    "",
    paste0("All ", nrow(validation), " registered validation checks: **PASS**."),
    "",
    "This QA file intentionally does not duplicate the characteristic estimates. Use the registered aggregate CSV sources."
  )
}

manifest_rows <- function(root, authorization, staged_assets, finalized_at, run_id) {
  package_versions <- paste0(
    "digest=", as.character(utils::packageVersion("digest")), ";",
    "survey=", as.character(utils::packageVersion("survey")), ";",
    "yaml=", as.character(utils::packageVersion("yaml"))
  )
  registry <- authorization$registry
  auth_rows <- data.frame(
    asset = as.character(registry$asset),
    path = as.character(registry$path),
    exists = TRUE,
    bytes = suppressWarnings(as.numeric(registry$bytes)),
    sha256 = as.character(registry$sha256),
    stringsAsFactors = FALSE
  )
  registry_row <- file_record(
    root, "authorization_registry",
    "work_v44/baseline_characteristics_authorization_hashes_v44_2.csv"
  )[, c("asset", "path", "exists", "bytes", "sha256")]
  output_rows <- do.call(rbind, lapply(names(staged_assets), function(asset) {
    info <- staged_assets[[asset]]
    data.frame(
      asset = asset,
      path = info$final_relative,
      exists = file.exists(info$staged_path),
      bytes = as.numeric(file.info(info$staged_path)$size),
      sha256 = sha256_file(info$staged_path),
      stringsAsFactors = FALSE
    )
  }))
  out <- rbind(auth_rows, registry_row, output_rows)
  out$finalized_at <- finalized_at
  out$run_id <- run_id
  out$authorization_id <- "baseline_characteristics_additive_v44_2"
  out$authorization_registry_sha256 <- authorization$registry_sha256
  out$r_version <- R.version.string
  out$package_versions <- package_versions
  out
}

promote_bundle <- function(root, staging_root, relative_paths) {
  promoted <- character()
  ok <- tryCatch({
    for (relative in relative_paths) {
      source <- file.path(staging_root, relative)
      target <- resolve_path(root, relative)
      if (!file.exists(source) || file.info(source)$size <= 0 || file.exists(target)) {
        stop("Publication target is unavailable for staged promotion: ", relative, call. = FALSE)
      }
      dir.create(dirname(target), recursive = TRUE, showWarnings = FALSE)
      if (!file.rename(source, target)) {
        stop("Could not promote staged file with an atomic rename: ", relative, call. = FALSE)
      }
      promoted <- c(promoted, target)
    }
    TRUE
  }, error = function(e) e)
  if (inherits(ok, "error")) {
    unlink(promoted, force = TRUE)
    stop(conditionMessage(ok), " All current-run public files were removed.", call. = FALSE)
  }
  unlink(staging_root, recursive = TRUE, force = TRUE)
  invisible(TRUE)
}

run_formal_v44_2 <- function(root, spec, contract, authorization, runtime_lock,
                             predecessor_v44, predecessor_v43, completion_v44,
                             completion_nhanes) {
  charls_data <- prepare_charls(root, spec)
  nhanes_data <- prepare_nhanes(root, spec)
  if (nrow(charls_data) != 12555L || nrow(nhanes_data) != 29353L) {
    stop("Prepared cohort row anchors failed.", call. = FALSE)
  }
  prior_survey_options <- options(
    survey.lonely.psu = "adjust",
    survey.adjust.domain.lonely = TRUE
  )
  on.exit(options(prior_survey_options), add = TRUE)
  charls_design <- make_design(charls_data, "CHARLS")
  nhanes_design <- make_design(nhanes_data, "NHANES")
  charls_summary <- summarize_cohort(
    "CHARLS", charls_data, spec$variables$CHARLS, charls_design, spec
  )
  nhanes_summary <- summarize_cohort(
    "NHANES", nhanes_data, spec$variables$NHANES, nhanes_design, spec
  )
  long <- rbind(charls_summary$long, nhanes_summary$long)
  missingness <- rbind(charls_summary$missingness, nhanes_summary$missingness)
  dictionary <- flatten_variable_dictionary(spec)
  main_table <- long[long$display_role == "main", , drop = FALSE]
  design_audit <- rbind(charls_summary$design_audit, nhanes_summary$design_audit)

  long <- long[order(match(long$cohort, c("CHARLS", "NHANES")),
                     long$variable_order, long$level_order), , drop = FALSE]
  missingness <- missingness[order(match(missingness$cohort, c("CHARLS", "NHANES")),
                                   missingness$variable_order), , drop = FALSE]
  dictionary <- dictionary[order(match(dictionary$cohort, c("CHARLS", "NHANES")),
                                 dictionary$variable_order), , drop = FALSE]
  main_table <- main_table[order(match(main_table$cohort, c("CHARLS", "NHANES")),
                                 main_table$variable_order, main_table$level_order), , drop = FALSE]
  rownames(long) <- rownames(missingness) <- rownames(dictionary) <-
    rownames(main_table) <- rownames(design_audit) <- NULL

  validation <- build_validation(
    root, authorization, runtime_lock, predecessor_v44, predecessor_v43, completion_v44,
    completion_nhanes, charls_data, nhanes_data, charls_design, nhanes_design,
    long, missingness, dictionary, main_table, design_audit, contract, spec
  )

  expected_rows <- spec$expected_cardinality
  schema_checks <- c(
    validate_output_schema(long, contract, "characteristics_long", as.integer(expected_rows$characteristics_long)),
    validate_output_schema(missingness, contract, "missingness", as.integer(expected_rows$missingness)),
    validate_output_schema(dictionary, contract, "variable_dictionary", as.integer(expected_rows$variable_dictionary)),
    validate_output_schema(main_table, contract, "main_table_source", as.integer(expected_rows$main_table_source)),
    validate_output_schema(design_audit, contract, "design_audit", as.integer(expected_rows$design_audit)),
    validate_output_schema(validation, contract, "validation", as.integer(expected_rows$validation))
  )
  if (!all(schema_checks)) stop("One or more prepublication output schemas failed.", call. = FALSE)

  run_id <- paste0(
    "baseline_v44_2_", format(Sys.time(), "%Y%m%dT%H%M%S", tz = "Asia/Shanghai"),
    "_pid", Sys.getpid()
  )
  staging_base <- resolve_path(root, spec$outputs$staging_directory)
  staging_root <- file.path(staging_base, run_id)
  if (dir.exists(staging_root)) stop("Current v44.2 staging run already exists.", call. = FALSE)
  dir.create(staging_root, recursive = TRUE, showWarnings = FALSE)
  completed <- FALSE
  on.exit(if (!completed && dir.exists(staging_root)) {
    unlink(staging_root, recursive = TRUE, force = TRUE)
  }, add = TRUE)

  object_map <- list(
    baseline_characteristics_long_v44_2 = list(
      data = long, relative = spec$outputs$files$characteristics_long),
    baseline_missingness_v44_2 = list(
      data = missingness, relative = spec$outputs$files$missingness),
    baseline_variable_dictionary_v44_2 = list(
      data = dictionary, relative = spec$outputs$files$variable_dictionary),
    table1_baseline_characteristics_source_v44_2 = list(
      data = main_table, relative = spec$outputs$files$main_table_source),
    baseline_design_audit_v44_2 = list(
      data = design_audit, relative = spec$outputs$files$design_audit),
    baseline_validation_v44_2 = list(
      data = validation, relative = spec$outputs$files$validation)
  )
  for (asset in names(object_map)) {
    object_map[[asset]]$staged_path <- file.path(staging_root, object_map[[asset]]$relative)
    write_csv_stage(object_map[[asset]]$data, object_map[[asset]]$staged_path)
  }
  qa_path <- file.path(staging_root, spec$outputs$files$qa)
  write_lines_stage(
    qa_lines(validation, design_audit, long, missingness,
             authorization$registry_sha256, run_id),
    qa_path
  )
  object_map$BASELINE_CHARACTERISTICS_QA_v44_2 <- list(
    final_relative = spec$outputs$files$qa,
    staged_path = qa_path
  )
  for (asset in setdiff(names(object_map), "BASELINE_CHARACTERISTICS_QA_v44_2")) {
    object_map[[asset]]$final_relative <- object_map[[asset]]$relative
  }

  finalized_at <- format(Sys.time(), tz = "Asia/Shanghai", usetz = TRUE)
  manifest <- manifest_rows(root, authorization, object_map, finalized_at, run_id)
  if (!validate_output_schema(
    manifest, contract, "manifest", as.integer(expected_rows$manifest)
  )) {
    stop("v44.2 manifest schema/cardinality failed before publication.", call. = FALSE)
  }
  manifest_path <- file.path(staging_root, spec$outputs$files$manifest)
  write_csv_stage(manifest, manifest_path)

  relative_paths <- output_paths_from_spec(spec)
  staged_files <- list.files(staging_root, recursive = TRUE, full.names = FALSE)
  if (length(staged_files) != 8L || !setequal(staged_files, relative_paths) ||
      any(file.info(file.path(staging_root, relative_paths))$size <= 0)) {
    stop("v44.2 staged public file set is not the exact eight-file contract.", call. = FALSE)
  }
  promote_bundle(root, staging_root, relative_paths)
  completed <- TRUE
  invisible(list(validation = validation, manifest = manifest))
}

main <- function() {
  root <- project_root()
  required <- c("digest", "survey", "yaml")
  missing_packages <- required[
    !vapply(required, requireNamespace, logical(1), quietly = TRUE)
  ]
  if (length(missing_packages)) {
    stop("Missing v44.2 packages: ", paste(missing_packages, collapse = ", "), call. = FALSE)
  }
  spec_path <- file.path(root, "work_v44/baseline_characteristics_spec_v44_2.yml")
  contract_path <- file.path(root, "work_v44/baseline_characteristics_contract_v44_2.yml")
  spec <- yaml::read_yaml(spec_path)
  contract <- yaml::read_yaml(contract_path)
  static_preflight(root, spec, contract, require_proposal = TRUE)

  runtime_lock <- validate_runtime_lock(root, spec)
  if (!runtime_lock$pass) {
    stop("v44.2 runtime does not exactly match the frozen renv.lock: ",
         runtime_lock$detail, call. = FALSE)
  }

  if (identical(
    Sys.getenv(spec$governance$preflight_only_environment_variable, unset = ""),
    as.character(spec$governance$preflight_only_value)
  )) {
    message("v44.2 BASELINE PRE-DATA CONTRACT PREFLIGHT PASS")
    return(invisible(TRUE))
  }

  empty <- namespace_empty(root, spec)
  if (!empty$pass) {
    stop("v44.2 output namespace is not empty before first formal run: ", empty$detail,
         call. = FALSE)
  }
  authorization <- validate_formal_authorization(root, spec)
  predecessor_v44 <- validate_recursive_registry(
    root, resolve_path(root, spec$inputs$v44_1_1_authorization_registry), 29L
  )
  predecessor_v43 <- validate_recursive_registry(
    root, resolve_path(root, spec$inputs$v43_authorization_registry), 25L
  )
  completion_v44 <- validate_v44_completion(root, spec)
  completion_nhanes <- validate_nhanes_completion_binding(root, spec)
  if (!predecessor_v44$pass || !predecessor_v43$pass ||
      !completion_v44$pass || !completion_nhanes) {
    stop(
      "v44.2 predecessor completion gates failed before sensitive data access: ",
      "v44.1.1=", predecessor_v44$detail, "; v43=", predecessor_v43$detail,
      "; v44 completion=", completion_v44$detail,
      "; NHANES binding=", completion_nhanes,
      call. = FALSE
    )
  }
  result <- run_formal_v44_2(
    root, spec, contract, authorization, runtime_lock,
    predecessor_v44, predecessor_v43, completion_v44, completion_nhanes
  )
  message(
    "v44.2 BASELINE CHARACTERISTICS FORMAL PASS; ",
    nrow(result$validation), "/", nrow(result$validation),
    " validation checks; no participant-level data printed or persisted"
  )
  invisible(result)
}

if (sys.nframe() == 0L) main()
