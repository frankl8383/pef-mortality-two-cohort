# v44.1.1 post-audit CHARLS anthropometric-QC formal resolution.
#
# The v43 Stage 3 implementation is sourced only as a content-addressed
# function library. Its main() is not called, no v43 file is modified, and all
# v44.1.1 products are aggregate. The frozen E0/E0b exposure, person-period outcome
# skeleton, survey design, spline knots, and model formulas are reused exactly.

options(stringsAsFactors = FALSE)

project_root_v44 <- function() {
  cwd <- normalizePath(getwd(), mustWork = TRUE)
  if (file.exists(file.path(cwd, "work_v44", "charls_anthropometric_qc_resolution_spec_v44_1_1.yml"))) {
    return(cwd)
  }
  args <- commandArgs(trailingOnly = FALSE)
  file_arg <- grep("^--file=", args, value = TRUE)
  if (length(file_arg)) {
    script <- sub("^--file=", "", file_arg[[1]])
    return(normalizePath(file.path(dirname(script), "..", ".."), mustWork = TRUE))
  }
  normalizePath(getwd(), mustWork = TRUE)
}

root_v44 <- project_root_v44()
project_r_library_v44 <- file.path(
  root_v44, "work_v43/renv/library/macos/R-4.5/aarch64-apple-darwin20"
)
if (dir.exists(project_r_library_v44)) {
  .libPaths(unique(c(project_r_library_v44, .libPaths())))
}
reference_script_v44 <- file.path(root_v44, "R/v43/04_charls_stage3_primary_mortality.R")
if (!file.exists(reference_script_v44)) stop("Missing v43 reference implementation.", call. = FALSE)
if (!all(vapply(c("digest", "yaml"), requireNamespace, quietly = TRUE,
                FUN.VALUE = logical(1)))) {
  stop("The digest and yaml packages are required before pre-data validation.",
       call. = FALSE)
}
bootstrap_validate_resolution_authorization_v44_1 <- function(root) {
  registry_path <- file.path(
    root, "work_v44/charls_anthropometric_qc_resolution_authorization_hashes_v44_1_1.csv"
  )
  expected_assets <- c(
    "spec", "contract", "seed_ledger", "decision_log", "gate_state",
    "failure_record", "script", "v44_1_0_authorization_registry",
    "v44_0_6_production_library", "v44_0_6_authorization_registry",
    "v44_technical_pilot_provenance", "v43_reference_script",
    "stage3_exact25_registry", "stage3_completion_manifest",
    "stage3_analysis_ledger", "charls_core", "v43_charls_registry",
    "v43_charls_knots", "stage4_anthropometric_audit", "renv_lock",
    "dense_pilot_protocol", "dense_pilot_authorization_registry",
    "dense_pilot_manifest", "dense_pilot_summary", "acyclic_pilot_protocol",
    "acyclic_pilot_authorization_registry", "acyclic_pilot_decision_log",
    "acyclic_pilot_manifest", "acyclic_pilot_summary"
  )
  expected_paths <- c(
    "work_v44/charls_anthropometric_qc_resolution_spec_v44_1_1.yml",
    "work_v44/charls_anthropometric_qc_resolution_contract_v44_1_1.yml",
    "work_v44/charls_anthropometric_qc_resolution_seed_ledger_v44_1_1.csv",
    "work_v44/charls_anthropometric_qc_resolution_decision_log_v44_1_1.md",
    "work_v44/charls_anthropometric_qc_resolution_gate_state_v44_1_1.yml",
    "work_v44/charls_anthropometric_qc_resolution_failure_v44_1_0.md",
    "R/v44/05_charls_anthropometric_qc_resolution_v44_1_1.R",
    "work_v44/charls_anthropometric_qc_resolution_authorization_hashes_v44_1.csv",
    "R/v44/01_charls_anthropometric_qc_mi_sensitivity.R",
    "work_v44/charls_anthropometric_qc_authorization_hashes_v44.csv",
    "work_v44/charls_anthropometric_qc_pilot_provenance_v44.csv",
    "R/v43/04_charls_stage3_primary_mortality.R",
    "work_v43/stage3_authorization_hashes_v43.csv",
    "results/v43/stage3_charls_completion_manifest_v43.csv",
    "derived_sensitive/v43/charls_stage3_analysis_ledger_v43.rds",
    "derived_sensitive/charls/charls_core_harmonized_provisional.rds",
    "results/v43/stage3_charls_primary_association_registry_v43.csv",
    "results/v43/stage3_charls_spline_knot_registry_v43.csv",
    "results/v43/stage4_charls_anthropometric_qc_audit_v43.csv",
    "work_v43/renv.lock",
    "work_v44/charls_anthropometric_qc_later_aux_convergence_pilot_protocol_v44.yml",
    "work_v44/charls_anthropometric_qc_later_aux_pilot_authorization_v44.csv",
    "work_v44/charls_anthropometric_qc_later_aux_convergence_pilot_manifest_v44.csv",
    "work_v44/charls_anthropometric_qc_later_aux_convergence_pilot_v44.md",
    "work_v44/charls_anthropometric_qc_later_aux_acyclic_pilot_protocol_v44.yml",
    "work_v44/charls_anthropometric_qc_later_aux_acyclic_pilot_authorization_v44.csv",
    "work_v44/charls_anthropometric_qc_later_aux_acyclic_decision_log_v44.md",
    "work_v44/charls_anthropometric_qc_later_aux_acyclic_convergence_pilot_manifest_v44.csv",
    "work_v44/charls_anthropometric_qc_later_aux_acyclic_convergence_pilot_v44.md"
  )
  expected_roles <- c(
    "governance_spec", "output_contract", "reproducibility_seed",
    "decision_provenance", "gate_authorization", "failure_provenance",
    "production_executable", "predecessor_authorization_evidence",
    "historical_production_executable", "historical_authorization_evidence",
    "technical_pilot_provenance", "reference_implementation",
    "stage3_authorization", "stage3_completion_binding",
    "sensitive_analysis_input", "source_core", "stage3_comparator",
    "stage3_knots", "qc_preflight_evidence", "environment_lock",
    "dense_pilot_protocol", "dense_pilot_authorization",
    "dense_pilot_manifest", "dense_pilot_summary", "acyclic_pilot_protocol",
    "acyclic_pilot_authorization", "acyclic_pilot_decision",
    "acyclic_pilot_manifest", "acyclic_pilot_summary"
  )
  required <- c(
    "authorization_id", "asset", "role", "path", "required", "exists",
    "bytes", "sha256", "frozen_at"
  )
  if (!file.exists(registry_path)) {
    return(list(pass = FALSE, detail = "v44.1.1 authorization registry missing"))
  }
  registry_sha256 <- digest::digest(registry_path, algo = "sha256", file = TRUE)
  supplied <- tolower(trimws(Sys.getenv("V44_1_1_CHARLS_QC_AUTH_SHA256", "")))
  x <- utils::read.csv(registry_path, stringsAsFactors = FALSE, check.names = FALSE)
  schema <- identical(names(x), required) && nrow(x) == length(expected_assets) &&
    identical(unique(as.character(x$authorization_id)),
              "charls_anthropometric_qc_formal_resolution_v44_1_1") &&
    identical(as.character(x$asset), expected_assets) &&
    identical(as.character(x$role), expected_roles) &&
    identical(as.character(x$path), expected_paths) &&
    !anyDuplicated(x$asset) && !anyDuplicated(x$path) &&
    all(as.logical(x$required)) && all(as.logical(x$exists)) &&
    all(!grepl("^/", x$path)) && all(!grepl("(^|/)\\.\\.(/|$)", x$path)) &&
    length(unique(as.character(x$frozen_at))) == 1L
  if (!schema || !identical(supplied, registry_sha256)) {
    return(list(
      pass = FALSE, registry_sha256 = registry_sha256,
      detail = "v44.1.1 authorization schema/path/external-root failure"
    ))
  }
  full <- file.path(root, x$path)
  current <- vapply(seq_along(full), function(i) {
    file.exists(full[[i]]) && !dir.exists(full[[i]]) &&
      !nzchar(Sys.readlink(full[[i]])) &&
      isTRUE(file.info(full[[i]])$size == suppressWarnings(as.numeric(x$bytes[[i]]))) &&
      identical(
        tolower(digest::digest(full[[i]], algo = "sha256", file = TRUE)),
        tolower(as.character(x$sha256[[i]]))
      )
  }, logical(1))
  list(
    pass = all(current), current = sum(current), total = length(current),
    registry = x, registry_path = registry_path,
    registry_sha256 = registry_sha256,
    detail = paste0(sum(current), "/", length(current),
                    " v44.1.1 authorization assets current")
  )
}

bootstrap_validate_predecessor_v44_1_0 <- function(root) {
  path <- file.path(
    root, "work_v44/charls_anthropometric_qc_resolution_authorization_hashes_v44_1.csv"
  )
  expected_root <-
    "bece61fc7863694c18888774c28ddfb9af9b5ac613afdb45b5d5919a1458d8c0"
  required <- c(
    "authorization_id", "asset", "role", "path", "required", "exists",
    "bytes", "sha256", "frozen_at"
  )
  if (!file.exists(path) || !identical(
      tolower(digest::digest(path, algo = "sha256", file = TRUE)), expected_root)) {
    return(list(pass = FALSE, detail = "v44.1.0 authorization root mismatch"))
  }
  x <- utils::read.csv(path, stringsAsFactors = FALSE, check.names = FALSE)
  schema <- identical(names(x), required) && nrow(x) == 27L &&
    identical(unique(as.character(x$authorization_id)),
              "charls_anthropometric_qc_formal_resolution_v44_1_0") &&
    !anyDuplicated(x$asset) && !anyDuplicated(x$path) &&
    all(as.logical(x$required)) && all(as.logical(x$exists)) &&
    all(!grepl("^/", x$path)) && all(!grepl("(^|/)\\.\\.(/|$)", x$path))
  if (!schema) {
    return(list(pass = FALSE, detail = "v44.1.0 authorization schema mismatch"))
  }
  full <- file.path(root, x$path)
  current <- vapply(seq_along(full), function(i) {
    file.exists(full[[i]]) && !dir.exists(full[[i]]) &&
      !nzchar(Sys.readlink(full[[i]])) &&
      isTRUE(file.info(full[[i]])$size == suppressWarnings(as.numeric(x$bytes[[i]]))) &&
      identical(
        tolower(digest::digest(full[[i]], algo = "sha256", file = TRUE)),
        tolower(as.character(x$sha256[[i]]))
      )
  }, logical(1))
  list(
    pass = all(current), current = sum(current), total = length(current),
    registry_sha256 = expected_root,
    detail = paste0(sum(current), "/27 predecessor v44.1.0 assets current")
  )
}

bootstrap_validate_contract_schema_v44_1_1 <- function(root) {
  spec_path <- file.path(
    root, "work_v44/charls_anthropometric_qc_resolution_spec_v44_1_1.yml"
  )
  contract_path <- file.path(
    root, "work_v44/charls_anthropometric_qc_resolution_contract_v44_1_1.yml"
  )
  gate_path <- file.path(
    root, "work_v44/charls_anthropometric_qc_resolution_gate_state_v44_1_1.yml"
  )
  seed_path <- file.path(
    root, "work_v44/charls_anthropometric_qc_resolution_seed_ledger_v44_1_1.csv"
  )
  old_seed_path <- file.path(
    root, "work_v44/charls_anthropometric_qc_resolution_seed_ledger_v44_1.csv"
  )
  failure_path <- file.path(
    root, "work_v44/charls_anthropometric_qc_resolution_failure_v44_1_0.md"
  )
  required_files <- c(
    spec_path, contract_path, gate_path, seed_path, old_seed_path, failure_path
  )
  if (!all(file.exists(required_files))) {
    return(list(pass = FALSE, detail = "v44.1.1 preflight governance file missing"))
  }
  spec <- yaml::read_yaml(spec_path)
  contract <- yaml::read_yaml(contract_path)
  gate <- yaml::read_yaml(gate_path)
  expected_paths <- c(
    "results/v44_1_1/charls_anthropometric_qc_source_audit_v44_1_1.csv",
    "results/v44_1_1/stage3_charls_primary_association_registry_v44_1_1.csv",
    "results/v44_1_1/stage3_charls_anthropometric_sensitivity_registry_v44_1_1.csv",
    "results/v44_1_1/stage3_charls_nonlinearity_tests_v44_1_1.csv",
    "results/v44_1_1/charls_anthropometric_qc_comparison_v44_1_1.csv",
    "results/v44_1_1/charls_anthropometric_qc_variant_disposition_v44_1_1.csv",
    "results/v44_1_1/charls_anthropometric_qc_mi_convergence_v44_1_1.csv",
    "results/v44_1_1/charls_anthropometric_qc_mi_diagnostics_v44_1_1.csv",
    "results/v44_1_1/charls_anthropometric_qc_mi_escalation_v44_1_1.csv",
    "results/v44_1_1/charls_anthropometric_qc_model_diagnostics_v44_1_1.csv",
    "results/v44_1_1/charls_anthropometric_qc_validation_v44_1_1.csv",
    "results/v44_1_1/charls_anthropometric_qc_manifest_v44_1_1.csv",
    "output/qa/v44_1_1/CHARLS_ANTHROPOMETRIC_QC_RESOLUTION_QA_v44_1_1.md"
  )
  expected_columns <- stats::setNames(list(
    c(
      "variant_id", "role", "bounds", "invalidation", "later_wave_auxiliaries",
      "n", "events", "raw_height_observed", "raw_weight_observed", "height_flag_n",
      "weight_flag_n", "bmi_flag_n", "any_flag_n", "flagged_event_n",
      "postclean_height_missing_n", "postclean_weight_missing_n",
      "postclean_parent_union_missing_n", "postclean_bmi_outside_active_range_n",
      "participant_deleted_n", "small_cell_suppressed"
    ),
    c(
      "analysis_id", "cohort", "variant_id", "role", "exposure_id", "model_tier",
      "n", "events", "m", "maxit", "estimate", "standard_error", "ci_low",
      "ci_high", "p_value", "hazard_ratio", "hr_ci_low", "hr_ci_high",
      "fraction_missing_information", "relative_efficiency",
      "monte_carlo_error_fraction", "formula_text", "gate_status"
    ),
    c(
      "analysis_id", "cohort", "variant_id", "role", "exposure_id", "model_tier",
      "n", "events", "m", "maxit", "estimate", "standard_error", "ci_low",
      "ci_high", "p_value", "hazard_ratio", "hr_ci_low", "hr_ci_high",
      "fraction_missing_information", "relative_efficiency",
      "monte_carlo_error_fraction", "formula_text", "gate_status"
    ),
    c(
      "analysis_id", "cohort", "variant_id", "test_id", "terms", "df_test",
      "statistic", "p_value", "m", "gate_status"
    ),
    c(
      "analysis_id", "comparator_analysis_id", "model_tier", "comparator_log_hr",
      "current_log_hr", "absolute_log_hr_change", "relative_log_effect_change_percent",
      "hr_ratio", "stability_class", "direction_preserved", "ci_excludes_null"
    ),
    c(
      "variant_id", "registered_role", "formal_execution_disposition",
      "estimability_status", "requested_fit_tiers", "mortality_model_fitted",
      "effect_estimate_available", "effect_rows_expected", "effect_rows_observed",
      "reason_code", "resolution_evidence_id",
      "resolution_frozen_before_v44_1_0_execution", "manuscript_reporting_rule",
      "gate_status"
    ),
    c(
      "variant_id", "mi_run", "checkpoint_order", "checkpoint_iteration",
      "selected_checkpoint", "variable", "parameter", "category_level", "missing_n",
      "iterations", "chains", "rhat", "hard_gate", "pass", "diagnostic_status",
      "rank_normalized_split_rhat", "folded_split_rhat", "detail"
    ),
    c(
      "variant_id", "m", "selected_maxit", "active_target_n", "logged_events",
      "anthropometric_identity_failures", "completed_range_failures",
      "completed_bmi_outside_active_range_n", "observed_valid_value_changes",
      "smoking_conflicts", "maximum_monte_carlo_error_fraction", "convergence_pass"
    ),
    c(
      "variant_id", "initial_m", "initial_maximum_monte_carlo_error_fraction",
      "escalation_threshold", "escalated", "final_m",
      "final_maximum_monte_carlo_error_fraction", "decision_rule"
    ),
    c(
      "variant_id", "cohort", "model_id", "n_participants", "n_person_period_rows",
      "events", "nominal_person_years", "time_basis", "exact_death_date_used",
      "prefit_time_basis_support_gate",
      "runtime_multivariable_finite_fit_gate", "design_psu", "design_df",
      "glm_converged", "glm_boundary", "glm_iterations", "matrix_columns",
      "matrix_rank", "covariance_symmetry_error", "covariance_minimum_eigenvalue",
      "covariance_condition_number", "fitted_probability_min", "fitted_probability_max",
      "fitted_probability_near_zero", "fitted_probability_near_one", "warnings"
    ),
    c("check_id", "status", "observed", "expected", "detail"),
    c(
      "asset", "path", "exists", "bytes", "sha256", "finalized_at", "run_id",
      "authorization_id", "authorization_registry_sha256", "rng_kind", "r_version",
      "package_versions"
    )
  ), expected_paths[seq_len(12L)])
  expected_rows <- list(
    3L, 12L, 2L, 2L, 14L, 4L,
    "one of 153, 204, 255, 306, 357, 408, or 459; exactly 51 rows per attempted checkpoint",
    3L, 3L,
    "one of 603, 653, 703, 1103, 1153, or 1203; exact dynamic formula is 3 complete-case fits + 10 times primary-variant m + component m + PCORnet m",
    23L, 42L, NULL
  )
  scalar_character <- function(x) {
    is.character(x) && length(x) == 1L && !is.na(x) && nzchar(x)
  }
  output_structure_pass <- is.list(contract$outputs) &&
    length(contract$outputs) == 13L &&
    all(vapply(contract$outputs, function(entry) {
      is.list(entry) && scalar_character(entry$path)
    }, logical(1)))
  if (!output_structure_pass) {
    return(list(pass = FALSE, detail = "contract output/path type preflight failed"))
  }
  parsed_paths <- vapply(contract$outputs, `[[`, character(1), "path")
  column_type_pass <- all(vapply(seq_len(12L), function(i) {
    columns <- contract$outputs[[i]]$required_columns
    is.character(columns) && length(columns) > 0L &&
      !anyNA(columns) && all(nzchar(columns))
  }, logical(1)))
  exact_column_matches <- vapply(seq_len(12L), function(i) {
    columns <- unlist(contract$outputs[[i]]$required_columns, use.names = FALSE)
    !anyDuplicated(columns) && identical(columns, expected_columns[[parsed_paths[[i]]]])
  }, logical(1))
  exact_columns_pass <- column_type_pass && all(exact_column_matches)
  rows_pass <- all(vapply(seq_len(13L), function(i) {
    identical(contract$outputs[[i]]$rows, expected_rows[[i]])
  }, logical(1)))
  prefixes_pass <- identical(
    unlist(contract$immutability$permitted_output_prefixes, use.names = FALSE),
    c(
      "results/v44_1_1/charls_anthropometric_qc_",
      "results/v44_1_1/stage3_charls_",
      "output/qa/v44_1_1/CHARLS_ANTHROPOMETRIC_QC_"
    )
  )
  identity_pass <- identical(spec$spec_id,
                             "charls_anthropometric_qc_resolution_v44_1_1") &&
    identical(contract$contract_id, spec$spec_id) &&
    identical(spec$version, "v44.1.1") && identical(contract$version, spec$version) &&
    identical(gate$spec_id, spec$spec_id) && identical(gate$version, spec$version) &&
    identical(gate$authorization_id,
              "charls_anthropometric_qc_formal_resolution_v44_1_1") &&
    identical(gate$authorized_entrypoint,
              "R/v44/05_charls_anthropometric_qc_resolution_v44_1_1.R")
  seed_pass <- identical(
    digest::digest(seed_path, algo = "sha256", file = TRUE),
    digest::digest(old_seed_path, algo = "sha256", file = TRUE)
  )
  failure_text <- paste(readLines(failure_path, warn = FALSE), collapse = "\n")
  failure_keywords <- c(
    "failure_code=CONTRACT_YAML11_IDENTIFIER_COERCION",
    "failure_phase=POST_ANALYSIS_PRE_STAGING_CONTRACT_SCHEMA_VALIDATION",
    "public_output_count=0", "manifest_present=FALSE", "reuse=FORBIDDEN",
    "scientific_delta=NONE"
  )
  failure_pass <- all(vapply(
    failure_keywords, function(x) grepl(x, failure_text, fixed = TRUE), logical(1)
  ))
  file_count <- function(relative_path) {
    path <- file.path(root, relative_path)
    if (!dir.exists(path)) return(0L)
    length(list.files(path, recursive = TRUE, all.files = TRUE, no.. = TRUE))
  }
  empty_pass <- all(vapply(c(
    "results/v44_1", "output/qa/v44_1",
    "derived_sensitive/v44_1/.publication_staging",
    "results/v44_1_1", "output/qa/v44_1_1",
    "derived_sensitive/v44_1_1/.publication_staging"
  ), file_count, integer(1)) == 0L)
  pass <- identical(parsed_paths, expected_paths) && !anyDuplicated(parsed_paths) &&
    exact_columns_pass && rows_pass &&
    identical(contract$outputs[[13]]$type, "markdown") && prefixes_pass &&
    identity_pass && seed_pass && failure_pass && empty_pass
  list(
    pass = pass, spec = spec, contract = contract, gate = gate,
    detail = paste0(
      "paths=", identical(parsed_paths, expected_paths),
      "; columns=", exact_columns_pass,
      "; column_mismatches=",
      paste(parsed_paths[seq_len(12L)][!exact_column_matches], collapse = "|"),
      "; rows=", rows_pass,
      "; identity=", identity_pass, "; inherited_seed=", seed_pass,
      "; failure_evidence=", failure_pass, "; empty_namespaces=", empty_pass
    )
  )
}

bootstrap_authorization_v44_1 <-
  bootstrap_validate_resolution_authorization_v44_1(root_v44)
if (!isTRUE(bootstrap_authorization_v44_1$pass)) {
  stop(
    "v44.1.1 authorization failed before loading production libraries: ",
    bootstrap_authorization_v44_1$detail, call. = FALSE
  )
}
bootstrap_predecessor_v44_1_0 <-
  bootstrap_validate_predecessor_v44_1_0(root_v44)
if (!isTRUE(bootstrap_predecessor_v44_1_0$pass)) {
  stop("v44.1.0 predecessor authorization failed before loading production libraries: ",
       bootstrap_predecessor_v44_1_0$detail, call. = FALSE)
}
bootstrap_contract_v44_1_1 <-
  bootstrap_validate_contract_schema_v44_1_1(root_v44)
if (!isTRUE(bootstrap_contract_v44_1_1$pass)) {
  stop("v44.1.1 pre-data contract-schema validation failed: ",
       bootstrap_contract_v44_1_1$detail, call. = FALSE)
}
if (identical(Sys.getenv("V44_1_1_CHARLS_QC_REFRESH", "0"), "1")) {
  stop("v44.1.1 is first-production-only; refresh requires a new governed version.",
       call. = FALSE)
}
if (identical(Sys.getenv("V44_1_1_CHARLS_QC_PREFLIGHT_ONLY", "0"), "1")) {
  cat("CHARLS v44.1.1 PRE-DATA CONTRACT PREFLIGHT PASS\n")
  quit(save = "no", status = 0L, runLast = FALSE)
}
reference_script_sha256_v44 <- "bc759aab44691deb5a920a4017c7b51bfe7c5694959b27ae9aa95462fba5908d"
if (!identical(
  digest::digest(reference_script_v44, algo = "sha256", file = TRUE),
  reference_script_sha256_v44
)) {
  stop("The v43 reference implementation drifted before source().", call. = FALSE)
}
source(reference_script_v44, local = globalenv())
attach_passive_variables_v43_impl <- attach_passive_variables

if (!all(vapply(c("yaml", "digest", "mice", "survey", "dplyr"), requireNamespace,
                quietly = TRUE, FUN.VALUE = logical(1)))) {
  stop("Required v44 packages are unavailable.", call. = FALSE)
}

v44_constrained_weight_pmm_core <- function(
    y, ry, x, wy = NULL, donors = 5L, ridge = 1e-5,
    bmi_lower, bmi_upper, ...) {
  if (is.null(wy)) wy <- !ry
  if (is.null(colnames(x))) {
    stop("Constrained weight PMM requires named predictors.", call. = FALSE)
  }
  height_column <- which(colnames(x) == "height_m_w1")
  if (length(height_column) != 1L) {
    stop("Constrained weight PMM requires exactly one height_m_w1 predictor.", call. = FALSE)
  }
  y <- suppressWarnings(as.numeric(y))
  recipient_height <- suppressWarnings(as.numeric(x[wy, height_column]))
  if (!length(recipient_height) || any(!is.finite(recipient_height))) {
    stop("Constrained weight PMM received an invalid completed height.", call. = FALSE)
  }
  design <- cbind(1, as.matrix(x))
  draw <- mice:::.norm.draw(y, ry, design, ridge = ridge, ...)
  yhat_observed <- as.numeric(design[ry, , drop = FALSE] %*% draw$coef)
  yhat_missing <- as.numeric(design[wy, , drop = FALSE] %*% draw$beta)
  observed_y <- y[ry]
  if (any(!is.finite(observed_y))) {
    stop("Constrained weight PMM donor pool is nonfinite.", call. = FALSE)
  }
  vapply(seq_along(yhat_missing), function(i) {
    eligible <- which(
      observed_y >= bmi_lower * recipient_height[[i]]^2 &
        observed_y <= bmi_upper * recipient_height[[i]]^2
    )
    if (!length(eligible)) {
      stop("No eligible weight donor satisfies the active passive-BMI gate.", call. = FALSE)
    }
    distance <- abs(yhat_observed[eligible] - yhat_missing[[i]])
    donor_n <- min(as.integer(donors), length(eligible))
    nearest <- integer(donor_n)
    for (j in seq_len(donor_n)) {
      position <- which.min(distance)
      nearest[[j]] <- eligible[[position]]
      distance[[position]] <- Inf
    }
    sample(observed_y[nearest], size = 1L)
  }, numeric(1))
}

v44_constrained_height_pmm_core <- function(
    y, ry, x, wy = NULL, donors = 5L, ridge = 1e-5,
    bmi_lower, bmi_upper, ...) {
  if (is.null(wy)) wy <- !ry
  if (is.null(colnames(x))) {
    stop("Constrained height PMM requires named predictors.", call. = FALSE)
  }
  weight_column <- which(colnames(x) == "weight_kg_w1")
  if (length(weight_column) != 1L) {
    stop("Constrained height PMM requires exactly one weight_kg_w1 predictor.", call. = FALSE)
  }
  y <- suppressWarnings(as.numeric(y))
  recipient_weight <- suppressWarnings(as.numeric(x[wy, weight_column]))
  if (!length(recipient_weight) || any(!is.finite(recipient_weight))) {
    stop("Constrained height PMM received an invalid completed weight.", call. = FALSE)
  }
  design <- cbind(1, as.matrix(x))
  draw <- mice:::.norm.draw(y, ry, design, ridge = ridge, ...)
  yhat_observed <- as.numeric(design[ry, , drop = FALSE] %*% draw$coef)
  yhat_missing <- as.numeric(design[wy, , drop = FALSE] %*% draw$beta)
  observed_y <- y[ry]
  if (any(!is.finite(observed_y) | observed_y <= 0)) {
    stop("Constrained height PMM donor pool is invalid.", call. = FALSE)
  }
  vapply(seq_along(yhat_missing), function(i) {
    resulting_bmi <- recipient_weight[[i]] / observed_y^2
    eligible <- which(resulting_bmi >= bmi_lower & resulting_bmi <= bmi_upper)
    if (!length(eligible)) {
      stop("No eligible height donor satisfies the active passive-BMI gate.", call. = FALSE)
    }
    distance <- abs(yhat_observed[eligible] - yhat_missing[[i]])
    donor_n <- min(as.integer(donors), length(eligible))
    nearest <- integer(donor_n)
    for (j in seq_len(donor_n)) {
      position <- which.min(distance)
      nearest[[j]] <- eligible[[position]]
      distance[[position]] <- Inf
    }
    sample(observed_y[nearest], size = 1L)
  }, numeric(1))
}

mice.impute.v44_who_constrained_weight_pmm <- function(...) {
  v44_constrained_weight_pmm_core(..., bmi_lower = 11, bmi_upper = 75)
}

mice.impute.v44_who_constrained_height_pmm <- function(...) {
  v44_constrained_height_pmm_core(..., bmi_lower = 11, bmi_upper = 75)
}

mice.impute.v44_pcornet_constrained_weight_pmm <- function(...) {
  v44_constrained_weight_pmm_core(..., bmi_lower = 15, bmi_upper = 90)
}

mice.impute.v44_pcornet_constrained_height_pmm <- function(...) {
  v44_constrained_height_pmm_core(..., bmi_lower = 15, bmi_upper = 90)
}

atomic_write_csv_v44 <- function(x, path) {
  dir.create(dirname(path), recursive = TRUE, showWarnings = FALSE)
  tmp <- tempfile(paste0(".", basename(path), "."), tmpdir = dirname(path))
  on.exit(if (file.exists(tmp)) unlink(tmp, force = TRUE), add = TRUE)
  utils::write.csv(x, tmp, row.names = FALSE, na = "")
  if (!file.rename(tmp, path)) stop("Atomic CSV write failed: ", path, call. = FALSE)
}

atomic_write_lines_v44 <- function(x, path) {
  dir.create(dirname(path), recursive = TRUE, showWarnings = FALSE)
  tmp <- tempfile(paste0(".", basename(path), "."), tmpdir = dirname(path))
  on.exit(if (file.exists(tmp)) unlink(tmp, force = TRUE), add = TRUE)
  writeLines(x, tmp, useBytes = TRUE)
  if (!file.rename(tmp, path)) stop("Atomic text write failed: ", path, call. = FALSE)
}

markdown_table_v44 <- function(x) {
  x <- as.data.frame(x, stringsAsFactors = FALSE)
  if (!nrow(x)) return("_No rows._")
  x[] <- lapply(x, function(z) ifelse(is.na(z), "", as.character(z)))
  c(
    paste0("| ", paste(names(x), collapse = " | "), " |"),
    paste0("| ", paste(rep("---", ncol(x)), collapse = " | "), " |"),
    apply(x, 1L, function(z) paste0("| ", paste(z, collapse = " | "), " |"))
  )
}

validate_exact25_v44 <- function(path, expected_registry_hash) {
  if (!file.exists(path)) return(list(pass = FALSE, current = 0L, detail = "missing"))
  if (!identical(sha256_file(path), as.character(expected_registry_hash))) {
    return(list(pass = FALSE, current = 0L, detail = "registry hash drifted"))
  }
  x <- utils::read.csv(path, stringsAsFactors = FALSE, check.names = FALSE)
  required <- c("asset", "path", "exists", "bytes", "sha256", "frozen_at")
  schema <- identical(names(x), required) && nrow(x) == 25L &&
    !anyDuplicated(x$asset) && !anyDuplicated(x$path)
  if (!schema) return(list(pass = FALSE, current = 0L, detail = "schema/cardinality failure"))
  current <- vapply(seq_len(nrow(x)), function(i) {
    p <- as.character(x$path[[i]])
    file.exists(p) && !dir.exists(p) &&
      isTRUE(file.info(p)$size == suppressWarnings(as.numeric(x$bytes[[i]]))) &&
      identical(tolower(sha256_file(p)), tolower(as.character(x$sha256[[i]])))
  }, logical(1))
  list(pass = all(current), current = sum(current), detail = paste0(sum(current), "/25 current"))
}

validate_completion_inputs_v44 <- function(root, spec) {
  manifest_path <- file.path(root, spec$inputs$stage3_charls_completion_manifest)
  expected_manifest_hash <- as.character(
    spec$inputs$stage3_charls_completion_manifest_sha256
  )
  if (!file.exists(manifest_path) ||
      !identical(sha256_file(manifest_path), expected_manifest_hash)) {
    return(list(pass = FALSE, detail = "completion manifest missing or hash drifted"))
  }
  manifest <- utils::read.csv(
    manifest_path, stringsAsFactors = FALSE, check.names = FALSE
  )
  required_columns <- c(
    "cohort", "status", "authorization_registry_sha256",
    "artifact", "bytes", "sha256"
  )
  required_artifacts <- c(
    spec$inputs$stage3_analysis_ledger,
    spec$inputs$stage3_charls_registry,
    spec$inputs$stage3_charls_knots
  )
  authorization_hash <- as.character(spec$inputs$stage3_authorization_registry_sha256)
  if (!all(required_columns %in% names(manifest)) ||
      anyDuplicated(manifest$artifact) ||
      !all(required_artifacts %in% manifest$artifact) ||
      !identical(unique(as.character(manifest$authorization_registry_sha256)),
                 authorization_hash)) {
    return(list(pass = FALSE, detail = "completion manifest schema/key failure"))
  }
  current <- vapply(required_artifacts, function(rel) {
    row <- manifest[manifest$artifact == rel, , drop = FALSE]
    path <- file.path(root, rel)
    nrow(row) == 1L && identical(row$cohort[[1]], "CHARLS") &&
      identical(row$status[[1]], "COMPLETE") && file.exists(path) &&
      isTRUE(file.info(path)$size == suppressWarnings(as.numeric(row$bytes[[1]]))) &&
      identical(sha256_file(path), as.character(row$sha256[[1]]))
  }, logical(1))
  list(
    pass = all(current),
    detail = paste0(sum(current), "/", length(current),
                    " opened completion-bound inputs current")
  )
}

validate_v44_authorization <- function(root, path) {
  expected <- file.path(
    root, "work_v44/charls_anthropometric_qc_resolution_authorization_hashes_v44_1_1.csv"
  )
  if (!identical(normalizePath(path, mustWork = FALSE),
                 normalizePath(expected, mustWork = FALSE))) {
    return(list(pass = FALSE, current = 0L, detail = "unexpected authorization path"))
  }
  bootstrap_validate_resolution_authorization_v44_1(root)
}

attach_passive_variables <- function(dat, knots) {
  height <- numeric_code(dat$height_m_w1)
  weight <- numeric_code(dat$weight_kg_w1)
  if (any(!is.finite(height) | height <= 0) || any(!is.finite(weight) | weight <= 0)) {
    stop("Completed v44 anthropometric parents are nonfinite or nonpositive.", call. = FALSE)
  }
  dat$bmi_w1 <- weight / height^2
  attach_passive_variables_v43_impl(dat, knots)
}

variant_catalog_v44 <- function(spec) {
  variants <- spec$mi_variants
  out <- lapply(variants, function(v) {
    bounds <- if (identical(v$bounds, "who_operational")) {
      spec$anthropometric_rules$who_operational
    } else if (identical(v$bounds, "pcornet_sensitivity")) {
      spec$anthropometric_rules$pcornet_sensitivity
    } else {
      stop("Unknown anthropometric bound set: ", v$bounds, call. = FALSE)
    }
    list(
      id = as.character(v$id), role = as.character(v$role),
      bounds_id = as.character(v$bounds), invalidation = as.character(v$invalidation),
      later = isTRUE(v$later_wave_auxiliaries),
      tiers = unlist(v$fit_tiers, use.names = FALSE), seed = as.integer(v$seed),
      h = as.numeric(unlist(bounds$height_m)),
      w = as.numeric(unlist(bounds$weight_kg)),
      b = as.numeric(unlist(bounds$reconstructed_bmi_kg_m2)),
      block = grepl("block", as.character(v$id), fixed = TRUE)
    )
  })
  names(out) <- vapply(out, `[[`, character(1), "id")
  out
}

clean_wave_v44 <- function(height, weight, variant) {
  height <- suppressWarnings(as.numeric(height))
  weight <- suppressWarnings(as.numeric(weight))
  h_flag <- is.finite(height) & (height < variant$h[[1]] | height > variant$h[[2]])
  w_flag <- is.finite(weight) & (weight < variant$w[[1]] | weight > variant$w[[2]])
  raw_bmi <- ifelse(
    is.finite(height) & height > 0 & is.finite(weight),
    weight / height^2,
    NA_real_
  )
  b_flag <- is.finite(raw_bmi) & (raw_bmi < variant$b[[1]] | raw_bmi > variant$b[[2]])
  if (isTRUE(variant$block)) {
    any_flag <- h_flag | w_flag | b_flag
    height_clean <- ifelse(any_flag, NA_real_, height)
    weight_clean <- ifelse(any_flag, NA_real_, weight)
  } else {
    any_flag <- h_flag | w_flag | b_flag
    height_clean <- ifelse(h_flag, NA_real_, height)
    weight_clean <- ifelse(w_flag, NA_real_, weight)
  }
  bmi_clean <- ifelse(
    is.finite(height_clean) & height_clean > 0 & is.finite(weight_clean),
    weight_clean / height_clean^2,
    NA_real_
  )
  list(
    height = height_clean, weight = weight_clean, bmi = bmi_clean,
    h_flag = h_flag, w_flag = w_flag, b_flag = b_flag,
    any_flag = any_flag, raw_bmi = raw_bmi
  )
}

prepare_variant_v44 <- function(raw_master, variant) {
  if (isTRUE(variant$later)) {
    stop("v44.1.1 forbids constructing a later-wave auxiliary variant.", call. = FALSE)
  }
  w1 <- clean_wave_v44(raw_master$height_m_w1_raw, raw_master$weight_kg_w1_raw, variant)
  out <- raw_master
  out$height_m_w1 <- w1$height
  out$weight_kg_w1 <- w1$weight
  out$bmi_w1 <- w1$bmi
  audit <- data.frame(
    variant_id = variant$id,
    role = variant$role,
    bounds = paste0(
      "height=", paste(variant$h, collapse = "-"), "m; weight=",
      paste(variant$w, collapse = "-"), "kg; BMI=", paste(variant$b, collapse = "-")
    ),
    invalidation = if (variant$block) "block" else "component_only",
    later_wave_auxiliaries = variant$later,
    n = nrow(out), events = sum(out$event_any == 1L),
    raw_height_observed = sum(is.finite(raw_master$height_m_w1_raw)),
    raw_weight_observed = sum(is.finite(raw_master$weight_kg_w1_raw)),
    height_flag_n = sum(w1$h_flag), weight_flag_n = sum(w1$w_flag),
    bmi_flag_n = sum(w1$b_flag), any_flag_n = sum(w1$any_flag),
    flagged_event_n = sum(w1$any_flag & out$event_any == 1L),
    postclean_height_missing_n = sum(!is.finite(out$height_m_w1)),
    postclean_weight_missing_n = sum(!is.finite(out$weight_kg_w1)),
    postclean_parent_union_missing_n =
      sum(!is.finite(out$height_m_w1) | !is.finite(out$weight_kg_w1)),
    postclean_bmi_outside_active_range_n = sum(
      is.finite(out$bmi_w1) & (out$bmi_w1 < variant$b[[1]] | out$bmi_w1 > variant$b[[2]])
    ),
    participant_deleted_n = 0L,
    stringsAsFactors = FALSE
  )
  list(master = out, audit = audit, flags = w1)
}

make_mi_input_v44 <- function(master, variant) {
  if (isTRUE(variant$later)) {
    stop("v44.1.1 forbids later-wave anthropometric MI inputs.", call. = FALSE)
  }
  dat <- make_mi_input(master)
  dat$weight_kg_w1 <- suppressWarnings(as.numeric(master$weight_kg_w1))
  # Internal non-model placeholder. attach_passive_variables() deterministically
  # overwrites every completed value before any model matrix is constructed.
  dat$bmi_w1 <- 0
  dat
}

freeze_mi_spec_v44 <- function(mi_data, variant, spec) {
  forbidden_later <- c(
    "height_m_w2_aux", "weight_kg_w2_aux", "height_m_w3_aux", "weight_kg_w3_aux"
  )
  if (isTRUE(variant$later) || any(forbidden_later %in% names(mi_data))) {
    stop("v44.1.1 later-wave auxiliary columns are forbidden in formal MI.", call. = FALSE)
  }
  out <- freeze_mi_specification(mi_data)
  out$seed <- variant$seed
  out$maxit <- as.integer(spec$multiple_imputation$initial_maxit)
  out$convergence_iteration_checkpoints <-
    as.integer(unlist(spec$multiple_imputation$convergence_checkpoints))
  out$maximum_maxit <- as.integer(spec$multiple_imputation$maximum_maxit)
  out$initial_m <- as.integer(spec$multiple_imputation$m)
  out$maximum_m <- as.integer(spec$multiple_imputation$maximum_m_if_monte_carlo_gate_fails)
  out$convergence_rhat_max <- as.numeric(spec$multiple_imputation$improved_rhat_max)
  out$monte_carlo_error_fraction_max <-
    as.numeric(spec$multiple_imputation$monte_carlo_error_fraction_max)

  out$method[["bmi_w1"]] <- ""
  out$predictor_matrix["bmi_w1", ] <- 0
  out$predictor_matrix[, "bmi_w1"] <- 0
  quantitative <- intersect(
    c("height_m_w1", "weight_kg_w1"),
    names(mi_data)
  )
  for (v in quantitative) {
    out$method[[v]] <- if (anyNA(mi_data[[v]])) "pmm" else ""
  }
  if (isTRUE(variant$block) && anyNA(mi_data$weight_kg_w1)) {
    prefix <- if (identical(variant$bounds_id, "who_operational")) {
      "v44_who"
    } else {
      "v44_pcornet"
    }
    out$method[["weight_kg_w1"]] <- paste0(prefix, "_constrained_weight_pmm")
    out$method[["height_m_w1"]] <- paste0(prefix, "_constrained_height_pmm")
  }
  active <- names(out$method)[nzchar(out$method)]
  smoking <- intersect(c("smoke_ever_w1", "smoke_now_w1"), active)
  directed_anthropometry <- intersect(
    c("height_m_w1", "weight_kg_w1"), active
  )
  out$visit_sequence <- c(
    smoking,
    setdiff(directed_anthropometry, smoking),
    setdiff(active, c(smoking, directed_anthropometry))
  )
  out$unordered_multicategory_targets <- active[vapply(mi_data[active], function(x) {
    is.factor(x) && !is.ordered(x) && nlevels(x) > 2L
  }, logical(1))]
  out
}

validate_completed_mids_v44 <- function(imp, mi_data, clean_master, variant, knots) {
  identity_failures <- 0L
  range_failures <- 0L
  completed_bmi_outside_active_range_n <- 0L
  observed_value_changes <- 0L
  smoking_conflicts <- 0L
  observed_h <- is.finite(clean_master$height_m_w1)
  observed_w <- is.finite(clean_master$weight_kg_w1)
  completed_ranges <- vector("list", imp$m)
  for (j in seq_len(imp$m)) {
    completed <- mice::complete(imp, action = j)
    h <- numeric_code(completed$height_m_w1)
    w <- numeric_code(completed$weight_kg_w1)
    bmi <- w / h^2
    modeled <- attach_passive_variables(completed, knots)
    modeled_bmi <- numeric_code(modeled$bmi_w1)
    identity_failures <- identity_failures +
      sum(!is.finite(modeled_bmi) | abs(modeled_bmi - bmi) > 1e-10)
    parent_bad <- !is.finite(h) | h < variant$h[[1]] | h > variant$h[[2]] |
      !is.finite(w) | w < variant$w[[1]] | w > variant$w[[2]]
    bmi_bad <- !is.finite(bmi) | bmi < variant$b[[1]] | bmi > variant$b[[2]]
    completed_bmi_outside_active_range_n <-
      completed_bmi_outside_active_range_n + sum(bmi_bad)
    range_failures <- range_failures + sum(parent_bad) +
      if (variant$block) sum(bmi_bad) else 0L
    observed_value_changes <- observed_value_changes +
      sum(abs(h[observed_h] - clean_master$height_m_w1[observed_h]) > 1e-12) +
      sum(abs(w[observed_w] - clean_master$weight_kg_w1[observed_w]) > 1e-12)
    ever <- numeric_code(completed$smoke_ever_w1)
    now <- numeric_code(completed$smoke_now_w1)
    smoking_conflicts <- smoking_conflicts +
      sum(!is.finite(ever) | !is.finite(now) | !(ever %in% 0:1) | !(now %in% 0:1) |
            (ever == 0 & now == 1))
    completed_ranges[[j]] <- data.frame(
      imputation = j, height_min = min(h), height_max = max(h),
      weight_min = min(w), weight_max = max(w), bmi_min = min(bmi), bmi_max = max(bmi)
    )
  }
  list(
    identity_failures = identity_failures,
    range_failures = range_failures,
    completed_bmi_outside_active_range_n = completed_bmi_outside_active_range_n,
    observed_value_changes = observed_value_changes,
    smoking_conflicts = smoking_conflicts,
    ranges = dplyr::bind_rows(completed_ranges)
  )
}

association_row_v44 <- function(
    pooled, analysis_id, variant, exposure_id, tier, formula, diagnostic,
    m, maxit, role = variant$role) {
  data.frame(
    analysis_id = analysis_id, cohort = "CHARLS", variant_id = variant$id,
    role = role, exposure_id = exposure_id, model_tier = tier,
    n = diagnostic$n_participants[[1]], events = diagnostic$events[[1]],
    m = as.integer(m), maxit = as.integer(maxit),
    estimate = pooled$estimate, standard_error = pooled$standard_error,
    ci_low = pooled$ci_low, ci_high = pooled$ci_high, p_value = pooled$p_value,
    hazard_ratio = exp(pooled$estimate), hr_ci_low = exp(pooled$ci_low),
    hr_ci_high = exp(pooled$ci_high),
    fraction_missing_information = if (!is.null(pooled$fraction_missing_information))
      pooled$fraction_missing_information else 0,
    relative_efficiency = if (!is.null(pooled$relative_efficiency))
      pooled$relative_efficiency else 1,
    monte_carlo_error_fraction = if (!is.null(pooled$monte_carlo_error_fraction))
      pooled$monte_carlo_error_fraction else 0,
    formula_text = paste(deparse(formula), collapse = " "),
    gate_status = "PASS", stringsAsFactors = FALSE
  )
}

diagnostics_from_fits_v44 <- function(fits, variant_id) {
  x <- dplyr::bind_rows(lapply(fits, function(tier) {
    dplyr::bind_rows(lapply(tier, `[[`, "diagnostics"))
  }))
  x$variant_id <- variant_id
  x[, c("variant_id", setdiff(names(x), "variant_id")), drop = FALSE]
}

pool_complete_case_v44 <- function(fit) {
  b <- unname(fit$coefficients[["E0"]])
  se <- sqrt(unname(fit$variance["E0", "E0"]))
  df <- fit$diagnostics$design_df[[1]]
  critical <- stats::qt(0.975, df = df)
  data.frame(
    estimate = b, standard_error = se,
    ci_low = b - critical * se, ci_high = b + critical * se,
    p_value = 2 * stats::pt(abs(b / se), df = df, lower.tail = FALSE),
    fraction_missing_information = 0, relative_efficiency = 1,
    monte_carlo_error_fraction = 0
  )
}

fit_variant_bundle_v44 <- function(imp, master, period, knots, variant, maxit) {
  formulas_e0 <- model_formulas("E0")
  association <- list()
  diagnostics <- list()
  nonlinear <- NULL

  if (identical(variant$role, "primary_v44_qc_rerun")) {
    fits_e0 <- fit_across_imputations(
      imp, period, knots, formulas_e0, "v44_s3_charls_pc_e0"
    )
    diagnostics[["e0"]] <- diagnostics_from_fits_v44(fits_e0, variant$id)
    for (tier in names(fits_e0)) {
      pooled <- pool_scalar_rubin(fits_e0[[tier]], "E0")
      association[[paste0("e0_", tier)]] <- association_row_v44(
        pooled, paste0("v44_s3_charls_pc_e0_", tolower(tier)), variant,
        "E0", tier, formulas_e0[[tier]], fits_e0[[tier]][[1]]$diagnostics,
        imp$m, maxit
      )
    }

    formulas_e0b <- model_formulas("E0b")
    fits_e0b <- fit_across_imputations(
      imp, period, knots, formulas_e0b, "v44_s3_charls_pc_e0b"
    )
    diagnostics[["e0b"]] <- diagnostics_from_fits_v44(fits_e0b, variant$id)
    for (tier in names(fits_e0b)) {
      pooled <- pool_scalar_rubin(fits_e0b[[tier]], "E0b")
      association[[paste0("e0b_", tier)]] <- association_row_v44(
        pooled, paste0("v44_s3_charls_pc_e0b_", tolower(tier)), variant,
        "E0b", tier, formulas_e0b[[tier]], fits_e0b[[tier]][[1]]$diagnostics,
        imp$m, maxit
      )
    }

    cc_fits <- fit_complete_case_set(
      master, period, knots, formulas_e0, "v44_s3_charls_pc_e0_complete_case"
    )
    cc_diag <- dplyr::bind_rows(lapply(cc_fits, `[[`, "diagnostics"))
    cc_diag$variant_id <- variant$id
    diagnostics[["complete_case"]] <- cc_diag[, c("variant_id", setdiff(names(cc_diag), "variant_id"))]
    for (tier in names(cc_fits)) {
      pooled <- pool_complete_case_v44(cc_fits[[tier]])
      association[[paste0("cc_", tier)]] <- association_row_v44(
        pooled, paste0("v44_s3_charls_pc_e0_", tolower(tier), "_complete_case"),
        variant, "E0", tier, formulas_e0[[tier]], cc_fits[[tier]]$diagnostics,
        0L, 0L, "complete_case_missing_data_sensitivity"
      )
    }

    sensitivity_masks <- list(
      boundary_excluded = master$pef_w1_rowmax != 30 & master$pef_w1_rowmax != 890,
      strict_measurement = master$pef_w1_strict_protocol %in% TRUE & master$pef_w1_valid_n >= 2
    )
    for (id in names(sensitivity_masks)) {
      ids <- master$participant_id[sensitivity_masks[[id]] %in% TRUE]
      pp <- period[period$participant_id %in% ids, , drop = FALSE]
      fits <- fit_across_imputations(
        imp, pp, knots, list(A1 = formulas_e0$A1),
        paste0("v44_s3_charls_pc_e0_a1_", id)
      )
      diagnostics[[id]] <- diagnostics_from_fits_v44(fits, variant$id)
      pooled <- pool_scalar_rubin(fits$A1, "E0")
      association[[id]] <- association_row_v44(
        pooled, paste0("v44_s3_charls_pc_e0_a1_", id), variant,
        "E0", "A1", formulas_e0$A1, fits$A1[[1]]$diagnostics,
        imp$m, maxit, paste0(id, "_measurement_sensitivity")
      )
    }

    w2_period <- build_w2_landmark_period(master, period)
    w2_fits <- fit_across_imputations(
      imp, w2_period, knots, list(A1 = formulas_e0$A1),
      "v44_s3_charls_pc_e0_a1_w2_landmark_conditional_survivor"
    )
    diagnostics[["w2_landmark"]] <- diagnostics_from_fits_v44(w2_fits, variant$id)
    w2_pool <- pool_scalar_rubin(w2_fits$A1, "E0")
    association[["w2_landmark"]] <- association_row_v44(
      w2_pool, "v44_s3_charls_pc_e0_a1_w2_landmark_conditional_survivor",
      variant, "E0", "A1", formulas_e0$A1, w2_fits$A1[[1]]$diagnostics,
      imp$m, maxit, "reverse_causation_conditional_survivor_sensitivity"
    )

    spline_formulas <- model_formulas("E0", spline_exposure = TRUE)
    spline_fits <- fit_across_imputations(
      imp, period, knots, list(A1 = spline_formulas$A1),
      "v44_s3_charls_pc_e0_spline"
    )
    diagnostics[["spline"]] <- diagnostics_from_fits_v44(spline_fits, variant$id)
    overall <- pool_multivariate_rubin(
      spline_fits$A1, c("E0_linear", "E0_nonlinear1", "E0_nonlinear2"),
      "v44_s3_charls_pc_e0_a1_spline_overall"
    )
    nonlin <- pool_multivariate_rubin(
      spline_fits$A1, c("E0_nonlinear1", "E0_nonlinear2"),
      "v44_s3_charls_pc_e0_a1_spline_nonlinear"
    )
    nonlinear <- dplyr::bind_rows(overall, nonlin)
    nonlinear <- data.frame(
      analysis_id = nonlinear$test_id, cohort = "CHARLS", variant_id = variant$id,
      test_id = nonlinear$test_id, terms = nonlinear$terms,
      df_test = nonlinear$df, statistic = nonlinear$statistic,
      p_value = nonlinear$p_value, m = nonlinear$m, gate_status = "PASS",
      stringsAsFactors = FALSE
    )
  } else {
    fits <- fit_across_imputations(
      imp, period, knots, list(A1 = formulas_e0$A1),
      paste0("v44_s3_charls_pc_e0_a1_", variant$id)
    )
    diagnostics[["a1"]] <- diagnostics_from_fits_v44(fits, variant$id)
    pooled <- pool_scalar_rubin(fits$A1, "E0")
    association[["a1"]] <- association_row_v44(
      pooled, paste0("v44_s3_charls_pc_e0_a1_", variant$id), variant,
      "E0", "A1", formulas_e0$A1, fits$A1[[1]]$diagnostics,
      imp$m, maxit
    )
  }

  association <- dplyr::bind_rows(association)
  list(
    association = association,
    diagnostics = dplyr::bind_rows(diagnostics), nonlinear = nonlinear,
    maximum_mce = max(association$monte_carlo_error_fraction)
  )
}

add_check_v44 <- function(x, id, pass, observed, expected, detail) {
  rbind(x, data.frame(
    check_id = id, status = if (isTRUE(pass)) "PASS" else "FAIL",
    observed = as.character(observed), expected = as.character(expected),
    detail = as.character(detail), stringsAsFactors = FALSE
  ))
}

validate_bound_registry_v44_1 <- function(
    root, relative_path, expected_id, expected_root, expected_n) {
  path <- file.path(root, relative_path)
  if (!file.exists(path) || dir.exists(path) || nzchar(Sys.readlink(path)) ||
      !identical(sha256_file(path), expected_root)) {
    return(list(pass = FALSE, detail = "registry missing, unsafe, or root drifted"))
  }
  x <- utils::read.csv(path, stringsAsFactors = FALSE, check.names = FALSE)
  required <- c(
    "authorization_id", "asset", "path", "required", "exists",
    "bytes", "sha256", "frozen_at"
  )
  if ("role" %in% names(x)) {
    required <- c(
      "authorization_id", "asset", "role", "path", "required", "exists",
      "bytes", "sha256", "frozen_at"
    )
  }
  schema <- identical(names(x), required) && nrow(x) == expected_n &&
    identical(unique(as.character(x$authorization_id)), expected_id) &&
    !anyDuplicated(x$asset) && !anyDuplicated(x$path) &&
    all(as.logical(x$required)) && all(as.logical(x$exists)) &&
    all(!grepl("^/", x$path)) && all(!grepl("(^|/)\\.\\.(/|$)", x$path))
  if (!schema) return(list(pass = FALSE, detail = "registry schema drifted"))
  current <- vapply(seq_len(nrow(x)), function(i) {
    current_path <- file.path(root, x$path[[i]])
    file.exists(current_path) && !dir.exists(current_path) &&
      !nzchar(Sys.readlink(current_path)) &&
      isTRUE(file.info(current_path)$size == suppressWarnings(as.numeric(x$bytes[[i]]))) &&
      identical(sha256_file(current_path), as.character(x$sha256[[i]]))
  }, logical(1))
  list(
    pass = all(current), registry = x, current = sum(current), total = length(current),
    detail = paste0(sum(current), "/", length(current), " registry assets current")
  )
}

validate_bound_manifest_v44_1 <- function(
    root, relative_path, expected_root, expected_assets) {
  path <- file.path(root, relative_path)
  if (!file.exists(path) || dir.exists(path) || nzchar(Sys.readlink(path)) ||
      !identical(sha256_file(path), expected_root)) {
    return(list(pass = FALSE, detail = "manifest missing, unsafe, or root drifted"))
  }
  x <- utils::read.csv(path, stringsAsFactors = FALSE, check.names = FALSE)
  required <- c(
    "asset", "path", "bytes", "sha256", "finalized_at", "pilot_id",
    "pilot_authorization_id", "pilot_authorization_registry_sha256",
    "formal_authorization_registry_sha256", "protocol_sha256", "script_sha256",
    "rng_kind", "r_version", "package_versions", "access_class"
  )
  schema <- identical(names(x), required) && nrow(x) == length(expected_assets) &&
    identical(as.character(x$asset), expected_assets) &&
    !anyDuplicated(x$asset) && !anyDuplicated(x$path) &&
    all(!grepl("^/", x$path)) && all(!grepl("(^|/)\\.\\.(/|$)", x$path)) &&
    all(as.character(x$access_class) ==
          "restricted nonpublic aggregate diagnostics; never a manuscript/public output")
  if (!schema) return(list(pass = FALSE, detail = "manifest schema drifted"))
  current <- vapply(seq_len(nrow(x)), function(i) {
    current_path <- file.path(root, x$path[[i]])
    file.exists(current_path) && !dir.exists(current_path) &&
      !nzchar(Sys.readlink(current_path)) &&
      isTRUE(file.info(current_path)$size == suppressWarnings(as.numeric(x$bytes[[i]]))) &&
      identical(sha256_file(current_path), as.character(x$sha256[[i]]))
  }, logical(1))
  list(
    pass = all(current), manifest = x, current = sum(current), total = length(current),
    detail = paste0(sum(current), "/", length(current), " manifest assets current")
  )
}

validate_later_resolution_evidence_v44_1 <- function(root, spec) {
  old_formal <- validate_bound_registry_v44_1(
    root, "work_v44/charls_anthropometric_qc_authorization_hashes_v44.csv",
    "charls_anthropometric_qc_formal_production_v44_0_6",
    "9136092e39406abcdac5d546d1e1e3cd704a7fa904b06a511d7830ca61b14ef5",
    16L
  )
  dense_auth <- validate_bound_registry_v44_1(
    root, spec$inputs$dense_pilot_authorization_registry,
    "charls_anthropometric_qc_later_aux_pilot_v44_1",
    "6340c62f36ddeb34fd261d11e28bf9171cb7127c3e817ffefcdd1174471ad186",
    9L
  )
  dense_manifest <- validate_bound_manifest_v44_1(
    root, spec$inputs$dense_pilot_manifest,
    "86a54a5b7cc95cfd17efdd4cecdc12c606fcf1ddc5c203d73aee5ffa28609a3a",
    c("convergence", "correlations", "summary")
  )
  acyclic_auth <- validate_bound_registry_v44_1(
    root, spec$inputs$acyclic_pilot_authorization_registry,
    "charls_anthropometric_qc_later_aux_acyclic_pilot_v44_2",
    "17a6f9902c531d6406244190c4515624615f984dfedeea3eb9327c1b3b31d522",
    13L
  )
  acyclic_manifest <- validate_bound_manifest_v44_1(
    root, spec$inputs$acyclic_pilot_manifest,
    "30f8ed1bb6b97ad52e4283ca6844ee4e54fd5b54da11cac65520b58576b1ae34",
    c("convergence", "correlations", "graph_audit", "summary")
  )
  bound_pass <- all(vapply(
    list(old_formal, dense_auth, dense_manifest, acyclic_auth, acyclic_manifest),
    function(x) isTRUE(x$pass), logical(1)
  ))
  if (!bound_pass) {
    return(list(
      pass = FALSE,
      detail = paste(
        old_formal$detail, dense_auth$detail, dense_manifest$detail,
        acyclic_auth$detail, acyclic_manifest$detail, sep = "; "
      )
    ))
  }
  dense_convergence_path <- file.path(
    root, dense_manifest$manifest$path[
      dense_manifest$manifest$asset == "convergence"
    ]
  )
  dense <- utils::read.csv(
    dense_convergence_path, stringsAsFactors = FALSE, check.names = FALSE
  )
  dense_summary_text <- paste(
    readLines(file.path(root, spec$inputs$dense_pilot_summary), warn = FALSE),
    collapse = "\n"
  )
  dense_final <- dense[
    dense$checkpoint_iteration == 160L & dense$hard_gate %in% TRUE,
    , drop = FALSE
  ]
  dense_failures <- sum(!(dense_final$pass %in% TRUE))
  dense_failed_rows <- dense_final[!(dense_final$pass %in% TRUE), , drop = FALSE]

  acyclic_convergence <- utils::read.csv(
    file.path(root, spec$inputs$acyclic_pilot_convergence),
    stringsAsFactors = FALSE, check.names = FALSE
  )
  acyclic_correlations <- utils::read.csv(
    file.path(root, spec$inputs$acyclic_pilot_correlations),
    stringsAsFactors = FALSE, check.names = FALSE
  )
  acyclic_graph <- utils::read.csv(
    file.path(root, spec$inputs$acyclic_pilot_graph_audit),
    stringsAsFactors = FALSE, check.names = FALSE
  )
  acyclic_summary_text <- paste(
    readLines(file.path(root, spec$inputs$acyclic_pilot_summary), warn = FALSE),
    collapse = "\n"
  )
  acyclic_final <- acyclic_convergence[
    acyclic_convergence$checkpoint_iteration == 160L &
      acyclic_convergence$hard_gate %in% TRUE,
    , drop = FALSE
  ]
  final_correlations <- acyclic_correlations[
    acyclic_correlations$checkpoint_iteration == 160L, , drop = FALSE
  ]
  failed_correlations <- final_correlations[
    !(final_correlations$plausibility_pass %in% TRUE), , drop = FALSE
  ]
  status_spec <- spec$nonestimable_registered_sensitivity
  manifest_path_binding_pass <- identical(
    as.character(acyclic_manifest$manifest$path[
      acyclic_manifest$manifest$asset == "convergence"
    ]), as.character(spec$inputs$acyclic_pilot_convergence)
  ) && identical(
    as.character(acyclic_manifest$manifest$path[
      acyclic_manifest$manifest$asset == "correlations"
    ]), as.character(spec$inputs$acyclic_pilot_correlations)
  ) && identical(
    as.character(acyclic_manifest$manifest$path[
      acyclic_manifest$manifest$asset == "graph_audit"
    ]), as.character(spec$inputs$acyclic_pilot_graph_audit)
  ) && identical(
    as.character(acyclic_manifest$manifest$path[
      acyclic_manifest$manifest$asset == "summary"
    ]), as.character(spec$inputs$acyclic_pilot_summary)
  )
  dense_manifest_path_binding_pass <- identical(
    as.character(dense_manifest$manifest$path[
      dense_manifest$manifest$asset == "summary"
    ]), as.character(spec$inputs$dense_pilot_summary)
  )
  dense_failure_key <- paste(
    dense_failed_rows$variable, dense_failed_rows$parameter, sep = "::"
  )
  evidence_pass <- nrow(dense) == 315L && nrow(dense_final) > 0L &&
    dense_failures == 2L && setequal(
      dense_failure_key,
      c("height_m_w3_aux::chain_mean", "height_m_w2_aux::chain_sd")
    ) && isTRUE(dense_manifest_path_binding_pass) &&
    grepl("Logged events: 0", dense_summary_text, fixed = TRUE) &&
    grepl("Numerical warnings: 0", dense_summary_text, fixed = TRUE) &&
    grepl("Eligible for an iteration-only formal amendment: FALSE",
          dense_summary_text, fixed = TRUE) &&
    nrow(acyclic_convergence) == 315L &&
    nrow(acyclic_correlations) == 30L && nrow(acyclic_graph) == 8L &&
    all(acyclic_graph$status == "PASS") && nrow(acyclic_final) > 0L &&
    all(acyclic_final$pass %in% TRUE) && nrow(final_correlations) == 6L &&
    all(final_correlations$positive_direction_preserved %in% TRUE) &&
    nrow(failed_correlations) == 1L &&
    identical(as.character(failed_correlations$pair_id), "weight_w1_w3") &&
    isTRUE(all.equal(
      as.numeric(failed_correlations$correlation_mean),
      as.numeric(status_spec$completed_correlation_mean), tolerance = 1e-15
    )) &&
    isTRUE(all.equal(
      as.numeric(failed_correlations$observed_pair_correlation),
      as.numeric(status_spec$observed_pair_correlation), tolerance = 1e-15
    )) &&
    isTRUE(all.equal(
      as.numeric(failed_correlations$absolute_difference_from_observed_pair),
      as.numeric(status_spec$absolute_difference), tolerance = 1e-15
    )) &&
    isTRUE(all.equal(
      as.numeric(failed_correlations$between_chain_spread),
      as.numeric(status_spec$between_chain_spread), tolerance = 1e-15
    )) &&
    as.numeric(status_spec$absolute_difference) >
      as.numeric(status_spec$frozen_maximum_absolute_difference) &&
    identical(status_spec$positive_direction_required, TRUE) &&
    as.numeric(status_spec$between_chain_spread) <=
      as.numeric(status_spec$frozen_maximum_between_chain_spread) &&
    identical(as.character(status_spec$id), "who_block_later_aux") &&
    identical(as.character(status_spec$disposition), "NOT_STABLY_ESTIMABLE") &&
    identical(as.character(status_spec$formal_execution_disposition),
              "NOT_EXECUTED_DIAGNOSTIC_INELIGIBILITY") &&
    identical(as.character(status_spec$resolution_evidence_id),
              "charls_anthropometric_qc_later_aux_acyclic_pilot_v44") &&
    identical(unlist(status_spec$requested_fit_tiers, use.names = FALSE), "A1") &&
    identical(as.character(status_spec$reason_code),
              "ACYCLIC_CORRELATION_PLAUSIBILITY_GATE_FAILED") &&
    identical(as.character(status_spec$failed_pair_id), "weight_w1_w3") &&
    identical(as.integer(status_spec$requested_seed), 440403L) &&
    identical(status_spec$mortality_model_fitted_after_diagnostic_failure, FALSE) &&
    identical(status_spec$effect_estimate_available, FALSE) &&
    isTRUE(manifest_path_binding_pass) &&
    grepl("Logged events: 0", acyclic_summary_text, fixed = TRUE) &&
    grepl("Numerical warnings: 0", acyclic_summary_text, fixed = TRUE) &&
    grepl("Final completed-data gates: PASS", acyclic_summary_text, fixed = TRUE) &&
    grepl("Later-wave WHO parent-range gate: PASS (failures=0)",
          acyclic_summary_text, fixed = TRUE) &&
    grepl("Later-wave observed-cell preservation: PASS (changes=0)",
          acyclic_summary_text, fixed = TRUE) &&
    grepl("Eligible for the exact acyclic formal amendment: FALSE",
          acyclic_summary_text, fixed = TRUE)
  list(
    pass = evidence_pass, dense_failures = dense_failures,
    acyclic_rhat_failures = sum(!(acyclic_final$pass %in% TRUE)),
    correlation_failures = nrow(failed_correlations),
    failed_pair_id = if (nrow(failed_correlations) == 1L)
      as.character(failed_correlations$pair_id[[1]]) else NA_character_,
    absolute_difference = if (nrow(failed_correlations) == 1L)
      as.numeric(failed_correlations$absolute_difference_from_observed_pair[[1]]) else NA_real_,
    detail = paste0(
      "old formal/dense/acyclic bindings current; dense terminal failures=",
      dense_failures, "; acyclic Rhat failures=",
      sum(!(acyclic_final$pass %in% TRUE)),
      "; acyclic correlation failures=", nrow(failed_correlations),
      "; failed pair=", if (nrow(failed_correlations) == 1L)
        as.character(failed_correlations$pair_id[[1]]) else "not_unique"
    )
  )
}

main_v44_1 <- function() {
  root <- project_root_v44()
  if (identical(Sys.getenv("V44_1_1_CHARLS_QC_REFRESH", "0"), "1")) {
    stop("v44.1.1 is first-production-only; refresh requires a new governed version.",
         call. = FALSE)
  }
  refresh <- FALSE
  spec_path <- file.path(
    root, "work_v44/charls_anthropometric_qc_resolution_spec_v44_1_1.yml"
  )
  contract_path <- file.path(
    root, "work_v44/charls_anthropometric_qc_resolution_contract_v44_1_1.yml"
  )
  seed_path <- file.path(
    root, "work_v44/charls_anthropometric_qc_resolution_seed_ledger_v44_1_1.csv"
  )
  script_path <- file.path(
    root, "R/v44/05_charls_anthropometric_qc_resolution_v44_1_1.R"
  )
  spec <- yaml::read_yaml(spec_path)
  contract <- yaml::read_yaml(contract_path)
  if (!identical(spec$spec_id, contract$contract_id) ||
      !identical(spec$version, contract$version)) {
    stop("v44.1.1 specification and contract ID/version mismatch.", call. = FALSE)
  }
  authorization_path <- file.path(root, spec$inputs$v44_authorization_registry)
  authorization_before <- validate_v44_authorization(root, authorization_path)
  if (!authorization_before$pass) {
    stop("v44.1.1 formal-resolution authorization is not current: ",
         authorization_before$detail, call. = FALSE)
  }
  predecessor_before <- bootstrap_validate_predecessor_v44_1_0(root)
  contract_preflight <- bootstrap_validate_contract_schema_v44_1_1(root)
  if (!predecessor_before$pass || !contract_preflight$pass) {
    stop(
      "v44.1.1 repeated pre-data governance preflight failed: ",
      predecessor_before$detail, "; ", contract_preflight$detail,
      call. = FALSE
    )
  }
  gate <- yaml::read_yaml(file.path(root, spec$inputs$v44_gate_state))
  if (!identical(gate$authorization_id,
                 "charls_anthropometric_qc_formal_resolution_v44_1_1") ||
      !identical(gate$spec_id, spec$spec_id) ||
      !identical(gate$version, spec$version) ||
      !identical(spec$status, "authorized_for_first_formal_resolution_execution") ||
      !isTRUE(gate$formal_production_allowed) ||
      !isTRUE(gate$first_production_only) ||
      !identical(gate$authorized_entrypoint,
                 "R/v44/05_charls_anthropometric_qc_resolution_v44_1_1.R") ||
      !identical(gate$authorization_environment_variable,
                 "V44_1_1_CHARLS_QC_AUTH_SHA256") ||
      !identical(gate$preflight_only_environment_variable,
                 "V44_1_1_CHARLS_QC_PREFLIGHT_ONLY") ||
      !identical(gate$refresh_environment_variable,
                 "V44_1_1_CHARLS_QC_REFRESH") ||
      !identical(gate$predecessor_authorization_registry_sha256,
                 "bece61fc7863694c18888774c28ddfb9af9b5ac613afdb45b5d5919a1458d8c0") ||
      !identical(gate$predecessor_failure$failure_code,
                 "CONTRACT_YAML11_IDENTIFIER_COERCION") ||
      !identical(gate$predecessor_failure$failure_phase,
                 "POST_ANALYSIS_PRE_STAGING_CONTRACT_SCHEMA_VALIDATION") ||
      !identical(gate$predecessor_failure$public_output_count, 0L) ||
      !identical(gate$predecessor_failure$manifest_present, FALSE) ||
      !identical(gate$predecessor_failure$reuse, "FORBIDDEN") ||
      !identical(gate$predecessor_failure$scientific_delta, "NONE") ||
      !identical(gate$registered_output_cardinalities$manifest_rows, 42L) ||
      !identical(gate$registered_output_cardinalities$authorization_registry_rows, 29L) ||
      !identical(
        gate$registered_output_cardinalities$predecessor_authorization_assets_recursively_current,
        27L
      ) ||
      isTRUE(gate$refresh_allowed) ||
      !identical(unlist(gate$active_variant_ids, use.names = FALSE), c(
        "who_block_no_later_aux", "who_component_no_later_aux",
        "pcornet_block_no_later_aux"
      )) ||
      !identical(unlist(gate$forbidden_active_variant_ids, use.names = FALSE),
                 "who_block_later_aux") ||
      !identical(gate$registered_nonestimable_variant$status,
                 "NOT_STABLY_ESTIMABLE") ||
      !identical(gate$registered_nonestimable_variant$formal_execution_disposition,
                 "NOT_EXECUTED_DIAGNOSTIC_INELIGIBILITY") ||
      !identical(gate$registered_nonestimable_variant$mortality_model_fitted, FALSE) ||
      !identical(gate$registered_nonestimable_variant$effect_estimate_available, FALSE)) {
    stop("v44.1.1 machine-readable gate state does not authorize this execution.", call. = FALSE)
  }
  RNGkind("Mersenne-Twister", "Inversion", "Rejection")
  run_id <- paste0(
    "charls_v44_1_1_", format(Sys.time(), "%Y%m%dT%H%M%S", tz = "Asia/Shanghai"),
    "_pid", Sys.getpid()
  )
  contract_paths <- vapply(
    contract$outputs, function(x) as.character(x$path), character(1)
  )
  allowed_prefixes <- unlist(
    contract$immutability$permitted_output_prefixes, use.names = FALSE
  )
  path_allowed <- vapply(contract_paths, function(path) {
    any(startsWith(path, allowed_prefixes))
  }, logical(1))
  if (!all(path_allowed)) {
    stop("Contract declares a path outside the permitted v44.1.1 prefixes: ",
         paste(contract_paths[!path_allowed], collapse = "; "), call. = FALSE)
  }
  preexisting_public_files <- unlist(lapply(
    c("results/v44_1_1", "output/qa/v44_1_1"), function(relative_dir) {
      path <- file.path(root, relative_dir)
      if (!dir.exists(path)) return(character())
      list.files(path, recursive = TRUE, all.files = TRUE, no.. = TRUE,
                 full.names = FALSE)
    }
  ), use.names = FALSE)
  if (length(preexisting_public_files)) {
    stop("v44.1.1 public directory is not empty before first production.", call. = FALSE)
  }
  exact25_before <- validate_exact25_v44(
    file.path(root, spec$inputs$stage3_authorization_registry),
    spec$inputs$stage3_authorization_registry_sha256
  )
  if (!exact25_before$pass) stop("Stage 3 exact-25 is not current before v44.1.", call. = FALSE)
  completion_inputs_before <- validate_completion_inputs_v44(root, spec)
  if (!completion_inputs_before$pass) {
    stop("Stage 3 completion-bound v44.1.1 inputs are not current before execution.", call. = FALSE)
  }
  later_evidence_before <- validate_later_resolution_evidence_v44_1(root, spec)
  if (!later_evidence_before$pass) {
    stop("The frozen later-aux non-estimability evidence did not validate before data access: ",
         later_evidence_before$detail, call. = FALSE)
  }

  ledger <- readRDS(file.path(root, spec$inputs$stage3_analysis_ledger))
  core <- readRDS(file.path(root, spec$inputs$charls_core))
  master <- ledger$person_master
  period <- ledger$person_period_skeleton
  knots <- utils::read.csv(file.path(root, spec$inputs$stage3_charls_knots), stringsAsFactors = FALSE)
  v43_registry <- utils::read.csv(
    file.path(root, spec$inputs$stage3_charls_registry), stringsAsFactors = FALSE,
    check.names = FALSE
  )
  if (anyDuplicated(master$participant_id) || anyDuplicated(core$participant_id)) {
    stop("Duplicate CHARLS participant key.", call. = FALSE)
  }
  core_match <- match(master$participant_id, core$participant_id)
  if (anyNA(core_match)) stop("CHARLS core join is incomplete.", call. = FALSE)
  raw_master <- master
  raw_master$height_m_w1_raw <- suppressWarnings(as.numeric(master$height_m_w1))
  raw_master$weight_kg_w1_raw <- suppressWarnings(as.numeric(core$weight_kg_w1[core_match]))

  frozen <- spec$frozen_population_and_exposure
  e0_alias_max_diff <- max(abs(
    as.numeric(master$E0) - as.numeric(master$E0_lower_pef_sex_specific_sd)
  ), na.rm = TRUE)
  e0b_alias_max_diff <- max(abs(
    as.numeric(master$E0b) - as.numeric(master$E0b_lower_pef_per_100_l_min)
  ), na.rm = TRUE)
  alias_tolerance <- as.numeric(frozen$exposure_alias_max_absolute_difference)
  e0_alias_pass <- length(master$E0) == length(master$E0_lower_pef_sex_specific_sd) &&
    identical(
      unname(is.na(master$E0)),
      unname(is.na(master$E0_lower_pef_sex_specific_sd))
    ) &&
    all(is.finite(as.numeric(master$E0)[!is.na(master$E0)])) &&
    all(is.finite(as.numeric(master$E0_lower_pef_sex_specific_sd)[
      !is.na(master$E0_lower_pef_sex_specific_sd)
    ])) &&
    is.finite(e0_alias_max_diff) && e0_alias_max_diff <= alias_tolerance
  e0b_alias_pass <- length(master$E0b) == length(master$E0b_lower_pef_per_100_l_min) &&
    identical(
      unname(is.na(master$E0b)),
      unname(is.na(master$E0b_lower_pef_per_100_l_min))
    ) &&
    all(is.finite(as.numeric(master$E0b)[!is.na(master$E0b)])) &&
    all(is.finite(as.numeric(master$E0b_lower_pef_per_100_l_min)[
      !is.na(master$E0b_lower_pef_per_100_l_min)
    ])) &&
    is.finite(e0b_alias_max_diff) && e0b_alias_max_diff <= alias_tolerance
  if (nrow(master) != as.integer(frozen$participants) ||
      sum(master$event_any == 1L) != as.integer(frozen$deaths) ||
      nrow(period) != as.integer(frozen$person_period_rows) ||
      sum(period$nominal_years) != as.numeric(frozen$nominal_person_years) ||
      !identical(alias_tolerance, 1e-12) || !e0_alias_pass || !e0b_alias_pass) {
    stop("Frozen CHARLS population/exposure/time anchors drifted.", call. = FALSE)
  }

  variants <- variant_catalog_v44(spec)
  expected_variant_ids <- c(
    "who_block_no_later_aux", "who_component_no_later_aux",
    "pcornet_block_no_later_aux"
  )
  if (!identical(names(variants), expected_variant_ids)) {
    stop("v44 variant order or IDs drifted.", call. = FALSE)
  }
  expected_bounds_ids <- c(
    "who_operational", "who_operational", "pcornet_sensitivity"
  )
  expected_later <- c(FALSE, FALSE, FALSE)
  expected_blocks <- c(TRUE, FALSE, TRUE)
  expected_tiers <- list(c("A0", "A1", "A2"), "A1", "A1")
  if (!identical(unname(vapply(variants, `[[`, character(1), "bounds_id")), expected_bounds_ids) ||
      !identical(unname(vapply(variants, `[[`, logical(1), "later")), expected_later) ||
      !identical(unname(vapply(variants, `[[`, logical(1), "block")), expected_blocks) ||
      !identical(unname(lapply(variants, `[[`, "tiers")), expected_tiers) ||
      !identical(variants[[1]]$h, c(1, 2.7)) ||
      !identical(variants[[1]]$w, c(20, 350)) ||
      !identical(variants[[1]]$b, c(11, 75)) ||
      !identical(variants[[3]]$h, c(1.219, 2.134)) ||
      !identical(variants[[3]]$w, c(22.7, 317.5)) ||
      !identical(variants[[3]]$b, c(15, 90))) {
    stop("v44.1.1 frozen variant semantics drifted.", call. = FALSE)
  }
  seed_ledger <- utils::read.csv(seed_path, stringsAsFactors = FALSE)
  expected_seed_columns <- c(
    "variant_id", "seed", "initial_m", "maximum_m", "convergence_checkpoints",
    "maximum_maxit", "improved_rhat_max", "rng_kind", "role"
  )
  if (!identical(names(seed_ledger), expected_seed_columns) ||
      !identical(seed_ledger$variant_id, expected_variant_ids) ||
      !identical(as.integer(seed_ledger$seed),
                 unname(vapply(variants, `[[`, integer(1), "seed"))) ||
      any(as.integer(seed_ledger$initial_m) != as.integer(spec$multiple_imputation$m)) ||
      any(as.integer(seed_ledger$maximum_m) !=
            as.integer(spec$multiple_imputation$maximum_m_if_monte_carlo_gate_fails)) ||
      any(as.integer(seed_ledger$maximum_maxit) !=
            as.integer(spec$multiple_imputation$maximum_maxit)) ||
      any(as.numeric(seed_ledger$improved_rhat_max) !=
            as.numeric(spec$multiple_imputation$improved_rhat_max)) ||
      any(as.character(seed_ledger$rng_kind) !=
            "Mersenne-Twister|Inversion|Rejection") ||
      !identical(
        as.character(seed_ledger$role),
        unname(vapply(variants, `[[`, character(1), "role"))
      ) ||
      any(as.character(seed_ledger$convergence_checkpoints) !=
            paste(unlist(spec$multiple_imputation$convergence_checkpoints), collapse = "|"))) {
    stop("v44.1.1 seed ledger does not match the frozen specification.", call. = FALSE)
  }

  source_audits <- list()
  main_registry <- NULL
  sensitivity_registry <- list()
  nonlinear_tests <- NULL
  convergence_all <- list()
  mi_diagnostics <- list()
  mi_escalation <- list()
  model_diagnostics <- list()
  primary_association <- NULL

  for (variant_id in names(variants)) {
    variant <- variants[[variant_id]]
    message("v44.1.1 variant starting: ", variant_id)
    prepared <- prepare_variant_v44(raw_master, variant)
    clean_master <- prepared$master
    source_audits[[variant_id]] <- prepared$audit
    mi_data <- make_mi_input_v44(clean_master, variant)
    mi_spec <- freeze_mi_spec_v44(mi_data, variant, spec)

    run_one_m <- function(m) {
      mi_run <- run_mi_convergence_schedule(
        mi_data, mi_spec, m = as.integer(m),
        analysis_id = paste0("v44_1_1_charls_anthropometric_", variant_id),
        mi_run = paste0("m", m)
      )
      logged_events <- if (is.null(mi_run$imp$loggedEvents)) {
        0L
      } else {
        nrow(mi_run$imp$loggedEvents)
      }
      if (logged_events != 0L) {
        stop("MICE logged events are forbidden before outcome fitting for ",
             variant_id, ": ", logged_events, call. = FALSE)
      }
      completion <- validate_completed_mids_v44(
        mi_run$imp, mi_data, clean_master, variant, knots
      )
      if (completion$identity_failures != 0L || completion$range_failures != 0L ||
          completion$observed_value_changes != 0L || completion$smoking_conflicts != 0L) {
        stop(
          "Completed-data hard gate failed for ", variant_id,
          ": identity=", completion$identity_failures,
          "; range=", completion$range_failures,
          "; observed changes=", completion$observed_value_changes,
          "; smoking=", completion$smoking_conflicts,
          call. = FALSE
        )
      }
      fitted <- fit_variant_bundle_v44(
        mi_run$imp, clean_master, period, knots, variant,
        mi_run$selected_maxit
      )
      list(mi = mi_run, completion = completion, fitted = fitted)
    }

    run <- run_one_m(mi_spec$initial_m)
    initial_mce <- run$fitted$maximum_mce
    escalated <- initial_mce > mi_spec$monte_carlo_error_fraction_max
    if (escalated) {
      message("v44.1.1 variant escalating to m=", mi_spec$maximum_m, ": ", variant_id)
      run <- run_one_m(mi_spec$maximum_m)
    }
    if (run$fitted$maximum_mce > mi_spec$monte_carlo_error_fraction_max) {
      stop("Monte Carlo error fraction remains above 0.10 for ", variant_id, call. = FALSE)
    }
    mi_escalation[[variant_id]] <- data.frame(
      variant_id = variant_id,
      initial_m = as.integer(mi_spec$initial_m),
      initial_maximum_monte_carlo_error_fraction = initial_mce,
      escalation_threshold = mi_spec$monte_carlo_error_fraction_max,
      escalated = escalated,
      final_m = run$mi$imp$m,
      final_maximum_monte_carlo_error_fraction = run$fitted$maximum_mce,
      decision_rule = "escalate from m=50 to m=100 only when initial maximum MCE fraction exceeds 0.10",
      stringsAsFactors = FALSE
    )

    convergence <- run$mi$checkpoint_diagnostics
    convergence$variant_id <- variant_id
    convergence_all[[variant_id]] <- convergence[, c(
      "variant_id", setdiff(names(convergence), "variant_id")
    )]
    logged_events <- if (is.null(run$mi$imp$loggedEvents)) 0L else nrow(run$mi$imp$loggedEvents)
    mi_diagnostics[[variant_id]] <- data.frame(
      variant_id = variant_id, m = run$mi$imp$m,
      selected_maxit = run$mi$selected_maxit,
      active_target_n = sum(nzchar(mi_spec$method)), logged_events = logged_events,
      anthropometric_identity_failures = run$completion$identity_failures,
      completed_range_failures = run$completion$range_failures,
      completed_bmi_outside_active_range_n =
        run$completion$completed_bmi_outside_active_range_n,
      observed_valid_value_changes = run$completion$observed_value_changes,
      smoking_conflicts = run$completion$smoking_conflicts,
      maximum_monte_carlo_error_fraction = run$fitted$maximum_mce,
      convergence_pass = all(
        !run$mi$final_convergence$hard_gate |
          run$mi$final_convergence$pass
      ),
      stringsAsFactors = FALSE
    )
    model_diagnostics[[variant_id]] <- run$fitted$diagnostics
    if (identical(variant$role, "primary_v44_qc_rerun")) {
      main_registry <- run$fitted$association
      nonlinear_tests <- run$fitted$nonlinear
      primary_association <- main_registry[
        main_registry$analysis_id == "v44_s3_charls_pc_e0_a1", , drop = FALSE
      ]
    } else {
      sensitivity_registry[[variant_id]] <- run$fitted$association
    }
    rm(run, mi_data, mi_spec, clean_master)
    invisible(gc(verbose = FALSE))
    message("v44.1.1 variant completed: ", variant_id)
  }

  source_audit <- dplyr::bind_rows(source_audits)
  source_audit_internal <- source_audit
  public_count_columns <- c(
    "height_flag_n", "weight_flag_n", "bmi_flag_n", "any_flag_n",
    "flagged_event_n"
  )
  source_audit$small_cell_suppressed <- FALSE
  for (column in public_count_columns) {
    suppress <- is.finite(source_audit[[column]]) &
      source_audit[[column]] > 0 & source_audit[[column]] < 5
    source_audit[[column]][suppress] <- NA_integer_
    source_audit$small_cell_suppressed <-
      source_audit$small_cell_suppressed | suppress
  }
  # Complementary suppression prevents a blank primary flag count from being
  # reconstructed as post-clean missing minus pre-clean missing. The internal
  # unsuppressed table remains available only in memory for hard-gate checks.
  complementary_columns <- c(
    "postclean_height_missing_n", "postclean_weight_missing_n",
    "postclean_parent_union_missing_n"
  )
  source_audit[source_audit$small_cell_suppressed, complementary_columns] <- NA_integer_
  sensitivity_registry <- dplyr::bind_rows(sensitivity_registry)
  convergence <- dplyr::bind_rows(convergence_all)
  convergence_public <- convergence[, intersect(c(
    "variant_id", "mi_run", "checkpoint_order", "checkpoint_iteration",
    "selected_checkpoint", "variable", "parameter", "category_level", "missing_n",
    "iterations", "chains", "rhat", "hard_gate", "pass",
    "diagnostic_status", "rank_normalized_split_rhat", "folded_split_rhat",
    "detail"
  ), names(convergence)), drop = FALSE]
  mi_diagnostics <- dplyr::bind_rows(mi_diagnostics)
  mi_escalation <- dplyr::bind_rows(mi_escalation)
  model_diagnostics <- dplyr::bind_rows(model_diagnostics)
  variant_disposition <- data.frame(
    variant_id = c(
      "who_block_no_later_aux", "who_component_no_later_aux",
      "who_block_later_aux", "pcornet_block_no_later_aux"
    ),
    registered_role = c(
      "primary_v44_qc_rerun", "measurement-component sensitivity",
      "postbaseline-auxiliary sensitivity", "stricter-range sensitivity"
    ),
    formal_execution_disposition = c(
      "EXECUTED_FROM_SCRATCH", "EXECUTED_FROM_SCRATCH",
      "NOT_EXECUTED_DIAGNOSTIC_INELIGIBILITY", "EXECUTED_FROM_SCRATCH"
    ),
    estimability_status = c(
      "ESTIMATED", "ESTIMATED", "NOT_STABLY_ESTIMABLE", "ESTIMATED"
    ),
    requested_fit_tiers = c("A0|A1|A2", "A1", "A1", "A1"),
    mortality_model_fitted = c(TRUE, TRUE, FALSE, TRUE),
    effect_estimate_available = c(TRUE, TRUE, FALSE, TRUE),
    effect_rows_expected = c(12L, 1L, 0L, 1L),
    effect_rows_observed = c(
      nrow(main_registry),
      sum(sensitivity_registry$variant_id == "who_component_no_later_aux"),
      0L,
      sum(sensitivity_registry$variant_id == "pcornet_block_no_later_aux")
    ),
    reason_code = c(
      "REGISTERED_FORMAL_ESTIMABLE_SET", "REGISTERED_FORMAL_ESTIMABLE_SET",
      "ACYCLIC_CORRELATION_PLAUSIBILITY_GATE_FAILED",
      "REGISTERED_FORMAL_ESTIMABLE_SET"
    ),
    resolution_evidence_id = c(
      run_id, run_id, "charls_anthropometric_qc_later_aux_acyclic_pilot_v44", run_id
    ),
    resolution_frozen_before_v44_1_0_execution = TRUE,
    manuscript_reporting_rule = c(
      "report as the CHARLS primary analysis only if the full v44.1.1 bundle passes",
      "report as a measurement-component sensitivity",
      "report disposition only; do not report or infer an HR, CI, or P value",
      "report as a stricter-range sensitivity"
    ),
    gate_status = "PASS",
    stringsAsFactors = FALSE
  )

  comparison_rows <- list()
  for (i in seq_len(nrow(main_registry))) {
    current <- main_registry[i, , drop = FALSE]
    comparator_id <- sub("^v44_", "v43_", current$analysis_id)
    comparator <- v43_registry[v43_registry$analysis_id == comparator_id, , drop = FALSE]
    if (nrow(comparator) != 1L) stop("Missing unique v43 comparator: ", comparator_id, call. = FALSE)
    delta <- current$estimate - comparator$estimate
    relative <- 100 * abs(delta) / abs(comparator$estimate)
    comparison_rows[[length(comparison_rows) + 1L]] <- data.frame(
      analysis_id = current$analysis_id, comparator_analysis_id = comparator_id,
      model_tier = current$model_tier, comparator_log_hr = comparator$estimate,
      current_log_hr = current$estimate, absolute_log_hr_change = abs(delta),
      relative_log_effect_change_percent = relative, hr_ratio = exp(delta),
      stability_class = if (sign(current$estimate) != sign(comparator$estimate)) {
        "material_direction_reversal"
      } else if (relative <= 10) "stable" else if (relative <= 20) "moderate" else "material",
      direction_preserved = sign(current$estimate) == sign(comparator$estimate),
      ci_excludes_null = current$ci_low > 0 | current$ci_high < 0,
      stringsAsFactors = FALSE
    )
  }
  if (nrow(primary_association) != 1L) stop("Primary v44 A1 row is not unique.", call. = FALSE)
  for (i in seq_len(nrow(sensitivity_registry))) {
    current <- sensitivity_registry[i, , drop = FALSE]
    delta <- current$estimate - primary_association$estimate
    relative <- 100 * abs(delta) / abs(primary_association$estimate)
    comparison_rows[[length(comparison_rows) + 1L]] <- data.frame(
      analysis_id = current$analysis_id,
      comparator_analysis_id = primary_association$analysis_id,
      model_tier = current$model_tier,
      comparator_log_hr = primary_association$estimate,
      current_log_hr = current$estimate, absolute_log_hr_change = abs(delta),
      relative_log_effect_change_percent = relative, hr_ratio = exp(delta),
      stability_class = if (sign(current$estimate) != sign(primary_association$estimate)) {
        "material_direction_reversal"
      } else if (relative <= 10) "stable" else if (relative <= 20) "moderate" else "material",
      direction_preserved = sign(current$estimate) == sign(primary_association$estimate),
      ci_excludes_null = current$ci_low > 0 | current$ci_high < 0,
      stringsAsFactors = FALSE
    )
  }
  comparison <- dplyr::bind_rows(comparison_rows)

  expected_main_ids <- c(
    paste0("v44_s3_charls_pc_e0_", tolower(c("A0", "A1", "A2"))),
    paste0("v44_s3_charls_pc_e0b_", tolower(c("A0", "A1", "A2"))),
    paste0("v44_s3_charls_pc_e0_", tolower(c("A0", "A1", "A2")), "_complete_case"),
    "v44_s3_charls_pc_e0_a1_boundary_excluded",
    "v44_s3_charls_pc_e0_a1_strict_measurement",
    "v44_s3_charls_pc_e0_a1_w2_landmark_conditional_survivor"
  )
  expected_sensitivity_ids <- paste0(
    "v44_s3_charls_pc_e0_a1_",
    c(
      "who_component_no_later_aux", "pcornet_block_no_later_aux"
    )
  )
  expected_nonlinear_ids <- c(
    "v44_s3_charls_pc_e0_a1_spline_overall",
    "v44_s3_charls_pc_e0_a1_spline_nonlinear"
  )
  frozen_comparison_map <- dplyr::bind_rows(
    spec$comparison_interpretation$exact_analysis_to_comparator
  )
  exact_id_sets_pass <- !anyDuplicated(main_registry$analysis_id) &&
    !anyDuplicated(sensitivity_registry$analysis_id) &&
    !anyDuplicated(nonlinear_tests$analysis_id) &&
    setequal(main_registry$analysis_id, expected_main_ids) &&
    setequal(sensitivity_registry$analysis_id, expected_sensitivity_ids) &&
    setequal(nonlinear_tests$analysis_id, expected_nonlinear_ids) &&
    !anyDuplicated(comparison$analysis_id) &&
    setequal(comparison$analysis_id, c(expected_main_ids, expected_sensitivity_ids)) &&
    identical(as.character(comparison$analysis_id),
              as.character(frozen_comparison_map$analysis_id)) &&
    identical(as.character(comparison$comparator_analysis_id),
              as.character(frozen_comparison_map$comparator_analysis_id))

  checks <- data.frame(
    check_id = character(), status = character(), observed = character(),
    expected = character(), detail = character(), stringsAsFactors = FALSE
  )
  checks <- add_check_v44(
    checks, "spec_contract_hash_binding",
    authorization_before$pass && contract_preflight$pass,
    paste0("version=", spec$version, "; spec=", sha256_file(spec_path),
           "; contract=", sha256_file(contract_path), "; script=", sha256_file(script_path),
           "; preflight=", contract_preflight$detail),
    "matching ID/version/current hashes and exact pre-data character schema",
    "Governance, executable, output paths, column types, and exact schemas are content-addressed."
  )
  checks <- add_check_v44(
    checks, "v44_1_1_authorization_current_before_execution",
    authorization_before$pass && predecessor_before$pass,
    paste(authorization_before$detail, predecessor_before$detail, sep = "; "),
    "29/29 v44.1.1 assets current; predecessor root exact and 27/27 current",
    "Formal resolution is fail-closed against both the patch and immutable failed-run evidence."
  )
  checks <- add_check_v44(
    checks, "later_aux_resolution_evidence_current_before_data_access",
    later_evidence_before$pass, later_evidence_before$detail,
    "dense pilot ineligible and sole acyclic pilot ineligible from one correlation-plausibility failure",
    "Non-estimability was recomputed from content-addressed effect-blind evidence before analysis data were opened."
  )
  checks <- add_check_v44(
    checks, "stage3_exact25_current_before_execution", exact25_before$pass,
    exact25_before$detail, "25/25 current", "v44.1.1 is additive."
  )
  checks <- add_check_v44(
    checks, "frozen_population_exposure_time_anchors", TRUE,
    paste0(
      "N=12555; deaths=1735; rows=45503; nominal years=104459; E0 max alias diff=",
      signif(e0_alias_max_diff, 6), "; E0b max alias diff=", signif(e0b_alias_max_diff, 6)
    ),
    "count/time anchors exact; E0 and E0b alias maximum absolute difference <=1e-12",
    "No exposure, outcome, sample, or time-basis change."
  )
  who_rows <- source_audit_internal[
    source_audit_internal$bounds %in%
      source_audit_internal$bounds[grepl("height=1-2.7", source_audit_internal$bounds)],
    , drop = FALSE
  ]
  checks <- add_check_v44(
    checks, "who_source_qc_anchors",
    nrow(who_rows) == 2L && all(who_rows$height_flag_n == 9L) &&
      all(who_rows$weight_flag_n == 3L) && all(who_rows$bmi_flag_n == 11L) &&
      all(who_rows$any_flag_n == 13L) && all(who_rows$flagged_event_n == 4L),
    "all internal WHO anchors matched; public cells below 5 suppressed",
    "frozen internal anchors matched",
    "The same raw W1 values are screened independently; small public cells are not disclosed."
  )
  pc <- source_audit_internal[
    source_audit_internal$variant_id == "pcornet_block_no_later_aux", , drop = FALSE
  ]
  checks <- add_check_v44(
    checks, "pcornet_source_qc_anchors",
    nrow(pc) == 1L && pc$height_flag_n == 11L && pc$weight_flag_n == 4L &&
      pc$bmi_flag_n == 51L && pc$any_flag_n == 55L && pc$flagged_event_n == 25L,
    "all internal PCORnet anchors matched; public cells below 5 suppressed",
    "frozen internal anchors matched",
    "PCORnet-style bounds are a stricter alternative; small public cells are not disclosed."
  )
  source_privacy_pass <- all(vapply(public_count_columns, function(column) {
    internal <- source_audit_internal[[column]]
    public <- source_audit[[column]]
    small <- is.finite(internal) & internal > 0 & internal < 5
    all(is.na(public[small])) &&
      isTRUE(all.equal(public[!small], internal[!small], check.attributes = FALSE))
  }, logical(1))) && all(source_audit$small_cell_suppressed == vapply(
    seq_len(nrow(source_audit_internal)), function(i) {
      any(vapply(public_count_columns, function(column) {
        value <- source_audit_internal[[column]][[i]]
        is.finite(value) && value > 0 && value < 5
      }, logical(1)))
    }, logical(1)
  )) && all(vapply(complementary_columns, function(column) {
    affected <- source_audit$small_cell_suppressed
    all(is.na(source_audit[[column]][affected])) &&
      isTRUE(all.equal(
        source_audit[[column]][!affected],
        source_audit_internal[[column]][!affected],
        check.attributes = FALSE
      ))
  }, logical(1)))
  checks <- add_check_v44(
    checks, "source_audit_small_cell_privacy", source_privacy_pass,
    paste0("suppressed_rows=", sum(source_audit$small_cell_suppressed)),
    "every positive source-QC flag/event count below 5 blanked; post-clean missing margins complementarily suppressed on affected rows",
    "Complementary suppression prevents reconstruction from raw and post-clean missing margins."
  )
  checks <- add_check_v44(
    checks, "mi_completed_data_gates",
    nrow(mi_diagnostics) == 3L && all(mi_diagnostics$logged_events == 0L) &&
      all(mi_diagnostics$anthropometric_identity_failures == 0L) &&
      all(mi_diagnostics$completed_range_failures == 0L) &&
      all(mi_diagnostics$completed_bmi_outside_active_range_n >= 0L) &&
      all(mi_diagnostics$completed_bmi_outside_active_range_n[
        mi_diagnostics$variant_id %in%
          c("who_block_no_later_aux", "pcornet_block_no_later_aux")
      ] == 0L) &&
      all(mi_diagnostics$observed_valid_value_changes == 0L) &&
      all(mi_diagnostics$smoking_conflicts == 0L) && all(mi_diagnostics$convergence_pass),
    paste0("variants=", nrow(mi_diagnostics), "; failures=",
           sum(mi_diagnostics$logged_events + mi_diagnostics$anthropometric_identity_failures +
                 mi_diagnostics$completed_range_failures +
                 mi_diagnostics$observed_valid_value_changes + mi_diagnostics$smoking_conflicts)),
    "3 variants; zero hard-gate failures; block-variant BMI violations=0; convergence PASS",
    "Observed valid parents are unchanged and BMI is deterministic after MI; component-only out-of-range BMI is audit-only by design."
  )
  convergence_key <- convergence_public[, c(
    "variant_id", "checkpoint_iteration", "variable", "parameter", "category_level"
  ), drop = FALSE]
  checkpoint_counts <- as.data.frame(table(
    convergence_public$variant_id, convergence_public$checkpoint_iteration
  ), stringsAsFactors = FALSE)
  checkpoint_counts <- checkpoint_counts[checkpoint_counts$Freq > 0L, , drop = FALSE]
  names(checkpoint_counts) <- c("variant_id", "checkpoint_iteration", "n")
  checkpoint_prefix_pass <- all(vapply(expected_variant_ids, function(id) {
    observed <- sort(unique(as.integer(
      convergence_public$checkpoint_iteration[convergence_public$variant_id == id]
    )))
    any(vapply(
      list(20L, c(20L, 40L), c(20L, 40L, 80L)),
      function(allowed) identical(observed, allowed), logical(1)
    ))
  }, logical(1)))
  selected_checkpoint_pass <- all(vapply(expected_variant_ids, function(id) {
    rows <- convergence_public[convergence_public$variant_id == id, , drop = FALSE]
    selected <- rows[rows$selected_checkpoint %in% TRUE, , drop = FALSE]
    nrow(selected) == 51L &&
      length(unique(selected$checkpoint_iteration)) == 1L &&
      unique(selected$checkpoint_iteration) == max(rows$checkpoint_iteration)
  }, logical(1)))
  convergence_cardinality_pass <- nrow(convergence_public) %in% seq(153L, 459L, 51L) &&
    !anyDuplicated(convergence_key) && nrow(checkpoint_counts) >= 3L &&
    all(checkpoint_counts$n == 51L) && checkpoint_prefix_pass && selected_checkpoint_pass
  checks <- add_check_v44(
    checks, "mi_convergence_key_checkpoint_cardinality", convergence_cardinality_pass,
    paste0("rows=", nrow(convergence_public), "; checkpoint cells=",
           paste(checkpoint_counts$n, collapse = "|")),
    "unique diagnostic keys; exactly 51 rows per attempted 20/40/80 checkpoint; one terminal selected checkpoint per variant",
    "The convergence table cannot pass by a loose minimum row count."
  )
  checks <- add_check_v44(
    checks, "mi_escalation_rule_audit",
    nrow(mi_escalation) == 3L &&
      all(mi_escalation$escalated ==
            (mi_escalation$initial_maximum_monte_carlo_error_fraction >
               mi_escalation$escalation_threshold)) &&
      all(mi_escalation$final_maximum_monte_carlo_error_fraction <=
            mi_escalation$escalation_threshold),
    paste0("variants=", nrow(mi_escalation), "; escalated=", sum(mi_escalation$escalated)),
    "3 executed variants; escalation iff initial MCE >0.10; all final MCE <=0.10",
    "Initial diagnostics remain aggregate and auditable even if m escalates."
  )
  checks <- add_check_v44(
    checks, "registered_result_cardinalities",
    exact_id_sets_pass && nrow(main_registry) == 12L && nrow(sensitivity_registry) == 2L &&
      nrow(nonlinear_tests) == 2L && nrow(comparison) == 14L,
    paste0("main/sensitivity/nonlinear/comparison=", paste(
      c(nrow(main_registry), nrow(sensitivity_registry), nrow(nonlinear_tests), nrow(comparison)),
      collapse = "/")),
    "12/2/2/14 with exact unique analysis-ID sets",
    "The v44.1.1 manuscript-facing estimable result set is complete and cannot pass by row count alone."
  )
  later_id <- "who_block_later_aux"
  later_absent <- !later_id %in% names(variants) &&
    !later_id %in% seed_ledger$variant_id && !440403L %in% as.integer(seed_ledger$seed) &&
    !later_id %in% source_audit$variant_id &&
    !later_id %in% mi_diagnostics$variant_id &&
    !later_id %in% mi_escalation$variant_id &&
    !later_id %in% convergence_public$variant_id &&
    !later_id %in% model_diagnostics$variant_id &&
    !later_id %in% main_registry$variant_id &&
    !later_id %in% sensitivity_registry$variant_id &&
    !any(grepl(later_id, comparison$analysis_id, fixed = TRUE)) &&
    !any(grepl(later_id, comparison$comparator_analysis_id, fixed = TRUE))
  checks <- add_check_v44(
    checks, "later_aux_absent_from_formal_analysis_outputs", later_absent,
    paste0("active=", paste(names(variants), collapse = "|"),
           "; seed440403_present=", 440403L %in% as.integer(seed_ledger$seed)),
    "later variant and seed absent from MI, model, source, effect, comparison, and diagnostics",
    "The registered failed sensitivity can appear only in the disposition registry."
  )
  later_disposition <- variant_disposition[
    variant_disposition$variant_id == later_id, , drop = FALSE
  ]
  disposition_pass <- nrow(variant_disposition) == 4L &&
    identical(as.character(variant_disposition$variant_id), c(
      "who_block_no_later_aux", "who_component_no_later_aux",
      "who_block_later_aux", "pcornet_block_no_later_aux"
    )) && identical(as.integer(variant_disposition$effect_rows_expected), c(12L, 1L, 0L, 1L)) &&
    identical(as.integer(variant_disposition$effect_rows_observed), c(12L, 1L, 0L, 1L)) &&
    nrow(later_disposition) == 1L &&
    identical(as.character(later_disposition$estimability_status), "NOT_STABLY_ESTIMABLE") &&
    identical(as.character(later_disposition$formal_execution_disposition),
              "NOT_EXECUTED_DIAGNOSTIC_INELIGIBILITY") &&
    identical(as.character(later_disposition$reason_code),
              "ACYCLIC_CORRELATION_PLAUSIBILITY_GATE_FAILED") &&
    identical(later_disposition$mortality_model_fitted, FALSE) &&
    identical(later_disposition$effect_estimate_available, FALSE) &&
    all(variant_disposition$gate_status == "PASS") &&
    all(variant_disposition$resolution_frozen_before_v44_1_0_execution %in% TRUE) &&
    !any(c(
      "estimate", "standard_error", "hazard_ratio", "hr_ci_low", "hr_ci_high", "p_value"
    ) %in% names(variant_disposition))
  checks <- add_check_v44(
    checks, "registered_variant_disposition_semantics", disposition_pass,
    paste0("rows=", nrow(variant_disposition), "; observed effects=",
           paste(variant_disposition$effect_rows_observed, collapse = "|")),
    "4 rows; effect rows 12|1|0|1; later row NOT_STABLY_ESTIMABLE with no mortality fit/effect fields",
    "A failed diagnostic sensitivity is not encoded as a null or missing association."
  )
  all_associations <- dplyr::bind_rows(main_registry, sensitivity_registry)
  checks <- add_check_v44(
    checks, "association_numerical_and_monte_carlo_gates",
    all(all_associations$gate_status == "PASS") &&
      all(is.finite(as.matrix(all_associations[c(
        "estimate", "standard_error", "ci_low", "ci_high", "p_value",
        "hazard_ratio", "hr_ci_low", "hr_ci_high"
      )]))) && all(all_associations$monte_carlo_error_fraction <= 0.10),
    paste0("rows=", nrow(all_associations), "; max MCE fraction=",
           signif(max(all_associations$monte_carlo_error_fraction), 6)),
    "14 finite PASS rows; maximum MCE fraction <=0.10",
    "Effect change is never used as a computational pass/fail gate."
  )
  association_algebra_pass <- all(all_associations$standard_error > 0) &&
    all(all_associations$ci_low <= all_associations$estimate) &&
    all(all_associations$estimate <= all_associations$ci_high) &&
    all(all_associations$p_value >= 0 & all_associations$p_value <= 1) &&
    all(all_associations$hazard_ratio > 0) &&
    max(abs(all_associations$hazard_ratio - exp(all_associations$estimate))) <= 1e-12 &&
    max(abs(all_associations$hr_ci_low - exp(all_associations$ci_low))) <= 1e-12 &&
    max(abs(all_associations$hr_ci_high - exp(all_associations$ci_high))) <= 1e-12 &&
    all(all_associations$fraction_missing_information >= -1e-10 &
          all_associations$fraction_missing_information <= 1 + 1e-10) &&
    all(all_associations$relative_efficiency > 0 &
          all_associations$relative_efficiency <= 1 + 1e-10) &&
    all(all_associations$monte_carlo_error_fraction >= 0) &&
    all(all_associations$n > 0 & all_associations$events > 0 &
          all_associations$events <= all_associations$n) &&
    all(nzchar(all_associations$formula_text))
  checks <- add_check_v44(
    checks, "association_scale_range_and_identity_gates", association_algebra_pass,
    paste0("rows=", nrow(all_associations), "; max HR identity error=",
           signif(max(abs(all_associations$hazard_ratio - exp(all_associations$estimate))), 6)),
    "SE>0; ordered CI; valid P/FMI/RE/MCE; HR and CI exponentiation identities within 1e-12",
    "Association rows are checked semantically as well as for finiteness."
  )
  nonlinear_pass <- nrow(nonlinear_tests) == 2L &&
    all(is.finite(as.matrix(nonlinear_tests[c("df_test", "statistic", "p_value", "m")]))) &&
    all(nonlinear_tests$df_test > 0 & nonlinear_tests$statistic >= 0) &&
    all(nonlinear_tests$p_value >= 0 & nonlinear_tests$p_value <= 1) &&
    all(nonlinear_tests$m > 0) && all(nonlinear_tests$gate_status == "PASS")
  checks <- add_check_v44(
    checks, "nonlinearity_numerical_gates", nonlinear_pass,
    paste0("rows=", nrow(nonlinear_tests), "; tests=",
           paste(nonlinear_tests$test_id, collapse = "|")),
    "two exact registered tests with finite nonnegative statistics and valid P values",
    "Spline evidence is numerically and semantically complete."
  )
  expected_stability_class <- ifelse(
    !comparison$direction_preserved, "material_direction_reversal",
    ifelse(comparison$relative_log_effect_change_percent <= 10, "stable",
           ifelse(comparison$relative_log_effect_change_percent <= 20,
                  "moderate", "material"))
  )
  comparison_delta <- comparison$current_log_hr - comparison$comparator_log_hr
  comparison_current_index <- match(comparison$analysis_id, all_associations$analysis_id)
  comparison_current_expected <- all_associations$estimate[comparison_current_index]
  comparison_ci_expected <-
    all_associations$ci_low[comparison_current_index] > 0 |
    all_associations$ci_high[comparison_current_index] < 0
  comparison_comparator_expected <- vapply(
    seq_len(nrow(comparison)), function(i) {
      comparator_id <- comparison$comparator_analysis_id[[i]]
      if (identical(comparator_id, primary_association$analysis_id[[1]])) {
        return(primary_association$estimate[[1]])
      }
      row <- v43_registry[v43_registry$analysis_id == comparator_id, , drop = FALSE]
      if (nrow(row) != 1L) return(NA_real_)
      as.numeric(row$estimate[[1]])
    }, numeric(1)
  )
  comparison_pass <- nrow(comparison) == 14L &&
    !anyNA(comparison_current_index) &&
    all(is.finite(as.matrix(comparison[c(
      "comparator_log_hr", "current_log_hr", "absolute_log_hr_change",
      "relative_log_effect_change_percent", "hr_ratio"
    )]))) && all(comparison$relative_log_effect_change_percent >= 0) &&
    max(abs(comparison$current_log_hr - comparison_current_expected)) <= 1e-15 &&
    max(abs(comparison$comparator_log_hr - comparison_comparator_expected)) <= 1e-15 &&
    identical(as.logical(comparison$ci_excludes_null),
              as.logical(comparison_ci_expected)) &&
    max(abs(comparison$absolute_log_hr_change - abs(comparison_delta))) <= 1e-12 &&
    max(abs(comparison$hr_ratio - exp(comparison_delta))) <= 1e-12 &&
    identical(
      as.logical(comparison$direction_preserved),
      as.logical(sign(comparison$current_log_hr) == sign(comparison$comparator_log_hr))
    ) &&
    identical(as.character(comparison$stability_class),
              as.character(expected_stability_class)) &&
    all(!is.na(comparison$direction_preserved)) &&
    all(!is.na(comparison$ci_excludes_null))
  checks <- add_check_v44(
    checks, "comparison_numerical_and_classification_gates", comparison_pass,
    paste0("rows=", nrow(comparison), "; classes=",
           paste(sort(unique(comparison$stability_class)), collapse = "|")),
    "14 finite rows with exact delta/HR-ratio identities and frozen stability classification",
    "Comparison labels are descriptive and cannot select the preferred effect."
  )
  primary_m <- mi_diagnostics$m[
    mi_diagnostics$variant_id == "who_block_no_later_aux"
  ]
  sensitivity_m <- mi_diagnostics$m[
    mi_diagnostics$variant_id != "who_block_no_later_aux"
  ]
  expected_model_diagnostic_rows <- if (
    length(primary_m) == 1L && length(sensitivity_m) == 2L
  ) {
    3L + 10L * primary_m + sum(sensitivity_m)
  } else {
    NA_integer_
  }
  checks <- add_check_v44(
    checks, "model_diagnostic_runtime_gates",
    is.finite(expected_model_diagnostic_rows) &&
      expected_model_diagnostic_rows %in% c(603L, 653L, 703L, 1103L, 1153L, 1203L) &&
      nrow(model_diagnostics) == expected_model_diagnostic_rows &&
      all(model_diagnostics$n_participants > 0L) &&
      all(model_diagnostics$n_person_period_rows >= model_diagnostics$n_participants) &&
      all(model_diagnostics$events > 0L &
            model_diagnostics$events <= model_diagnostics$n_participants) &&
      all(is.finite(model_diagnostics$nominal_person_years) &
            model_diagnostics$nominal_person_years > 0) &&
      all(model_diagnostics$time_basis ==
            "factor(end_wave) + offset(log(nominal_years))") &&
      all(model_diagnostics$prefit_time_basis_support_gate == "PASS") &&
      all(model_diagnostics$runtime_multivariable_finite_fit_gate == "PASS") &&
      all(model_diagnostics$glm_converged) &&
      all(!model_diagnostics$glm_boundary) &&
      all(model_diagnostics$matrix_columns == model_diagnostics$matrix_rank) &&
      all(is.finite(model_diagnostics$covariance_symmetry_error) &
            model_diagnostics$covariance_symmetry_error <= 1e-8) &&
      all(is.finite(model_diagnostics$covariance_minimum_eigenvalue) &
            model_diagnostics$covariance_minimum_eigenvalue > 0) &&
      all(is.finite(model_diagnostics$covariance_condition_number) &
            model_diagnostics$covariance_condition_number > 0) &&
      all(model_diagnostics$fitted_probability_min >= 0 &
            model_diagnostics$fitted_probability_max < 1) &&
      all(model_diagnostics$fitted_probability_near_one == 0L) &&
      all(is.na(model_diagnostics$warnings) | model_diagnostics$warnings == ""),
    paste0("rows=", nrow(model_diagnostics), "; warnings=",
           sum(!is.na(model_diagnostics$warnings) & nzchar(model_diagnostics$warnings))),
    paste0("exact dynamic row count=", expected_model_diagnostic_rows,
           "; all converged/full-rank/nonboundary; zero warnings"),
    "Every imputation-specific survey model passed the inherited v43 hard gates."
  )
  exact25_after <- validate_exact25_v44(
    file.path(root, spec$inputs$stage3_authorization_registry),
    spec$inputs$stage3_authorization_registry_sha256
  )
  completion_inputs_after <- validate_completion_inputs_v44(root, spec)
  later_evidence_after <- validate_later_resolution_evidence_v44_1(root, spec)
  authorization_after <- validate_v44_authorization(root, authorization_path)
  predecessor_after <- bootstrap_validate_predecessor_v44_1_0(root)
  contract_preflight_after <- bootstrap_validate_contract_schema_v44_1_1(root)
  checks <- add_check_v44(
    checks, "stage3_exact25_current_after_execution", exact25_after$pass,
    exact25_after$detail, "25/25 current", "Outcome execution did not mutate v43."
  )
  checks <- add_check_v44(
    checks, "completion_bound_inputs_current_before_and_after",
    completion_inputs_before$pass && completion_inputs_after$pass,
    paste(completion_inputs_before$detail, completion_inputs_after$detail, sep = "; "),
    "3/3 opened completion-bound inputs current before and after",
    "The analysis ledger, CHARLS registry, and spline knots are bound to the frozen completion manifest."
  )
  checks <- add_check_v44(
    checks, "later_aux_resolution_evidence_current_after_execution",
    later_evidence_before$pass && later_evidence_after$pass,
    paste(later_evidence_before$detail, later_evidence_after$detail, sep = "; "),
    "same frozen non-estimability evidence current before and after",
    "Formal outcome execution did not mutate the diagnostic evidence."
  )
  checks <- add_check_v44(
    checks, "v44_1_1_authorization_current_after_execution",
    authorization_after$pass && predecessor_after$pass && contract_preflight_after$pass,
    paste(
      authorization_after$detail, predecessor_after$detail,
      contract_preflight_after$detail, sep = "; "
    ),
    "29/29 v44.1.1 assets current; predecessor 27/27 current; exact schema preflight current",
    "Formal execution did not mutate current or predecessor governance, code, inputs, or schemas."
  )
  if (any(checks$status != "PASS")) {
    print(checks[checks$status != "PASS", ], row.names = FALSE)
    stop("v44.1.1 hard validation failed before publication.", call. = FALSE)
  }

  output_objects <- list(
    "results/v44_1_1/charls_anthropometric_qc_source_audit_v44_1_1.csv" = source_audit,
    "results/v44_1_1/stage3_charls_primary_association_registry_v44_1_1.csv" = main_registry,
    "results/v44_1_1/stage3_charls_anthropometric_sensitivity_registry_v44_1_1.csv" = sensitivity_registry,
    "results/v44_1_1/stage3_charls_nonlinearity_tests_v44_1_1.csv" = nonlinear_tests,
    "results/v44_1_1/charls_anthropometric_qc_comparison_v44_1_1.csv" = comparison,
    "results/v44_1_1/charls_anthropometric_qc_variant_disposition_v44_1_1.csv" =
      variant_disposition,
    "results/v44_1_1/charls_anthropometric_qc_mi_convergence_v44_1_1.csv" =
      convergence_public,
    "results/v44_1_1/charls_anthropometric_qc_mi_diagnostics_v44_1_1.csv" = mi_diagnostics,
    "results/v44_1_1/charls_anthropometric_qc_mi_escalation_v44_1_1.csv" = mi_escalation,
    "results/v44_1_1/charls_anthropometric_qc_model_diagnostics_v44_1_1.csv" =
      model_diagnostics,
    "results/v44_1_1/charls_anthropometric_qc_validation_v44_1_1.csv" = checks
  )
  expected_contract_paths <- c(
    names(output_objects),
    "results/v44_1_1/charls_anthropometric_qc_manifest_v44_1_1.csv",
    "output/qa/v44_1_1/CHARLS_ANTHROPOMETRIC_QC_RESOLUTION_QA_v44_1_1.md"
  )
  if (!identical(contract_paths, expected_contract_paths)) {
    stop("v44.1.1 contract output path order or identity drifted.", call. = FALSE)
  }
  for (entry in contract$outputs) {
    path <- as.character(entry$path)
    if (!grepl("\\.csv$", path) || grepl("manifest", path)) next
    if (!path %in% names(output_objects)) stop("Contracted v44.1.1 output missing: ", path, call. = FALSE)
    dat <- output_objects[[path]]
    if (!is.character(entry$required_columns) ||
        !length(entry$required_columns) || anyNA(entry$required_columns) ||
        any(!nzchar(entry$required_columns))) {
      stop("v44.1.1 runtime output contract contains a non-character column identifier: ",
           path, call. = FALSE)
    }
    required <- unlist(entry$required_columns, use.names = FALSE)
    if (!identical(names(dat), required)) {
      stop("v44.1.1 output schema mismatch for ", path, ": ",
           paste0("expected=", paste(required, collapse = "|"),
                  "; observed=", paste(names(dat), collapse = "|")),
           call. = FALSE)
    }
    rows <- entry$rows
    if (is.numeric(rows) && nrow(dat) != as.integer(rows)) {
      stop("v44.1.1 output row mismatch for ", path, call. = FALSE)
    }
    if (is.character(rows) && grepl("^>=", rows) &&
        nrow(dat) < as.integer(sub("^>=", "", rows))) {
      stop("v44.1.1 output minimum row mismatch for ", path, call. = FALSE)
    }
  }

  primary <- main_registry[main_registry$analysis_id == "v44_s3_charls_pc_e0_a1", ]
  primary_comparison <- comparison[comparison$analysis_id == "v44_s3_charls_pc_e0_a1", ]
  qa_lines <- c(
    "# CHARLS v44.1.1 anthropometric-QC formal resolution",
    "",
    paste0("Generated: ", format(Sys.time(), tz = "Asia/Shanghai", usetz = TRUE)),
    paste0("Run ID: ", run_id),
    paste0("Authorization registry SHA-256: ", authorization_before$registry_sha256),
    "",
    "## Decision",
    "",
    "The additive WHO-block rerun completed without changing the frozen population, E0/E0b, outcome skeleton, survey design, spline knots, or model formulas. WHO limits are operational data-entry bounds, not biological normal ranges.",
    "",
    paste0(
      "Primary A1/E0: HR ", signif(primary$hazard_ratio, 5), " (95% CI ",
      signif(primary$hr_ci_low, 5), "-", signif(primary$hr_ci_high, 5),
      "); relative log-effect change versus v43 = ",
      signif(primary_comparison$relative_log_effect_change_percent, 4), "% (",
      primary_comparison$stability_class, ")."
    ),
    "",
    "## Source-QC audit",
    "",
    markdown_table_v44(source_audit),
    "",
    "## Registered primary and sensitivity associations",
    "",
    markdown_table_v44(dplyr::bind_rows(main_registry, sensitivity_registry)[, c(
      "analysis_id", "variant_id", "model_tier", "n", "events", "m",
      "hazard_ratio", "hr_ci_low", "hr_ci_high", "p_value",
      "monte_carlo_error_fraction"
    )]),
    "",
    "## Registered variant disposition",
    "",
    markdown_table_v44(variant_disposition),
    "",
    "The later-wave auxiliary sensitivity was not executed in v44.1.1 and has no HR, confidence interval, or P value. Its sole permitted acyclic diagnostic approximation failed the frozen repeated-weight correlation-plausibility gate.",
    "",
    "## v43-v44 and within-v44 stability",
    "",
    markdown_table_v44(comparison),
    "",
    "## MI diagnostics",
    "",
    markdown_table_v44(mi_diagnostics),
    "",
    "## Hard validation",
    "",
    markdown_table_v44(checks),
    "",
    "No participant-level record, completed dataset, imputation object, model coefficient vector, local absolute path, or identifier is published."
  )
  qa_text_gate <- paste(qa_lines, collapse = "\n")
  if (!all(vapply(c(
    "NOT_STABLY_ESTIMABLE",
    "ACYCLIC_CORRELATION_PLAUSIBILITY_GATE_FAILED",
    "has no HR, confidence interval, or P value"
  ), function(required) grepl(required, qa_text_gate, fixed = TRUE), logical(1)))) {
    stop("v44.1.1 QA omits the frozen later-aux disposition semantics.", call. = FALSE)
  }

  staging_parent <- file.path(root, "derived_sensitive/v44_1_1/.publication_staging")
  dir.create(staging_parent, recursive = TRUE, showWarnings = FALSE)
  staging <- tempfile("charls_qc_", tmpdir = staging_parent)
  dir.create(staging, recursive = TRUE)
  on.exit(if (dir.exists(staging)) unlink(staging, recursive = TRUE, force = TRUE), add = TRUE)
  for (path in names(output_objects)) {
    atomic_write_csv_v44(output_objects[[path]], file.path(staging, path))
  }
  qa_rel <- "output/qa/v44_1_1/CHARLS_ANTHROPOMETRIC_QC_RESOLUTION_QA_v44_1_1.md"
  atomic_write_lines_v44(qa_lines, file.path(staging, qa_rel))

  manifest_sources <- stats::setNames(
    as.character(authorization_before$registry$path),
    as.character(authorization_before$registry$asset)
  )
  manifest_sources <- c(
    manifest_sources,
    resolution_authorization_registry =
      "work_v44/charls_anthropometric_qc_resolution_authorization_hashes_v44_1_1.csv"
  )
  manifest <- data.frame(
    asset = names(manifest_sources), path = unname(manifest_sources),
    exists = TRUE,
    bytes = vapply(file.path(root, unname(manifest_sources)), function(p) file.info(p)$size, numeric(1)),
    sha256 = vapply(file.path(root, unname(manifest_sources)), sha256_file, character(1)),
    finalized_at = format(Sys.time(), tz = "Asia/Shanghai", usetz = TRUE),
    stringsAsFactors = FALSE
  )
  staged_rel <- c(names(output_objects), qa_rel)
  staged_manifest <- data.frame(
    asset = sub("\\.[^.]+$", "", basename(staged_rel)), path = staged_rel,
    exists = TRUE,
    bytes = vapply(file.path(staging, staged_rel), function(p) file.info(p)$size, numeric(1)),
    sha256 = vapply(file.path(staging, staged_rel), sha256_file, character(1)),
    finalized_at = format(Sys.time(), tz = "Asia/Shanghai", usetz = TRUE),
    stringsAsFactors = FALSE
  )
  rng_kind <- paste(RNGkind(), collapse = "|")
  package_versions <- paste(
    paste0(
      c("mice", "survey", "dplyr", "yaml", "digest"), "=",
      vapply(c("mice", "survey", "dplyr", "yaml", "digest"),
             function(pkg) as.character(utils::packageVersion(pkg)), character(1))
    ),
    collapse = ";"
  )
  add_manifest_context <- function(x) {
    x$run_id <- run_id
    x$authorization_id <- gate$authorization_id
    x$authorization_registry_sha256 <- authorization_before$registry_sha256
    x$rng_kind <- rng_kind
    x$r_version <- R.version.string
    x$package_versions <- package_versions
    x
  }
  manifest <- add_manifest_context(manifest)
  staged_manifest <- add_manifest_context(staged_manifest)
  manifest <- rbind(manifest, staged_manifest)
  manifest_required <- unlist(
    contract$outputs[[12L]]$required_columns, use.names = FALSE
  )
  if (!identical(names(manifest), manifest_required) ||
      nrow(manifest) != 42L || anyDuplicated(manifest$asset) ||
      anyDuplicated(manifest$path)) {
    stop("v44.1.1 manifest schema/cardinality/key gate failed (expected exact schema and 42 rows).",
         call. = FALSE)
  }
  manifest_rel <- "results/v44_1_1/charls_anthropometric_qc_manifest_v44_1_1.csv"
  atomic_write_csv_v44(manifest, file.path(staging, manifest_rel))

  public_paths <- c(staged_rel, manifest_rel)
  public_text <- paste(vapply(file.path(staging, public_paths), function(p) {
    paste(readLines(p, warn = FALSE), collapse = "\n")
  }, character(1)), collapse = "\n")
  if (grepl("/Users/", public_text, fixed = TRUE) ||
      grepl("LOCAL_USER", public_text, fixed = TRUE)) {
    stop("Public v44.1.1 bundle contains a local absolute path.", call. = FALSE)
  }

  final_rel <- c(public_paths)
  existing <- file.exists(file.path(root, final_rel))
  if (any(existing)) {
    stop("Refusing to replace an existing v44.1.1 bundle; create a new governed version.",
         call. = FALSE)
  }
  backup <- tempfile("charls_qc_backup_", tmpdir = staging_parent)
  dir.create(backup, recursive = TRUE)
  promoted_rel <- character()
  promotion_committed <- FALSE
  on.exit({
    restore_ok <- TRUE
    if (!promotion_committed) {
      for (rel in promoted_rel) {
        final <- file.path(root, rel)
        if (file.exists(final)) unlink(final, force = TRUE)
      }
      for (rel in final_rel) {
        saved <- file.path(backup, rel)
        final <- file.path(root, rel)
        if (file.exists(saved)) {
          dir.create(dirname(final), recursive = TRUE, showWarnings = FALSE)
          restore_ok <- isTRUE(file.rename(saved, final)) && restore_ok
        }
      }
    }
    if (dir.exists(backup) && (promotion_committed || restore_ok)) {
      unlink(backup, recursive = TRUE, force = TRUE)
    } else if (dir.exists(backup)) {
      warning("Rollback restoration was incomplete; backup preserved at ", backup)
    }
  }, add = TRUE)
  for (rel in final_rel[existing]) {
    final <- file.path(root, rel)
    saved <- file.path(backup, rel)
    dir.create(dirname(saved), recursive = TRUE, showWarnings = FALSE)
    if (!file.rename(final, saved)) {
      stop("Could not stage the prior v44.1.1 output for rollback: ", rel, call. = FALSE)
    }
  }
  for (rel in final_rel) {
    final <- file.path(root, rel)
    dir.create(dirname(final), recursive = TRUE, showWarnings = FALSE)
    if (!file.rename(file.path(staging, rel), final)) {
      stop("Could not promote staged v44.1.1 output: ", rel, call. = FALSE)
    }
    promoted_rel <- c(promoted_rel, rel)
  }
  promotion_committed <- TRUE
  unlink(backup, recursive = TRUE, force = TRUE)
  unlink(staging, recursive = TRUE, force = TRUE)
  cat(
    "CHARLS v44.1.1 anthropometric-QC formal resolution PASS\n",
    "Primary A1 HR=", signif(primary$hazard_ratio, 7),
    " (", signif(primary$hr_ci_low, 7), "-", signif(primary$hr_ci_high, 7), ")\n",
    "v43 relative log-effect change=", signif(primary_comparison$relative_log_effect_change_percent, 6), "%\n",
    "Stage 3 exact-25 current=25/25\n", sep = ""
  )
}

if (sys.nframe() == 0L) main_v44_1()
