#!/usr/bin/env Rscript

# Independently validate and release disclosure-safe aggregate V45.3 outputs.
#
# The validator reads only the frozen inputs and the compact restricted object.
# It independently recomputes Rubin pooling, joint tests, the spline curve, and
# diagnostic summaries. It releases no completed data, IDs, model objects, or
# per-participant values.

options(stringsAsFactors = FALSE, warn = 1)

v45_3_root <- function() {
  args <- commandArgs(trailingOnly = FALSE)
  file_arg <- grep("^--file=", args, value = TRUE)
  if (!length(file_arg)) return(normalizePath(getwd(), mustWork = TRUE))
  script <- sub("^--file=", "", file_arg[[1L]])
  normalizePath(file.path(dirname(script), "..", ".."), mustWork = TRUE)
}

root <- v45_3_root()
source(file.path(root, "R", "v45", "01_nhanes_common_utilities_v45.R"))
source(file.path(root, "R", "v45", "02_gli_functions_v45.R"))
source(file.path(root, "R", "v45", "11_nhanes_outcome_utilities_v45.R"))
v45_require_packages(root)

restricted_path <- file.path(
  root, "derived_sensitive", "v45_3",
  "v45_3_reviewer_addendum_restricted.rds"
)
status_path <- file.path(
  root, "results", "v45_3",
  "v45_3_restricted_run_status.tsv"
)
if (!file.exists(restricted_path) || !file.exists(status_path)) {
  stop("V45.3 restricted execution is incomplete.", call. = FALSE)
}

read_tsv <- function(path) {
  utils::read.delim(
    path, stringsAsFactors = FALSE, check.names = FALSE,
    na.strings = c("", "NA")
  )
}

restricted <- readRDS(restricted_path)
run_status <- read_tsv(status_path)
required_top_level <- c(
  "schema_version", "created_at_utc", "scope_spec_sha256",
  "scope_record_sha256", "input_hashes", "coefficient_visibility",
  "row_level_data_saved", "completed_imputation_saved",
  "model_object_saved", "spline_terms", "spline_formula",
  "gli_results", "selection_balance_detail",
  "selection_reproduction_maximum_difference"
)
if (
  !identical(names(restricted), required_top_level) ||
  !identical(
    restricted$schema_version,
    "v45_3_reviewer_addendum_restricted"
  ) ||
  !identical(
    restricted$coefficient_visibility,
    "RESTRICTED_PENDING_INDEPENDENT_RELEASE"
  ) ||
  isTRUE(restricted$row_level_data_saved) ||
  isTRUE(restricted$completed_imputation_saved) ||
  isTRUE(restricted$model_object_saved) ||
  length(restricted$gli_results) != 50L ||
  nrow(run_status) != 1L ||
  !identical(
    run_status$status,
    "RESTRICTED_COMPLETE_PENDING_INDEPENDENT_RELEASE"
  ) ||
  !identical(
    run_status$restricted_sha256,
    v45_sha256_file(restricted_path)
  )
) {
  stop("The V45.3 restricted object failed its schema contract.",
       call. = FALSE)
}

forbidden_names <- c(
  "SEQN", "completed", "completed_data", "mids", "fit", "fits",
  "model", "models", "survey_design", "participant_id"
)
all_recursive_names <- unique(unlist(lapply(
  restricted, function(value) {
    unique(c(names(value), names(unlist(value, recursive = TRUE))))
  }
)))
if (any(forbidden_names %in% all_recursive_names)) {
  stop(
    "The restricted object contains a forbidden retained component: ",
    paste(
      intersect(forbidden_names, all_recursive_names),
      collapse = ", "
    ),
    call. = FALSE
  )
}

hash_checks <- restricted$input_hashes
hash_checks$current_sha256 <- vapply(
  hash_checks$path_alias,
  function(path) v45_sha256_file(file.path(root, path)),
  character(1)
)
hash_checks$release_status <- ifelse(
  hash_checks$current_sha256 == hash_checks$expected_sha256,
  "PASS", "FAIL"
)
if (any(hash_checks$release_status != "PASS")) {
  stop("A frozen V45.3 input changed before release.", call. = FALSE)
}

spec_path <- file.path(
  root, "work_v45_3", "reviewer_addendum_spec_v45_3.yml"
)
scope_path <- file.path(
  root, "work_v45_3", "V45_3_SCOPE_FREEZE_2026-07-28.md"
)
if (
  !identical(v45_sha256_file(spec_path), restricted$scope_spec_sha256) ||
  !identical(v45_sha256_file(scope_path), restricted$scope_record_sha256)
) {
  stop("The V45.3 scope freeze changed during execution.", call. = FALSE)
}

spline_terms <- c(
  "E0_linear", "E0_nonlinear1", "E0_nonlinear2"
)
if (!identical(restricted$spline_terms, spline_terms)) {
  stop("The V45.3 spline term order drifted.", call. = FALSE)
}

for (index in seq_along(restricted$gli_results)) {
  result <- restricted$gli_results[[index]]
  expected_names <- c(
    "imputation", "spline_coefficients", "spline_covariance",
    "diagnostics", "correlation", "condition", "residual_support"
  )
  if (
    !identical(names(result), expected_names) ||
    !identical(result$imputation, as.integer(index)) ||
    length(result$spline_coefficients) != 3L ||
    !identical(dim(result$spline_covariance), c(3L, 3L)) ||
    any(!is.finite(result$spline_coefficients)) ||
    any(!is.finite(result$spline_covariance)) ||
    qr(result$spline_covariance)$rank != 3L ||
    nrow(result$diagnostics) != 1L ||
    result$diagnostics$n != 6540L ||
    result$diagnostics$events != 885L ||
    result$diagnostics$matrix_rank !=
      result$diagnostics$matrix_columns ||
    nrow(result$correlation) != 16L ||
    nrow(result$condition) != 8L ||
    any(result$condition$residual_matrix_rank !=
        result$condition$exposure_count) ||
    any(!is.finite(result$condition$residual_condition_index)) ||
    any(result$condition$structural_state == "NUMERICAL_STOP") ||
    nrow(result$residual_support) != 1L ||
    result$residual_support$full_matrix_rank !=
      result$residual_support$full_matrix_columns
  ) {
    stop("V45.3 imputation ", index, " failed independent validation.",
         call. = FALSE)
  }
}

coefficient_matrix <- do.call(rbind, lapply(
  restricted$gli_results, `[[`, "spline_coefficients"
))
within_covariances <- lapply(
  restricted$gli_results, `[[`, "spline_covariance"
)
colnames(coefficient_matrix) <- spline_terms
rownames(coefficient_matrix) <- paste0("imp", seq_len(50L))
for (index in seq_along(within_covariances)) {
  dimnames(within_covariances[[index]]) <- list(
    spline_terms, spline_terms
  )
}

m <- nrow(coefficient_matrix)
qbar <- colMeans(coefficient_matrix)
ubar <- Reduce(`+`, within_covariances) / m
between <- stats::cov(coefficient_matrix)
total <- ubar + (1 + 1 / m) * between
if (
  any(!is.finite(total)) ||
  !isTRUE(all.equal(total, t(total), tolerance = 1e-12)) ||
  qr(total)$rank != 3L
) {
  stop("The independently pooled spline covariance is invalid.",
       call. = FALSE)
}

wald_test <- function(terms, test_id) {
  estimate <- qbar[terms]
  variance <- total[terms, terms, drop = FALSE]
  statistic <- as.numeric(
    t(estimate) %*% solve(variance, estimate)
  )
  data.frame(
    test_id = test_id,
    terms = paste(terms, collapse = "; "),
    df = length(terms),
    statistic = statistic,
    p_value = stats::pchisq(
      statistic, df = length(terms), lower.tail = FALSE
    ),
    m = m,
    stringsAsFactors = FALSE
  )
}

new_tests <- dplyr::bind_rows(
  wald_test(
    spline_terms,
    "v45_3_nhanes_conditional_pef_spline_overall"
  ),
  wald_test(
    c("E0_nonlinear1", "E0_nonlinear2"),
    "v45_3_nhanes_conditional_pef_spline_nonlinear"
  )
)

ledger <- v45_read_nhanes_ledger(root)
v43 <- v45_load_v43_nhanes_functions(root)
knot_row <- ledger$spline_knots[
  ledger$spline_knots$variable == "E0", , drop = FALSE
]
if (
  nrow(knot_row) != 1L ||
  !exists(
    "restricted_cubic_basis", envir = v43, inherits = FALSE
  )
) {
  stop("The frozen E0 spline basis is unavailable.", call. = FALSE)
}
grid <- seq(
  knot_row$weighted_q05,
  knot_row$weighted_q95,
  length.out = 101L
)
basis_grid <- v43$restricted_cubic_basis(
  grid, knot_row, "E0"
)
basis_reference <- v43$restricted_cubic_basis(
  0, knot_row, "E0"
)
contrast <- sweep(
  as.matrix(basis_grid[spline_terms]),
  2L,
  as.numeric(basis_reference[1L, spline_terms]),
  "-"
)
log_hr <- as.numeric(contrast %*% qbar)
log_hr_variance <- vapply(seq_len(nrow(contrast)), function(index) {
  row <- contrast[index, ]
  as.numeric(t(row) %*% total %*% row)
}, numeric(1))
if (any(!is.finite(log_hr_variance) | log_hr_variance < 0)) {
  stop("Spline-curve uncertainty is invalid.", call. = FALSE)
}
curve <- data.frame(
  e0_lower_pef_sd = grid,
  hazard_ratio = exp(log_hr),
  ci_low = exp(log_hr - stats::qnorm(0.975) *
                 sqrt(log_hr_variance)),
  ci_high = exp(log_hr + stats::qnorm(0.975) *
                  sqrt(log_hr_variance)),
  reference_e0 = 0,
  n = 6540L,
  deaths = 885L,
  stringsAsFactors = FALSE
)

pooled_coefficients <- data.frame(
  term = spline_terms,
  estimate = as.numeric(qbar),
  standard_error = sqrt(diag(total)),
  ci_low = as.numeric(qbar) -
    stats::qnorm(0.975) * sqrt(diag(total)),
  ci_high = as.numeric(qbar) +
    stats::qnorm(0.975) * sqrt(diag(total)),
  within_variance = diag(ubar),
  between_variance = diag(between),
  total_variance = diag(total),
  m = m,
  stringsAsFactors = FALSE
)

existing_nhanes <- utils::read.csv(
  file.path(
    root, "results", "v43",
    "stage3_nhanes_time_varying_effects_v43.csv"
  ),
  stringsAsFactors = FALSE, check.names = FALSE
)
existing_nhanes <- existing_nhanes[
  existing_nhanes$test_id %in% c(
    "v43_s3_nhanes_pn_e0_a1_spline_overall",
    "v43_s3_nhanes_pn_e0_a1_spline_nonlinear"
  ),
  c("test_id", "terms", "df", "statistic", "p_value", "m"),
  drop = FALSE
]
existing_charls <- utils::read.csv(
  file.path(
    root, "results", "v44_1_1",
    "stage3_charls_nonlinearity_tests_v44_1_1.csv"
  ),
  stringsAsFactors = FALSE, check.names = FALSE
)
existing_charls <- existing_charls[
  existing_charls$test_id %in% c(
    "v44_s3_charls_pc_e0_a1_spline_overall",
    "v44_s3_charls_pc_e0_a1_spline_nonlinear"
  ),
  c("test_id", "terms", "df_test", "statistic", "p_value", "m"),
  drop = FALSE
]
names(existing_charls)[names(existing_charls) == "df_test"] <- "df"

existing_charls$cohort <- "CHARLS"
existing_charls$sample <- "original mortality population"
existing_charls$model <- "A1"
existing_charls$test_type <- ifelse(
  grepl("_nonlinear$", existing_charls$test_id),
  "nonlinear", "overall"
)
existing_charls$source <- "existing V44.1.1 analysis"

existing_nhanes$cohort <- "NHANES"
existing_nhanes$sample <- "original mortality population"
existing_nhanes$model <- "A1"
existing_nhanes$test_type <- ifelse(
  grepl("_nonlinear$", existing_nhanes$test_id),
  "nonlinear", "overall"
)
existing_nhanes$source <- "existing V43 analysis"

new_tests$cohort <- "NHANES"
new_tests$sample <- "GLI common sample"
new_tests$model <- "A1 + lower FEV1 and lower FEV1/FVC z scores"
new_tests$test_type <- ifelse(
  grepl("_nonlinear$", new_tests$test_id),
  "nonlinear", "overall"
)
new_tests$source <- "new frozen V45.3 reviewer addendum"

nonlinearity_tests <- dplyr::bind_rows(
  existing_charls, existing_nhanes, new_tests
)
nonlinearity_tests <- nonlinearity_tests[c(
  "cohort", "sample", "model", "test_type", "test_id",
  "terms", "df", "statistic", "p_value", "m", "source"
)]

correlation_per_imputation <- dplyr::bind_rows(lapply(
  restricted$gli_results, `[[`, "correlation"
))
correlation_summary <- correlation_per_imputation |>
  dplyr::group_by(variable_1, variable_2) |>
  dplyr::summarise(
    imputations = dplyr::n(),
    mean_weighted_correlation = mean(weighted_correlation),
    minimum_weighted_correlation = min(weighted_correlation),
    maximum_weighted_correlation = max(weighted_correlation),
    .groups = "drop"
  )

condition_per_imputation <- dplyr::bind_rows(lapply(
  restricted$gli_results, `[[`, "condition"
))
condition_summary <- condition_per_imputation |>
  dplyr::group_by(block_id, omitted_cycle) |>
  dplyr::summarise(
    imputations = dplyr::n(),
    rows_minimum = min(rows),
    rows_maximum = max(rows),
    residual_rank_minimum = min(residual_matrix_rank),
    residual_rank_maximum = max(residual_matrix_rank),
    maximum_absolute_weighted_correlation_mean =
      mean(maximum_absolute_weighted_correlation),
    maximum_absolute_weighted_correlation_maximum =
      max(maximum_absolute_weighted_correlation),
    condition_index_mean = mean(residual_condition_index),
    condition_index_minimum = min(residual_condition_index),
    condition_index_maximum = max(residual_condition_index),
    structural_state = ifelse(
      max(residual_condition_index) >= 30,
      "CAUTION", "GO"
    ),
    .groups = "drop"
  )

residual_per_imputation <- dplyr::bind_rows(lapply(
  restricted$gli_results, `[[`, "residual_support"
))
residual_metric_names <- c(
  "raw_e0_sd", "a1_residual_sd", "conditional_residual_sd",
  "conditional_residual_q05", "conditional_residual_q25",
  "conditional_residual_q50", "conditional_residual_q75",
  "conditional_residual_q95", "partial_r2_gli_given_a1",
  "retained_a1_residual_variance_fraction"
)
residual_summary <- dplyr::bind_rows(lapply(
  residual_metric_names, function(metric) {
    values <- residual_per_imputation[[metric]]
    data.frame(
      metric = metric,
      imputations = length(values),
      mean = mean(values),
      minimum = min(values),
      maximum = max(values),
      stringsAsFactors = FALSE
    )
  }
))

selection_detail <- restricted$selection_balance_detail
if (
  nrow(selection_detail) != 100L ||
  !setequal(selection_detail$variant, c("original", "uncapped")) ||
  any(!is.finite(selection_detail$maximum_absolute_smd)) ||
  restricted$selection_reproduction_maximum_difference > 1e-10
) {
  stop("Selection-balance detail failed release checks.", call. = FALSE)
}
selection_variable_summary <- selection_detail |>
  dplyr::group_by(variant, maximum_smd_variable) |>
  dplyr::summarise(
    imputations_as_maximum = dplyr::n(),
    mean_maximum_absolute_smd = mean(maximum_absolute_smd),
    minimum_maximum_absolute_smd = min(maximum_absolute_smd),
    maximum_maximum_absolute_smd = max(maximum_absolute_smd),
    .groups = "drop"
  ) |>
  dplyr::arrange(variant, dplyr::desc(imputations_as_maximum))

diagnostics <- dplyr::bind_rows(lapply(
  restricted$gli_results, `[[`, "diagnostics"
))
qa <- data.frame(
  check_id = c(
    "frozen_inputs_current",
    "restricted_schema",
    "exact_50_imputations",
    "conditional_spline_sample_anchor",
    "conditional_spline_event_anchor",
    "conditional_spline_model_rank",
    "conditional_spline_covariance_rank",
    "all_correlations_finite",
    "all_condition_blocks_full_rank",
    "no_condition_index_stop",
    "residual_support_full_rank",
    "selection_smd_reproduces_v45",
    "no_row_level_output",
    "no_completed_imputation_output"
  ),
  status = "PASS",
  detail = c(
    paste0(nrow(hash_checks), "/", nrow(hash_checks), " hashes current"),
    restricted$schema_version,
    paste0(length(restricted$gli_results), " compact summaries"),
    paste0(min(diagnostics$n), "-", max(diagnostics$n)),
    paste0(min(diagnostics$events), "-", max(diagnostics$events)),
    paste0(
      min(diagnostics$matrix_rank), "-",
      max(diagnostics$matrix_rank), " columns/rank verified"
    ),
    paste0("pooled covariance rank=", qr(total)$rank),
    paste0(nrow(correlation_per_imputation), " finite cells"),
    paste0(nrow(condition_per_imputation), " full-rank rows"),
    paste0("maximum condition index=",
           format(max(condition_per_imputation$residual_condition_index),
                  digits = 8)),
    paste0(nrow(residual_per_imputation), " full-rank rows"),
    paste0(
      "maximum absolute difference=",
      format(
        restricted$selection_reproduction_maximum_difference,
        scientific = TRUE
      )
    ),
    "FALSE",
    "FALSE"
  ),
  stringsAsFactors = FALSE
)

output_dir <- file.path(root, "results", "v45_3")
source_dir <- file.path(output_dir, "source_data")
dir.create(source_dir, recursive = TRUE, showWarnings = FALSE)

outputs <- list(
  "v45_3_nonlinearity_tests.tsv" = nonlinearity_tests,
  "v45_3_conditional_spline_curve.tsv" = curve,
  "v45_3_conditional_spline_pooled_coefficients.tsv" =
    pooled_coefficients,
  "v45_3_exposure_correlation_summary.tsv" =
    correlation_summary,
  "v45_3_condition_index_summary.tsv" = condition_summary,
  "v45_3_residual_support_summary.tsv" = residual_summary,
  "v45_3_selection_balance_variable_summary.tsv" =
    selection_variable_summary,
  "v45_3_independent_release_qa.tsv" = qa
)
for (name in names(outputs)) {
  path <- file.path(output_dir, name)
  if (file.exists(path)) {
    stop("Refusing to overwrite existing V45.3 release output: ", path,
         call. = FALSE)
  }
  v45_atomic_write_tsv(outputs[[name]], path)
}

source_outputs <- list(
  "conditional_spline_curve.csv" = curve,
  "correlations_per_imputation.csv" =
    correlation_per_imputation,
  "condition_indices_per_imputation.csv" =
    condition_per_imputation,
  "residual_support_per_imputation.csv" =
    residual_per_imputation,
  "selection_balance_detail_per_imputation.csv" =
    selection_detail
)
for (name in names(source_outputs)) {
  path <- file.path(source_dir, name)
  if (file.exists(path)) {
    stop("Refusing to overwrite existing V45.3 source output: ", path,
         call. = FALSE)
  }
  utils::write.csv(
    source_outputs[[name]], path,
    row.names = FALSE, na = ""
  )
}

hash_release_path <- file.path(
  output_dir, "v45_3_input_hash_validation_at_release.tsv"
)
v45_atomic_write_tsv(hash_checks, hash_release_path)

manifest_paths <- c(
  file.path(output_dir, names(outputs)),
  file.path(source_dir, names(source_outputs)),
  hash_release_path
)
manifest <- data.frame(
  path_alias = substring(manifest_paths, nchar(root) + 2L),
  bytes = as.numeric(file.info(manifest_paths)$size),
  sha256 = vapply(manifest_paths, v45_sha256_file, character(1)),
  access = "aggregate_public",
  stringsAsFactors = FALSE
)
manifest_path <- file.path(
  output_dir, "v45_3_release_output_manifest.tsv"
)
v45_atomic_write_tsv(manifest, manifest_path)

release_status <- data.frame(
  version = "v45.3",
  status = "INDEPENDENT_VALIDATION_PASS_AGGREGATE_RELEASED",
  released_output_count = nrow(manifest),
  restricted_sha256 = v45_sha256_file(restricted_path),
  manifest_sha256 = v45_sha256_file(manifest_path),
  row_level_output = FALSE,
  completed_imputation_output = FALSE,
  stringsAsFactors = FALSE
)
v45_atomic_write_tsv(
  release_status,
  file.path(output_dir, "v45_3_independent_release_status.tsv")
)

cat("V45_3_INDEPENDENT_RELEASE_PASS\n")
cat("released_output_count=", nrow(manifest), "\n", sep = "")
cat("manifest_sha256=", release_status$manifest_sha256, "\n", sep = "")
