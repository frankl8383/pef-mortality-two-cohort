#!/usr/bin/env Rscript

# Run the frozen V45.3 reviewer addendum.
#
# This script fits one new coefficient-bearing model: the prespecified
# restricted-cubic-spline version of the focal NHANES MI-G conditional model.
# All completed data remain in memory. Compact per-imputation coefficients and
# covariance matrices are written only to derived_sensitive/ for independent
# release. Public output from this script is limited to hashes and run status.

options(stringsAsFactors = FALSE, warn = 1)

v45_3_root <- function() {
  args <- commandArgs(trailingOnly = FALSE)
  file_arg <- grep("^--file=", args, value = TRUE)
  if (!length(file_arg)) return(normalizePath(getwd(), mustWork = TRUE))
  script <- sub("^--file=", "", file_arg[[1L]])
  normalizePath(file.path(dirname(script), "..", ".."), mustWork = TRUE)
}

root <- v45_3_root()
source(file.path(root, "R", "v45", "01_nhanes_common_utilities_v45.R"))
source(file.path(root, "R", "v45", "02_gli_functions_v45.R"))
source(file.path(root, "R", "v45", "11_nhanes_outcome_utilities_v45.R"))
v45_require_packages(root)

options(
  survey.lonely.psu = "adjust",
  survey.adjust.domain.lonely = TRUE,
  survey.replicates.mse = TRUE,
  survey.multicore = FALSE
)

args <- commandArgs(trailingOnly = TRUE)
arg_value <- function(prefix, default = NULL) {
  hit <- grep(paste0("^", prefix, "="), args, value = TRUE)
  if (!length(hit)) return(default)
  sub(paste0("^", prefix, "="), "", tail(hit, 1L))
}
workers <- suppressWarnings(as.integer(arg_value("--workers", "4")))
if (!is.finite(workers) || workers < 1L || workers > 8L) {
  stop("--workers must be an integer from 1 to 8.", call. = FALSE)
}
workers <- min(workers, max(1L, parallel::detectCores() - 1L))

public_dir <- file.path(root, "results", "v45_3")
restricted_dir <- file.path(root, "derived_sensitive", "v45_3")
log_dir <- file.path(root, "logs", "v45_3")
work_dir <- file.path(root, "work_v45_3")
dir.create(public_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(restricted_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(log_dir, recursive = TRUE, showWarnings = FALSE)

restricted_path <- file.path(
  restricted_dir, "v45_3_reviewer_addendum_restricted.rds"
)
hash_output_path <- file.path(
  public_dir, "v45_3_input_hash_validation.tsv"
)
run_status_path <- file.path(public_dir, "v45_3_restricted_run_status.tsv")
log_path <- file.path(log_dir, "v45_3_reviewer_addendum.log")

for (path in c(restricted_path, hash_output_path, run_status_path, log_path)) {
  if (file.exists(path)) {
    stop("Refusing to overwrite an existing V45.3 output: ", path,
         call. = FALSE)
  }
}

expected_inputs <- data.frame(
  asset_id = c(
    "V45_2_BASELINE_ARCHIVE",
    "MI_G_POINTER",
    "MI_G_MIDS",
    "MI_S_POINTER",
    "MI_S_MIDS",
    "NHANES_STAGE3_LEDGER",
    "RAO_WU_CONTRACT",
    "NHANES_SPLINE_KNOTS",
    "NHANES_EXISTING_LINEARITY",
    "CHARLS_EXISTING_LINEARITY",
    "V43_NHANES_SOURCE",
    "V45_COMMON_UTILITIES",
    "V45_GLI_FUNCTIONS",
    "V45_OUTCOME_UTILITIES",
    "V45_PRIOR_IPW_RESTRICTED",
    "V45_RUNTIME_MANIFEST",
    "V45_SEED_LEDGER"
  ),
  path_alias = c(
    "output/submission_package_v45_2_FINAL_2026-07-28.zip",
    "results/v45/production_mi/MI_G_m50_current.tsv",
    paste0(
      "derived_sensitive/v45/production_mi/MI-G/m50/",
      "v45_mig_m50_20260725T115408_pid11053/MI-G_m50.mids.rds"
    ),
    "results/v45/production_mi/MI_S_m50_current.tsv",
    paste0(
      "derived_sensitive/v45/production_mi/MI-S/m50/",
      "v45_mis_m50_20260725T130516_pid28025/MI-S_m50.mids.rds"
    ),
    "derived_sensitive/v43/nhanes_stage3_analysis_ledger_v43.rds",
    "derived_sensitive/v45/v45_rao_wu_replicate_contract.rds",
    "results/v43/stage3_nhanes_spline_knot_registry_v43.csv",
    "results/v43/stage3_nhanes_time_varying_effects_v43.csv",
    "results/v44_1_1/stage3_charls_nonlinearity_tests_v44_1_1.csv",
    paste0(
      "output/code_archive/PEF_mortality_v44_2_code_candidate/",
      "R/v43/05_nhanes_stage3_primary_mortality.R"
    ),
    "R/v45/01_nhanes_common_utilities_v45.R",
    "R/v45/02_gli_functions_v45.R",
    "R/v45/11_nhanes_outcome_utilities_v45.R",
    paste0(
      "derived_sensitive/v45/outcome_execution/m50/",
      "v45_nhanes_outcome_m50_20260725T150659_pid55259/",
      "ipw_full_restricted.rds"
    ),
    "work_v45/v45_runtime_manifest.tsv",
    "work_v45/v45_seed_ledger.tsv"
  ),
  expected_sha256 = c(
    "71c4a9bd8ca03c3a7508d760781ef2c138a7f56d6c0d6084a15e4af3c8a12118",
    "f619725b2fd1c7f8734133816f03eac4fa890c7ecdf5e28aeda44f1fbcc1fb7a",
    "41bcc3e5fbfd8f19501682e93354856ffc06adf6e426937327e07138d17733d3",
    "d14a33528ba70d327e9f2f7b632126af1708d319ea93e9ea12e026d6228ea420",
    "eac97bedccf143d7ff7896df7f891f414df65a1204c296e5dbd4befded3de5dd",
    "5bbf1a1b5f6896e5f119ed903a4e7b8f751947b5880a9edfe4cd05228a2013b6",
    "2d795d61aabcce42603b1cfa7b254239a716980821ad1865347a8a8327c9f152",
    "9c1f62ee917d4d54a6aaeef00c6728066b352f871c5c593e94e8ea0e7db5690c",
    "56587869df7f85e55a5d1c74ee120e3407859f3bd0c347f39cf605219547df83",
    "de114f6185adcfeb14a286a8bef54acb8099229567a19ad3b3a8d3341665e55f",
    "fe3c13c9fda0c9036765cd7440c6c2aa43d0498cedc2c988e3b0806a8215e8b5",
    "5dd8519d0236c57b2cda97393d2543494afbec286d8433ab7b75ae5ebe32e8b4",
    "ff5d1526dc504858895fd40d9ea44be7894830745ed61071e739b039c52cdf66",
    "24339325545eed72643a7cd2329796dafa2a4930c183104426eacad04de48dc8",
    "a38e4ed97d84952a8f6134fa63a6cdbd4da827c7d020de74f0e506a59c875b05",
    "e2513d3bd932313baa6bcaea93f169b89c5fd2d191e27715496d8340f23837a7",
    "ae9b6360333174d384c55791623646363b072d421b9f81a9a7dc690b2dd20af5"
  ),
  stringsAsFactors = FALSE
)
expected_inputs$observed_sha256 <- vapply(
  expected_inputs$path_alias,
  function(path) {
    full <- file.path(root, path)
    if (!file.exists(full)) return(NA_character_)
    v45_sha256_file(full)
  },
  character(1)
)
expected_inputs$status <- ifelse(
  expected_inputs$observed_sha256 == expected_inputs$expected_sha256,
  "PASS", "FAIL"
)
if (any(expected_inputs$status != "PASS")) {
  failed <- expected_inputs$asset_id[expected_inputs$status != "PASS"]
  stop("V45.3 input freeze failed for: ", paste(failed, collapse = ", "),
       call. = FALSE)
}

spec_path <- file.path(
  work_dir, "reviewer_addendum_spec_v45_3.yml"
)
scope_path <- file.path(
  work_dir, "V45_3_SCOPE_FREEZE_2026-07-28.md"
)
if (!file.exists(spec_path) || !file.exists(scope_path)) {
  stop("The V45.3 frozen scope files are missing.", call. = FALSE)
}

read_tsv <- function(path) {
  utils::read.delim(
    path, stringsAsFactors = FALSE, check.names = FALSE,
    na.strings = c("", "NA")
  )
}

load_frozen_mids <- function(pointer_alias, expected_id, expected_hash) {
  pointer <- read_tsv(file.path(root, pointer_alias))
  if (
    nrow(pointer) != 1L ||
    !identical(as.character(pointer$object_id), expected_id) ||
    pointer$requested_m != 50L ||
    !identical(as.character(pointer$status), "INDEPENDENT_VALIDATION_PASS")
  ) {
    stop(expected_id, " pointer does not satisfy the frozen contract.",
         call. = FALSE)
  }
  path <- file.path(root, pointer$mids_path_alias[[1L]])
  if (!file.exists(path) ||
      !identical(v45_sha256_file(path), expected_hash) ||
      !identical(as.character(pointer$mids_sha256), expected_hash)) {
    stop(expected_id, " mids hash does not satisfy the frozen contract.",
         call. = FALSE)
  }
  object <- readRDS(path)
  if (!inherits(object, "mids") || object$m != 50L) {
    stop(expected_id, " is not an exact m=50 mids object.",
         call. = FALSE)
  }
  object
}

weighted_mean <- function(x, w) {
  sum(as.numeric(x) * as.numeric(w)) / sum(as.numeric(w))
}

weighted_variance <- function(x, w) {
  x <- as.numeric(x)
  w <- as.numeric(w)
  center <- weighted_mean(x, w)
  sum(w * (x - center)^2) / sum(w)
}

weighted_quantile <- function(x, w, probs) {
  x <- as.numeric(x)
  w <- as.numeric(w)
  keep <- is.finite(x) & is.finite(w) & w > 0
  x <- x[keep]
  w <- w[keep]
  order_index <- order(x, method = "radix")
  x <- x[order_index]
  w <- w[order_index]
  plotting_position <- (cumsum(w) - 0.5 * w) / sum(w)
  as.numeric(stats::approx(
    plotting_position, x, xout = probs,
    method = "linear", ties = "ordered", rule = 2
  )$y)
}

weighted_correlation <- function(data, variables, weights) {
  matrix <- as.matrix(data[variables])
  storage.mode(matrix) <- "double"
  weights <- as.numeric(weights)
  if (any(!is.finite(matrix)) ||
      any(!is.finite(weights) | weights <= 0)) {
    stop("Weighted correlation received non-finite data or weights.",
         call. = FALSE)
  }
  centers <- colSums(matrix * weights) / sum(weights)
  centered <- sweep(matrix, 2L, centers, "-")
  scales <- sqrt(colSums(centered^2 * weights) / sum(weights))
  standardized <- sweep(centered, 2L, scales, "/")
  correlation <- crossprod(
    standardized, standardized * weights
  ) / sum(weights)
  dimnames(correlation) <- list(variables, variables)
  correlation
}

a1_rhs <- paste(v45_outcome_a1_terms(), collapse = " + ")

residual_condition_row <- function(
    data, exposure_names, block_id, imputation,
    omitted_cycle = "none") {
  use <- if (identical(omitted_cycle, "none")) {
    rep(TRUE, nrow(data))
  } else {
    as.character(data$cycle_label) != omitted_cycle
  }
  local <- data[use, , drop = FALSE]
  weights <- as.numeric(local$wtmec6yr)
  base <- stats::model.matrix(
    stats::as.formula(paste("~", a1_rhs)), data = local
  )
  residuals <- sapply(exposure_names, function(name) {
    stats::lm.wfit(
      x = base, y = as.numeric(local[[name]]), w = weights
    )$residuals
  })
  if (is.null(dim(residuals))) residuals <- matrix(residuals, ncol = 1L)
  centers <- colSums(residuals * weights) / sum(weights)
  centered <- sweep(residuals, 2L, centers, "-")
  scales <- sqrt(colSums(centered^2 * weights) / sum(weights))
  standardized <- sweep(centered, 2L, scales, "/")
  correlation <- crossprod(
    standardized, standardized * weights
  ) / sum(weights)
  eigenvalues <- eigen(
    correlation, symmetric = TRUE, only.values = TRUE
  )$values
  rank <- qr(standardized)$rank
  condition_index <- if (min(eigenvalues) > 0) {
    sqrt(max(eigenvalues) / min(eigenvalues))
  } else {
    Inf
  }
  off_diagonal <- correlation[
    row(correlation) != col(correlation)
  ]
  state <- if (rank < length(exposure_names) ||
               !is.finite(condition_index)) {
    "NUMERICAL_STOP"
  } else if (condition_index >= 30) {
    "CAUTION"
  } else {
    "GO"
  }
  data.frame(
    block_id = block_id,
    imputation = as.integer(imputation),
    omitted_cycle = omitted_cycle,
    rows = nrow(local),
    exposure_count = length(exposure_names),
    residual_matrix_rank = rank,
    maximum_absolute_weighted_correlation =
      max(abs(off_diagonal)),
    residual_condition_index = condition_index,
    structural_state = state,
    stringsAsFactors = FALSE
  )
}

residual_support_row <- function(data, imputation) {
  weights <- as.numeric(data$wtmec6yr)
  base <- stats::model.matrix(
    stats::as.formula(paste("~", a1_rhs)), data = data
  )
  full <- cbind(
    base,
    L_FEV1 = as.numeric(data$L_FEV1),
    L_RATIO = as.numeric(data$L_RATIO)
  )
  target <- as.numeric(data$E0)
  residual_base <- stats::lm.wfit(
    x = base, y = target, w = weights
  )$residuals
  residual_full <- stats::lm.wfit(
    x = full, y = target, w = weights
  )$residuals
  sse_base <- sum(weights * residual_base^2)
  sse_full <- sum(weights * residual_full^2)
  quantiles <- weighted_quantile(
    residual_full, weights, c(0.05, 0.25, 0.50, 0.75, 0.95)
  )
  data.frame(
    imputation = as.integer(imputation),
    raw_e0_sd = sqrt(weighted_variance(target, weights)),
    a1_residual_sd =
      sqrt(weighted_variance(residual_base, weights)),
    conditional_residual_sd =
      sqrt(weighted_variance(residual_full, weights)),
    conditional_residual_q05 = quantiles[[1L]],
    conditional_residual_q25 = quantiles[[2L]],
    conditional_residual_q50 = quantiles[[3L]],
    conditional_residual_q75 = quantiles[[4L]],
    conditional_residual_q95 = quantiles[[5L]],
    partial_r2_gli_given_a1 = 1 - sse_full / sse_base,
    retained_a1_residual_variance_fraction = sse_full / sse_base,
    full_matrix_columns = ncol(full),
    full_matrix_rank = qr(full)$rank,
    stringsAsFactors = FALSE
  )
}

balance_detail_rows <- function(target_data, base_weight, imputation) {
  response_formula <- v45_outcome_d1_formula(FALSE)
  response_data <- target_data
  response_data$.v45_response_weight <-
    base_weight / mean(base_weight)
  fit <- stats::glm(
    response_formula,
    data = response_data,
    weights = .v45_response_weight,
    family = quasibinomial()
  )
  probability <- as.numeric(stats::predict(
    fit, newdata = target_data, type = "response"
  ))
  respondent <- as.character(target_data$R_A) == "1"
  factor_contract <- v45_ipw_factors(
    probability, respondent, base_weight
  )
  matrix <- stats::model.matrix(
    stats::delete.response(stats::terms(response_formula)),
    data = target_data
  )
  matrix <- matrix[
    , colnames(matrix) != "(Intercept)", drop = FALSE
  ]
  target_mean <- apply(
    matrix, 2L, weighted_mean, w = base_weight
  )
  target_sd <- sqrt(apply(
    matrix, 2L, weighted_variance, w = base_weight
  ))
  target_sd[!is.finite(target_sd) | target_sd <= 0] <- NA_real_
  respondent_base <- base_weight[respondent]
  variants <- list(
    original = rep(1, sum(respondent)),
    uncapped = factor_contract$factors[["uncapped"]]
  )
  dplyr::bind_rows(lapply(names(variants), function(variant) {
    weight <- respondent_base * variants[[variant]]
    respondent_mean <- apply(
      matrix[respondent, , drop = FALSE],
      2L, weighted_mean, w = weight
    )
    smd <- (respondent_mean - target_mean) / target_sd
    index <- which.max(abs(smd))
    data.frame(
      imputation = as.integer(imputation),
      response_specification = "primary",
      variant = variant,
      maximum_absolute_smd = abs(smd[[index]]),
      maximum_smd_variable = names(smd)[[index]],
      signed_smd = smd[[index]],
      stringsAsFactors = FALSE
    )
  }))
}

parallel_map <- function(indices, fun, label) {
  message(label, ": ", length(indices), " imputations; workers=", workers)
  wrapper <- function(index) {
    tryCatch(
      list(ok = TRUE, value = fun(index), error = ""),
      error = function(error) list(
        ok = FALSE, value = NULL,
        error = conditionMessage(error)
      )
    )
  }
  result <- if (workers == 1L) {
    lapply(indices, wrapper)
  } else {
    parallel::mclapply(
      indices, wrapper, mc.cores = workers,
      mc.preschedule = FALSE, mc.set.seed = FALSE
    )
  }
  failed <- !vapply(result, `[[`, logical(1), "ok")
  if (any(failed)) {
    stop(
      label, " failed for imputation(s) ",
      paste(indices[failed], collapse = ", "), ": ",
      paste(
        vapply(result[failed], `[[`, character(1), "error"),
        collapse = " | "
      ),
      call. = FALSE
    )
  }
  lapply(result, `[[`, "value")
}

ledger <- v45_read_nhanes_ledger(root)
v43 <- v45_load_v43_nhanes_functions(root)
rw <- readRDS(file.path(
  root, "derived_sensitive", "v45",
  "v45_rao_wu_replicate_contract.rds"
))
design_data <- v45_outcome_design_data(ledger, rw)

mig <- load_frozen_mids(
  "results/v45/production_mi/MI_G_m50_current.tsv",
  "MI-G",
  "41bcc3e5fbfd8f19501682e93354856ffc06adf6e426937327e07138d17733d3"
)

spline_terms <- c(
  "E0_linear", "E0_nonlinear1", "E0_nonlinear2"
)
spline_formula <- v45_outcome_formula(
  c(spline_terms, "L_FEV1", "L_RATIO"), "A1"
)
correlation_variables <- c(
  "E0", "L_FEV1", "L_FVC", "L_RATIO"
)
condition_blocks <- list(
  prespecified_conditional =
    c("E0", "L_FEV1", "L_RATIO"),
  four_exposure_sensitivity =
    c("E0", "L_FEV1", "L_FVC", "L_RATIO")
)

gli_results <- parallel_map(seq_len(50L), function(imputation) {
  completed <- v45_prepare_mig_completed(
    mice::complete(mig, action = imputation), ledger, v43
  )
  merged <- v45_merge_completed_design(design_data, completed)
  design <- v45_make_taylor_design(merged)
  fit <- v45_fit_taylor_cox_prebuilt(
    merged = merged,
    full_design = design,
    domain_index = merged$analysis_domain,
    formula = spline_formula,
    model_id = paste0(
      "v45_3_nhanes_conditional_pef_spline_imp", imputation
    )
  )
  missing_terms <- setdiff(spline_terms, names(fit$coefficients))
  if (length(missing_terms)) {
    stop("Spline fit lacks: ", paste(missing_terms, collapse = ", "),
         call. = FALSE)
  }
  correlation <- weighted_correlation(
    completed, correlation_variables, completed$wtmec6yr
  )
  correlation_long <- expand.grid(
    variable_1 = correlation_variables,
    variable_2 = correlation_variables,
    stringsAsFactors = FALSE
  )
  correlation_long$imputation <- as.integer(imputation)
  correlation_long$weighted_correlation <- mapply(
    function(variable_1, variable_2) {
      correlation[variable_1, variable_2]
    },
    correlation_long$variable_1,
    correlation_long$variable_2
  )
  condition_rows <- dplyr::bind_rows(lapply(
    names(condition_blocks), function(block_id) {
      dplyr::bind_rows(lapply(
        c("none", "E", "F", "G"), function(omitted_cycle) {
          residual_condition_row(
            completed, condition_blocks[[block_id]], block_id,
            imputation, omitted_cycle
          )
        }
      ))
    }
  ))
  list(
    imputation = as.integer(imputation),
    spline_coefficients =
      unname(fit$coefficients[spline_terms]),
    spline_covariance =
      unname(fit$variance[spline_terms, spline_terms, drop = FALSE]),
    diagnostics = fit$diagnostics,
    correlation = correlation_long,
    condition = condition_rows,
    residual_support = residual_support_row(completed, imputation)
  )
}, "MI-G conditional spline and diagnostics")
rm(mig)
invisible(gc(verbose = FALSE))

mis <- load_frozen_mids(
  "results/v45/production_mi/MI_S_m50_current.tsv",
  "MI-S",
  "eac97bedccf143d7ff7896df7f891f414df65a1204c296e5dbd4befded3de5dd"
)
selection_results <- parallel_map(seq_len(50L), function(imputation) {
  completed <- v45_prepare_mis_completed(
    mice::complete(mis, action = imputation), ledger, v43
  )
  full_rows <- match(as.integer(completed$SEQN), design_data$SEQN)
  if (anyNA(full_rows)) {
    stop("MI-S target IDs are absent from the frozen design.")
  }
  base_weight <- as.numeric(rw$full_design_pweights[full_rows])
  balance_detail_rows(completed, base_weight, imputation)
}, "MI-S pre/post-weight balance detail")
rm(mis)
invisible(gc(verbose = FALSE))

selection_detail <- dplyr::bind_rows(selection_results)
prior_ipw <- readRDS(file.path(
  root,
  paste0(
    "derived_sensitive/v45/outcome_execution/m50/",
    "v45_nhanes_outcome_m50_20260725T150659_pid55259/",
    "ipw_full_restricted.rds"
  )
))
prior_balance <- prior_ipw$balance[
  prior_ipw$balance$response_specification == "primary" &
    prior_ipw$balance$variant %in% c("original", "uncapped"),
  c("imputation", "variant", "maximum_absolute_smd"),
  drop = FALSE
]
selection_check <- dplyr::left_join(
  selection_detail,
  prior_balance,
  by = c("imputation", "variant"),
  suffix = c("_recomputed", "_frozen")
)
if (
  nrow(selection_check) != 100L ||
  anyNA(selection_check$maximum_absolute_smd_frozen) ||
  max(abs(
    selection_check$maximum_absolute_smd_recomputed -
      selection_check$maximum_absolute_smd_frozen
  )) > 1e-10
) {
  stop("Recomputed IPW SMD maxima do not reproduce the frozen V45 output.",
       call. = FALSE)
}

restricted_object <- list(
  schema_version = "v45_3_reviewer_addendum_restricted",
  created_at_utc = format(
    Sys.time(), tz = "UTC", format = "%Y-%m-%dT%H:%M:%SZ"
  ),
  scope_spec_sha256 = v45_sha256_file(spec_path),
  scope_record_sha256 = v45_sha256_file(scope_path),
  input_hashes = expected_inputs,
  coefficient_visibility = "RESTRICTED_PENDING_INDEPENDENT_RELEASE",
  row_level_data_saved = FALSE,
  completed_imputation_saved = FALSE,
  model_object_saved = FALSE,
  spline_terms = spline_terms,
  spline_formula = paste(deparse(spline_formula), collapse = " "),
  gli_results = gli_results,
  selection_balance_detail = selection_detail,
  selection_reproduction_maximum_difference = max(abs(
    selection_check$maximum_absolute_smd_recomputed -
      selection_check$maximum_absolute_smd_frozen
  ))
)
v45_atomic_save_rds(restricted_object, restricted_path)

expected_inputs$scope_spec_sha256 <- v45_sha256_file(spec_path)
expected_inputs$restricted_output_sha256 <- v45_sha256_file(restricted_path)
v45_atomic_write_tsv(expected_inputs, hash_output_path)

status <- data.frame(
  version = "v45.3",
  status = "RESTRICTED_COMPLETE_PENDING_INDEPENDENT_RELEASE",
  imputations = 50L,
  new_outcome_model_count = 1L,
  completed_data_saved = FALSE,
  row_level_data_saved = FALSE,
  restricted_path_alias = substring(
    restricted_path, nchar(root) + 2L
  ),
  restricted_sha256 = v45_sha256_file(restricted_path),
  workers = workers,
  stringsAsFactors = FALSE
)
v45_atomic_write_tsv(status, run_status_path)
v45_atomic_write_lines(c(
  "V45.3 reviewer addendum restricted execution completed.",
  paste0("created_at_utc: ", restricted_object$created_at_utc),
  "new_outcome_model_count: 1",
  "imputations: 50",
  "coefficient_visibility: restricted pending independent release",
  "completed_data_saved: false",
  "row_level_data_saved: false",
  paste0("restricted_sha256: ", status$restricted_sha256)
), log_path)

cat("V45_3_RESTRICTED_EXECUTION_COMPLETE\n")
cat("restricted_sha256=", status$restricted_sha256, "\n", sep = "")
cat("coefficient_visibility=RESTRICTED_PENDING_INDEPENDENT_RELEASE\n")
