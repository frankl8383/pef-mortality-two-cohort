# v43 NHANES Stage 1-2 audit: source merge, target-population flow,
# spirometry measurement quality, survey design, and outcome-blind E0 scaling.
#
# This script reads raw public NHANES files directly. It does not fit an
# outcome model. Results/logs are aggregate only; the sole row-level output is
# the contract-authorized machine ledger under derived_sensitive/v43/.

suppressPackageStartupMessages({
  library(dplyr)
  library(haven)
  library(readr)
  library(survey)
  library(tibble)
  library(tidyr)
  library(yaml)
})

options(survey.lonely.psu = "adjust")

project_root <- function() {
  args <- commandArgs(trailingOnly = FALSE)
  file_arg <- grep("^--file=", args, value = TRUE)
  if (length(file_arg)) {
    script <- sub("^--file=", "", file_arg[[1]])
    return(normalizePath(file.path(dirname(script), "..", ".."), mustWork = TRUE))
  }
  normalizePath(getwd(), mustWork = TRUE)
}

resolve_path <- function(root, path) {
  if (grepl("^/", path)) path else file.path(root, path)
}

clean_chr <- function(x) {
  out <- toupper(trimws(as.character(x)))
  out[is.na(out) | !nzchar(out)] <- NA_character_
  out
}

difficulty_binary <- function(x) {
  z <- suppressWarnings(as.numeric(x))
  dplyr::case_when(
    z == 1 ~ 0L,
    z %in% 2:4 ~ 1L,
    TRUE ~ NA_integer_
  )
}

difficulty_binary_code5_positive <- function(x) {
  z <- suppressWarnings(as.numeric(x))
  dplyr::case_when(
    z == 1 ~ 0L,
    z %in% 2:5 ~ 1L,
    TRUE ~ NA_integer_
  )
}

row_any_positive <- function(dat) {
  mat <- as.matrix(dat)
  observed <- rowSums(!is.na(mat))
  positive <- rowSums(mat == 1, na.rm = TRUE)
  out <- rep(NA_integer_, nrow(mat))
  out[positive > 0] <- 1L
  out[observed == ncol(mat) & positive == 0] <- 0L
  out
}

weighted_mean_simple <- function(x, w) {
  ok <- is.finite(x) & is.finite(w) & w > 0
  if (!any(ok)) return(NA_real_)
  sum(x[ok] * w[ok]) / sum(w[ok])
}

weighted_var_simple <- function(x, w) {
  ok <- is.finite(x) & is.finite(w) & w > 0
  if (sum(ok) < 2L) return(NA_real_)
  mu <- weighted_mean_simple(x[ok], w[ok])
  sum(w[ok] * (x[ok] - mu)^2) / sum(w[ok])
}

weighted_cor_simple <- function(x, y, w) {
  ok <- is.finite(x) & is.finite(y) & is.finite(w) & w > 0
  if (sum(ok) < 3L) return(NA_real_)
  x <- x[ok]
  y <- y[ok]
  w <- w[ok]
  mx <- sum(w * x) / sum(w)
  my <- sum(w * y) / sum(w)
  vx <- sum(w * (x - mx)^2) / sum(w)
  vy <- sum(w * (y - my)^2) / sum(w)
  if (!is.finite(vx) || !is.finite(vy) || vx <= 0 || vy <= 0) return(NA_real_)
  sum(w * (x - mx) * (y - my)) / sum(w) / sqrt(vx * vy)
}

kish_ess <- function(w) {
  w <- w[is.finite(w) & w > 0]
  if (!length(w)) return(NA_real_)
  sum(w)^2 / sum(w^2)
}

markdown_table <- function(dat) {
  dat <- as.data.frame(dat, stringsAsFactors = FALSE)
  if (!nrow(dat)) return("_No rows._")
  dat[] <- lapply(dat, function(x) ifelse(is.na(x), "", as.character(x)))
  c(
    paste0("| ", paste(names(dat), collapse = " | "), " |"),
    paste0("| ", paste(rep("---", ncol(dat)), collapse = " | "), " |"),
    apply(dat, 1, function(x) paste0("| ", paste(x, collapse = " | "), " |"))
  )
}

read_xpt_cycle <- function(raw_dir, component, suffix, cycle) {
  path <- file.path(raw_dir, paste0(component, "_", suffix, ".XPT"))
  if (!file.exists(path)) stop("Missing raw NHANES file: ", path, call. = FALSE)
  dat <- haven::zap_labels(haven::read_xpt(path))
  names(dat) <- toupper(names(dat))
  dat %>%
    mutate(cycle_label = suffix, cycle = cycle, source_file = basename(path))
}

read_mortality_cycle <- function(path, suffix, cycle) {
  if (!file.exists(path)) stop("Missing mortality file: ", path, call. = FALSE)
  readr::read_fwf(
    file = path,
    col_types = "iiiiiiii",
    col_positions = readr::fwf_cols(
      SEQN = c(1, 6),
      ELIGSTAT = c(15, 15),
      MORTSTAT = c(16, 16),
      UCOD_LEADING = c(17, 19),
      DIABETES = c(20, 20),
      HYPERTEN = c(21, 21),
      PERMTH_INT = c(43, 45),
      PERMTH_EXM = c(46, 48)
    ),
    na = c("", "."),
    progress = FALSE
  ) %>%
    mutate(cycle_label = suffix, cycle = cycle, mortality_source_file = basename(path))
}

status_label <- function(x) {
  dplyr::case_when(
    x == 1 ~ "Complete exam",
    x == 2 ~ "Partial exam",
    x == 3 ~ "Not done",
    x == 4 ~ "Safety exclusion",
    TRUE ~ "Missing/unknown"
  )
}

comment_label <- function(x) {
  dplyr::case_when(
    is.na(x) ~ "No comment recorded",
    x == 2 ~ "SP refusal",
    x == 3 ~ "No time",
    x == 4 ~ "Physical limitation",
    x == 5 ~ "Communication problem",
    x == 6 ~ "Equipment failure",
    x == 7 ~ "SP ill/emergency",
    x == 14 ~ "Interrupted",
    x == 27 ~ "Proxy no information",
    x == 51 ~ "SP unable to comply",
    x == 56 ~ "Came late/left early",
    x == 62 ~ "Problem with data capture",
    x == 84 ~ "SP with child",
    x == 99 ~ "Other",
    x == 122 ~ "Language barrier",
    TRUE ~ paste0("Unmapped comment code ", x)
  )
}

append_all_cycle <- function(dat) {
  bind_rows(dat, dat %>% mutate(cycle_label = "ALL", cycle = "2007-2012 pooled"))
}

count_flag <- function(dat, flag, branch, order, id, label) {
  tibble(
    flow_branch = branch,
    step_order = order,
    step_id = id,
    step_label = label,
    n = sum(flag, na.rm = TRUE),
    deaths = sum(dat$death[flag] == 1L, na.rm = TRUE)
  )
}

count_by_cycle <- function(dat, flag_name, anchor_id) {
  pooled <- dat %>%
    filter(.data[[flag_name]]) %>%
    summarise(n = n(), deaths = sum(death == 1L, na.rm = TRUE)) %>%
    mutate(cycle_label = "ALL", cycle = "2007-2012 pooled", .before = 1)
  by_cycle <- dat %>%
    filter(.data[[flag_name]]) %>%
    group_by(cycle_label, cycle) %>%
    summarise(n = n(), deaths = sum(death == 1L, na.rm = TRUE), .groups = "drop")
  bind_rows(pooled, by_cycle) %>%
    mutate(anchor_id = anchor_id, .after = cycle)
}

summarise_quality_flag <- function(dat, flag_name, layer_id, definition) {
  denominator <- dat %>% filter(safe_target)
  make_one <- function(d, cycle_label, cycle) {
    flag <- d[[flag_name]]
    w <- d$wtmec6yr
    tibble(
      cycle_label = cycle_label,
      cycle = cycle,
      layer_id = layer_id,
      definition = definition,
      denominator_n = nrow(d),
      n = sum(flag, na.rm = TRUE),
      deaths = sum(d$death[flag] == 1L, na.rm = TRUE),
      unweighted_percent = 100 * mean(flag, na.rm = TRUE),
      weighted_percent = 100 * sum(w[flag], na.rm = TRUE) / sum(w, na.rm = TRUE)
    )
  }
  bind_rows(
    make_one(denominator, "ALL", "2007-2012 pooled"),
    bind_rows(lapply(split(denominator, denominator$cycle_label), function(d) {
      make_one(d, d$cycle_label[[1]], d$cycle[[1]])
    }))
  )
}

measurement_summary_one <- function(dat, flag_name, population_id, variable, variable_label) {
  selected <- dat %>% filter(.data[[flag_name]])
  make_one <- function(d, cycle_label, cycle) {
    x <- d[[variable]]
    w <- d$wtmec6yr
    ok <- is.finite(x) & is.finite(w) & w > 0
    x_ok <- x[ok]
    w_ok <- w[ok]
    if (!length(x_ok)) {
      return(tibble(
        cycle_label = cycle_label, cycle = cycle, population_id = population_id,
        variable = variable, variable_label = variable_label, n_nonmissing = 0L,
        weighted_mean = NA_real_, weighted_sd = NA_real_, unweighted_mean = NA_real_,
        unweighted_sd = NA_real_, unweighted_min = NA_real_, unweighted_p01 = NA_real_,
        unweighted_p05 = NA_real_, unweighted_p25 = NA_real_, unweighted_median = NA_real_,
        unweighted_p75 = NA_real_, unweighted_p95 = NA_real_, unweighted_p99 = NA_real_,
        unweighted_max = NA_real_
      ))
    }
    qs <- as.numeric(quantile(
      x_ok, c(0.01, 0.05, 0.25, 0.50, 0.75, 0.95, 0.99),
      na.rm = TRUE, names = FALSE
    ))
    tibble(
      cycle_label = cycle_label,
      cycle = cycle,
      population_id = population_id,
      variable = variable,
      variable_label = variable_label,
      n_nonmissing = length(x_ok),
      weighted_mean = weighted_mean_simple(x_ok, w_ok),
      weighted_sd = sqrt(weighted_var_simple(x_ok, w_ok)),
      unweighted_mean = mean(x_ok),
      unweighted_sd = stats::sd(x_ok),
      unweighted_min = min(x_ok), unweighted_p01 = qs[[1]], unweighted_p05 = qs[[2]],
      unweighted_p25 = qs[[3]], unweighted_median = qs[[4]], unweighted_p75 = qs[[5]],
      unweighted_p95 = qs[[6]], unweighted_p99 = qs[[7]], unweighted_max = max(x_ok)
    )
  }
  bind_rows(
    make_one(selected, "ALL", "2007-2012 pooled"),
    bind_rows(lapply(split(selected, selected$cycle_label), function(d) {
      make_one(d, d$cycle_label[[1]], d$cycle[[1]])
    }))
  )
}

correlation_rows <- function(dat, flag_name, quality_layer) {
  pairs <- tribble(
    ~x, ~y, ~pair,
    "pef_l_min", "fev1_l", "PEF vs FEV1",
    "pef_l_min", "fvc_l", "PEF vs FVC",
    "pef_l_min", "fev1_fvc", "PEF vs FEV1/FVC",
    "fev1_l", "fvc_l", "FEV1 vs FVC"
  )
  selected <- dat %>% filter(.data[[flag_name]], spirometry_abc)
  make_cycle <- function(d, cycle_label, cycle) {
    bind_rows(lapply(seq_len(nrow(pairs)), function(i) {
      x <- d[[pairs$x[[i]]]]
      y <- d[[pairs$y[[i]]]]
      w <- d$wtmec6yr
      ok <- is.finite(x) & is.finite(y) & is.finite(w) & w > 0
      tibble(
        cycle_label = cycle_label,
        cycle = cycle,
        quality_layer = quality_layer,
        pair = pairs$pair[[i]],
        n = sum(ok),
        pearson = if (sum(ok) >= 3L) stats::cor(x[ok], y[ok], method = "pearson") else NA_real_,
        spearman = if (sum(ok) >= 3L) stats::cor(x[ok], y[ok], method = "spearman") else NA_real_,
        weighted_pearson = weighted_cor_simple(x, y, w)
      )
    }))
  }
  bind_rows(
    make_cycle(selected, "ALL", "2007-2012 pooled"),
    bind_rows(lapply(split(selected, selected$cycle_label), function(d) {
      make_cycle(d, d$cycle_label[[1]], d$cycle[[1]])
    }))
  )
}

anomaly_rows <- function(dat, flag, anomaly_id, definition, scope,
                         hard_assertion = TRUE, expected_n = 0L) {
  make_one <- function(d, f, cycle_label, cycle) {
    n <- sum(f, na.rm = TRUE)
    tibble(
      cycle_label = cycle_label,
      cycle = cycle,
      anomaly_id = anomaly_id,
      definition = definition,
      scope = scope,
      n = n,
      deaths = sum(d$death[f] == 1L, na.rm = TRUE),
      hard_assertion = hard_assertion,
      expected_n = if (hard_assertion) expected_n else NA_integer_,
      pass = if (hard_assertion) n == expected_n else NA
    )
  }
  out <- make_one(dat, flag, "ALL", "2007-2012 pooled")
  for (cy in c("E", "F", "G")) {
    idx <- dat$cycle_label == cy
    out <- bind_rows(out, make_one(
      dat[idx, , drop = FALSE], flag[idx], cy, unique(dat$cycle[idx])[[1]]
    ))
  }
  out
}

gate_row <- function(check, pass, observed, expected, detail = "") {
  tibble(
    check = check,
    pass = as.logical(pass),
    observed = as.character(observed),
    expected = as.character(expected),
    detail = detail
  )
}

root <- project_root()
spec <- yaml::read_yaml(file.path(root, "work_v43", "analysis_spec_v43.yml"))
raw_dir <- resolve_path(root, spec$inputs$nhanes_raw_xpt_dir)
mort_dir <- resolve_path(root, spec$inputs$nhanes_mortality_dir)
out_dir <- file.path(root, "results", "v43")
log_dir <- file.path(root, "logs", "v43")
ledger_dir <- file.path(root, "derived_sensitive", "v43")
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(log_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(ledger_dir, recursive = TRUE, showWarnings = FALSE)

cycle_map <- tribble(
  ~cycle_label, ~cycle, ~sddsrvyr_expected, ~mortality_file,
  "E", "2007-2008", 5, "NHANES_2007_2008_MORT_2019_PUBLIC.dat",
  "F", "2009-2010", 6, "NHANES_2009_2010_MORT_2019_PUBLIC.dat",
  "G", "2011-2012", 7, "NHANES_2011_2012_MORT_2019_PUBLIC.dat"
)

demo_keep <- c(
  "SEQN", "SDDSRVYR", "RIDSTATR", "RIDAGEYR", "RIAGENDR", "RIDRETH1",
  "WTMEC2YR", "SDMVPSU", "SDMVSTRA"
)
spx_keep <- c(
  "SEQN", "ENQ010", "ENQ020", "SPQ010", "SPQ020", "SPQ030", "SPQ040",
  "SPQ050", "SPQ060", "SPQ070A", "SPQ070B", "SPQ070C", "SPQ070D",
  "SPQ070E", "SPQ080", "SPQ090", "SPQ100", "ENQ100",
  "SPXNSTAT", "SPXNCMT", "SPXNPEF", "SPXNFEV1", "SPXNFVC", "SPXNQEFF",
  "SPXNQFVC", "SPXNQFV1", "SPDNACC"
)
pfq_keep <- c(
  "SEQN", "PFQ049", "PFQ051", "PFQ054", "PFQ057", "PFQ059",
  paste0("PFQ061", c("A", "B", "C", "F", "G", "H", "I", "J", "K", "L"))
)

demo_list <- list()
spx_list <- list()
pfq_list <- list()
mort_list <- list()
for (i in seq_len(nrow(cycle_map))) {
  suffix <- cycle_map$cycle_label[[i]]
  cycle <- cycle_map$cycle[[i]]
  demo_i <- read_xpt_cycle(raw_dir, "DEMO", suffix, cycle)
  spx_i <- read_xpt_cycle(raw_dir, "SPX", suffix, cycle)
  pfq_i <- read_xpt_cycle(raw_dir, "PFQ", suffix, cycle)
  missing_demo <- setdiff(demo_keep, names(demo_i))
  missing_spx <- setdiff(spx_keep, names(spx_i))
  missing_pfq <- setdiff(pfq_keep, names(pfq_i))
  if (length(missing_demo)) stop("Missing DEMO variables in cycle ", suffix, ": ", paste(missing_demo, collapse = "; "))
  if (length(missing_spx)) stop("Missing SPX variables in cycle ", suffix, ": ", paste(missing_spx, collapse = "; "))
  if (length(missing_pfq)) stop("Missing PFQ variables in cycle ", suffix, ": ", paste(missing_pfq, collapse = "; "))
  demo_list[[suffix]] <- demo_i %>% select(all_of(demo_keep), cycle_label, cycle, source_file)
  spx_list[[suffix]] <- spx_i %>% select(all_of(spx_keep), cycle_label, cycle, source_file)
  pfq_list[[suffix]] <- pfq_i %>% select(all_of(pfq_keep), cycle_label, cycle, source_file)
  mort_list[[suffix]] <- read_mortality_cycle(
    file.path(mort_dir, cycle_map$mortality_file[[i]]), suffix, cycle
  )
}

demo <- bind_rows(demo_list) %>% rename(demo_source_file = source_file)
spx <- bind_rows(spx_list) %>% rename(spx_source_file = source_file)
pfq <- bind_rows(pfq_list) %>% rename(pfq_source_file = source_file)
mortality <- bind_rows(mort_list)

merge_audit <- bind_rows(lapply(seq_len(nrow(cycle_map)), function(i) {
  suffix <- cycle_map$cycle_label[[i]]
  cycle <- cycle_map$cycle[[i]]
  d <- demo_list[[suffix]]
  s <- spx_list[[suffix]]
  p <- pfq_list[[suffix]]
  m <- mort_list[[suffix]]
  tibble(
    cycle_label = suffix,
    cycle = cycle,
    demo_n = nrow(d),
    demo_duplicate_seqn = sum(duplicated(d$SEQN)),
    spx_n = nrow(s),
    spx_duplicate_seqn = sum(duplicated(s$SEQN)),
    pfq_n = nrow(p),
    pfq_duplicate_seqn = sum(duplicated(p$SEQN)),
    mortality_n = nrow(m),
    mortality_duplicate_seqn = sum(duplicated(m$SEQN)),
    demo_spx_matched_n = sum(d$SEQN %in% s$SEQN),
    spx_without_demo_n = sum(!s$SEQN %in% d$SEQN),
    demo_pfq_matched_n = sum(d$SEQN %in% p$SEQN),
    pfq_without_demo_n = sum(!p$SEQN %in% d$SEQN),
    demo_mortality_matched_n = sum(d$SEQN %in% m$SEQN),
    mortality_without_demo_n = sum(!m$SEQN %in% d$SEQN),
    three_way_matched_n = sum(d$SEQN %in% intersect(s$SEQN, m$SEQN))
  )
}))
merge_audit <- bind_rows(
  merge_audit,
  merge_audit %>%
    summarise(across(where(is.numeric), sum)) %>%
    mutate(cycle_label = "ALL", cycle = "2007-2012 pooled", .before = 1)
)

master <- demo %>%
  left_join(
    spx %>% select(-cycle, -spx_source_file),
    by = c("SEQN", "cycle_label")
  ) %>%
  left_join(
    pfq %>% select(-cycle, -pfq_source_file),
    by = c("SEQN", "cycle_label")
  ) %>%
  left_join(
    mortality %>% select(-cycle),
    by = c("SEQN", "cycle_label")
  ) %>%
  mutate(
    cycle_expected = dplyr::case_when(
      SDDSRVYR == 5 ~ "E",
      SDDSRVYR == 6 ~ "F",
      SDDSRVYR == 7 ~ "G",
      TRUE ~ NA_character_
    ),
    mortality_matched = !is.na(ELIGSTAT),
    mortality_eligible = ELIGSTAT == 1L,
    death = dplyr::case_when(
      ELIGSTAT == 1L & MORTSTAT == 1L ~ 1L,
      ELIGSTAT == 1L & MORTSTAT == 0L ~ 0L,
      TRUE ~ NA_integer_
    ),
    age_45_79 = is.finite(RIDAGEYR) & RIDAGEYR >= spec$nhanes$age_min & RIDAGEYR <= spec$nhanes$age_max,
    age_gt_79 = is.finite(RIDAGEYR) & RIDAGEYR > spec$nhanes$age_max,
    mec_examined = RIDSTATR == 2L & is.finite(WTMEC2YR) & WTMEC2YR > 0,
    wtmec6yr = WTMEC2YR / 3,
    status_available = SPXNSTAT %in% 1:4,
    target_linked = age_45_79 & mec_examined & mortality_eligible,
    safety_exclusion = target_linked & SPXNSTAT == 4L,
    safe_target = target_linked & SPXNSTAT %in% 1:3,
    pef_effort_quality = clean_chr(SPXNQEFF),
    fvc_quality = clean_chr(SPXNQFVC),
    fev1_quality = clean_chr(SPXNQFV1),
    pef_l_min = as.numeric(SPXNPEF) * spec$nhanes$measurement$conversion_multiplier,
    fev1_l = as.numeric(SPXNFEV1) / 1000,
    fvc_l = as.numeric(SPXNFVC) / 1000,
    fev1_fvc = ifelse(is.finite(SPXNFEV1) & is.finite(SPXNFVC) & SPXNFVC > 0,
                      SPXNFEV1 / SPXNFVC, NA_real_),
    pef_nonmissing = safe_target & is.finite(SPXNPEF) & SPXNPEF > 0,
    pef_A = pef_nonmissing & pef_effort_quality %in% "A",
    pef_A_acc3 = pef_nonmissing & pef_effort_quality %in% "A" &
      is.finite(SPDNACC) & SPDNACC >= 3,
    pef_AC = pef_nonmissing & pef_effort_quality %in% c("A", "C"),
    pef_ABC = pef_nonmissing & pef_effort_quality %in% c("A", "B", "C"),
    pef_B_only = pef_nonmissing & pef_effort_quality %in% "B",
    pef_C_only = pef_nonmissing & pef_effort_quality %in% "C",
    pef_blank_with_value = pef_nonmissing & is.na(pef_effort_quality),
    effort_present_pef_missing = safe_target & !is.na(pef_effort_quality) & !is.finite(SPXNPEF),
    spirometry_raw = safe_target & is.finite(SPXNFEV1) & SPXNFEV1 > 0 &
      is.finite(SPXNFVC) & SPXNFVC > 0 & is.finite(SPXNPEF) & SPXNPEF > 0,
    spirometry_abc = spirometry_raw & fev1_quality %in% c("A", "B", "C") &
      fvc_quality %in% c("A", "B", "C"),
    spirometry_ab = spirometry_raw & fev1_quality %in% c("A", "B") &
      fvc_quality %in% c("A", "B"),
    status_complete = safe_target & SPXNSTAT == 1L,
    status_partial = safe_target & SPXNSTAT == 2L,
    status_not_done = safe_target & SPXNSTAT == 3L,
    sex = dplyr::case_when(RIAGENDR == 1L ~ "male", RIAGENDR == 2L ~ "female", TRUE ~ NA_character_),
    design_strata = interaction(cycle_label, SDMVSTRA, drop = TRUE),
    design_psu = interaction(cycle_label, SDMVSTRA, SDMVPSU, drop = TRUE)
  )

# PFQ061 detailed-function items use a deterministic routing rule. Participants
# aged <=59 with PFQ049, PFQ057, and PFQ059 all coded "no" skip PFQ061 and
# should be coded as having no detailed difficulty, not treated as missing.
# PFQ051 and PFQ054 are deliberately not added to this check because the
# official PFQ059A CAPI rule names only PFQ049, PFQ057, and PFQ059. Conversely,
# PFQ054=1 suppresses the two walking items because difficulty without special
# equipment is already established; those participants are mobility-positive.
pfq_detail_vars <- paste0("PFQ061", c("A", "B", "C", "F", "G", "H", "I", "J", "K", "L"))
pfq_difficulty_vars <- paste0("difficulty_", pfq_detail_vars)
pfq_difficulty_code5_positive_vars <- paste0("difficulty_code5_positive_", pfq_detail_vars)
master[pfq_difficulty_vars] <- lapply(master[pfq_detail_vars], difficulty_binary)
master[pfq_difficulty_code5_positive_vars] <-
  lapply(master[pfq_detail_vars], difficulty_binary_code5_positive)
mobility_detail <- row_any_positive(master[paste0("difficulty_PFQ061", c("B", "C"))])
adl_detail <- row_any_positive(
  master[paste0("difficulty_PFQ061", c("A", "F", "G", "H", "I", "J", "K", "L"))]
)
mobility_detail_code5_positive <- row_any_positive(
  master[paste0("difficulty_code5_positive_PFQ061", c("B", "C"))]
)
adl_detail_code5_positive <- row_any_positive(
  master[paste0(
    "difficulty_code5_positive_PFQ061",
    c("A", "F", "G", "H", "I", "J", "K", "L")
  )]
)
master <- master %>%
  mutate(
    pfq_younger_no_limitation_skip = RIDAGEYR <= 59 &
      PFQ049 == 2 & PFQ057 == 2 & PFQ059 == 2,
    mobility_difficulty_routed = dplyr::case_when(
      PFQ054 == 1 ~ 1L,
      !is.na(mobility_detail) ~ mobility_detail,
      pfq_younger_no_limitation_skip ~ 0L,
      TRUE ~ NA_integer_
    ),
    adl_iadl_difficulty_routed = dplyr::case_when(
      !is.na(adl_detail) ~ adl_detail,
      pfq_younger_no_limitation_skip ~ 0L,
      TRUE ~ NA_integer_
    ),
    mobility_difficulty_code5_positive = dplyr::case_when(
      PFQ054 == 1 ~ 1L,
      !is.na(mobility_detail_code5_positive) ~ mobility_detail_code5_positive,
      pfq_younger_no_limitation_skip ~ 0L,
      TRUE ~ NA_integer_
    ),
    adl_iadl_difficulty_code5_positive = dplyr::case_when(
      !is.na(adl_detail_code5_positive) ~ adl_detail_code5_positive,
      pfq_younger_no_limitation_skip ~ 0L,
      TRUE ~ NA_integer_
    ),
    mobility_route_source = dplyr::case_when(
      PFQ054 == 1 ~ "PFQ054 established walking difficulty; B/C structurally suppressed",
      !is.na(mobility_detail) ~ "PFQ061B/C observed and classifiable under main code-5-missing rule",
      pfq_younger_no_limitation_skip ~ "age<=59 no-limitation screen; PFQ061 structurally skipped",
      TRUE ~ "unresolved item/nonresponse missing"
    ),
    adl_route_source = dplyr::case_when(
      !is.na(adl_detail) ~ "PFQ061A/F-L observed and classifiable under main code-5-missing rule",
      pfq_younger_no_limitation_skip ~ "age<=59 no-limitation screen; PFQ061 structurally skipped",
      TRUE ~ "unresolved item/nonresponse missing"
    ),
    mobility_code5_positive_route_source = dplyr::case_when(
      PFQ054 == 1 ~ "PFQ054 established walking difficulty; B/C structurally suppressed",
      !is.na(mobility_detail_code5_positive) ~ "PFQ061B/C observed and classifiable",
      pfq_younger_no_limitation_skip ~ "age<=59 no-limitation screen; PFQ061 structurally skipped",
      TRUE ~ "unresolved item/nonresponse missing"
    ),
    adl_code5_positive_route_source = dplyr::case_when(
      !is.na(adl_detail_code5_positive) ~ "PFQ061A/F-L observed and classifiable",
      pfq_younger_no_limitation_skip ~ "age<=59 no-limitation screen; PFQ061 structurally skipped",
      TRUE ~ "unresolved item/nonresponse missing"
    )
  )

# Official safety-screen positives. Checkbox variables SPQ070A-C use their
# item number as the affirmative code. Reasons can overlap.
master <- master %>%
  mutate(
    safety_reason_supplemental_oxygen = ENQ010 == 1L,
    safety_reason_deep_breath_problem = ENQ020 == 1L,
    safety_reason_recent_eye_surgery = SPQ030 == 1L,
    safety_reason_recent_chest_abdominal_surgery = SPQ050 == 1L,
    safety_reason_tuberculosis_past_year = SPQ060 == 1L,
    safety_reason_aneurysm = SPQ070A == 1L,
    safety_reason_collapsed_lung = SPQ070B == 2L,
    safety_reason_detached_retina = SPQ070C == 3L,
    safety_reason_recent_stroke = SPQ080 == 1L,
    safety_reason_recent_heart_attack = SPQ090 == 1L,
    safety_reason_coughed_blood = SPQ100 == 1L
  )

safety_reason_cols <- c(
  "safety_reason_supplemental_oxygen",
  "safety_reason_deep_breath_problem",
  "safety_reason_recent_eye_surgery",
  "safety_reason_recent_chest_abdominal_surgery",
  "safety_reason_tuberculosis_past_year",
  "safety_reason_aneurysm",
  "safety_reason_collapsed_lung",
  "safety_reason_detached_retina",
  "safety_reason_recent_stroke",
  "safety_reason_recent_heart_attack",
  "safety_reason_coughed_blood"
)
safety_matrix <- as.matrix(master[, safety_reason_cols])
safety_matrix[is.na(safety_matrix)] <- FALSE
master$safety_any_explicit_positive <- rowSums(safety_matrix) > 0

screen_vars <- c(
  "ENQ010", "ENQ020", "SPQ030", "SPQ050", "SPQ060", "SPQ070A", "SPQ080",
  "SPQ090", "SPQ100"
)
unknown_matrix <- sapply(master[, screen_vars, drop = FALSE], function(x) x %in% c(7, 9, 77, 99))
master$safety_screen_unknown_refused <- rowSums(unknown_matrix, na.rm = TRUE) > 0

# Survey design is built before domains are selected.
design_data <- master %>%
  filter(mec_examined, is.finite(wtmec6yr), wtmec6yr > 0,
         !is.na(design_strata), !is.na(design_psu))
full_design <- survey::svydesign(
  ids = ~design_psu,
  strata = ~design_strata,
  weights = ~wtmec6yr,
  nest = TRUE,
  data = design_data
)

# Cohort flow. Each branch is monotone so independent validation can check
# excluded_from_previous = lag(n) - n.
cohort_flow <- bind_rows(
  count_flag(master, rep(TRUE, nrow(master)), "core", 1, "all_demo", "All DEMO records"),
  count_flag(master, master$age_45_79, "core", 2, "age_45_79", "Age 45-79"),
  count_flag(master, master$age_45_79 & master$mec_examined, "core", 3, "age_45_79_mec", "Age 45-79 and MEC examined"),
  count_flag(master, master$age_45_79 & master$mec_examined & master$mortality_matched,
             "core", 4, "age_45_79_mec_mortality_matched", "Age 45-79, MEC examined, mortality file matched"),
  count_flag(master, master$target_linked, "core", 5, "target_linked", "Age 45-79, MEC examined, ELIGSTAT=1"),
  count_flag(master, master$target_linked & master$status_available,
             "core", 6, "target_linked_status_available", "Target linked with SPXNSTAT available"),
  count_flag(master, master$safe_target, "core", 7, "safe_target", "Target linked without SPXNSTAT=4 safety exclusion"),

  count_flag(master, master$safe_target, "pef_quality", 1, "safe_target", "Safe target denominator"),
  count_flag(master, master$pef_nonmissing, "pef_quality", 2, "pef_nonmissing", "Positive nonmissing SPXNPEF"),
  count_flag(master, master$pef_ABC, "pef_quality", 3, "pef_ABC", "PEF broad layer: SPXNQEFF A/B/C"),
  count_flag(master, master$pef_AC, "pef_quality", 4, "pef_A_plus_C", "PEF duration-relaxed layer: SPXNQEFF A+C"),
  count_flag(master, master$pef_A, "pef_quality", 5, "pef_A_only", "PEF strict primary layer: SPXNQEFF A only"),
  count_flag(master, master$pef_A_acc3, "pef_quality", 6, "pef_A_acc3", "PEF strict sensitivity: SPXNQEFF A and SPDNACC >=3"),

  count_flag(master, master$safe_target, "spirometry_quality", 1, "safe_target", "Safe target denominator"),
  count_flag(master, master$spirometry_raw, "spirometry_quality", 2, "spirometry_raw", "Positive nonmissing PEF, FEV1 and FVC"),
  count_flag(master, master$spirometry_abc, "spirometry_quality", 3, "spirometry_ABC", "FEV1 and FVC quality both A/B/C"),
  count_flag(master, master$spirometry_ab, "spirometry_quality", 4, "spirometry_AB", "FEV1 and FVC quality both A/B")
) %>%
  group_by(flow_branch) %>%
  arrange(step_order, .by_group = TRUE) %>%
  mutate(excluded_from_previous = lag(n) - n) %>%
  ungroup() %>%
  select(flow_branch, step_order, step_id, step_label, n, excluded_from_previous, deaths)

anchor_map <- c(
  target_linked = "target_45_79_mec_mortality_eligible",
  safety_exclusion = "safety_exclusion",
  safe_target = "safe_target",
  pef_nonmissing = "pef_nonmissing",
  pef_A = "pef_A_only",
  pef_A_acc3 = "pef_A_acc3",
  pef_AC = "pef_A_plus_C",
  pef_ABC = "pef_ABC",
  spirometry_abc = "spirometry_ABC",
  spirometry_ab = "spirometry_AB"
)
sample_event_anchors <- bind_rows(lapply(names(anchor_map), function(flag_name) {
  count_by_cycle(master, flag_name, unname(anchor_map[[flag_name]]))
})) %>%
  select(cycle_label, cycle, anchor_id, n, deaths) %>%
  arrange(match(cycle_label, c("ALL", "E", "F", "G")), anchor_id)

# Administrative follow-up audit for the frozen fixed-horizon analyses.  A
# horizon is administratively complete only when every linked survivor in the
# primary A-only PEF layer has at least that many exam-follow-up months.  Deaths
# before the horizon remain observed events; deaths after it are known alive at
# the horizon because their follow-up exceeds the horizon.  This table prevents
# the old outcome-dependent rule that retained early deaths from an otherwise
# incomplete cycle.
followup_horizon_audit <- bind_rows(lapply(c("E", "F", "G"), function(cy) {
  d <- master %>% filter(cycle_label == cy, pef_A, mortality_eligible)
  cycle_text <- unique(d$cycle)[[1]]
  bind_rows(lapply(c(60L, 120L), function(horizon) {
    survivor_followup <- d$PERMTH_EXM[d$death == 0L]
    known_at_horizon <- d$PERMTH_EXM >= horizon |
      (d$death == 1L & d$PERMTH_EXM <= horizon)
    complete <- length(survivor_followup) > 0L &&
      all(is.finite(survivor_followup)) && min(survivor_followup) >= horizon
    role <- dplyr::case_when(
      horizon == 60L ~ "common 5-year horizon allowed",
      horizon == 120L && cy == "E" ~ "10-year main sensitivity allowed",
      TRUE ~ "10-year fixed-horizon analysis prohibited"
    )
    tibble(
      cycle_label = cy,
      cycle = cycle_text,
      quality_layer = "pef_A_only",
      horizon_months = horizon,
      n = nrow(d),
      deaths_total = sum(d$death == 1L),
      deaths_by_horizon = sum(d$death == 1L & d$PERMTH_EXM <= horizon),
      survivors_n = sum(d$death == 0L),
      survivor_followup_min_months = min(survivor_followup),
      survivor_followup_median_months = stats::median(survivor_followup),
      survivor_followup_max_months = max(survivor_followup),
      known_status_n = sum(known_at_horizon),
      known_status_fraction = mean(known_at_horizon),
      administratively_complete = complete,
      prespecified_role = role
    )
  }))
}))

# Descriptive selection contrast within the structurally safe target. This is
# not an association model and does not repair missing PEF; it documents why
# Stage 4 must distinguish the strict PEF-observed estimand from the full safe
# target population.
pef_observation_contrast <- append_all_cycle(master %>% filter(safe_target)) %>%
  mutate(observation_group = ifelse(pef_A, "A-only PEF observed", "not in A-only layer")) %>%
  group_by(cycle_label, cycle, observation_group) %>%
  summarise(
    n = n(),
    deaths = sum(death == 1L),
    weighted_population = sum(wtmec6yr),
    weighted_death_fraction = sum(wtmec6yr * (death == 1L)) / sum(wtmec6yr),
    .groups = "drop"
  ) %>%
  arrange(match(cycle_label, c("ALL", "E", "F", "G")), observation_group)

target_linked <- master %>% filter(target_linked)
status_comment <- append_all_cycle(target_linked) %>%
  mutate(
    status_code = SPXNSTAT,
    status_label = status_label(SPXNSTAT),
    comment_code = ifelse(is.na(SPXNCMT), NA_integer_, as.integer(SPXNCMT)),
    comment_label = comment_label(SPXNCMT)
  ) %>%
  group_by(cycle_label, cycle, status_code, status_label, comment_code, comment_label) %>%
  summarise(n = n(), deaths = sum(death == 1L, na.rm = TRUE), .groups = "drop") %>%
  group_by(cycle_label) %>%
  mutate(percent_of_target_linked = 100 * n / sum(n)) %>%
  ungroup() %>%
  arrange(match(cycle_label, c("ALL", "E", "F", "G")), status_code, comment_code)

safety_reason_definitions <- tribble(
  ~reason_id, ~reason_label, ~flag_name,
  "supplemental_oxygen", "Requires supplemental oxygen", "safety_reason_supplemental_oxygen",
  "deep_breath_problem", "Pain/problem preventing forceful expiration", "safety_reason_deep_breath_problem",
  "recent_eye_surgery", "Eye surgery in previous 3 months", "safety_reason_recent_eye_surgery",
  "recent_chest_abdominal_surgery", "Open chest/abdominal surgery in previous 3 months", "safety_reason_recent_chest_abdominal_surgery",
  "tuberculosis_past_year", "Tuberculosis exposure/history in previous year", "safety_reason_tuberculosis_past_year",
  "aneurysm", "History of aneurysm", "safety_reason_aneurysm",
  "collapsed_lung", "History of collapsed lung", "safety_reason_collapsed_lung",
  "detached_retina", "History of detached retina", "safety_reason_detached_retina",
  "recent_stroke", "Stroke in previous 3 months", "safety_reason_recent_stroke",
  "recent_heart_attack", "Heart attack in previous 3 months", "safety_reason_recent_heart_attack",
  "coughed_blood", "Coughed up blood in previous month", "safety_reason_coughed_blood",
  "screen_unknown_refused", "Unknown/refused response in a gating screen", "safety_screen_unknown_refused",
  "any_explicit_positive", "At least one explicit positive safety reason", "safety_any_explicit_positive"
)
safety_data <- master %>% filter(safety_exclusion)
safety_reasons <- bind_rows(lapply(c("ALL", "E", "F", "G"), function(cy) {
  d <- if (cy == "ALL") safety_data else safety_data %>% filter(cycle_label == cy)
  cycle_text <- if (cy == "ALL") "2007-2012 pooled" else unique(d$cycle)[[1]]
  denom <- nrow(d)
  bind_rows(lapply(seq_len(nrow(safety_reason_definitions)), function(i) {
    f <- d[[safety_reason_definitions$flag_name[[i]]]]
    tibble(
      cycle_label = cy,
      cycle = cycle_text,
      reason_id = safety_reason_definitions$reason_id[[i]],
      reason_label = safety_reason_definitions$reason_label[[i]],
      n = sum(f, na.rm = TRUE),
      deaths = sum(d$death[f] == 1L, na.rm = TRUE),
      safety_exclusion_denominator = denom,
      percent_of_safety_excluded = 100 * sum(f, na.rm = TRUE) / denom
    )
  })) %>%
    bind_rows(tibble(
      cycle_label = cy,
      cycle = cycle_text,
      reason_id = "no_explicit_positive",
      reason_label = "No explicit positive reason reconstructed from released screening fields",
      n = sum(!d$safety_any_explicit_positive),
      deaths = sum(d$death[!d$safety_any_explicit_positive] == 1L, na.rm = TRUE),
      safety_exclusion_denominator = denom,
      percent_of_safety_excluded = 100 * sum(!d$safety_any_explicit_positive) / denom
    ))
}))

pef_quality_layers <- tribble(
  ~flag_name, ~layer_id, ~definition,
  "pef_nonmissing", "pef_nonmissing", "Positive nonmissing SPXNPEF",
  "pef_A", "pef_A_only", "SPXNPEF present and SPXNQEFF=A",
  "pef_A_acc3", "pef_A_acc3", "SPXNPEF present, SPXNQEFF=A and SPDNACC >=3",
  "pef_AC", "pef_A_plus_C", "SPXNPEF present and SPXNQEFF=A or C",
  "pef_ABC", "pef_ABC", "SPXNPEF present and SPXNQEFF=A, B or C",
  "pef_B_only", "pef_B_only", "SPXNPEF present and SPXNQEFF=B",
  "pef_C_only", "pef_C_only", "SPXNPEF present and SPXNQEFF=C",
  "pef_blank_with_value", "pef_value_quality_blank", "SPXNPEF present but SPXNQEFF blank",
  "effort_present_pef_missing", "effort_quality_but_pef_missing", "SPXNQEFF present but SPXNPEF missing"
)
pef_quality <- bind_rows(lapply(seq_len(nrow(pef_quality_layers)), function(i) {
  summarise_quality_flag(
    master,
    pef_quality_layers$flag_name[[i]],
    pef_quality_layers$layer_id[[i]],
    pef_quality_layers$definition[[i]]
  )
}))

spirometry_layers <- tribble(
  ~flag_name, ~layer_id, ~definition,
  "spirometry_raw", "spirometry_raw", "Positive nonmissing PEF, FEV1 and FVC",
  "spirometry_abc", "spirometry_ABC", "FEV1 and FVC quality both A/B/C",
  "spirometry_ab", "spirometry_AB", "FEV1 and FVC quality both A/B",
  "status_complete", "status_complete", "SPXNSTAT=1 complete exam",
  "status_partial", "status_partial", "SPXNSTAT=2 partial exam",
  "status_not_done", "status_not_done", "SPXNSTAT=3 eligible but not done"
)
spirometry_quality <- bind_rows(lapply(seq_len(nrow(spirometry_layers)), function(i) {
  summarise_quality_flag(
    master,
    spirometry_layers$flag_name[[i]],
    spirometry_layers$layer_id[[i]],
    spirometry_layers$definition[[i]]
  )
}))

pooled_safe_weight <- sum(master$wtmec6yr[master$safe_target], na.rm = TRUE)
contract_defs <- tribble(
  ~layer_id, ~domain, ~definition, ~source_variables, ~unit_rule, ~flag_name, ~frozen_role,
  "safe_target", "eligibility", "Age 45-79, MEC examined, ELIGSTAT=1, SPXNSTAT 1/2/3", "RIDAGEYR;RIDSTATR;WTMEC2YR;ELIGSTAT;SPXNSTAT", "not applicable", "safe_target", "observation-IPW target denominator",
  "pef_A_only", "PEF", "Positive SPXNPEF and SPXNQEFF=A", "SPXNPEF;SPXNQEFF", "L/min = mL/s * 0.06", "pef_A", "strict primary PEF-quality layer",
  "pef_A_acc3", "PEF", "Positive SPXNPEF, SPXNQEFF=A and SPDNACC >=3", "SPXNPEF;SPXNQEFF;SPDNACC", "L/min = mL/s * 0.06", "pef_A_acc3", "prespecified acceptable-curve sensitivity",
  "pef_A_plus_C", "PEF", "Positive SPXNPEF and SPXNQEFF=A or C", "SPXNPEF;SPXNQEFF", "L/min = mL/s * 0.06", "pef_AC", "duration-relaxed sensitivity",
  "pef_ABC", "PEF", "Positive SPXNPEF and SPXNQEFF=A, B or C", "SPXNPEF;SPXNQEFF", "L/min = mL/s * 0.06", "pef_ABC", "broad sensitivity only",
  "spirometry_ABC", "full spirometry", "Positive PEF/FEV1/FVC and both FEV1/FVC quality attributes A/B/C", "SPXNPEF;SPXNFEV1;SPXNFVC;SPXNQFV1;SPXNQFVC", "FEV1/FVC use common mL units", "spirometry_abc", "complete usable spirometry",
  "spirometry_AB", "full spirometry", "Positive PEF/FEV1/FVC and both FEV1/FVC quality attributes A/B", "SPXNPEF;SPXNFEV1;SPXNFVC;SPXNQFV1;SPXNQFVC", "FEV1/FVC use common mL units", "spirometry_ab", "strict FEV1/FVC sensitivity"
)
measurement_contract <- bind_rows(lapply(seq_len(nrow(contract_defs)), function(i) {
  f <- master[[contract_defs$flag_name[[i]]]]
  tibble(
    layer_id = contract_defs$layer_id[[i]],
    domain = contract_defs$domain[[i]],
    definition = contract_defs$definition[[i]],
    source_variables = contract_defs$source_variables[[i]],
    unit_rule = contract_defs$unit_rule[[i]],
    frozen_role = contract_defs$frozen_role[[i]],
    n = sum(f, na.rm = TRUE),
    deaths = sum(master$death[f] == 1L, na.rm = TRUE),
    weighted_fraction_of_safe_target = if (contract_defs$layer_id[[i]] == "safe_target") 1 else
      sum(master$wtmec6yr[f], na.rm = TRUE) / pooled_safe_weight
  )
}))

measurement_populations <- list(
  pef_nonmissing = c("pef_l_min", "acceptable_curves"),
  pef_A = c("pef_l_min", "acceptable_curves"),
  pef_A_acc3 = c("pef_l_min", "acceptable_curves"),
  pef_AC = c("pef_l_min", "acceptable_curves"),
  pef_ABC = c("pef_l_min", "acceptable_curves"),
  spirometry_abc = c("pef_l_min", "fev1_l", "fvc_l", "fev1_fvc", "acceptable_curves"),
  spirometry_ab = c("pef_l_min", "fev1_l", "fvc_l", "fev1_fvc", "acceptable_curves")
)
variable_labels <- c(
  pef_l_min = "PEF (L/min)",
  fev1_l = "FEV1 (L)",
  fvc_l = "FVC (L)",
  fev1_fvc = "FEV1/FVC",
  acceptable_curves = "Number of acceptable curves"
)
master$acceptable_curves <- as.numeric(master$SPDNACC)
measurement_summary <- bind_rows(lapply(names(measurement_populations), function(pop) {
  bind_rows(lapply(measurement_populations[[pop]], function(v) {
    measurement_summary_one(master, pop, pop, v, variable_labels[[v]])
  }))
}))

measurement_correlations <- bind_rows(
  correlation_rows(master, "pef_A", "pef_A_only"),
  correlation_rows(master, "pef_AC", "pef_A_plus_C"),
  correlation_rows(master, "pef_ABC", "pef_ABC")
)

# Machine-readable logical and physiological anomaly counts. Physiological
# tail flags are descriptive only and do not trigger exclusion or a hard gate.
measurement_anomalies <- bind_rows(
  anomaly_rows(master, master$age_gt_79 & !is.na(master$SPXNSTAT),
               "age_gt79_with_spx_status", "Age >79 has nonmissing SPXNSTAT", "all DEMO", TRUE, 0),
  anomaly_rows(master, master$age_gt_79 & is.finite(master$SPXNPEF),
               "age_gt79_with_pef", "Age >79 has nonmissing SPXNPEF", "all DEMO", TRUE, 0),
  anomaly_rows(master, master$target_linked & !master$status_available,
               "target_linked_status_missing", "Target-linked record lacks SPXNSTAT", "target linked", TRUE, 0),
  anomaly_rows(master, master$safety_exclusion & is.finite(master$SPXNPEF),
               "safety_exclusion_with_pef", "SPXNSTAT=4 record has PEF", "target linked", TRUE, 0),
  anomaly_rows(master, master$status_not_done & is.finite(master$SPXNPEF),
               "not_done_with_pef", "SPXNSTAT=3 record has PEF", "safe target", TRUE, 0),
  anomaly_rows(master, !is.na(master$SPXNSTAT) & (is.na(master$SPXNPEF) != is.na(master$SPXNFEV1)),
               "pef_fev1_missingness_mismatch", "PEF and FEV1 missingness differ", "SPX target rows", TRUE, 0),
  anomaly_rows(master, !is.na(master$SPXNSTAT) & (is.na(master$SPXNPEF) != is.na(master$SPXNFVC)),
               "pef_fvc_missingness_mismatch", "PEF and FVC missingness differ", "SPX target rows", TRUE, 0),
  anomaly_rows(master, master$status_complete != master$spirometry_abc,
               "complete_status_spiro_abc_mismatch", "SPXNSTAT=1 differs from both FEV1/FVC A/B/C rule", "safe target", TRUE, 0),
  anomaly_rows(master, master$spirometry_raw & master$SPXNFEV1 > master$SPXNFVC,
               "fev1_greater_than_fvc", "FEV1 exceeds FVC", "spirometry raw", TRUE, 0),
  anomaly_rows(master, master$spirometry_raw & (!is.finite(master$fev1_fvc) | master$fev1_fvc <= 0 | master$fev1_fvc > 1),
               "fev1_fvc_outside_0_1", "FEV1/FVC outside (0,1]", "spirometry raw", TRUE, 0),
  anomaly_rows(master, master$safe_target & is.finite(master$pef_l_min) & master$pef_l_min <= 0,
               "pef_nonpositive", "PEF <=0 L/min", "safe target", TRUE, 0),
  anomaly_rows(master, master$pef_nonmissing & master$pef_l_min < 30,
               "pef_below_30", "PEF <30 L/min; descriptive tail flag only", "PEF nonmissing", FALSE),
  anomaly_rows(master, master$pef_nonmissing & master$pef_l_min > 900,
               "pef_above_900", "PEF >900 L/min; descriptive tail flag only", "PEF nonmissing", FALSE),
  anomaly_rows(master, master$pef_blank_with_value,
               "pef_value_effort_blank", "PEF present but SPXNQEFF blank", "safe target", FALSE),
  anomaly_rows(master, master$safe_target & master$pef_effort_quality == "A" & !is.finite(master$SPXNPEF),
               "effort_A_pef_missing", "SPXNQEFF=A but summary PEF missing", "safe target", FALSE),
  anomaly_rows(master, master$pef_A & is.finite(master$SPDNACC) & master$SPDNACC < 3,
               "pef_A_fewer_than_3_acceptable_curves", "PEF A-only with fewer than 3 acceptable curves", "PEF A-only", FALSE)
)

# Outcome-blind sex-specific E0 scale parameters, estimated by survey domain.
e0_layers <- tribble(
  ~quality_layer, ~flag_name,
  "pef_A_only", "pef_A",
  "pef_A_plus_C", "pef_AC",
  "pef_ABC", "pef_ABC"
)
e0_scale <- bind_rows(lapply(seq_len(nrow(e0_layers)), function(i) {
  bind_rows(lapply(c(1L, 2L), function(sex_code) {
    flag_name <- e0_layers$flag_name[[i]]
    rows <- design_data[[flag_name]] & design_data$RIAGENDR == sex_code
    rows[is.na(rows)] <- FALSE
    domain <- full_design[rows, ]
    mean_obj <- survey::svymean(~pef_l_min, design = domain, na.rm = TRUE)
    var_obj <- survey::svyvar(~pef_l_min, design = domain, na.rm = TRUE)
    x <- design_data$pef_l_min[rows]
    w <- design_data$wtmec6yr[rows]
    tibble(
      quality_layer = e0_layers$quality_layer[[i]],
      sex_code = sex_code,
      sex = ifelse(sex_code == 1L, "male", "female"),
      n = sum(rows, na.rm = TRUE),
      weighted_mean_l_min = as.numeric(coef(mean_obj)[[1]]),
      se_weighted_mean = as.numeric(survey::SE(mean_obj)[[1]]),
      weighted_sd_l_min = sqrt(as.numeric(coef(var_obj)[[1]])),
      unweighted_mean_l_min = mean(x, na.rm = TRUE),
      unweighted_sd_l_min = stats::sd(x, na.rm = TRUE),
      sum_mec6yr_weights = sum(w, na.rm = TRUE),
      kish_ess = kish_ess(w),
      e0_formula = "(sex-specific weighted mean PEF - individual PEF) / sex-specific weighted SD",
      e0_direction = "higher E0 means lower raw PEF",
      outcome_scaling_role = ifelse(
        e0_layers$quality_layer[[i]] == "pef_A_only",
        "PRIMARY constants; reuse unchanged for A+C and A/B/C outcome sensitivities",
        "descriptive diagnostic only; do not rescale quality-sensitivity outcome models"
      ),
      e0b_physical_scale = "per 100 L/min lower raw PEF"
    )
  }))
}))

# Survey design audit, including non-overlapping public stratum codes.
design_pairs <- design_data %>% distinct(cycle_label, SDMVSTRA, SDMVPSU)
design_stratum_counts <- design_pairs %>%
  count(cycle_label, SDMVSTRA, name = "n_psu")
design_by_cycle <- design_pairs %>%
  group_by(cycle_label) %>%
  summarise(
    n_strata = n_distinct(SDMVSTRA),
    n_stratum_psu = n(),
    design_df = n_stratum_psu - n_strata,
    strata_min = min(SDMVSTRA),
    strata_max = max(SDMVSTRA),
    .groups = "drop"
  ) %>%
  left_join(
    design_stratum_counts %>%
      group_by(cycle_label) %>%
      summarise(lonely_strata = sum(n_psu < 2L), .groups = "drop"),
    by = "cycle_label"
  )
shared_strata_ef <- length(intersect(
  unique(design_data$SDMVSTRA[design_data$cycle_label == "E"]),
  unique(design_data$SDMVSTRA[design_data$cycle_label == "F"])
))
shared_strata_eg <- length(intersect(
  unique(design_data$SDMVSTRA[design_data$cycle_label == "E"]),
  unique(design_data$SDMVSTRA[design_data$cycle_label == "G"])
))
shared_strata_fg <- length(intersect(
  unique(design_data$SDMVSTRA[design_data$cycle_label == "F"]),
  unique(design_data$SDMVSTRA[design_data$cycle_label == "G"])
))
survey_design_audit <- bind_rows(
  tibble(metric = "all_demo_n", cycle_label = "ALL", value_numeric = nrow(master), expected = 30442, pass = nrow(master) == 30442, detail = "All DEMO rows"),
  tibble(metric = "mec_examined_n", cycle_label = "ALL", value_numeric = nrow(design_data), expected = 29353, pass = nrow(design_data) == 29353, detail = "RIDSTATR=2 and positive WTMEC2YR"),
  tibble(metric = "ridstatr_weight_mismatch_n", cycle_label = "ALL", value_numeric = sum((master$RIDSTATR == 2L) != (master$WTMEC2YR > 0), na.rm = TRUE), expected = 0, pass = value_numeric == expected, detail = "MEC status versus positive MEC weight"),
  tibble(metric = "wtmec6yr_formula_max_abs_diff", cycle_label = "ALL", value_numeric = max(abs(master$wtmec6yr - master$WTMEC2YR / 3), na.rm = TRUE), expected = 0, pass = value_numeric == expected, detail = "WTMEC6YR=WTMEC2YR/3"),
  tibble(metric = "pooled_strata_n", cycle_label = "ALL", value_numeric = n_distinct(design_data$design_strata), expected = 45, pass = value_numeric == expected, detail = "Cycle-specific public strata"),
  tibble(metric = "pooled_stratum_psu_n", cycle_label = "ALL", value_numeric = n_distinct(design_data$design_psu), expected = 94, pass = value_numeric == expected, detail = "Cycle-stratum-PSU identifiers"),
  tibble(metric = "survey_design_df", cycle_label = "ALL", value_numeric = survey::degf(full_design), expected = 49, pass = value_numeric == expected, detail = "degf(full MEC design)"),
  tibble(metric = "pef_A_domain_strata_n", cycle_label = "ALL", value_numeric = n_distinct(design_data$design_strata[design_data$pef_A]), expected = 45, pass = value_numeric == expected, detail = "A-only primary domain retains all strata"),
  tibble(metric = "pef_A_domain_psu_n", cycle_label = "ALL", value_numeric = n_distinct(design_data$design_psu[design_data$pef_A]), expected = 94, pass = value_numeric == expected, detail = "A-only primary domain retains all PSU"),
  tibble(metric = "shared_strata_E_F", cycle_label = "ALL", value_numeric = shared_strata_ef, expected = 0, pass = value_numeric == expected, detail = "Raw SDMVSTRA code reuse"),
  tibble(metric = "shared_strata_E_G", cycle_label = "ALL", value_numeric = shared_strata_eg, expected = 0, pass = value_numeric == expected, detail = "Raw SDMVSTRA code reuse"),
  tibble(metric = "shared_strata_F_G", cycle_label = "ALL", value_numeric = shared_strata_fg, expected = 0, pass = value_numeric == expected, detail = "Raw SDMVSTRA code reuse"),
  design_by_cycle %>% transmute(metric = "cycle_strata_n", cycle_label, value_numeric = n_strata, expected = c(E = 16, F = 15, G = 14)[cycle_label], pass = value_numeric == expected, detail = paste0("range ", strata_min, "-", strata_max)),
  design_by_cycle %>% transmute(metric = "cycle_stratum_psu_n", cycle_label, value_numeric = n_stratum_psu, expected = c(E = 32, F = 31, G = 31)[cycle_label], pass = value_numeric == expected, detail = paste0("cycle design df=", design_df)),
  design_by_cycle %>% transmute(metric = "cycle_lonely_strata_n", cycle_label, value_numeric = lonely_strata, expected = 0, pass = value_numeric == expected, detail = "Strata with fewer than 2 PSU")
) %>%
  mutate(value_text = as.character(value_numeric), expected = as.character(expected)) %>%
  select(metric, cycle_label, value_numeric, value_text, expected, pass, detail)

gate1 <- bind_rows(
  gate_row("demo_unique_seqn", sum(duplicated(demo$SEQN)) == 0, sum(duplicated(demo$SEQN)), 0),
  gate_row("spx_unique_seqn", sum(duplicated(spx$SEQN)) == 0, sum(duplicated(spx$SEQN)), 0),
  gate_row("mortality_unique_seqn", sum(duplicated(mortality$SEQN)) == 0, sum(duplicated(mortality$SEQN)), 0),
  gate_row("spx_all_match_demo", all(spx$SEQN %in% demo$SEQN), sum(!spx$SEQN %in% demo$SEQN), 0),
  gate_row("mortality_all_match_demo", all(mortality$SEQN %in% demo$SEQN), sum(!mortality$SEQN %in% demo$SEQN), 0),
  gate_row("all_demo_match_mortality", all(demo$SEQN %in% mortality$SEQN), sum(!demo$SEQN %in% mortality$SEQN), 0),
  gate_row("cycle_code_matches_suffix", all(master$cycle_label == master$cycle_expected), sum(master$cycle_label != master$cycle_expected), 0),
  gate_row("ridstatr_matches_positive_mec_weight", all((master$RIDSTATR == 2L) == (master$WTMEC2YR > 0)), sum((master$RIDSTATR == 2L) != (master$WTMEC2YR > 0)), 0),
  gate_row("age45_79_mec_anchor", sum(master$age_45_79 & master$mec_examined) == 8763, sum(master$age_45_79 & master$mec_examined), 8763),
  gate_row("target_linked_anchor", sum(master$target_linked) == 8750, sum(master$target_linked), 8750),
  gate_row("safety_exclusion_anchor", sum(master$safety_exclusion) == 824, sum(master$safety_exclusion), 824),
  gate_row("safe_target_anchor", sum(master$safe_target) == 7926, sum(master$safe_target), 7926),
  gate_row("safe_target_death_anchor", sum(master$death[master$safe_target] == 1L) == 1228, sum(master$death[master$safe_target] == 1L), 1228),
  gate_row("positive_exam_followup_in_target", all(master$PERMTH_EXM[master$target_linked] > 0), sum(master$PERMTH_EXM[master$target_linked] <= 0 | is.na(master$PERMTH_EXM[master$target_linked])), 0),
  gate_row("age_gt79_structural_spx_absence", all(is.na(master$SPXNSTAT[master$age_gt_79]) & is.na(master$SPXNPEF[master$age_gt_79])), sum(!is.na(master$SPXNSTAT[master$age_gt_79]) | !is.na(master$SPXNPEF[master$age_gt_79])), 0),
  gate_row("survey_design_df", survey::degf(full_design) == 49, survey::degf(full_design), 49),
  gate_row(
    "five_year_administrative_completeness_all_cycles",
    all(followup_horizon_audit$administratively_complete[followup_horizon_audit$horizon_months == 60L]),
    paste(followup_horizon_audit$cycle_label[followup_horizon_audit$horizon_months == 60L],
          followup_horizon_audit$administratively_complete[followup_horizon_audit$horizon_months == 60L], sep = "=", collapse = ";"),
    "E=TRUE;F=TRUE;G=TRUE"
  ),
  gate_row(
    "ten_year_administrative_completeness_cycle_E_only",
    isTRUE(followup_horizon_audit$administratively_complete[
      followup_horizon_audit$cycle_label == "E" & followup_horizon_audit$horizon_months == 120L
    ]) && all(!followup_horizon_audit$administratively_complete[
      followup_horizon_audit$cycle_label %in% c("F", "G") & followup_horizon_audit$horizon_months == 120L
    ]),
    paste(followup_horizon_audit$cycle_label[followup_horizon_audit$horizon_months == 120L],
          followup_horizon_audit$administratively_complete[followup_horizon_audit$horizon_months == 120L], sep = "=", collapse = ";"),
    "E=TRUE;F=FALSE;G=FALSE"
  )
)

gate2 <- bind_rows(
  gate_row("pef_conversion_multiplier_frozen", identical(as.numeric(spec$nhanes$measurement$conversion_multiplier), 0.06), spec$nhanes$measurement$conversion_multiplier, 0.06),
  gate_row("pef_fev1_missingness_synchronized", all(is.na(spx$SPXNPEF) == is.na(spx$SPXNFEV1)), sum(is.na(spx$SPXNPEF) != is.na(spx$SPXNFEV1)), 0),
  gate_row("pef_fvc_missingness_synchronized", all(is.na(spx$SPXNPEF) == is.na(spx$SPXNFVC)), sum(is.na(spx$SPXNPEF) != is.na(spx$SPXNFVC)), 0),
  gate_row("complete_status_equals_spirometry_abc", all(master$status_complete == master$spirometry_abc), sum(master$status_complete != master$spirometry_abc), 0),
  gate_row("safety_exclusion_has_no_pef", all(is.na(master$SPXNPEF[master$safety_exclusion])), sum(!is.na(master$SPXNPEF[master$safety_exclusion])), 0),
  gate_row("not_done_has_no_pef", all(is.na(master$SPXNPEF[master$status_not_done])), sum(!is.na(master$SPXNPEF[master$status_not_done])), 0),
  gate_row("pef_A_anchor", sum(master$pef_A) == 6719, sum(master$pef_A), 6719),
  gate_row("pef_A_death_anchor", sum(master$death[master$pef_A] == 1L) == 925, sum(master$death[master$pef_A] == 1L), 925),
  gate_row("pef_A_plus_C_anchor", sum(master$pef_AC) == 6971, sum(master$pef_AC), 6971),
  gate_row("pef_A_plus_C_death_anchor", sum(master$death[master$pef_AC] == 1L) == 967, sum(master$death[master$pef_AC] == 1L), 967),
  gate_row("pef_ABC_anchor", sum(master$pef_ABC) == 7083, sum(master$pef_ABC), 7083),
  gate_row("pef_ABC_death_anchor", sum(master$death[master$pef_ABC] == 1L) == 989, sum(master$death[master$pef_ABC] == 1L), 989),
  gate_row("spirometry_ABC_anchor", sum(master$spirometry_abc) == 6776, sum(master$spirometry_abc), 6776),
  gate_row("spirometry_AB_anchor", sum(master$spirometry_ab) == 6020, sum(master$spirometry_ab), 6020),
  gate_row("pef_quality_hierarchy_A_in_AC", all(!master$pef_A | master$pef_AC), sum(master$pef_A & !master$pef_AC), 0),
  gate_row("pef_quality_hierarchy_A_acc3_in_A", all(!master$pef_A_acc3 | master$pef_A), sum(master$pef_A_acc3 & !master$pef_A), 0),
  gate_row("pef_quality_hierarchy_AC_in_ABC", all(!master$pef_AC | master$pef_ABC), sum(master$pef_AC & !master$pef_ABC), 0),
  gate_row("B_excluded_from_strict_pef_layer", all(!(master$pef_A & master$pef_effort_quality == "B")), sum(master$pef_A & master$pef_effort_quality == "B"), 0),
  gate_row("hard_measurement_anomalies_zero", all(measurement_anomalies$pass[measurement_anomalies$hard_assertion]), sum(!measurement_anomalies$pass[measurement_anomalies$hard_assertion]), 0),
  gate_row("pef_A_retains_all_design_strata", n_distinct(design_data$design_strata[design_data$pef_A]) == 45, n_distinct(design_data$design_strata[design_data$pef_A]), 45),
  gate_row("pef_A_retains_all_design_psu", n_distinct(design_data$design_psu[design_data$pef_A]) == 94, n_distinct(design_data$design_psu[design_data$pef_A]), 94)
)

function_routing_audit <- bind_rows(
  master %>%
    filter(pef_A) %>%
    transmute(
      coding_variant = "main_code5_missing",
      route_component = "mobility",
      route_source = mobility_route_source
    ) %>%
    count(coding_variant, route_component, route_source, name = "n"),
  master %>%
    filter(pef_A) %>%
    transmute(
      coding_variant = "main_code5_missing",
      route_component = "adl_iadl",
      route_source = adl_route_source
    ) %>%
    count(coding_variant, route_component, route_source, name = "n"),
  master %>%
    filter(pef_A) %>%
    transmute(
      coding_variant = "sensitivity_code5_positive",
      route_component = "mobility",
      route_source = mobility_code5_positive_route_source
    ) %>%
    count(coding_variant, route_component, route_source, name = "n"),
  master %>%
    filter(pef_A) %>%
    transmute(
      coding_variant = "sensitivity_code5_positive",
      route_component = "adl_iadl",
      route_source = adl_code5_positive_route_source
    ) %>%
    count(coding_variant, route_component, route_source, name = "n")
) %>%
  mutate(
    primary_A_n = sum(master$pef_A),
    rule = dplyr::case_when(
      coding_variant == "main_code5_missing" & route_component == "mobility" ~
        "PFQ054=1 is positive; PFQ061B/C codes 2-4 are positive, code 1 negative, code 5/7/9 missing; age<=59 official structural skip is zero",
      coding_variant == "main_code5_missing" ~
        "PFQ061A/F-L codes 2-4 are positive, code 1 negative, code 5/7/9 missing; age<=59 official structural skip is zero",
      route_component == "mobility" ~
        "Sensitivity: PFQ054=1 or PFQ061B/C codes 2-5 are positive; age<=59 official structural skip is zero",
      TRUE ~
        "Sensitivity: PFQ061A/F-L codes 2-5 are positive; age<=59 official structural skip is zero"
    )
  )

gate2 <- bind_rows(
  gate2,
  gate_row(
    "pfq_equipment_skip_is_mobility_positive",
    all(master$mobility_difficulty_routed[master$PFQ054 == 1L] == 1L, na.rm = TRUE),
    sum(master$PFQ054 == 1L & master$mobility_difficulty_routed != 1L, na.rm = TRUE),
    0,
    "PFQ061B/C are suppressed when PFQ054 already establishes walking difficulty."
  ),
  gate_row(
    "pfq_younger_no_limitation_skip_is_zero",
    all(
      master$mobility_difficulty_routed[master$pfq_younger_no_limitation_skip] == 0L &
        master$adl_iadl_difficulty_routed[master$pfq_younger_no_limitation_skip] == 0L,
      na.rm = TRUE
    ),
    sum(
      master$pfq_younger_no_limitation_skip &
        (master$mobility_difficulty_routed != 0L | master$adl_iadl_difficulty_routed != 0L),
      na.rm = TRUE
    ),
    0,
    "Age<=59 participants routed past PFQ061 after all-negative screens are deterministic zero, not missing."
  ),
  gate_row(
    "pef_A_route_aware_mobility_observed_anchor",
    sum(master$pef_A & !is.na(master$mobility_difficulty_routed)) == 6681L,
    sum(master$pef_A & !is.na(master$mobility_difficulty_routed)),
    6681,
    "Main rule treats PFQ061 code 5 and incomplete B/C responses as missing."
  ),
  gate_row(
    "pef_A_route_aware_adl_observed_anchor",
    sum(master$pef_A & !is.na(master$adl_iadl_difficulty_routed)) == 6557L,
    sum(master$pef_A & !is.na(master$adl_iadl_difficulty_routed)),
    6557,
    "Main rule treats PFQ061 code 5 and incomplete A/F-L responses as missing."
  ),
  gate_row(
    "pef_A_code5_positive_mobility_observed_anchor",
    sum(master$pef_A & !is.na(master$mobility_difficulty_code5_positive)) == 6715L,
    sum(master$pef_A & !is.na(master$mobility_difficulty_code5_positive)),
    6715,
    "Prespecified sensitivity codes PFQ061 response 5 as difficulty-positive."
  ),
  gate_row(
    "pef_A_code5_positive_adl_observed_anchor",
    sum(master$pef_A & !is.na(master$adl_iadl_difficulty_code5_positive)) == 6717L,
    sum(master$pef_A & !is.na(master$adl_iadl_difficulty_code5_positive)),
    6717,
    "Prespecified sensitivity codes PFQ061 response 5 as difficulty-positive."
  ),
  gate_row(
    "pef_A_code5_mobility_classification_delta_anchor",
    sum(
      master$pef_A &
        is.na(master$mobility_difficulty_routed) &
        master$mobility_difficulty_code5_positive == 1L,
      na.rm = TRUE
    ) == 34L,
    sum(
      master$pef_A &
        is.na(master$mobility_difficulty_routed) &
        master$mobility_difficulty_code5_positive == 1L,
      na.rm = TRUE
    ),
    34,
    "Participants whose mobility classification depends on treating response 5 as positive."
  ),
  gate_row(
    "pef_A_code5_adl_classification_delta_anchor",
    sum(
      master$pef_A &
        is.na(master$adl_iadl_difficulty_routed) &
        master$adl_iadl_difficulty_code5_positive == 1L,
      na.rm = TRUE
    ) == 160L,
    sum(
      master$pef_A &
        is.na(master$adl_iadl_difficulty_routed) &
        master$adl_iadl_difficulty_code5_positive == 1L,
      na.rm = TRUE
    ),
    160,
    "Participants whose ADL/IADL classification depends on treating response 5 as positive."
  )
)

common_sample_audit <- bind_rows(
  tibble(
    sample_id = "pef_A_only",
    definition = "SPXNQEFF=A and positive SPXNPEF",
    n = sum(master$pef_A),
    deaths = sum(master$death[master$pef_A] == 1L)
  ),
  tibble(
    sample_id = "spirometry_ABC",
    definition = "positive PEF/FEV1/FVC with FEV1 and FVC quality A/B/C",
    n = sum(master$spirometry_abc),
    deaths = sum(master$death[master$spirometry_abc] == 1L)
  ),
  tibble(
    sample_id = "pef_A_x_spirometry_ABC",
    definition = "measurement-only common sample for later nested PEF versus full-spirometry comparisons",
    n = sum(master$pef_A & master$spirometry_abc),
    deaths = sum(master$death[master$pef_A & master$spirometry_abc] == 1L)
  )
)

gate2 <- bind_rows(
  gate2,
  gate_row(
    "pef_A_x_spirometry_ABC_common_sample_anchor",
    common_sample_audit$n[common_sample_audit$sample_id == "pef_A_x_spirometry_ABC"] == 6540 &&
      common_sample_audit$deaths[common_sample_audit$sample_id == "pef_A_x_spirometry_ABC"] == 885,
    paste0(
      common_sample_audit$n[common_sample_audit$sample_id == "pef_A_x_spirometry_ABC"], "/",
      common_sample_audit$deaths[common_sample_audit$sample_id == "pef_A_x_spirometry_ABC"]
    ),
    "6540/885",
    "Measurement-only common sample; later covariate completeness may reduce it but nested models must remain common-sample."
  )
)

# Contract-authorized row-level machine ledger. This is deliberately kept out
# of results/ and logs/; it contains no fitted values or model results.
ledger <- master %>%
  select(
    SEQN, cycle_label, cycle, SDDSRVYR,
    RIDAGEYR, RIAGENDR, RIDRETH1, RIDSTATR,
    WTMEC2YR, wtmec6yr, SDMVSTRA, SDMVPSU, design_strata, design_psu,
    ELIGSTAT, MORTSTAT, PERMTH_INT, PERMTH_EXM, mortality_matched,
    mortality_eligible, death,
    SPXNSTAT, SPXNCMT, SPXNPEF, SPXNFEV1, SPXNFVC,
    SPXNQEFF, SPXNQFVC, SPXNQFV1, SPDNACC,
    pef_l_min, fev1_l, fvc_l, fev1_fvc, acceptable_curves,
    age_45_79, age_gt_79, mec_examined, status_available,
    target_linked, safety_exclusion, safe_target,
    pef_effort_quality, fvc_quality, fev1_quality,
    pef_nonmissing, pef_A, pef_A_acc3, pef_AC, pef_ABC, pef_B_only, pef_C_only,
    pef_blank_with_value, effort_present_pef_missing,
    spirometry_raw, spirometry_abc, spirometry_ab,
    status_complete, status_partial, status_not_done,
    all_of(pfq_keep[-1]),
    all_of(pfq_difficulty_vars), all_of(pfq_difficulty_code5_positive_vars),
    pfq_younger_no_limitation_skip,
    mobility_difficulty_routed, adl_iadl_difficulty_routed,
    mobility_difficulty_code5_positive, adl_iadl_difficulty_code5_positive,
    mobility_route_source, adl_route_source,
    mobility_code5_positive_route_source, adl_code5_positive_route_source,
    all_of(safety_reason_cols), safety_any_explicit_positive,
    safety_screen_unknown_refused
  )
attr(ledger, "artifact_contract") <- "NHANES v43 Stage 1 machine ledger; no model results"
attr(ledger, "generated_at") <- format(Sys.time(), tz = "Asia/Shanghai", usetz = TRUE)
saveRDS(ledger, file.path(ledger_dir, "nhanes_stage1_ledger_v43.rds"), compress = "xz")

# Aggregate-only results and logs.
readr::write_csv(merge_audit, file.path(out_dir, "nhanes_merge_audit_v43.csv"))
readr::write_csv(cohort_flow, file.path(out_dir, "nhanes_cohort_flow_v43.csv"))
readr::write_csv(sample_event_anchors, file.path(out_dir, "nhanes_sample_event_anchors_v43.csv"))
readr::write_csv(followup_horizon_audit, file.path(out_dir, "nhanes_followup_horizon_audit_v43.csv"))
readr::write_csv(pef_observation_contrast, file.path(out_dir, "nhanes_pef_observation_contrast_v43.csv"))
readr::write_csv(status_comment, file.path(out_dir, "nhanes_status_comment_v43.csv"))
readr::write_csv(safety_reasons, file.path(out_dir, "nhanes_safety_reasons_v43.csv"))
readr::write_csv(pef_quality, file.path(out_dir, "nhanes_pef_quality_v43.csv"))
readr::write_csv(spirometry_quality, file.path(out_dir, "nhanes_spirometry_quality_v43.csv"))
readr::write_csv(measurement_contract, file.path(out_dir, "nhanes_measurement_contract_v43.csv"))
readr::write_csv(function_routing_audit, file.path(out_dir, "nhanes_function_routing_audit_v43.csv"))
readr::write_csv(measurement_summary, file.path(out_dir, "nhanes_measurement_summary_v43.csv"))
readr::write_csv(measurement_correlations, file.path(out_dir, "nhanes_measurement_correlations_v43.csv"))
readr::write_csv(measurement_anomalies, file.path(out_dir, "nhanes_measurement_anomalies_v43.csv"))
readr::write_csv(survey_design_audit, file.path(out_dir, "nhanes_survey_design_audit_v43.csv"))
readr::write_csv(e0_scale, file.path(out_dir, "nhanes_e0_scale_v43.csv"))
readr::write_csv(common_sample_audit, file.path(out_dir, "nhanes_common_sample_audit_v43.csv"))
readr::write_csv(gate1, file.path(out_dir, "gate1_nhanes_flow_v43.csv"))
readr::write_csv(gate2, file.path(out_dir, "gate2_nhanes_measurement_v43.csv"))

gate1_status <- if (isTRUE(all(gate1$pass))) "PASS" else "FAIL"
gate2_status <- if (isTRUE(all(gate2$pass))) "PASS" else "FAIL"
soft_anomalies <- measurement_anomalies %>%
  filter(cycle_label == "ALL", !hard_assertion, n > 0) %>%
  select(anomaly_id, definition, n, deaths)

log_lines <- c(
  "# NHANES v43 Stage 1-2 flow and measurement audit",
  "",
  paste0("Completed: ", format(Sys.time(), tz = "Asia/Shanghai", usetz = TRUE)),
  "",
  "## Scope",
  "",
  "- Read raw DEMO_E/F/G, SPX_E/F/G, and the three 2019 public-use linked-mortality DAT files directly.",
  "- Results/logs contain aggregate counts and diagnostics only.",
  "- Wrote the contract-authorized row-level machine ledger to `derived_sensitive/v43/nhanes_stage1_ledger_v43.rds`; it contains no model results.",
  "- No mortality association, prediction, or other outcome model was fitted.",
  paste0("- Gate 1 (flow/source integrity): **", gate1_status, "**."),
  paste0("- Gate 2 (NHANES measurement contract): **", gate2_status, "**."),
  "",
  "## Three-way merge audit",
  "",
  markdown_table(merge_audit),
  "",
  "## Cohort flow",
  "",
  markdown_table(cohort_flow),
  "",
  "## Frozen sample/event anchors",
  "",
  markdown_table(sample_event_anchors %>% filter(cycle_label == "ALL")),
  "",
  "## Administrative follow-up horizons in the primary A-only layer",
  "",
  markdown_table(followup_horizon_audit %>% mutate(known_status_fraction = round(known_status_fraction, 5))),
  "",
  "## Strict PEF observation contrast within the safe target",
  "",
  markdown_table(pef_observation_contrast %>% mutate(weighted_death_fraction = round(weighted_death_fraction, 5))),
  "",
  "## Measurement-only common sample for later nested models",
  "",
  markdown_table(common_sample_audit),
  "",
  "## Measurement contract",
  "",
  markdown_table(measurement_contract %>% mutate(weighted_fraction_of_safe_target = round(weighted_fraction_of_safe_target, 5))),
  "",
  "## Route-aware physical-function reconstruction",
  "",
  markdown_table(function_routing_audit),
  "",
  "## Outcome-blind E0 scale parameters",
  "",
  markdown_table(e0_scale %>% mutate(across(where(is.numeric), ~round(.x, 5)))),
  "",
  "## Survey design",
  "",
  markdown_table(survey_design_audit),
  "",
  "## Non-zero descriptive anomaly flags",
  "",
  markdown_table(soft_anomalies),
  "",
  "## Interpretation boundary",
  "",
  "`SPXNQEFF=A` is the strict primary PEF-quality layer. A+C is the duration-relaxed sensitivity and A/B/C is broad only. B is not called strict because it denotes delayed or non-repeatable peak flow. FEV1/FVC quality uses its separate A/B/C versus A/B hierarchy.",
  "",
  "A-only sex-specific weighted means and SDs are the sole outcome-model scaling constants and must be reused unchanged in A+C and A/B/C sensitivities. Layer-specific scale rows are descriptive diagnostics only.",
  "",
  "The reconstructed safety-reason table is descriptive only; `SPXNSTAT=4`, not the reason reconstruction, defines official safety exclusion.",
  "",
  "Safety-excluded participants and adults older than 79 years are outside the PEF-observation estimand and must not enter observation-IPW or MI as item-missing records. Survey designs must be created before domain restriction.",
  "",
  paste0("Outcome models fitted: 0")
)
writeLines(log_lines, file.path(log_dir, "02_nhanes_stage1_2_audit_v43.md"), useBytes = TRUE)

if (gate1_status != "PASS" || gate2_status != "PASS") {
  stop(
    "NHANES Stage 1-2 audit failed: Gate 1=", gate1_status,
    ", Gate 2=", gate2_status,
    ". Inspect aggregate gate tables and log before outcome modeling.",
    call. = FALSE
  )
}

message(
  "NHANES Stage 1-2 audit PASS. Results/logs are aggregate; ",
  "authorized sensitive ledger written; outcome models fitted: 0."
)
