# v43 Stage 3: NHANES primary all-cause mortality association.
#
# GOVERNANCE WARNING
# ------------------
# This file is intentionally executable only after the independent Stage 0-2
# gate has been promoted to PASS in work_v43/gate_state_v43.yml and the final
# Stage 3 authorization hashes have been frozen. The authorization check runs
# before any row-level input is opened and before any mortality model is fitted.
#
# Primary model:
#   survey-weighted Cox regression, with the complete pooled MEC design built
#   before the age/safety/PEF analytic domain is applied.
# Primary exposure:
#   E0 = (sex-specific frozen A-only weighted mean PEF - raw PEF) /
#        sex-specific frozen A-only weighted SD PEF.
# Primary adjustment tier:
#   A1 (A0 structural terms plus smoking, BMI, education and PIR).
#
# SPXNQEFF B is never called strict quality. Official positive PEF tails are
# retained in the primary analysis. Mortality linked-file DIABETES/HYPERTEN
# fields are never used as baseline comorbidities.
#
# NHANES body weight is an MI parent/auxiliary only. Missing height and weight
# are PMM-imputed before only the originally missing BMI cells are passively
# reconstructed on the released cycle-specific weight/height-squared scale.

options(stringsAsFactors = FALSE)

project_root <- function() {
  args <- commandArgs(trailingOnly = FALSE)
  file_arg <- grep("^--file=", args, value = TRUE)
  if (length(file_arg)) {
    script <- sub("^--file=", "", file_arg[[1]])
    return(normalizePath(file.path(dirname(script), "..", ".."), mustWork = TRUE))
  }
  normalizePath(getwd(), mustWork = TRUE)
}

one_line <- function(x, empty = "") {
  x <- trimws(as.character(x))
  x <- x[!is.na(x) & nzchar(x)]
  if (!length(x)) return(empty)
  gsub("[\r\n]+", " ", paste(x, collapse = "; "))
}

atomic_write_csv <- function(dat, path) {
  dir.create(dirname(path), recursive = TRUE, showWarnings = FALSE)
  tmp <- tempfile(
    pattern = paste0(".", basename(path), "."),
    tmpdir = dirname(path)
  )
  on.exit(if (file.exists(tmp)) unlink(tmp), add = TRUE)
  utils::write.csv(dat, tmp, row.names = FALSE, na = "")
  if (!file.rename(tmp, path)) {
    stop("Could not atomically publish CSV: ", path, call. = FALSE)
  }
  invisible(path)
}

atomic_write_lines <- function(lines, path) {
  dir.create(dirname(path), recursive = TRUE, showWarnings = FALSE)
  tmp <- tempfile(
    pattern = paste0(".", basename(path), "."),
    tmpdir = dirname(path)
  )
  on.exit(if (file.exists(tmp)) unlink(tmp), add = TRUE)
  writeLines(lines, tmp, useBytes = TRUE)
  if (!file.rename(tmp, path)) {
    stop("Could not atomically publish text output: ", path, call. = FALSE)
  }
  invisible(path)
}

as_flag <- function(x) {
  if (is.logical(x)) return(x)
  if (is.numeric(x)) return(ifelse(is.na(x), NA, x != 0))
  y <- toupper(trimws(as.character(x)))
  out <- rep(NA, length(y))
  out[y %in% c("TRUE", "T", "1", "YES", "Y", "PASS", "GO", "OK")] <- TRUE
  out[y %in% c("FALSE", "F", "0", "NO", "N", "FAIL", "NO-GO", "NO_GO", "ERROR")] <- FALSE
  out
}

expected_runtime_authorization_checks <- function() {
  c(
    "required_authorization_assets",
    "gate_state_allows_outcome_execution",
    "independent_stage0_2_validation",
    "stage3_no_model_preflight_pass",
    "private_manifest_rows_current",
    "stable_input_inventory_rows_current",
    "validator_source_inventory_rows_current",
    "final_authorization_audit_pass",
    "final_pre_model_hash_registry",
    "stage3_packages_locked_and_loaded_versions_match"
  )
}

sha256_file <- function(path) {
  if (!file.exists(path) || dir.exists(path)) return(NA_character_)
  if (!requireNamespace("digest", quietly = TRUE)) return(NA_character_)
  digest::digest(file = path, algo = "sha256", serialize = FALSE)
}

write_cohort_csv <- function(dat, path, cohort = "NHANES") {
  if (!"cohort" %in% names(dat)) {
    stop("Cohort-specific Stage 3 table lacks a cohort column: ", path, call. = FALSE)
  }
  if (any(is.na(dat$cohort)) || any(toupper(as.character(dat$cohort)) != toupper(cohort))) {
    stop("Cohort-specific Stage 3 table contains a non-", cohort, " row: ", path, call. = FALSE)
  }
  readr::write_csv(dat, path)
  invisible(dat)
}

validate_hash_inventory <- function(path, required_assets = character()) {
  out <- list(pass = FALSE, observed = "inventory unavailable")
  if (!file.exists(path) || file.info(path)$size <= 0) return(out)
  dat <- tryCatch(
    utils::read.csv(path, stringsAsFactors = FALSE, check.names = FALSE),
    error = function(e) NULL
  )
  required_columns <- c("asset", "path", "exists", "bytes", "sha256", "frozen_at")
  if (is.null(dat) || !all(required_columns %in% names(dat))) {
    out$observed <- "inventory lacks the six-column final-registry schema"
    return(out)
  }
  if (anyDuplicated(dat$asset) || anyDuplicated(dat$path) || !nrow(dat)) {
    out$observed <- "inventory has duplicate/empty asset or path rows"
    return(out)
  }
  missing_assets <- setdiff(required_assets, dat$asset)
  unexpected_assets <- setdiff(dat$asset, required_assets)
  recorded_exists <- as_flag(dat$exists)
  paths_exist <- file.exists(dat$path) & !dir.exists(dat$path)
  current_bytes <- ifelse(paths_exist, as.numeric(file.info(dat$path)$size), NA_real_)
  current <- vapply(dat$path, sha256_file, character(1))
  bytes_match <- paths_exist & is.finite(current_bytes) &
    current_bytes == suppressWarnings(as.numeric(dat$bytes))
  hashes_match <- !is.na(current) &
    grepl("^[0-9a-fA-F]{64}$", as.character(dat$sha256)) &
    tolower(current) == tolower(as.character(dat$sha256))
  frozen_at_ok <- length(unique(as.character(dat$frozen_at))) == 1L &&
    all(nzchar(as.character(dat$frozen_at)))
  out$pass <- !length(missing_assets) && !length(unexpected_assets) &&
    nrow(dat) == length(required_assets) &&
    all(recorded_exists %in% TRUE) &&
    all(paths_exist) && all(bytes_match) && all(hashes_match) && frozen_at_ok
  out$observed <- paste0(
    "rows=", nrow(dat),
    "; missing_assets=", if (length(missing_assets)) paste(missing_assets, collapse = "|") else "none",
    "; unexpected_assets=", if (length(unexpected_assets)) paste(unexpected_assets, collapse = "|") else "none",
    "; missing_paths=", sum(!paths_exist),
    "; byte_mismatches=", sum(!bytes_match),
    "; hash_mismatches=", sum(!hashes_match)
  )
  out$data <- dat
  out
}

validate_private_manifest <- function(path) {
  out <- list(pass = FALSE, observed = "private manifest unavailable")
  if (!file.exists(path) || file.info(path)$size <= 0) return(out)
  dat <- tryCatch(
    utils::read.csv(path, stringsAsFactors = FALSE, check.names = FALSE),
    error = function(e) NULL
  )
  required <- c("group", "role", "path", "exists", "sha256")
  if (is.null(dat) || !all(required %in% names(dat))) {
    out$observed <- "private manifest lacks required columns"
    return(out)
  }
  if (!nrow(dat) || anyDuplicated(dat$path)) {
    out$observed <- "private manifest is empty or has duplicate paths"
    return(out)
  }
  recorded_exists <- as_flag(dat$exists)
  current_exists <- file.exists(dat$path) & !dir.exists(dat$path)
  current_hash <- vapply(dat$path, sha256_file, character(1))
  hash_match <- current_exists & !is.na(current_hash) & nzchar(dat$sha256) &
    tolower(current_hash) == tolower(as.character(dat$sha256))
  out$pass <- all(recorded_exists %in% TRUE) && all(current_exists) && all(hash_match)
  out$observed <- paste0(
    "rows=", nrow(dat),
    "; recorded_missing=", sum(!(recorded_exists %in% TRUE)),
    "; current_missing=", sum(!current_exists),
    "; hash_mismatches=", sum(!hash_match)
  )
  out$data <- dat
  out
}

validate_stable_input_inventory <- function(path) {
  out <- list(pass = FALSE, observed = "stable input inventory unavailable")
  if (!file.exists(path) || file.info(path)$size <= 0) return(out)
  dat <- tryCatch(
    utils::read.csv(path, stringsAsFactors = FALSE, check.names = FALSE),
    error = function(e) NULL
  )
  required <- c("group", "role", "path", "restricted", "exists", "bytes", "sha256")
  if (is.null(dat) || !all(required %in% names(dat))) {
    out$observed <- "stable input inventory lacks required columns"
    return(out)
  }
  if (!nrow(dat) || anyDuplicated(dat$path)) {
    out$observed <- "stable input inventory is empty or has duplicate paths"
    return(out)
  }
  recorded_exists <- as_flag(dat$exists)
  current_exists <- file.exists(dat$path) & !dir.exists(dat$path)
  current_bytes <- ifelse(current_exists, as.numeric(file.info(dat$path)$size), NA_real_)
  current_hash <- vapply(dat$path, sha256_file, character(1))
  byte_match <- current_exists & is.finite(current_bytes) &
    current_bytes == suppressWarnings(as.numeric(dat$bytes))
  hash_match <- current_exists & !is.na(current_hash) & nzchar(dat$sha256) &
    tolower(current_hash) == tolower(as.character(dat$sha256))
  out$pass <- all(recorded_exists %in% TRUE) && all(current_exists) &&
    all(byte_match) && all(hash_match)
  out$observed <- paste0(
    "rows=", nrow(dat),
    "; current_missing=", sum(!current_exists),
    "; byte_mismatches=", sum(!byte_match),
    "; hash_mismatches=", sum(!hash_match)
  )
  out$data <- dat
  out
}

validate_validator_source_inventory <- function(path) {
  out <- list(pass = FALSE, observed = "validator source inventory unavailable")
  if (!file.exists(path) || file.info(path)$size <= 0) return(out)
  dat <- tryCatch(
    utils::read.csv(path, stringsAsFactors = FALSE, check.names = FALSE),
    error = function(e) NULL
  )
  required <- c("path", "exists", "bytes", "sha256")
  if (is.null(dat) || !all(required %in% names(dat))) {
    out$observed <- "validator source inventory lacks required columns"
    return(out)
  }
  normalized_paths <- normalizePath(as.character(dat$path), mustWork = FALSE)
  if (!nrow(dat) || anyDuplicated(normalized_paths)) {
    out$observed <- "validator source inventory is empty or has duplicate paths"
    return(out)
  }
  recorded_exists <- as_flag(dat$exists)
  current_exists <- file.exists(dat$path) & !dir.exists(dat$path)
  current_bytes <- ifelse(current_exists, as.numeric(file.info(dat$path)$size), NA_real_)
  current_hash <- vapply(dat$path, sha256_file, character(1))
  byte_match <- current_exists & is.finite(current_bytes) &
    current_bytes == suppressWarnings(as.numeric(dat$bytes))
  hash_match <- current_exists & !is.na(current_hash) &
    grepl("^[0-9a-fA-F]{64}$", as.character(dat$sha256)) &
    tolower(current_hash) == tolower(as.character(dat$sha256))
  out$pass <- all(recorded_exists %in% TRUE) && all(current_exists) &&
    all(byte_match) && all(hash_match)
  out$observed <- paste0(
    "rows=", nrow(dat),
    "; current_missing=", sum(!current_exists),
    "; byte_mismatches=", sum(!byte_match),
    "; hash_mismatches=", sum(!hash_match)
  )
  out$data <- dat
  out
}

validate_authorization_audit <- function(path) {
  out <- list(pass = FALSE, observed = "final authorization audit unavailable")
  if (!file.exists(path) || file.info(path)$size <= 0) return(out)
  dat <- tryCatch(
    utils::read.csv(path, stringsAsFactors = FALSE, check.names = FALSE),
    error = function(e) NULL
  )
  required_columns <- c("check", "status", "observed", "expected", "checked_at")
  expected_checks <- c(
    "gate0_recomputed_from_current_files",
    "gate_state_promoted_for_final_authorization",
    "independent_stage0_2_validator_pass",
    "validator_source_inventory_matches_current_files",
    "preflight_report_schema_complete",
    "preflight_fixed_unique_check_contract",
    "preflight_all_fixed_checks_pass",
    "preflight_snapshot_matches_current_scripts_and_inputs"
  )
  if (is.null(dat) || !all(required_columns %in% names(dat))) {
    out$observed <- "final authorization audit lacks required columns"
    return(out)
  }
  out$pass <- nrow(dat) == length(expected_checks) &&
    !anyDuplicated(dat$check) &&
    setequal(as.character(dat$check), expected_checks) &&
    all(toupper(as.character(dat$status)) == "PASS") &&
    length(unique(as.character(dat$checked_at))) == 1L &&
    all(!is.na(dat$checked_at) & nzchar(as.character(dat$checked_at))) &&
    all(!is.na(dat$observed) & nzchar(as.character(dat$observed))) &&
    all(!is.na(dat$expected) & nzchar(as.character(dat$expected)))
  out$observed <- paste0(
    "rows=", nrow(dat), "/", length(expected_checks),
    "; duplicate_checks=", anyDuplicated(dat$check),
    "; check_contract=", setequal(as.character(dat$check), expected_checks),
    "; pass_rows=", sum(toupper(as.character(dat$status)) == "PASS")
  )
  out$data <- dat
  out
}

write_authorization_failure <- function(root, checks, reason) {
  out_dir <- file.path(root, "results", "v43")
  log_dir <- file.path(root, "logs", "v43")
  dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)
  dir.create(log_dir, recursive = TRUE, showWarnings = FALSE)
  checks <- as.data.frame(checks, stringsAsFactors = FALSE)
  checks$run_timestamp <- format(Sys.time(), tz = "Asia/Shanghai", usetz = TRUE)
  utils::write.csv(
    checks,
    file.path(out_dir, "stage3_nhanes_authorization_audit_v43.csv"),
    row.names = FALSE,
    na = ""
  )
  writeLines(
    c(
      paste0("NHANES Stage 3 execution denied: ", format(Sys.time(), tz = "Asia/Shanghai", usetz = TRUE)),
      paste0("Reason: ", one_line(reason)),
      "Row-level inputs opened: 0",
      "Mortality models fitted: 0",
      "This is the only output permitted when the authorization gate fails."
    ),
    file.path(log_dir, "stage3_nhanes_authorization_failure_v43.log"),
    useBytes = TRUE
  )
}

authorization_gate <- function(root) {
  required_gate_packages <- c("yaml", "digest")
  missing_gate_packages <- required_gate_packages[
    !vapply(required_gate_packages, requireNamespace, logical(1), quietly = TRUE)
  ]
  if (length(missing_gate_packages)) {
    checks <- data.frame(
      check = "authorization_reader_packages",
      status = "FAIL",
      observed = paste(missing_gate_packages, collapse = "; "),
      expected = paste(required_gate_packages, collapse = "; "),
      stringsAsFactors = FALSE
    )
    write_authorization_failure(root, checks, "Packages required to read the authorization state are unavailable.")
    stop("Stage 3 authorization failed before any row-level input was opened.", call. = FALSE)
  }

  paths <- list(
    gate_state = file.path(root, "work_v43", "gate_state_v43.yml"),
    gate0 = file.path(root, "results", "v43", "gate0_reproducibility_v43.csv"),
    validator = file.path(root, "results", "v43", "gate1_2_validation_v43.csv"),
    validator_source_inventory = file.path(root, "results", "v43", "stage0_2_validated_source_inventory_v43.csv"),
    authorization_validation = file.path(root, "results", "v43", "stage3_authorization_validation_v43.csv"),
    preflight_validation = file.path(root, "results", "v43", "stage3_preflight_validation_v43.csv"),
    spec = file.path(root, "work_v43", "analysis_spec_v43.yml"),
    manifest = file.path(root, "results", "v43", "input_manifest_private_v43.csv"),
    decision_log = file.path(root, "work_v43", "decision_log_v43.md"),
    blueprint = file.path(root, "output", "qa", "v43_STAGE3_MODEL_BLUEPRINT_20260716.md"),
    output_contract = file.path(root, "work_v43", "output_contract_v43.yml"),
    registry_schema = file.path(root, "work_v43", "registry_schema_v43.csv"),
    renv_lock = file.path(root, "work_v43", "renv.lock"),
    hash_registry = file.path(root, "work_v43", "stage3_authorization_hashes_v43.csv"),
    stable_input_inventory = file.path(root, "work_v43", "stage3_stable_input_inventory_v43.csv"),
    stage0_script = file.path(root, "R", "v43", "00_freeze_and_manifest.R"),
    validator_script = file.path(root, "R", "v43", "03_validate_stage0_2.R"),
    preflight_script = file.path(root, "R", "v43", "03b_stage3_preflight.R"),
    charls_script = file.path(root, "R", "v43", "04_charls_stage3_primary_mortality.R"),
    nhanes_script = file.path(root, "R", "v43", "05_nhanes_stage3_primary_mortality.R"),
    finalizer_script = file.path(root, "R", "v43", "06_finalize_stage3_outputs.R"),
    charls_core = file.path(root, "derived_sensitive", "charls", "charls_core_harmonized_provisional.rds"),
    charls_ledger = file.path(root, "derived_sensitive", "v43", "charls_stage1_ledger_v43.rds"),
    charls_e0 = file.path(root, "results", "v43", "charls_e0_scale_v43.csv"),
    nhanes_ledger = file.path(root, "derived_sensitive", "v43", "nhanes_stage1_ledger_v43.rds"),
    nhanes_donor = file.path(root, "derived_sensitive", "nhanes", "nhanes_mortality_analysis_ready_v30_0.rds"),
    nhanes_e0 = file.path(root, "results", "v43", "nhanes_e0_scale_v43.csv"),
    nhanes_function_routing_audit = file.path(root, "results", "v43", "nhanes_function_routing_audit_v43.csv"),
    nhanes_function_proxy_evidence = file.path(root, "output", "qa", "v43_NHANES_FUNCTION_PROXY_EVIDENCE_20260716.md")
  )

  checks <- list()
  add <- function(check, pass, observed, expected) {
    checks[[length(checks) + 1L]] <<- data.frame(
      check = check,
      status = if (isTRUE(pass)) "PASS" else "FAIL",
      observed = one_line(observed),
      expected = one_line(expected),
      stringsAsFactors = FALSE
    )
  }

  path_exists <- vapply(paths, function(x) file.exists(x) && file.info(x)$size > 0, logical(1))
  expected_gate0_checks <- c(
    "analysis_spec_frozen",
    "governance_files_exist",
    "renv_lock_exists",
    "all_manifest_inputs_exist",
    "stage0_2_packages_available",
    "stage3_packages_available",
    "later_optional_packages_recorded"
  )
  gate0_ok <- FALSE
  gate0_observed <- "Gate 0 report unavailable"
  if (path_exists[["gate0"]]) {
    gate0_report <- tryCatch(
      utils::read.csv(paths$gate0, stringsAsFactors = FALSE, check.names = FALSE),
      error = function(e) NULL
    )
    if (!is.null(gate0_report) &&
        all(c("check", "pass") %in% names(gate0_report))) {
      observed_checks <- as.character(gate0_report$check)
      pass <- as_flag(gate0_report$pass)
      gate0_ok <- nrow(gate0_report) == length(expected_gate0_checks) &&
        !anyDuplicated(observed_checks) &&
        setequal(observed_checks, expected_gate0_checks) &&
        all(pass %in% TRUE)
      gate0_observed <- paste0(
        sum(pass %in% TRUE), "/", nrow(gate0_report),
        " PASS; unique=", !anyDuplicated(observed_checks),
        "; fixed_contract=", setequal(observed_checks, expected_gate0_checks)
      )
    }
  }
  add(
    "required_authorization_assets",
    all(path_exists) && gate0_ok,
    paste0(
      paste(names(path_exists), path_exists, sep = "=", collapse = "; "),
      "; current_gate0=", gate0_ok,
      "; ", gate0_observed
    ),
    paste(
      "all required authorization, ledger, donor, scaling, registry and lock",
      "assets are present and the exact seven-row current Gate 0 contract is PASS"
    )
  )

  gate_state <- if (path_exists[["gate_state"]]) yaml::read_yaml(paths$gate_state) else NULL
  gate_ok <- !is.null(gate_state) &&
    identical(toupper(gate_state$gate0$status), "PASS") &&
    identical(toupper(gate_state$gate1$status), "PASS") &&
    identical(toupper(gate_state$gate2$status), "PASS") &&
    isTRUE(gate_state$outcome_execution_allowed)
  add(
    "gate_state_allows_outcome_execution",
    gate_ok,
    if (is.null(gate_state)) "gate state unreadable" else paste0(
      "Gate0=", gate_state$gate0$status,
      "; Gate1=", gate_state$gate1$status,
      "; Gate2=", gate_state$gate2$status,
      "; allowed=", gate_state$outcome_execution_allowed
    ),
    "Gate0=PASS; Gate1=PASS; Gate2=PASS; outcome_execution_allowed=true"
  )

  validator_ok <- FALSE
  validator_observed <- "validator unavailable"
  if (path_exists[["validator"]]) {
    validator <- utils::read.csv(paths$validator, stringsAsFactors = FALSE, check.names = FALSE)
    if (all(c("required", "status") %in% names(validator))) {
      required <- as_flag(validator$required)
      validator_ok <- any(required %in% TRUE) &&
        all(toupper(validator$status[required %in% TRUE]) == "PASS")
      validator_observed <- paste0(
        sum(toupper(validator$status[required %in% TRUE]) == "PASS"), "/",
        sum(required %in% TRUE), " required checks PASS"
      )
    }
  }
  add(
    "independent_stage0_2_validation",
    validator_ok,
    validator_observed,
    "every required row in gate1_2_validation_v43.csv is PASS"
  )

  preflight_ok <- FALSE
  preflight_observed <- "preflight validation unavailable"
  if (path_exists[["preflight_validation"]]) {
    preflight <- utils::read.csv(paths$preflight_validation, stringsAsFactors = FALSE, check.names = FALSE)
    expected_checks <- list(
      BOTH = c(
        "preflight_packages_available",
        "gate0_2_pass_before_preflight",
        "outcome_execution_disabled_during_preflight",
        "independent_stage0_2_validator_pass",
        "preliminary_manifest_current_and_complete",
        "governance_preflight_completed"
      ),
      CHARLS = c(
        "structural_sample_time_support_rebuilt",
        "mi_targets_have_predictors",
        "mi_specification_hash_recorded",
        "mi_expanded_dimension_below_rows",
        "two_by_two_mice_dry_run",
        "A0_A2_model_matrices_full_rank",
        "survey_design_df_exceeds_model_dimension",
        "spline_knots_finite",
        "charls_preflight_completed"
      ),
      NHANES = c(
        "primary_sample_and_events_rebuilt",
        "full_design_backbone_rebuilt",
        "mi_targets_have_predictors",
        "mi_specification_hash_recorded",
        "mi_expanded_dimension_below_rows",
        "stratum_plus_raw_psu_reconstructs_design_psu",
        "two_by_two_mice_dry_run",
        "full_design_before_domain_preserved",
        "A0_A2_model_matrices_full_rank",
        "survey_design_df_exceeds_model_dimension",
        "start_stop_window_matrix_full_rank",
        "nhanes_preflight_completed"
      )
    )
    expected_keys <- unlist(lapply(names(expected_checks), function(cohort) {
      paste(cohort, expected_checks[[cohort]], sep = "::")
    }), use.names = FALSE)
    hash_columns <- c(
      "check_contract_sha256", "stable_input_inventory_sha256",
      "stage0_script_sha256", "validator_script_sha256",
      "preflight_script_sha256", "charls_script_sha256", "nhanes_script_sha256",
      "finalizer_script_sha256",
      "analysis_spec_sha256", "charls_core_sha256", "charls_ledger_sha256",
      "charls_e0_sha256", "nhanes_ledger_sha256", "nhanes_donor_sha256",
      "nhanes_e0_sha256", "nhanes_function_routing_audit_sha256",
      "nhanes_function_proxy_evidence_sha256", "renv_lock_sha256",
      "validator_report_sha256", "validator_source_inventory_sha256",
      "preliminary_manifest_sha256"
    )
    required_preflight_columns <- c(
      "cohort", "check", "status", "hard_gate", "expected_check", hash_columns
    )
    if (all(required_preflight_columns %in% names(preflight))) {
      hard <- as_flag(preflight$hard_gate)
      expected_flag <- as_flag(preflight$expected_check)
      observed_keys <- paste(toupper(preflight$cohort), preflight$check, sep = "::")
      current_hashes <- c(
        stable_input_inventory_sha256 = sha256_file(paths$stable_input_inventory),
        stage0_script_sha256 = sha256_file(paths$stage0_script),
        validator_script_sha256 = sha256_file(paths$validator_script),
        preflight_script_sha256 = sha256_file(paths$preflight_script),
        charls_script_sha256 = sha256_file(paths$charls_script),
        nhanes_script_sha256 = sha256_file(paths$nhanes_script),
        finalizer_script_sha256 = sha256_file(paths$finalizer_script),
        analysis_spec_sha256 = sha256_file(paths$spec),
        charls_core_sha256 = sha256_file(paths$charls_core),
        charls_ledger_sha256 = sha256_file(paths$charls_ledger),
        charls_e0_sha256 = sha256_file(paths$charls_e0),
        nhanes_ledger_sha256 = sha256_file(paths$nhanes_ledger),
        nhanes_donor_sha256 = sha256_file(paths$nhanes_donor),
        nhanes_e0_sha256 = sha256_file(paths$nhanes_e0),
        nhanes_function_routing_audit_sha256 = sha256_file(paths$nhanes_function_routing_audit),
        nhanes_function_proxy_evidence_sha256 = sha256_file(paths$nhanes_function_proxy_evidence),
        renv_lock_sha256 = sha256_file(paths$renv_lock),
        validator_report_sha256 = sha256_file(paths$validator),
        validator_source_inventory_sha256 = sha256_file(paths$validator_source_inventory)
      )
      hash_unique_nonempty <- vapply(
        hash_columns,
        function(column) {
          values <- unique(tolower(as.character(preflight[[column]])))
          length(values) == 1L && !is.na(values) &&
            grepl("^[0-9a-f]{64}$", values)
        },
        logical(1)
      )
      current_hash_match <- vapply(
        names(current_hashes),
        function(column) {
          isTRUE(hash_unique_nonempty[[column]]) &&
            identical(
              unique(tolower(as.character(preflight[[column]]))),
              tolower(unname(current_hashes[[column]]))
            )
        },
        logical(1)
      )
      preflight_ok <- nrow(preflight) == length(expected_keys) &&
        !anyDuplicated(observed_keys) &&
        setequal(observed_keys, expected_keys) &&
        all(hard %in% TRUE) &&
        all(expected_flag %in% TRUE) &&
        all(toupper(preflight$status) == "PASS") &&
        all(hash_unique_nonempty) &&
        all(current_hash_match)
      preflight_observed <- paste0(
        "rows=", nrow(preflight), "/", length(expected_keys),
        "; duplicate_keys=", anyDuplicated(observed_keys),
        "; key_contract=", setequal(observed_keys, expected_keys),
        "; pass_rows=", sum(toupper(preflight$status) == "PASS"),
        "; hash_columns_unique=", sum(hash_unique_nonempty), "/", length(hash_unique_nonempty),
        "; current_hash_matches=", sum(current_hash_match), "/", length(current_hash_match)
      )
    } else {
      preflight_observed <- paste0(
        "missing columns: ",
        paste(setdiff(required_preflight_columns, names(preflight)), collapse = "; ")
      )
    }
  }
  add(
    "stage3_no_model_preflight_pass",
    preflight_ok,
    preflight_observed,
    paste0(
      "exactly 27 unique expected hard checks PASS; every embedded hash is a ",
      "single valid SHA-256; every stable input/script hash matches the current asset"
    )
  )

  manifest_validation <- validate_private_manifest(paths$manifest)
  add(
    "private_manifest_rows_current",
    manifest_validation$pass,
    manifest_validation$observed,
    "every private-manifest path exists and its current SHA-256 equals the frozen row"
  )

  stable_inventory_validation <- validate_stable_input_inventory(paths$stable_input_inventory)
  add(
    "stable_input_inventory_rows_current",
    stable_inventory_validation$pass,
    stable_inventory_validation$observed,
    "every stable-input path retains its frozen byte count and SHA-256"
  )

  validator_inventory_validation <- validate_validator_source_inventory(
    paths$validator_source_inventory
  )
  add(
    "validator_source_inventory_rows_current",
    validator_inventory_validation$pass,
    validator_inventory_validation$observed,
    "every aggregate source read by the independent validator retains its recorded byte count and SHA-256"
  )

  authorization_audit_validation <- validate_authorization_audit(
    paths$authorization_validation
  )
  add(
    "final_authorization_audit_pass",
    authorization_audit_validation$pass,
    authorization_audit_validation$observed,
    "the exact eight final-authorization checks are unique and PASS"
  )

  required_registry_assets <- c(
    "analysis_spec", "private_manifest", "decision_log", "stage3_blueprint",
    "stage3_preflight_script", "charls_stage3_script", "nhanes_stage3_script",
    "stage3_preflight_validation", "gate_state", "stage0_2_validator_report",
    "stage0_freeze_script", "stage0_2_validator_script", "charls_core",
    "charls_stage1_ledger", "charls_e0_scale", "nhanes_stage1_ledger",
    "nhanes_donor", "nhanes_e0_scale", "nhanes_function_routing_audit",
    "nhanes_function_proxy_evidence", "renv_lock", "stable_input_inventory",
    "stage3_authorization_validation", "stage0_2_validator_source_inventory",
    "stage3_output_finalizer_script"
  )
  registry_validation <- validate_hash_inventory(
    paths$hash_registry,
    required_assets = required_registry_assets
  )
  add(
    "final_pre_model_hash_registry",
    registry_validation$pass,
    registry_validation$observed,
    "every required final-authorization file asset exists and matches its registry SHA-256"
  )

  locked_packages <- c(
    "digest", "dplyr", "haven", "mice", "mitools", "readr",
    "survey", "survival", "tibble", "tidyr", "yaml"
  )
  lock_ok <- FALSE
  lock_observed <- "renv lock unavailable"
  if (path_exists[["renv_lock"]]) {
    lock <- tryCatch(yaml::read_yaml(paths$renv_lock), error = function(e) NULL)
    lock_versions <- vapply(
      locked_packages,
      function(pkg) {
        if (is.null(lock) || is.null(lock$Packages[[pkg]]$Version)) NA_character_
        else as.character(lock$Packages[[pkg]]$Version)
      },
      character(1)
    )
    installed_versions <- vapply(
      locked_packages,
      function(pkg) {
        if (!requireNamespace(pkg, quietly = TRUE)) NA_character_
        else as.character(utils::packageDescription(pkg, fields = "Version"))
      },
      character(1)
    )
    version_match <- !is.na(lock_versions) & !is.na(installed_versions) &
      lock_versions == installed_versions
    locked_r <- if (is.null(lock) || is.null(lock$R$Version)) NA_character_ else
      as.character(lock$R$Version)
    installed_r <- as.character(getRversion())
    r_version_match <- !is.na(locked_r) && identical(locked_r, installed_r)
    lock_ok <- all(version_match) && r_version_match
    lock_observed <- paste0(
      "R=", locked_r, "/", installed_r, " match=", r_version_match, "; ",
      paste(
        locked_packages,
        paste0(lock_versions, "/", installed_versions, "=", version_match),
        sep = ":",
        collapse = "; "
      )
    )
  }
  add(
    "stage3_packages_locked_and_loaded_versions_match",
    lock_ok,
    lock_observed,
    "the running R version and each required package version exactly match work_v43/renv.lock"
  )

  checks_df <- do.call(rbind, checks)
  expected_runtime_checks <- expected_runtime_authorization_checks()
  if (nrow(checks_df) != 10L ||
      anyDuplicated(checks_df$check) ||
      !identical(as.character(checks_df$check), expected_runtime_checks)) {
    stop(
      "Internal error: NHANES runtime authorization audit is not the exact ",
      "10-check contract. No row-level input was opened.",
      call. = FALSE
    )
  }
  if (!all(checks_df$status == "PASS")) {
    write_authorization_failure(root, checks_df, "One or more frozen Stage 3 authorization conditions failed.")
    stop(
      "NHANES Stage 3 is not authorized. No row-level input was opened and no mortality model was fitted.",
      call. = FALSE
    )
  }
  invisible(list(paths = paths, gate_state = gate_state, checks = checks_df))
}

require_stage3_packages <- function() {
  packages <- c(
    "digest", "dplyr", "haven", "mice", "mitools", "readr",
    "survey", "survival", "tibble", "tidyr", "yaml"
  )
  missing <- packages[!vapply(packages, requireNamespace, logical(1), quietly = TRUE)]
  if (length(missing)) {
    stop(
      "Authorized execution cannot continue because required packages are unavailable: ",
      paste(missing, collapse = ", "),
      call. = FALSE
    )
  }
  options(survey.lonely.psu = "adjust")
  invisible(packages)
}

as_num <- function(x) {
  out <- haven::zap_labels(x)
  if (is.factor(out)) out <- as.character(out)
  suppressWarnings(as.numeric(out))
}

as_chr <- function(x) {
  out <- as.character(haven::zap_labels(x))
  out[is.na(out) | !nzchar(out)] <- NA_character_
  out
}

weighted_mean_simple <- function(x, w) {
  ok <- is.finite(x) & is.finite(w) & w > 0
  if (!any(ok)) return(NA_real_)
  sum(x[ok] * w[ok]) / sum(w[ok])
}

weighted_var_simple <- function(x, w) {
  ok <- is.finite(x) & is.finite(w) & w > 0
  if (sum(ok) < 2L) return(NA_real_)
  mu <- weighted_mean_simple(x[ok], w[ok])
  sum(w[ok] * (x[ok] - mu)^2) / sum(w[ok])
}

weighted_quantile_simple <- function(x, w, probs) {
  ok <- is.finite(x) & is.finite(w) & w > 0
  x <- x[ok]
  w <- w[ok]
  if (!length(x)) return(rep(NA_real_, length(probs)))
  ord <- order(x)
  x <- x[ord]
  w <- w[ord]
  cw <- cumsum(w) / sum(w)
  vapply(probs, function(p) x[which(cw >= p)[1]], numeric(1))
}

assert_unique_id <- function(dat, id, source) {
  if (!id %in% names(dat)) stop(source, " lacks ID column ", id, call. = FALSE)
  ids <- dat[[id]]
  if (anyNA(ids) || anyDuplicated(ids)) {
    stop(source, " does not have one nonmissing row per ", id, call. = FALSE)
  }
  invisible(TRUE)
}

new_audit_store <- function() {
  env <- new.env(parent = emptyenv())
  env$joins <- list()
  env$assertions <- list()
  env
}

record_assertion <- function(store, check, pass, observed, expected, hard_stop = TRUE) {
  store$assertions[[length(store$assertions) + 1L]] <- data.frame(
    check = check,
    status = if (isTRUE(pass)) "PASS" else "FAIL",
    observed = one_line(observed),
    expected = one_line(expected),
    stringsAsFactors = FALSE
  )
  if (!isTRUE(pass) && isTRUE(hard_stop)) {
    stop(check, " failed: ", one_line(observed), call. = FALSE)
  }
  invisible(pass)
}

audited_left_join <- function(x, y, by, source, store) {
  assert_unique_id(y, by, source)
  before <- nrow(x)
  matched <- sum(x[[by]] %in% y[[by]])
  out <- dplyr::left_join(x, y, by = by)
  store$joins[[length(store$joins) + 1L]] <- data.frame(
    source = source,
    source_rows = nrow(y),
    source_unique_ids = length(unique(y[[by]])),
    target_rows_before = before,
    target_rows_after = nrow(out),
    matched_target_ids = matched,
    unmatched_target_ids = before - matched,
    duplicate_source_ids = anyDuplicated(y[[by]]),
    stringsAsFactors = FALSE
  )
  if (nrow(out) != before) stop("Join expanded rows for source ", source, call. = FALSE)
  out
}

capture_fit <- function(expr) {
  warnings <- character()
  value <- withCallingHandlers(
    tryCatch(expr, error = function(e) structure(list(error = conditionMessage(e)), class = "stage3_fit_error")),
    warning = function(w) {
      warnings <<- c(warnings, conditionMessage(w))
      invokeRestart("muffleWarning")
    }
  )
  list(value = value, warnings = unique(warnings))
}

validate_cox_fit <- function(fit, warnings, model_id) {
  coefficients <- stats::coef(fit)
  variance <- stats::vcov(fit)
  warning_values <- trimws(as.character(warnings))
  warning_values <- warning_values[
    !is.na(warning_values) & nzchar(warning_values)
  ]
  warning_text <- one_line(warning_values)
  fit_fail_text <- one_line(fit$fail)
  warning_flag <- nzchar(warning_text)
  failure_warning <- any(grepl(
    "did not converge|failed to converge|infinite coefficient|singular",
    warning_values,
    ignore.case = TRUE
  ), na.rm = TRUE)
  explicit_failure <- nzchar(fit_fail_text)
  coefficient_n <- length(coefficients)
  nonfinite_coefficient_n <- sum(!is.finite(coefficients))
  variance_dim <- dim(variance)
  variance_is_matrix <- is.matrix(variance) && length(variance_dim) == 2L
  variance_is_aligned <- variance_is_matrix &&
    nrow(variance) == coefficient_n &&
    ncol(variance) == coefficient_n
  covariance_dimension <- if (variance_is_matrix) {
    paste(variance_dim, collapse = "x")
  } else {
    "<not-a-matrix>"
  }
  nonfinite_covariance_n <- if (is.numeric(variance)) {
    sum(!is.finite(variance))
  } else {
    length(variance)
  }
  covariance_diagonal <- if (variance_is_matrix) diag(variance) else numeric()
  nonpositive_covariance_diagonal_n <- sum(
    is.finite(covariance_diagonal) & covariance_diagonal <= 0
  )
  covariance_rank <- if (
    variance_is_aligned &&
      nonfinite_covariance_n == 0L &&
      coefficient_n > 0L
  ) {
    tryCatch(qr(variance)$rank, error = function(e) NA_integer_)
  } else {
    NA_integer_
  }
  covariance_rank_failure <- !isTRUE(
    is.finite(covariance_rank) && covariance_rank == coefficient_n
  )
  numerical_failure <-
    coefficient_n == 0L ||
    nonfinite_coefficient_n > 0L ||
    !variance_is_aligned ||
    nonfinite_covariance_n > 0L ||
    length(covariance_diagonal) != coefficient_n ||
    nonpositive_covariance_diagonal_n > 0L ||
    covariance_rank_failure
  hard_gate_failure <- failure_warning || explicit_failure || numerical_failure
  if (hard_gate_failure) {
    failure_detail <- paste0(
      "warning_flag=", warning_flag,
      "; failure_warning_flag=", failure_warning,
      "; explicit_fit_fail_flag=", explicit_failure,
      "; warning_count=", length(unique(warning_values)),
      "; coefficient_count=", coefficient_n,
      "; nonfinite_coefficient_count=", nonfinite_coefficient_n,
      "; covariance_dimension=", covariance_dimension,
      "; covariance_aligned_flag=", variance_is_aligned,
      "; nonfinite_covariance_count=", nonfinite_covariance_n,
      "; nonpositive_covariance_diagonal_count=",
      nonpositive_covariance_diagonal_n,
      "; covariance_rank=",
      if (is.finite(covariance_rank)) covariance_rank else "NA",
      "; covariance_expected_rank=", coefficient_n,
      "; covariance_rank_failure_flag=", covariance_rank_failure,
      "; numerical_failure_flag=", numerical_failure,
      "; hard_gate_failure_flag=", hard_gate_failure
    )
    stop(
      model_id,
      " failed Cox convergence/finite-covariance checks: ",
      failure_detail,
      call. = FALSE
    )
  }
  list(coefficients = coefficients, variance = variance)
}

nelson_aalen_at_time <- function(time, event) {
  time <- as.numeric(time)
  event <- as.integer(event)
  if (any(!is.finite(time) | time <= 0) || any(!event %in% c(0L, 1L))) {
    stop("Nelson-Aalen input contains invalid follow-up or event values.", call. = FALSE)
  }
  event_times <- sort(unique(time[event == 1L]))
  if (!length(event_times)) return(rep(0, length(time)))
  increments <- vapply(event_times, function(t) {
    d <- sum(event == 1L & time == t)
    r <- sum(time >= t)
    if (r <= 0) stop("Invalid Nelson-Aalen risk set.", call. = FALSE)
    d / r
  }, numeric(1))
  cumulative <- cumsum(increments)
  vapply(time, function(t) {
    idx <- findInterval(t, event_times)
    if (idx == 0L) 0 else cumulative[[idx]]
  }, numeric(1))
}

reconstruct_released_nhanes_bmi <- function(
    weight_kg, height_cm, cycle_label) {
  cycle <- as.character(cycle_label)
  invalid_cycle <- !is.na(cycle) & !cycle %in% c("E", "F", "G")
  if (any(invalid_cycle)) {
    stop(
      "NHANES BMI reconstruction encountered an unsupported cycle: ",
      paste(sort(unique(cycle[invalid_cycle])), collapse = ", "),
      call. = FALSE
    )
  }
  raw_bmi <- weight_kg / (height_cm / 100)^2
  scale <- ifelse(cycle == "G", 10, 100)
  floor((raw_bmi + 1e-8) * scale + 0.5) / scale
}

build_nhanes_master <- function(root, paths, store) {
  ledger <- readRDS(paths$nhanes_ledger)
  donor <- readRDS(paths$nhanes_donor)
  ledger <- tibble::as_tibble(ledger)
  donor <- tibble::as_tibble(donor)
  ledger$SEQN <- as_num(ledger$SEQN)
  donor$SEQN <- as_num(donor$participant_id)
  assert_unique_id(ledger, "SEQN", "nhanes_stage1_ledger_v43.rds")
  assert_unique_id(donor, "SEQN", "nhanes_mortality_analysis_ready_v30_0.rds")

  route_fields <- c(
    "mobility_difficulty_routed", "adl_iadl_difficulty_routed",
    "mobility_difficulty_code5_positive", "adl_iadl_difficulty_code5_positive"
  )
  missing_route_fields <- setdiff(route_fields, names(ledger))
  record_assertion(
    store,
    "v43_route_aware_function_fields_present",
    !length(missing_route_fields),
    if (length(missing_route_fields)) paste(missing_route_fields, collapse = ",") else paste(route_fields, collapse = ","),
    "main code-5-missing and code-5-positive sensitivity function components are present in the v43 ledger"
  )
  if (length(missing_route_fields)) {
    stop("The v43 NHANES ledger lacks route-aware function fields: ",
         paste(missing_route_fields, collapse = ", "), call. = FALSE)
  }

  donor_fields <- c(
    "SEQN", "age_years", "sex_code", "height_cm", "weight_kg", "bmi",
    "race_ethnicity", "cycle_label", "smoking_status", "education",
    "income_poverty_ratio", "self_reported_emphysema_or_bronchitis",
    "ever_asthma", "pef_l_min",
    "wtmec6yr", "all_cause_death", "followup_months_exam",
    "followup_years_exam", "psu", "strata", "waist_cm", "phq9_score",
    "low_physical_activity"
  )
  missing_donor <- setdiff(donor_fields, names(donor))
  record_assertion(
    store,
    "verified_v30_donor_fields_present",
    !length(missing_donor),
    if (length(missing_donor)) paste(missing_donor, collapse = ",") else paste(donor_fields, collapse = ","),
    "all frozen NHANES donor and auxiliary fields are present; the obsolete v30 frailty/function proxies and linked-mortality DIABETES/HYPERTEN are not selected"
  )
  donor <- donor[donor_fields]
  names(donor)[names(donor) != "SEQN"] <- paste0("donor_", names(donor)[names(donor) != "SEQN"])
  master <- audited_left_join(ledger, donor, "SEQN", "nhanes_mortality_analysis_ready_v30_0.rds", store)

  linked_rows <- !is.na(master$donor_age_years)
  record_assertion(
    store,
    "v43_ledger_v30_donor_linkage",
    sum(linked_rows) == nrow(master),
    paste0("matched=", sum(linked_rows), "; ledger rows=", nrow(master)),
    "every v43 ledger participant has exactly one covariate-donor row"
  )

  numeric_equal <- function(x, y, tolerance = 1e-10) {
    both_na <- is.na(x) & is.na(y)
    both_value <- is.finite(x) & is.finite(y) & abs(x - y) <= tolerance
    both_na | both_value
  }
  exact_equal <- function(x, y) {
    (is.na(x) & is.na(y)) | (!is.na(x) & !is.na(y) & as.character(x) == as.character(y))
  }
  reconciliation <- list(
    age = numeric_equal(as_num(master$RIDAGEYR), as_num(master$donor_age_years)),
    sex = numeric_equal(as_num(master$RIAGENDR), as_num(master$donor_sex_code)),
    pef = numeric_equal(as_num(master$pef_l_min), as_num(master$donor_pef_l_min), tolerance = 1e-8),
    survey_weight = numeric_equal(as_num(master$wtmec6yr), as_num(master$donor_wtmec6yr), tolerance = 1e-10),
    death = numeric_equal(as_num(master$death), as_num(master$donor_all_cause_death)),
    followup_months = numeric_equal(as_num(master$PERMTH_EXM), as_num(master$donor_followup_months_exam)),
    cycle = exact_equal(master$cycle_label, master$donor_cycle_label),
    psu = numeric_equal(as_num(master$SDMVPSU), as_num(master$donor_psu)),
    strata = numeric_equal(as_num(master$SDMVSTRA), as_num(master$donor_strata))
  )
  for (nm in names(reconciliation)) {
    ok <- reconciliation[[nm]]
    record_assertion(
      store,
      paste0("ledger_donor_", nm, "_exact_reconciliation"),
      all(ok),
      paste0("mismatches=", sum(!ok)),
      "zero mismatches for the shared raw/derived field"
    )
  }

  master$height_cm <- as_num(master$donor_height_cm)
  master$weight_kg <- as_num(master$donor_weight_kg)
  master$bmi <- as_num(master$donor_bmi)
  master$race_ethnicity <- as_chr(master$donor_race_ethnicity)
  master$smoking_status <- as_chr(master$donor_smoking_status)
  master$education <- as_chr(master$donor_education)
  master$income_poverty_ratio <- as_num(master$donor_income_poverty_ratio)
  master$self_reported_emphysema_or_bronchitis <- as_num(master$donor_self_reported_emphysema_or_bronchitis)
  master$ever_asthma <- as_num(master$donor_ever_asthma)
  master$waist_cm <- as_num(master$donor_waist_cm)
  master$phq9_score <- as_num(master$donor_phq9_score)
  master$low_physical_activity <- as_num(master$donor_low_physical_activity)
  master$mobility_difficulty_routed <- as_num(master$mobility_difficulty_routed)
  master$adl_iadl_difficulty_routed <- as_num(master$adl_iadl_difficulty_routed)
  master$mobility_difficulty_code5_positive <- as_num(master$mobility_difficulty_code5_positive)
  master$adl_iadl_difficulty_code5_positive <- as_num(master$adl_iadl_difficulty_code5_positive)
  master$followup_years <- as_num(master$PERMTH_EXM) / 12

  bmi_missing <- is.na(master$bmi)
  anthropometric_parent_missing <- is.na(master$height_cm) | is.na(master$weight_kg)
  observed_triplet <- !bmi_missing & !anthropometric_parent_missing
  reconstructed_bmi <- reconstruct_released_nhanes_bmi(
    master$weight_kg[observed_triplet],
    master$height_cm[observed_triplet],
    master$cycle_label[observed_triplet]
  )
  record_assertion(
    store,
    "nhanes_bmi_missingness_equals_height_or_weight_missingness",
    identical(bmi_missing, anthropometric_parent_missing),
    paste0(
      "BMI missing=", sum(bmi_missing),
      "; height missing=", sum(is.na(master$height_cm)),
      "; weight missing=", sum(is.na(master$weight_kg)),
      "; discordant masks=", sum(bmi_missing != anthropometric_parent_missing)
    ),
    "BMI is missing if and only if height or body weight is missing"
  )
  record_assertion(
    store,
    "nhanes_observed_bmi_matches_published_formula",
    sum(observed_triplet) == 26875L &&
      all(is.finite(reconstructed_bmi)) &&
      all(master$bmi[observed_triplet] == reconstructed_bmi) &&
      all(master$height_cm[observed_triplet] > 0) &&
      all(master$weight_kg[observed_triplet] > 0),
    paste0(
      "observed triplets=", sum(observed_triplet),
      "; exact cycle-specific reconstructions=",
      sum(master$bmi[observed_triplet] == reconstructed_bmi),
      "; E/F two-decimal and G one-decimal mismatches=",
      sum(master$bmi[observed_triplet] != reconstructed_bmi),
      "; invalid parent values=",
      sum(
        master$height_cm[observed_triplet] <= 0 |
          master$weight_kg[observed_triplet] <= 0
      )
    ),
    "all 26875 donor rows with observed BMI/height/weight exactly reproduce the released XPT scale using positive decimal half-up precision (E/F two decimals; G one decimal) and are never overwritten"
  )

  primary_domain <- master$safe_target %in% TRUE & master$pef_A %in% TRUE &
    is.finite(master$PERMTH_EXM) & master$PERMTH_EXM > 0
  record_assertion(
    store,
    "primary_A_only_domain_anchor",
    sum(primary_domain) == 6719L && sum(master$death[primary_domain] == 1L) == 925L,
    paste0(sum(primary_domain), "/", sum(master$death[primary_domain] == 1L)),
    "6719 participants and 925 deaths"
  )
  age60_79_domain <- primary_domain & master$RIDAGEYR >= 60 & master$RIDAGEYR <= 79
  record_assertion(
    store,
    "primary_A_only_age60_79_anchor",
    sum(age60_79_domain) == 3346L && sum(master$death[age60_79_domain] == 1L) == 701L,
    paste0(sum(age60_79_domain), "/", sum(master$death[age60_79_domain] == 1L)),
    "3346 participants and 701 deaths in the prespecified older-adult sensitivity domain"
  )
  record_assertion(
    store,
    "primary_route_aware_function_anchors",
    sum(primary_domain & !is.na(master$mobility_difficulty_routed)) == 6681L &&
      sum(primary_domain & !is.na(master$adl_iadl_difficulty_routed)) == 6557L &&
      sum(primary_domain & !is.na(master$mobility_difficulty_code5_positive)) == 6715L &&
      sum(primary_domain & !is.na(master$adl_iadl_difficulty_code5_positive)) == 6717L,
    paste0(
      "main mobility=", sum(primary_domain & !is.na(master$mobility_difficulty_routed)),
      "; main ADL/IADL=", sum(primary_domain & !is.na(master$adl_iadl_difficulty_routed)),
      "; sensitivity mobility=", sum(primary_domain & !is.na(master$mobility_difficulty_code5_positive)),
      "; sensitivity ADL/IADL=", sum(primary_domain & !is.na(master$adl_iadl_difficulty_code5_positive))
    ),
    "6681/6557 main-rule and 6715/6717 code-5-positive sensitivity observations"
  )

  scale <- utils::read.csv(paths$nhanes_e0, stringsAsFactors = FALSE, check.names = FALSE)
  primary_scale <- scale[scale$quality_layer == "pef_A_only", , drop = FALSE]
  record_assertion(
    store,
    "e0_primary_scale_two_sex_rows",
    nrow(primary_scale) == 2L && setequal(primary_scale$sex_code, c(1, 2)),
    paste0("rows=", nrow(primary_scale), "; sex=", paste(primary_scale$sex_code, collapse = ",")),
    "exactly one frozen A-only E0 row for male and female"
  )
  record_assertion(
    store,
    "e0_primary_scale_positive_sd",
    all(is.finite(primary_scale$weighted_sd_l_min) & primary_scale$weighted_sd_l_min > 0),
    paste(primary_scale$weighted_sd_l_min, collapse = ","),
    "both frozen sex-specific weighted SD values are positive"
  )
  expected_mu <- c(`1` = 544.8197627618421, `2` = 390.0234624295741)
  expected_sd <- c(`1` = 123.5911609847102, `2` = 87.4123992791175)
  observed_mu <- setNames(primary_scale$weighted_mean_l_min, primary_scale$sex_code)
  observed_sd <- setNames(primary_scale$weighted_sd_l_min, primary_scale$sex_code)
  record_assertion(
    store,
    "e0_frozen_numeric_anchor",
    all(abs(observed_mu[names(expected_mu)] - expected_mu) < 1e-10) &&
      all(abs(observed_sd[names(expected_sd)] - expected_sd) < 1e-10),
    paste0("mu=", paste(observed_mu[names(expected_mu)], collapse = ","),
           "; sd=", paste(observed_sd[names(expected_sd)], collapse = ",")),
    "frozen A-only male/female mean and SD equal the Stage 3 blueprint anchors"
  )

  master$E0 <- (observed_mu[as.character(master$RIAGENDR)] - master$pef_l_min) /
    observed_sd[as.character(master$RIAGENDR)]
  master$E0b <- (observed_mu[as.character(master$RIAGENDR)] - master$pef_l_min) / 100
  master$primary_domain <- primary_domain

  backbone <- master[
    master$mec_examined %in% TRUE & is.finite(master$wtmec6yr) & master$wtmec6yr > 0 &
      !is.na(master$design_strata) & !is.na(master$design_psu),
    ,
    drop = FALSE
  ]
  record_assertion(
    store,
    "full_MEC_design_backbone_anchor",
    nrow(backbone) == 29353L && length(unique(backbone$design_strata)) == 45L &&
      length(unique(backbone$design_psu)) == 94L,
    paste0("N=", nrow(backbone), "; strata=", length(unique(backbone$design_strata)),
           "; PSU=", length(unique(backbone$design_psu))),
    "29353 positive-weight MEC rows, 45 cycle-specific strata and 94 cycle-stratum PSUs"
  )
  record_assertion(
    store,
    "primary_domain_retains_design",
    length(unique(master$design_strata[primary_domain])) == 45L &&
      length(unique(master$design_psu[primary_domain])) == 94L,
    paste0("strata=", length(unique(master$design_strata[primary_domain])),
           "; PSU=", length(unique(master$design_psu[primary_domain]))),
    "A-only primary domain retains all 45 strata and 94 PSUs"
  )

  list(master = master, backbone = backbone, primary_scale = primary_scale)
}

freeze_spline_knots <- function(dat) {
  variables <- c("RIDAGEYR", "height_cm", "bmi", "E0")
  rows <- lapply(variables, function(v) {
    q <- weighted_quantile_simple(dat[[v]], dat$wtmec6yr, c(0.05, 0.35, 0.65, 0.95))
    data.frame(
      cohort = "NHANES",
      variable = v,
      n_observed = sum(is.finite(dat[[v]]) & is.finite(dat$wtmec6yr) & dat$wtmec6yr > 0),
      weighted_q05 = q[[1]],
      weighted_q35 = q[[2]],
      weighted_q65 = q[[3]],
      weighted_q95 = q[[4]],
      rule = "outcome-blind weighted q05/q35/q65/q95 in the primary A-only observed-exposure cohort",
      stringsAsFactors = FALSE
    )
  })
  knots <- do.call(rbind, rows)
  values <- knots[c("weighted_q05", "weighted_q35", "weighted_q65", "weighted_q95")]
  if (any(!is.finite(unlist(values)))) stop("One or more frozen NHANES spline knots are non-finite.", call. = FALSE)
  if (any(apply(values, 1, function(x) any(diff(x) <= 0)))) {
    stop("One or more frozen NHANES spline knot sequences are not strictly increasing.", call. = FALSE)
  }
  knots
}

get_knot_row <- function(knots, variable) {
  out <- knots[knots$variable == variable, , drop = FALSE]
  if (nrow(out) != 1L) stop("Expected exactly one knot row for ", variable, call. = FALSE)
  out
}

fixed_ns <- function(x, knot_row, prefix) {
  basis <- splines::ns(
    x,
    knots = c(knot_row$weighted_q35, knot_row$weighted_q65),
    Boundary.knots = c(knot_row$weighted_q05, knot_row$weighted_q95)
  )
  basis <- as.data.frame(basis)
  names(basis) <- paste0(prefix, "_ns", seq_len(ncol(basis)))
  basis
}

restricted_cubic_basis <- function(x, knot_row, prefix = "E0") {
  k <- as.numeric(knot_row[c("weighted_q05", "weighted_q35", "weighted_q65", "weighted_q95")])
  tp3 <- function(z) pmax(z, 0)^3
  nonlinear <- lapply(1:2, function(j) {
    (tp3(x - k[j]) -
       tp3(x - k[3]) * (k[4] - k[j]) / (k[4] - k[3]) +
       tp3(x - k[4]) * (k[3] - k[j]) / (k[4] - k[3])) /
      (k[4] - k[1])^2
  })
  out <- data.frame(x, nonlinear[[1]], nonlinear[[2]])
  names(out) <- c(paste0(prefix, "_linear"), paste0(prefix, "_nonlinear1"), paste0(prefix, "_nonlinear2"))
  out
}

attach_passive_variables <- function(dat, knots) {
  dat$RIAGENDR <- factor(round(as_num(dat$RIAGENDR)), levels = c(1, 2))
  dat$cycle_label <- factor(as_chr(dat$cycle_label), levels = c("E", "F", "G"))
  dat$race_ethnicity <- factor(
    as_chr(dat$race_ethnicity),
    levels = c(
      "Mexican American", "Other Hispanic", "Non-Hispanic White",
      "Non-Hispanic Black", "Other/Multi-Racial"
    )
  )
  dat$smoking_status <- factor(as_chr(dat$smoking_status), levels = c("never", "former", "current"))
  dat$education <- factor(
    as_chr(dat$education),
    levels = c("<9th grade", "9-11th grade", "High school/GED", "Some college/AA", "College graduate+")
  )
  dat$self_reported_emphysema_or_bronchitis <- as_num(dat$self_reported_emphysema_or_bronchitis)
  dat$ever_asthma <- as_num(dat$ever_asthma)
  dat$phq9_score <- pmin(pmax(as_num(dat$phq9_score), 0), 27)
  dat$low_physical_activity <- pmin(pmax(round(as_num(dat$low_physical_activity)), 0), 1)
  dat$mobility_difficulty_routed <- pmin(pmax(round(as_num(dat$mobility_difficulty_routed)), 0), 1)
  dat$adl_iadl_difficulty_routed <- pmin(pmax(round(as_num(dat$adl_iadl_difficulty_routed)), 0), 1)
  dat$depressive_symptoms_phq9_ge10 <- as.integer(dat$phq9_score >= 10)
  dat$nhanes_function_health_proxy_count <- rowSums(cbind(
    dat$mobility_difficulty_routed,
    dat$adl_iadl_difficulty_routed,
    dat$depressive_symptoms_phq9_ge10,
    dat$low_physical_activity
  ))
  mobility_code5_positive_observed <- as_num(dat$mobility_difficulty_code5_positive)
  adl_code5_positive_observed <- as_num(dat$adl_iadl_difficulty_code5_positive)
  dat$mobility_difficulty_code5_positive_completed <- ifelse(
    is.na(mobility_code5_positive_observed),
    dat$mobility_difficulty_routed,
    mobility_code5_positive_observed
  )
  dat$adl_iadl_difficulty_code5_positive_completed <- ifelse(
    is.na(adl_code5_positive_observed),
    dat$adl_iadl_difficulty_routed,
    adl_code5_positive_observed
  )
  dat$nhanes_function_health_proxy_count_code5_positive <- rowSums(cbind(
    dat$mobility_difficulty_code5_positive_completed,
    dat$adl_iadl_difficulty_code5_positive_completed,
    dat$depressive_symptoms_phq9_ge10,
    dat$low_physical_activity
  ))
  dat <- cbind(
    dat,
    fixed_ns(dat$RIDAGEYR, get_knot_row(knots, "RIDAGEYR"), "age"),
    fixed_ns(dat$height_cm, get_knot_row(knots, "height_cm"), "height"),
    fixed_ns(dat$bmi, get_knot_row(knots, "bmi"), "bmi"),
    restricted_cubic_basis(dat$E0, get_knot_row(knots, "E0"), "E0")
  )
  required <- c(
    "E0", "E0b", "age_ns1", "age_ns2", "age_ns3",
    "height_ns1", "height_ns2", "height_ns3", "bmi_ns1", "bmi_ns2", "bmi_ns3",
    "race_ethnicity", "smoking_status", "education", "income_poverty_ratio",
    "self_reported_emphysema_or_bronchitis", "ever_asthma",
    "nhanes_function_health_proxy_count",
    "nhanes_function_health_proxy_count_code5_positive"
  )
  incomplete <- vapply(dat[required], function(x) any(is.na(x)), logical(1))
  if (any(incomplete)) {
    stop("Completed/common-sample data retain missing model fields: ",
         paste(names(incomplete)[incomplete], collapse = ", "), call. = FALSE)
  }
  dat
}

make_mi_input <- function(master, domain_flag) {
  dat <- master[domain_flag %in% TRUE, , drop = FALSE]
  if (!nrow(dat)) stop("Requested NHANES MI domain is empty.", call. = FALSE)
  dat$nelson_aalen <- nelson_aalen_at_time(dat$followup_years, dat$death)
  dat$log_survey_weight <- log(dat$wtmec6yr)
  keep <- c(
    "SEQN", "design_psu", "design_strata", "SDMVPSU", "cycle_label", "RIDAGEYR", "RIAGENDR",
    "pef_l_min", "E0", "E0b", "wtmec6yr", "death", "PERMTH_EXM",
    "followup_years", "nelson_aalen", "log_survey_weight",
    "height_cm", "weight_kg", "bmi", "race_ethnicity", "smoking_status", "education",
    "income_poverty_ratio", "self_reported_emphysema_or_bronchitis",
    "ever_asthma", "waist_cm", "phq9_score", "low_physical_activity",
    "mobility_difficulty_routed", "adl_iadl_difficulty_routed",
    "mobility_difficulty_code5_positive", "adl_iadl_difficulty_code5_positive"
  )
  missing <- setdiff(keep, names(dat))
  if (length(missing)) stop("NHANES MI master lacks fields: ", paste(missing, collapse = ", "), call. = FALSE)
  dat <- dat[keep]
  dat$SEQN <- factor(dat$SEQN)
  dat$design_psu <- factor(dat$design_psu)
  dat$design_strata <- factor(dat$design_strata)
  dat$SDMVPSU <- factor(dat$SDMVPSU)
  if (anyNA(dat$SDMVPSU)) {
    stop("The raw within-stratum PSU code contains missing values in the NHANES MI domain.", call. = FALSE)
  }
  dat$cycle_label <- factor(dat$cycle_label, levels = c("E", "F", "G"))
  dat$RIAGENDR <- factor(dat$RIAGENDR, levels = c(1, 2))
  dat$race_ethnicity <- factor(dat$race_ethnicity)
  dat$smoking_status <- factor(dat$smoking_status, levels = c("never", "former", "current"))
  dat$education <- factor(dat$education)
  for (v in c(
    "self_reported_emphysema_or_bronchitis", "ever_asthma",
    "low_physical_activity", "mobility_difficulty_routed", "adl_iadl_difficulty_routed"
  )) dat[[v]] <- factor(dat[[v]], levels = 0:1)
  dat
}

freeze_mi_specification <- function(mi_data, seed) {
  method <- mice::make.method(mi_data)
  predictor <- mice::make.predictorMatrix(mi_data)
  where <- is.na(mi_data)
  passive_bmi_method <-
    paste0(
      "~I(floor(((weight_kg / (height_cm / 100)^2 + 1e-8) * ",
      "ifelse(cycle_label == 'G', 10, 100)) + 0.5) / ",
      "ifelse(cycle_label == 'G', 10, 100))"
    )
  passive_bmi_contract <- list(
    parent_methods = c(height_cm = "pmm", weight_kg = "pmm"),
    bmi_method = passive_bmi_method,
    bmi_formula_fields = c("height_cm", "weight_kg", "cycle_label"),
    bmi_cycle_precision = c(E = 2L, F = 2L, G = 1L),
    bmi_rounding_rule = "positive_decimal_half_up",
    primary_observed_bmi_exact_reconstruction_n = 6677L,
    waist_method = "pmm",
    visit_sequence_prefix =
      c("height_cm", "waist_cm", "weight_kg", "bmi"),
    bmi_parent_predictors_only = c("height_cm", "weight_kg"),
    anthropometric_equations_exclude_bmi =
      c("height_cm", "weight_kg", "waist_cm"),
    anthropometric_update_graph = list(
      height_cm = character(),
      waist_cm = "height_cm",
      weight_kg = c("height_cm", "waist_cm"),
      bmi = c("height_cm", "weight_kg")
    ),
    weight_predictor_target_whitelist =
      "bmi",
    weight_outcome_covariate = FALSE,
    observed_bmi_preserved = TRUE,
    same_seed_dry_run_replicates = 2L
  )
  never_impute <- c(
    "SEQN", "design_psu", "design_strata", "SDMVPSU", "cycle_label", "RIDAGEYR", "RIAGENDR",
    "pef_l_min", "E0", "E0b", "wtmec6yr", "death", "PERMTH_EXM",
    "followup_years", "nelson_aalen", "log_survey_weight",
    "mobility_difficulty_code5_positive", "adl_iadl_difficulty_code5_positive"
  )
  method[never_impute] <- ""
  method[c(
    "height_cm", "weight_kg", "income_poverty_ratio", "waist_cm", "phq9_score"
  )] <- "pmm"
  method[["bmi"]] <- passive_bmi_method
  method[c("race_ethnicity", "smoking_status", "education")] <- "polyreg"
  method[c(
    "self_reported_emphysema_or_bronchitis", "ever_asthma",
    "low_physical_activity", "mobility_difficulty_routed", "adl_iadl_difficulty_routed"
  )] <- "logreg"
  method[vapply(mi_data, function(x) !anyNA(x), logical(1))] <- ""
  unordered_multicategory_targets <- names(method)[
    nzchar(method) &
      vapply(mi_data, function(x) {
        is.factor(x) && !is.ordered(x) && nlevels(x) > 2L
      }, logical(1))
  ]
  predictor[, "SEQN"] <- 0
  predictor["SEQN", ] <- 0
  # Preserve both public design identifiers in the MI ledger without fitting a
  # singular set of nested fixed effects: cycle-specific stratum plus the raw
  # within-stratum PSU code fully identify the public PSU. Deterministic
  # exposure, time, and weight re-expressions are likewise reduced to one
  # predictor representation apiece.
  predictor[, c(
    "design_psu", "cycle_label", "E0b", "pef_l_min", "wtmec6yr", "PERMTH_EXM",
    "mobility_difficulty_code5_positive", "adl_iadl_difficulty_code5_positive"
  )] <- 0
  # Use an acyclic anthropometric update subgraph to prevent the severe
  # donor-neighbourhood trapping observed when height, weight, BMI, and waist
  # were allowed to update one another reciprocally. This is a numerical FCS
  # specification, not a causal graph.
  predictor[, "weight_kg"] <- 0
  predictor["height_cm", c("waist_cm", "weight_kg", "bmi")] <- 0
  predictor["waist_cm", c("weight_kg", "bmi")] <- 0
  predictor["waist_cm", "height_cm"] <- 1
  predictor["weight_kg", c("height_cm", "waist_cm")] <- 1
  predictor["weight_kg", "bmi"] <- 0
  predictor["bmi", ] <- 0
  predictor["bmi", c("height_cm", "weight_kg")] <- 1
  diag(predictor) <- 0
  active_targets <- names(method)[nzchar(method)]
  visit_sequence <- c(
    intersect(
      passive_bmi_contract$visit_sequence_prefix,
      active_targets
    ),
    setdiff(
      active_targets,
      passive_bmi_contract$visit_sequence_prefix
    )
  )
  list(
    method = method,
    predictor_matrix = predictor,
    where = where,
    visit_sequence = visit_sequence,
    nhanes_passive_bmi = passive_bmi_contract,
    unordered_multicategory_targets = unordered_multicategory_targets,
    maxit = 20L,
    convergence_iteration_checkpoints = c(20L, 40L, 80L),
    maximum_maxit = 80L,
    initial_m = 50L,
    maximum_m = 100L,
    seed = as.integer(seed),
    monte_carlo_error_fraction_max = 0.10,
    convergence_rhat_max = 1.05,
    trace_release_missing_n_min = 20L
  )
}

validate_nhanes_passive_bmi_state <- function(imp, mi_data, mi_spec) {
  contract <- mi_spec$nhanes_passive_bmi
  required <- c("height_cm", "weight_kg", "bmi", "cycle_label")
  if (is.null(contract) || !all(required %in% names(mi_data)) ||
      !all(required %in% names(imp$data))) {
    stop("NHANES passive-BMI validation lacks its frozen fields or contract.",
         call. = FALSE)
  }
  if (!identical(
    as.character(imp$visitSequence),
    as.character(mi_spec$visit_sequence)
  )) {
    stop(
      "NHANES MICE changed the frozen anthropometric visit sequence.",
      call. = FALSE
    )
  }
  missing_bmi <- is.na(mi_data$bmi)
  if (!identical(
    missing_bmi,
    is.na(mi_data$height_cm) | is.na(mi_data$weight_kg)
  )) {
    stop(
      "NHANES BMI missingness no longer equals height-or-weight missingness.",
      call. = FALSE
    )
  }
  if (is.null(imp$where) ||
      !all(unname(imp$where[, "bmi"]) == unname(missing_bmi))) {
    stop("NHANES MICE changed the frozen BMI imputation mask.", call. = FALSE)
  }
  observed_bmi <- !missing_bmi
  reconstructed_observed_bmi <- reconstruct_released_nhanes_bmi(
    mi_data$weight_kg[observed_bmi],
    mi_data$height_cm[observed_bmi],
    mi_data$cycle_label[observed_bmi]
  )
  observed_bmi_exact_reconstruction_n <- sum(
    mi_data$bmi[observed_bmi] == reconstructed_observed_bmi
  )
  if (observed_bmi_exact_reconstruction_n != sum(observed_bmi)) {
    stop(
      "NHANES observed BMI no longer exactly reproduces the frozen ",
      "cycle-specific released-file scale: ",
      observed_bmi_exact_reconstruction_n, "/", sum(observed_bmi),
      call. = FALSE
    )
  }
  maximum_identity_difference <- 0
  observed_bmi_change_n <- 0L
  invalid_completed_parent_n <- 0L
  for (chain in seq_len(imp$m)) {
    completed <- mice::complete(imp, action = chain)
    observed_bmi_change_n <- observed_bmi_change_n + sum(
      completed$bmi[!missing_bmi] != mi_data$bmi[!missing_bmi]
    )
    expected_bmi <- reconstruct_released_nhanes_bmi(
      completed$weight_kg[missing_bmi],
      completed$height_cm[missing_bmi],
      completed$cycle_label[missing_bmi]
    )
    differences <- abs(completed$bmi[missing_bmi] - expected_bmi)
    if (length(differences)) {
      maximum_identity_difference <- max(
        maximum_identity_difference,
        differences
      )
    }
    invalid_completed_parent_n <- invalid_completed_parent_n + sum(
      !is.finite(completed$height_cm) |
        completed$height_cm <= 0 |
        !is.finite(completed$weight_kg) |
        completed$weight_kg <= 0 |
        !is.finite(completed$bmi) |
        completed$bmi <= 0
    )
    rm(completed)
  }
  if (observed_bmi_change_n != 0L ||
      !is.finite(maximum_identity_difference) ||
      maximum_identity_difference > 1e-12 ||
      invalid_completed_parent_n != 0L) {
    stop(
      "NHANES passive-BMI completed-data gate failed: observed BMI changes=",
      observed_bmi_change_n,
      "; maximum identity difference=", maximum_identity_difference,
      "; invalid height/weight/BMI cells=", invalid_completed_parent_n,
      call. = FALSE
    )
  }
  list(
    chains_checked = as.integer(imp$m),
    bmi_missing_n = sum(missing_bmi),
    bmi_missing_by_cycle = as.list(
      stats::setNames(
        as.integer(table(
          factor(
            as.character(mi_data$cycle_label[missing_bmi]),
            levels = c("E", "F", "G")
          )
        )),
        c("E", "F", "G")
      )
    ),
    observed_bmi_n = sum(!missing_bmi),
    observed_bmi_exact_reconstruction_n =
      observed_bmi_exact_reconstruction_n,
    observed_bmi_change_n = observed_bmi_change_n,
    maximum_identity_difference = maximum_identity_difference,
    invalid_completed_parent_n = invalid_completed_parent_n,
    visit_sequence_preserved = TRUE,
    rule = contract$bmi_method
  )
}

record_category_trace_iteration <- function(imp, mi_data, mi_spec) {
  targets <- mi_spec$unordered_multicategory_targets
  if (!length(targets)) {
    return(data.frame(
      variable = character(), category_level = character(),
      iteration = integer(), chain = integer(), missing_n = integer(),
      value = numeric(), stringsAsFactors = FALSE
    ))
  }
  dplyr::bind_rows(lapply(targets, function(variable) {
    levels_expected <- levels(mi_data[[variable]])
    values <- imp$imp[[variable]]
    missing_n <- sum(is.na(mi_data[[variable]]))
    if (is.null(values) || nrow(values) != missing_n || ncol(values) != imp$m ||
        missing_n < 1L || !length(levels_expected)) {
      stop("Invalid current categorical imputation state for ", variable, call. = FALSE)
    }
    dplyr::bind_rows(lapply(seq_len(imp$m), function(chain) {
      observed <- as.character(values[[chain]])
      codes <- match(observed, levels_expected)
      if (length(codes) != missing_n || anyNA(codes)) {
        stop("Categorical imputation contains an invalid level for ", variable, call. = FALSE)
      }
      data.frame(
        variable = variable,
        category_level = levels_expected,
        iteration = as.integer(imp$iteration),
        chain = as.integer(chain),
        missing_n = as.integer(missing_n),
        value = tabulate(codes, nbins = length(levels_expected)) / missing_n,
        stringsAsFactors = FALSE
      )
    }))
  }))
}

assert_nhanes_visit_sequence <- function(imp, mi_spec) {
  if (!identical(
    as.character(imp$visitSequence),
    as.character(mi_spec$visit_sequence)
  )) {
    stop(
      "NHANES MICE changed the frozen visit sequence during an ",
      "iteration or extension.",
      call. = FALSE
    )
  }
  invisible(TRUE)
}

run_mi <- function(mi_data, mi_spec, m, maxit = mi_spec$maxit) {
  maxit <- as.integer(maxit)
  if (!is.finite(maxit) || maxit < 1L) {
    stop("MICE requires at least one monitored iteration.", call. = FALSE)
  }
  imp <- mice::mice(
    data = mi_data,
    m = m,
    maxit = 1L,
    method = mi_spec$method,
    predictorMatrix = mi_spec$predictor_matrix,
    where = mi_spec$where,
    visitSequence = mi_spec$visit_sequence,
    seed = mi_spec$seed,
    printFlag = FALSE,
    remove.collinear = FALSE,
    remove.constant = FALSE
  )
  assert_nhanes_visit_sequence(imp, mi_spec)
  category_trace <- record_category_trace_iteration(imp, mi_data, mi_spec)
  if (maxit > 1L) {
    for (iteration in seq.int(2L, maxit)) {
      imp <- mice::mice.mids(imp, maxit = 1L, printFlag = FALSE)
      assert_nhanes_visit_sequence(imp, mi_spec)
      category_trace <- dplyr::bind_rows(
        category_trace,
        record_category_trace_iteration(imp, mi_data, mi_spec)
      )
    }
  }
  attr(imp, "category_trace") <- category_trace
  imp
}

run_mi_checked <- function(mi_data, mi_spec, m, maxit = mi_spec$maxit) {
  warnings <- character()
  imp <- withCallingHandlers(
    run_mi(mi_data, mi_spec, m = m, maxit = maxit),
    warning = function(w) {
      warnings <<- c(warnings, conditionMessage(w))
      invokeRestart("muffleWarning")
    }
  )
  warnings <- unique(warnings)
  logged_events <- if (is.null(imp$loggedEvents)) 0L else nrow(imp$loggedEvents)
  if (length(warnings) || logged_events > 0L) {
    stop(
      "NHANES MICE emitted numerical warnings or logged events: warnings=",
      if (length(warnings)) paste(warnings, collapse = " | ") else "0",
      "; logged_events=", logged_events,
      call. = FALSE
    )
  }
  attr(imp, "nhanes_passive_bmi_audit") <-
    validate_nhanes_passive_bmi_state(imp, mi_data, mi_spec)
  imp
}

extend_mi_checked <- function(imp, mi_data, mi_spec, additional_iterations) {
  additional_iterations <- as.integer(additional_iterations)
  if (!is.finite(additional_iterations) || additional_iterations < 1L) {
    stop("MICE extension requires at least one additional iteration.", call. = FALSE)
  }
  category_trace <- attr(imp, "category_trace", exact = TRUE)
  if (is.null(category_trace)) {
    category_trace <- data.frame(
      variable = character(), category_level = character(),
      iteration = integer(), chain = integer(), missing_n = integer(),
      value = numeric(), stringsAsFactors = FALSE
    )
  }
  warnings <- character()
  extended <- withCallingHandlers(
    {
      current <- imp
      for (step in seq_len(additional_iterations)) {
        current <- mice::mice.mids(current, maxit = 1L, printFlag = FALSE)
        assert_nhanes_visit_sequence(current, mi_spec)
        category_trace <- dplyr::bind_rows(
          category_trace,
          record_category_trace_iteration(current, mi_data, mi_spec)
        )
      }
      current
    },
    warning = function(w) {
      warnings <<- c(warnings, conditionMessage(w))
      invokeRestart("muffleWarning")
    }
  )
  warnings <- unique(warnings)
  logged_events <- if (is.null(extended$loggedEvents)) 0L else nrow(extended$loggedEvents)
  if (length(warnings) || logged_events > 0L) {
    stop(
      "Extended NHANES MICE emitted numerical warnings or logged events: warnings=",
      if (length(warnings)) paste(warnings, collapse = " | ") else "0",
      "; logged_events=", logged_events,
      call. = FALSE
    )
  }
  attr(extended, "category_trace") <- category_trace
  attr(extended, "nhanes_passive_bmi_audit") <-
    validate_nhanes_passive_bmi_state(extended, mi_data, mi_spec)
  extended
}

mice_chain_convergence_legacy_disabled <- function(imp, mi_data, mi_spec, imputation_id) {
  if (length(imp$iteration) != 1L || !is.numeric(imp$iteration) ||
      !is.finite(imp$iteration) ||
      imp$iteration < 0 || imp$iteration != as.integer(imp$iteration) ||
      length(imp$m) != 1L || !is.numeric(imp$m) || !is.finite(imp$m) ||
      imp$m < 1 || imp$m != as.integer(imp$m)) {
    stop("MICE object has an invalid iteration or chain count.", call. = FALSE)
  }
  iteration_count <- as.integer(imp$iteration)
  chain_count <- as.integer(imp$m)
  imputed_variables <- names(mi_spec$method)[nzchar(mi_spec$method)]
  missing_n <- vapply(mi_data[imputed_variables], function(x) sum(is.na(x)), integer(1))
  imputed_variables <- imputed_variables[missing_n > 0L]
  missing_n <- missing_n[imputed_variables]
  if (!length(imputed_variables)) {
    return(data.frame(
      cohort = "NHANES", imputation_id = imputation_id,
      variable = NA_character_, parameter = "none",
      missing_n = 0L, iterations = iteration_count, chains = chain_count,
      retained_iterations = 0L, applicability = "NOT_APPLICABLE_NO_MISSING",
      rank_normalized_split_rhat = NA_real_, folded_split_rhat = NA_real_,
      rhat = NA_real_, classic_final_half_rhat = NA_real_,
      distinct_trace_values = 0L, median_lag1_ac = NA_real_,
      standardized_last5_shift = NA_real_,
      hard_gate = FALSE, pass = TRUE,
      diagnostic_status = "NOT_APPLICABLE_NO_MISSING",
      detail = "No variable required imputation; chain convergence is not applicable.",
      stringsAsFactors = FALSE
    ))
  }

  split_chains <- function(values) {
    n <- nrow(values)
    half <- floor(n / 2L)
    if (half < 2L) return(NULL)
    cbind(
      values[seq_len(half), , drop = FALSE],
      values[seq.int(n - half + 1L, n), , drop = FALSE]
    )
  }

  basic_rhat <- function(values) {
    within_chain_variances <- apply(values, 2L, stats::var)
    within <- mean(within_chain_variances)
    between <- nrow(values) * stats::var(colMeans(values))
    if (!all(is.finite(c(within_chain_variances, within, between)))) {
      return(NA_real_)
    }
    if (within <= 0) return(NA_real_)
    variance_plus <- ((nrow(values) - 1) / nrow(values)) * within +
      between / nrow(values)
    if (!is.finite(variance_plus) || variance_plus < 0) return(NA_real_)
    max(1, sqrt(variance_plus / within))
  }

  rank_normalize <- function(values) {
    flat <- as.vector(values)
    ranks <- rank(flat, ties.method = "average")
    transformed <- stats::qnorm(
      (ranks - 3 / 8) / (length(ranks) + 1 / 4)
    )
    matrix(transformed, nrow = nrow(values), ncol = ncol(values))
  }

  improved_rhat <- function(values) {
    split <- split_chains(values)
    if (is.null(split) || any(!is.finite(split))) {
      return(list(
        rank_normalized = NA_real_,
        folded = NA_real_,
        maximum = NA_real_,
        degenerate = TRUE
      ))
    }
    degenerate <- length(unique(as.vector(split))) < 2L
    if (degenerate) {
      return(list(
        rank_normalized = NA_real_,
        folded = NA_real_,
        maximum = NA_real_,
        degenerate = TRUE
      ))
    }
    rank_rhat <- basic_rhat(rank_normalize(split))
    folded_values <- abs(split - stats::median(as.vector(split)))
    folded_rhat <- if (length(unique(as.vector(folded_values))) < 2L) {
      1
    } else {
      basic_rhat(rank_normalize(folded_values))
    }
    list(
      rank_normalized = rank_rhat,
      folded = folded_rhat,
      maximum = if (all(is.finite(c(rank_rhat, folded_rhat)))) {
        max(rank_rhat, folded_rhat)
      } else {
        NA_real_
      },
      degenerate = FALSE
    )
  }

  classic_final_half_rhat <- function(values) {
    keep <- seq.int(floor(nrow(values) / 2L) + 1L, nrow(values))
    basic_rhat(values[keep, , drop = FALSE])
  }

  trace_support <- function(variable, parameter) {
    x <- mi_data[[variable]]
    legacy_missing_n_min <- 20L
    unordered_multicategory <- is.factor(x) &&
      !is.ordered(x) &&
      nlevels(x) > 2L
    n_missing <- missing_n[[variable]]
    if (parameter == "chain_sd" && n_missing == 1L) {
      return(list(
        applicability = "NOT_APPLICABLE_SINGLE_MISSING",
        hard_gate = FALSE,
        reason = "a chain SD is undefined for one imputed cell"
      ))
    }
    if (unordered_multicategory) {
      return(list(
        applicability = "SUPPORTIVE_UNORDERED_MULTICATEGORY",
        hard_gate = FALSE,
        reason = "integer-coded unordered-category means/SDs are not a quantitative hard-gate estimand"
      ))
    }
    if (n_missing >= legacy_missing_n_min) {
      return(list(
        applicability = "QUANTITATIVE_HARD",
        hard_gate = TRUE,
        reason = paste0(
          "missing_n>=", legacy_missing_n_min,
          " and the trace summary is quantitatively interpretable"
        )
      ))
    }
    if (n_missing >= 10L) {
      return(list(
        applicability = "SUPPORTIVE_LOW_N_10_19",
        hard_gate = FALSE,
        reason = "coarse low-support trace; R-hat is supportive rather than dispositive"
      ))
    }
    if (n_missing >= 2L) {
      return(list(
        applicability = "DESCRIPTIVE_VERY_LOW_N_2_9",
        hard_gate = FALSE,
        reason = "very low-support trace; report descriptively"
      ))
    }
    list(
      applicability = "NOT_APPLICABLE_SINGLE_MISSING",
      hard_gate = FALSE,
      reason = "one imputed cell cannot support a multi-chain mixing statistic"
    )
  }

  summarize_trace <- function(values) {
    lag1 <- apply(values, 2L, function(x) {
      current <- x[-1L]
      lagged <- x[-length(x)]
      sd_current <- stats::sd(current)
      sd_lagged <- stats::sd(lagged)
      if (!is.finite(sd_current) || !is.finite(sd_lagged) ||
          sd_current == 0 || sd_lagged == 0) {
        return(NA_real_)
      }
      stats::cor(current, lagged)
    })
    median_lag1 <- if (any(is.finite(lag1))) {
      stats::median(lag1[is.finite(lag1)])
    } else {
      NA_real_
    }
    standardized_shift <- NA_real_
    if (nrow(values) >= 10L && all(is.finite(values))) {
      previous <- values[seq.int(nrow(values) - 9L, nrow(values) - 5L), , drop = FALSE]
      final <- values[seq.int(nrow(values) - 4L, nrow(values)), , drop = FALSE]
      scale <- stats::mad(as.vector(final), constant = 1.4826)
      if (!is.finite(scale) || scale <= 0) scale <- stats::sd(as.vector(final))
      if (is.finite(scale) && scale > 0) {
        standardized_shift <- abs(mean(final) - mean(previous)) / scale
      }
    }
    list(
      median_lag1_ac = median_lag1,
      standardized_last5_shift = standardized_shift
    )
  }

  diagnose_array <- function(array, parameter, transform = identity) {
    dplyr::bind_rows(lapply(imputed_variables, function(variable) {
      array_dimensions <- dim(array)
      variable_names <- if (length(array_dimensions) == 3L) dimnames(array)[[1]] else NULL
      array_ok <- !is.null(array) &&
        length(array_dimensions) == 3L &&
        identical(as.integer(array_dimensions[2:3]), c(iteration_count, chain_count)) &&
        !is.null(variable_names) &&
        sum(variable_names == variable, na.rm = TRUE) == 1L
      if (!array_ok) {
        return(data.frame(
          cohort = "NHANES", imputation_id = imputation_id,
          variable = variable, parameter = parameter,
          missing_n = missing_n[[variable]],
          iterations = iteration_count, chains = chain_count,
          retained_iterations = 0L, applicability = "DIAGNOSTIC_ARRAY_INVALID",
          rank_normalized_split_rhat = NA_real_, folded_split_rhat = NA_real_,
          rhat = NA_real_, classic_final_half_rhat = NA_real_,
          distinct_trace_values = 0L, median_lag1_ac = NA_real_,
          standardized_last5_shift = NA_real_,
          hard_gate = TRUE, pass = FALSE, diagnostic_status = "FAIL",
          detail = "MICE chain diagnostic array is missing, ambiguously named, or has dimensions inconsistent with the mids object.",
          stringsAsFactors = FALSE
        ))
      }
      values <- transform(array[variable, , , drop = TRUE])
      if (is.null(dim(values))) values <- matrix(values, ncol = imp$m)
      if (nrow(values) < 6L || ncol(values) < 2L) {
        return(data.frame(
          cohort = "NHANES", imputation_id = imputation_id, variable = variable,
          parameter = parameter, missing_n = missing_n[[variable]],
          iterations = nrow(values), chains = ncol(values), retained_iterations = 0L,
          applicability = "INSUFFICIENT_TRACE_LENGTH",
          rank_normalized_split_rhat = NA_real_, folded_split_rhat = NA_real_,
          rhat = NA_real_, classic_final_half_rhat = NA_real_,
          distinct_trace_values = length(unique(as.vector(values))),
          median_lag1_ac = NA_real_, standardized_last5_shift = NA_real_,
          hard_gate = TRUE, pass = FALSE, diagnostic_status = "FAIL",
          detail = "insufficient iterations or chains", stringsAsFactors = FALSE
        ))
      }
      support <- trace_support(variable, parameter)
      finite <- all(is.finite(values))
      distinct_values <- length(unique(as.vector(values[is.finite(values)])))
      improved <- if (finite) improved_rhat(values) else list(
        rank_normalized = NA_real_,
        folded = NA_real_,
        maximum = NA_real_,
        degenerate = TRUE
      )
      trace_summary <- summarize_trace(values)
      hard_gate <- support$hard_gate
      pass <- if (hard_gate) {
        finite &&
          !improved$degenerate &&
          is.finite(improved$maximum) &&
          improved$maximum <= mi_spec$convergence_rhat_max
      } else {
        TRUE
      }
      data.frame(
        cohort = "NHANES", imputation_id = imputation_id, variable = variable,
        parameter = parameter, missing_n = missing_n[[variable]],
        iterations = iteration_count, chains = chain_count,
        retained_iterations = iteration_count,
        applicability = support$applicability,
        rank_normalized_split_rhat = improved$rank_normalized,
        folded_split_rhat = improved$folded,
        rhat = improved$maximum,
        classic_final_half_rhat = if (finite) classic_final_half_rhat(values) else NA_real_,
        distinct_trace_values = distinct_values,
        median_lag1_ac = trace_summary$median_lag1_ac,
        standardized_last5_shift = trace_summary$standardized_last5_shift,
        hard_gate = hard_gate, pass = pass,
        diagnostic_status = if (hard_gate) {
          if (pass) "PASS" else "FAIL"
        } else {
          support$applicability
        },
        detail = paste0(
          support$reason,
          "; improved_Rhat_threshold=", mi_spec$convergence_rhat_max,
          if (hard_gate && !pass) "; hard-gate mixing failure" else ""
        ),
        stringsAsFactors = FALSE
      )
    }))
  }

  dplyr::bind_rows(
    diagnose_array(imp$chainMean, "chain_mean"),
    diagnose_array(imp$chainVar, "chain_sd", transform = sqrt)
  )
}

mice_chain_trace_legacy_disabled <- function(imp, convergence, imputation_id) {
  arrays <- list(chain_mean = imp$chainMean, chain_sd = sqrt(imp$chainVar))
  release <- convergence[
    convergence$hard_gate %in% TRUE &
      convergence$parameter %in% names(arrays),
    c("variable", "parameter", "missing_n"),
    drop = FALSE
  ]
  if (!nrow(release)) {
    return(data.frame(
      cohort = "NHANES", imputation_id = imputation_id,
      variable = NA_character_, parameter = "none",
      missing_n = 0L, iteration = NA_integer_, chain = NA_integer_,
      value = NA_real_, trace_release_status = "NO_RELEASE_ELIGIBLE_TRACE",
      stringsAsFactors = FALSE
    ))
  }
  dplyr::bind_rows(lapply(seq_len(nrow(release)), function(i) {
    variable <- release$variable[[i]]
    parameter <- release$parameter[[i]]
    values <- arrays[[parameter]][variable, , , drop = TRUE]
    if (is.null(dim(values))) values <- matrix(values, ncol = imp$m)
    grid <- expand.grid(
      iteration = seq_len(nrow(values)),
      chain = seq_len(ncol(values)),
      KEEP.OUT.ATTRS = FALSE,
      stringsAsFactors = FALSE
    )
    data.frame(
      cohort = "NHANES",
      imputation_id = imputation_id,
      variable = variable,
      parameter = parameter,
      missing_n = release$missing_n[[i]],
      iteration = grid$iteration,
      chain = grid$chain,
      value = as.vector(values),
      trace_release_status = "RELEASED_QUANTITATIVE_HARD_GATE",
      stringsAsFactors = FALSE
    )
  }))
}

format_mice_convergence_failures_legacy_disabled <- function(convergence) {
  failed <- convergence[
    convergence$hard_gate %in% TRUE & !(convergence$pass %in% TRUE),
    ,
    drop = FALSE
  ]
  if (!nrow(failed)) return("none")
  paste(
    paste0(
      failed$imputation_id, ":",
      failed$variable, "/", failed$parameter,
      "[missing_n=", failed$missing_n,
      ",rank_Rhat=", signif(failed$rank_normalized_split_rhat, 4),
      ",folded_Rhat=", signif(failed$folded_split_rhat, 4),
      ",max_Rhat=", signif(failed$rhat, 4),
      "]"
    ),
    collapse = "; "
  )
}

mice_category_trace <- function(imp, mi_data, mi_spec) {
  targets <- mi_spec$unordered_multicategory_targets
  empty <- data.frame(
    variable = character(), category_level = character(),
    iteration = integer(), chain = integer(), missing_n = integer(),
    value = numeric(), stringsAsFactors = FALSE
  )
  if (!length(targets)) return(empty)
  trace <- attr(imp, "category_trace", exact = TRUE)
  required <- names(empty)
  if (is.null(trace) || !all(required %in% names(trace))) {
    stop("The monitored unordered-category trace is missing or malformed.", call. = FALSE)
  }
  trace <- trace[required]
  expected_rows <- sum(vapply(targets, function(variable) {
    nlevels(mi_data[[variable]]) * imp$iteration * imp$m
  }, numeric(1)))
  key <- paste(
    trace$variable, trace$category_level, trace$iteration, trace$chain,
    sep = "\r"
  )
  basic_ok <- nrow(trace) == expected_rows &&
    !anyDuplicated(key) &&
    setequal(unique(trace$variable), targets) &&
    all(is.finite(trace$value)) &&
    all(trace$value >= 0 & trace$value <= 1) &&
    all(trace$iteration %in% seq_len(imp$iteration)) &&
    all(trace$chain %in% seq_len(imp$m))
  if (!basic_ok) {
    stop("The monitored unordered-category trace fails its complete-grid contract.", call. = FALSE)
  }
  for (variable in targets) {
    levels_expected <- levels(mi_data[[variable]])
    missing_expected <- sum(is.na(mi_data[[variable]]))
    current <- trace[trace$variable == variable, , drop = FALSE]
    if (!setequal(unique(current$category_level), levels_expected) ||
        any(current$missing_n != missing_expected)) {
      stop("The monitored category levels or missing count changed for ", variable, call. = FALSE)
    }
    sums <- stats::aggregate(value ~ iteration + chain, data = current, FUN = sum)
    grid_ok <- abs(current$value * missing_expected -
                     round(current$value * missing_expected)) <= 1e-10
    if (nrow(sums) != imp$iteration * imp$m ||
        any(abs(sums$value - 1) > 1e-10) || !all(grid_ok)) {
      stop("The monitored category proportions fail simplex/grid checks for ", variable, call. = FALSE)
    }
    final <- current[current$iteration == imp$iteration, , drop = FALSE]
    for (chain in seq_len(imp$m)) {
      values <- as.character(imp$imp[[variable]][[chain]])
      expected <- tabulate(
        match(values, levels_expected),
        nbins = length(levels_expected)
      ) / missing_expected
      chain_final <- final[final$chain == chain, , drop = FALSE]
      observed <- chain_final$value[
        match(levels_expected, chain_final$category_level)
      ]
      if (length(observed) != length(expected) ||
          any(abs(observed - expected) > 1e-12)) {
        stop(
          "The final monitored category proportions do not match mids$imp for ",
          variable,
          call. = FALSE
        )
      }
    }
  }
  trace[
    order(trace$variable, trace$category_level, trace$iteration, trace$chain),
    ,
    drop = FALSE
  ]
}

stage3_split_chains <- function(values) {
  half <- floor(nrow(values) / 2L)
  if (half < 2L) return(NULL)
  cbind(
    values[seq_len(half), , drop = FALSE],
    values[seq.int(nrow(values) - half + 1L, nrow(values)), , drop = FALSE]
  )
}

stage3_basic_rhat <- function(values) {
  within_chain_variances <- apply(values, 2L, stats::var)
  within <- mean(within_chain_variances)
  between <- nrow(values) * stats::var(colMeans(values))
  if (!all(is.finite(c(within_chain_variances, within, between)))) return(NA_real_)
  if (within == 0 && between > 0) return(Inf)
  if (within <= 0) return(NA_real_)
  variance_plus <- ((nrow(values) - 1) / nrow(values)) * within +
    between / nrow(values)
  if (!is.finite(variance_plus) || variance_plus < 0) return(NA_real_)
  sqrt(variance_plus / within)
}

stage3_rank_normalize <- function(values) {
  flat <- as.vector(values)
  ranks <- rank(flat, ties.method = "average")
  matrix(
    stats::qnorm((ranks - 3 / 8) / (length(ranks) + 1 / 4)),
    nrow = nrow(values),
    ncol = ncol(values)
  )
}

stage3_improved_rhat <- function(values) {
  split <- stage3_split_chains(values)
  if (is.null(split) || any(!is.finite(split))) {
    return(list(
      rank_normalized = NA_real_, folded = NA_real_, maximum = NA_real_,
      raw_constant = FALSE, folded_identifiable = FALSE
    ))
  }
  raw_constant <- length(unique(as.vector(split))) < 2L
  if (raw_constant) {
    return(list(
      rank_normalized = NA_real_, folded = NA_real_, maximum = NA_real_,
      raw_constant = TRUE, folded_identifiable = FALSE
    ))
  }
  rank_rhat <- stage3_basic_rhat(stage3_rank_normalize(split))
  folded_values <- abs(split - stats::median(as.vector(split)))
  folded_identifiable <- length(unique(as.vector(folded_values))) >= 2L
  folded_rhat <- if (folded_identifiable) {
    stage3_basic_rhat(stage3_rank_normalize(folded_values))
  } else {
    NA_real_
  }
  components <- c(rank_rhat, folded_rhat)
  components <- components[
    is.finite(components) | is.infinite(components)
  ]
  list(
    rank_normalized = rank_rhat,
    folded = folded_rhat,
    maximum = if (length(components)) max(components) else NA_real_,
    raw_constant = FALSE,
    folded_identifiable = folded_identifiable
  )
}

stage3_classic_final_half_rhat <- function(values) {
  keep <- seq.int(floor(nrow(values) / 2L) + 1L, nrow(values))
  stage3_basic_rhat(values[keep, , drop = FALSE])
}

stage3_summarize_trace <- function(values) {
  lag1 <- apply(values, 2L, function(x) {
    current <- x[-1L]
    lagged <- x[-length(x)]
    if (!all(is.finite(c(current, lagged))) ||
        stats::sd(current) == 0 || stats::sd(lagged) == 0) return(NA_real_)
    stats::cor(current, lagged)
  })
  median_lag1 <- if (any(is.finite(lag1))) {
    stats::median(lag1[is.finite(lag1)])
  } else {
    NA_real_
  }
  standardized_shift <- NA_real_
  if (nrow(values) >= 10L && all(is.finite(values))) {
    previous <- values[
      seq.int(nrow(values) - 9L, nrow(values) - 5L),
      ,
      drop = FALSE
    ]
    final <- values[
      seq.int(nrow(values) - 4L, nrow(values)),
      ,
      drop = FALSE
    ]
    scale <- stats::mad(as.vector(final), constant = 1.4826)
    if (!is.finite(scale) || scale <= 0) scale <- stats::sd(as.vector(final))
    if (is.finite(scale) && scale > 0) {
      standardized_shift <- abs(mean(final) - mean(previous)) / scale
    }
  }
  list(
    median_lag1_ac = median_lag1,
    standardized_last5_shift = standardized_shift
  )
}

mice_chain_convergence <- function(
    imp, mi_data, mi_spec, imputation_id) {
  if (length(imp$iteration) != 1L || !is.numeric(imp$iteration) ||
      !is.finite(imp$iteration) ||
      imp$iteration < 0 || imp$iteration != as.integer(imp$iteration) ||
      length(imp$m) != 1L || !is.numeric(imp$m) || !is.finite(imp$m) ||
      imp$m < 1 || imp$m != as.integer(imp$m)) {
    stop("MICE object has an invalid iteration or chain count.", call. = FALSE)
  }
  iteration_count <- as.integer(imp$iteration)
  chain_count <- as.integer(imp$m)
  imputed_variables <- names(mi_spec$method)[nzchar(mi_spec$method)]
  missing_n <- vapply(
    mi_data[imputed_variables],
    function(x) sum(is.na(x)),
    integer(1)
  )
  imputed_variables <- imputed_variables[missing_n > 0L]
  missing_n <- missing_n[imputed_variables]
  unordered_variables <- intersect(
    imputed_variables,
    mi_spec$unordered_multicategory_targets
  )
  quantitative_variables <- setdiff(imputed_variables, unordered_variables)

  diagnostic_row <- function(
      variable, parameter, category_level, values, n_missing,
      role, applicability, detail_prefix) {
    if (is.null(dim(values))) values <- matrix(values, ncol = chain_count)
    finite <- all(is.finite(values))
    distinct_values <- length(unique(as.vector(values[is.finite(values)])))
    improved <- if (finite && nrow(values) >= 6L && ncol(values) >= 2L) {
      stage3_improved_rhat(values)
    } else {
      list(
        rank_normalized = NA_real_, folded = NA_real_, maximum = NA_real_,
        raw_constant = FALSE, folded_identifiable = FALSE
      )
    }
    trace_summary <- stage3_summarize_trace(values)
    structural_na <- role %in% c("scale", "category_scale") &&
      n_missing == 1L
    supportive <- role == "category_scale" && !structural_na
    constant_acceptable <- improved$raw_constant &&
      role %in% c("scale", "category_location", "category_scale")
    hard_gate <- !structural_na && !supportive && !constant_acceptable
    pass <- if (structural_na || supportive || constant_acceptable) {
      TRUE
    } else {
      finite &&
        nrow(values) >= 6L &&
        ncol(values) >= 2L &&
        !improved$raw_constant &&
        is.finite(improved$rank_normalized) &&
        is.finite(improved$maximum) &&
        improved$maximum <= mi_spec$convergence_rhat_max
    }
    diagnostic_status <- if (structural_na) {
      "NOT_APPLICABLE_SINGLE_MISSING_SD"
    } else if (improved$raw_constant && role == "scale") {
      "NA_CONSTANT_SCALE"
    } else if (improved$raw_constant && role == "category_location") {
      "NA_CONSTANT_LEVEL"
    } else if (improved$raw_constant && role == "category_scale") {
      "NA_CONSTANT_CATEGORY_SCALE"
    } else if (supportive && !improved$folded_identifiable) {
      "SUPPORTIVE_CATEGORY_SCALE_BULK_ONLY"
    } else if (supportive) {
      "SUPPORTIVE_CATEGORY_SCALE"
    } else if (!pass) {
      "FAIL"
    } else if (!improved$folded_identifiable) {
      "PASS_BULK_ONLY_FOLDED_DEGENERATE"
    } else {
      "PASS"
    }
    data.frame(
      cohort = "NHANES", imputation_id = imputation_id,
      variable = variable, parameter = parameter,
      category_level = category_level, missing_n = as.integer(n_missing),
      iterations = nrow(values), chains = ncol(values),
      retained_iterations = nrow(values), applicability = applicability,
      rank_normalized_split_rhat = improved$rank_normalized,
      folded_split_rhat = improved$folded, rhat = improved$maximum,
      folded_identifiable = improved$folded_identifiable,
      raw_trace_constant = improved$raw_constant,
      classic_final_half_rhat = if (finite) {
        stage3_classic_final_half_rhat(values)
      } else {
        NA_real_
      },
      distinct_trace_values = distinct_values,
      median_lag1_ac = trace_summary$median_lag1_ac,
      standardized_last5_shift = trace_summary$standardized_last5_shift,
      hard_gate = hard_gate, pass = pass,
      diagnostic_status = diagnostic_status,
      detail = paste0(
        detail_prefix,
        "; improved_Rhat_threshold=", mi_spec$convergence_rhat_max,
        if (hard_gate && !pass) "; hard-gate mixing failure" else ""
      ),
      stringsAsFactors = FALSE
    )
  }

  diagnose_array <- function(array, parameter, role, transform = identity) {
    dplyr::bind_rows(lapply(quantitative_variables, function(variable) {
      array_dimensions <- dim(array)
      variable_names <- if (length(array_dimensions) == 3L) {
        dimnames(array)[[1]]
      } else {
        NULL
      }
      array_ok <- !is.null(array) &&
        length(array_dimensions) == 3L &&
        identical(
          as.integer(array_dimensions[2:3]),
          c(iteration_count, chain_count)
        ) &&
        !is.null(variable_names) &&
        sum(variable_names == variable, na.rm = TRUE) == 1L
      if (!array_ok) {
        values <- matrix(
          NA_real_,
          nrow = iteration_count,
          ncol = chain_count
        )
        row <- diagnostic_row(
          variable, parameter, NA_character_, values,
          missing_n[[variable]], role, "DIAGNOSTIC_ARRAY_INVALID",
          "MICE chain array is missing, ambiguously named, or dimensionally inconsistent"
        )
        row$hard_gate <- TRUE
        row$pass <- FALSE
        row$diagnostic_status <- "FAIL"
        return(row)
      }
      values <- transform(array[variable, , , drop = TRUE])
      diagnostic_row(
        variable, parameter, NA_character_, values, missing_n[[variable]],
        role,
        if (role == "location") {
          "QUANTITATIVE_LOCATION_HARD"
        } else {
          "QUANTITATIVE_SCALE_HARD_OR_STRUCTURAL_NA"
        },
        if (role == "location") {
          "chain mean is a numerical hard gate regardless of the number of imputed cells"
        } else {
          "chain SD is a numerical hard gate except when one imputed cell makes SD undefined"
        }
      )
    }))
  }

  categorical_trace <- mice_category_trace(imp, mi_data, mi_spec)
  categorical_rows <- dplyr::bind_rows(lapply(
    unordered_variables,
    function(variable) {
      variable_trace <- categorical_trace[
        categorical_trace$variable == variable,
        ,
        drop = FALSE
      ]
      levels_expected <- levels(mi_data[[variable]])
      rows <- dplyr::bind_rows(lapply(
        levels_expected,
        function(category_level) {
          selected <- variable_trace[
            variable_trace$category_level == category_level,
            ,
            drop = FALSE
          ]
          values <- matrix(
            NA_real_,
            nrow = iteration_count,
            ncol = chain_count
          )
          values[cbind(selected$iteration, selected$chain)] <- selected$value
          proportion_row <- diagnostic_row(
            variable,
            paste0("category_proportion[level=", category_level, "]"),
            category_level,
            values,
            missing_n[[variable]],
            "category_location",
            "UNORDERED_CATEGORY_LEVEL_PROPORTION",
            paste0(
              "per-level indicator proportion replaces arbitrary integer-coded factor means; observed_level_n=",
              sum(
                as.character(mi_data[[variable]]) == category_level,
                na.rm = TRUE
              )
            )
          )
          sd_values <- if (missing_n[[variable]] > 1L) {
            sqrt(
              missing_n[[variable]] /
                (missing_n[[variable]] - 1) *
                values * (1 - values)
            )
          } else {
            matrix(
              NA_real_,
              nrow = iteration_count,
              ncol = chain_count
            )
          }
          scale_row <- diagnostic_row(
            variable,
            paste0("category_indicator_sd[level=", category_level, "]"),
            category_level,
            sd_values,
            missing_n[[variable]],
            "category_scale",
            "UNORDERED_CATEGORY_LEVEL_SCALE",
            "sample SD of the per-level indicator; supportive audit only"
          )
          dplyr::bind_rows(proportion_row, scale_row)
        }
      ))
      evaluable_levels <- unique(rows$category_level[
        grepl("^category_proportion", rows$parameter) &
          !rows$raw_trace_constant &
          rows$hard_gate
      ])
      coverage_pass <- length(evaluable_levels) >= 2L
      coverage <- data.frame(
        cohort = "NHANES", imputation_id = imputation_id,
        variable = variable, parameter = "category_level_coverage",
        category_level = NA_character_, missing_n = missing_n[[variable]],
        iterations = iteration_count, chains = chain_count,
        retained_iterations = iteration_count,
        applicability = "UNORDERED_CATEGORY_COVERAGE_HARD",
        rank_normalized_split_rhat = NA_real_,
        folded_split_rhat = NA_real_, rhat = NA_real_,
        folded_identifiable = NA, raw_trace_constant = NA,
        classic_final_half_rhat = NA_real_,
        distinct_trace_values = length(evaluable_levels),
        median_lag1_ac = NA_real_,
        standardized_last5_shift = NA_real_,
        hard_gate = TRUE, pass = coverage_pass,
        diagnostic_status = if (coverage_pass) "PASS" else "FAIL",
        detail = paste0(
          "at least two nonconstant per-level proportion traces required; evaluable_levels=",
          paste(evaluable_levels, collapse = "|")
        ),
        stringsAsFactors = FALSE
      )
      dplyr::bind_rows(rows, coverage)
    }
  ))

  final_variation_rows <- dplyr::bind_rows(lapply(
    imputed_variables,
    function(variable) {
      values <- imp$imp[[variable]]
      valid <- !is.null(values) &&
        nrow(values) == missing_n[[variable]] &&
        ncol(values) == chain_count &&
        !anyNA(values)
      row_varies <- if (valid) {
        apply(
          values,
          1L,
          function(x) length(unique(as.character(x))) > 1L
        )
      } else {
        logical()
      }
      varying_rows <- sum(row_varies)
      variation_pass <- valid && varying_rows > 0L
      data.frame(
        cohort = "NHANES", imputation_id = imputation_id,
        variable = variable,
        parameter = "final_between_imputation_variation",
        category_level = NA_character_, missing_n = missing_n[[variable]],
        iterations = iteration_count, chains = chain_count,
        retained_iterations = 0L,
        applicability = "FINAL_IMPUTATION_VARIATION_HARD",
        rank_normalized_split_rhat = NA_real_,
        folded_split_rhat = NA_real_, rhat = NA_real_,
        folded_identifiable = NA,
        raw_trace_constant = if (valid) !variation_pass else NA,
        classic_final_half_rhat = NA_real_,
        distinct_trace_values = varying_rows,
        median_lag1_ac = NA_real_,
        standardized_last5_shift = NA_real_,
        hard_gate = TRUE, pass = variation_pass,
        diagnostic_status = if (variation_pass) "PASS" else "FAIL",
        detail = paste0(
          "at least one missing cell must vary across the final ", chain_count,
          " imputations; varying_missing_rows=", varying_rows,
          "/", missing_n[[variable]],
          if (!valid) {
            "; final mids$imp object is missing, incomplete, or contains NA"
          } else {
            ""
          }
        ),
        stringsAsFactors = FALSE
      )
    }
  ))

  diagnostics <- dplyr::bind_rows(
    diagnose_array(imp$chainMean, "chain_mean", "location"),
    diagnose_array(imp$chainVar, "chain_sd", "scale", transform = sqrt),
    categorical_rows,
    final_variation_rows
  )
  if (!nrow(diagnostics)) {
    diagnostics <- data.frame(
      cohort = "NHANES", imputation_id = imputation_id,
      variable = NA_character_, parameter = "none",
      category_level = NA_character_, missing_n = 0L,
      iterations = iteration_count, chains = chain_count,
      retained_iterations = 0L,
      applicability = "NOT_APPLICABLE_NO_MISSING",
      rank_normalized_split_rhat = NA_real_,
      folded_split_rhat = NA_real_, rhat = NA_real_,
      folded_identifiable = NA, raw_trace_constant = NA,
      classic_final_half_rhat = NA_real_,
      distinct_trace_values = 0L, median_lag1_ac = NA_real_,
      standardized_last5_shift = NA_real_,
      hard_gate = FALSE, pass = TRUE,
      diagnostic_status = "NOT_APPLICABLE_NO_MISSING",
      detail = "No variable required imputation.",
      stringsAsFactors = FALSE
    )
  }
  diagnostics
}

mice_chain_trace <- function(
    imp, convergence, mi_data, mi_spec, imputation_id) {
  arrays <- list(chain_mean = imp$chainMean, chain_sd = sqrt(imp$chainVar))
  categorical_trace <- mice_category_trace(imp, mi_data, mi_spec)
  release <- convergence[
    convergence$hard_gate %in% TRUE &
      convergence$pass %in% TRUE &
      convergence$missing_n >= mi_spec$trace_release_missing_n_min &
      (
        convergence$parameter %in% names(arrays) |
          grepl("^category_proportion", convergence$parameter)
      ),
    c("variable", "parameter", "category_level", "missing_n"),
    drop = FALSE
  ]
  if (!nrow(release)) {
    return(data.frame(
      cohort = "NHANES", imputation_id = imputation_id,
      variable = NA_character_, parameter = "none",
      category_level = NA_character_, missing_n = 0L,
      iteration = NA_integer_, chain = NA_integer_, value = NA_real_,
      trace_release_status = "NO_RELEASE_ELIGIBLE_TRACE",
      stringsAsFactors = FALSE
    ))
  }
  dplyr::bind_rows(lapply(seq_len(nrow(release)), function(i) {
    variable <- release$variable[[i]]
    parameter <- release$parameter[[i]]
    category_level <- release$category_level[[i]]
    if (parameter %in% names(arrays)) {
      values <- arrays[[parameter]][variable, , , drop = TRUE]
      if (is.null(dim(values))) values <- matrix(values, ncol = imp$m)
    } else {
      selected <- categorical_trace[
        categorical_trace$variable == variable &
          categorical_trace$category_level == category_level,
        ,
        drop = FALSE
      ]
      values <- matrix(
        NA_real_,
        nrow = imp$iteration,
        ncol = imp$m
      )
      values[cbind(selected$iteration, selected$chain)] <- selected$value
    }
    grid <- expand.grid(
      iteration = seq_len(nrow(values)),
      chain = seq_len(ncol(values)),
      KEEP.OUT.ATTRS = FALSE,
      stringsAsFactors = FALSE
    )
    data.frame(
      cohort = "NHANES", imputation_id = imputation_id,
      variable = variable, parameter = parameter,
      category_level = category_level, missing_n = release$missing_n[[i]],
      iteration = grid$iteration, chain = grid$chain,
      value = as.vector(values),
      trace_release_status = "RELEASED_HARD_GATE_AGGREGATE",
      stringsAsFactors = FALSE
    )
  }))
}

format_mice_convergence_failures <- function(convergence) {
  failed <- convergence[
    convergence$hard_gate %in% TRUE & !(convergence$pass %in% TRUE),
    ,
    drop = FALSE
  ]
  if (!nrow(failed)) return("none")
  paste(
    paste0(
      failed$imputation_id, ":",
      failed$variable, "/", failed$parameter,
      "[missing_n=", failed$missing_n,
      ",rank_Rhat=", signif(failed$rank_normalized_split_rhat, 4),
      ",folded_Rhat=", signif(failed$folded_split_rhat, 4),
      ",max_Rhat=", signif(failed$rhat, 4),
      ",status=", failed$diagnostic_status,
      "]"
    ),
    collapse = "; "
  )
}

new_stage3_mice_convergence_error <- function(message, checkpoints) {
  structure(
    list(
      message = one_line(message),
      call = NULL,
      checkpoint_diagnostics = checkpoints
    ),
    class = c("stage3_mice_convergence_error", "error", "condition")
  )
}

run_mi_convergence_schedule <- function(
    mi_data, mi_spec, m, imputation_id, mi_run) {
  checkpoints <- sort(unique(as.integer(
    mi_spec$convergence_iteration_checkpoints
  )))
  if (!length(checkpoints) || anyNA(checkpoints) ||
      any(!is.finite(checkpoints)) || any(checkpoints < 1L) ||
      checkpoints[[1]] != mi_spec$maxit ||
      tail(checkpoints, 1L) != mi_spec$maximum_maxit ||
      any(diff(checkpoints) <= 0L)) {
    stop("The frozen MICE convergence checkpoint schedule is invalid.", call. = FALSE)
  }
  imp <- NULL
  history <- list()
  for (checkpoint_order in seq_along(checkpoints)) {
    target <- checkpoints[[checkpoint_order]]
    imp <- tryCatch(
      {
        if (is.null(imp)) {
          run_mi_checked(mi_data, mi_spec, m = m, maxit = target)
        } else {
          extend_mi_checked(
            imp, mi_data, mi_spec,
            target - as.integer(imp$iteration)
          )
        }
      },
      error = function(e) {
        prior <- dplyr::bind_rows(history)
        stop(new_stage3_mice_convergence_error(
          paste0(
            "MICE failed while advancing to checkpoint ", target,
            " for ", imputation_id, "/", mi_run, ": ",
            conditionMessage(e)
          ),
          prior
        ))
      }
    )
    convergence <- tryCatch(
      mice_chain_convergence(imp, mi_data, mi_spec, imputation_id),
      error = function(e) {
        prior <- dplyr::bind_rows(history)
        stop(new_stage3_mice_convergence_error(
          paste0(
            "MICE convergence diagnostics failed at checkpoint ", target,
            " for ", imputation_id, "/", mi_run, ": ",
            conditionMessage(e)
          ),
          prior
        ))
      }
    )
    convergence$mi_run <- mi_run
    convergence$checkpoint_order <- checkpoint_order
    convergence$checkpoint_iteration <- target
    convergence$selected_checkpoint <- FALSE
    history[[length(history) + 1L]] <- convergence
    failed <- convergence$hard_gate %in% TRUE &
      !(convergence$pass %in% TRUE)
    if (!any(failed)) {
      convergence$selected_checkpoint <- TRUE
      checkpoint_diagnostics <- dplyr::bind_rows(history)
      checkpoint_diagnostics$selected_checkpoint <-
        checkpoint_diagnostics$checkpoint_order == checkpoint_order
      return(list(
        imp = imp,
        final_convergence = convergence,
        checkpoint_diagnostics = checkpoint_diagnostics,
        selected_maxit = target
      ))
    }
  }
  checkpoint_diagnostics <- dplyr::bind_rows(history)
  checkpoint_diagnostics$selected_checkpoint <-
    checkpoint_diagnostics$checkpoint_order == length(checkpoints)
  stop(new_stage3_mice_convergence_error(
    paste0(
      "MICE mixing fails the frozen improved-Rhat <= ",
      mi_spec$convergence_rhat_max,
      " gate through ", tail(checkpoints, 1L), " iterations for ",
      imputation_id, "/", mi_run, ": ",
      format_mice_convergence_failures(tail(history, 1L)[[1L]])
    ),
    checkpoint_diagnostics
  ))
}

model_formulas <- function(
    exposure = "E0", spline_exposure = FALSE,
    health_proxy = "nhanes_function_health_proxy_count") {
  exposure_term <- if (spline_exposure) {
    "E0_linear + E0_nonlinear1 + E0_nonlinear2"
  } else {
    exposure
  }
  a0 <- paste(
    "survival::Surv(followup_years, death) ~", exposure_term,
    "+ age_ns1 + age_ns2 + age_ns3",
    "+ factor(RIAGENDR)",
    "+ height_ns1 + height_ns2 + height_ns3",
    "+ factor(race_ethnicity) + factor(cycle_label)"
  )
  a1 <- paste(
    a0,
    "+ factor(smoking_status)",
    "+ bmi_ns1 + bmi_ns2 + bmi_ns3",
    "+ factor(education) + income_poverty_ratio"
  )
  a2 <- paste(
    a1,
    "+ self_reported_emphysema_or_bronchitis + ever_asthma",
    "+", health_proxy
  )
  list(A0 = stats::as.formula(a0), A1 = stats::as.formula(a1), A2 = stats::as.formula(a2))
}

model_rhs_text <- function(tier = "A1", exposure = "E0") {
  formulas <- model_formulas(exposure)
  formula <- formulas[[tier]]
  paste(deparse(formula[[3]]), collapse = " ")
}

supportive_log_time_a1_terms <- function(exposure = "E0") {
  labels <- attr(
    stats::terms(model_formulas(exposure)[["A1"]]),
    "term.labels"
  )
  removed <- c(exposure, "factor(cycle_label)")
  removal_counts <- vapply(
    removed,
    function(term) sum(labels == term),
    integer(1)
  )
  if (!identical(unname(removal_counts), c(1L, 1L))) {
    stop(
      "The supportive log-time A1 term contract drifted: ",
      paste(names(removal_counts), removal_counts, sep = "=", collapse = "; "),
      call. = FALSE
    )
  }
  retained <- labels[!labels %in% removed]
  if (!length(retained) || any(retained == "factor(cycle_label)")) {
    stop(
      "Could not construct the cycle-absorbed supportive log-time A1 terms.",
      call. = FALSE
    )
  }
  retained
}

supportive_log_time_formula <- function(exposure = "E0") {
  retained <- supportive_log_time_a1_terms(exposure)
  stats::as.formula(paste0(
    "survival::Surv(followup_years, death) ~ ",
    exposure, " + tt(", exposure, ") + ",
    paste(retained, collapse = " + "),
    " + survival::strata(design_strata)",
    " + survival::cluster(design_psu)"
  ))
}

supportive_log_time_proxy_formula <- function(exposure = "E0") {
  retained <- supportive_log_time_a1_terms(exposure)
  stats::as.formula(paste0(
    "~ ", exposure, " + ", exposure, "_log_time_proxy + ",
    paste(retained, collapse = " + ")
  ))
}

supportive_log_time_alias_contract <- function(completed, exposure = "E0") {
  required <- c(
    exposure, "cycle_label", "design_strata", "followup_years", "death"
  )
  missing <- setdiff(required, names(completed))
  if (length(missing)) {
    stop(
      "Supportive log-time alias contract lacks fields: ",
      paste(missing, collapse = ", "),
      call. = FALSE
    )
  }
  cycle <- droplevels(factor(completed$cycle_label))
  design_strata <- droplevels(factor(completed$design_strata))
  cross <- table(design_strata, cycle)
  cycles_per_stratum <- rowSums(cross > 0)
  stratum_matrix <- stats::model.matrix(
    ~ 0 + factor(design_strata),
    data = completed
  )
  cycle_matrix <- stats::model.matrix(
    ~ factor(cycle),
    data = completed
  )
  cycle_matrix <- cycle_matrix[, -1L, drop = FALSE]
  stratum_qr <- qr(stratum_matrix)
  rank_strata <- stratum_qr$rank
  rank_with_cycle <- qr(cbind(stratum_matrix, cycle_matrix))$rank
  cycle_rank_increment <- rank_with_cycle - rank_strata
  cycle_residual_max <- if (ncol(cycle_matrix)) {
    max(abs(qr.resid(stratum_qr, cycle_matrix)))
  } else {
    Inf
  }

  proxy <- completed
  proxy[[paste0(exposure, "_log_time_proxy")]] <-
    proxy[[exposure]] * log(pmax(proxy$followup_years, 1 / 12))
  proxy_matrix <- stats::model.matrix(
    stats::delete.response(
      stats::terms(supportive_log_time_proxy_formula(exposure))
    ),
    data = proxy
  )
  proxy_intercept_columns <- sum(colnames(proxy_matrix) == "(Intercept)")
  proxy_matrix <- proxy_matrix[
    ,
    colnames(proxy_matrix) != "(Intercept)",
    drop = FALSE
  ]
  proxy_columns <- ncol(proxy_matrix)
  proxy_matrix_rank <- qr(proxy_matrix)$rank
  proxy_full_rank <- proxy_matrix_rank == proxy_columns
  followup <- as.numeric(completed$followup_years)
  event <- as.integer(completed$death)
  event_times <- sort(unique(followup[event == 1L]))
  time_origin_ok <-
    length(followup) > 0L &&
    all(is.finite(followup) & followup > 0) &&
    isTRUE(all.equal(min(followup), 1 / 12, tolerance = 1e-12)) &&
    length(event_times) == 147L &&
    all(is.finite(event_times) & event_times > 0) &&
    isTRUE(all.equal(min(event_times), 1 / 12, tolerance = 1e-12))
  policy_pass <-
    nrow(completed) == 6719L &&
    nlevels(design_strata) == 45L &&
    nlevels(cycle) == 3L &&
    all(cycles_per_stratum == 1L) &&
    ncol(cycle_matrix) == 2L &&
    cycle_rank_increment == 0L &&
    is.finite(cycle_residual_max) &&
    cycle_residual_max < 1e-10 &&
    proxy_intercept_columns == 1L &&
    proxy_columns == 23L &&
    proxy_matrix_rank == 23L &&
    proxy_full_rank &&
    time_origin_ok
  list(
    pass = policy_pass,
    n = nrow(completed),
    design_strata = nlevels(design_strata),
    cycles = nlevels(cycle),
    maximum_cycles_per_stratum = max(cycles_per_stratum),
    cycle_dummy_columns = ncol(cycle_matrix),
    stratum_rank = rank_strata,
    rank_with_cycle = rank_with_cycle,
    cycle_rank_increment = cycle_rank_increment,
    cycle_residual_max = cycle_residual_max,
    proxy_intercept_columns = proxy_intercept_columns,
    proxy_columns = proxy_columns,
    proxy_rank = proxy_matrix_rank,
    minimum_followup_years = min(followup),
    nonpositive_followup_n = sum(!is.finite(followup) | followup <= 0),
    distinct_event_times = length(event_times),
    minimum_event_time_years = min(event_times)
  )
}

design_backbone_fields <- function(backbone) {
  required <- c(
    "SEQN", "design_psu", "design_strata", "wtmec6yr", "cycle_label",
    "primary_domain", "pef_A", "pef_A_acc3", "pef_AC", "pef_ABC",
    "pef_l_min", "PERMTH_EXM", "death"
  )
  missing <- setdiff(required, names(backbone))
  if (length(missing)) stop("Full MEC design backbone lacks fields: ", paste(missing, collapse = ", "), call. = FALSE)
  backbone[required]
}

build_full_design_then_domain <- function(completed, backbone, member_ids = NULL, repeated = FALSE) {
  completed$SEQN <- as_num(as.character(completed$SEQN))
  assert_unique_id(completed, "SEQN", "completed NHANES imputation")
  if (is.null(member_ids)) member_ids <- completed$SEQN
  member_ids <- as_num(member_ids)
  base <- design_backbone_fields(backbone)
  model_fields <- setdiff(names(completed), c("design_psu", "design_strata", "wtmec6yr", "cycle_label"))
  merged <- dplyr::left_join(base, completed[model_fields], by = "SEQN", suffix = c("", ".completed"))
  if (nrow(merged) != nrow(base)) stop("Completed covariate merge changed the full MEC backbone row count.", call. = FALSE)
  merged$analysis_domain <- merged$SEQN %in% member_ids
  if (repeated) {
    design <- survey::svydesign(
      ids = ~design_psu + SEQN,
      strata = ~design_strata,
      weights = ~wtmec6yr,
      data = merged,
      nest = TRUE
    )
  } else {
    design <- survey::svydesign(
      ids = ~design_psu,
      strata = ~design_strata,
      weights = ~wtmec6yr,
      data = merged,
      nest = TRUE
    )
  }
  list(full_design = design, domain_design = subset(design, analysis_domain), data = merged)
}

model_matrix_rank <- function(formula, data) {
  terms_no_response <- stats::delete.response(stats::terms(formula))
  mm <- stats::model.matrix(terms_no_response, data = data)
  list(columns = ncol(mm), rank = qr(mm)$rank, full_rank = qr(mm)$rank == ncol(mm))
}

fit_one_survey_cox <- function(completed, backbone, formula, model_id, member_ids = NULL) {
  if (is.null(member_ids)) member_ids <- as_num(as.character(completed$SEQN))
  design_obj <- build_full_design_then_domain(completed, backbone, member_ids)
  domain_data <- design_obj$data[design_obj$data$analysis_domain, , drop = FALSE]
  rank <- model_matrix_rank(formula, domain_data)
  if (!rank$full_rank) stop("Rank-deficient NHANES design matrix for ", model_id, call. = FALSE)
  fit_obj <- capture_fit(survey::svycoxph(formula, design = design_obj$domain_design))
  if (inherits(fit_obj$value, "stage3_fit_error")) {
    stop(model_id, " failed: ", fit_obj$value$error, call. = FALSE)
  }
  fit <- fit_obj$value
  checked <- validate_cox_fit(fit, fit_obj$warnings, model_id)
  design_strata <- length(unique(domain_data$design_strata))
  design_psu <- length(unique(domain_data$design_psu))
  # The full survey Cox object recursively retains the complete design and
  # model data. Downstream pooling uses only these validated compact summaries.
  list(
    coefficients = checked$coefficients,
    variance = checked$variance,
    diagnostics = data.frame(
      cohort = "NHANES",
      model_id = model_id,
      n_participants = nrow(domain_data),
      n_person_period_rows = NA_integer_,
      events = sum(domain_data$death == 1L),
      person_years = sum(domain_data$followup_years),
      weighted_person_years = sum(domain_data$wtmec6yr * domain_data$followup_years),
      design_strata = design_strata,
      design_psu = design_psu,
      design_df = survey::degf(design_obj$domain_design),
      cox_iterations = one_line(fit$iter),
      matrix_columns = rank$columns,
      matrix_rank = rank$rank,
      warnings = one_line(fit_obj$warnings),
      stringsAsFactors = FALSE
    )
  )
}

validate_compact_nhanes_fit_summary <- function(x, context) {
  if (!identical(names(x), c("coefficients", "variance", "diagnostics"))) {
    stop(
      "The NHANES fit retained an unauthorized noncompact component for ",
      context,
      call. = FALSE
    )
  }
  x
}

fit_across_imputations <- function(imp, backbone, knots, formulas, model_prefix, member_selector = NULL) {
  m <- imp$m
  tiers <- names(formulas)
  fits <- setNames(vector("list", length(tiers)), tiers)
  for (tier in tiers) fits[[tier]] <- vector("list", m)
  for (j in seq_len(m)) {
    completed <- mice::complete(imp, action = j)
    completed <- attach_passive_variables(completed, knots)
    member_ids <- if (is.null(member_selector)) {
      as_num(as.character(completed$SEQN))
    } else {
      member_selector(completed, backbone)
    }
    for (tier in tiers) {
      compact_fit <- fit_one_survey_cox(
        completed,
        backbone,
        formulas[[tier]],
        paste0(model_prefix, "_", tolower(tier), "_imp", j),
        member_ids = member_ids
      )
      fits[[tier]][[j]] <- validate_compact_nhanes_fit_summary(
        compact_fit,
        paste0(model_prefix, "/", tier, "/imp", j)
      )
    }
    rm(completed, member_ids, compact_fit)
    if (j %% 5L == 0L || j == m) invisible(gc(verbose = FALSE))
  }
  fits
}

pool_scalar_rubin <- function(fits, term) {
  q <- vapply(fits, function(x) unname(x$coefficients[[term]]), numeric(1))
  u <- vapply(fits, function(x) unname(x$variance[term, term]), numeric(1))
  design_df <- vapply(fits, function(x) {
    if (is.null(x$diagnostics) || !"design_df" %in% names(x$diagnostics)) return(Inf)
    as.numeric(x$diagnostics$design_df[[1]])
  }, numeric(1))
  finite_design_df <- design_df[is.finite(design_df) & design_df > 0]
  df_complete <- if (length(finite_design_df)) min(finite_design_df) else Inf
  pooled <- mice::pool.scalar(
    q,
    u,
    n = if (is.finite(df_complete)) df_complete + 1 else Inf,
    k = 1,
    rule = "rubin1987"
  )
  m <- pooled$m
  qbar <- pooled$qbar
  ubar <- pooled$ubar
  b <- pooled$b
  total <- pooled$t
  se <- sqrt(total)
  relative_increase <- pooled$r
  df <- pooled$df
  statistic <- qbar / se
  p <- if (is.finite(df)) 2 * stats::pt(abs(statistic), df = df, lower.tail = FALSE) else
    2 * stats::pnorm(abs(statistic), lower.tail = FALSE)
  fmi <- pooled$fmi
  critical <- if (is.finite(df)) stats::qt(0.975, df = df) else stats::qnorm(0.975)
  data.frame(
    term = term,
    m = m,
    estimate = qbar,
    standard_error = se,
    ci_low = qbar - critical * se,
    ci_high = qbar + critical * se,
    p_value = p,
    within_variance = ubar,
    between_variance = b,
    total_variance = total,
    df = df,
    complete_data_design_df = df_complete,
    relative_increase_variance = relative_increase,
    fraction_missing_information = fmi,
    relative_efficiency = 1 / (1 + fmi / m),
    monte_carlo_error = sqrt(b / m),
    monte_carlo_error_fraction = sqrt(b / m) / se,
    stringsAsFactors = FALSE
  )
}

pool_multivariate_rubin <- function(fits, terms, test_id) {
  q <- do.call(rbind, lapply(fits, function(x) unname(x$coefficients[terms])))
  u <- lapply(fits, function(x) x$variance[terms, terms, drop = FALSE])
  qbar <- colMeans(q)
  ubar <- Reduce(`+`, u) / length(u)
  b <- stats::cov(q)
  total <- ubar + (1 + 1 / nrow(q)) * b
  if (any(!is.finite(total)) || qr(total)$rank < ncol(total)) {
    stop("Non-finite or singular pooled covariance for ", test_id, call. = FALSE)
  }
  statistic <- as.numeric(t(qbar) %*% solve(total, qbar))
  data.frame(
    test_id = test_id,
    pooling_rule = "multivariate Rubin total covariance; large-sample Wald chi-square",
    terms = paste(terms, collapse = "; "),
    df = length(terms),
    statistic = statistic,
    p_value = stats::pchisq(statistic, df = length(terms), lower.tail = FALSE),
    m = nrow(q),
    stringsAsFactors = FALSE
  )
}

pool_linear_combination_rubin <- function(fits, contrast_builder, label) {
  q <- numeric(length(fits))
  u <- numeric(length(fits))
  for (i in seq_along(fits)) {
    beta <- fits[[i]]$coefficients
    variance <- fits[[i]]$variance
    contrast <- contrast_builder(names(beta))
    if (!identical(names(contrast), names(beta))) {
      stop("Contrast builder did not return a coefficient-aligned named vector for ", label, call. = FALSE)
    }
    q[[i]] <- sum(contrast * beta)
    u[[i]] <- as.numeric(t(contrast) %*% variance %*% contrast)
  }
  proxy_fits <- lapply(seq_along(q), function(i) {
    list(
      coefficients = setNames(q[[i]], label),
      variance = matrix(u[[i]], 1, 1, dimnames = list(label, label)),
      diagnostics = fits[[i]]$diagnostics
    )
  })
  pool_scalar_rubin(proxy_fits, label)
}

registry_row <- function(
    pooled, analysis_id, exposure_id, sample_id, model_tier, quality_layer,
    formula, model_diagnostic, hashes, e0_hash, knot_hash, mi_m, warnings = "") {
  data.frame(
    analysis_id = analysis_id,
    stage = 3L,
    cohort = "NHANES",
    estimand_id = "PN",
    exposure_id = exposure_id,
    sample_id = sample_id,
    model_family = "survey_weighted_cox",
    n = model_diagnostic$n_participants[[1]],
    events = model_diagnostic$events[[1]],
    estimate = pooled$estimate,
    standard_error = pooled$standard_error,
    ci_low = pooled$ci_low,
    ci_high = pooled$ci_high,
    p_value = pooled$p_value,
    gate_status = "PASS",
    model_attempt_status = "ESTIMATED_PASS",
    nonestimability_reason = "",
    script = "R/v43/05_nhanes_stage3_primary_mortality.R",
    spec_sha256 = hashes[["analysis_spec"]],
    manifest_sha256 = hashes[["private_manifest"]],
    warnings = one_line(warnings),
    run_timestamp = format(Sys.time(), tz = "Asia/Shanghai", usetz = TRUE),
    effect_measure = "HR",
    exp_estimate = exp(pooled$estimate),
    exp_ci_low = exp(pooled$ci_low),
    exp_ci_high = exp(pooled$ci_high),
    model_tier = model_tier,
    quality_layer = quality_layer,
    formula_text = paste(deparse(formula), collapse = " "),
    formula_sha256 = digest::digest(paste(deparse(formula), collapse = " "), algo = "sha256"),
    n_participants = model_diagnostic$n_participants[[1]],
    n_person_period_rows = NA_integer_,
    person_years = model_diagnostic$person_years[[1]],
    design_strata = model_diagnostic$design_strata[[1]],
    design_psu = model_diagnostic$design_psu[[1]],
    design_df = model_diagnostic$design_df[[1]],
    mi_m = mi_m,
    mi_seed = NA_integer_,
    fraction_missing_information = pooled$fraction_missing_information,
    relative_efficiency = pooled$relative_efficiency,
    monte_carlo_error = pooled$monte_carlo_error,
    monte_carlo_error_fraction = pooled$monte_carlo_error_fraction,
    e0_scaling_path = "results/v43/nhanes_e0_scale_v43.csv",
    e0_scaling_sha256 = e0_hash,
    spline_knot_registry_path = "results/v43/stage3_nhanes_spline_knot_registry_v43.csv",
    spline_knot_registry_sha256 = knot_hash,
    convergence_diagnostic_id = paste0(analysis_id, "_convergence"),
    time_varying_effect_diagnostic_id = NA_character_,
    stringsAsFactors = FALSE
  )
}

not_estimable_registry_row <- function(
    analysis_id, model_tier, formula, model_diagnostic, hashes, e0_hash,
    knot_hash, mi_m, mi_seed, model_attempt_status,
    nonestimability_reason) {
  empty_pooled <- data.frame(
    estimate = NA_real_,
    standard_error = NA_real_,
    ci_low = NA_real_,
    ci_high = NA_real_,
    p_value = NA_real_,
    fraction_missing_information = NA_real_,
    relative_efficiency = NA_real_,
    monte_carlo_error = NA_real_,
    monte_carlo_error_fraction = NA_real_,
    stringsAsFactors = FALSE
  )
  row <- registry_row(
    pooled = empty_pooled,
    analysis_id = analysis_id,
    exposure_id = "E0",
    sample_id = "nhanes_pef_A_only_age60_79_common_mi",
    model_tier = model_tier,
    quality_layer = paste0(
      "Older-adult boundary sensitivity; same-domain A1/A2 registration; ",
      "NOT_ESTIMABLE with no post-hoc rescue"
    ),
    formula = formula,
    model_diagnostic = model_diagnostic,
    hashes = hashes,
    e0_hash = e0_hash,
    knot_hash = knot_hash,
    mi_m = mi_m,
    warnings = ""
  )
  row$gate_status <- "NOT_ESTIMABLE"
  row$model_attempt_status <- model_attempt_status
  row$nonestimability_reason <- nonestimability_reason
  row$mi_seed <- as.integer(mi_seed)
  row$convergence_diagnostic_id <- NA_character_
  row$time_varying_effect_diagnostic_id <- NA_character_
  row
}

expected_nhanes_registry_ids <- function() {
  c(
    "v43_s3_nhanes_pn_e0_a0",
    "v43_s3_nhanes_pn_e0_a1",
    "v43_s3_nhanes_pn_e0_a2",
    "v43_s3_nhanes_pn_e0_code5_positive_a2",
    "v43_s3_nhanes_pn_e0_age60_79_a1",
    "v43_s3_nhanes_pn_e0_age60_79_a2",
    "v43_s3_nhanes_pn_e0b_a0",
    "v43_s3_nhanes_pn_e0b_a1",
    "v43_s3_nhanes_pn_e0b_a2",
    "v43_s3_nhanes_pn_e0_a0_complete_case",
    "v43_s3_nhanes_pn_e0_a1_complete_case",
    "v43_s3_nhanes_pn_e0_a2_complete_case",
    "v43_s3_nhanes_pn_e0_two_year_landmark_a1",
    "v43_s3_nhanes_pn_e0_pef_A_acc3_a0",
    "v43_s3_nhanes_pn_e0_pef_A_acc3_a1",
    "v43_s3_nhanes_pn_e0_pef_A_acc3_a2",
    "v43_s3_nhanes_pn_e0_pef_A_plus_C_a0",
    "v43_s3_nhanes_pn_e0_pef_A_plus_C_a1",
    "v43_s3_nhanes_pn_e0_pef_A_plus_C_a2",
    "v43_s3_nhanes_pn_e0_pef_ABC_a0",
    "v43_s3_nhanes_pn_e0_pef_ABC_a1",
    "v43_s3_nhanes_pn_e0_pef_ABC_a2",
    "v43_s3_nhanes_pn_e0_gt900_influence_exclusion_a1",
    "v43_s3_nhanes_pn_e0_leave_cycle_E_a1",
    "v43_s3_nhanes_pn_e0_leave_cycle_F_a1",
    "v43_s3_nhanes_pn_e0_leave_cycle_G_a1"
  )
}

expected_nhanes_time_varying_ids <- function() {
  c(
    "v43_s3_nhanes_pn_e0_a1_window_heterogeneity",
    "v43_s3_nhanes_pn_e0_a1_window_0_2",
    "v43_s3_nhanes_pn_e0_a1_window_2_5",
    "v43_s3_nhanes_pn_e0_a1_window_gt5",
    "v43_s3_nhanes_pn_e0_a1_log_time_supportive",
    "v43_s3_nhanes_pn_e0_a1_spline_overall",
    "v43_s3_nhanes_pn_e0_a1_spline_nonlinear"
  )
}

validate_nhanes_time_varying_contract <- function(time_varying) {
  expected_ids <- expected_nhanes_time_varying_ids()
  required <- c(
    "test_id", "pooling_rule", "terms", "df", "statistic", "p_value",
    "diagnostic_role", "diagnostic_status"
  )
  missing <- setdiff(required, names(time_varying))
  if (length(missing)) {
    stop(
      "NHANES time-varying output lacks fields: ",
      paste(missing, collapse = ", "),
      call. = FALSE
    )
  }
  exact_ids <-
    nrow(time_varying) == length(expected_ids) &&
    !anyDuplicated(time_varying$test_id) &&
    setequal(as.character(time_varying$test_id), expected_ids)
  common_numeric_ok <-
    all(is.finite(as.numeric(time_varying$df))) &&
    all(as.numeric(time_varying$df) > 0) &&
    all(is.finite(as.numeric(time_varying$statistic))) &&
    all(is.finite(as.numeric(time_varying$p_value))) &&
    all(as.numeric(time_varying$p_value) >= 0) &&
    all(as.numeric(time_varying$p_value) <= 1)
  text_ok <-
    all(!is.na(time_varying$pooling_rule) &
          nzchar(trimws(as.character(time_varying$pooling_rule)))) &&
    all(!is.na(time_varying$terms) &
          nzchar(trimws(as.character(time_varying$terms)))) &&
    all(as.character(time_varying$diagnostic_status) == "PASS")
  effect_ids <- c(
    "v43_s3_nhanes_pn_e0_a1_window_0_2",
    "v43_s3_nhanes_pn_e0_a1_window_2_5",
    "v43_s3_nhanes_pn_e0_a1_window_gt5",
    "v43_s3_nhanes_pn_e0_a1_log_time_supportive"
  )
  effect_fields <- c(
    "estimate", "standard_error", "ci_low", "ci_high",
    "exp_estimate", "exp_ci_low", "exp_ci_high"
  )
  effect_schema_ok <- all(effect_fields %in% names(time_varying))
  effect <- time_varying$test_id %in% effect_ids
  effect_numeric_ok <- effect_schema_ok &&
    all(vapply(
      effect_fields,
      function(field) all(is.finite(as.numeric(time_varying[[field]][effect]))),
      logical(1)
    )) &&
    all(as.numeric(time_varying$standard_error[effect]) > 0) &&
    all(as.numeric(time_varying$ci_low[effect]) <=
          as.numeric(time_varying$ci_high[effect]))
  effect_exp_consistency_ok <- effect_schema_ok &&
    isTRUE(all.equal(
      as.numeric(time_varying$exp_estimate[effect]),
      exp(as.numeric(time_varying$estimate[effect])),
      tolerance = 1e-12,
      check.attributes = FALSE
    )) &&
    isTRUE(all.equal(
      as.numeric(time_varying$exp_ci_low[effect]),
      exp(as.numeric(time_varying$ci_low[effect])),
      tolerance = 1e-12,
      check.attributes = FALSE
    )) &&
    isTRUE(all.equal(
      as.numeric(time_varying$exp_ci_high[effect]),
      exp(as.numeric(time_varying$ci_high[effect])),
      tolerance = 1e-12,
      check.attributes = FALSE
    ))
  test_only_na_ok <- effect_schema_ok &&
    all(vapply(
      effect_fields,
      function(field) all(is.na(time_varying[[field]][!effect])),
      logical(1)
    ))
  role_map <- setNames(
    c(
      "PRINCIPAL_TIME_HETEROGENEITY",
      rep("PRINCIPAL_WINDOW_ESTIMATE", 3L),
      "SUPPORTIVE_LOG_LINEAR_TIME_TREND",
      rep("EXPOSURE_FUNCTIONAL_FORM", 2L)
    ),
    expected_ids
  )
  ordered <- time_varying[
    match(expected_ids, as.character(time_varying$test_id)),
    ,
    drop = FALSE
  ]
  roles_ok <- identical(
    as.character(ordered$diagnostic_role),
    unname(role_map[expected_ids])
  )
  if (!all(c(
    exact_ids, common_numeric_ok, text_ok, effect_numeric_ok,
    effect_exp_consistency_ok,
    test_only_na_ok, roles_ok
  ))) {
    stop(
      "NHANES time-varying output violates its exact seven-ID/status/value ",
      "contract: exact_ids=", exact_ids,
      "; common_numeric=", common_numeric_ok,
      "; text=", text_ok,
      "; effect_numeric=", effect_numeric_ok,
      "; effect_exp_consistency=", effect_exp_consistency_ok,
      "; test_only_na=", test_only_na_ok,
      "; roles=", roles_ok,
      call. = FALSE
    )
  }
  invisible(TRUE)
}

validate_nhanes_time_varying_references <- function(registry, time_varying) {
  required <- c("analysis_id", "time_varying_effect_diagnostic_id")
  missing <- setdiff(required, names(registry))
  if (length(missing)) {
    stop(
      "NHANES registry lacks time-varying reference fields: ",
      paste(missing, collapse = ", "),
      call. = FALSE
    )
  }
  refs <- trimws(as.character(registry$time_varying_effect_diagnostic_id))
  refs[is.na(registry$time_varying_effect_diagnostic_id) | !nzchar(refs)] <-
    NA_character_
  expected_analysis <- "v43_s3_nhanes_pn_e0_a1"
  expected_reference <-
    "v43_s3_nhanes_pn_e0_a1_window_heterogeneity"
  reference_rows <- which(!is.na(refs))
  exact_reference <-
    length(reference_rows) == 1L &&
    identical(as.character(registry$analysis_id[reference_rows]), expected_analysis) &&
    identical(refs[reference_rows], expected_reference)
  resolved <- all(
    vapply(
      refs[!is.na(refs)],
      function(ref) sum(as.character(time_varying$test_id) == ref) == 1L,
      logical(1)
    )
  )
  if (!exact_reference || !resolved) {
    stop(
      "NHANES primary-registry time-varying references violate the exact ",
      "same-cohort foreign-key contract: nonmissing=", length(reference_rows),
      "; exact_primary_A1_reference=", exact_reference,
      "; all_resolved_once=", resolved,
      call. = FALSE
    )
  }
  invisible(TRUE)
}

validate_nhanes_registry_contract <- function(
    registry, primary_mi_m, primary_mi_seed) {
  expected_ids <- expected_nhanes_registry_ids()
  not_estimable_ids <- c(
    "v43_s3_nhanes_pn_e0_age60_79_a1",
    "v43_s3_nhanes_pn_e0_age60_79_a2"
  )
  required_semantic_fields <- c(
    "analysis_id", "gate_status", "model_attempt_status",
    "nonestimability_reason", "n", "n_participants", "events",
    "estimand_id", "exposure_id", "sample_id", "model_family", "model_tier",
    "formula_text", "formula_sha256", "spec_sha256", "manifest_sha256",
    "mi_m", "mi_seed"
  )
  missing_semantic_fields <- setdiff(required_semantic_fields, names(registry))
  if (length(missing_semantic_fields)) {
    stop(
      "NHANES registry lacks NOT_ESTIMABLE semantic fields: ",
      paste(missing_semantic_fields, collapse = ", "),
      call. = FALSE
    )
  }
  if (
    nrow(registry) != length(expected_ids) ||
      anyDuplicated(registry$analysis_id) ||
      !setequal(registry$analysis_id, expected_ids)
  ) {
    stop(
      "NHANES registry violates the exact 26-ID contract: rows=",
      nrow(registry),
      "; duplicates=", sum(duplicated(registry$analysis_id)),
      "; missing=", paste(setdiff(expected_ids, registry$analysis_id), collapse = "|"),
      "; unexpected=", paste(setdiff(registry$analysis_id, expected_ids), collapse = "|"),
      call. = FALSE
    )
  }

  is_not_estimable <- registry$analysis_id %in% not_estimable_ids
  if (
    sum(is_not_estimable) != 2L ||
      any(is.na(registry$gate_status)) ||
      !all(registry$gate_status[is_not_estimable] == "NOT_ESTIMABLE") ||
      !all(registry$gate_status[!is_not_estimable] == "PASS")
  ) {
    stop(
      "NHANES registry must contain exactly two fixed NOT_ESTIMABLE age-60-79 ",
      "rows and 24 PASS rows.",
      call. = FALSE
    )
  }

  inferential_numeric_fields <- c(
    "estimate", "standard_error", "ci_low", "ci_high", "p_value",
    "exp_estimate", "exp_ci_low", "exp_ci_high",
    "fraction_missing_information", "relative_efficiency",
    "monte_carlo_error", "monte_carlo_error_fraction"
  )
  missing_inferential_fields <- setdiff(inferential_numeric_fields, names(registry))
  if (length(missing_inferential_fields)) {
    stop(
      "NHANES registry lacks inferential numeric fields: ",
      paste(missing_inferential_fields, collapse = ", "),
      call. = FALSE
    )
  }
  pass_numeric <- as.matrix(registry[!is_not_estimable, inferential_numeric_fields, drop = FALSE])
  ne_numeric <- as.matrix(registry[is_not_estimable, inferential_numeric_fields, drop = FALSE])
  if (!all(is.finite(pass_numeric))) {
    stop("A PASS NHANES registry row contains a non-finite inferential numeric value.", call. = FALSE)
  }
  if (
    any(registry$standard_error[!is_not_estimable] <= 0) ||
      any(registry$ci_low[!is_not_estimable] > registry$ci_high[!is_not_estimable])
  ) {
    stop("A PASS NHANES registry row has an invalid SE or confidence interval.", call. = FALSE)
  }
  if (!all(is.na(ne_numeric))) {
    stop(
      "The two NOT_ESTIMABLE NHANES rows must have NA estimates, SEs, ",
      "confidence limits, P values, exponentiated estimates, and MI inferential diagnostics.",
      call. = FALSE
    )
  }

  ne <- registry[match(not_estimable_ids, registry$analysis_id), , drop = FALSE]
  expected_attempt_status <- c(
    "ARCHIVED_NUMERICAL_HARD_GATE_FAILURE",
    "NOT_ATTEMPTED_PANEL_DEPENDENCY"
  )
  if (
    !identical(as.integer(ne$n), c(3346L, 3346L)) ||
      !identical(as.integer(ne$n_participants), c(3346L, 3346L)) ||
      !identical(as.integer(ne$events), c(701L, 701L)) ||
      !identical(as.character(ne$model_tier), c("A1", "A2")) ||
      !identical(as.character(ne$model_attempt_status), expected_attempt_status) ||
      any(!nzchar(ne$nonestimability_reason)) ||
      any(!grepl("no post-hoc rescue", ne$nonestimability_reason, fixed = TRUE)) ||
      any(ne$estimand_id != "PN") ||
      any(ne$exposure_id != "E0") ||
      any(ne$sample_id != "nhanes_pef_A_only_age60_79_common_mi") ||
      any(ne$model_family != "survey_weighted_cox") ||
      any(ne$mi_m != as.integer(primary_mi_m)) ||
      any(ne$mi_seed != as.integer(primary_mi_seed)) ||
      any(!nzchar(ne$formula_text)) ||
      any(!grepl("^[0-9a-fA-F]{64}$", ne$formula_sha256)) ||
      any(!grepl("^[0-9a-fA-F]{64}$", ne$spec_sha256)) ||
      any(!grepl("^[0-9a-fA-F]{64}$", ne$manifest_sha256))
  ) {
    stop(
      "The two fixed age-60-79 NOT_ESTIMABLE rows violate their N/event, ",
      "attempt-status, no-rescue, formula, seed, MI, spec, or manifest contract.",
      call. = FALSE
    )
  }
  if (
    any(registry$model_attempt_status[!is_not_estimable] != "ESTIMATED_PASS") ||
      any(nzchar(registry$nonestimability_reason[!is_not_estimable]))
  ) {
    stop(
      "Every non-age-60-79 registered NHANES row must be ESTIMATED_PASS ",
      "with an empty nonestimability reason.",
      call. = FALSE
    )
  }
  invisible(TRUE)
}

complete_case_mask <- function(master, domain_flag) {
  required <- c(
    "height_cm", "bmi", "race_ethnicity", "smoking_status", "education",
    "income_poverty_ratio", "self_reported_emphysema_or_bronchitis",
    "ever_asthma", "phq9_score", "low_physical_activity",
    "mobility_difficulty_routed", "adl_iadl_difficulty_routed"
  )
  domain_flag %in% TRUE & stats::complete.cases(master[required])
}

fit_complete_case_set <- function(master, backbone, knots, formulas, domain_flag, prefix) {
  keep <- complete_case_mask(master, domain_flag)
  cc <- master[keep, , drop = FALSE]
  cc <- attach_passive_variables(cc, knots)
  fits <- lapply(names(formulas), function(tier) {
    fit_one_survey_cox(cc, backbone, formulas[[tier]], paste0(prefix, "_", tolower(tier)), cc$SEQN)
  })
  names(fits) <- names(formulas)
  fits
}

pooled_from_single_fit <- function(fit, term) {
  b <- unname(fit$coefficients[[term]])
  se <- sqrt(unname(fit$variance[term, term]))
  df <- fit$diagnostics$design_df[[1]]
  critical <- if (is.finite(df)) stats::qt(0.975, df = df) else stats::qnorm(0.975)
  data.frame(
    estimate = b,
    standard_error = se,
    ci_low = b - critical * se,
    ci_high = b + critical * se,
    p_value = if (is.finite(df)) {
      2 * stats::pt(abs(b / se), df = df, lower.tail = FALSE)
    } else {
      2 * stats::pnorm(abs(b / se), lower.tail = FALSE)
    },
    fraction_missing_information = 0,
    relative_efficiency = 1,
    monte_carlo_error = 0,
    monte_carlo_error_fraction = 0,
    stringsAsFactors = FALSE
  )
}

split_followup_windows <- function(completed) {
  cut_starts <- c(0, 2, 5)
  cut_ends <- c(2, 5, Inf)
  labels <- c("0_2", "2_5", "gt5")
  rows <- lapply(seq_len(nrow(completed)), function(i) {
    t <- completed$followup_years[[i]]
    event <- completed$death[[i]]
    if (!is.finite(t) || t <= 0 || !event %in% c(0L, 1L)) return(NULL)
    out <- lapply(seq_along(cut_starts), function(j) {
      if (t <= cut_starts[[j]]) return(NULL)
      stop_time <- min(t, cut_ends[[j]])
      data.frame(
        SEQN = completed$SEQN[[i]],
        tstart = cut_starts[[j]],
        tstop = stop_time,
        split_event = as.integer(event == 1L && t <= cut_ends[[j]]),
        time_window = labels[[j]],
        stringsAsFactors = FALSE
      )
    })
    dplyr::bind_rows(out)
  })
  split <- dplyr::bind_rows(rows)
  split$time_window <- factor(split$time_window, levels = labels)
  split
}

window_formula_A1 <- function(exposure = "E0") {
  rhs <- model_rhs_text("A1", exposure)
  rhs <- sub(paste0("^", exposure, "\\s*\\+"), "", rhs)
  stats::as.formula(paste0(
    "survival::Surv(tstart, tstop, split_event) ~ ", exposure,
    " + ", exposure, ":factor(time_window) + survival::strata(time_window) + ", rhs
  ))
}

fit_one_window_model <- function(completed, backbone, formula, model_id, member_ids = NULL) {
  completed$SEQN <- as_num(as.character(completed$SEQN))
  if (is.null(member_ids)) member_ids <- completed$SEQN
  split <- split_followup_windows(completed[completed$SEQN %in% member_ids, , drop = FALSE])
  covariates <- completed[completed$SEQN %in% member_ids, , drop = FALSE]
  split <- dplyr::left_join(split, covariates, by = "SEQN")
  if (!nrow(split)) stop("Window split produced no analytic rows for ", model_id, call. = FALSE)

  base <- design_backbone_fields(backbone)
  non_domain <- base[!base$SEQN %in% member_ids, , drop = FALSE]
  non_domain$tstart <- 0
  non_domain$tstop <- 1
  non_domain$split_event <- 0L
  non_domain$time_window <- factor("0_2", levels = c("0_2", "2_5", "gt5"))
  non_domain$analysis_domain <- FALSE

  split$analysis_domain <- TRUE
  common <- intersect(names(non_domain), names(split))
  repeated_backbone <- dplyr::bind_rows(
    non_domain[common],
    split[common]
  )
  extra <- setdiff(names(split), names(repeated_backbone))
  if (length(extra)) {
    repeated_backbone <- dplyr::left_join(
      repeated_backbone,
      split[c("SEQN", "tstart", "tstop", extra)],
      by = c("SEQN", "tstart", "tstop")
    )
  }
  rank <- model_matrix_rank(formula, repeated_backbone[repeated_backbone$analysis_domain, , drop = FALSE])
  if (!rank$full_rank) stop("Rank-deficient NHANES window design matrix for ", model_id, call. = FALSE)
  design <- survey::svydesign(
    ids = ~design_psu + SEQN,
    strata = ~design_strata,
    weights = ~wtmec6yr,
    data = repeated_backbone,
    nest = TRUE
  )
  domain <- subset(design, analysis_domain)
  fit_obj <- capture_fit(survey::svycoxph(formula, design = domain))
  if (inherits(fit_obj$value, "stage3_fit_error")) stop(model_id, " failed: ", fit_obj$value$error, call. = FALSE)
  fit <- fit_obj$value
  checked <- validate_cox_fit(fit, fit_obj$warnings, model_id)
  list(
    coefficients = checked$coefficients,
    variance = checked$variance,
    diagnostics = data.frame(
      cohort = "NHANES",
      model_id = model_id,
      n_participants = length(unique(split$SEQN)),
      n_person_period_rows = nrow(split),
      events = sum(split$split_event),
      person_years = sum(split$tstop - split$tstart),
      weighted_person_years = sum(split$wtmec6yr * (split$tstop - split$tstart)),
      design_strata = length(unique(split$design_strata)),
      design_psu = length(unique(split$design_psu)),
      design_df = survey::degf(domain),
      cox_iterations = one_line(fit$iter),
      matrix_columns = rank$columns,
      matrix_rank = rank$rank,
      warnings = one_line(fit_obj$warnings),
      stringsAsFactors = FALSE
    )
  )
}

fit_window_across_imputations <- function(imp, backbone, knots, formula, prefix) {
  out <- vector("list", imp$m)
  for (j in seq_len(imp$m)) {
    completed <- attach_passive_variables(mice::complete(imp, action = j), knots)
    compact_fit <- fit_one_window_model(
      completed,
      backbone,
      formula,
      paste0(prefix, "_imp", j)
    )
    out[[j]] <- validate_compact_nhanes_fit_summary(
      compact_fit,
      paste0(prefix, "/imp", j)
    )
    rm(completed, compact_fit)
    if (j %% 5L == 0L || j == imp$m) invisible(gc(verbose = FALSE))
  }
  out
}

window_contrast_builder <- function(window) {
  force(window)
  function(coef_names) {
    out <- setNames(rep(0, length(coef_names)), coef_names)
    if (!"E0" %in% coef_names) stop("Window model lacks the base E0 coefficient.", call. = FALSE)
    out[["E0"]] <- 1
    if (window != "0_2") {
      candidates <- grep(
        paste0("E0:factor\\(time_window\\)", window, "|factor\\(time_window\\)", window, ":E0"),
        coef_names,
        value = TRUE
      )
      if (length(candidates) != 1L) stop("Could not identify one E0 interaction for window ", window, call. = FALSE)
      out[[candidates]] <- 1
    }
    out
  }
}

fit_log_time_diagnostic_one <- function(completed, model_id) {
  formula <- supportive_log_time_formula("E0")
  alias <- supportive_log_time_alias_contract(completed, "E0")
  if (!isTRUE(alias$pass)) {
    stop(
      "Supportive log-time alias/rank/time contract failed for ", model_id,
      ": strata=", alias$design_strata,
      "; max_cycles_per_stratum=", alias$maximum_cycles_per_stratum,
      "; cycle_dummy_columns=", alias$cycle_dummy_columns,
      "; cycle_rank_increment=", alias$cycle_rank_increment,
      "; cycle_residual_max=", signif(alias$cycle_residual_max, 6),
      "; proxy_columns/rank=", alias$proxy_columns, "/", alias$proxy_rank,
      "; minimum_followup=", alias$minimum_followup_years,
      "; distinct_event_times=", alias$distinct_event_times,
      call. = FALSE
    )
  }
  fit_obj <- capture_fit(survival::coxph(
    formula,
    data = completed,
    weights = wtmec6yr,
    robust = TRUE,
    tt = function(x, t, ...) x * log(pmax(t, 1 / 12)),
    ties = "efron",
    singular.ok = FALSE,
    model = FALSE,
    x = FALSE,
    y = FALSE
  ))
  if (inherits(fit_obj$value, "stage3_fit_error")) stop(model_id, " failed: ", fit_obj$value$error, call. = FALSE)
  fit <- fit_obj$value
  checked <- validate_cox_fit(fit, fit_obj$warnings, model_id)
  coefficient_names <- names(checked$coefficients)
  corrected_dimension_ok <-
    length(checked$coefficients) == 23L &&
    identical(dim(checked$variance), c(23L, 23L)) &&
    sum(grepl("^tt\\(E0\\)$", coefficient_names)) == 1L &&
    !any(grepl("cycle_label", coefficient_names, fixed = TRUE))
  if (!corrected_dimension_ok) {
    stop(
      model_id,
      " violates the corrected 23-coefficient supportive-log-time contract: ",
      "coefficient_count=", length(checked$coefficients),
      "; covariance_dimension=", paste(dim(checked$variance), collapse = "x"),
      "; tt_terms=", sum(grepl("^tt\\(E0\\)$", coefficient_names)),
      "; cycle_terms=", sum(grepl("cycle_label", coefficient_names, fixed = TRUE)),
      call. = FALSE
    )
  }
  complete_data_design_df <- length(unique(completed$design_psu)) -
    length(unique(completed$design_strata))
  if (!is.finite(complete_data_design_df) || complete_data_design_df <= 0) {
    stop("Supportive log-time diagnostic has invalid public-design degrees of freedom.", call. = FALSE)
  }
  list(
    coefficients = checked$coefficients,
    variance = checked$variance,
    diagnostics = data.frame(
      cohort = "NHANES",
      model_id = model_id,
      n_participants = nrow(completed),
      n_person_period_rows = NA_integer_,
      events = sum(completed$death),
      person_years = sum(completed$followup_years),
      weighted_person_years = sum(completed$wtmec6yr * completed$followup_years),
      design_strata = length(unique(completed$design_strata)),
      design_psu = length(unique(completed$design_psu)),
      design_df = complete_data_design_df,
      design_df_source = "public PSU count minus public stratum count",
      cox_iterations = one_line(fit$iter),
      matrix_columns = alias$proxy_columns,
      matrix_rank = alias$proxy_rank,
      cycle_absorbed_by_strata = TRUE,
      cycle_absorbed_df = alias$cycle_dummy_columns,
      cycle_rank_increment = alias$cycle_rank_increment,
      cycle_residual_max = alias$cycle_residual_max,
      distinct_event_times = alias$distinct_event_times,
      minimum_event_time_years = alias$minimum_event_time_years,
      ties_method = "efron",
      singular_ok = FALSE,
      warnings = one_line(fit_obj$warnings),
      stringsAsFactors = FALSE
    )
  )
}

fit_log_time_across_imputations <- function(imp, knots, prefix) {
  out <- vector("list", imp$m)
  for (j in seq_len(imp$m)) {
    completed <- attach_passive_variables(mice::complete(imp, action = j), knots)
    compact_fit <- fit_log_time_diagnostic_one(
      completed,
      paste0(prefix, "_imp", j)
    )
    out[[j]] <- validate_compact_nhanes_fit_summary(
      compact_fit,
      paste0(prefix, "/imp", j)
    )
    rm(completed, compact_fit)
    if (j %% 5L == 0L || j == imp$m) invisible(gc(verbose = FALSE))
  }
  out
}

make_sample_event_audit <- function(master, backbone, joins, assertions) {
  definitions <- list(
    full_MEC_design_backbone = backbone$mec_examined %in% TRUE,
    safe_target = master$safe_target %in% TRUE,
    pef_A_only = master$primary_domain %in% TRUE,
    pef_A_acc3 = master$pef_A_acc3 %in% TRUE & master$PERMTH_EXM > 0,
    pef_A_plus_C = master$pef_AC %in% TRUE & master$PERMTH_EXM > 0,
    pef_ABC = master$pef_ABC %in% TRUE & master$PERMTH_EXM > 0
  )
  overall <- dplyr::bind_rows(lapply(names(definitions), function(id) {
    source <- if (id == "full_MEC_design_backbone") backbone else master
    flag <- definitions[[id]]
    data.frame(
      cohort = "NHANES",
      audit_type = "sample",
      stratum = id,
      n_people = sum(flag),
      transition_rows = NA_integer_,
      deaths = sum(source$death[flag] == 1L, na.rm = TRUE),
      community_psu = length(unique(source$design_psu[flag])),
      detail = "person-level linked mortality sample; counts are descriptive anchors, not model results",
      stringsAsFactors = FALSE
    )
  }))
  by_cycle <- master |>
    dplyr::filter(primary_domain) |>
    dplyr::group_by(cycle_label) |>
    dplyr::summarise(
      n_people = dplyr::n(),
      transition_rows = NA_integer_,
      deaths = sum(death),
      community_psu = dplyr::n_distinct(design_psu),
      .groups = "drop"
    ) |>
    dplyr::mutate(
      cohort = "NHANES", audit_type = "cycle", stratum = as.character(cycle_label),
      detail = "primary A-only domain by NHANES cycle", .before = 1
    ) |>
    dplyr::select(-cycle_label)
  age60_79 <- master$primary_domain %in% TRUE &
    master$RIDAGEYR >= 60 & master$RIDAGEYR <= 79
  age60_79_row <- data.frame(
    cohort = "NHANES",
    audit_type = "registered_sensitivity",
    stratum = "pef_A_only_age60_79",
    n_people = sum(age60_79),
    transition_rows = NA_integer_,
    deaths = sum(master$death[age60_79] == 1L, na.rm = TRUE),
    community_psu = length(unique(master$design_psu[age60_79])),
    analysis_action = "NOT_ESTIMABLE",
    detail = paste0(
      "Registered age-60-79 A1/A2 sensitivity: N=3346, events=701. ",
      "Archived first-imputation A1 failed the finite-coefficient/covariance ",
      "numerical hard gate; paired A2 was not attempted under the all-or-none ",
      "same-domain rule; no post-hoc rescue model was attempted."
    ),
    stringsAsFactors = FALSE
  )
  if (
    age60_79_row$n_people != 3346L ||
      age60_79_row$deaths != 701L ||
      age60_79_row$analysis_action != "NOT_ESTIMABLE"
  ) {
    stop(
      "The age-60-79 registered-sensitivity audit row violates its fixed ",
      "N=3346/events=701/NOT_ESTIMABLE contract.",
      call. = FALSE
    )
  }
  list(
    overall = dplyr::bind_rows(overall, by_cycle, age60_79_row),
    joins = joins,
    assertions = assertions
  )
}

factor_level_audit <- function(master, domain_flag) {
  dat <- master[domain_flag %in% TRUE, , drop = FALSE]
  variables <- c("cycle_label", "RIAGENDR", "race_ethnicity", "smoking_status", "education")
  dplyr::bind_rows(lapply(variables, function(v) {
    tab <- table(dat[[v]], dat$cycle_label, useNA = "ifany")
    rows <- as.data.frame(tab, stringsAsFactors = FALSE)
    names(rows) <- c("level", "cycle_label", "n")
    rows$cohort <- "NHANES"
    rows$variable <- v
    rows$sparse_lt10 <- rows$n > 0 & rows$n < 10
    rows[, c("cohort", "variable", "level", "cycle_label", "n", "sparse_lt10")]
  }))
}

missingness_audit <- function(master, domain_flag) {
  variables <- c(
    "height_cm", "weight_kg", "bmi", "waist_cm",
    "race_ethnicity", "smoking_status", "education",
    "income_poverty_ratio", "self_reported_emphysema_or_bronchitis",
    "ever_asthma", "phq9_score", "low_physical_activity",
    "mobility_difficulty_routed", "adl_iadl_difficulty_routed",
    "mobility_difficulty_code5_positive", "adl_iadl_difficulty_code5_positive"
  )
  dat <- master[domain_flag %in% TRUE, , drop = FALSE]
  dplyr::bind_rows(lapply(variables, function(v) {
    data.frame(
      cohort = "NHANES",
      variable = v,
      n = nrow(dat),
      missing_n = sum(is.na(dat[[v]])),
      missing_fraction = mean(is.na(dat[[v]])),
      stringsAsFactors = FALSE
    )
  }))
}

run_domain_mi_models <- function(
    master, backbone, knots, domain_flag, formulas, model_prefix, seed,
  exposure_term = "E0") {
  mi_data <- make_mi_input(master, domain_flag)
  mi_spec <- freeze_mi_specification(mi_data, seed)
  m50_run <- run_mi_convergence_schedule(
    mi_data = mi_data,
    mi_spec = mi_spec,
    m = mi_spec$initial_m,
    imputation_id = model_prefix,
    mi_run = paste0("m", mi_spec$initial_m)
  )
  imp <- m50_run$imp
  final_chain_convergence <- m50_run$final_convergence
  chain_convergence <- m50_run$checkpoint_diagnostics
  selected_maxit <- m50_run$selected_maxit
  fits <- fit_across_imputations(imp, backbone, knots, formulas, model_prefix)
  pooled <- lapply(names(fits), function(tier) pool_scalar_rubin(fits[[tier]], exposure_term))
  names(pooled) <- names(fits)
  maximum_mce_fraction <- max(vapply(pooled, function(x) x$monte_carlo_error_fraction, numeric(1)))
  if (maximum_mce_fraction > mi_spec$monte_carlo_error_fraction_max) {
    m100_run <- tryCatch(
      run_mi_convergence_schedule(
        mi_data = mi_data,
        mi_spec = mi_spec,
        m = mi_spec$maximum_m,
        imputation_id = model_prefix,
        mi_run = paste0("m", mi_spec$maximum_m)
      ),
      stage3_mice_convergence_error = function(e) {
        e$checkpoint_diagnostics <- dplyr::bind_rows(
          chain_convergence,
          e$checkpoint_diagnostics
        )
        stop(e)
      }
    )
    imp <- m100_run$imp
    final_chain_convergence <- m100_run$final_convergence
    chain_convergence <- dplyr::bind_rows(
      chain_convergence,
      m100_run$checkpoint_diagnostics
    )
    selected_maxit <- m100_run$selected_maxit
    fits <- fit_across_imputations(imp, backbone, knots, formulas, model_prefix)
    pooled <- lapply(names(fits), function(tier) pool_scalar_rubin(fits[[tier]], exposure_term))
    names(pooled) <- names(fits)
    maximum_mce_fraction <- max(vapply(pooled, function(x) x$monte_carlo_error_fraction, numeric(1)))
  }
  if (maximum_mce_fraction > mi_spec$monte_carlo_error_fraction_max) {
    stop("MI Monte Carlo error remains above 10% of the pooled exposure SE after 100 imputations for ",
         model_prefix, call. = FALSE)
  }
  mi_spec$selected_maxit <- selected_maxit
  mi_spec$selected_m <- as.integer(imp$m)
  diagnostics <- dplyr::bind_rows(lapply(fits, function(tier_fits) {
    dplyr::bind_rows(lapply(tier_fits, `[[`, "diagnostics"))
  }))
  mi_diagnostics <- dplyr::bind_rows(lapply(names(pooled), function(tier) {
    cbind(
      data.frame(
        cohort = "NHANES",
        model_tier = tier,
        exposure_id = exposure_term,
        model_prefix = model_prefix,
        logged_mice_events = if (is.null(imp$loggedEvents)) 0L else nrow(imp$loggedEvents),
        stringsAsFactors = FALSE
      ),
      pooled[[tier]]
    )
  }))
  list(
    mi_data = mi_data,
    mi_spec = mi_spec,
    imp = imp,
    fits = fits,
    pooled = pooled,
    diagnostics = diagnostics,
    mi_diagnostics = mi_diagnostics,
    chain_convergence = chain_convergence,
    final_chain_convergence = final_chain_convergence,
    mi_trace = mice_chain_trace(
      imp, final_chain_convergence, mi_data, mi_spec, model_prefix
    )
  )
}

make_registry_from_mi <- function(
    result, formulas, analysis_stem, exposure_id, sample_id, quality_layer,
    hashes, e0_hash, knot_hash) {
  dplyr::bind_rows(lapply(names(result$pooled), function(tier) {
    diag <- result$fits[[tier]][[1]]$diagnostics
    registry_row(
      result$pooled[[tier]],
      analysis_id = paste0(analysis_stem, "_", tolower(tier)),
      exposure_id = exposure_id,
      sample_id = sample_id,
      model_tier = tier,
      quality_layer = quality_layer,
      formula = formulas[[tier]],
      model_diagnostic = diag,
      hashes = hashes,
      e0_hash = e0_hash,
      knot_hash = knot_hash,
      mi_m = result$imp$m,
      warnings = vapply(result$fits[[tier]], function(x) x$diagnostics$warnings, character(1))
    )
  }))
}

fit_subset_from_existing_imp <- function(
    imp, backbone, knots, formulas, member_ids, model_prefix, exposure_term = "E0") {
  selector <- function(completed, backbone) {
    intersect(as_num(as.character(completed$SEQN)), as_num(member_ids))
  }
  fits <- fit_across_imputations(
    imp, backbone, knots, formulas, model_prefix, member_selector = selector
  )
  pooled <- lapply(names(fits), function(tier) pool_scalar_rubin(fits[[tier]], exposure_term))
  names(pooled) <- names(fits)
  diagnostics <- dplyr::bind_rows(lapply(fits, function(tier_fits) {
    dplyr::bind_rows(lapply(tier_fits, `[[`, "diagnostics"))
  }))
  list(imp = imp, fits = fits, pooled = pooled, diagnostics = diagnostics)
}

fit_two_year_landmark_from_existing_imp <- function(
    imp, backbone, knots, formula, model_prefix, exposure_term = "E0") {
  fits <- lapply(seq_len(imp$m), function(j) {
    completed <- attach_passive_variables(mice::complete(imp, action = j), knots)
    completed$landmark_tstart_years <- 2
    member_ids <- as_num(as.character(completed$SEQN))[
      completed$followup_years > 2
    ]
    fit <- fit_one_survey_cox(
      completed,
      backbone,
      formula,
      paste0(model_prefix, "_imp", j),
      member_ids = member_ids
    )
    landmark_data <- completed[
      as_num(as.character(completed$SEQN)) %in% member_ids,
      ,
      drop = FALSE
    ]
    post_landmark_years <- landmark_data$followup_years - 2
    if (!nrow(landmark_data) || any(!is.finite(post_landmark_years) | post_landmark_years <= 0)) {
      stop("The NHANES two-year landmark risk set is empty or has invalid post-landmark time.",
           call. = FALSE)
    }
    fit$diagnostics$person_years <- sum(post_landmark_years)
    fit$diagnostics$weighted_person_years <- sum(
      landmark_data$wtmec6yr * post_landmark_years
    )
    fit$diagnostics$landmark_start_years <- 2
    fit$diagnostics$conditioning_event <- "alive and linked follow-up beyond 2 years"
    fit
  })
  pooled <- pool_scalar_rubin(fits, exposure_term)
  list(
    imp = imp,
    fits = list(A1 = fits),
    pooled = list(A1 = pooled),
    diagnostics = dplyr::bind_rows(lapply(fits, `[[`, "diagnostics"))
  )
}

run_authorized_stage3 <- function(root, authorization, output_root) {
  paths <- authorization$paths
  out_dir <- file.path(output_root, "results", "v43")
  log_dir <- file.path(output_root, "logs", "v43")
  qa_dir <- file.path(output_root, "output", "qa", "v43")
  sensitive_dir <- file.path(output_root, "derived_sensitive", "v43")
  dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)
  dir.create(log_dir, recursive = TRUE, showWarnings = FALSE)
  dir.create(qa_dir, recursive = TRUE, showWarnings = FALSE)
  dir.create(sensitive_dir, recursive = TRUE, showWarnings = FALSE)

  spec <- yaml::read_yaml(paths$spec)
  store <- new_audit_store()
  built <- build_nhanes_master(root, paths, store)
  master <- built$master
  backbone <- built$backbone
  primary_scale <- built$primary_scale
  primary <- master[master$primary_domain %in% TRUE, , drop = FALSE]

  design_audit <- data.frame(
    cohort = "NHANES",
    design_stage = c("full_positive_weight_MEC_backbone", "primary_A_only_domain"),
    n = c(nrow(backbone), nrow(primary)),
    deaths = c(sum(backbone$death == 1L, na.rm = TRUE), sum(primary$death == 1L, na.rm = TRUE)),
    design_strata = c(
      length(unique(backbone$design_strata)),
      length(unique(primary$design_strata))
    ),
    design_psu = c(
      length(unique(backbone$design_psu)),
      length(unique(primary$design_psu))
    ),
    construction_order = c(
      "svydesign backbone is constructed before every analytic domain subset",
      "domain subset is applied only after the full MEC design exists"
    ),
    stringsAsFactors = FALSE
  )
  readr::write_csv(
    design_audit,
    file.path(out_dir, "stage3_nhanes_design_audit_v43.csv")
  )

  record_assertion(
    store,
    "linked_mortality_contributing_causes_prohibited",
    !any(c("DIABETES", "HYPERTEN", "diabetes", "hyperten") %in%
           c("height_cm", "bmi", "race_ethnicity", "smoking_status", "education",
             "income_poverty_ratio", "self_reported_emphysema_or_bronchitis",
             "ever_asthma", "phq9_score", "low_physical_activity",
             "mobility_difficulty_routed", "adl_iadl_difficulty_routed",
             "nhanes_function_health_proxy_count")),
    "no linked-mortality contributing-cause variable selected",
    "DIABETES/HYPERTEN are prohibited as baseline covariates"
  )
  record_assertion(
    store,
    "official_positive_pef_tails_retained",
    all(is.finite(primary$pef_l_min) & primary$pef_l_min > 0),
    paste0("positive=", sum(primary$pef_l_min > 0), "; >900=", sum(primary$pef_l_min > 900)),
    "all official positive A-only PEF values, including >900 L/min, remain primary"
  )

  knots <- freeze_spline_knots(primary)
  cohort_knot_path <- file.path(out_dir, "stage3_nhanes_spline_knot_registry_v43.csv")
  write_cohort_csv(knots, cohort_knot_path)
  knot_hash <- sha256_file(cohort_knot_path)
  e0_hash <- sha256_file(paths$nhanes_e0)
  hashes <- c(
    analysis_spec = sha256_file(paths$spec),
    private_manifest = sha256_file(paths$manifest),
    decision_log = sha256_file(paths$decision_log),
    stage3_blueprint = sha256_file(paths$blueprint)
  )
  formulas_e0 <- model_formulas("E0")
  record_assertion(
    store,
    "body_weight_is_mi_auxiliary_not_outcome_covariate",
    !grepl(
      "\\bweight_kg\\b",
      paste(
        vapply(formulas_e0, function(x) paste(deparse(x), collapse = " "),
               character(1)),
        collapse = " | "
      ),
      perl = TRUE
    ),
    paste(vapply(formulas_e0, function(x) paste(deparse(x), collapse = " "),
                 character(1)), collapse = " | "),
    "weight_kg is used only as the passive BMI parent after its height/waist-informed PMM update and is absent from A0-A2 outcome formulas"
  )

  assertion_rows <- dplyr::bind_rows(store$assertions)
  expected_assertions <- c(
    "v43_route_aware_function_fields_present",
    "verified_v30_donor_fields_present",
    "v43_ledger_v30_donor_linkage",
    "ledger_donor_age_exact_reconciliation",
    "ledger_donor_sex_exact_reconciliation",
    "ledger_donor_pef_exact_reconciliation",
    "ledger_donor_survey_weight_exact_reconciliation",
    "ledger_donor_death_exact_reconciliation",
    "ledger_donor_followup_months_exact_reconciliation",
    "ledger_donor_cycle_exact_reconciliation",
    "ledger_donor_psu_exact_reconciliation",
    "ledger_donor_strata_exact_reconciliation",
    "nhanes_bmi_missingness_equals_height_or_weight_missingness",
    "nhanes_observed_bmi_matches_published_formula",
    "primary_A_only_domain_anchor",
    "primary_A_only_age60_79_anchor",
    "primary_route_aware_function_anchors",
    "e0_primary_scale_two_sex_rows",
    "e0_primary_scale_positive_sd",
    "e0_frozen_numeric_anchor",
    "full_MEC_design_backbone_anchor",
    "primary_domain_retains_design",
    "linked_mortality_contributing_causes_prohibited",
    "official_positive_pef_tails_retained",
    "body_weight_is_mi_auxiliary_not_outcome_covariate"
  )
  assertion_contract_ok <-
    nrow(assertion_rows) == length(expected_assertions) &&
    !anyDuplicated(assertion_rows$check) &&
    setequal(assertion_rows$check, expected_assertions) &&
    all(assertion_rows$status == "PASS")
  if (!assertion_contract_ok) {
    stop(
      "NHANES pre-model assertion output violates the exact 25-check ",
      "contract: rows=", nrow(assertion_rows),
      "; duplicates=", sum(duplicated(assertion_rows$check)),
      "; missing=",
      paste(setdiff(expected_assertions, assertion_rows$check), collapse = "|"),
      "; unexpected=",
      paste(setdiff(assertion_rows$check, expected_assertions), collapse = "|"),
      "; nonpass=", sum(assertion_rows$status != "PASS"),
      call. = FALSE
    )
  }

  audit <- make_sample_event_audit(
    master,
    backbone,
    dplyr::bind_rows(store$joins),
    assertion_rows
  )
  write_cohort_csv(audit$overall, file.path(out_dir, "stage3_nhanes_sample_event_audit_v43.csv"))
  readr::write_csv(audit$joins, file.path(out_dir, "stage3_nhanes_join_audit_v43.csv"))
  readr::write_csv(audit$assertions, file.path(out_dir, "stage3_nhanes_assertion_audit_v43.csv"))
  readr::write_csv(missingness_audit(master, master$primary_domain),
                   file.path(out_dir, "stage3_nhanes_missingness_audit_v43.csv"))
  readr::write_csv(factor_level_audit(master, master$primary_domain),
                   file.path(out_dir, "stage3_nhanes_factor_level_audit_v43.csv"))

  base_seed <- as.integer(spec$seeds$missing_data_mi)
  primary_result <- run_domain_mi_models(
    master,
    backbone,
    knots,
    master$primary_domain,
    formulas_e0,
    "v43_s3_nhanes_pn_e0",
    seed = base_seed,
    exposure_term = "E0"
  )
  registry <- make_registry_from_mi(
    primary_result,
    formulas_e0,
    "v43_s3_nhanes_pn_e0",
    "E0",
    "nhanes_pef_A_only_common_mi",
    "SPXNQEFF A-only; official positive tails retained",
    hashes,
    e0_hash,
    knot_hash
  )
  model_diagnostics <- primary_result$diagnostics
  mi_diagnostics <- primary_result$mi_diagnostics
  chain_convergence <- primary_result$chain_convergence
  mi_trace <- primary_result$mi_trace

  # Boundary sensitivity for the ambiguous PFQ061 response 5. The primary
  # definition treats response 5 as missing because it does not establish
  # difficulty. This sensitivity deterministically sets observed response-5
  # mobility/ADL components to positive and reuses the same imputations for all
  # ordinary item nonresponse.
  formulas_code5_positive <- model_formulas(
    "E0",
    health_proxy = "nhanes_function_health_proxy_count_code5_positive"
  )
  code5_positive_fits <- fit_across_imputations(
    primary_result$imp,
    backbone,
    knots,
    list(A2 = formulas_code5_positive$A2),
    "v43_s3_nhanes_pn_e0_a2_code5_positive"
  )
  code5_positive_result <- list(
    imp = primary_result$imp,
    fits = code5_positive_fits,
    pooled = list(A2 = pool_scalar_rubin(code5_positive_fits$A2, "E0"))
  )
  registry <- dplyr::bind_rows(
    registry,
    make_registry_from_mi(
      code5_positive_result,
      list(A2 = formulas_code5_positive$A2),
      "v43_s3_nhanes_pn_e0_code5_positive",
      "E0",
      "nhanes_pef_A_only_common_mi",
      "A2 health-status boundary; PFQ061 response 5 coded difficulty-positive",
      hashes,
      e0_hash,
      knot_hash
    )
  )
  model_diagnostics <- dplyr::bind_rows(
    model_diagnostics,
    dplyr::bind_rows(lapply(code5_positive_fits$A2, `[[`, "diagnostics"))
  )

  # The registered older-adult sensitivity avoids relying on the age<=59
  # deterministic PFQ061 skip-to-zero rule. In the archived first imputation,
  # its A1 survey Cox fit failed the prespecified finite-coefficient/covariance
  # numerical hard gate. The same-domain A1/A2 comparison is all-or-none, so A2
  # is not attempted after A1 failure. Both fixed IDs remain transparently
  # registered as NOT_ESTIMABLE; fitting a rescue model is prohibited.
  age60_79_domain <- primary$RIDAGEYR >= 60 & primary$RIDAGEYR <= 79
  age60_79_data <- primary[age60_79_domain, , drop = FALSE]
  age60_79_diagnostic <- data.frame(
    n_participants = nrow(age60_79_data),
    events = sum(age60_79_data$death == 1L),
    person_years = sum(age60_79_data$followup_years),
    design_strata = length(unique(age60_79_data$design_strata)),
    design_psu = length(unique(age60_79_data$design_psu)),
    design_df = NA_real_,
    stringsAsFactors = FALSE
  )
  if (
    age60_79_diagnostic$n_participants != 3346L ||
      age60_79_diagnostic$events != 701L
  ) {
    stop(
      "The registered age-60-79 NOT_ESTIMABLE sensitivity no longer matches ",
      "its fixed N=3346/events=701 anchor.",
      call. = FALSE
    )
  }
  age60_79_registry <- dplyr::bind_rows(
    not_estimable_registry_row(
      analysis_id = "v43_s3_nhanes_pn_e0_age60_79_a1",
      model_tier = "A1",
      formula = formulas_e0$A1,
      model_diagnostic = age60_79_diagnostic,
      hashes = hashes,
      e0_hash = e0_hash,
      knot_hash = knot_hash,
      mi_m = primary_result$imp$m,
      mi_seed = primary_result$mi_spec$seed,
      model_attempt_status =
        "ARCHIVED_NUMERICAL_HARD_GATE_FAILURE",
      nonestimability_reason = paste0(
        "Archived first-imputation age-60-79 A1 survey Cox fit failed the ",
        "prespecified numerical finite-coefficient/covariance hard gate; ",
        "no coefficient value is reported and no post-hoc rescue model was attempted."
      )
    ),
    not_estimable_registry_row(
      analysis_id = "v43_s3_nhanes_pn_e0_age60_79_a2",
      model_tier = "A2",
      formula = formulas_e0$A2,
      model_diagnostic = age60_79_diagnostic,
      hashes = hashes,
      e0_hash = e0_hash,
      knot_hash = knot_hash,
      mi_m = primary_result$imp$m,
      mi_seed = primary_result$mi_spec$seed,
      model_attempt_status =
        "NOT_ATTEMPTED_PANEL_DEPENDENCY",
      nonestimability_reason = paste0(
        "The registered age-60-79 A1/A2 comparison is all-or-none; A2 was ",
        "not attempted after the archived first-imputation A1 numerical ",
        "hard-gate failure, and no post-hoc rescue model was attempted."
      )
    )
  )
  registry <- dplyr::bind_rows(
    registry,
    age60_79_registry
  )

  # Physical-unit re-expression on the identical primary imputations and sample.
  formulas_e0b <- model_formulas("E0b")
  fits_e0b <- fit_across_imputations(
    primary_result$imp,
    backbone,
    knots,
    formulas_e0b,
    "v43_s3_nhanes_pn_e0b"
  )
  pooled_e0b <- lapply(names(fits_e0b), function(tier) pool_scalar_rubin(fits_e0b[[tier]], "E0b"))
  names(pooled_e0b) <- names(fits_e0b)
  e0b_result <- list(imp = primary_result$imp, fits = fits_e0b, pooled = pooled_e0b)
  registry <- dplyr::bind_rows(
    registry,
    make_registry_from_mi(
      e0b_result,
      formulas_e0b,
      "v43_s3_nhanes_pn_e0b",
      "E0b",
      "nhanes_pef_A_only_common_mi",
      "SPXNQEFF A-only; per 100 L/min lower PEF; unchanged E0 means",
      hashes,
      e0_hash,
      knot_hash
    )
  )
  model_diagnostics <- dplyr::bind_rows(
    model_diagnostics,
    dplyr::bind_rows(lapply(fits_e0b, function(x) dplyr::bind_rows(lapply(x, `[[`, "diagnostics"))))
  )

  # One common A2-complete sample is used for A0, A1 and A2.
  cc_fits <- fit_complete_case_set(
    master,
    backbone,
    knots,
    formulas_e0,
    master$primary_domain,
    "v43_s3_nhanes_pn_e0_complete_case"
  )
  cc_registry <- dplyr::bind_rows(lapply(names(cc_fits), function(tier) {
    fit <- cc_fits[[tier]]
    registry_row(
      pooled_from_single_fit(fit, "E0"),
      paste0("v43_s3_nhanes_pn_e0_", tolower(tier), "_complete_case"),
      "E0",
      "nhanes_pef_A_only_common_A2_complete_case",
      tier,
      "SPXNQEFF A-only; common A2 complete-case sample",
      formulas_e0[[tier]],
      fit$diagnostics,
      hashes,
      e0_hash,
      knot_hash,
      0L,
      warnings = fit$diagnostics$warnings
    )
  }))
  registry <- dplyr::bind_rows(registry, cc_registry)
  model_diagnostics <- dplyr::bind_rows(
    model_diagnostics,
    dplyr::bind_rows(lapply(cc_fits, `[[`, "diagnostics"))
  )

  # Prespecified 0-2, 2-5 and >5-year PH/window diagnostic.
  window_formula <- window_formula_A1("E0")
  window_fits <- fit_window_across_imputations(
    primary_result$imp,
    backbone,
    knots,
    window_formula,
    "v43_s3_nhanes_pn_e0_a1_window"
  )
  model_diagnostics <- dplyr::bind_rows(
    model_diagnostics,
    dplyr::bind_rows(lapply(window_fits, `[[`, "diagnostics"))
  )
  interaction_terms <- grep(
    "E0:factor\\(time_window\\)|factor\\(time_window\\).*:E0",
    names(window_fits[[1]]$coefficients),
    value = TRUE
  )
  if (length(interaction_terms) != 2L) {
    stop("Expected two estimable E0-by-window interaction terms.", call. = FALSE)
  }
  time_varying <- pool_multivariate_rubin(
    window_fits,
    interaction_terms,
    "v43_s3_nhanes_pn_e0_a1_window_heterogeneity"
  )
  window_effects <- dplyr::bind_rows(lapply(c("0_2", "2_5", "gt5"), function(window) {
    pooled <- pool_linear_combination_rubin(window_fits, window_contrast_builder(window), paste0("E0_", window))
    data.frame(
      test_id = paste0("v43_s3_nhanes_pn_e0_a1_window_", window),
      pooling_rule = "Rubin-pooled linear combination of base E0 and window interaction",
      terms = paste0("E0 effect in ", window, " years"),
      df = pooled$df,
      statistic = pooled$estimate / pooled$standard_error,
      p_value = pooled$p_value,
      m = pooled$m,
      estimate = pooled$estimate,
      standard_error = pooled$standard_error,
      ci_low = pooled$ci_low,
      ci_high = pooled$ci_high,
      exp_estimate = exp(pooled$estimate),
      exp_ci_low = exp(pooled$ci_low),
      exp_ci_high = exp(pooled$ci_high),
      stringsAsFactors = FALSE
    )
  }))

  # Supportive weighted robust E0-by-log(time) diagnostic; not a replacement
  # for the complex-survey primary Cox or window-stratified analysis.
  log_time_fits <- fit_log_time_across_imputations(
    primary_result$imp,
    knots,
    "v43_s3_nhanes_pn_e0_a1_log_time"
  )
  log_time_term <- grep("tt\\(E0\\)", names(log_time_fits[[1]]$coefficients), value = TRUE)
  if (length(log_time_term) != 1L) stop("Could not identify the E0-by-log(time) term.", call. = FALSE)
  log_time_pool <- pool_scalar_rubin(log_time_fits, log_time_term)
  log_time_row <- data.frame(
    test_id = "v43_s3_nhanes_pn_e0_a1_log_time_supportive",
    pooling_rule = paste0(
      "Rubin-pooled weighted robust coxph with Efron ties, cycle-specific ",
      "public-stratum baseline and PSU clustering; separate cycle fixed terms ",
      "are omitted because cycle is absorbed by the stratum baselines"
    ),
    terms = log_time_term,
    df = log_time_pool$df,
    statistic = log_time_pool$estimate / log_time_pool$standard_error,
    p_value = log_time_pool$p_value,
    m = log_time_pool$m,
    estimate = log_time_pool$estimate,
    standard_error = log_time_pool$standard_error,
    ci_low = log_time_pool$ci_low,
    ci_high = log_time_pool$ci_high,
    exp_estimate = exp(log_time_pool$estimate),
    exp_ci_low = exp(log_time_pool$ci_low),
    exp_ci_high = exp(log_time_pool$ci_high),
    stringsAsFactors = FALSE
  )
  model_diagnostics <- dplyr::bind_rows(
    model_diagnostics,
    dplyr::bind_rows(lapply(log_time_fits, `[[`, "diagnostics"))
  )

  # Prespecified exposure-spline overall and nonlinear tests.
  spline_formulas <- model_formulas("E0", spline_exposure = TRUE)
  spline_fits <- fit_across_imputations(
    primary_result$imp,
    backbone,
    knots,
    list(A1_exposure_spline = spline_formulas$A1),
    "v43_s3_nhanes_pn_e0_spline"
  )$A1_exposure_spline
  spline_overall <- pool_multivariate_rubin(
    spline_fits,
    c("E0_linear", "E0_nonlinear1", "E0_nonlinear2"),
    "v43_s3_nhanes_pn_e0_a1_spline_overall"
  )
  spline_nonlinear <- pool_multivariate_rubin(
    spline_fits,
    c("E0_nonlinear1", "E0_nonlinear2"),
    "v43_s3_nhanes_pn_e0_a1_spline_nonlinear"
  )
  model_diagnostics <- dplyr::bind_rows(
    model_diagnostics,
    dplyr::bind_rows(lapply(spline_fits, `[[`, "diagnostics"))
  )
  time_varying <- dplyr::bind_rows(
    time_varying, window_effects, log_time_row, spline_overall,
    spline_nonlinear
  )
  diagnostic_roles <- setNames(
    c(
      "PRINCIPAL_TIME_HETEROGENEITY",
      rep("PRINCIPAL_WINDOW_ESTIMATE", 3L),
      "SUPPORTIVE_LOG_LINEAR_TIME_TREND",
      rep("EXPOSURE_FUNCTIONAL_FORM", 2L)
    ),
    expected_nhanes_time_varying_ids()
  )
  time_varying$diagnostic_role <- unname(
    diagnostic_roles[as.character(time_varying$test_id)]
  )
  time_varying$diagnostic_status <- "PASS"
  time_varying$cohort <- "NHANES"
  time_varying <- time_varying[, c("cohort", setdiff(names(time_varying), "cohort"))]
  validate_nhanes_time_varying_contract(time_varying)
  write_cohort_csv(
    time_varying,
    file.path(out_dir, "stage3_nhanes_time_varying_effects_v43.csv")
  )

  # Two-year landmark sensitivity. This conditions on survival and observed
  # linked follow-up beyond 24 months, then left-truncates the Cox risk process
  # at year 2. It is a reverse-causation robustness probe, not a claim that
  # occult disease or reverse causation has been eliminated.
  landmark_formula <- stats::as.formula(paste(
    "survival::Surv(landmark_tstart_years, followup_years, death) ~",
    model_rhs_text("A1", "E0")
  ))
  landmark_result <- fit_two_year_landmark_from_existing_imp(
    primary_result$imp,
    backbone,
    knots,
    landmark_formula,
    "v43_s3_nhanes_pn_e0_a1_two_year_landmark"
  )
  registry <- dplyr::bind_rows(
    registry,
    make_registry_from_mi(
      landmark_result,
      list(A1 = landmark_formula),
      "v43_s3_nhanes_pn_e0_two_year_landmark",
      "E0",
      "nhanes_pef_A_only_conditional_survival_beyond_2y_common_mi",
      paste0(
        "SPXNQEFF A-only; two-year landmark with left truncation at year 2; ",
        "reverse-causation robustness probe only"
      ),
      hashes,
      e0_hash,
      knot_hash
    )
  )
  model_diagnostics <- dplyr::bind_rows(
    model_diagnostics, landmark_result$diagnostics
  )

  # A-only plus acceptable-curves sensitivity is nested within the primary MI.
  acc3_ids <- master$SEQN[master$pef_A_acc3 %in% TRUE & master$PERMTH_EXM > 0]
  acc3_result <- fit_subset_from_existing_imp(
    primary_result$imp,
    backbone,
    knots,
    formulas_e0,
    acc3_ids,
    "v43_s3_nhanes_pn_e0_pef_A_acc3"
  )
  registry <- dplyr::bind_rows(
    registry,
    make_registry_from_mi(
      acc3_result,
      formulas_e0,
      "v43_s3_nhanes_pn_e0_pef_A_acc3",
      "E0",
      "nhanes_pef_A_acc3_common_mi",
      "SPXNQEFF A-only plus SPDNACC>=3; A-only constants reused",
      hashes,
      e0_hash,
      knot_hash
    )
  )
  model_diagnostics <- dplyr::bind_rows(model_diagnostics, acc3_result$diagnostics)

  # A+C and A/B/C introduce additional participants, so each has its own
  # common A0-A2 MI cohort while retaining the primary A-only constants/knots.
  quality_definitions <- list(
    pef_A_plus_C = master$pef_AC %in% TRUE & master$PERMTH_EXM > 0,
    pef_ABC = master$pef_ABC %in% TRUE & master$PERMTH_EXM > 0
  )
  quality_labels <- c(
    pef_A_plus_C = "SPXNQEFF A+C duration-relaxed; A-only constants reused",
    pef_ABC = "SPXNQEFF A/B/C broad sensitivity; B is not strict; A-only constants reused"
  )
  quality_results <- list()
  for (i in seq_along(quality_definitions)) {
    id <- names(quality_definitions)[[i]]
    result <- tryCatch(
      run_domain_mi_models(
        master,
        backbone,
        knots,
        quality_definitions[[i]],
        formulas_e0,
        paste0("v43_s3_nhanes_pn_e0_", id),
        seed = base_seed + i,
        exposure_term = "E0"
      ),
      stage3_mice_convergence_error = function(e) {
        e$checkpoint_diagnostics <- dplyr::bind_rows(
          chain_convergence,
          e$checkpoint_diagnostics
        )
        stop(e)
      }
    )
    quality_results[[id]] <- result
    registry <- dplyr::bind_rows(
      registry,
      make_registry_from_mi(
        result,
        formulas_e0,
        paste0("v43_s3_nhanes_pn_e0_", id),
        "E0",
        paste0("nhanes_", id, "_common_mi"),
        quality_labels[[id]],
        hashes,
        e0_hash,
        knot_hash
      )
    )
    model_diagnostics <- dplyr::bind_rows(model_diagnostics, result$diagnostics)
    mi_diagnostics <- dplyr::bind_rows(mi_diagnostics, result$mi_diagnostics)
    chain_convergence <- dplyr::bind_rows(chain_convergence, result$chain_convergence)
    mi_trace <- dplyr::bind_rows(mi_trace, result$mi_trace)
  }

  # Official >900 L/min observations remain primary. This leave-tail-out model
  # is an influence diagnostic only and cannot redefine the quality layer.
  no_tail_ids <- primary$SEQN[primary$pef_l_min <= 900]
  tail_result <- fit_subset_from_existing_imp(
    primary_result$imp,
    backbone,
    knots,
    list(A1 = formulas_e0$A1),
    no_tail_ids,
    "v43_s3_nhanes_pn_e0_a1_gt900_influence_exclusion"
  )
  registry <- dplyr::bind_rows(
    registry,
    make_registry_from_mi(
      tail_result,
      list(A1 = formulas_e0$A1),
      "v43_s3_nhanes_pn_e0_gt900_influence_exclusion",
      "E0",
      "nhanes_pef_A_only_gt900_excluded_influence_only",
      "Influence diagnostic only; official >900 values remain in the primary quality layer",
      hashes,
      e0_hash,
      knot_hash
    )
  )
  model_diagnostics <- dplyr::bind_rows(model_diagnostics, tail_result$diagnostics)

  # Leave-one-cycle-out A1 estimates retain the primary A-only imputations.
  cycle_registry <- list()
  cycle_diagnostics <- list()
  for (cycle in c("E", "F", "G")) {
    ids <- primary$SEQN[primary$cycle_label != cycle]
    result <- fit_subset_from_existing_imp(
      primary_result$imp,
      backbone,
      knots,
      list(A1 = formulas_e0$A1),
      ids,
      paste0("v43_s3_nhanes_pn_e0_a1_leave_cycle_", cycle)
    )
    cycle_registry[[cycle]] <- make_registry_from_mi(
      result,
      list(A1 = formulas_e0$A1),
      paste0("v43_s3_nhanes_pn_e0_leave_cycle_", cycle),
      "E0",
      paste0("nhanes_pef_A_only_leave_cycle_", cycle, "_common_mi"),
      paste0("SPXNQEFF A-only; cycle ", cycle, " omitted"),
      hashes,
      e0_hash,
      knot_hash
    )
    cycle_diagnostics[[cycle]] <- result$diagnostics
  }
  registry <- dplyr::bind_rows(registry, dplyr::bind_rows(cycle_registry))
  model_diagnostics <- dplyr::bind_rows(model_diagnostics, dplyr::bind_rows(cycle_diagnostics))

  # Complete-case A1 leave-one-PSU influence audit. Only aggregate summaries
  # are written; no PSU identifier leaves the sensitive environment.
  cc_keep <- complete_case_mask(master, master$primary_domain)
  cc_master <- attach_passive_variables(master[cc_keep, , drop = FALSE], knots)
  psus <- sort(unique(cc_master$design_psu))
  loo <- lapply(psus, function(psu) {
    ids <- cc_master$SEQN[cc_master$design_psu != psu]
    dat <- cc_master[cc_master$SEQN %in% ids, , drop = FALSE]
    fit <- fit_one_survey_cox(
      dat,
      backbone,
      formulas_e0$A1,
      "nhanes_complete_case_A1_leave_one_PSU",
      ids
    )
    data.frame(
      omitted_psu_rank = match(psu, psus),
      estimate = unname(fit$coefficients[["E0"]]),
      standard_error = sqrt(unname(fit$variance["E0", "E0"])),
      warnings = fit$diagnostics$warnings,
      stringsAsFactors = FALSE
    )
  })
  loo <- dplyr::bind_rows(loo)
  reference_cc_a1_estimate <- unname(cc_fits$A1$coefficients[["E0"]])
  if (!is.finite(reference_cc_a1_estimate)) {
    stop("The complete-case A1 reference estimate is non-finite for the PSU influence audit.", call. = FALSE)
  }
  influence_summary <- data.frame(
    cohort = "NHANES",
    diagnostic_id = "v43_s3_nhanes_pn_e0_a1_complete_case_leave_one_psu",
    psu_refits = nrow(loo),
    reference_complete_case_a1_estimate = reference_cc_a1_estimate,
    estimate_min = min(loo$estimate),
    estimate_q05 = as.numeric(stats::quantile(loo$estimate, 0.05)),
    estimate_median = stats::median(loo$estimate),
    estimate_q95 = as.numeric(stats::quantile(loo$estimate, 0.95)),
    estimate_max = max(loo$estimate),
    sign_reversal_count = sum(sign(loo$estimate) != sign(reference_cc_a1_estimate)),
    nonempty_warning_refits = sum(nzchar(loo$warnings)),
    stringsAsFactors = FALSE
  )
  readr::write_csv(influence_summary, file.path(out_dir, "stage3_nhanes_psu_influence_summary_v43.csv"))

  write_cohort_csv(
    model_diagnostics,
    file.path(out_dir, "stage3_nhanes_model_diagnostics_v43.csv")
  )
  write_cohort_csv(
    mi_diagnostics,
    file.path(out_dir, "stage3_nhanes_mi_diagnostics_v43.csv")
  )
  write_cohort_csv(
    chain_convergence,
    file.path(out_dir, "stage3_nhanes_mi_chain_convergence_v43.csv")
  )
  write_cohort_csv(
    mi_trace,
    file.path(out_dir, "stage3_nhanes_mi_trace_v43.csv")
  )

  registry$e0_mean_male_l_min <- primary_scale$weighted_mean_l_min[primary_scale$sex_code == 1]
  registry$e0_sd_male_l_min <- primary_scale$weighted_sd_l_min[primary_scale$sex_code == 1]
  registry$e0_mean_female_l_min <- primary_scale$weighted_mean_l_min[primary_scale$sex_code == 2]
  registry$e0_sd_female_l_min <- primary_scale$weighted_sd_l_min[primary_scale$sex_code == 2]
  primary_pef_checksum <- digest::digest(
    primary[c("SEQN", "pef_l_min")],
    algo = "sha256",
    serialize = TRUE
  )
  registry$primary_pef_ledger_column <- "pef_l_min"
  registry$primary_pef_construction_checksum <- primary_pef_checksum
  registry$time_varying_effect_diagnostic_id <- NA_character_
  primary_a1_reference_row <-
    registry$analysis_id == "v43_s3_nhanes_pn_e0_a1"
  if (sum(primary_a1_reference_row) != 1L) {
    stop(
      "Could not identify exactly one primary NHANES E0 A1 registry row for ",
      "the frozen time-heterogeneity reference.",
      call. = FALSE
    )
  }
  registry$time_varying_effect_diagnostic_id[primary_a1_reference_row] <-
    "v43_s3_nhanes_pn_e0_a1_window_heterogeneity"
  validate_nhanes_time_varying_references(registry, time_varying)

  required_registry <- utils::read.csv(paths$registry_schema, stringsAsFactors = FALSE)
  missing_registry_fields <- setdiff(
    required_registry$field[required_registry$required == "yes"],
    names(registry)
  )
  if (length(missing_registry_fields)) {
    stop("Stage 3 registry lacks required fields: ", paste(missing_registry_fields, collapse = ", "), call. = FALSE)
  }
  if (anyDuplicated(registry$analysis_id)) stop("Stage 3 analysis_id values are not globally unique.", call. = FALSE)
  validate_nhanes_registry_contract(
    registry,
    primary_mi_m = primary_result$imp$m,
    primary_mi_seed = primary_result$mi_spec$seed
  )
  registry_not_estimable_n <- sum(registry$gate_status == "NOT_ESTIMABLE")
  registry_pass_n <- sum(registry$gate_status == "PASS")
  write_cohort_csv(
    registry,
    file.path(out_dir, "stage3_nhanes_primary_association_registry_v43.csv")
  )

  primary_passive_bmi_audit <- attr(
    primary_result$imp,
    "nhanes_passive_bmi_audit",
    exact = TRUE
  )
  quality_passive_bmi_audits <- lapply(
    quality_results,
    function(x) attr(
      x$imp,
      "nhanes_passive_bmi_audit",
      exact = TRUE
    )
  )
  passive_bmi_audits <- c(
    list(primary_A_only = primary_passive_bmi_audit),
    quality_passive_bmi_audits
  )
  passive_audit_pass <- vapply(passive_bmi_audits, function(audit) {
    !is.null(audit) &&
      audit$observed_bmi_exact_reconstruction_n == audit$observed_bmi_n &&
      audit$observed_bmi_change_n == 0L &&
      is.finite(audit$maximum_identity_difference) &&
      audit$maximum_identity_difference <= 1e-12 &&
      audit$invalid_completed_parent_n == 0L &&
      isTRUE(audit$visit_sequence_preserved)
  }, logical(1))
  if (!length(passive_audit_pass) || !all(passive_audit_pass)) {
    stop(
      "The successful NHANES run lacks passing passive-BMI audits for all ",
      "primary and expanded quality-domain MI objects: ",
      paste(names(passive_audit_pass), passive_audit_pass, sep = "=", collapse = "|"),
      call. = FALSE
    )
  }
  saveRDS(
    list(
      person_master = master,
      full_mec_design_backbone = backbone,
      primary_domain_ids = primary$SEQN,
      primary_mi_specification = primary_result$mi_spec,
      quality_mi_specifications = lapply(quality_results, `[[`, "mi_spec"),
      primary_passive_bmi_audit = primary_passive_bmi_audit,
      quality_passive_bmi_audits = quality_passive_bmi_audits,
      spline_knots = knots,
      e0_scale_sha256 = e0_hash,
      primary_pef_column = "pef_l_min",
      primary_pef_construction_checksum = primary_pef_checksum,
      prohibited_baseline_fields = c("DIABETES", "HYPERTEN"),
      design_rule = "full positive-weight MEC design before analytic domain"
    ),
    file.path(sensitive_dir, "nhanes_stage3_analysis_ledger_v43.rds")
  )

  hard_rhat_summary <- chain_convergence |>
    dplyr::filter(
      selected_checkpoint %in% TRUE,
      hard_gate %in% TRUE,
      is.finite(rhat)
    ) |>
    dplyr::group_by(imputation_id, mi_run) |>
    dplyr::summarise(
      chains = max(chains),
      iterations = max(checkpoint_iteration),
      maximum_rhat = max(rhat),
      .groups = "drop"
    )
  hard_rhat_text <- if (nrow(hard_rhat_summary)) {
    paste0(
      hard_rhat_summary$imputation_id,
      "/", hard_rhat_summary$mi_run,
      "[m=", hard_rhat_summary$chains,
      ",maxit=", hard_rhat_summary$iterations,
      ",max_Rhat=", signif(hard_rhat_summary$maximum_rhat, 6),
      "]",
      collapse = "; "
    )
  } else {
    "no hard-gate-eligible trace"
  }
  log_lines <- c(
    paste0("NHANES Stage 3 completed: ", format(Sys.time(), tz = "Asia/Shanghai", usetz = TRUE)),
    "Authorization: Gate0 PASS; Gate1 PASS; core Gate2 PASS; outcome_execution_allowed=true",
    paste0("Primary A-only N: ", nrow(primary)),
    paste0("Primary deaths: ", sum(primary$death)),
    paste0("Full MEC design: N=", nrow(backbone), "; strata=", length(unique(backbone$design_strata)),
           "; PSU=", length(unique(backbone$design_psu))),
    paste0("Primary MI imputations: ", primary_result$imp$m),
    paste0(
      "Passive BMI audited MI domains: ",
      sum(passive_audit_pass), "/", length(passive_audit_pass)
    ),
    paste0("MI mixing summaries: ", hard_rhat_text),
    paste0(
      "Passive BMI audit: chains=", primary_passive_bmi_audit$chains_checked,
      "; missing BMI=", primary_passive_bmi_audit$bmi_missing_n,
      " (E/F/G=",
      paste(
        unlist(primary_passive_bmi_audit$bmi_missing_by_cycle),
        collapse = "/"
      ),
      ")",
      "; observed exact reconstructions=",
      primary_passive_bmi_audit$observed_bmi_exact_reconstruction_n,
      "/", primary_passive_bmi_audit$observed_bmi_n,
      "; observed BMI changes=",
      primary_passive_bmi_audit$observed_bmi_change_n,
      "; maximum identity difference=",
      primary_passive_bmi_audit$maximum_identity_difference,
      "; invalid completed height/weight/BMI=",
      primary_passive_bmi_audit$invalid_completed_parent_n,
      "; visit sequence preserved=",
      primary_passive_bmi_audit$visit_sequence_preserved
    ),
    paste0(
      "Registered association rows: ", nrow(registry),
      " (PASS=", registry_pass_n,
      "; NOT_ESTIMABLE=", registry_not_estimable_n, ")"
    ),
    paste0(
      "Age-60-79 registered sensitivity: A1/A2 NOT_ESTIMABLE ",
      "(N=3346; events=701); archived first-imputation numerical hard-gate ",
      "failure; no post-hoc rescue model attempted"
    ),
    "Primary interpretation: survey-weighted average Cox hazard association, conditional on PH diagnostics",
    "PH windows: 0-2, 2-5 and >5 years; window-specific estimates retained if PH is not credible",
    "Row-level outputs: derived_sensitive/v43/nhanes_stage3_analysis_ledger_v43.rds only"
  )
  writeLines(
    log_lines,
    file.path(log_dir, "stage3_nhanes_primary_association_v43.log"),
    useBytes = TRUE
  )

  qa_lines <- c(
    "# NHANES v43 Stage 3 primary association QA",
    "",
    paste0("Generated: ", format(Sys.time(), tz = "Asia/Shanghai", usetz = TRUE)),
    "",
    "Authorization, one-to-one ledger/donor reconciliation, frozen A-only E0 constants, full-design-before-domain construction, common MI and complete-case samples, fixed spline knots, survey Cox rank, MI Monte Carlo error, PH diagnostics and output boundaries were checked before registration.",
    "",
    paste0("- Primary A-only participants: ", nrow(primary)),
    paste0("- Death events: ", sum(primary$death)),
    paste0("- Full MEC design rows: ", nrow(backbone)),
    paste0("- Public design strata/PSUs: ", length(unique(backbone$design_strata)), "/", length(unique(backbone$design_psu))),
    paste0("- Primary MI imputations: ", primary_result$imp$m),
    paste0(
      "- Passive BMI audited MI domains: ",
      sum(passive_audit_pass), "/", length(passive_audit_pass)
    ),
    paste0("- MI mixing summaries: ", hard_rhat_text),
    paste0(
      "- Passive BMI integrity: ",
      primary_passive_bmi_audit$chains_checked,
      " chains; ", primary_passive_bmi_audit$bmi_missing_n,
      " originally missing BMI values (E/F/G=",
      paste(
        unlist(primary_passive_bmi_audit$bmi_missing_by_cycle),
        collapse = "/"
      ),
      "); ",
      primary_passive_bmi_audit$observed_bmi_exact_reconstruction_n,
      "/", primary_passive_bmi_audit$observed_bmi_n,
      " observed values exactly reconstructed; ",
      primary_passive_bmi_audit$observed_bmi_change_n,
      " observed BMI changes; maximum identity difference ",
      primary_passive_bmi_audit$maximum_identity_difference,
      "; visit sequence preserved ",
      primary_passive_bmi_audit$visit_sequence_preserved
    ),
    paste0(
      "- Registered models/sensitivities: ", nrow(registry),
      " (", registry_pass_n, " PASS; ",
      registry_not_estimable_n, " NOT_ESTIMABLE)"
    ),
    paste0(
      "- Age-60-79 registered A1/A2 sensitivity: NOT_ESTIMABLE ",
      "(N=3346; events=701). The archived first-imputation A1 fit failed ",
      "the numerical finite-coefficient/covariance hard gate; A2 was not ",
      "attempted under the all-or-none same-domain rule; no post-hoc rescue ",
      "model was attempted."
    ),
    "",
    "The primary A1 model uses the SPXNQEFF A-only domain after constructing the full pooled MEC design. A-only+SPDNACC>=3, A+C and A/B/C are prespecified sensitivities that reuse the A-only E0 constants. B is not described as strict quality.",
    "",
    "MICE mixing used rank-normalized and folded split R-hat for every computable quantitative chain-mean/SD trace and per-level unordered-category proportion trace. The numerical anthropometric update graph was height to waist to weight to BMI; it was not interpreted causally. Height, waist, and body weight were PMM-imputed, and only originally missing BMI was passively reconstructed from weight/height-squared using positive decimal half-up on the released cycle-specific scale (E/F two decimals; G one decimal), while observed BMI was preserved. Low-support aggregate traces were hard-gated internally but were not released.",
    "",
    "Official positive PEF tails remain in the primary analysis; the >900 L/min leave-tail-out result is influence-only. Linked-mortality DIABETES/HYPERTEN fields are not baseline covariates."
  )
  writeLines(
    qa_lines,
    file.path(qa_dir, "STAGE3_NHANES_PRIMARY_ASSOCIATION_QA_v43.md"),
    useBytes = TRUE
  )

  message("NHANES Stage 3 calculations completed in the run-scoped staging area.")
}

nhanes_stage3_result_paths <- function(root) {
  c(
    file.path(root, "results", "v43", c(
      "stage3_nhanes_join_audit_v43.csv",
      "stage3_nhanes_assertion_audit_v43.csv",
      "stage3_nhanes_design_audit_v43.csv",
      "stage3_nhanes_missingness_audit_v43.csv",
      "stage3_nhanes_factor_level_audit_v43.csv",
      "stage3_nhanes_psu_influence_summary_v43.csv",
      "stage3_nhanes_spline_knot_registry_v43.csv",
      "stage3_nhanes_sample_event_audit_v43.csv",
      "stage3_nhanes_time_varying_effects_v43.csv",
      "stage3_nhanes_model_diagnostics_v43.csv",
      "stage3_nhanes_mi_diagnostics_v43.csv",
      "stage3_nhanes_mi_chain_convergence_v43.csv",
      "stage3_nhanes_mi_trace_v43.csv",
      "stage3_nhanes_primary_association_registry_v43.csv"
    )),
    file.path(root, "derived_sensitive", "v43", "nhanes_stage3_analysis_ledger_v43.rds"),
    file.path(root, "logs", "v43", "stage3_nhanes_primary_association_v43.log"),
    file.path(root, "output", "qa", "v43", "STAGE3_NHANES_PRIMARY_ASSOCIATION_QA_v43.md")
  )
}

nhanes_stage3_completion_manifest_path <- function(root) {
  file.path(
    root, "results", "v43", "stage3_nhanes_completion_manifest_v43.csv"
  )
}

stage3_finalized_shared_paths <- function(root) {
  c(
    file.path(root, "results", "v43", c(
      "stage3_spline_knot_registry_v43.csv",
      "stage3_sample_event_audit_v43.csv",
      "stage3_model_diagnostics_v43.csv",
      "stage3_mi_diagnostics_v43.csv",
      "stage3_mi_chain_convergence_v43.csv",
      "stage3_time_varying_effects_v43.csv",
      "stage3_primary_association_registry_v43.csv",
      "stage3_output_finalization_manifest_v43.csv"
    )),
    file.path(root, "logs", "v43", "stage3_output_finalization_v43.log"),
    file.path(
      root, "output", "qa", "v43", "STAGE3_OUTPUT_FINALIZATION_QA_v43.md"
    )
  )
}

write_nhanes_completion_manifest <- function(staging_root, root, authorization) {
  staged_paths <- nhanes_stage3_result_paths(staging_root)
  final_paths <- nhanes_stage3_result_paths(root)
  actual_staged <- list.files(
    staging_root, recursive = TRUE, full.names = TRUE,
    all.files = TRUE, no.. = TRUE
  )
  actual_staged <- actual_staged[!dir.exists(actual_staged)]
  actual_staged <- normalizePath(actual_staged, mustWork = FALSE)
  expected_staged <- normalizePath(staged_paths, mustWork = FALSE)
  if (!setequal(actual_staged, expected_staged)) {
    stop(
      "NHANES Stage 3 staging violates the exact artifact whitelist: missing=",
      paste(setdiff(expected_staged, actual_staged), collapse = "; "),
      "; unexpected=",
      paste(setdiff(actual_staged, expected_staged), collapse = "; "),
      call. = FALSE
    )
  }
  exists <- file.exists(staged_paths) & !dir.exists(staged_paths)
  bytes <- ifelse(exists, as.numeric(file.info(staged_paths)$size), NA_real_)
  hashes <- vapply(staged_paths, sha256_file, character(1))
  if (!all(exists) || any(!is.finite(bytes) | bytes <= 0) ||
      any(!grepl("^[0-9a-fA-F]{64}$", hashes))) {
    stop(
      "NHANES Stage 3 cannot issue a completion manifest because its staged ",
      "artifact set is incomplete or unhashable.",
      call. = FALSE
    )
  }
  registry_hash <- sha256_file(authorization$paths$hash_registry)
  if (!grepl("^[0-9a-fA-F]{64}$", registry_hash)) {
    stop("Current final-authorization registry is unhashable at completion.", call. = FALSE)
  }
  root_prefix <- paste0(normalizePath(root, mustWork = TRUE), .Platform$file.sep)
  normalized_final <- normalizePath(final_paths, mustWork = FALSE)
  artifact <- ifelse(
    startsWith(normalized_final, root_prefix),
    substring(normalized_final, nchar(root_prefix) + 1L),
    basename(normalized_final)
  )
  completed_at <- format(Sys.time(), tz = "Asia/Shanghai", usetz = TRUE)
  manifest <- data.frame(
    cohort = "NHANES",
    status = "COMPLETE",
    run_id = basename(staging_root),
    authorization_registry_sha256 = registry_hash,
    artifact = artifact,
    path = normalized_final,
    bytes = bytes,
    sha256 = hashes,
    completed_at = completed_at,
    stringsAsFactors = FALSE
  )
  if (anyDuplicated(manifest$artifact) || anyDuplicated(manifest$path)) {
    stop("NHANES completion manifest contains duplicate artifacts or paths.", call. = FALSE)
  }
  manifest_path <- nhanes_stage3_completion_manifest_path(staging_root)
  write_cohort_csv(manifest, manifest_path)
  invisible(manifest)
}

write_authorization_success <- function(root, authorization) {
  out_dir <- file.path(root, "results", "v43")
  log_dir <- file.path(root, "logs", "v43")
  dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)
  dir.create(log_dir, recursive = TRUE, showWarnings = FALSE)
  audit <- authorization$checks
  audit$run_timestamp <- format(Sys.time(), tz = "Asia/Shanghai", usetz = TRUE)
  readr::write_csv(
    audit,
    file.path(out_dir, "stage3_nhanes_authorization_audit_v43.csv")
  )
  stale_markers <- c(
    file.path(log_dir, "stage3_nhanes_authorization_failure_v43.log"),
    file.path(out_dir, "stage3_nhanes_execution_failure_v43.csv"),
    file.path(
      out_dir,
      "stage3_nhanes_mi_convergence_failure_checkpoints_v43.csv"
    ),
    file.path(log_dir, "stage3_nhanes_execution_failure_v43.log")
  )
  unlink(stale_markers[file.exists(stale_markers)])
  invisible(audit)
}

create_nhanes_stage3_staging <- function(root) {
  run_id <- paste0(
    "nhanes_",
    format(Sys.time(), tz = "Asia/Shanghai", format = "%Y%m%dT%H%M%S"),
    "_", Sys.getpid()
  )
  path <- file.path(root, "derived_sensitive", "v43", ".stage3_staging", run_id)
  if (file.exists(path)) stop("Refusing to reuse an existing Stage 3 staging path.", call. = FALSE)
  dir.create(path, recursive = TRUE, showWarnings = FALSE)
  if (!dir.exists(path)) stop("Could not create the NHANES Stage 3 staging path.", call. = FALSE)
  path
}

cleanup_nhanes_stage3_staging <- function(staging_root) {
  if (!is.null(staging_root) && nzchar(staging_root) && dir.exists(staging_root)) {
    unlink(staging_root, recursive = TRUE, force = TRUE)
  }
  invisible(TRUE)
}

promote_nhanes_stage3_staging <- function(staging_root, root) {
  files <- list.files(
    staging_root, recursive = TRUE, full.names = TRUE,
    all.files = TRUE, no.. = TRUE
  )
  files <- files[!dir.exists(files)]
  if (!length(files)) stop("NHANES Stage 3 staging produced no files.", call. = FALSE)
  prefix <- paste0(normalizePath(staging_root, mustWork = TRUE), .Platform$file.sep)
  normalized_files <- normalizePath(files, mustWork = TRUE)
  if (any(!startsWith(normalized_files, prefix))) {
    stop("A staged output resolves outside the run-scoped staging root.", call. = FALSE)
  }
  relative <- substring(normalized_files, nchar(prefix) + 1L)
  destination <- file.path(root, relative)
  if (any(file.exists(destination))) {
    stop(
      "Refusing to overwrite an existing successful NHANES Stage 3 output: ",
      paste(destination[file.exists(destination)], collapse = "; "),
      call. = FALSE
    )
  }
  promoted <- character()
  on.exit({
    if (length(promoted) && length(promoted) < length(destination)) {
      unlink(promoted[file.exists(promoted)], force = TRUE)
    }
  }, add = TRUE)
  for (i in seq_along(normalized_files)) {
    dir.create(dirname(destination[[i]]), recursive = TRUE, showWarnings = FALSE)
    if (!file.rename(normalized_files[[i]], destination[[i]])) {
      stop("Atomic promotion failed for staged output: ", relative[[i]], call. = FALSE)
    }
    promoted <- c(promoted, destination[[i]])
  }
  cleanup_nhanes_stage3_staging(staging_root)
  invisible(destination)
}

write_authorized_execution_failure <- function(
    root, error_message, checkpoint_diagnostics = NULL) {
  out_dir <- file.path(root, "results", "v43")
  log_dir <- file.path(root, "logs", "v43")
  dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)
  dir.create(log_dir, recursive = TRUE, showWarnings = FALSE)
  failure <- data.frame(
    cohort = "NHANES",
    stage = 3L,
    status = "FAIL",
    reason = one_line(error_message),
    row_level_result_published = FALSE,
    coefficient_registry_published = FALSE,
    run_timestamp = format(Sys.time(), tz = "Asia/Shanghai", usetz = TRUE),
    stringsAsFactors = FALSE
  )
  atomic_write_csv(
    failure,
    file.path(out_dir, "stage3_nhanes_execution_failure_v43.csv")
  )
  if (!is.null(checkpoint_diagnostics) && nrow(checkpoint_diagnostics)) {
    aggregate_columns <- c(
      "cohort", "imputation_id", "mi_run", "checkpoint_order",
      "checkpoint_iteration", "selected_checkpoint", "variable", "parameter",
      "category_level", "missing_n", "iterations", "chains",
      "retained_iterations", "applicability", "rank_normalized_split_rhat",
      "folded_split_rhat", "rhat", "folded_identifiable",
      "raw_trace_constant", "classic_final_half_rhat",
      "distinct_trace_values", "median_lag1_ac",
      "standardized_last5_shift", "hard_gate", "pass",
      "diagnostic_status", "detail"
    )
    diagnostics <- checkpoint_diagnostics[
      intersect(aggregate_columns, names(checkpoint_diagnostics))
    ]
    atomic_write_csv(
      diagnostics,
      file.path(
        out_dir,
        "stage3_nhanes_mi_convergence_failure_checkpoints_v43.csv"
      )
    )
  }
  atomic_write_lines(
    c(
      paste0("Authorized NHANES Stage 3 execution failed: ", failure$run_timestamp),
      paste0("Reason: ", failure$reason),
      "Only this run's private staging directory was removed; prior successful outputs were preserved.",
      "No failed or partial coefficient is eligible for reporting."
    ),
    file.path(log_dir, "stage3_nhanes_execution_failure_v43.log")
  )
}

main <- function() {
  root <- project_root()
  staging_root <- NULL

  expected_outputs <- c(
    nhanes_stage3_result_paths(root),
    nhanes_stage3_completion_manifest_path(root),
    stage3_finalized_shared_paths(root)
  )
  existing_outputs <- expected_outputs[file.exists(expected_outputs)]
  if (length(existing_outputs)) {
    completeness <- if (length(existing_outputs) == length(expected_outputs)) {
      "complete"
    } else {
      paste0("incomplete (", length(existing_outputs), "/", length(expected_outputs), ")")
    }
    stop(
      "NHANES Stage 3 execution was not attempted because a ", completeness,
      " prior output set exists and overwrite_old_versions=false: ",
      paste(existing_outputs, collapse = "; "),
      call. = FALSE
    )
  }

  # After the zero-write prior-output guard, this is the first authorization
  # action. It reads aggregate governance assets only; row-level and mortality
  # inputs remain unopened until authorization.
  authorization <- authorization_gate(root)

  tryCatch(
    {
      require_stage3_packages()
      write_authorization_success(root, authorization)
      staging_root <- create_nhanes_stage3_staging(root)
      run_authorized_stage3(root, authorization, output_root = staging_root)
      write_nhanes_completion_manifest(staging_root, root, authorization)
      promote_nhanes_stage3_staging(staging_root, root)
      staging_root <- NULL
      message("NHANES Stage 3 completed, atomically promoted, and registered under v43.")
    },
    error = function(e) {
      original_error <- conditionMessage(e)
      checkpoint_diagnostics <- if (inherits(e, "stage3_mice_convergence_error")) {
        e$checkpoint_diagnostics
      } else {
        NULL
      }
      cleanup_error <- tryCatch(
        {
          cleanup_nhanes_stage3_staging(staging_root)
          NULL
        },
        error = function(clean_e) conditionMessage(clean_e)
      )
      failure_write_error <- tryCatch(
        {
          write_authorized_execution_failure(
            root,
            original_error,
            checkpoint_diagnostics
          )
          NULL
        },
        error = function(write_e) conditionMessage(write_e)
      )
      stop(
        "Authorized NHANES Stage 3 execution failed; only this run's staging area was removed. ",
        original_error,
        if (!is.null(cleanup_error)) {
          paste0(" Staging cleanup also failed: ", cleanup_error)
        } else {
          ""
        },
        if (!is.null(failure_write_error)) {
          paste0(" Failure-marker writing also failed: ", failure_write_error)
        } else {
          ""
        },
        call. = FALSE
      )
    }
  )
}

if (sys.nframe() == 0L) {
  main()
}
