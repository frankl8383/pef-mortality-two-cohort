# v43 Stage 0: freeze inputs and record the analysis environment.
# This script does not fit or inspect any outcome model.
#
# Two-phase contract:
#   1) Rscript R/v43/00_freeze_and_manifest.R --phase=preliminary
#      writes current manifests/Gate 0 and removes every old authorization.
#   2) Run the independent Stage 0-2 validator and the no-model Stage 3
#      preflight while outcome_execution_allowed remains false.
#   3) After recording Gate 0-2 PASS and promoting outcome_execution_allowed,
#      rerun with --phase=authorize. This recomputes the actual inventory,
#      rejects any change since preflight, and only then writes the registry.

suppressPackageStartupMessages({
  library(digest)
  library(dplyr)
  library(readr)
  library(tibble)
  library(yaml)
})

project_root <- function() {
  args <- commandArgs(trailingOnly = FALSE)
  file_arg <- grep("^--file=", args, value = TRUE)
  if (length(file_arg)) {
    script <- sub("^--file=", "", file_arg[[1]])
    return(normalizePath(file.path(dirname(script), "..", ".."), mustWork = TRUE))
  }
  normalizePath(getwd(), mustWork = TRUE)
}

sha256_file <- function(path) {
  if (!file.exists(path) || dir.exists(path)) return(NA_character_)
  digest::digest(file = path, algo = "sha256", serialize = FALSE)
}

relativize <- function(path, root) {
  root_prefix <- paste0(normalizePath(root, mustWork = TRUE), .Platform$file.sep)
  normalized <- normalizePath(path, mustWork = FALSE)
  ifelse(startsWith(normalized, root_prefix), substring(normalized, nchar(root_prefix) + 1L), basename(path))
}

add_input <- function(group, role, path, restricted = FALSE) {
  tibble(group = group, role = role, path = path, restricted = restricted)
}

as_flag <- function(x) {
  if (is.logical(x)) return(x)
  if (is.numeric(x)) return(ifelse(is.na(x), NA, x != 0))
  y <- toupper(trimws(as.character(x)))
  out <- rep(NA, length(y))
  out[y %in% c("TRUE", "T", "1", "YES", "Y", "PASS", "GO", "OK")] <- TRUE
  out[y %in% c("FALSE", "F", "0", "NO", "N", "FAIL", "NO-GO", "NO_GO", "ERROR")] <- FALSE
  out
}

expected_preflight_checks <- function() {
  tibble::tribble(
    ~cohort, ~check,
    "BOTH", "preflight_packages_available",
    "BOTH", "gate0_2_pass_before_preflight",
    "BOTH", "outcome_execution_disabled_during_preflight",
    "BOTH", "independent_stage0_2_validator_pass",
    "BOTH", "preliminary_manifest_current_and_complete",
    "BOTH", "governance_preflight_completed",
    "CHARLS", "structural_sample_time_support_rebuilt",
    "CHARLS", "mi_targets_have_predictors",
    "CHARLS", "mi_specification_hash_recorded",
    "CHARLS", "mi_expanded_dimension_below_rows",
    "CHARLS", "two_by_two_mice_dry_run",
    "CHARLS", "A0_A2_model_matrices_full_rank",
    "CHARLS", "survey_design_df_exceeds_model_dimension",
    "CHARLS", "spline_knots_finite",
    "CHARLS", "charls_preflight_completed",
    "NHANES", "primary_sample_and_events_rebuilt",
    "NHANES", "full_design_backbone_rebuilt",
    "NHANES", "mi_targets_have_predictors",
    "NHANES", "mi_specification_hash_recorded",
    "NHANES", "mi_expanded_dimension_below_rows",
    "NHANES", "stratum_plus_raw_psu_reconstructs_design_psu",
    "NHANES", "two_by_two_mice_dry_run",
    "NHANES", "full_design_before_domain_preserved",
    "NHANES", "A0_A2_model_matrices_full_rank",
    "NHANES", "survey_design_df_exceeds_model_dimension",
    "NHANES", "start_stop_window_matrix_full_rank",
    "NHANES", "nhanes_preflight_completed"
  )
}

check_contract_sha256 <- function() {
  contract <- expected_preflight_checks() %>%
    arrange(cohort, check) %>%
    transmute(line = paste(cohort, check, sep = "|"))
  digest::digest(paste(contract$line, collapse = "\n"), algo = "sha256", serialize = FALSE)
}

canonical_inventory <- function(manifest, exclude_roles = "gate_state") {
  required <- c("group", "role", "path", "restricted", "exists", "bytes", "sha256")
  if (!all(required %in% names(manifest))) return(NULL)
  manifest %>%
    filter(!role %in% exclude_roles) %>%
    transmute(
      group = as.character(group),
      role = as.character(role),
      path = normalizePath(as.character(path), mustWork = FALSE),
      restricted = toupper(as.character(as_flag(restricted))),
      exists = toupper(as.character(as_flag(exists))),
      bytes = format(as.numeric(bytes), scientific = FALSE, trim = TRUE),
      sha256 = tolower(as.character(sha256))
    ) %>%
    arrange(group, role, path)
}

inventory_sha256 <- function(manifest, exclude_roles = "gate_state") {
  stable <- canonical_inventory(manifest, exclude_roles = exclude_roles)
  if (is.null(stable)) return(NA_character_)
  tmp <- tempfile("stage3_stable_inventory_", fileext = ".csv")
  on.exit(unlink(tmp), add = TRUE)
  readr::write_csv(stable, tmp)
  sha256_file(tmp)
}

read_required_pass_table <- function(path) {
  if (!file.exists(path) || file.info(path)$size <= 0) {
    return(list(pass = FALSE, detail = "missing or empty"))
  }
  dat <- tryCatch(
    utils::read.csv(path, stringsAsFactors = FALSE, check.names = FALSE),
    error = function(e) NULL
  )
  if (is.null(dat) || !all(c("required", "status") %in% names(dat))) {
    return(list(pass = FALSE, detail = "unreadable or missing required/status columns"))
  }
  required <- as_flag(dat$required)
  selected <- required %in% TRUE
  ok <- any(selected) && all(!is.na(required[selected])) &&
    all(toupper(as.character(dat$status[selected])) == "PASS")
  list(
    pass = ok,
    detail = paste0(
      sum(toupper(as.character(dat$status[selected])) == "PASS"), "/",
      sum(selected), " required checks PASS"
    )
  )
}

phase_args <- grep("^--phase=", commandArgs(trailingOnly = TRUE), value = TRUE)
phase <- if (length(phase_args)) sub("^--phase=", "", tail(phase_args, 1L)) else "preliminary"
if (!phase %in% c("preliminary", "authorize")) {
  stop("--phase must be either preliminary or authorize.", call. = FALSE)
}

root <- project_root()
spec_path <- file.path(root, "work_v43", "analysis_spec_v43.yml")
spec <- yaml::read_yaml(spec_path)
out_dir <- file.path(root, "results", "v43")
log_dir <- file.path(root, "logs", "v43")
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(log_dir, recursive = TRUE, showWarnings = FALSE)
authorization_registry_path <- file.path(root, "work_v43", "stage3_authorization_hashes_v43.csv")
stable_inventory_path <- file.path(root, "work_v43", "stage3_stable_input_inventory_v43.csv")
# Every freeze run is fail-closed. A preliminary freeze explicitly invalidates
# any prior authorization, and an authorization attempt cannot leave a stale
# registry behind if one of its checks fails.
if (file.exists(authorization_registry_path)) unlink(authorization_registry_path)
if (file.exists(stable_inventory_path)) unlink(stable_inventory_path)

resolve <- function(path) {
  if (grepl("^/", path)) path else file.path(root, path)
}

nhanes_xpt <- sort(list.files(
  resolve(spec$inputs$nhanes_raw_xpt_dir),
  pattern = "\\.XPT$", full.names = TRUE, ignore.case = TRUE
))
nhanes_mortality <- sort(list.files(
  resolve(spec$inputs$nhanes_mortality_dir),
  pattern = "_MORT_2019_PUBLIC\\.dat$", full.names = TRUE
))

inputs <- bind_rows(
  add_input("CHARLS", "harmonized_core", resolve(spec$inputs$charls_core), TRUE),
  add_input("CHARLS", "harmonized_source_archive", resolve(spec$inputs$charls_harmonized_archive), TRUE),
  add_input("CHARLS", "wave5_source_archive", resolve(spec$inputs$charls_wave5_archive), TRUE),
  add_input("CHARLS", "v43_stage1_ledger", file.path(root, "derived_sensitive", "v43", "charls_stage1_ledger_v43.rds"), TRUE),
  add_input("CHARLS", "v43_E0_scale", file.path(root, "results", "v43", "charls_e0_scale_v43.csv"), FALSE),
  add_input("NHANES", "linked_analysis_ready", resolve(spec$inputs$nhanes_ready), TRUE),
  add_input("NHANES", "v43_stage1_ledger", file.path(root, "derived_sensitive", "v43", "nhanes_stage1_ledger_v43.rds"), TRUE),
  add_input("NHANES", "v43_E0_scale", file.path(root, "results", "v43", "nhanes_e0_scale_v43.csv"), FALSE),
  add_input("NHANES", "v43_function_routing_audit", file.path(root, "results", "v43", "nhanes_function_routing_audit_v43.csv"), FALSE),
  bind_rows(lapply(nhanes_xpt, function(x) add_input("NHANES", "raw_xpt", x, TRUE))),
  bind_rows(lapply(nhanes_mortality, function(x) add_input("NHANES", "linked_mortality_raw", x, TRUE))),
  add_input("governance", "analysis_spec", spec_path, FALSE),
  add_input("governance", "scientific_plan", resolve(spec$scientific_plan), FALSE),
  add_input("governance", "stage3_model_blueprint", file.path(root, "output", "qa", "v43_STAGE3_MODEL_BLUEPRINT_20260716.md"), FALSE),
  add_input("governance", "nhanes_function_proxy_evidence", file.path(root, "output", "qa", "v43_NHANES_FUNCTION_PROXY_EVIDENCE_20260716.md"), FALSE),
  add_input("governance", "landmark_sensitivity_evidence", resolve(spec$governance$landmark_sensitivity_evidence), FALSE),
  add_input("governance", "stage3_literature_gap_audit", resolve(spec$governance$stage3_literature_gap_audit), FALSE),
  add_input("governance", "deviation_log", resolve(spec$governance$deviation_log), FALSE),
  add_input("governance", "decision_log", resolve(spec$governance$decision_log), FALSE),
  add_input("governance", "seed_ledger", resolve(spec$governance$seed_ledger), FALSE),
  add_input("governance", "output_contract", file.path(root, "work_v43", "output_contract_v43.yml"), FALSE),
  add_input("governance", "registry_schema", file.path(root, "work_v43", "registry_schema_v43.csv"), FALSE),
  add_input("governance", "gate_state", file.path(root, "work_v43", "gate_state_v43.yml"), FALSE),
  add_input("governance", "renv_description", file.path(root, "work_v43", "DESCRIPTION"), FALSE),
  add_input("governance", "renv_lock", resolve(spec$software$lockfile), FALSE),
  add_input("code", "stage0_freeze", file.path(root, "R", "v43", "00_freeze_and_manifest.R"), FALSE),
  add_input("code", "charls_stage1_2", file.path(root, "R", "v43", "01_charls_stage1_2_flow_measurement_audit.R"), FALSE),
  add_input("code", "nhanes_stage1_2", file.path(root, "R", "v43", "02_nhanes_stage1_2_flow_measurement_audit.R"), FALSE),
  add_input("code", "stage0_2_validator", file.path(root, "R", "v43", "03_validate_stage0_2.R"), FALSE),
  add_input("code", "stage3_preflight", file.path(root, "R", "v43", "03b_stage3_preflight.R"), FALSE),
  add_input("code", "charls_stage3", file.path(root, "R", "v43", "04_charls_stage3_primary_mortality.R"), FALSE),
  add_input("code", "nhanes_stage3", file.path(root, "R", "v43", "05_nhanes_stage3_primary_mortality.R"), FALSE),
  add_input("code", "stage3_output_finalizer", file.path(root, "R", "v43", "06_finalize_stage3_outputs.R"), FALSE),
  add_input("metadata", "CHARLS_variable_evidence", file.path(root, "metadata", "charls_phenotype_codebook_variable_evidence_v0_4.csv"), FALSE),
  add_input("metadata", "NHANES_mapping", file.path(root, "metadata", "nhanes_replication_mapping_v0_1.csv"), FALSE)
) %>%
  distinct(path, .keep_all = TRUE) %>%
  mutate(
    exists = file.exists(path),
    bytes = ifelse(exists, file.info(path)$size, NA_real_),
    mtime_utc = ifelse(exists, format(file.info(path)$mtime, tz = "UTC", usetz = TRUE), NA_character_),
    sha256 = vapply(path, sha256_file, character(1))
  )

readr::write_csv(inputs, file.path(out_dir, "input_manifest_private_v43.csv"))
public_manifest <- inputs %>%
  mutate(
    path_alias = ifelse(restricted, paste0("LOCAL_RESTRICTED/", basename(path)), relativize(path, root))
  ) %>%
  select(group, role, path_alias, restricted, exists, bytes, mtime_utc, sha256)
readr::write_csv(public_manifest, file.path(out_dir, "input_manifest_public_v43.csv"))

package_names <- unique(c(
  "R", spec$software$stage0_2_packages, spec$software$stage3_required_packages,
  spec$software$later_optional_packages, "renv"
))
package_versions <- tibble(
  package = package_names,
  version = vapply(package_names, function(pkg) {
    if (pkg == "R") return(R.version.string)
    if (!requireNamespace(pkg, quietly = TRUE)) return("MISSING")
    as.character(utils::packageVersion(pkg))
  }, character(1)),
  available_before_new_install = version != "MISSING"
)
readr::write_csv(package_versions, file.path(out_dir, "environment_versions_v43.csv"))

session_lines <- c(
  capture.output(sessionInfo()),
  "",
  "BLAS/LAPACK:",
  capture.output(extSoftVersion()),
  paste0("R_BLAS_LIB=", Sys.getenv("R_BLAS_LIB", unset = "")),
  paste0("renv_project=", tryCatch(renv::project(), error = function(e) "not_loaded"))
)
writeLines(session_lines, file.path(log_dir, "session_info_v43.txt"), useBytes = TRUE)

required_paths <- c(
  spec_path,
  resolve(spec$governance$deviation_log),
  resolve(spec$governance$decision_log),
  resolve(spec$governance$seed_ledger),
  file.path(root, "work_v43", "output_contract_v43.yml"),
  file.path(root, "work_v43", "registry_schema_v43.csv"),
  file.path(root, "work_v43", "gate_state_v43.yml"),
  resolve(spec$software$lockfile)
)
gate0 <- tibble(
  check = c(
    "analysis_spec_frozen",
    "governance_files_exist",
    "renv_lock_exists",
    "all_manifest_inputs_exist",
    "stage0_2_packages_available",
    "stage3_packages_available",
    "later_optional_packages_recorded"
  ),
  pass = c(
    identical(
      spec$status,
      "frozen_post_outcome_execution_ph_design_alias_amendment"
    ) &&
      identical(spec$spec_version, "v43_4") &&
      !is.null(spec$amended_at) &&
      nzchar(as.character(spec$amended_at)) &&
      !is.null(spec$amendment_scope) &&
      grepl(
        "NHANES outcome-model code then executed",
        as.character(spec$amendment_scope),
        fixed = TRUE
      ) &&
      grepl(
        paste0(
          "no NHANES coefficient magnitude, direction, confidence interval, ",
          "P value, window-test result, or primary-model result was inspected"
        ),
        as.character(spec$amendment_scope),
        fixed = TRUE
      ) &&
      grepl(
        "25 coefficients included exactly two non-finite entries",
        as.character(spec$amendment_scope),
        fixed = TRUE
      ) &&
      grepl(
        paste0(
          "archive/v43/charls_20260719T061050_nhanes_20260719T071156_",
          "log_time_ph_failure/"
        ),
        as.character(spec$amendment_scope),
        fixed = TRUE
      ) &&
      grepl(
        "v43_4 removes factor(cycle_label) only from the supportive log-time formula",
        as.character(spec$amendment_scope),
        fixed = TRUE
      ) &&
      grepl(
        "Both cohorts must rerun in full under one new registry",
        as.character(spec$amendment_scope),
        fixed = TRUE
      ) &&
      !is.null(spec$governance$registered_nonestimability_policy) &&
      grepl(
        "primary analyses and all other registered models remain fail-closed",
        as.character(spec$governance$registered_nonestimability_policy),
        fixed = TRUE
      ) &&
      !is.null(spec$governance$nhanes_ph_design_alias_amendment_policy) &&
      grepl(
        "two exactly redundant cycle indicators",
        as.character(spec$governance$nhanes_ph_design_alias_amendment_policy),
        fixed = TRUE
      ) &&
      grepl(
        "singular.ok=FALSE",
        as.character(spec$governance$nhanes_ph_design_alias_amendment_policy),
        fixed = TRUE
      ) &&
      !is.null(spec$governance$time_varying_reference_policy) &&
      grepl(
        "only v43_s3_nhanes_pn_e0_a1 may reference",
        as.character(spec$governance$time_varying_reference_policy),
        fixed = TRUE
      ) &&
      identical(
        spec$nhanes$mortality$time_heterogeneity$supportive_log_time_role,
        paste0(
          "weighted robust coxph one-degree-of-freedom E0-by-log(time) trend ",
          "diagnostic; supportive only, not an omnibus PH test and not a ",
          "replacement for the complex-survey primary or window models"
        )
      ) &&
      grepl(
        "corrected 23-coefficient contract",
        as.character(spec$governance$nhanes_ph_design_alias_amendment_policy),
        fixed = TRUE
      ) &&
      grepl(
        "ties='efron'",
        as.character(
          spec$nhanes$mortality$time_heterogeneity$supportive_formula
        ),
        fixed = TRUE
      ) &&
      identical(
        spec$nhanes$function_health_boundary$older_adult_sensitivity$status,
        "NOT_ESTIMABLE"
      ) &&
      identical(
        unname(as.integer(
          spec$nhanes$function_health_boundary$older_adult_sensitivity$registered_n
        )),
        3346L
      ) &&
      identical(
        unname(as.integer(
          spec$nhanes$function_health_boundary$older_adult_sensitivity$registered_events
        )),
        701L
      ) &&
      identical(
        unname(unlist(
          spec$nhanes$function_health_boundary$older_adult_sensitivity$registry_ids
        )),
        c(
          "v43_s3_nhanes_pn_e0_age60_79_a1",
          "v43_s3_nhanes_pn_e0_age60_79_a2"
        )
      ) &&
      grepl(
        "do not refit the panel",
        as.character(
          spec$nhanes$function_health_boundary$older_adult_sensitivity$model_attempt_policy
        ),
        fixed = TRUE
      ) &&
      identical(
        length(unlist(
          spec$nhanes$function_health_boundary$older_adult_sensitivity$rescue_prohibitions
        )),
        9L
      ) &&
      identical(
        spec$charls$mortality$time_structure$primary_time_basis,
        "factor(end_wave) + offset(log(nominal_years))"
      ) &&
      identical(
        spec$charls$mortality$time_structure$legacy_window_factor_status,
        "prohibited_nonestimable"
      ) &&
      identical(
        sort(unname(unlist(
          spec$charls$mortality$time_structure$legacy_all_event_windows
        ))),
        sort(c("W1_W3", "W1_W4", "W2_W4"))
      ) &&
      identical(
        unname(as.integer(unlist(
          spec$charls$mortality$time_structure$nominal_wave_year_grid
        ))),
        c(2011L, 2013L, 2015L, 2018L, 2020L)
      ),
    all(file.exists(required_paths[1:7])),
    file.exists(required_paths[8]) && file.info(required_paths[8])$size > 0,
    all(inputs$exists),
    all(package_versions$available_before_new_install[package_versions$package %in% c("R", spec$software$stage0_2_packages)]),
    all(package_versions$available_before_new_install[package_versions$package %in% spec$software$stage3_required_packages]),
    all(spec$software$later_optional_packages %in% package_versions$package)
  ),
  detail = c(
    spec$status,
    paste(basename(required_paths[1:7]), collapse = "; "),
    relativize(required_paths[8], root),
    paste0(sum(inputs$exists), "/", nrow(inputs), " inputs present"),
    paste(package_versions$package[package_versions$package %in% spec$software$stage0_2_packages & !package_versions$available_before_new_install], collapse = "; "),
    paste(package_versions$package[package_versions$package %in% spec$software$stage3_required_packages & !package_versions$available_before_new_install], collapse = "; "),
    paste(spec$software$later_optional_packages, collapse = "; ")
  )
)
readr::write_csv(gate0, file.path(out_dir, "gate0_reproducibility_v43.csv"))

gate0_status <- if (all(gate0$pass)) "PASS" else "FAIL"
log_lines <- c(
  paste0("v43 Stage 0 completed: ", format(Sys.time(), tz = "Asia/Shanghai", usetz = TRUE)),
  paste0("Freeze phase: ", phase),
  paste0("Gate 0: ", gate0_status),
  paste0("Manifest entries: ", nrow(inputs)),
  paste0("Missing inputs: ", paste(basename(inputs$path[!inputs$exists]), collapse = "; ")),
  paste0("Outcome models fitted: 0")
)
writeLines(log_lines, file.path(log_dir, "00_freeze_and_manifest_v43.log"), useBytes = TRUE)

if (gate0_status != "PASS") {
  stop("Gate 0 failed. Inspect results/v43/gate0_reproducibility_v43.csv before continuing.", call. = FALSE)
}

if (identical(phase, "preliminary")) {
  message(
    "Preliminary freeze PASS. Authorization registry is absent by design. ",
    "Next: independent Stage 0-2 validation, no-model Stage 3 preflight, ",
    "gate-state promotion, then rerun with --phase=authorize."
  )
} else {
  validator_path <- file.path(out_dir, "gate1_2_validation_v43.csv")
  validator_source_inventory_path <- file.path(
    out_dir, "stage0_2_validated_source_inventory_v43.csv"
  )
  preflight_path <- file.path(out_dir, "stage3_preflight_validation_v43.csv")
  gate_state_path <- file.path(root, "work_v43", "gate_state_v43.yml")
  authorization_audit_path <- file.path(out_dir, "stage3_authorization_validation_v43.csv")

  authorization_checks <- list()
  add_authorization_check <- function(check, pass, observed, expected) {
    authorization_checks[[length(authorization_checks) + 1L]] <<- tibble(
      check = check,
      status = if (isTRUE(pass)) "PASS" else "FAIL",
      observed = as.character(observed),
      expected = as.character(expected)
    )
  }

  add_authorization_check(
    "gate0_recomputed_from_current_files",
    identical(gate0_status, "PASS"),
    paste0(sum(gate0$pass), "/", nrow(gate0), " Gate 0 checks PASS"),
    "all Gate 0 checks pass after recomputing the current input inventory"
  )

  gate_state <- tryCatch(yaml::read_yaml(gate_state_path), error = function(e) NULL)
  gate_state_ok <- !is.null(gate_state) &&
    identical(toupper(gate_state$gate0$status), "PASS") &&
    identical(toupper(gate_state$gate1$status), "PASS") &&
    identical(toupper(gate_state$gate2$status), "PASS") &&
    isTRUE(gate_state$outcome_execution_allowed)
  add_authorization_check(
    "gate_state_promoted_for_final_authorization",
    gate_state_ok,
    if (is.null(gate_state)) {
      "gate state missing or unreadable"
    } else {
      paste0(
        "Gate0=", gate_state$gate0$status,
        "; Gate1=", gate_state$gate1$status,
        "; Gate2=", gate_state$gate2$status,
        "; outcome_execution_allowed=", gate_state$outcome_execution_allowed
      )
    },
    "Gate0=PASS; Gate1=PASS; Gate2=PASS; outcome_execution_allowed=true"
  )

  validator_eval <- read_required_pass_table(validator_path)
  add_authorization_check(
    "independent_stage0_2_validator_pass",
    validator_eval$pass,
    validator_eval$detail,
    "all required independent Stage 0-2 validator checks PASS"
  )
  validator_source_inventory <- tryCatch(
    utils::read.csv(
      validator_source_inventory_path,
      stringsAsFactors = FALSE,
      check.names = FALSE
    ),
    error = function(e) NULL
  )
  validator_inventory_ok <- !is.null(validator_source_inventory) &&
    all(c("path", "exists", "bytes", "sha256") %in% names(validator_source_inventory)) &&
    nrow(validator_source_inventory) > 0L &&
    !anyDuplicated(normalizePath(validator_source_inventory$path, mustWork = FALSE))
  if (validator_inventory_ok) {
    current_validator_source_hash <- vapply(
      as.character(validator_source_inventory$path),
      sha256_file,
      character(1)
    )
    current_validator_source_bytes <- vapply(
      as.character(validator_source_inventory$path),
      function(path) {
        if (!file.exists(path) || dir.exists(path)) return(NA_real_)
        as.numeric(file.info(path)$size)
      },
      numeric(1)
    )
    validator_inventory_ok <- all(as_flag(validator_source_inventory$exists) %in% TRUE) &&
      all(!is.na(current_validator_source_hash)) &&
      identical(
        tolower(unname(current_validator_source_hash)),
        tolower(as.character(validator_source_inventory$sha256))
      ) &&
      isTRUE(all.equal(
        unname(current_validator_source_bytes),
        suppressWarnings(as.numeric(validator_source_inventory$bytes)),
        check.attributes = FALSE
      ))
  }
  add_authorization_check(
    "validator_source_inventory_matches_current_files",
    validator_inventory_ok,
    if (is.null(validator_source_inventory)) {
      "validated source inventory missing or unreadable"
    } else {
      paste0(nrow(validator_source_inventory), " validator-source rows checked")
    },
    "every Stage 0-2 YAML/CSV source validated before preflight still matches its recorded size and SHA-256"
  )

  preflight <- tryCatch(
    utils::read.csv(preflight_path, stringsAsFactors = FALSE, check.names = FALSE),
    error = function(e) NULL
  )
  expected_contract <- expected_preflight_checks() %>% arrange(cohort, check)
  preflight_schema <- c(
    "cohort", "check", "status", "hard_gate", "expected_check", "observed", "expected",
    "check_contract_sha256", "stable_input_inventory_sha256",
    "stage0_script_sha256", "validator_script_sha256",
    "preflight_script_sha256", "charls_script_sha256", "nhanes_script_sha256",
    "finalizer_script_sha256",
    "analysis_spec_sha256", "charls_core_sha256", "charls_ledger_sha256",
    "charls_e0_sha256", "nhanes_ledger_sha256", "nhanes_donor_sha256",
    "nhanes_e0_sha256", "nhanes_function_routing_audit_sha256",
    "nhanes_function_proxy_evidence_sha256", "renv_lock_sha256", "validator_report_sha256",
    "validator_source_inventory_sha256", "preliminary_manifest_sha256", "run_timestamp"
  )
  schema_ok <- !is.null(preflight) && all(preflight_schema %in% names(preflight))
  add_authorization_check(
    "preflight_report_schema_complete",
    schema_ok,
    if (is.null(preflight)) "missing or unreadable" else paste(names(preflight), collapse = "; "),
    paste(preflight_schema, collapse = "; ")
  )

  contract_ok <- FALSE
  hard_ok <- FALSE
  snapshot_ok <- FALSE
  snapshot_observed <- "preflight report unavailable"
  current_inventory_hash <- inventory_sha256(inputs)
  if (schema_ok) {
    observed_contract <- preflight %>%
      transmute(cohort = as.character(cohort), check = as.character(check)) %>%
      arrange(cohort, check)
    contract_ok <- nrow(observed_contract) == nrow(expected_contract) &&
      !anyDuplicated(paste(observed_contract$cohort, observed_contract$check, sep = "|")) &&
      identical(as.data.frame(observed_contract), as.data.frame(expected_contract)) &&
      all(as.character(preflight$check_contract_sha256) == check_contract_sha256())
    hard <- as_flag(preflight$hard_gate)
    expected_flag <- as_flag(preflight$expected_check)
    preflight_run_timestamp <- unique(as.character(preflight$run_timestamp))
    hard_ok <- all(hard %in% TRUE) && all(expected_flag %in% TRUE) &&
      all(toupper(as.character(preflight$status)) == "PASS") &&
      length(preflight_run_timestamp) == 1L &&
      !is.na(preflight_run_timestamp) && nzchar(preflight_run_timestamp)

    snapshot_paths <- c(
      stage0_script_sha256 = file.path(root, "R", "v43", "00_freeze_and_manifest.R"),
      validator_script_sha256 = file.path(root, "R", "v43", "03_validate_stage0_2.R"),
      preflight_script_sha256 = file.path(root, "R", "v43", "03b_stage3_preflight.R"),
      charls_script_sha256 = file.path(root, "R", "v43", "04_charls_stage3_primary_mortality.R"),
      nhanes_script_sha256 = file.path(root, "R", "v43", "05_nhanes_stage3_primary_mortality.R"),
      finalizer_script_sha256 = file.path(root, "R", "v43", "06_finalize_stage3_outputs.R"),
      analysis_spec_sha256 = spec_path,
      charls_core_sha256 = resolve(spec$inputs$charls_core),
      charls_ledger_sha256 = file.path(root, "derived_sensitive", "v43", "charls_stage1_ledger_v43.rds"),
      charls_e0_sha256 = file.path(root, "results", "v43", "charls_e0_scale_v43.csv"),
      nhanes_ledger_sha256 = file.path(root, "derived_sensitive", "v43", "nhanes_stage1_ledger_v43.rds"),
      nhanes_donor_sha256 = resolve(spec$inputs$nhanes_ready),
      nhanes_e0_sha256 = file.path(root, "results", "v43", "nhanes_e0_scale_v43.csv"),
      nhanes_function_routing_audit_sha256 = file.path(root, "results", "v43", "nhanes_function_routing_audit_v43.csv"),
      nhanes_function_proxy_evidence_sha256 = file.path(root, "output", "qa", "v43_NHANES_FUNCTION_PROXY_EVIDENCE_20260716.md"),
      renv_lock_sha256 = resolve(spec$software$lockfile),
      validator_report_sha256 = validator_path,
      validator_source_inventory_sha256 = validator_source_inventory_path
    )
    current_snapshot <- vapply(snapshot_paths, sha256_file, character(1))
    report_snapshot <- vapply(
      names(current_snapshot),
      function(name) {
        values <- unique(tolower(as.character(preflight[[name]])))
        if (length(values) == 1L) values[[1]] else NA_character_
      },
      character(1)
    )
    report_inventory <- unique(tolower(as.character(preflight$stable_input_inventory_sha256)))
    report_inventory_scalar <- if (length(report_inventory) == 1L) report_inventory[[1]] else NA_character_
    snapshot_ok <- length(report_inventory) == 1L &&
      identical(report_inventory_scalar, tolower(current_inventory_hash)) &&
      all(!is.na(current_snapshot)) &&
      all(!is.na(report_snapshot)) &&
      identical(tolower(unname(current_snapshot)), unname(report_snapshot))
    snapshot_observed <- paste0(
      "inventory=", substr(report_inventory_scalar, 1, 12), "/",
      substr(current_inventory_hash, 1, 12), "; ",
      paste(
        names(current_snapshot),
        paste0(substr(report_snapshot, 1, 10), "/", substr(current_snapshot, 1, 10)),
        sep = "=",
        collapse = "; "
      )
    )
  }
  add_authorization_check(
    "preflight_fixed_unique_check_contract",
    contract_ok,
    if (is.null(preflight)) "preflight unavailable" else
      paste0(nrow(preflight), " rows; ", length(unique(preflight$cohort)), " cohort domains"),
    paste0(nrow(expected_contract), " unique fixed checks across BOTH/CHARLS/NHANES")
  )
  add_authorization_check(
    "preflight_all_fixed_checks_pass",
    hard_ok,
    if (is.null(preflight)) "preflight unavailable" else
      paste0(sum(toupper(as.character(preflight$status)) == "PASS"), "/", nrow(preflight), " PASS"),
    "all fixed preflight rows are hard gates and PASS"
  )
  add_authorization_check(
    "preflight_snapshot_matches_current_scripts_and_inputs",
    snapshot_ok,
    snapshot_observed,
    "current stable input inventory and every recorded script/key-input SHA-256 equal the no-model preflight snapshot"
  )

  authorization_audit <- dplyr::bind_rows(authorization_checks) %>%
    mutate(checked_at = format(Sys.time(), tz = "Asia/Shanghai", usetz = TRUE))
  readr::write_csv(authorization_audit, authorization_audit_path)

  if (!all(authorization_audit$status == "PASS")) {
    stop(
      "Final Stage 3 authorization failed. The authorization registry was not generated. ",
      "Inspect results/v43/stage3_authorization_validation_v43.csv.",
      call. = FALSE
    )
  }

  stable_inventory <- canonical_inventory(inputs)
  if (is.null(stable_inventory) || !nrow(stable_inventory)) {
    stop("Final stable input inventory could not be constructed.", call. = FALSE)
  }
  readr::write_csv(stable_inventory, stable_inventory_path)
  if (!identical(sha256_file(stable_inventory_path), current_inventory_hash)) {
    unlink(stable_inventory_path)
    stop(
      "Written stable input inventory does not reproduce the preflight-bound current inventory SHA-256.",
      call. = FALSE
    )
  }

  file_assets <- tibble(
    asset = c(
      "analysis_spec", "private_manifest", "decision_log", "stage3_blueprint",
      "stage3_preflight_script", "charls_stage3_script", "nhanes_stage3_script",
      "stage3_output_finalizer_script",
      "stage3_preflight_validation", "gate_state", "stage0_2_validator_report",
      "stage0_freeze_script", "stage0_2_validator_script", "charls_core",
      "charls_stage1_ledger", "charls_e0_scale", "nhanes_stage1_ledger",
      "nhanes_donor", "nhanes_e0_scale", "nhanes_function_routing_audit",
      "nhanes_function_proxy_evidence", "renv_lock", "stable_input_inventory",
      "stage3_authorization_validation", "stage0_2_validator_source_inventory"
    ),
    path = c(
      spec_path,
      file.path(out_dir, "input_manifest_private_v43.csv"),
      resolve(spec$governance$decision_log),
      file.path(root, "output", "qa", "v43_STAGE3_MODEL_BLUEPRINT_20260716.md"),
      file.path(root, "R", "v43", "03b_stage3_preflight.R"),
      file.path(root, "R", "v43", "04_charls_stage3_primary_mortality.R"),
      file.path(root, "R", "v43", "05_nhanes_stage3_primary_mortality.R"),
      file.path(root, "R", "v43", "06_finalize_stage3_outputs.R"),
      preflight_path,
      gate_state_path,
      validator_path,
      file.path(root, "R", "v43", "00_freeze_and_manifest.R"),
      file.path(root, "R", "v43", "03_validate_stage0_2.R"),
      resolve(spec$inputs$charls_core),
      file.path(root, "derived_sensitive", "v43", "charls_stage1_ledger_v43.rds"),
      file.path(root, "results", "v43", "charls_e0_scale_v43.csv"),
      file.path(root, "derived_sensitive", "v43", "nhanes_stage1_ledger_v43.rds"),
      resolve(spec$inputs$nhanes_ready),
      file.path(root, "results", "v43", "nhanes_e0_scale_v43.csv"),
      file.path(root, "results", "v43", "nhanes_function_routing_audit_v43.csv"),
      file.path(root, "output", "qa", "v43_NHANES_FUNCTION_PROXY_EVIDENCE_20260716.md"),
      resolve(spec$software$lockfile),
      stable_inventory_path,
      authorization_audit_path,
      validator_source_inventory_path
    )
  ) %>%
    mutate(
      exists = file.exists(path),
      bytes = ifelse(exists, file.info(path)$size, NA_real_),
      sha256 = vapply(path, sha256_file, character(1)),
      frozen_at = format(Sys.time(), tz = "Asia/Shanghai", usetz = TRUE)
    )
  authorization_assets <- file_assets
  if (
    !all(file_assets$exists) ||
      any(!grepl("^[0-9a-fA-F]{64}$", file_assets$sha256))
  ) {
    if (file.exists(stable_inventory_path)) unlink(stable_inventory_path)
    stop(
      "One or more final authorization assets disappeared or could not be hashed. ",
      "The authorization registry was not generated.",
      call. = FALSE
    )
  }
  readr::write_csv(authorization_assets, authorization_registry_path)
  message(
    "Final Stage 3 authorization PASS. Registry generated only after current-file ",
    "Gate 0, independent validation, fixed no-model preflight, and hash-snapshot checks."
  )
}
