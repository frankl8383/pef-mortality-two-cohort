# v43 CHARLS Stage 1-2 audit: source reconciliation, participant flow,
# repeated PEF measurement quality, cross-wave comparability, and outcome-blind
# E0 scaling.
#
# This script does not fit a mortality association, prediction, or other outcome
# model. Aggregate outputs are written to results/v43 and logs/v43. The sole
# row-level output is the contract-authorized ledger under derived_sensitive/v43.

suppressPackageStartupMessages({
  library(dplyr)
  library(haven)
  library(readr)
  library(tibble)
  library(tidyr)
  library(yaml)
})

project_root <- function() {
  args <- commandArgs(trailingOnly = FALSE)
  file_arg <- grep("^--file=", args, value = TRUE)
  if (length(file_arg)) {
    script <- sub("^--file=", "", file_arg[[1]])
    return(normalizePath(file.path(dirname(script), "..", ".."), mustWork = TRUE))
  }
  normalizePath(getwd(), mustWork = TRUE)
}

resolve_path <- function(root, path) {
  if (grepl("^/", path)) path else file.path(root, path)
}

to_num <- function(x) suppressWarnings(as.numeric(haven::zap_labels(haven::zap_missing(x))))
to_chr <- function(x) trimws(as.character(haven::zap_labels(haven::zap_missing(x))))

tag_code <- function(x) {
  vapply(seq_along(x), function(i) {
    value <- x[[i]]
    if (haven::is_tagged_na(value)) return(paste0(".", haven::na_tag(value)))
    if (is.na(value)) return("plain_NA")
    as.character(suppressWarnings(as.numeric(value)))
  }, character(1))
}

first_nonmissing <- function(x) {
  idx <- which(!is.na(x))
  if (!length(idx)) return(x[NA_integer_][1])
  x[idx[[1]]]
}

weighted_mean_simple <- function(x, w) {
  ok <- is.finite(x) & is.finite(w) & w > 0
  if (!any(ok)) return(NA_real_)
  sum(x[ok] * w[ok]) / sum(w[ok])
}

weighted_var_simple <- function(x, w) {
  ok <- is.finite(x) & is.finite(w) & w > 0
  if (sum(ok) < 2L) return(NA_real_)
  mu <- weighted_mean_simple(x[ok], w[ok])
  sum(w[ok] * (x[ok] - mu)^2) / sum(w[ok])
}

weighted_cor_simple <- function(x, y, w) {
  ok <- is.finite(x) & is.finite(y) & is.finite(w) & w > 0
  if (sum(ok) < 3L) return(NA_real_)
  x <- x[ok]
  y <- y[ok]
  w <- w[ok]
  mx <- sum(w * x) / sum(w)
  my <- sum(w * y) / sum(w)
  vx <- sum(w * (x - mx)^2) / sum(w)
  vy <- sum(w * (y - my)^2) / sum(w)
  if (!is.finite(vx) || !is.finite(vy) || vx <= 0 || vy <= 0) return(NA_real_)
  sum(w * (x - mx) * (y - my)) / sum(w) / sqrt(vx * vy)
}

markdown_table <- function(dat) {
  dat <- as.data.frame(dat, stringsAsFactors = FALSE)
  if (!nrow(dat)) return("_No rows._")
  dat[] <- lapply(dat, function(x) ifelse(is.na(x), "", as.character(x)))
  c(
    paste0("| ", paste(names(dat), collapse = " | "), " |"),
    paste0("| ", paste(rep("---", ncol(dat)), collapse = " | "), " |"),
    apply(dat, 1, function(x) paste0("| ", paste(x, collapse = " | "), " |"))
  )
}

read_zip_dta <- function(zip_path, member, cols) {
  td <- tempfile("charls_v43_zip_")
  dir.create(td, recursive = TRUE)
  on.exit(unlink(td, recursive = TRUE), add = TRUE)
  utils::unzip(zip_path, files = member, exdir = td, overwrite = TRUE)
  path <- file.path(td, member)
  if (!file.exists(path)) stop("Missing ZIP member after extraction: ", member, call. = FALSE)
  haven::read_dta(path, col_select = tidyselect::any_of(cols))
}

row_summary <- function(mat, fun) {
  apply(mat, 1, function(z) {
    z <- z[is.finite(z)]
    if (!length(z)) return(NA_real_)
    fun(z)
  })
}

top_two_difference <- function(mat) {
  apply(mat, 1, function(z) {
    z <- sort(z[is.finite(z)], decreasing = TRUE)
    if (length(z) < 2L) return(NA_real_)
    z[[1]] - z[[2]]
  })
}

icc_a1 <- function(mat) {
  y <- as.matrix(mat)
  y <- y[stats::complete.cases(y), , drop = FALSE]
  n <- nrow(y)
  k <- ncol(y)
  if (n < 3L || k < 2L) {
    return(c(n = n, k = k, ms_subject = NA_real_, ms_trial = NA_real_,
             ms_error = NA_real_, icc_a1 = NA_real_, icc_c1 = NA_real_))
  }
  grand <- mean(y)
  subject_mean <- rowMeans(y)
  trial_mean <- colMeans(y)
  ss_subject <- k * sum((subject_mean - grand)^2)
  ss_trial <- n * sum((trial_mean - grand)^2)
  ss_total <- sum((y - grand)^2)
  ss_error <- max(0, ss_total - ss_subject - ss_trial)
  ms_subject <- ss_subject / (n - 1)
  ms_trial <- ss_trial / (k - 1)
  ms_error <- ss_error / ((n - 1) * (k - 1))
  denom <- ms_subject + (k - 1) * ms_error + k * (ms_trial - ms_error) / n
  icc <- if (is.finite(denom) && denom > 0) (ms_subject - ms_error) / denom else NA_real_
  consistency_denom <- ms_subject + (k - 1) * ms_error
  icc_consistency <- if (is.finite(consistency_denom) && consistency_denom > 0) {
    (ms_subject - ms_error) / consistency_denom
  } else {
    NA_real_
  }
  c(n = n, k = k, ms_subject = ms_subject, ms_trial = ms_trial,
    ms_error = ms_error, icc_a1 = icc, icc_c1 = icc_consistency)
}

icc_bootstrap_ci <- function(mat, replicates) {
  y <- as.matrix(mat)
  y <- y[stats::complete.cases(y), , drop = FALSE]
  n <- nrow(y)
  if (n < 20L || replicates < 20L) {
    return(c(a_low = NA_real_, a_high = NA_real_, c_low = NA_real_, c_high = NA_real_))
  }
  vals <- replicate(replicates, {
    idx <- sample.int(n, n, replace = TRUE)
    unname(icc_a1(y[idx, , drop = FALSE])[c("icc_a1", "icc_c1")])
  })
  c(
    a_low = stats::quantile(vals[1, ], 0.025, na.rm = TRUE, names = FALSE),
    a_high = stats::quantile(vals[1, ], 0.975, na.rm = TRUE, names = FALSE),
    c_low = stats::quantile(vals[2, ], 0.025, na.rm = TRUE, names = FALSE),
    c_high = stats::quantile(vals[2, ], 0.975, na.rm = TRUE, names = FALSE)
  )
}

distribution_row <- function(x, wave, scope, metric, detail = "") {
  x <- x[is.finite(x)]
  if (!length(x)) {
    return(tibble(
      record_type = "distribution", wave = wave, scope = scope, metric = metric,
      n = 0L, mean = NA_real_, sd = NA_real_, min = NA_real_, p01 = NA_real_,
      p05 = NA_real_, p25 = NA_real_, median = NA_real_, p75 = NA_real_,
      p95 = NA_real_, p99 = NA_real_, max = NA_real_, value = NA_real_,
      denominator = NA_real_, percent = NA_real_, detail = detail
    ))
  }
  q <- as.numeric(stats::quantile(x, c(.01, .05, .25, .50, .75, .95, .99),
                                  na.rm = TRUE, names = FALSE))
  tibble(
    record_type = "distribution", wave = wave, scope = scope, metric = metric,
    n = length(x), mean = mean(x), sd = stats::sd(x), min = min(x),
    p01 = q[[1]], p05 = q[[2]], p25 = q[[3]], median = q[[4]], p75 = q[[5]],
    p95 = q[[6]], p99 = q[[7]], max = max(x), value = NA_real_,
    denominator = NA_real_, percent = NA_real_, detail = detail
  )
}

metric_row <- function(wave, scope, metric, value, n = NA_real_, denominator = NA_real_,
                       percent = NA_real_, detail = "") {
  tibble(
    record_type = "metric", wave = wave, scope = scope, metric = metric,
    n = n, mean = NA_real_, sd = NA_real_, min = NA_real_, p01 = NA_real_,
    p05 = NA_real_, p25 = NA_real_, median = NA_real_, p75 = NA_real_,
    p95 = NA_real_, p99 = NA_real_, max = NA_real_, value = value,
    denominator = denominator, percent = percent, detail = detail
  )
}

assertion_row <- function(check, pass, observed, expected, detail = "") {
  tibble(
    check = check,
    status = ifelse(isTRUE(pass), "PASS", "FAIL"),
    pass = isTRUE(pass),
    observed = as.character(observed),
    expected = as.character(expected),
    detail = detail
  )
}

gate_row <- function(gate, scope, check, status, pass, blocks_baseline_e0,
                     observed, expected, detail = "") {
  tibble(
    gate = gate, scope = scope, check = check, status = status,
    pass = pass, blocks_baseline_e0 = blocks_baseline_e0,
    observed = as.character(observed), expected = as.character(expected), detail = detail
  )
}

root <- project_root()
spec_path <- file.path(root, "work_v43", "analysis_spec_v43.yml")
spec <- yaml::read_yaml(spec_path)
out_dir <- file.path(root, "results", "v43")
log_dir <- file.path(root, "logs", "v43")
ledger_dir <- file.path(root, "derived_sensitive", "v43")
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(log_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(ledger_dir, recursive = TRUE, showWarnings = FALSE)

core_path <- resolve_path(root, spec$inputs$charls_core)
harmonized_zip <- resolve_path(root, spec$inputs$charls_harmonized_archive)
harmonized_member <- spec$inputs$charls_harmonized_member
wave5_zip <- resolve_path(root, spec$inputs$charls_wave5_archive)
stopifnot(file.exists(core_path), file.exists(harmonized_zip), file.exists(wave5_zip))

core <- readRDS(core_path)
core <- tibble::as_tibble(core)
if (!"participant_id" %in% names(core)) core$participant_id <- to_chr(core$ID)
core$participant_id <- to_chr(core$participant_id)

# Directly reconcile the selected raw Harmonized columns used by this audit.
raw_compare_cols <- unique(c(
  "ID", "communityID", "ragender", "r1agey", "r2agey", "r3agey",
  "r1mheight", "r2mheight", "r3mheight", "r1wtrespbioa", "r1wtrespbiob",
  as.vector(outer(paste0("r", 1:4), "iwstat", paste0)),
  as.vector(outer(paste0("r", 1:3), c(
    "puff1", "puff2", "puff3", "puff", "puffcomp", "puffpos", "puffeff"
  ), paste0))
))
raw_harmonized <- read_zip_dta(harmonized_zip, harmonized_member, raw_compare_cols)
raw_id <- to_chr(raw_harmonized$ID)
core_id <- to_chr(core$ID)
raw_to_core <- match(raw_id, core_id)
core_to_raw <- match(core_id, raw_id)

source_reconciliation <- bind_rows(
  tibble(
    check = c("harmonized_archive_member_present", "raw_row_count_matches_core",
              "raw_ID_unique", "core_participant_id_unique", "raw_IDs_match_core"),
    pass = c(
      harmonized_member %in% utils::unzip(harmonized_zip, list = TRUE)$Name,
      nrow(raw_harmonized) == nrow(core),
      !anyDuplicated(raw_id),
      !anyDuplicated(core$participant_id),
      all(!is.na(raw_to_core)) && setequal(raw_id, core_id)
    ),
    observed = c(
      harmonized_member,
      paste0(nrow(raw_harmonized), "/", nrow(core)),
      sum(duplicated(raw_id)),
      sum(duplicated(core$participant_id)),
      paste0(sum(!is.na(raw_to_core)), "/", length(raw_to_core))
    ),
    expected = c("member present", "equal row counts", "0 duplicate IDs",
                 "0 duplicate IDs", "all IDs matched"),
    detail = c(
      "Direct ZIP member check.",
      "Direct Harmonized DTA versus locked provisional core.",
      "Raw Harmonized participant identifier.",
      "Locked core participant identifier.",
      "Bidirectional set equality is also required."
    )
  )
)

raw_community <- to_chr(raw_harmonized$communityID)
core_community <- to_chr(core$communityID)[raw_to_core]
community_equal <- (is.na(raw_community) & is.na(core_community)) |
  (!is.na(raw_community) & !is.na(core_community) & raw_community == core_community)
participant_id_equal <- (is.na(core$participant_id) & is.na(core_id)) |
  (!is.na(core$participant_id) & !is.na(core_id) & core$participant_id == core_id)
source_reconciliation <- bind_rows(
  source_reconciliation,
  tibble(
    check = c("raw_core_field_communityID", "core_participant_id_equals_raw_ID"),
    pass = c(all(community_equal), all(participant_id_equal)),
    observed = c(as.character(sum(!community_equal)), as.character(sum(!participant_id_equal))),
    expected = c("0 mismatches", "0 mismatches"),
    detail = c(
      "Aggregate string reconciliation after ID matching.",
      "Derived participant_id must remain identical to the raw Harmonized ID."
    )
  )
)

numeric_compare <- setdiff(intersect(raw_compare_cols, names(raw_harmonized)), c("ID", "communityID"))
for (v in numeric_compare) {
  raw_v <- to_num(raw_harmonized[[v]])
  core_v <- to_num(core[[v]])[raw_to_core]
  equal <- (is.na(raw_v) & is.na(core_v)) |
    (is.finite(raw_v) & is.finite(core_v) & abs(raw_v - core_v) <= 1e-8)
  mismatch <- sum(!equal)
  source_reconciliation <- bind_rows(
    source_reconciliation,
    tibble(
      check = paste0("raw_core_field_", v), pass = mismatch == 0L,
      observed = as.character(mismatch), expected = "0 mismatches",
      detail = "Aggregate value/NA reconciliation after ID matching."
    )
  )
}

# Wave 5 sample/death status. The binary `died` variable contains Wave 5 new
# death ascertainment; deaths already known in W2-W4 are carried separately.
w5_raw <- read_zip_dta(wave5_zip, "Sample_Infor.dta", c("ID", "died"))
w5_raw_id <- to_chr(w5_raw$ID)
w5_raw_duplicate_id_n <- sum(duplicated(w5_raw_id))
w5 <- w5_raw %>%
  transmute(
    participant_id = to_chr(.data$ID),
    died_w5_raw = to_num(.data$died)
  ) %>%
  group_by(.data$participant_id) %>%
  summarise(died_w5_raw = first_nonmissing(.data$died_w5_raw), .groups = "drop") %>%
  mutate(
    died_w5 = case_when(
      .data$died_w5_raw == 1 ~ 1L,
      .data$died_w5_raw == 0 ~ 0L,
      TRUE ~ NA_integer_
    )
  )

dat <- core %>% left_join(w5, by = "participant_id")

# Frozen baseline biomarker weight: r1wtrespbiob with fallback only if absent.
weight_biomarker <- to_num(dat$r1wtrespbiob)
fallback <- is.na(weight_biomarker)
weight_biomarker[fallback] <- to_num(dat$r1wtrespbioa)[fallback]

lower_bound <- as.numeric(spec$charls$measurement$plausible_range_l_min[[1]])
upper_bound <- as.numeric(spec$charls$measurement$plausible_range_l_min[[2]])
repeatability_limit <- as.numeric(spec$charls$measurement$top_two_repeatability_flag_l_min)

trials_raw <- trials <- summaries <- list()
completion_status_rows <- list()
for (wave in 1:3) {
  raw_mat <- as.matrix(dat[paste0("r", wave, "puff", 1:3)])
  storage.mode(raw_mat) <- "numeric"
  trials_raw[[wave]] <- raw_mat
  mat <- raw_mat
  mat[!is.finite(mat) | mat < lower_bound | mat > upper_bound] <- NA_real_
  trials[[wave]] <- mat
  raw_completion <- raw_harmonized[[paste0("r", wave, "puffcomp")]][core_to_raw]
  completion_tags <- tag_code(raw_completion)
  raw_trial_started <- rowSums(is.finite(raw_mat)) > 0L
  documented_started_or_completed <- completion_tags %in% c("1", ".c", ".x") |
    raw_trial_started
  completion_status_rows[[wave]] <- tibble(
    wave = paste0("W", wave),
    status = c(
      "1_willing_able_complete", "0_not_willing_or_able", ".c_completed_test",
      ".x_tried_unable", ".r_refused", ".a_age_ineligible", ".t_not_tested",
      ".s_skip", ".p_proxy", ".m_missing", "other_tag_or_plain_missing"
    ),
    n = c(
      sum(completion_tags == "1"), sum(completion_tags == "0"),
      sum(completion_tags == ".c"), sum(completion_tags == ".x"),
      sum(completion_tags == ".r"), sum(completion_tags == ".a"),
      sum(completion_tags == ".t"), sum(completion_tags == ".s"),
      sum(completion_tags == ".p"), sum(completion_tags == ".m"),
      sum(!completion_tags %in% c("1", "0", ".c", ".x", ".r", ".a", ".t", ".s", ".p", ".m"))
    ),
    detail = "Raw Harmonized tagged status before zap_missing; true attempt is not fully recoverable."
  )
  summaries[[wave]] <- tibble(
    valid_n = rowSums(is.finite(mat)),
    row_max = row_summary(mat, max),
    row_mean = row_summary(mat, mean),
    row_median = row_summary(mat, stats::median),
    top_two_diff = top_two_difference(mat),
    test_started_or_completed = documented_started_or_completed,
    completion_yes = completion_tags %in% c("1", ".c"),
    not_willing_or_able = completion_tags == "0",
    tried_unable = completion_tags == ".x",
    refused = completion_tags == ".r",
    standing = to_num(dat[[paste0("r", wave, "puffpos")]]) ==
      as.numeric(spec$charls$measurement$standing_code),
    full_effort = to_num(dat[[paste0("r", wave, "puffeff")]]) ==
      as.numeric(spec$charls$measurement$full_effort_code)
  ) %>%
    mutate(
      standing = ifelse(is.na(.data$standing), FALSE, .data$standing),
      full_effort = ifelse(is.na(.data$full_effort), FALSE, .data$full_effort),
      strict_protocol = .data$standing & .data$full_effort & .data$valid_n >= 2L,
      complete_three = .data$valid_n == 3L,
      boundary_floor = .data$row_max == lower_bound,
      boundary_ceiling = .data$row_max == upper_bound
    )
}
completion_status_audit <- bind_rows(completion_status_rows)

status_cols <- lapply(1:4, function(w) to_num(dat[[paste0("r", w, "iwstat")]]))
names(status_cols) <- paste0("w", 1:4)
status_known_wave <- lapply(status_cols, function(x) x %in% c(1, 4, 5, 6))
status_known_wave <- lapply(status_known_wave, function(x) ifelse(is.na(x), FALSE, x))
prior_death_w2_w4 <- Reduce(`|`, lapply(status_cols[2:4], function(x) x %in% c(5, 6)))
prior_death_w2_w4[is.na(prior_death_w2_w4)] <- FALSE
death_status_matrix <- cbind(status_cols[[2]], status_cols[[3]], status_cols[[4]])
first_death_status_wave <- apply(death_status_matrix, 1, function(z) {
  idx <- which(z %in% c(5, 6))
  if (!length(idx)) return(NA_integer_)
  idx[[1]] + 1L
})
first_death_status_code <- apply(death_status_matrix, 1, function(z) {
  idx <- which(z %in% c(5, 6))
  if (!length(idx)) return(NA_integer_)
  as.integer(z[idx[[1]]])
})
code6_without_earlier_5 <- first_death_status_code == 6L
code6_without_earlier_5[is.na(code6_without_earlier_5)] <- FALSE
new_death_w2_w4 <- prior_death_w2_w4
alive_after_prior_death <- apply(death_status_matrix, 1, function(z) {
  death_idx <- which(z %in% c(5, 6))
  if (!length(death_idx)) return(FALSE)
  if (death_idx[[1]] >= length(z)) return(FALSE)
  any(z[seq.int(death_idx[[1]] + 1L, length(z))] %in% c(1, 4), na.rm = TRUE)
})
new_death_w5 <- !prior_death_w2_w4 & dat$died_w5 == 1L
new_death_w5[is.na(new_death_w5)] <- FALSE
prior_death_w5_alive_conflict <- prior_death_w2_w4 & dat$died_w5 == 0L
prior_death_w5_death_duplicate <- prior_death_w2_w4 & dat$died_w5 == 1L
prior_death_w5_alive_conflict[is.na(prior_death_w5_alive_conflict)] <- FALSE
prior_death_w5_death_duplicate[is.na(prior_death_w5_death_duplicate)] <- FALSE
future_status_known <- Reduce(`|`, status_known_wave[2:4]) | !is.na(dat$died_w5)

age_w1 <- to_num(dat$r1agey)
sex_code <- to_num(dat$ragender)
baseline_age_weight <- is.finite(age_w1) & age_w1 >= spec$charls$age_min &
  is.finite(weight_biomarker) & weight_biomarker > 0
baseline_measurement_eligible <- baseline_age_weight & sex_code %in% c(1, 2) &
  is.finite(summaries[[1]]$row_max)
primary_mortality_eligible <- baseline_measurement_eligible & future_status_known
primary_death_event <- new_death_w2_w4 | new_death_w5

# Wave-by-wave status and PEF flow. Code 1 is interviewed; code 4 is
# nonresponse with known-alive status (`nr, alive`), not proxy. Code 5 is a
# newly reported death, code 6 is a previously reported death, and 0/7/9/tagged
# missing values are not treated as known alive. Tagged `.p` is proxy.
raw_status_tags <- lapply(1:4, function(wave) {
  tag_code(raw_harmonized[[paste0("r", wave, "iwstat")]][core_to_raw])
})
flow_rows <- vector("list", 5)
for (wave in 1:4) {
  tags <- raw_status_tags[[wave]]
  n_code1 <- sum(tags == "1")
  n_code4 <- sum(tags == "4")
  n_code5 <- sum(tags == "5")
  n_code6 <- sum(tags == "6")
  n_code7 <- sum(tags == "7")
  n_code9 <- sum(tags == "9")
  n_code0 <- sum(tags == "0")
  n_proxy_tag <- sum(tags == ".p")
  known_tags <- c("0", "1", "4", "5", "6", "7", "9", ".p", "plain_NA")
  n_other_tagged <- sum(grepl("^\\.", tags) & !tags %in% c(".p"))
  n_plain_missing <- sum(tags == "plain_NA")
  n_other_numeric <- sum(!grepl("^\\.", tags) & !tags %in% known_tags)
  alive <- n_code1 + n_code4
  new_death <- n_code5
  carried_death <- n_code6
  known <- alive + new_death + carried_death
  test_started <- if (wave <= 3) sum(summaries[[wave]]$test_started_or_completed) else 0L
  valid <- if (wave <= 3) sum(is.finite(summaries[[wave]]$row_max)) else 0L
  flow_rows[[wave]] <- tibble(
    wave = wave, source = "Harmonized CHARLS D",
    core_n = nrow(dat), status_known = known, status_alive = alive,
    status_new_death = new_death, status_carried_death = carried_death,
    status_unknown = nrow(dat) - known,
    status_code1_interviewed = n_code1,
    status_code4_nonresponse_alive = n_code4,
    status_code5_new_death = n_code5,
    status_code6_prior_death = n_code6,
    status_code7 = n_code7, status_code9 = n_code9, status_code0 = n_code0,
    status_tagged_proxy = n_proxy_tag, status_other_tagged_missing = n_other_tagged,
    status_plain_missing = n_plain_missing, status_other_numeric = n_other_numeric,
    pef_test_started_or_completed = test_started,
    pef_attempted = test_started,
    pef_attempted_definition = "backward-compatible alias for conservative documented test-started/completed lower bound; true attempt not fully reconstructable",
    pef_valid = valid,
    pef_completion_yes = if (wave <= 3) sum(summaries[[wave]]$completion_yes) else 0L,
    pef_not_willing_or_able = if (wave <= 3) sum(summaries[[wave]]$not_willing_or_able) else 0L,
    pef_tried_unable_tag = if (wave <= 3) sum(summaries[[wave]]$tried_unable) else 0L,
    pef_refused_tag = if (wave <= 3) sum(summaries[[wave]]$refused) else 0L,
    pef_standing = if (wave <= 3) sum(summaries[[wave]]$standing &
      is.finite(summaries[[wave]]$row_max)) else 0L,
    pef_full_effort = if (wave <= 3) sum(summaries[[wave]]$full_effort &
      is.finite(summaries[[wave]]$row_max)) else 0L,
    pef_boundary_floor = if (wave <= 3) sum(summaries[[wave]]$boundary_floor, na.rm = TRUE) else 0L,
    pef_boundary_ceiling = if (wave <= 3) sum(summaries[[wave]]$boundary_ceiling, na.rm = TRUE) else 0L
  )
}
w5_alive <- sum(!prior_death_w2_w4 & dat$died_w5 == 0L, na.rm = TRUE)
w5_new_death <- sum(new_death_w5)
w5_carried <- sum(prior_death_w2_w4)
w5_known <- w5_alive + w5_new_death + w5_carried
flow_rows[[5]] <- tibble(
  wave = 5, source = "CHARLS 2020 Sample_Infor plus carried W2-W4 death",
  core_n = nrow(dat), status_known = w5_known, status_alive = w5_alive,
  status_new_death = w5_new_death, status_carried_death = w5_carried,
  status_unknown = nrow(dat) - w5_known,
  status_code1_interviewed = NA_integer_, status_code4_nonresponse_alive = NA_integer_,
  status_code5_new_death = w5_new_death, status_code6_prior_death = w5_carried,
  status_code7 = NA_integer_, status_code9 = NA_integer_, status_code0 = NA_integer_,
  status_tagged_proxy = NA_integer_, status_other_tagged_missing = NA_integer_,
  status_plain_missing = NA_integer_, status_other_numeric = NA_integer_,
  pef_test_started_or_completed = 0L, pef_attempted = 0L,
  pef_attempted_definition = "not measured in Wave 5",
  pef_valid = 0L, pef_completion_yes = 0L, pef_not_willing_or_able = 0L,
  pef_tried_unable_tag = 0L, pef_refused_tag = 0L,
  pef_standing = 0L, pef_full_effort = 0L,
  pef_boundary_floor = 0L, pef_boundary_ceiling = 0L
)
cohort_flow <- bind_rows(flow_rows)

# Reproduce the v42 N/death anchor under its exact historical eligibility rules.
historical_base <- dat$baseline_respiratory_axis_eligible %in% TRUE &
  is.finite(to_num(dat$pef_resid_z_w1)) & is.finite(to_num(dat$age_w1)) &
  !is.na(dat$sex_label) & is.finite(to_num(dat$bmi_w1)) &
  is.finite(to_num(dat$smoke_ever_w1)) & !is.na(dat$community_id) &
  is.finite(to_num(dat$weight_biomarker_w1)) & to_num(dat$weight_biomarker_w1) > 0
historical_event <- prior_death_w2_w4 | dat$died_w5 == 1L
historical_event[is.na(historical_event)] <- FALSE
historical_n <- sum(historical_base)
historical_deaths <- sum(historical_event[historical_base])

source_reconciliation <- bind_rows(
  source_reconciliation,
  tibble(
    check = c("wave5_raw_ID_unique_before_dedup", "wave5_sample_ID_unique_after_dedup",
              "wave5_status_linked_to_core", "prior_death_then_wave5_alive_conflict",
              "prior_death_repeated_as_wave5_new_death", "alive_after_prior_death_W2_W4",
              "v42_historical_N_12569", "v42_historical_deaths_1681"),
    pass = c(
      w5_raw_duplicate_id_n == 0L,
      !anyDuplicated(w5$participant_id),
      sum(!is.na(dat$died_w5)) > 19000,
      sum(prior_death_w5_alive_conflict) == 0L,
      sum(prior_death_w5_death_duplicate) == 0L,
      sum(alive_after_prior_death) == 0L,
      historical_n == 12569,
      historical_deaths == 1681
    ),
    observed = c(
      as.character(w5_raw_duplicate_id_n),
      as.character(sum(duplicated(w5$participant_id))),
      as.character(sum(!is.na(dat$died_w5))),
      as.character(sum(prior_death_w5_alive_conflict)),
      as.character(sum(prior_death_w5_death_duplicate)),
      as.character(sum(alive_after_prior_death)),
      as.character(historical_n),
      as.character(historical_deaths)
    ),
    expected = c("0 duplicate IDs", "0 duplicate IDs", ">19000 linked statuses",
                 "0 contradictions", "0 duplicate events", "0 alive-after-death sequences",
                 "12569", "1681"),
    detail = c(
      "Raw Wave 5 Sample_Infor before any grouping.",
      "Wave 5 Sample_Infor after deterministic deduplication.",
      "Aggregate linkage count; unmatched source rows are retained only in source audit.",
      "A participant previously dead cannot be reclassified as alive in Wave 5.",
      "Wave 5 died=1 must not be counted again after a W2-W4 death.",
      "Known alive status after a death report is a hard sequence contradiction.",
      "Exact v42 complete-covariate contract, not the v43 primary sample.",
      "Exact v42 event construction, not the v43 primary event contract."
    )
  )
)

status_event_anchors <- bind_rows(
  tibble(
    anchor_id = "source_core",
    analysis_set = "all_locked_core_rows",
    definition = "Locked provisional Harmonized core",
    n = nrow(dat), deaths = NA_integer_
  ),
  tibble(
    anchor_id = "baseline_age_positive_weight",
    analysis_set = "v43_measurement_source",
    definition = "Wave 1 age >=45 and positive baseline biomarker weight",
    n = sum(baseline_age_weight), deaths = sum(primary_death_event[baseline_age_weight])
  ),
  tibble(
    anchor_id = "baseline_valid_rowmax_pef",
    analysis_set = "v43_baseline_measurement_eligible",
    definition = "Age/weight eligible, sex known, valid Wave 1 rowmax PEF 30-890 L/min",
    n = sum(baseline_measurement_eligible), deaths = sum(primary_death_event[baseline_measurement_eligible])
  ),
  tibble(
    anchor_id = "primary_mortality_eligible",
    analysis_set = "v43_primary_P_C_upper_bound",
    definition = "Baseline measurement eligible and at least one known W2-W5 vital status",
    n = sum(primary_mortality_eligible), deaths = sum(primary_death_event[primary_mortality_eligible])
  ),
  tibble(
    anchor_id = "v42_historical_complete_covariate",
    analysis_set = "historical_reconciliation",
    definition = "Exact v42 complete-covariate and legacy status contract",
    n = historical_n, deaths = historical_deaths
  )
)

# Sequential baseline flow for one-way reconstruction of the primary P-C upper
# bound. This is distinct from the participant-by-wave status ledger above.
sequential_flags <- list(
  source_core = rep(TRUE, nrow(dat)),
  wave1_known_alive = status_cols[[1]] %in% c(1, 4),
  age_45_plus = NULL,
  positive_biomarker_weight = NULL,
  known_sex = NULL,
  valid_wave1_rowmax_pef = NULL,
  subsequent_vital_status_known = NULL
)
sequential_flags$wave1_known_alive[is.na(sequential_flags$wave1_known_alive)] <- FALSE
sequential_flags$age_45_plus <- sequential_flags$wave1_known_alive &
  is.finite(age_w1) & age_w1 >= spec$charls$age_min
sequential_flags$positive_biomarker_weight <- sequential_flags$age_45_plus &
  is.finite(weight_biomarker) & weight_biomarker > 0
sequential_flags$known_sex <- sequential_flags$positive_biomarker_weight & sex_code %in% c(1, 2)
sequential_flags$valid_wave1_rowmax_pef <- sequential_flags$known_sex &
  is.finite(summaries[[1]]$row_max)
sequential_flags$subsequent_vital_status_known <- sequential_flags$valid_wave1_rowmax_pef &
  future_status_known

sequential_labels <- c(
  source_core = "All locked Harmonized core rows",
  wave1_known_alive = "Wave 1 interviewed/known alive",
  age_45_plus = "Age at least 45 years",
  positive_biomarker_weight = "Positive Wave 1 biomarker survey weight",
  known_sex = "Known sex",
  valid_wave1_rowmax_pef = "Valid Wave 1 maximum of trials, 30-890 L/min",
  subsequent_vital_status_known = "At least one explicit W2-W5 vital status"
)
sequential_flow <- bind_rows(lapply(seq_along(sequential_flags), function(i) {
  flag <- sequential_flags[[i]]
  n_now <- sum(flag)
  n_prev <- if (i == 1L) n_now else sum(sequential_flags[[i - 1L]])
  tibble(
    flow_branch = "primary_P_C_upper_bound", step_order = i,
    step_id = names(sequential_flags)[[i]], step_label = unname(sequential_labels[[i]]),
    n = n_now, excluded_from_previous = n_prev - n_now,
    deaths = sum(primary_death_event[flag]),
    definition = "Nested sequential flow; deaths are descriptive event anchors, not model results."
  )
}))

# Within-session trial distributions, order effects, protocol, and boundary flags.
trial_qc <- list()
for (wave in 1:3) {
  mat <- trials[[wave]]
  ss <- summaries[[wave]]
  wave_label <- paste0("W", wave)
  trial_qc[[length(trial_qc) + 1L]] <- bind_rows(
    distribution_row(mat[, 1], wave_label, "all_valid", "trial_1_l_min", "PEF in L/min"),
    distribution_row(mat[, 2], wave_label, "all_valid", "trial_2_l_min", "PEF in L/min"),
    distribution_row(mat[, 3], wave_label, "all_valid", "trial_3_l_min", "PEF in L/min"),
    distribution_row(ss$row_max, wave_label, "all_valid", "rowmax_maximum_valid_trials_l_min", "Primary trial summary"),
    distribution_row(ss$row_mean, wave_label, "all_valid", "mean_of_valid_trials_l_min"),
    distribution_row(ss$row_median, wave_label, "all_valid", "median_of_valid_trials_l_min"),
    metric_row(wave_label, "paired_trials", "mean_trial2_minus_trial1_l_min",
               mean(mat[, 2] - mat[, 1], na.rm = TRUE), n = sum(complete.cases(mat[, 1:2]))),
    metric_row(wave_label, "paired_trials", "mean_trial3_minus_trial2_l_min",
               mean(mat[, 3] - mat[, 2], na.rm = TRUE), n = sum(complete.cases(mat[, 2:3]))),
    metric_row(wave_label, "paired_trials", "mean_rowmax_minus_trial1_l_min",
               mean(ss$row_max - mat[, 1], na.rm = TRUE), n = sum(complete.cases(ss$row_max, mat[, 1]))),
    metric_row(wave_label, "protocol", "documented_test_started_or_completed_lower_bound",
               sum(ss$test_started_or_completed),
               n = sum(ss$test_started_or_completed), denominator = nrow(dat),
               percent = 100 * mean(ss$test_started_or_completed),
               detail = "Conservative lower bound from raw trials, completion=1/.c, or tried-unable=.x; true attempted status is not fully reconstructable."),
    metric_row(wave_label, "protocol", "standing_position_code_1_among_valid_pef",
               sum(ss$standing & is.finite(ss$row_max)),
               n = sum(ss$standing & is.finite(ss$row_max)),
               denominator = sum(is.finite(ss$row_max)),
               percent = 100 * mean(ss$standing[is.finite(ss$row_max)]),
               detail = "Protocol proportion is defined among rows with valid PEF."),
    metric_row(wave_label, "protocol", "full_effort_code_1_among_valid_pef",
               sum(ss$full_effort & is.finite(ss$row_max)),
               n = sum(ss$full_effort & is.finite(ss$row_max)),
               denominator = sum(is.finite(ss$row_max)),
               percent = 100 * mean(ss$full_effort[is.finite(ss$row_max)]),
               detail = "Protocol proportion is defined among rows with valid PEF."),
    metric_row(wave_label, "repeatability", "at_least_two_valid_trials", sum(ss$valid_n >= 2),
               n = sum(ss$valid_n >= 2), denominator = sum(ss$valid_n >= 1),
               percent = 100 * mean(ss$valid_n[ss$valid_n >= 1] >= 2)),
    metric_row(wave_label, "repeatability", "top_two_difference_le_40_l_min",
               sum(ss$top_two_diff <= repeatability_limit, na.rm = TRUE),
               n = sum(ss$top_two_diff <= repeatability_limit, na.rm = TRUE),
               denominator = sum(is.finite(ss$top_two_diff)),
               percent = 100 * mean(ss$top_two_diff <= repeatability_limit, na.rm = TRUE),
               detail = "Top-two repeatability flag is 40 L/min."),
    metric_row(wave_label, "boundary", "rowmax_equal_30_l_min", sum(ss$boundary_floor),
               n = sum(ss$boundary_floor), denominator = sum(is.finite(ss$row_max)),
               percent = 100 * mean(ss$boundary_floor[is.finite(ss$row_max)]),
               detail = "30 is a left boundary code, retained primary and excluded in sensitivity."),
    metric_row(wave_label, "boundary", "rowmax_equal_890_l_min", sum(ss$boundary_ceiling),
               n = sum(ss$boundary_ceiling), denominator = sum(is.finite(ss$row_max)),
               percent = 100 * mean(ss$boundary_ceiling[is.finite(ss$row_max)]),
               detail = "890 is a right boundary code, retained primary and excluded in sensitivity."),
    metric_row(wave_label, "harmonized_missing", "literal_993_or_999_among_prefilter_trials",
               sum(trials_raw[[wave]] %in% c(993, 999), na.rm = TRUE),
               detail = "Original 993 attempted-but-failed and 999 refused are mapped to missing in Harmonized CHARLS.")
  )
}
trial_qc <- bind_rows(trial_qc)

# Closed-form absolute-agreement single-measure ICC(A,1), without psych/lmer.
set.seed(as.integer(spec$seeds$measurement_bootstrap))
bootstrap_replicates <- 200L
reliability <- list()
icc_cache <- list()
for (wave in 1:3) {
  mat <- trials[[wave]]
  ss <- summaries[[wave]]
  for (scope in c("all_complete_three", "standing_full_effort_complete_three")) {
    keep <- ss$complete_three
    if (scope == "standing_full_effort_complete_three") keep <- keep & ss$standing & ss$full_effort
    y <- mat[keep, , drop = FALSE]
    est <- icc_a1(y)
    ci <- icc_bootstrap_ci(y, bootstrap_replicates)
    trial_systematic_variance <- max(0, unname(est[["ms_trial"]] - est[["ms_error"]])) /
      unname(est[["n"]])
    sem_consistency <- sqrt(unname(est[["ms_error"]]))
    sem_absolute <- sqrt(unname(est[["ms_error"]]) + trial_systematic_variance)
    row_sd <- apply(y, 1, stats::sd)
    row_mean <- rowMeans(y)
    within_cv <- row_sd / row_mean
    key <- paste0("W", wave, "_", scope)
    icc_cache[[key]] <- est
    reliability[[length(reliability) + 1L]] <- tibble(
      metric_type = "same_session_reliability", wave_or_pair = paste0("W", wave),
      scope = scope, n = as.integer(est[["n"]]), trials_per_person = as.integer(est[["k"]]),
      method = "closed form: ICC(A,1)=ICC(2,1) absolute agreement; ICC(C,1)=ICC(3,1) consistency",
      estimate = unname(est[["icc_a1"]]), ci_low = ci[["a_low"]], ci_high = ci[["a_high"]],
      icc_absolute_a1 = unname(est[["icc_a1"]]),
      icc_consistency_c1 = unname(est[["icc_c1"]]),
      icc_consistency_ci_low = ci[["c_low"]], icc_consistency_ci_high = ci[["c_high"]],
      ms_subject = unname(est[["ms_subject"]]), ms_trial = unname(est[["ms_trial"]]),
      ms_error = unname(est[["ms_error"]]),
      trial_systematic_variance_l_min2 = trial_systematic_variance,
      sem_l_min = sem_absolute, sem_absolute_l_min = sem_absolute,
      sem_consistency_l_min = sem_consistency,
      repeatability_coefficient_l_min = 1.96 * sqrt(2) * sem_absolute,
      repeatability_coefficient_absolute_l_min = 1.96 * sqrt(2) * sem_absolute,
      repeatability_coefficient_consistency_l_min = 1.96 * sqrt(2) * sem_consistency,
      smallest_detectable_difference_l_min = 1.96 * sqrt(2) * sem_absolute,
      smallest_detectable_difference_consistency_l_min = 1.96 * sqrt(2) * sem_consistency,
      median_within_subject_cv = stats::median(within_cv[is.finite(within_cv)], na.rm = TRUE),
      threshold = spec$measurement_gates$same_session_icc_limited_below,
      decision = ifelse(est[["icc_a1"]] >= spec$measurement_gates$same_session_icc_limited_below,
                        "PASS", "MEASUREMENT-LIMITED")
    )
  }
}

# Approximate W1-W2 and W1-W3 change reliability using the mean of three trials;
# this is diagnostic only because rowmax is the frozen primary summary.
for (pair in list(c(1, 2), c(1, 3))) {
  a <- pair[[1]]
  b <- pair[[2]]
  keep <- baseline_measurement_eligible & summaries[[a]]$complete_three &
    summaries[[b]]$complete_three & summaries[[a]]$standing & summaries[[a]]$full_effort &
    summaries[[b]]$standing & summaries[[b]]$full_effort
  change <- summaries[[b]]$row_mean - summaries[[a]]$row_mean
  obs_var <- weighted_var_simple(change[keep], weight_biomarker[keep])
  mse_a <- icc_cache[[paste0("W", a, "_standing_full_effort_complete_three")]][["ms_error"]]
  mse_b <- icc_cache[[paste0("W", b, "_standing_full_effort_complete_three")]][["ms_error"]]
  error_var <- mse_a / 3 + mse_b / 3
  change_rel <- 1 - error_var / obs_var
  reliability[[length(reliability) + 1L]] <- tibble(
    metric_type = "cross_wave_change_reliability", wave_or_pair = paste0("W", a, "-W", b),
    scope = "standing_full_effort_complete_three_trial_mean", n = sum(keep),
    trials_per_person = 3L,
    method = "1-(MSE_wave_a/3+MSE_wave_b/3)/weighted Var(change); diagnostic only",
    estimate = change_rel, ci_low = NA_real_, ci_high = NA_real_,
    icc_absolute_a1 = NA_real_, icc_consistency_c1 = NA_real_,
    icc_consistency_ci_low = NA_real_, icc_consistency_ci_high = NA_real_,
    ms_subject = NA_real_, ms_trial = NA_real_, ms_error = error_var,
    trial_systematic_variance_l_min2 = NA_real_,
    sem_l_min = sqrt(error_var), sem_absolute_l_min = NA_real_,
    sem_consistency_l_min = sqrt(error_var),
    repeatability_coefficient_l_min = NA_real_,
    repeatability_coefficient_absolute_l_min = NA_real_,
    repeatability_coefficient_consistency_l_min = NA_real_,
    smallest_detectable_difference_l_min = 1.96 * sqrt(error_var),
    smallest_detectable_difference_consistency_l_min = 1.96 * sqrt(error_var),
    median_within_subject_cv = NA_real_,
    threshold = spec$measurement_gates$individual_change_reliability_hard_no_go_below,
    decision = ifelse(change_rel >= spec$measurement_gates$individual_change_reliability_hard_no_go_below,
                      "PASS_NUMERIC_ONLY", "NO-GO")
  )
}
reliability <- bind_rows(reliability)

# Outcome-blind W1 age/sex/height reference solely for cross-wave drift auditing.
# This is not the primary E0 exposure and is not labelled a healthy reference.
height <- lapply(1:3, function(w) to_num(dat[[paste0("r", w, "mheight")]]))
age <- lapply(1:3, function(w) to_num(dat[[paste0("r", w, "agey")]]))
reference_residual_z <- matrix(NA_real_, nrow(dat), 3)
reference_scale <- list()
for (sex in c(1, 2)) {
  ref <- baseline_measurement_eligible & sex_code == sex &
    is.finite(age[[1]]) & is.finite(height[[1]])
  model_data <- data.frame(
    pef = summaries[[1]]$row_max[ref], age = age[[1]][ref],
    height = height[[1]][ref], wt = weight_biomarker[ref]
  )
  fit <- stats::lm(
    pef ~ splines::ns(age, df = 4) + splines::ns(height, df = 4),
    data = model_data, weights = wt
  )
  predictions <- lapply(1:3, function(wave) {
    suppressWarnings(stats::predict(fit, newdata = data.frame(
      age = age[[wave]], height = height[[wave]]
    )))
  })
  residual_w1 <- summaries[[1]]$row_max - predictions[[1]]
  residual_sd <- sqrt(weighted_var_simple(residual_w1[ref], weight_biomarker[ref]))
  idx <- which(!is.na(sex_code) & sex_code == sex)
  for (wave in 1:3) {
    reference_residual_z[idx, wave] <-
      (summaries[[wave]]$row_max[idx] - predictions[[wave]][idx]) / residual_sd
  }
  reference_scale[[as.character(sex)]] <- residual_sd
}

drift_row <- function(a, b, scope, keep) {
  keep <- keep & is.finite(reference_residual_z[, a]) & is.finite(reference_residual_z[, b]) &
    is.finite(summaries[[a]]$row_max) & is.finite(summaries[[b]]$row_max) &
    is.finite(weight_biomarker) & weight_biomarker > 0
  raw_a <- summaries[[a]]$row_max[keep]
  raw_b <- summaries[[b]]$row_max[keep]
  z_a <- reference_residual_z[keep, a]
  z_b <- reference_residual_z[keep, b]
  wt <- weight_biomarker[keep]
  delta_raw <- weighted_mean_simple(raw_b - raw_a, wt)
  delta_z <- weighted_mean_simple(z_b - z_a, wt)
  status <- if (abs(delta_z) > spec$measurement_gates$cross_wave_unexplained_shift_sd_max ||
                abs(delta_raw) > spec$measurement_gates$cross_wave_unexplained_shift_l_min_max) {
    "NO-GO"
  } else {
    "PASS"
  }
  tibble(
    scope = scope, wave_start = paste0("W", a), wave_end = paste0("W", b),
    n = sum(keep), weighted_mean_start_l_min = weighted_mean_simple(raw_a, wt),
    weighted_mean_end_l_min = weighted_mean_simple(raw_b, wt),
    weighted_delta_l_min = delta_raw,
    unweighted_delta_l_min = mean(raw_b - raw_a),
    weighted_correlation = weighted_cor_simple(raw_a, raw_b, wt),
    weighted_reference_residual_start_sd = weighted_mean_simple(z_a, wt),
    weighted_reference_residual_end_sd = weighted_mean_simple(z_b, wt),
    unexplained_shift_sd = delta_z,
    threshold_l_min = spec$measurement_gates$cross_wave_unexplained_shift_l_min_max,
    threshold_sd = spec$measurement_gates$cross_wave_unexplained_shift_sd_max,
    status = status,
    detail = "W1 sex-specific weighted age/height conditional reference; diagnostic only, not primary E0."
  )
}

cross_wave_drift <- list()
for (pair in list(c(1, 2), c(1, 3), c(2, 3))) {
  a <- pair[[1]]
  b <- pair[[2]]
  cross_wave_drift[[length(cross_wave_drift) + 1L]] <- drift_row(
    a, b, "baseline_eligible_pairwise", baseline_measurement_eligible
  )
  cross_wave_drift[[length(cross_wave_drift) + 1L]] <- drift_row(
    a, b, "standing_full_effort_complete_three_pairwise",
    baseline_measurement_eligible & summaries[[a]]$standing & summaries[[a]]$full_effort &
      summaries[[a]]$complete_three & summaries[[b]]$standing & summaries[[b]]$full_effort &
      summaries[[b]]$complete_three
  )
  cross_wave_drift[[length(cross_wave_drift) + 1L]] <- drift_row(
    a, b, "standing_full_effort_complete_three_common_W1_W2_W3",
    baseline_measurement_eligible & Reduce(`&`, lapply(summaries, function(s) {
      s$standing & s$full_effort & s$complete_three
    }))
  )
}
cross_wave_drift <- bind_rows(cross_wave_drift)

common_three <- baseline_measurement_eligible & Reduce(`&`, lapply(summaries, function(s) {
  s$standing & s$full_effort & s$complete_three
}))
adjacent_change_correlation <- weighted_cor_simple(
  summaries[[2]]$row_max[common_three] - summaries[[1]]$row_max[common_three],
  summaries[[3]]$row_max[common_three] - summaries[[2]]$row_max[common_three],
  weight_biomarker[common_three]
)
cross_wave_drift <- bind_rows(
  cross_wave_drift,
  tibble(
    scope = "standing_full_effort_complete_three_common_W1_W2_W3",
    wave_start = "delta_W1_W2", wave_end = "delta_W2_W3", n = sum(common_three),
    weighted_mean_start_l_min = NA_real_, weighted_mean_end_l_min = NA_real_,
    weighted_delta_l_min = NA_real_, unweighted_delta_l_min = NA_real_,
    weighted_correlation = adjacent_change_correlation,
    weighted_reference_residual_start_sd = NA_real_,
    weighted_reference_residual_end_sd = NA_real_, unexplained_shift_sd = NA_real_,
    threshold_l_min = NA_real_, threshold_sd = NA_real_, status = "DESCRIPTIVE",
    detail = "Adjacent change correlation; a strong negative value is compatible with regression to the mean and/or protocol noise."
  )
)

# Freeze E0 constants in the mortality-eligible P-C upper-bound cohort. A
# baseline-only scale is retained as a descriptive denominator sensitivity.
e0_scale_one <- function(flag, sample_id, scaling_role) {
  bind_rows(lapply(c(1, 2), function(sex) {
    keep <- flag & sex_code == sex & is.finite(summaries[[1]]$row_max) &
      is.finite(weight_biomarker) & weight_biomarker > 0
    x <- summaries[[1]]$row_max[keep]
    wt <- weight_biomarker[keep]
    tibble(
      sample_id = sample_id, sex_code = sex,
      sex = ifelse(sex == 1, "male", "female"), n = sum(keep),
      weighted_mean_l_min = weighted_mean_simple(x, wt),
      weighted_sd_l_min = sqrt(weighted_var_simple(x, wt)),
      unweighted_mean_l_min = mean(x), unweighted_sd_l_min = stats::sd(x),
      outcome_scaling_role = scaling_role,
      direction = "E0=(sex-specific mean - PEF)/sex-specific weighted SD; higher E0 means lower PEF",
      physical_scale = "E0b reports each 100 L/min lower raw PEF",
      boundary_rule = "30 and 890 L/min retained primary as boundary-coded; exclude both in sensitivity"
    )
  }))
}

e0_scale <- bind_rows(
  e0_scale_one(
    primary_mortality_eligible,
    "primary_mortality_eligible",
    "PRIMARY frozen constants; reuse unchanged across CHARLS primary and prespecified quality/boundary sensitivities"
  ),
  e0_scale_one(
    baseline_measurement_eligible,
    "baseline_measurement_eligible_diagnostic",
    "Descriptive diagnostic only; do not rescale outcome models"
  )
)

primary_constants <- e0_scale %>%
  filter(.data$sample_id == "primary_mortality_eligible") %>%
  select("sex_code", mu = "weighted_mean_l_min", sigma = "weighted_sd_l_min")
mu <- primary_constants$mu[match(sex_code, primary_constants$sex_code)]
sigma <- primary_constants$sigma[match(sex_code, primary_constants$sex_code)]
e0 <- (mu - summaries[[1]]$row_max) / sigma

reported_reconciliation <- bind_rows(lapply(1:3, function(wave) {
  reported <- to_num(dat[[paste0("r", wave, "puff")]])
  rowmax <- summaries[[wave]]$row_max
  tibble(
    wave = paste0("W", wave), reported_nonmissing = sum(is.finite(reported)),
    rowmax_nonmissing = sum(is.finite(rowmax)),
    both_nonmissing_mismatch = sum(is.finite(reported) & is.finite(rowmax) & reported != rowmax),
    rowmax_only = sum(is.finite(rowmax) & !is.finite(reported)),
    reported_only = sum(!is.finite(rowmax) & is.finite(reported)),
    decision = "rowmax/maximum of valid trials is primary"
  )
}))

measurement_contract <- bind_rows(
  assertion_row("units", TRUE, "L/min", "L/min", "Raw Harmonized PEF is already in L/min."),
  assertion_row("valid_range", lower_bound == 30 && upper_bound == 890,
                paste0(lower_bound, "-", upper_bound, " inclusive"), "30-890 inclusive",
                "30 and 890 are boundary-coded observations, not exact physiologic values."),
  assertion_row("boundary_sensitivity", TRUE, "retain 30/890 primary; exclude both in sensitivity",
                "prespecified", "No post-outcome boundary deletion."),
  assertion_row("failure_refusal_codes", all(vapply(trials_raw, function(x) sum(x %in% c(993, 999), na.rm = TRUE) == 0L, logical(1))),
                "993 attempted-but-failed and 999 refused absent as literal values",
                "mapped to missing by Harmonized CHARLS"),
  assertion_row("primary_trial_summary", all(reported_reconciliation$both_nonmissing_mismatch == 0),
                "rowmax/maximum of valid trials; W3 rowmax-only rows retained",
                "maximum of valid trials reconciles with reported best"),
  assertion_row("repeatability_rule", repeatability_limit == 40,
                "at least 2 valid trials; top-two difference <=40 L/min", "40 L/min"),
  assertion_row("strict_protocol", TRUE, "standing code 1 and full-effort code 1",
                "standing/full-effort sensitivity"),
  assertion_row("completion_not_true_attempt", TRUE,
                "raw puffcomp/tagged completion audit retained; test-started/completed is a conservative lower bound",
                "do not equate puffcomp nonmissing or puffcomp=0 with attempted testing",
                "Harmonized data do not fully retain attempted-but-unable versus refusal for every skipped record."),
  assertion_row("E0_scale", all(is.finite(e0_scale$weighted_sd_l_min) & e0_scale$weighted_sd_l_min > 0),
                "sex-specific weighted SD; higher E0 means lower PEF; 100 L/min physical scale",
                "outcome-blind primary mortality-eligible constants")
)

flow_identity <- all(cohort_flow$status_known == cohort_flow$status_alive +
                       cohort_flow$status_new_death + cohort_flow$status_carried_death) &&
  all(cohort_flow$core_n == cohort_flow$status_known + cohort_flow$status_unknown)
status_category_sum <- rowSums(cohort_flow[1:4, c(
  "status_code1_interviewed", "status_code4_nonresponse_alive",
  "status_code5_new_death", "status_code6_prior_death", "status_code7",
  "status_code9", "status_code0", "status_tagged_proxy",
  "status_other_tagged_missing", "status_plain_missing", "status_other_numeric"
)], na.rm = TRUE)
status_category_identity <- all(status_category_sum == cohort_flow$core_n[1:4])
cumulative_death <- cohort_flow$status_new_death + cohort_flow$status_carried_death
pef_attempt_identity <- all(cohort_flow$pef_valid[1:3] <= cohort_flow$pef_attempted[1:3])
source_pass <- all(source_reconciliation$pass)
icc_w1_min <- min(reliability$estimate[
  reliability$metric_type == "same_session_reliability" & reliability$wave_or_pair == "W1"
], na.rm = TRUE)
icc_w2_min <- min(reliability$estimate[
  reliability$metric_type == "same_session_reliability" & reliability$wave_or_pair == "W2"
], na.rm = TRUE)
icc_w3_min <- min(reliability$estimate[
  reliability$metric_type == "same_session_reliability" & reliability$wave_or_pair == "W3"
], na.rm = TRUE)
w12_strict <- cross_wave_drift %>%
  filter(.data$scope == "standing_full_effort_complete_three_pairwise",
         .data$wave_start == "W1", .data$wave_end == "W2")
w13_strict <- cross_wave_drift %>%
  filter(.data$scope == "standing_full_effort_complete_three_pairwise",
         .data$wave_start == "W1", .data$wave_end == "W3")
w12_comparable <- nrow(w12_strict) == 1L && w12_strict$status == "PASS"
w13_comparable <- nrow(w13_strict) == 1L && w13_strict$status == "PASS"

machine_assertions <- bind_rows(
  assertion_row("source_reconciliation_all_pass", source_pass,
                paste0(sum(source_reconciliation$pass), "/", nrow(source_reconciliation)), "all PASS"),
  assertion_row("flow_status_identities", flow_identity, flow_identity, TRUE),
  assertion_row("raw_status_categories_exhaustive_W1_W4", status_category_identity,
                paste(status_category_sum, collapse = ","),
                paste(cohort_flow$core_n[1:4], collapse = ","),
                "Separates 1/4/5/6/7/9/0, tagged proxy, other tagged missing, plain missing, and other numeric codes."),
  assertion_row("sequential_primary_flow_reconstructs_upper_bound",
                tail(sequential_flow$n, 1) == sum(primary_mortality_eligible) &&
                  all(sequential_flow$excluded_from_previous[-1] ==
                        head(sequential_flow$n, -1) - tail(sequential_flow$n, -1)),
                paste0(tail(sequential_flow$n, 1), "/", sum(primary_mortality_eligible)),
                "equal final N and exact previous-minus-current exclusions"),
  assertion_row("cumulative_deaths_non_decreasing", all(diff(cumulative_death) >= 0),
                paste(cumulative_death, collapse = ","), "non-decreasing"),
  assertion_row("valid_pef_not_greater_than_attempted", pef_attempt_identity,
                paste0(cohort_flow$pef_valid[1:3], "/", cohort_flow$pef_attempted[1:3], collapse = ";"),
                "valid <= attempted"),
  assertion_row("reported_best_matches_rowmax_when_both_present",
                all(reported_reconciliation$both_nonmissing_mismatch == 0),
                paste(reported_reconciliation$both_nonmissing_mismatch, collapse = ","), "0,0,0"),
  assertion_row("W3_rowmax_only_recovered", reported_reconciliation$rowmax_only[[3]] == 14,
                reported_reconciliation$rowmax_only[[3]], 14,
                "Fourteen W3 records have valid trials but missing reported best; rowmax is retained."),
  assertion_row("code6_without_earlier_code5_zero", sum(code6_without_earlier_5) == 0L,
                sum(code6_without_earlier_5), 0,
                "A first code 6 has indeterminate timing and triggers mapping review/hard stop; current locked data have none."),
  assertion_row("vital_status_sequences_reconstructable",
                sum(alive_after_prior_death) == 0L &&
                  sum(prior_death_w5_alive_conflict) == 0L &&
                  sum(prior_death_w5_death_duplicate) == 0L,
                paste0("alive_after_death=", sum(alive_after_prior_death),
                       "; prior_death_w5_alive=", sum(prior_death_w5_alive_conflict),
                       "; prior_death_w5_died=", sum(prior_death_w5_death_duplicate)),
                "all zero",
                "Required for last-known-alive to next-known-status interval construction."),
  assertion_row("v42_historical_anchor", historical_n == 12569 && historical_deaths == 1681,
                paste0(historical_n, "/", historical_deaths), "12569/1681"),
  assertion_row("primary_scale_has_two_sexes", nrow(primary_constants) == 2 && all(primary_constants$sigma > 0),
                paste0(nrow(primary_constants), " rows"), "2 positive-SD rows")
)

gate_table <- bind_rows(
  gate_row("Gate 1", "flow_core", "direct_source_reconciliation",
           ifelse(source_pass, "PASS", "FAIL"), source_pass, TRUE,
           paste0(sum(source_reconciliation$pass), "/", nrow(source_reconciliation), " PASS"), "all source rows PASS"),
  gate_row("Gate 1", "flow_core", "participant_wave_status_identity",
           ifelse(flow_identity, "PASS", "FAIL"), flow_identity, TRUE,
           flow_identity, TRUE),
  gate_row("Gate 1", "flow_core", "cumulative_death_monotonic",
           ifelse(all(diff(cumulative_death) >= 0), "PASS", "FAIL"),
           all(diff(cumulative_death) >= 0), TRUE,
           paste(cumulative_death, collapse = ","), "non-decreasing"),
  gate_row("Gate 1", "flow_core", "v42_historical_anchor_reconciled",
           ifelse(historical_n == 12569 && historical_deaths == 1681, "PASS", "FAIL"),
           historical_n == 12569 && historical_deaths == 1681, TRUE,
           paste0(historical_n, "/", historical_deaths), "12569/1681",
           "Historical reproduction is a reconciliation anchor, not the v43 cohort definition."),
  gate_row("Gate 1", "flow_core", "machine_assertions",
           ifelse(all(machine_assertions$pass), "PASS", "FAIL"), all(machine_assertions$pass), TRUE,
           paste0(sum(machine_assertions$pass), "/", nrow(machine_assertions), " PASS"), "all PASS"),
  gate_row("Gate 2", "baseline_E0_core", "measurement_contract",
           ifelse(all(measurement_contract$pass), "PASS", "FAIL"),
           all(measurement_contract$pass), TRUE,
           paste0(sum(measurement_contract$pass), "/", nrow(measurement_contract), " PASS"), "all PASS"),
  gate_row("Gate 2", "baseline_E0_core", "W1_same_session_absolute_agreement",
           ifelse(icc_w1_min >= spec$measurement_gates$same_session_icc_limited_below, "PASS", "FAIL"),
           icc_w1_min >= spec$measurement_gates$same_session_icc_limited_below, TRUE,
           sprintf("minimum W1 ICC(A,1)=%.3f", icc_w1_min),
           paste0(">=", spec$measurement_gates$same_session_icc_limited_below)),
  gate_row("Gate 2", "baseline_E0_core", "E0_scale_frozen",
           ifelse(nrow(primary_constants) == 2 && all(primary_constants$sigma > 0), "PASS", "FAIL"),
           nrow(primary_constants) == 2 && all(primary_constants$sigma > 0), TRUE,
           paste0("male/female constants; N=", sum(primary_mortality_eligible)),
           "two sex-specific positive weighted SD constants"),
  gate_row("Gate 2", "repeated_burden_W1_W2", "W2_same_session_absolute_agreement",
           ifelse(icc_w2_min >= spec$measurement_gates$same_session_icc_limited_below, "PASS", "NO-GO"),
           icc_w2_min >= spec$measurement_gates$same_session_icc_limited_below, FALSE,
           sprintf("minimum W2 ICC(A,1)=%.3f", icc_w2_min),
           paste0(">=", spec$measurement_gates$same_session_icc_limited_below),
           "Non-blocking for baseline E0; required for the later W1/W2 repeated-burden module."),
  gate_row("Gate 2", "longitudinal_change_W3", "W3_same_session_absolute_agreement",
           ifelse(icc_w3_min >= spec$measurement_gates$same_session_icc_limited_below, "PASS", "NO-GO"),
           icc_w3_min >= spec$measurement_gates$same_session_icc_limited_below, FALSE,
           sprintf("minimum W3 ICC(A,1)=%.3f", icc_w3_min),
           paste0(">=", spec$measurement_gates$same_session_icc_limited_below),
           "Passing same-session reliability cannot override cross-wave drift."),
  gate_row("Gate 2", "repeated_burden_W1_W2", "W1_W2_protocol_comparability",
           ifelse(w12_comparable, "PASS", "NO-GO"),
           w12_comparable, FALSE,
           ifelse(nrow(w12_strict), sprintf("%.3f SD; %.1f L/min", w12_strict$unexplained_shift_sd, w12_strict$weighted_delta_l_min), "missing"),
           "<=0.20 SD and <=20 L/min",
           "W1/W2 repeated average burden may proceed to its later observation/landmark gates; this does not validate causal decline."),
  gate_row("Gate 2", "longitudinal_change_W3", "W3_person_specific_change_or_slope",
           ifelse(w13_comparable, "PASS", "NO-GO"),
           w13_comparable, FALSE,
           ifelse(nrow(w13_strict), sprintf("%.3f SD; %.1f L/min", w13_strict$unexplained_shift_sd, w13_strict$weighted_delta_l_min), "missing"),
           "must remain <=0.20 SD and <=20 L/min",
           "DISABLED/FORBIDDEN: unexplained Wave 3 upward drift persists after standing, full-effort, complete-three-trial and age/sex/height restriction; do not use person-specific W3 slope/change."
  )
)

# Contract-authorized row-level ledger. It contains measurements and status
# construction only, never fitted values or model coefficients.
ledger <- tibble(
  participant_id = dat$participant_id,
  community_id = to_chr(dat$community_id),
  sex_code = sex_code,
  age_w1 = age[[1]], age_w2 = age[[2]], age_w3 = age[[3]],
  height_m_w1 = height[[1]], height_m_w2 = height[[2]], height_m_w3 = height[[3]],
  weight_biomarker_w1 = weight_biomarker,
  iwstat_w1 = status_cols[[1]], iwstat_w2 = status_cols[[2]],
  iwstat_w3 = status_cols[[3]], iwstat_w4 = status_cols[[4]], died_w5 = dat$died_w5,
  future_status_known = future_status_known,
  first_death_status_wave_w2_w4 = first_death_status_wave,
  first_death_status_code_w2_w4 = first_death_status_code,
  code6_without_earlier_code5 = code6_without_earlier_5,
  baseline_age_weight = baseline_age_weight,
  baseline_measurement_eligible = baseline_measurement_eligible,
  primary_mortality_eligible = primary_mortality_eligible,
  primary_death_event_aggregate_contract = primary_death_event,
  pef_w1_trial1 = trials[[1]][, 1], pef_w1_trial2 = trials[[1]][, 2], pef_w1_trial3 = trials[[1]][, 3],
  pef_w2_trial1 = trials[[2]][, 1], pef_w2_trial2 = trials[[2]][, 2], pef_w2_trial3 = trials[[2]][, 3],
  pef_w3_trial1 = trials[[3]][, 1], pef_w3_trial2 = trials[[3]][, 2], pef_w3_trial3 = trials[[3]][, 3],
  pef_w1_rowmax = summaries[[1]]$row_max, pef_w2_rowmax = summaries[[2]]$row_max,
  pef_w3_rowmax = summaries[[3]]$row_max,
  pef_w1_mean = summaries[[1]]$row_mean, pef_w2_mean = summaries[[2]]$row_mean,
  pef_w3_mean = summaries[[3]]$row_mean,
  pef_w1_median = summaries[[1]]$row_median, pef_w2_median = summaries[[2]]$row_median,
  pef_w3_median = summaries[[3]]$row_median,
  pef_w1_valid_n = summaries[[1]]$valid_n, pef_w2_valid_n = summaries[[2]]$valid_n,
  pef_w3_valid_n = summaries[[3]]$valid_n,
  pef_w1_test_started_or_completed = summaries[[1]]$test_started_or_completed,
  pef_w2_test_started_or_completed = summaries[[2]]$test_started_or_completed,
  pef_w3_test_started_or_completed = summaries[[3]]$test_started_or_completed,
  pef_w1_completion_yes = summaries[[1]]$completion_yes,
  pef_w2_completion_yes = summaries[[2]]$completion_yes,
  pef_w3_completion_yes = summaries[[3]]$completion_yes,
  pef_w1_not_willing_or_able = summaries[[1]]$not_willing_or_able,
  pef_w2_not_willing_or_able = summaries[[2]]$not_willing_or_able,
  pef_w3_not_willing_or_able = summaries[[3]]$not_willing_or_able,
  pef_w1_standing = summaries[[1]]$standing, pef_w2_standing = summaries[[2]]$standing,
  pef_w3_standing = summaries[[3]]$standing,
  pef_w1_full_effort = summaries[[1]]$full_effort, pef_w2_full_effort = summaries[[2]]$full_effort,
  pef_w3_full_effort = summaries[[3]]$full_effort,
  pef_w1_strict_protocol = summaries[[1]]$strict_protocol,
  pef_w2_strict_protocol = summaries[[2]]$strict_protocol,
  pef_w3_strict_protocol = summaries[[3]]$strict_protocol,
  pef_w1_boundary_floor = summaries[[1]]$boundary_floor,
  pef_w1_boundary_ceiling = summaries[[1]]$boundary_ceiling,
  pef_w2_boundary_floor = summaries[[2]]$boundary_floor,
  pef_w2_boundary_ceiling = summaries[[2]]$boundary_ceiling,
  pef_w3_boundary_floor = summaries[[3]]$boundary_floor,
  pef_w3_boundary_ceiling = summaries[[3]]$boundary_ceiling,
  E0_lower_pef_sex_specific_sd = e0,
  E0b_lower_pef_per_100_l_min = (mu - summaries[[1]]$row_max) / 100
)
attr(ledger, "artifact_contract") <- "CHARLS v43 Stage 1-2 machine ledger; no fitted outcome model"
attr(ledger, "generated_at") <- format(Sys.time(), tz = "Asia/Shanghai", usetz = TRUE)
saveRDS(ledger, file.path(ledger_dir, "charls_stage1_ledger_v43.rds"), compress = "xz")

readr::write_csv(cohort_flow, file.path(out_dir, "charls_cohort_flow_v43.csv"))
readr::write_csv(sequential_flow, file.path(out_dir, "charls_sequential_flow_v43.csv"))
readr::write_csv(status_event_anchors, file.path(out_dir, "charls_status_event_anchors_v43.csv"))
readr::write_csv(machine_assertions, file.path(out_dir, "charls_machine_assertions_v43.csv"))
readr::write_csv(gate_table, file.path(out_dir, "charls_gate1_2_v43.csv"))
readr::write_csv(measurement_contract, file.path(out_dir, "charls_measurement_contract_v43.csv"))
readr::write_csv(trial_qc, file.path(out_dir, "charls_pef_trial_qc_v43.csv"))
readr::write_csv(reliability, file.path(out_dir, "charls_pef_reliability_v43.csv"))
readr::write_csv(cross_wave_drift, file.path(out_dir, "charls_cross_wave_drift_v43.csv"))
readr::write_csv(source_reconciliation, file.path(out_dir, "charls_core_source_reconciliation_v43.csv"))
readr::write_csv(e0_scale, file.path(out_dir, "charls_e0_scale_v43.csv"))
readr::write_csv(reported_reconciliation, file.path(out_dir, "charls_reported_rowmax_reconciliation_v43.csv"))
readr::write_csv(completion_status_audit, file.path(out_dir, "charls_pef_completion_status_v43.csv"))

blocking_gate2 <- gate_table$gate == "Gate 2" & gate_table$blocks_baseline_e0
gate1_status <- if (all(gate_table$pass[gate_table$gate == "Gate 1"])) "PASS" else "FAIL"
gate2_status <- if (all(gate_table$pass[blocking_gate2])) "PASS" else "FAIL"

log_lines <- c(
  "# CHARLS v43 Stage 1-2 flow and measurement audit",
  "",
  paste0("Completed: ", format(Sys.time(), tz = "Asia/Shanghai", usetz = TRUE)),
  "",
  "## Scope",
  "",
  "- Reconciled selected raw fields directly against `H_CHARLS_D_Data.dta` and linked Wave 5 `Sample_Infor.dta`.",
  "- Rebuilt W1-W5 status and W1-W3 PEF attempt/valid ledgers.",
  "- Used a closed-form two-way absolute-agreement single-measure ICC(A,1); no `psych`, `lmer`, or outcome model was used.",
  "- Aggregate outputs only, except the contract-authorized sensitive machine ledger.",
  paste0("- Gate 1: **", gate1_status, "**."),
  paste0("- Gate 2 core baseline E0: **", gate2_status, "**."),
  "- W3 person-specific change/slope: **NO-GO (non-blocking for baseline E0)**.",
  "- Outcome models fitted: 0.",
  "",
  "## Cohort flow",
  "",
  markdown_table(cohort_flow),
  "",
  "## Sequential primary baseline flow",
  "",
  markdown_table(sequential_flow),
  "",
  "## Sample/event anchors",
  "",
  markdown_table(status_event_anchors),
  "",
  "## Reported-best versus rowmax reconciliation",
  "",
  markdown_table(reported_reconciliation),
  "",
  "## Raw PEF completion/test-status audit",
  "",
  markdown_table(completion_status_audit),
  "",
  "## Same-session reliability",
  "",
  markdown_table(reliability %>% mutate(across(where(is.numeric), ~round(.x, 5)))),
  "",
  "## Cross-wave drift",
  "",
  markdown_table(cross_wave_drift %>% mutate(across(where(is.numeric), ~round(.x, 5)))),
  "",
  "## Frozen E0 scale",
  "",
  markdown_table(e0_scale %>% mutate(across(where(is.numeric), ~round(.x, 5)))),
  "",
  "## Gate decisions",
  "",
  markdown_table(gate_table),
  "",
  "## Interpretation boundary",
  "",
  "Same-session ICC(A,1) supports use of the Wave 1 row maximum as a baseline measurement, but the approximately 100+ L/min smallest detectable difference shows substantial individual measurement noise.",
  "",
  "W1-W2 remains usable for repeated average low-PEF burden after later landmark/observation gates. W3 has a persistent upward standardized shift after protocol and composition restriction, so person-specific W3 change, slope, or trajectory classes are disabled rather than rescued with an alternative model.",
  "",
  "`puffcomp` is willingness/ability/completion status, not a complete attempt indicator. The flow therefore reports a conservative documented test-started/completed lower bound and a separate raw tagged-status audit; true attempts cannot be fully reconstructed from the Harmonized source.",
  "",
  "Values 30 and 890 L/min remain boundary-coded in the primary exposure and are removed only in a prespecified sensitivity. Original codes 993 and 999 are missing in the Harmonized source and are never treated as physiologic PEF."
)
writeLines(log_lines, file.path(log_dir, "01_charls_stage1_2_audit_v43.md"), useBytes = TRUE)

if (gate1_status != "PASS" || gate2_status != "PASS") {
  stop(
    "CHARLS Stage 1-2 audit failed: Gate 1=", gate1_status,
    ", blocking Gate 2=", gate2_status,
    ". Inspect aggregate outputs before any outcome model.",
    call. = FALSE
  )
}

message(
  "CHARLS Stage 1-2 core gates PASS; W3 person-specific change/slope NO-GO. ",
  "Outcome models fitted: 0."
)
