# v43 Stage 3 preflight: build samples, imputation specifications, survey
# designs, and model matrices without fitting any mortality outcome model.
#
# This script is valid only after a preliminary freeze and independent
# Stage 0-2 validation. It emits exactly one row for every member of a fixed
# BOTH/CHARLS/NHANES check contract, plus immutable script/key-input hashes.
# The later final-authorization freeze must reproduce that input snapshot.

options(stringsAsFactors = FALSE)

project_root <- function() {
  args <- commandArgs(trailingOnly = FALSE)
  file_arg <- grep("^--file=", args, value = TRUE)
  if (length(file_arg)) {
    script <- sub("^--file=", "", file_arg[[1]])
    return(normalizePath(file.path(dirname(script), "..", ".."), mustWork = TRUE))
  }
  normalizePath(getwd(), mustWork = TRUE)
}

sha256_file <- function(path) {
  if (!file.exists(path) || dir.exists(path)) return(NA_character_)
  digest::digest(file = path, algo = "sha256", serialize = FALSE)
}

one_line <- function(x) {
  if (!length(x) || all(is.na(x))) return("")
  gsub("[\r\n]+", " ", paste(x[!is.na(x)], collapse = "; "))
}

as_flag <- function(x) {
  if (is.logical(x)) return(x)
  y <- toupper(trimws(as.character(x)))
  out <- rep(NA, length(y))
  out[y %in% c("TRUE", "T", "1", "YES", "PASS")] <- TRUE
  out[y %in% c("FALSE", "F", "0", "NO", "FAIL")] <- FALSE
  out
}

expected_preflight_checks <- function() {
  tibble::tribble(
    ~cohort, ~check,
    "BOTH", "preflight_packages_available",
    "BOTH", "gate0_2_pass_before_preflight",
    "BOTH", "outcome_execution_disabled_during_preflight",
    "BOTH", "independent_stage0_2_validator_pass",
    "BOTH", "preliminary_manifest_current_and_complete",
    "BOTH", "governance_preflight_completed",
    "CHARLS", "structural_sample_time_support_rebuilt",
    "CHARLS", "mi_targets_have_predictors",
    "CHARLS", "mi_specification_hash_recorded",
    "CHARLS", "mi_expanded_dimension_below_rows",
    "CHARLS", "two_by_two_mice_dry_run",
    "CHARLS", "A0_A2_model_matrices_full_rank",
    "CHARLS", "survey_design_df_exceeds_model_dimension",
    "CHARLS", "spline_knots_finite",
    "CHARLS", "charls_preflight_completed",
    "NHANES", "primary_sample_and_events_rebuilt",
    "NHANES", "full_design_backbone_rebuilt",
    "NHANES", "mi_targets_have_predictors",
    "NHANES", "mi_specification_hash_recorded",
    "NHANES", "mi_expanded_dimension_below_rows",
    "NHANES", "stratum_plus_raw_psu_reconstructs_design_psu",
    "NHANES", "two_by_two_mice_dry_run",
    "NHANES", "full_design_before_domain_preserved",
    "NHANES", "A0_A2_model_matrices_full_rank",
    "NHANES", "survey_design_df_exceeds_model_dimension",
    "NHANES", "start_stop_window_matrix_full_rank",
    "NHANES", "nhanes_preflight_completed"
  )
}

check_contract_sha256 <- function() {
  contract <- dplyr::arrange(expected_preflight_checks(), cohort, check)
  contract <- dplyr::transmute(contract, line = paste(cohort, check, sep = "|"))
  digest::digest(paste(contract$line, collapse = "\n"), algo = "sha256", serialize = FALSE)
}

new_check_store <- function() {
  store <- new.env(parent = emptyenv())
  contract <- expected_preflight_checks()
  store$rows <- contract
  store$rows$status <- "FAIL"
  store$rows$hard_gate <- TRUE
  store$rows$expected_check <- TRUE
  store$rows$observed <- "NOT_RUN"
  store$rows$expected <- "fixed preflight check must run and pass"
  store$snapshot <- NULL
  store
}

add_check <- function(store, cohort, check, pass, observed, expected, hard_gate = TRUE) {
  key <- store$rows$cohort == cohort & store$rows$check == check
  if (sum(key) != 1L) {
    stop(
      "Attempted to write an undeclared or non-unique preflight check: ",
      cohort, "/", check,
      call. = FALSE
    )
  }
  store$rows$status[key] <- if (isTRUE(pass)) "PASS" else "FAIL"
  store$rows$hard_gate[key] <- isTRUE(hard_gate)
  store$rows$observed[key] <- one_line(observed)
  store$rows$expected[key] <- one_line(expected)
  invisible(pass)
}

inventory_sha256 <- function(manifest, exclude_roles = "gate_state") {
  required <- c("group", "role", "path", "restricted", "exists", "bytes", "sha256")
  if (!all(required %in% names(manifest))) return(NA_character_)
  stable <- dplyr::filter(manifest, !role %in% exclude_roles)
  stable <- dplyr::transmute(
    stable,
    group = as.character(group),
    role = as.character(role),
    path = normalizePath(as.character(path), mustWork = FALSE),
    restricted = toupper(as.character(as_flag(restricted))),
    exists = toupper(as.character(as_flag(exists))),
    bytes = format(as.numeric(bytes), scientific = FALSE, trim = TRUE),
    sha256 = tolower(as.character(sha256))
  )
  stable <- dplyr::arrange(stable, group, role, path)
  tmp <- tempfile("stage3_stable_inventory_", fileext = ".csv")
  on.exit(unlink(tmp), add = TRUE)
  readr::write_csv(stable, tmp)
  sha256_file(tmp)
}

fill_for_matrix_dimension <- function(dat) {
  out <- dat
  for (name in names(out)) {
    x <- out[[name]]
    if (is.factor(x)) {
      if (!nlevels(x)) next
      x[is.na(x)] <- levels(x)[[1]]
    } else if (is.character(x)) {
      observed <- x[!is.na(x) & nzchar(x)]
      x[is.na(x) | !nzchar(x)] <- if (length(observed)) observed[[1]] else "missing"
      x <- factor(x)
    } else {
      x <- suppressWarnings(as.numeric(x))
      replacement <- if (any(is.finite(x))) stats::median(x[is.finite(x)]) else 0
      x[!is.finite(x)] <- replacement
    }
    out[[name]] <- x
  }
  out
}

expanded_predictor_columns <- function(mi_data, mi_spec) {
  targets <- names(mi_spec$method)[nzchar(mi_spec$method)]
  if (!length(targets)) return(data.frame(target = character(), expanded_columns = integer()))
  rows <- lapply(targets, function(target) {
    predictors <- names(which(mi_spec$predictor_matrix[target, ] != 0))
    if (!length(predictors)) {
      return(data.frame(
        target = target,
        observed_target_rows = sum(!is.na(mi_data[[target]])),
        expanded_columns = 0L,
        predictor_variables = 0L,
        matrix_rank = 0L,
        full_rank = FALSE,
        unused_factor_levels = "",
        normalized_crossprod_rcond = NA_real_,
        stringsAsFactors = FALSE
      ))
    }
    observed_target <- !is.na(mi_data[[target]])
    design_data <- fill_for_matrix_dimension(
      mi_data[observed_target, predictors, drop = FALSE]
    )
    unused_levels <- unlist(lapply(predictors, function(name) {
      x <- mi_data[[name]][observed_target]
      if (!is.factor(x)) return(character())
      absent <- setdiff(levels(x), unique(as.character(x[!is.na(x)])))
      if (!length(absent)) character() else paste0(name, "=", absent)
    }), use.names = FALSE)
    mm <- stats::model.matrix(~ ., data = design_data)
    qr_mm <- qr(mm)
    column_norm <- sqrt(colSums(mm^2))
    nonzero_columns <- is.finite(column_norm) & column_norm > 0
    normalized_rcond <- if (
      all(nonzero_columns) && qr_mm$rank == ncol(mm)
    ) {
      normalized <- sweep(mm, 2L, column_norm, "/")
      rcond(crossprod(normalized))
    } else {
      0
    }
    data.frame(
      target = target,
      observed_target_rows = sum(observed_target),
      expanded_columns = ncol(mm),
      predictor_variables = length(predictors),
      matrix_rank = qr_mm$rank,
      full_rank = qr_mm$rank == ncol(mm),
      unused_factor_levels = paste(unused_levels, collapse = ";"),
      normalized_crossprod_rcond = normalized_rcond,
      stringsAsFactors = FALSE
    )
  })
  dplyr::bind_rows(rows)
}

capture_mice_dry_run <- function(run_fun, mi_data, mi_spec) {
  warnings <- character()
  started <- proc.time()[["elapsed"]]
  imp <- tryCatch(
    withCallingHandlers(
      run_fun(mi_data, mi_spec, m = 2L, maxit = 2L),
      warning = function(w) {
        warnings <<- c(warnings, conditionMessage(w))
        invokeRestart("muffleWarning")
      }
    ),
    error = function(e) e
  )
  elapsed <- proc.time()[["elapsed"]] - started
  if (inherits(imp, "error")) {
    return(list(
      ok = FALSE,
      error = conditionMessage(imp),
      warnings = unique(warnings),
      elapsed = elapsed,
      imp = NULL
    ))
  }
  list(
    ok = TRUE,
    error = "",
    warnings = unique(warnings),
    elapsed = elapsed,
    imp = imp
  )
}

validate_monitored_category_trace <- function(env, imp, mi_data, mi_spec) {
  tryCatch(
    {
      trace <- env$mice_category_trace(imp, mi_data, mi_spec)
      targets <- mi_spec$unordered_multicategory_targets
      expected_rows <- sum(vapply(targets, function(variable) {
        nlevels(mi_data[[variable]]) * imp$iteration * imp$m
      }, numeric(1)))
      list(
        pass = imp$iteration == 2L &&
          imp$m == 2L &&
          nrow(trace) == expected_rows,
        detail = paste0(
          "iteration=", imp$iteration,
          "; chains=", imp$m,
          "; unordered_targets=", length(targets),
          "; category_trace_rows=", nrow(trace), "/", expected_rows
        )
      )
    },
    error = function(e) list(
      pass = FALSE,
      detail = paste0("category_trace_error=", conditionMessage(e))
    )
  )
}

validate_nhanes_passive_bmi_dry_run <- function(
    env, imp, mi_data, mi_spec) {
  tryCatch(
    {
      audit <- env$validate_nhanes_passive_bmi_state(
        imp,
        mi_data,
        mi_spec
      )
      contract <- mi_spec$nhanes_passive_bmi
      bmi_predictors <- names(which(
        mi_spec$predictor_matrix["bmi", ] != 0
      ))
      bmi_as_predictor_targets <- names(which(
        mi_spec$predictor_matrix[, "bmi"] != 0
      ))
      weight_predictor_targets <- names(which(
        mi_spec$predictor_matrix[, "weight_kg"] != 0
      ))
      graph_fields <- names(contract$anthropometric_update_graph)
      observed_graph <- stats::setNames(
        lapply(graph_fields, function(target) {
          intersect(
            graph_fields,
            names(which(
              mi_spec$predictor_matrix[target, ] != 0
            ))
          )
        }),
        graph_fields
      )
      graph_ok <-
        identical(
          names(observed_graph),
          names(contract$anthropometric_update_graph)
        ) &&
        all(vapply(graph_fields, function(target) {
          setequal(
            observed_graph[[target]],
            contract$anthropometric_update_graph[[target]]
          )
        }, logical(1)))
      pass <-
        identical(mi_spec$method[["height_cm"]], "pmm") &&
        identical(mi_spec$method[["weight_kg"]], "pmm") &&
        identical(
          mi_spec$method[["bmi"]],
          contract$bmi_method
        ) &&
        identical(mi_spec$method[["waist_cm"]], "pmm") &&
        identical(
          head(
            mi_spec$visit_sequence,
            length(contract$visit_sequence_prefix)
          ),
          contract$visit_sequence_prefix
        ) &&
        setequal(
          bmi_predictors,
          contract$bmi_parent_predictors_only
        ) &&
        all(
          contract$anthropometric_equations_exclude_bmi %in%
            setdiff(names(mi_spec$method), bmi_as_predictor_targets)
        ) &&
        setequal(
          weight_predictor_targets,
          contract$weight_predictor_target_whitelist
        ) &&
        graph_ok &&
        all(as.character(mi_data$cycle_label) %in% c("E", "F", "G")) &&
        all(
          unname(imp$where[, "bmi"]) ==
            unname(is.na(mi_data$bmi))
        ) &&
        nrow(imp$imp$bmi) == sum(is.na(mi_data$bmi)) &&
        ncol(imp$imp$bmi) == imp$m &&
        audit$observed_bmi_change_n == 0L &&
        audit$observed_bmi_exact_reconstruction_n ==
          audit$observed_bmi_n &&
        audit$observed_bmi_n ==
          contract$primary_observed_bmi_exact_reconstruction_n &&
        audit$maximum_identity_difference <= 1e-12 &&
        audit$invalid_completed_parent_n == 0L &&
        isTRUE(audit$visit_sequence_preserved)
      list(
        pass = isTRUE(pass),
        detail = paste0(
          "method=", mi_spec$method[["height_cm"]], "/",
          mi_spec$method[["weight_kg"]], "/",
          mi_spec$method[["bmi"]], "/",
          mi_spec$method[["waist_cm"]],
          "; visit_prefix=",
          paste(
            head(
              mi_spec$visit_sequence,
              length(contract$visit_sequence_prefix)
            ),
            collapse = "->"
          ),
          "; BMI_parents=", paste(bmi_predictors, collapse = "|"),
          "; BMI_predictor_targets=",
          if (length(bmi_as_predictor_targets)) {
            paste(bmi_as_predictor_targets, collapse = "|")
          } else {
            "none"
          },
          "; weight_predictor_targets=",
          paste(weight_predictor_targets, collapse = "|"),
          "; anthropometric_graph=",
          paste(vapply(graph_fields, function(target) {
            paste0(
              target, "<-",
              if (length(observed_graph[[target]])) {
                paste(observed_graph[[target]], collapse = "+")
              } else {
                "nonanthropometric_only"
              }
            )
          }, character(1)), collapse = "|"),
          "; BMI_missing=", audit$bmi_missing_n,
          "; BMI_missing_E/F/G=",
          paste(
            unlist(audit$bmi_missing_by_cycle),
            collapse = "/"
          ),
          "; observed_BMI_exact_reconstructions=",
          audit$observed_bmi_exact_reconstruction_n,
          "/", audit$observed_bmi_n,
          "; observed_BMI_changes=", audit$observed_bmi_change_n,
          "; maximum_identity_difference=",
          audit$maximum_identity_difference,
          "; invalid_completed_parent_cells=",
          audit$invalid_completed_parent_n,
          "; chains_checked=", audit$chains_checked
        )
      )
    },
    error = function(e) list(
      pass = FALSE,
      detail = paste0(
        "passive_BMI_error=",
        conditionMessage(e)
      )
    )
  )
}

same_seed_mice_reproducibility <- function(first, second) {
  components <- c(
    imp = identical(first$imp, second$imp),
    chainMean = identical(first$chainMean, second$chainMean),
    chainVar = identical(first$chainVar, second$chainVar),
    lastSeedValue = identical(
      first$lastSeedValue,
      second$lastSeedValue
    ),
    category_trace = identical(
      attr(first, "category_trace", exact = TRUE),
      attr(second, "category_trace", exact = TRUE)
    )
  )
  list(
    pass = all(components),
    detail = paste(names(components), components, sep = "=", collapse = "; ")
  )
}

validate_monitored_smoking_coherence <- function(env, imp) {
  tryCatch(
    {
      trace <- env$mice_smoking_coherence_trace(imp)
      list(
        pass = nrow(trace) == imp$iteration &&
          all(trace$chains_checked == imp$m) &&
          all(trace$unresolved_n_across_completed_chains == 0L) &&
          all(
            trace$parent_zero_child_one_n_across_completed_chains == 0L
          ),
        detail = paste0(
          "smoking_coherence_iterations=", nrow(trace), "/",
          imp$iteration,
          "; chains_per_iteration=",
          paste(unique(trace$chains_checked), collapse = "|"),
          "; unresolved=",
          sum(trace$unresolved_n_across_completed_chains),
          "; parent0_current1=",
          sum(
            trace$parent_zero_child_one_n_across_completed_chains
          )
        )
      )
    },
    error = function(e) list(
      pass = FALSE,
      detail = paste0(
        "smoking_coherence_error=",
        conditionMessage(e)
      )
    )
  )
}

charls_smoking_applicable_predictor_audit <- function(mi_data, mi_spec) {
  parent <- "smoke_ever_w1"
  child <- "smoke_now_w1"
  routing <- attr(
    mi_data,
    "charls_smoking_routing_audit",
    exact = TRUE
  )
  parent_value <- suppressWarnings(as.numeric(as.character(mi_data[[parent]])))
  child_value <- suppressWarnings(as.numeric(as.character(mi_data[[child]])))
  predictors <- names(which(mi_spec$predictor_matrix[child, ] != 0))
  conditional_predictors <- setdiff(predictors, parent)
  applicable_observed <- parent_value %in% 1 & !is.na(child_value)
  design_data <- fill_for_matrix_dimension(
    mi_data[
      applicable_observed,
      conditional_predictors,
      drop = FALSE
    ]
  )
  unused_levels <- unlist(lapply(conditional_predictors, function(name) {
    x <- mi_data[[name]][applicable_observed]
    if (!is.factor(x)) return(character())
    absent <- setdiff(levels(x), unique(as.character(x[!is.na(x)])))
    if (!length(absent)) character() else paste0(name, "=", absent)
  }), use.names = FALSE)
  mm <- stats::model.matrix(~ ., data = design_data)
  qr_mm <- qr(mm)
  column_norm <- sqrt(colSums(mm^2))
  nonzero_columns <- is.finite(column_norm) & column_norm > 0
  normalized_rcond <- if (
    length(nonzero_columns) &&
      all(nonzero_columns) &&
      qr_mm$rank == ncol(mm)
  ) {
    normalized <- sweep(mm, 2L, column_norm, "/")
    rcond(crossprod(normalized))
  } else {
    0
  }
  expected_prefix <- c(parent, child)
  pass <- !is.null(routing) &&
    nrow(routing) == 1L &&
    routing$output_parent_zero_child_one_n == 0L &&
    identical(
      mi_spec$method[[parent]],
      "logreg"
    ) &&
    identical(
      mi_spec$method[[child]],
      "charls_smoke_now_skip_logreg_v43"
    ) &&
    mi_spec$predictor_matrix[parent, child] == 0 &&
    mi_spec$predictor_matrix[child, parent] == 1 &&
    identical(
      head(mi_spec$visit_sequence, 2L),
      expected_prefix
    ) &&
    length(conditional_predictors) > 0L &&
    nrow(mm) > ncol(mm) &&
    qr_mm$rank == ncol(mm) &&
    !length(unused_levels) &&
    is.finite(normalized_rcond) &&
    normalized_rcond > 0 &&
    setequal(sort(unique(child_value[applicable_observed])), 0:1)
  list(
    pass = isTRUE(pass),
    detail = paste0(
      "method=", mi_spec$method[[parent]], "->",
      mi_spec$method[[child]],
      "; visit_prefix=",
      paste(head(mi_spec$visit_sequence, 2L), collapse = "->"),
      "; parent_uses_child=",
      mi_spec$predictor_matrix[parent, child],
      "; child_routes_on_parent=",
      mi_spec$predictor_matrix[child, parent],
      "; input_conflicts_normalized=",
      if (is.null(routing)) "NA" else
        routing$input_parent_zero_child_one_n,
      "; output_conflicts=",
      if (is.null(routing)) "NA" else
        routing$output_parent_zero_child_one_n,
      "; applicable_observed_rows=", nrow(mm),
      "; conditional_columns=", ncol(mm),
      "; conditional_rank=", qr_mm$rank,
      "; unused_levels=",
      if (length(unused_levels)) {
        paste(unused_levels, collapse = "|")
      } else {
        "none"
      },
      "; conditional_normalized_rcond=",
      signif(normalized_rcond, 4)
    )
  )
}

mi_specification_contract <- function(
    mi_spec, analysis_spec, cohort = c("CHARLS", "NHANES")) {
  cohort <- match.arg(cohort)
  rules <- analysis_spec$missingness$mi
  checkpoints <- as.integer(unlist(rules$convergence_iteration_checkpoints))
  expected_checkpoints <- c(20L, 40L, 80L)
  smoking_contract_ok <- TRUE
  nhanes_passive_bmi_contract_ok <- TRUE
  if (identical(cohort, "CHARLS")) {
    smoking_rules <- rules$charls_smoking_skip_pattern
    smoking_contract_ok <-
      !is.null(smoking_rules) &&
      identical(
        as.character(smoking_rules$parent),
        as.character(mi_spec$charls_smoking_skip_pattern$parent)
      ) &&
      identical(
        as.character(smoking_rules$child),
        as.character(mi_spec$charls_smoking_skip_pattern$child)
      ) &&
      identical(
        as.character(smoking_rules$observed_conflict_rule),
        as.character(
          mi_spec$charls_smoking_skip_pattern$observed_conflict_rule
        )
      ) &&
      identical(
        isTRUE(smoking_rules$parent_equation_excludes_child),
        isTRUE(
          mi_spec$charls_smoking_skip_pattern$
            parent_equation_excludes_child
        )
      ) &&
      identical(
        as.integer(smoking_rules$child_model_applicable_parent_value),
        as.integer(
          mi_spec$charls_smoking_skip_pattern$
            child_model_applicable_parent_value
        )
      ) &&
      identical(
        as.integer(smoking_rules$child_structural_value_when_parent_zero),
        as.integer(
          mi_spec$charls_smoking_skip_pattern$
            child_structural_value_when_parent_zero
        )
      ) &&
      identical(
        as.character(unlist(smoking_rules$visit_sequence_prefix)),
        as.character(
          mi_spec$charls_smoking_skip_pattern$visit_sequence_prefix
        )
      ) &&
      identical(
        as.character(smoking_rules$per_iteration_completed_pair_gate),
        as.character(
          mi_spec$charls_smoking_skip_pattern$
            per_iteration_completed_pair_gate
        )
      ) &&
      identical(
        head(
          as.character(mi_spec$visit_sequence),
          length(
            mi_spec$charls_smoking_skip_pattern$visit_sequence_prefix
          )
        ),
        as.character(
          mi_spec$charls_smoking_skip_pattern$visit_sequence_prefix
        )
      )
  }
  if (identical(cohort, "NHANES")) {
    bmi_rules <- rules$nhanes_passive_bmi
    bmi_contract <- mi_spec$nhanes_passive_bmi
    bmi_predictors <- names(which(
      mi_spec$predictor_matrix["bmi", ] != 0
    ))
    bmi_as_predictor_targets <- names(which(
      mi_spec$predictor_matrix[, "bmi"] != 0
    ))
    weight_predictor_targets <- names(which(
      mi_spec$predictor_matrix[, "weight_kg"] != 0
    ))
    graph_fields <- names(bmi_contract$anthropometric_update_graph)
    observed_graph <- stats::setNames(
      lapply(graph_fields, function(target) {
        intersect(
          graph_fields,
          names(which(
            mi_spec$predictor_matrix[target, ] != 0
          ))
        )
      }),
      graph_fields
    )
    rules_graph <- stats::setNames(
      lapply(graph_fields, function(target) {
        as.character(unlist(
          bmi_rules$anthropometric_update_graph[[target]]
        ))
      }),
      graph_fields
    )
    contract_graph <- stats::setNames(
      lapply(graph_fields, function(target) {
        as.character(
          bmi_contract$anthropometric_update_graph[[target]]
        )
      }),
      graph_fields
    )
    graph_ok <-
      identical(
        names(bmi_rules$anthropometric_update_graph),
        graph_fields
      ) &&
      all(vapply(graph_fields, function(target) {
        setequal(rules_graph[[target]], contract_graph[[target]]) &&
          setequal(observed_graph[[target]], contract_graph[[target]])
      }, logical(1)))
    nhanes_passive_bmi_contract_ok <-
      !is.null(bmi_rules) &&
      !is.null(bmi_contract) &&
      identical(
        as.character(bmi_rules$bmi_method),
        as.character(bmi_contract$bmi_method)
      ) &&
      identical(
        as.character(unlist(bmi_rules$bmi_formula_fields)),
        as.character(bmi_contract$bmi_formula_fields)
      ) &&
      identical(
        as.integer(unlist(bmi_rules$bmi_cycle_precision)),
        as.integer(bmi_contract$bmi_cycle_precision)
      ) &&
      identical(
        names(unlist(bmi_rules$bmi_cycle_precision)),
        names(bmi_contract$bmi_cycle_precision)
      ) &&
      identical(
        as.character(bmi_rules$bmi_rounding_rule),
        as.character(bmi_contract$bmi_rounding_rule)
      ) &&
      identical(
        as.integer(
          bmi_rules$primary_observed_bmi_exact_reconstruction_n
        ),
        as.integer(
          bmi_contract$primary_observed_bmi_exact_reconstruction_n
        )
      ) &&
      identical(
        as.character(bmi_rules$parent_methods$height_cm),
        as.character(bmi_contract$parent_methods[["height_cm"]])
      ) &&
      identical(
        as.character(bmi_rules$parent_methods$weight_kg),
        as.character(bmi_contract$parent_methods[["weight_kg"]])
      ) &&
      identical(
        as.character(bmi_rules$waist_method),
        as.character(bmi_contract$waist_method)
      ) &&
      identical(
        as.character(unlist(bmi_rules$visit_sequence_prefix)),
        as.character(bmi_contract$visit_sequence_prefix)
      ) &&
      identical(
        head(
          as.character(mi_spec$visit_sequence),
          length(bmi_contract$visit_sequence_prefix)
        ),
        as.character(bmi_contract$visit_sequence_prefix)
      ) &&
      identical(
        as.character(unlist(bmi_rules$bmi_parent_predictors_only)),
        as.character(bmi_contract$bmi_parent_predictors_only)
      ) &&
      setequal(
        bmi_predictors,
        bmi_contract$bmi_parent_predictors_only
      ) &&
      identical(
        as.character(
          unlist(bmi_rules$anthropometric_equations_exclude_bmi)
        ),
        as.character(
          bmi_contract$anthropometric_equations_exclude_bmi
        )
      ) &&
      all(
        bmi_contract$anthropometric_equations_exclude_bmi %in%
          setdiff(names(mi_spec$method), bmi_as_predictor_targets)
      ) &&
      identical(
        as.character(
          unlist(bmi_rules$weight_predictor_target_whitelist)
        ),
        as.character(bmi_contract$weight_predictor_target_whitelist)
      ) &&
      setequal(
        weight_predictor_targets,
        bmi_contract$weight_predictor_target_whitelist
      ) &&
      graph_ok &&
      identical(
        isTRUE(bmi_rules$observed_bmi_preserved),
        isTRUE(bmi_contract$observed_bmi_preserved)
      ) &&
      identical(
        isTRUE(bmi_rules$weight_outcome_covariate),
        isTRUE(bmi_contract$weight_outcome_covariate)
      ) &&
      identical(
        as.integer(bmi_rules$same_seed_dry_run_replicates),
        as.integer(bmi_contract$same_seed_dry_run_replicates)
      ) &&
      identical(
        as.integer(bmi_contract$same_seed_dry_run_replicates),
        2L
      ) &&
      is.logical(mi_spec$where[, "bmi"]) &&
      !anyNA(mi_spec$where[, "bmi"]) &&
      any(mi_spec$where[, "bmi"]) &&
      any(!mi_spec$where[, "bmi"])
  }
  contract_ok <- identical(checkpoints, expected_checkpoints) &&
    identical(
      as.integer(mi_spec$seed),
      as.integer(analysis_spec$seeds$missing_data_mi)
    ) &&
    identical(
      as.integer(mi_spec$convergence_iteration_checkpoints),
      expected_checkpoints
    ) &&
    identical(as.integer(mi_spec$maxit), checkpoints[[1]]) &&
    identical(as.integer(mi_spec$maximum_maxit), tail(checkpoints, 1L)) &&
    identical(
      as.integer(mi_spec$initial_m),
      as.integer(rules$minimum_imputations)
    ) &&
    identical(
      as.integer(mi_spec$maximum_m),
      as.integer(rules$maximum_imputations)
    ) &&
    isTRUE(all.equal(
      as.numeric(mi_spec$monte_carlo_error_fraction_max),
      as.numeric(rules$monte_carlo_error_fraction_of_se_max)
    )) &&
    isTRUE(all.equal(
      as.numeric(mi_spec$convergence_rhat_max),
      as.numeric(rules$improved_rhat_hard_gate_max)
    )) &&
    identical(
      as.integer(mi_spec$trace_release_missing_n_min),
      as.integer(rules$trace_release_missing_n_min)
    ) &&
    smoking_contract_ok &&
    nhanes_passive_bmi_contract_ok
  signature <- list(
    cohort = cohort,
    method = mi_spec$method,
    predictor_matrix = mi_spec$predictor_matrix,
    visit_sequence = mi_spec$visit_sequence,
    charls_smoking_skip_pattern = if (identical(cohort, "CHARLS")) {
      mi_spec$charls_smoking_skip_pattern
    } else {
      NULL
    },
    nhanes_passive_bmi = if (identical(cohort, "NHANES")) {
      mi_spec$nhanes_passive_bmi
    } else {
      NULL
    },
    nhanes_bmi_where_sha256 = if (identical(cohort, "NHANES")) {
      digest::digest(
        unname(mi_spec$where[, "bmi"]),
        algo = "sha256",
        serialize = TRUE
      )
    } else {
      NULL
    },
    unordered_multicategory_targets =
      sort(mi_spec$unordered_multicategory_targets),
    seed = mi_spec$seed,
    convergence_iteration_checkpoints =
      as.integer(mi_spec$convergence_iteration_checkpoints),
    initial_m = mi_spec$initial_m,
    maximum_m = mi_spec$maximum_m,
    monte_carlo_error_fraction_max =
      mi_spec$monte_carlo_error_fraction_max,
    convergence_rhat_max = mi_spec$convergence_rhat_max,
    trace_release_missing_n_min =
      mi_spec$trace_release_missing_n_min,
    monitored_iteration_algorithm =
      "mice(maxit=1) then same-chain mice.mids(maxit=1) per iteration",
    convergence_algorithm_version = if (identical(cohort, "CHARLS")) {
      "rank_normalized_split_plus_folded_split_per_level_v3_skip_pattern"
    } else {
      "rank_normalized_split_plus_folded_split_per_level_v4_directed_cycle_scaled_passive_bmi"
    }
  )
  list(
    pass = contract_ok,
    sha256 = digest::digest(
      signature,
      algo = "sha256",
      serialize = TRUE
    ),
    detail = paste0(
      "checkpoints=",
      paste(mi_spec$convergence_iteration_checkpoints, collapse = "/"),
      "; m=", mi_spec$initial_m, "/", mi_spec$maximum_m,
      "; Rhat<=", mi_spec$convergence_rhat_max,
      if (identical(cohort, "CHARLS")) {
        paste0(
          "; smoking_IAAC=",
          paste(head(mi_spec$visit_sequence, 2L), collapse = "->"),
          "; parent_excludes_child=",
          mi_spec$charls_smoking_skip_pattern$
            parent_equation_excludes_child,
          "; per_iteration_gate=",
          mi_spec$charls_smoking_skip_pattern$
            per_iteration_completed_pair_gate
        )
      } else {
        paste0(
          "; passive_BMI=",
          mi_spec$nhanes_passive_bmi$bmi_method,
          "; visit_prefix=",
          paste(
            head(
              mi_spec$visit_sequence,
              length(
                mi_spec$nhanes_passive_bmi$visit_sequence_prefix
              )
            ),
            collapse = "->"
          ),
          "; observed_BMI_preserved=",
          mi_spec$nhanes_passive_bmi$observed_bmi_preserved,
          "; released_cycle_precision=E",
          mi_spec$nhanes_passive_bmi$bmi_cycle_precision[["E"]],
          "/F",
          mi_spec$nhanes_passive_bmi$bmi_cycle_precision[["F"]],
          "/G",
          mi_spec$nhanes_passive_bmi$bmi_cycle_precision[["G"]],
          "; repeated_same_seed_dry_runs=",
          mi_spec$nhanes_passive_bmi$same_seed_dry_run_replicates
        )
      },
      "; trace_release_missing_n>=",
      mi_spec$trace_release_missing_n_min,
      "; unordered_targets=",
      if (length(mi_spec$unordered_multicategory_targets)) {
        paste(
          sort(mi_spec$unordered_multicategory_targets),
          collapse = "|"
        )
      } else {
        "none"
      }
    )
  )
}

load_stage3_environment <- function(path) {
  env <- new.env(parent = globalenv())
  sys.source(path, envir = env)
  env
}

governance_preflight <- function(root, store) {
  required_packages <- c(
    "digest", "dplyr", "haven", "mice", "readr", "survey", "survival",
    "tibble", "tidyr", "yaml"
  )
  available <- vapply(required_packages, requireNamespace, logical(1), quietly = TRUE)
  add_check(
    store, "BOTH", "preflight_packages_available", all(available),
    paste(names(available), available, sep = "=", collapse = "; "),
    paste(required_packages, collapse = "; ")
  )

  gate_path <- file.path(root, "work_v43", "gate_state_v43.yml")
  validator_path <- file.path(root, "results", "v43", "gate1_2_validation_v43.csv")
  validator_inventory_path <- file.path(
    root, "results", "v43", "stage0_2_validated_source_inventory_v43.csv"
  )
  manifest_path <- file.path(root, "results", "v43", "input_manifest_private_v43.csv")
  gate <- yaml::read_yaml(gate_path)
  gate_ok <- identical(toupper(gate$gate0$status), "PASS") &&
    identical(toupper(gate$gate1$status), "PASS") &&
    identical(toupper(gate$gate2$status), "PASS")
  add_check(
    store, "BOTH", "gate0_2_pass_before_preflight", gate_ok,
    paste0("Gate0=", gate$gate0$status, "; Gate1=", gate$gate1$status, "; Gate2=", gate$gate2$status,
           "; outcome_allowed=", gate$outcome_execution_allowed),
    "Gate0=PASS; Gate1=PASS; Gate2=PASS; outcome models remain unfitted during preflight"
  )
  outcome_disabled <- identical(gate$outcome_execution_allowed, FALSE)
  add_check(
    store, "BOTH", "outcome_execution_disabled_during_preflight", outcome_disabled,
    paste0("outcome_execution_allowed=", gate$outcome_execution_allowed),
    "outcome_execution_allowed=false until the no-model preflight has passed"
  )

  validator <- utils::read.csv(validator_path, stringsAsFactors = FALSE, check.names = FALSE)
  required <- as_flag(validator$required)
  validator_status_ok <- any(required %in% TRUE) &&
    all(toupper(validator$status[required %in% TRUE]) == "PASS")
  validator_inventory <- utils::read.csv(
    validator_inventory_path,
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
  validator_inventory_schema <- all(
    c("path", "exists", "bytes", "sha256") %in% names(validator_inventory)
  ) && nrow(validator_inventory) > 0L &&
    !anyDuplicated(normalizePath(validator_inventory$path, mustWork = FALSE))
  validator_inventory_hash <- if (validator_inventory_schema) {
    vapply(as.character(validator_inventory$path), sha256_file, character(1))
  } else {
    character()
  }
  validator_inventory_bytes <- if (validator_inventory_schema) {
    vapply(as.character(validator_inventory$path), function(path) {
      if (!file.exists(path) || dir.exists(path)) return(NA_real_)
      as.numeric(file.info(path)$size)
    }, numeric(1))
  } else {
    numeric()
  }
  validator_inventory_current <- validator_inventory_schema &&
    all(as_flag(validator_inventory$exists) %in% TRUE) &&
    all(!is.na(validator_inventory_hash)) &&
    identical(
      tolower(unname(validator_inventory_hash)),
      tolower(as.character(validator_inventory$sha256))
    ) &&
    isTRUE(all.equal(
      unname(validator_inventory_bytes),
      suppressWarnings(as.numeric(validator_inventory$bytes)),
      check.attributes = FALSE
    ))
  report_binding_columns <- c(
    "validator_script_sha256", "private_manifest_sha256",
    "validated_source_inventory_sha256"
  )
  validator_report_bound <- all(report_binding_columns %in% names(validator)) &&
    all(vapply(report_binding_columns, function(name) {
      length(unique(as.character(validator[[name]]))) == 1L
    }, logical(1))) &&
    identical(
      tolower(unique(as.character(validator$validator_script_sha256))),
      tolower(sha256_file(file.path(root, "R", "v43", "03_validate_stage0_2.R")))
    ) &&
    identical(
      tolower(unique(as.character(validator$private_manifest_sha256))),
      tolower(sha256_file(manifest_path))
    ) &&
    identical(
      tolower(unique(as.character(validator$validated_source_inventory_sha256))),
      tolower(sha256_file(validator_inventory_path))
    )
  validator_ok <- validator_status_ok && validator_inventory_current &&
    validator_report_bound
  add_check(
    store, "BOTH", "independent_stage0_2_validator_pass", validator_ok,
    paste0(
      sum(toupper(validator$status[required %in% TRUE]) == "PASS"), "/",
      sum(required %in% TRUE), " required PASS; source inventory current=",
      validator_inventory_current, "; report bound=", validator_report_bound
    ),
    "all required independent validator rows PASS and its manifest/script/upstream-source snapshot still matches current files"
  )

  manifest <- utils::read.csv(manifest_path, stringsAsFactors = FALSE, check.names = FALSE)
  manifest_required <- c("group", "role", "path", "restricted", "exists", "bytes", "sha256")
  manifest_schema_ok <- all(manifest_required %in% names(manifest)) && nrow(manifest) > 0L
  manifest_unique <- manifest_schema_ok && !anyDuplicated(normalizePath(manifest$path, mustWork = FALSE))
  current_hash <- if (manifest_schema_ok) {
    vapply(as.character(manifest$path), sha256_file, character(1))
  } else {
    character()
  }
  current_bytes <- if (manifest_schema_ok) {
    vapply(as.character(manifest$path), function(path) {
      if (!file.exists(path) || dir.exists(path)) return(NA_real_)
      as.numeric(file.info(path)$size)
    }, numeric(1))
  } else {
    numeric()
  }
  recorded_hash <- if (manifest_schema_ok) tolower(as.character(manifest$sha256)) else character()
  recorded_bytes <- if (manifest_schema_ok) suppressWarnings(as.numeric(manifest$bytes)) else numeric()
  recorded_exists <- if (manifest_schema_ok) as_flag(manifest$exists) else logical()
  manifest_current <- manifest_schema_ok && manifest_unique &&
    all(recorded_exists %in% TRUE) &&
    length(current_hash) == nrow(manifest) &&
    all(!is.na(current_hash)) &&
    identical(tolower(unname(current_hash)), recorded_hash) &&
    isTRUE(all.equal(unname(current_bytes), recorded_bytes, check.attributes = FALSE))
  add_check(
    store, "BOTH", "preliminary_manifest_current_and_complete", manifest_current,
    if (!manifest_schema_ok) {
      "manifest schema missing"
    } else {
      paste0(
        nrow(manifest), " rows; unique paths=", manifest_unique,
        "; current hashes=", sum(!is.na(current_hash) & tolower(current_hash) == recorded_hash),
        "/", nrow(manifest),
        "; current sizes=", sum(!is.na(current_bytes) & current_bytes == recorded_bytes),
        "/", nrow(manifest)
      )
    },
    "every preliminary-manifest path is unique, present, and exactly matches its recorded size and SHA-256"
  )

  spec <- yaml::read_yaml(file.path(root, "work_v43", "analysis_spec_v43.yml"))
  resolve <- function(path) if (grepl("^/", path)) path else file.path(root, path)
  snapshot_paths <- c(
    stage0_script_sha256 = file.path(root, "R", "v43", "00_freeze_and_manifest.R"),
    validator_script_sha256 = file.path(root, "R", "v43", "03_validate_stage0_2.R"),
    preflight_script_sha256 = file.path(root, "R", "v43", "03b_stage3_preflight.R"),
    charls_script_sha256 = file.path(root, "R", "v43", "04_charls_stage3_primary_mortality.R"),
    nhanes_script_sha256 = file.path(root, "R", "v43", "05_nhanes_stage3_primary_mortality.R"),
    finalizer_script_sha256 = file.path(root, "R", "v43", "06_finalize_stage3_outputs.R"),
    analysis_spec_sha256 = file.path(root, "work_v43", "analysis_spec_v43.yml"),
    charls_core_sha256 = resolve(spec$inputs$charls_core),
    charls_ledger_sha256 = file.path(root, "derived_sensitive", "v43", "charls_stage1_ledger_v43.rds"),
    charls_e0_sha256 = file.path(root, "results", "v43", "charls_e0_scale_v43.csv"),
    nhanes_ledger_sha256 = file.path(root, "derived_sensitive", "v43", "nhanes_stage1_ledger_v43.rds"),
    nhanes_donor_sha256 = resolve(spec$inputs$nhanes_ready),
    nhanes_e0_sha256 = file.path(root, "results", "v43", "nhanes_e0_scale_v43.csv"),
    nhanes_function_routing_audit_sha256 = file.path(root, "results", "v43", "nhanes_function_routing_audit_v43.csv"),
    nhanes_function_proxy_evidence_sha256 = file.path(root, "output", "qa", "v43_NHANES_FUNCTION_PROXY_EVIDENCE_20260716.md"),
    renv_lock_sha256 = resolve(spec$software$lockfile),
    validator_report_sha256 = validator_path,
    validator_source_inventory_sha256 = validator_inventory_path,
    preliminary_manifest_sha256 = manifest_path
  )
  snapshot_hashes <- vapply(snapshot_paths, sha256_file, character(1))
  store$snapshot <- c(
    as.list(snapshot_hashes),
    list(
      check_contract_sha256 = check_contract_sha256(),
      stable_input_inventory_sha256 = inventory_sha256(manifest)
    )
  )

  governance_ok <- gate_ok && outcome_disabled && validator_ok &&
    manifest_current && all(available) &&
    all(!is.na(unlist(store$snapshot, use.names = FALSE)))
  add_check(
    store, "BOTH", "governance_preflight_completed", governance_ok,
    paste0(
      "packages=", all(available),
      "; gates=", gate_ok,
      "; outcome_disabled=", outcome_disabled,
      "; validator=", validator_ok,
      "; manifest_current=", manifest_current,
      "; snapshot_complete=", all(!is.na(unlist(store$snapshot, use.names = FALSE)))
    ),
    "all preliminary governance checks and the immutable hash snapshot complete successfully"
  )
  invisible(governance_ok)
}

preflight_charls <- function(root, env, store) {
  paths <- list(
    spec = file.path(root, "work_v43", "analysis_spec_v43.yml"),
    charls_ledger = file.path(root, "derived_sensitive", "v43", "charls_stage1_ledger_v43.rds"),
    charls_e0 = file.path(root, "results", "v43", "charls_e0_scale_v43.csv")
  )
  audit_store <- env$new_audit_store()
  master <- env$build_charls_master(root, paths, audit_store)
  period <- env$build_period_skeleton(master, audit_store)
  master <- env$augment_mi_outcome_predictors(master, period)
  knots <- env$freeze_spline_knots(master)
  mi_data <- env$make_mi_input(master)
  mi_spec <- env$freeze_mi_specification(mi_data)
  analysis_spec <- yaml::read_yaml(paths$spec)
  mi_contract <- mi_specification_contract(
    mi_spec,
    analysis_spec,
    cohort = "CHARLS"
  )
  expanded <- expanded_predictor_columns(mi_data, mi_spec)
  smoking_applicable <-
    charls_smoking_applicable_predictor_audit(mi_data, mi_spec)
  w2_landmark_period <- env$build_w2_landmark_period(master, period)
  time_support <- env$planned_time_basis_support_audit(master, period)

  summarize_time_support <- function(data, strata) {
    data |>
      dplyr::group_by(dplyr::across(dplyr::all_of(strata))) |>
      dplyr::summarise(
        transition_rows = dplyr::n(),
        deaths = sum(period_event == 1L),
        non_deaths = sum(period_event == 0L),
        weighted_events = sum(weight_biomarker_w1[period_event == 1L]),
        weighted_non_events = sum(weight_biomarker_w1[period_event == 0L]),
        .groups = "drop"
      ) |>
      dplyr::arrange(dplyr::across(dplyr::all_of(strata)))
  }
  exact_counts_equal <- function(observed, expected) {
    if (!identical(names(observed), names(expected)) ||
        nrow(observed) != nrow(expected)) {
      return(FALSE)
    }
    isTRUE(all.equal(
      as.data.frame(observed),
      as.data.frame(expected),
      tolerance = 0,
      check.attributes = FALSE
    ))
  }
  window_support <- summarize_time_support(
    period,
    c("window_id", "nominal_years")
  )
  expected_window_support <- tibble::tibble(
    window_id = c(
      "W1_W2", "W1_W3", "W1_W4", "W1_W5", "W2_W3",
      "W2_W4", "W2_W5", "W3_W4", "W3_W5", "W4_W5"
    ),
    nominal_years = c(2, 4, 7, 9, 2, 5, 7, 3, 5, 2),
    transition_rows = c(
      12427L, 41L, 14L, 73L, 11839L,
      40L, 102L, 10795L, 455L, 9717L
    ),
    deaths = c(276L, 41L, 14L, 10L, 335L, 40L, 22L, 539L, 69L, 389L),
    non_deaths = c(
      12151L, 0L, 0L, 63L, 11504L,
      0L, 80L, 10256L, 386L, 9328L
    )
  )
  window_count_support <- window_support[
    ,
    names(expected_window_support),
    drop = FALSE
  ]
  primary_end_wave_support <- summarize_time_support(period, "end_wave")
  expected_primary_end_wave_support <- tibble::tibble(
    end_wave = 2:5,
    transition_rows = c(12427L, 11880L, 10849L, 10347L),
    deaths = c(276L, 376L, 593L, 490L),
    non_deaths = c(12151L, 11504L, 10256L, 9857L)
  )
  primary_count_support <- primary_end_wave_support[
    ,
    names(expected_primary_end_wave_support),
    drop = FALSE
  ]
  w2_end_wave_support <- summarize_time_support(
    w2_landmark_period,
    "end_wave"
  )
  expected_w2_end_wave_support <- tibble::tibble(
    end_wave = 3:5,
    transition_rows = c(11839L, 10835L, 10274L),
    deaths = c(335L, 579L, 480L),
    non_deaths = c(11504L, 10256L, 9794L)
  )
  w2_count_support <- w2_end_wave_support[
    ,
    names(expected_w2_end_wave_support),
    drop = FALSE
  ]
  legacy_all_event_windows <- sort(as.character(
    window_support$window_id[
      window_support$deaths > 0L & window_support$non_deaths == 0L
    ]
  ))
  expected_time_samples <- c(
    "charls_primary_mortality_eligible_common_mi",
    "charls_common_A2_complete_case",
    "charls_boundary_excluded_common_mi",
    "charls_strict_measurement_common_mi",
    "charls_known_alive_w2_with_post_w2_explicit_followup_common_mi"
  )
  aggregate_support_ok <-
    nrow(master) == 12555L &&
    nrow(period) == 45503L &&
    sum(period$period_event) == 1735L &&
    exact_counts_equal(window_count_support, expected_window_support) &&
    exact_counts_equal(
      primary_count_support,
      expected_primary_end_wave_support
    ) &&
    exact_counts_equal(w2_count_support, expected_w2_end_wave_support) &&
    identical(
      legacy_all_event_windows,
      sort(c("W1_W3", "W1_W4", "W2_W4"))
    ) &&
    nrow(time_support) == 19L &&
    setequal(unique(time_support$sample_id), expected_time_samples) &&
    all(time_support$baseline_stratum_outcome_support_pass %in% TRUE) &&
    all(time_support$e0_marginal_overlap_pass %in% TRUE) &&
    all(time_support$cluster_support_pass %in% TRUE) &&
    all(time_support$time_basis_support_pass %in% TRUE) &&
    all(is.finite(time_support$weighted_events) &
      time_support$weighted_events > 0) &&
    all(is.finite(time_support$weighted_non_events) &
      time_support$weighted_non_events > 0)
  add_check(
    store,
    "CHARLS",
    "structural_sample_time_support_rebuilt",
    aggregate_support_ok,
    paste0(
      "N=", nrow(master),
      "; transitions=", nrow(period),
      "; deaths=", sum(period$period_event),
      "; legacy windows=", nrow(window_support),
      "; all-event legacy set=",
      paste(legacy_all_event_windows, collapse = "|"),
      "; primary end-wave support=",
      sum(primary_end_wave_support$deaths > 0L &
        primary_end_wave_support$non_deaths > 0L),
      "/", nrow(primary_end_wave_support),
      "; W2 landmark support=",
      sum(w2_end_wave_support$deaths > 0L &
        w2_end_wave_support$non_deaths > 0L),
      "/", nrow(w2_end_wave_support),
      "; registered sample-strata=", nrow(time_support),
      "; minimum unweighted cell=",
      min(time_support$minimum_outcome_cell),
      "; minimum weighted event/non-event mass=",
      signif(min(c(
        time_support$weighted_events,
        time_support$weighted_non_events
      )), 7)
    ),
    paste(
      "N=12555, 45503 transitions and 1735 deaths; exact ten-window and",
      "four-end-wave anchors; legacy all-event set W1_W3/W1_W4/W2_W4;",
      "primary 4/4, W2 landmark 3/3, and all 19 registered sample/end-wave",
      "strata have positive finite weighted and unweighted outcome support,",
      "overlapping marginal E0 support, and >=2 PSUs per outcome state;",
      "this is a necessary time-basis gate, not proof that every multivariable",
      "configuration is nonseparated"
    )
  )
  add_check(store, "CHARLS", "mi_targets_have_predictors", nrow(expanded) > 0 && all(expanded$expanded_columns > 0),
            paste0(
              "targets=", nrow(expanded),
              "; predictor variables range=", paste(range(expanded$predictor_variables), collapse = "-"),
              "; expanded columns range=", paste(range(expanded$expanded_columns), collapse = "-")
            ),
            "every actually imputed field has a nonempty predictor set")
  add_check(
    store, "CHARLS", "mi_specification_hash_recorded", mi_contract$pass,
    paste0(
      "sha256=", mi_contract$sha256,
      "; seed=", mi_spec$seed,
      "; ", mi_contract$detail
    ),
    "the methods, predictors, visit sequence, CHARLS smoking skip-pattern IAAC, category targets, seed, 20/40/80 schedule, m=50/100, MCE, R-hat and trace-release rules match the analysis specification and have a deterministic hash"
  )
  predictor_matrix_ok <- isTRUE(all(
    expanded$expanded_columns < expanded$observed_target_rows &
      expanded$full_rank &
      !nzchar(expanded$unused_factor_levels) &
      is.finite(expanded$normalized_crossprod_rcond) &
      expanded$normalized_crossprod_rcond > 0
  )) && smoking_applicable$pass
  minimum_normalized_rcond <- if (any(is.finite(expanded$normalized_crossprod_rcond))) {
    min(expanded$normalized_crossprod_rcond[is.finite(expanded$normalized_crossprod_rcond)])
  } else {
    NA_real_
  }
  add_check(
    store, "CHARLS", "mi_expanded_dimension_below_rows", predictor_matrix_ok,
    paste0(
      "max columns=", max(expanded$expanded_columns),
      "; min observed target rows=", min(expanded$observed_target_rows),
      "; full-rank targets=", sum(expanded$full_rank), "/", nrow(expanded),
      "; unused factor-level targets=", sum(nzchar(expanded$unused_factor_levels)),
      "; min normalized rcond=", signif(minimum_normalized_rcond, 4),
      "; smoking applicable equation: ", smoking_applicable$detail
    ),
    "each target-specific expanded predictor matrix is smaller than its observed-target sample, full rank, free of unused factor levels, and has positive normalized reciprocal condition; the current-smoking equation separately passes the ever=1 applicable-subset design audit after removing the routing parent"
  )
  if (!predictor_matrix_ok) {
    if (!smoking_applicable$pass) {
      stop(
        "The CHARLS applicable-branch smoking IAAC design failed: ",
        smoking_applicable$detail,
        call. = FALSE
      )
    }
    bad_flag <-
      expanded$expanded_columns >= expanded$observed_target_rows |
        !expanded$full_rank |
        nzchar(expanded$unused_factor_levels) |
        !is.finite(expanded$normalized_crossprod_rcond) |
        expanded$normalized_crossprod_rcond <= 0
    bad_flag[is.na(bad_flag)] <- TRUE
    bad <- expanded[bad_flag, , drop = FALSE]
    stop(
      "CHARLS target-specific MI predictor matrices failed: ",
      paste(
        paste0(
          bad$target,
          "[columns=", bad$expanded_columns,
          ",rank=", bad$matrix_rank,
          ",unused=", ifelse(nzchar(bad$unused_factor_levels), bad$unused_factor_levels, "none"),
          "]"
        ),
        collapse = "; "
      ),
      call. = FALSE
    )
  }

  dry <- capture_mice_dry_run(env$run_mi, mi_data, mi_spec)
  if (!dry$ok) {
    add_check(
      store, "CHARLS", "two_by_two_mice_dry_run", FALSE,
      paste0(
        "error=", dry$error,
        "; elapsed_seconds=", round(dry$elapsed, 2),
        "; warnings=", if (length(dry$warnings)) paste(dry$warnings, collapse = " | ") else "0"
      ),
      "m=2/maxit=2 completes with zero warnings and zero logged events without fitting an outcome model"
    )
    stop("CHARLS MICE dry run failed: ", dry$error, call. = FALSE)
  }
  imp <- dry$imp
  completed <- mice::complete(imp, action = 1L)
  completed <- env$attach_passive_variables(completed, knots)
  logged_events <- if (is.null(imp$loggedEvents)) 0L else nrow(imp$loggedEvents)
  category_trace <- validate_monitored_category_trace(
    env, imp, mi_data, mi_spec
  )
  smoking_coherence <- validate_monitored_smoking_coherence(env, imp)
  dry_ok <- nrow(completed) == nrow(mi_data) &&
    imp$iteration == 2L &&
    length(dry$warnings) == 0L &&
    logged_events == 0L &&
    category_trace$pass &&
    smoking_coherence$pass
  add_check(
    store, "CHARLS", "two_by_two_mice_dry_run", dry_ok,
    paste0(
      "rows=", nrow(completed),
      "; elapsed_seconds=", round(dry$elapsed, 2),
      "; warnings=", length(dry$warnings),
      "; logged_events=", logged_events,
      "; ", category_trace$detail,
      "; ", smoking_coherence$detail
    ),
    "m=2/maxit=2 completes by monitored single-iteration advancement with zero warnings/events, a valid unordered-category per-level trace grid, and zero unresolved or ever=0/current=1 pairs across every chain and iteration, without fitting an outcome model"
  )
  if (!dry_ok) {
    stop(
      "CHARLS MICE dry run emitted numerical warnings or logged events.",
      call. = FALSE
    )
  }

  transition_fields <- c("participant_id", "start_wave", "end_wave", "window_id", "period_event", "nominal_years")
  pp <- dplyr::inner_join(period[transition_fields], completed, by = "participant_id")
  formulas <- env$model_formulas("E0")
  formula_contract <- vapply(
    names(formulas),
    function(tier) {
      tryCatch(
        {
          env$validate_inferential_time_formula(
            formulas[[tier]],
            paste0("preflight_", tier)
          )
          TRUE
        },
        error = function(e) FALSE
      )
    },
    logical(1)
  )
  ranks <- vapply(formulas, function(formula) {
    mm <- stats::model.matrix(formula, data = pp)
    qr(mm)$rank == ncol(mm)
  }, logical(1))
  w2_landmark_pp <- dplyr::inner_join(
    w2_landmark_period[transition_fields],
    completed,
    by = "participant_id"
  )
  w2_landmark_matrix <- stats::model.matrix(
    formulas$A1,
    data = w2_landmark_pp
  )
  w2_landmark_rank_ok <- qr(w2_landmark_matrix)$rank ==
    ncol(w2_landmark_matrix)
  design <- survey::svydesign(
    ids = ~community_id + participant_id,
    weights = ~weight_biomarker_w1,
    data = pp,
    nest = TRUE
  )
  w2_landmark_design <- survey::svydesign(
    ids = ~community_id + participant_id,
    weights = ~weight_biomarker_w1,
    data = w2_landmark_pp,
    nest = TRUE
  )
  max_columns <- max(vapply(formulas, function(formula) ncol(stats::model.matrix(formula, data = pp)), integer(1)))
  add_check(
    store, "CHARLS", "A0_A2_model_matrices_full_rank",
    all(formula_contract) && all(ranks) && w2_landmark_rank_ok,
    paste0(
      "time formula contract: ",
      paste(names(formula_contract), formula_contract, sep = "=", collapse = "; "),
      "; matrix rank: ",
      paste(names(ranks), ranks, sep = "=", collapse = "; "),
      "; W2_landmark_A1=", w2_landmark_rank_ok,
      "; landmark_N=", length(unique(w2_landmark_pp$participant_id)),
      "; landmark_transitions=", nrow(w2_landmark_pp),
      "; landmark_deaths=", sum(w2_landmark_pp$period_event)
    ),
    "A0, A1, A2, and W2-landmark A1 use only factor(end_wave) plus the nominal-duration offset, contain no window/time interaction, and are full rank independently of the preceding outcome-support gate"
  )
  add_check(
    store, "CHARLS", "survey_design_df_exceeds_model_dimension",
    survey::degf(design) > max_columns &&
      survey::degf(w2_landmark_design) > ncol(w2_landmark_matrix),
    paste0(
      "primary design_df=", survey::degf(design),
      "; primary max_columns=", max_columns,
      "; landmark design_df=", survey::degf(w2_landmark_design),
      "; landmark columns=", ncol(w2_landmark_matrix)
    ),
    "survey design degrees of freedom exceed both primary and W2-landmark model dimensions"
  )
  add_check(store, "CHARLS", "spline_knots_finite", all(is.finite(unlist(knots[c("weighted_q05", "weighted_q35", "weighted_q65", "weighted_q95")]))),
            paste0("rows=", nrow(knots)), "four finite frozen knot rows")
  add_check(
    store, "CHARLS", "charls_preflight_completed", TRUE,
    "all fixed CHARLS preflight operations completed",
    "all CHARLS sample, MI-feasibility, design, and matrix checks execute without an outcome model"
  )
}

preflight_nhanes <- function(root, env, store) {
  paths <- list(
    spec = file.path(root, "work_v43", "analysis_spec_v43.yml"),
    nhanes_ledger = file.path(root, "derived_sensitive", "v43", "nhanes_stage1_ledger_v43.rds"),
    nhanes_donor = file.path(root, "derived_sensitive", "nhanes", "nhanes_mortality_analysis_ready_v30_0.rds"),
    nhanes_e0 = file.path(root, "results", "v43", "nhanes_e0_scale_v43.csv")
  )
  audit_store <- env$new_audit_store()
  built <- env$build_nhanes_master(root, paths, audit_store)
  master <- built$master
  backbone <- built$backbone
  primary <- master[master$primary_domain %in% TRUE, , drop = FALSE]
  knots <- env$freeze_spline_knots(primary)
  mi_data <- env$make_mi_input(master, master$primary_domain)
  analysis_spec <- yaml::read_yaml(paths$spec)
  older_spec <-
    analysis_spec$nhanes$function_health_boundary$older_adult_sensitivity
  older_status <- if (is.list(older_spec)) {
    if (!is.null(older_spec$status) && length(older_spec$status) == 1L) {
      as.character(older_spec$status)
    } else {
      NA_character_
    }
  } else {
    NA_character_
  }
  older_role <- if (is.list(older_spec)) {
    if (!is.null(older_spec$role) && length(older_spec$role) == 1L) {
      as.character(older_spec$role)
    } else {
      NA_character_
    }
  } else {
    NA_character_
  }
  older_registered_n <- if (is.list(older_spec)) {
    if (!is.null(older_spec$registered_n) &&
        length(older_spec$registered_n) == 1L) {
      suppressWarnings(as.integer(older_spec$registered_n))
    } else {
      NA_integer_
    }
  } else {
    NA_integer_
  }
  older_registered_events <- if (is.list(older_spec)) {
    if (!is.null(older_spec$registered_events) &&
        length(older_spec$registered_events) == 1L) {
      suppressWarnings(as.integer(older_spec$registered_events))
    } else {
      NA_integer_
    }
  } else {
    NA_integer_
  }
  older_status_ok <- identical(older_status, "NOT_ESTIMABLE")
  mi_spec <- env$freeze_mi_specification(
    mi_data,
    seed = as.integer(analysis_spec$seeds$missing_data_mi)
  )
  mi_contract <- mi_specification_contract(
    mi_spec,
    analysis_spec,
    cohort = "NHANES"
  )
  expanded <- expanded_predictor_columns(mi_data, mi_spec)

  older_primary <- primary[
    primary$RIDAGEYR >= 60 & primary$RIDAGEYR <= 79,
    ,
    drop = FALSE
  ]
  older_strata <- length(unique(older_primary$design_strata))
  older_psu <- length(unique(older_primary$design_psu))
  older_event_strata <- length(unique(
    older_primary$design_strata[older_primary$death == 1L]
  ))
  older_nonevent_strata <- length(unique(
    older_primary$design_strata[older_primary$death == 0L]
  ))
  older_event_psu <- length(unique(
    older_primary$design_psu[older_primary$death == 1L]
  ))
  older_nonevent_psu <- length(unique(
    older_primary$design_psu[older_primary$death == 0L]
  ))
  older_both_outcomes_by_stratum <- tapply(
    older_primary$death,
    older_primary$design_strata,
    function(x) any(x == 1L) && any(x == 0L)
  )
  older_both_outcomes_by_cycle <- tapply(
    older_primary$death,
    older_primary$cycle_label,
    function(x) any(x == 1L) && any(x == 0L)
  )
  older_anchor_ok <-
    nrow(older_primary) == 3346L &&
    sum(older_primary$death == 1L) == 701L &&
    sum(older_primary$death == 0L) == 2645L &&
    older_registered_n == 3346L &&
    older_registered_events == 701L
  older_aggregate_support_ok <-
    older_strata == 45L &&
    older_psu == 94L &&
    older_event_strata == 45L &&
    older_nonevent_strata == 45L &&
    older_event_psu == 93L &&
    older_nonevent_psu == 94L &&
    length(older_both_outcomes_by_stratum) == 45L &&
    all(older_both_outcomes_by_stratum) &&
    length(older_both_outcomes_by_cycle) == 3L &&
    all(older_both_outcomes_by_cycle)
  primary_anchor_ok <-
    nrow(primary) == 6719L &&
    sum(primary$death == 1L) == 925L
  add_check(
    store, "NHANES", "primary_sample_and_events_rebuilt",
    primary_anchor_ok && older_anchor_ok && older_aggregate_support_ok,
    paste0(
      "primary N/deaths=", nrow(primary), "/", sum(primary$death == 1L),
      "; age60_79 N/deaths/nondeaths=", nrow(older_primary), "/",
      sum(older_primary$death == 1L), "/",
      sum(older_primary$death == 0L),
      "; registered N/events=", older_registered_n, "/",
      older_registered_events,
      "; age60_79 strata/PSUs=", older_strata, "/", older_psu,
      "; event-supported strata/PSUs=", older_event_strata, "/",
      older_event_psu,
      "; non-event-supported strata/PSUs=", older_nonevent_strata, "/",
      older_nonevent_psu,
      "; strata with both outcomes=",
      sum(older_both_outcomes_by_stratum),
      "; cycles with both outcomes=", sum(older_both_outcomes_by_cycle)
    ),
    paste0(
      "primary N=6719/deaths=925; age60-79 N=3346/deaths=701/",
      "nondeaths=2645 agrees with the frozen registry anchors; all 45 strata, ",
      "94 PSUs, and all three cycles retain aggregate event/non-event support. ",
      "These are necessary prefit support conditions only and do not establish ",
      "finite coefficients or an invertible sandwich covariance matrix"
    )
  )
  add_check(store, "NHANES", "full_design_backbone_rebuilt", nrow(backbone) == 29353L &&
              length(unique(backbone$design_strata)) == 45L && length(unique(backbone$design_psu)) == 94L,
            paste0("N=", nrow(backbone), "; strata=", length(unique(backbone$design_strata)),
                   "; PSU=", length(unique(backbone$design_psu))),
            "N=29353, 45 strata and 94 PSUs")
  add_check(store, "NHANES", "mi_targets_have_predictors", nrow(expanded) > 0 && all(expanded$expanded_columns > 0),
            paste0(
              "targets=", nrow(expanded),
              "; predictor variables range=", paste(range(expanded$predictor_variables), collapse = "-"),
              "; expanded columns range=", paste(range(expanded$expanded_columns), collapse = "-")
            ),
            "every actually imputed field has a nonempty predictor set")
  add_check(
    store, "NHANES", "mi_specification_hash_recorded", mi_contract$pass,
    paste0(
      "sha256=", mi_contract$sha256,
      "; seed=", mi_spec$seed,
      "; ", mi_contract$detail
    ),
    "the methods, predictors, category targets, seed, 20/40/80 schedule, m=50/100, MCE, R-hat and trace-release rules match the analysis specification and have a deterministic hash"
  )
  predictor_matrix_ok <- isTRUE(all(
    expanded$expanded_columns < expanded$observed_target_rows &
      expanded$full_rank &
      !nzchar(expanded$unused_factor_levels) &
      is.finite(expanded$normalized_crossprod_rcond) &
      expanded$normalized_crossprod_rcond > 0
  ))
  minimum_normalized_rcond <- if (any(is.finite(expanded$normalized_crossprod_rcond))) {
    min(expanded$normalized_crossprod_rcond[is.finite(expanded$normalized_crossprod_rcond)])
  } else {
    NA_real_
  }
  add_check(
    store, "NHANES", "mi_expanded_dimension_below_rows", predictor_matrix_ok,
    paste0(
      "max columns=", max(expanded$expanded_columns),
      "; min observed target rows=", min(expanded$observed_target_rows),
      "; full-rank targets=", sum(expanded$full_rank), "/", nrow(expanded),
      "; unused factor-level targets=", sum(nzchar(expanded$unused_factor_levels)),
      "; min normalized rcond=", signif(minimum_normalized_rcond, 4)
    ),
    "each target-specific expanded predictor matrix is smaller than its observed-target sample, full rank, free of unused factor levels, and has positive normalized reciprocal condition"
  )
  if (!predictor_matrix_ok) {
    bad_flag <-
      expanded$expanded_columns >= expanded$observed_target_rows |
        !expanded$full_rank |
        nzchar(expanded$unused_factor_levels) |
        !is.finite(expanded$normalized_crossprod_rcond) |
        expanded$normalized_crossprod_rcond <= 0
    bad_flag[is.na(bad_flag)] <- TRUE
    bad <- expanded[bad_flag, , drop = FALSE]
    stop(
      "NHANES target-specific MI predictor matrices failed: ",
      paste(
        paste0(
          bad$target,
          "[columns=", bad$expanded_columns,
          ",rank=", bad$matrix_rank,
          ",unused=", ifelse(nzchar(bad$unused_factor_levels), bad$unused_factor_levels, "none"),
          "]"
        ),
        collapse = "; "
      ),
      call. = FALSE
    )
  }
  psu_pair <- interaction(mi_data$design_strata, mi_data$SDMVPSU, drop = TRUE)
  pair_map <- unique(data.frame(pair = as.character(psu_pair), design_psu = as.character(mi_data$design_psu)))
  add_check(
    store, "NHANES", "stratum_plus_raw_psu_reconstructs_design_psu",
    nlevels(psu_pair) == nlevels(mi_data$design_psu) &&
      !anyDuplicated(pair_map$pair) && !anyDuplicated(pair_map$design_psu),
    paste0("pairs=", nlevels(psu_pair), "; design_psu=", nlevels(mi_data$design_psu),
           "; mapped_rows=", nrow(pair_map)),
    "cycle-specific stratum plus raw within-stratum PSU code has a one-to-one map to all 94 design PSUs"
  )

  dry <- capture_mice_dry_run(env$run_mi, mi_data, mi_spec)
  if (!dry$ok) {
    add_check(
      store, "NHANES", "two_by_two_mice_dry_run", FALSE,
      paste0(
        "error=", dry$error,
        "; elapsed_seconds=", round(dry$elapsed, 2),
        "; warnings=", if (length(dry$warnings)) paste(dry$warnings, collapse = " | ") else "0"
      ),
      "m=2/maxit=2 completes with zero warnings and zero logged events without fitting an outcome model"
    )
    stop("NHANES MICE dry run failed: ", dry$error, call. = FALSE)
  }
  imp <- dry$imp
  passive_bmi <- validate_nhanes_passive_bmi_dry_run(
    env,
    imp,
    mi_data,
    mi_spec
  )
  dry_repeat <- capture_mice_dry_run(env$run_mi, mi_data, mi_spec)
  if (!dry_repeat$ok) {
    add_check(
      store, "NHANES", "two_by_two_mice_dry_run", FALSE,
      paste0(
        "first_elapsed_seconds=", round(dry$elapsed, 2),
        "; repeated_error=", dry_repeat$error,
        "; repeated_elapsed_seconds=", round(dry_repeat$elapsed, 2),
        "; repeated_warnings=",
        if (length(dry_repeat$warnings)) {
          paste(dry_repeat$warnings, collapse = " | ")
        } else {
          "0"
        },
        "; ", passive_bmi$detail
      ),
      "two independent same-seed m=2/maxit=2 runs complete without an outcome model and pass passive-BMI integrity plus bitwise reproducibility"
    )
    stop(
      "The repeated same-seed NHANES MICE dry run failed: ",
      dry_repeat$error,
      call. = FALSE
    )
  }
  imp_repeat <- dry_repeat$imp
  passive_bmi_repeat <- validate_nhanes_passive_bmi_dry_run(
    env,
    imp_repeat,
    mi_data,
    mi_spec
  )
  reproducibility <- same_seed_mice_reproducibility(
    imp,
    imp_repeat
  )
  completed <- mice::complete(imp, action = 1L)
  completed <- env$attach_passive_variables(completed, knots)
  logged_events <- if (is.null(imp$loggedEvents)) 0L else nrow(imp$loggedEvents)
  repeated_logged_events <- if (is.null(imp_repeat$loggedEvents)) {
    0L
  } else {
    nrow(imp_repeat$loggedEvents)
  }
  category_trace <- validate_monitored_category_trace(
    env, imp, mi_data, mi_spec
  )
  dry_ok <- nrow(completed) == nrow(mi_data) &&
    imp$iteration == 2L &&
    length(dry$warnings) == 0L &&
    logged_events == 0L &&
    imp_repeat$iteration == 2L &&
    length(dry_repeat$warnings) == 0L &&
    repeated_logged_events == 0L &&
    category_trace$pass &&
    passive_bmi$pass &&
    passive_bmi_repeat$pass &&
    reproducibility$pass
  add_check(
    store, "NHANES", "two_by_two_mice_dry_run", dry_ok,
    paste0(
      "rows=", nrow(completed),
      "; first/repeated_elapsed_seconds=",
      round(dry$elapsed, 2), "/", round(dry_repeat$elapsed, 2),
      "; first/repeated_warnings=", length(dry$warnings), "/",
      length(dry_repeat$warnings),
      "; first/repeated_logged_events=", logged_events, "/",
      repeated_logged_events,
      "; ", category_trace$detail,
      "; first_", passive_bmi$detail,
      "; repeated_", passive_bmi_repeat$detail,
      "; reproducibility=", reproducibility$detail
    ),
    "two independent same-seed m=2/maxit=2 runs complete by monitored single-iteration advancement with zero warnings/events, valid category traces, official passive-BMI identity, preserved observed BMI, and bitwise-identical RNG outputs, without fitting an outcome model"
  )
  if (!dry_ok) {
    stop(
      "NHANES MICE dry-run integrity, passive-BMI, or same-seed reproducibility gate failed.",
      call. = FALSE
    )
  }

  design_obj <- env$build_full_design_then_domain(completed, backbone)
  full_data <- design_obj$data
  domain_data <- full_data[full_data$analysis_domain, , drop = FALSE]
  formulas <- env$model_formulas("E0")
  primary_rank <- lapply(
    formulas,
    function(formula) env$model_matrix_rank(formula, domain_data)
  )
  ranks <- vapply(primary_rank, `[[`, logical(1), "full_rank")
  max_columns <- max(vapply(primary_rank, `[[`, integer(1), "columns"))
  older_ids <- env$as_num(as.character(older_primary$SEQN))
  older_design <- env$build_full_design_then_domain(
    completed,
    backbone,
    member_ids = older_ids
  )
  older_domain <- older_design$data[
    older_design$data$analysis_domain,
    ,
    drop = FALSE
  ]
  older_formulas <- formulas[c("A1", "A2")]
  older_rank <- lapply(
    older_formulas,
    function(formula) env$model_matrix_rank(formula, older_domain)
  )
  older_ranks <- vapply(older_rank, `[[`, logical(1), "full_rank")
  older_columns <- vapply(older_rank, `[[`, integer(1), "columns")
  older_design_df <- survey::degf(older_design$domain_design)
  completed$landmark_tstart_years <- 2
  landmark_ids <- env$as_num(as.character(completed$SEQN))[
    completed$followup_years > 2
  ]
  landmark_formula <- stats::as.formula(paste(
    "survival::Surv(landmark_tstart_years, followup_years, death) ~",
    env$model_rhs_text("A1", "E0")
  ))
  landmark_design <- env$build_full_design_then_domain(
    completed, backbone, member_ids = landmark_ids
  )
  landmark_domain <- landmark_design$data[
    landmark_design$data$analysis_domain,
    ,
    drop = FALSE
  ]
  landmark_rank <- env$model_matrix_rank(landmark_formula, landmark_domain)
  add_check(
    store, "NHANES", "full_design_before_domain_preserved",
    nrow(full_data) == 29353L &&
      nrow(domain_data) == 6719L &&
      nrow(older_design$data) == 29353L &&
      nrow(older_domain) == 3346L &&
      sum(older_domain$death == 1L) == 701L,
    paste0(
      "primary full/domain=", nrow(full_data), "/", nrow(domain_data),
      "; primary design_df=", survey::degf(design_obj$domain_design),
      "; age60_79 full/domain=", nrow(older_design$data), "/",
      nrow(older_domain),
      "; age60_79 deaths/design_df=", sum(older_domain$death == 1L), "/",
      older_design_df
    ),
    paste0(
      "the full 29353-person MEC design is constructed before both the ",
      "6719-person primary and 3346-person age60-79 domains; the latter ",
      "contains 701 deaths"
    )
  )
  add_check(
    store, "NHANES", "A0_A2_model_matrices_full_rank",
    all(ranks) && all(older_ranks),
    paste0(
      "primary ",
      paste0(
        names(primary_rank),
        "=",
        vapply(primary_rank, `[[`, integer(1), "columns"),
        "/",
        vapply(primary_rank, `[[`, integer(1), "rank"),
        collapse = "; "
      ),
      "; age60_79 ",
      paste0(
        names(older_rank),
        "=",
        older_columns,
        "/",
        vapply(older_rank, `[[`, integer(1), "rank"),
        collapse = "; "
      )
    ),
    paste0(
      "primary A0/A1/A2 and age60-79 A1/A2 matrices are full rank; ",
      "full rank is necessary but does not guarantee finite Cox estimates ",
      "or an invertible sandwich covariance matrix"
    )
  )
  add_check(
    store, "NHANES", "survey_design_df_exceeds_model_dimension",
    survey::degf(design_obj$domain_design) > max_columns &&
      survey::degf(landmark_design$domain_design) > landmark_rank$columns &&
      older_design_df > max(older_columns),
    paste0(
      "primary design_df=", survey::degf(design_obj$domain_design),
      "; primary max_columns=", max_columns,
      "; landmark design_df=", survey::degf(landmark_design$domain_design),
      "; landmark columns=", landmark_rank$columns,
      "; age60_79 design_df=", older_design_df,
      "; age60_79 A1/A2 columns=", paste(older_columns, collapse = "/")
    ),
    paste0(
      "survey design degrees of freedom exceed the primary, two-year ",
      "landmark, and age60-79 A1/A2 dimensions; this dimension check is ",
      "necessary but does not guarantee an invertible sandwich covariance matrix"
    )
  )

  split <- env$split_followup_windows(completed)
  split <- dplyr::left_join(split, completed, by = "SEQN")
  window_rank <- env$model_matrix_rank(env$window_formula_A1("E0"), split)
  log_time_alias <- env$supportive_log_time_alias_contract(completed, "E0")
  time_policy <- analysis_spec$nhanes$mortality$time_heterogeneity
  time_policy_ok <-
    !is.null(time_policy) &&
    grepl(
      "interpretive priority",
      as.character(time_policy$principal_handling),
      fixed = TRUE
    ) &&
    grepl(
      "supportive only, not an omnibus PH test",
      as.character(time_policy$supportive_log_time_role),
      fixed = TRUE
    ) &&
    grepl(
      "ties='efron'",
      as.character(time_policy$supportive_formula),
      fixed = TRUE
    ) &&
    grepl(
      "singular.ok=FALSE",
      as.character(time_policy$supportive_formula),
      fixed = TRUE
    ) &&
    grepl(
      "23-column/full-rank corrected supportive proxy matrix",
      as.character(time_policy$no_model_alias_gate),
      fixed = TRUE
    ) &&
    grepl(
      "exactly 23 finite coefficients",
      as.character(time_policy$runtime_gate),
      fixed = TRUE
    ) &&
    grepl(
      "not designed as a formal time-varying-effect-compatible",
      as.character(time_policy$mi_interpretation_limit),
      fixed = TRUE
    ) &&
    grepl(
      "outside v43.4 and v44",
      as.character(time_policy$joint_test_reference),
      fixed = TRUE
    )
  add_check(
    store, "NHANES", "start_stop_window_matrix_full_rank",
    window_rank$full_rank && landmark_rank$full_rank &&
      isTRUE(log_time_alias$pass) && time_policy_ok,
    paste0(
      "window rows=", nrow(split),
      "; window columns/rank=", window_rank$columns, "/", window_rank$rank,
      "; landmark N=", nrow(landmark_domain),
      "; landmark columns/rank=", landmark_rank$columns, "/", landmark_rank$rank,
      "; log-time N/strata/cycles=", log_time_alias$n, "/",
      log_time_alias$design_strata, "/", log_time_alias$cycles,
      "; max cycles per stratum=", log_time_alias$maximum_cycles_per_stratum,
      "; cycle dummies/rank increment=", log_time_alias$cycle_dummy_columns,
      "/", log_time_alias$cycle_rank_increment,
      "; cycle residual max=", signif(log_time_alias$cycle_residual_max, 6),
      "; proxy intercept removed=", log_time_alias$proxy_intercept_columns,
      "; corrected proxy columns/rank=", log_time_alias$proxy_columns,
      "/", log_time_alias$proxy_rank,
      "; minimum follow-up/event time=",
      signif(log_time_alias$minimum_followup_years, 6), "/",
      signif(log_time_alias$minimum_event_time_years, 6),
      "; distinct event times=", log_time_alias$distinct_event_times,
      "; frozen time policy=", time_policy_ok
    ),
    paste0(
      "0-2/2-5/>5-year A1 start-stop and two-year-left-truncated landmark ",
      "matrices are full rank; all 45 cycle-specific design strata map to ",
      "one cycle, exactly two cycle columns add zero rank beyond the stratum ",
      "space, the corrected supportive log-time proxy is 23/23 full rank, ",
      "follow-up begins at 1/12 year with 147 distinct positive event times, ",
      "and the v43.4 supportive-only/Efron/singular.ok=FALSE policy is frozen"
    )
  )
  preceding_nhanes_pass <- all(
    store$rows$status[
      store$rows$cohort == "NHANES" &
        store$rows$check != "nhanes_preflight_completed"
    ] == "PASS"
  )
  add_check(
    store, "NHANES", "nhanes_preflight_completed",
    preceding_nhanes_pass && older_status_ok,
    paste0(
      "all preceding NHANES checks=", preceding_nhanes_pass,
      "; older_adult_sensitivity status=", older_status,
      "; role=", older_role
    ),
    paste0(
      "all NHANES sample, MI-feasibility, design, aggregate support, and ",
      "matrix checks pass without an outcome model; frozen ",
      "nhanes.function_health_boundary.older_adult_sensitivity.status is ",
      "NOT_ESTIMABLE and the retired analysis is not reauthorized by ",
      "necessary prefit support alone"
    )
  )
}

write_preflight_outputs <- function(root, store) {
  out_dir <- file.path(root, "results", "v43")
  qa_dir <- file.path(root, "output", "qa", "v43")
  log_dir <- file.path(root, "logs", "v43")
  dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)
  dir.create(qa_dir, recursive = TRUE, showWarnings = FALSE)
  dir.create(log_dir, recursive = TRUE, showWarnings = FALSE)
  rows <- store$rows
  contract <- dplyr::arrange(expected_preflight_checks(), cohort, check)
  observed_contract <- dplyr::arrange(
    dplyr::select(rows, cohort, check),
    cohort, check
  )
  contract_ok <- nrow(rows) == nrow(contract) &&
    !anyDuplicated(paste(rows$cohort, rows$check, sep = "|")) &&
    identical(as.data.frame(observed_contract), as.data.frame(contract))
  if (!contract_ok) {
    stop("Internal error: preflight check output does not match the fixed unique contract.", call. = FALSE)
  }
  snapshot_names <- c(
    "check_contract_sha256", "stable_input_inventory_sha256",
    "stage0_script_sha256", "validator_script_sha256",
    "preflight_script_sha256", "charls_script_sha256", "nhanes_script_sha256",
    "finalizer_script_sha256",
    "analysis_spec_sha256", "charls_core_sha256", "charls_ledger_sha256",
    "charls_e0_sha256", "nhanes_ledger_sha256", "nhanes_donor_sha256",
    "nhanes_e0_sha256", "nhanes_function_routing_audit_sha256",
    "nhanes_function_proxy_evidence_sha256", "renv_lock_sha256", "validator_report_sha256",
    "validator_source_inventory_sha256", "preliminary_manifest_sha256"
  )
  snapshot <- store$snapshot
  if (is.null(snapshot)) snapshot <- setNames(as.list(rep(NA_character_, length(snapshot_names))), snapshot_names)
  for (name in snapshot_names) {
    value <- snapshot[[name]]
    rows[[name]] <- if (length(value) == 1L) as.character(value) else NA_character_
  }
  rows$run_timestamp <- format(Sys.time(), tz = "Asia/Shanghai", usetz = TRUE)
  readr::write_csv(rows, file.path(out_dir, "stage3_preflight_validation_v43.csv"))

  hard <- rows$hard_gate %in% TRUE
  snapshot_complete <- all(vapply(snapshot_names, function(name) {
    value <- unique(as.character(rows[[name]]))
    length(value) == 1L && !is.na(value) && nzchar(value) &&
      grepl("^[0-9a-fA-F]{64}$", value)
  }, logical(1)))
  overall <- if (
    all(hard) && all(rows$expected_check %in% TRUE) && all(rows$status == "PASS") &&
      identical(sort(unique(rows$cohort)), c("BOTH", "CHARLS", "NHANES")) &&
      snapshot_complete
  ) "PASS" else "FAIL"
  qa <- c(
    "# v43 Stage 3 preflight validation",
    "",
    paste0("Overall: **", overall, "**"),
    "",
    "No mortality outcome model was fitted. The preflight rebuilt samples; independently verified exact CHARLS transition-path and end-wave outcome-support anchors, including the necessary weighted/unweighted time-basis support gate; ran only monitored m=2/maxit=2 covariate-imputation feasibility checks (including unordered-category per-level trace-grid validation and the CHARLS every-chain/every-iteration smoking skip-pattern coherence gate); constructed survey designs; and separately checked the amended time-formula contract and frozen model-matrix ranks. For NHANES it also rebuilt the registered age60-79 N=3346/deaths=701 domain from the full MEC design, checked aggregate stratum/PSU/event support, A1/A2 matrix rank, and design degrees of freedom, and verified that the frozen status remains NOT_ESTIMABLE rather than treating those necessary prefit checks as authorization to refit the retired panel. Aggregate support, full rank, and nominal design degrees of freedom are not represented as proof of finite multivariable coefficients or an invertible sandwich covariance matrix; authorized fits retain warning, boundary, finite-coefficient/covariance, and fitted-probability runtime gates.",
    "",
    paste0("- Fixed hard checks passed: ", sum(rows$status == "PASS"), "/", nrow(rows)),
    paste0("- Fixed check-contract SHA-256: `", check_contract_sha256(), "`"),
    paste0("- Stable input-inventory SHA-256: `", unique(rows$stable_input_inventory_sha256), "`"),
    paste0("- CHARLS checks: ", sum(rows$cohort == "CHARLS")),
    paste0("- NHANES checks: ", sum(rows$cohort == "NHANES"))
  )
  writeLines(qa, file.path(qa_dir, "STAGE3_PREFLIGHT_VALIDATION_v43.md"), useBytes = TRUE)
  writeLines(
    c(
      paste0("v43 Stage 3 preflight: ", overall),
      paste0("Completed: ", format(Sys.time(), tz = "Asia/Shanghai", usetz = TRUE)),
      "Outcome models fitted: 0"
    ),
    file.path(log_dir, "03b_stage3_preflight_v43.log"),
    useBytes = TRUE
  )
  invisible(list(rows = rows, overall = overall))
}

main <- function() {
  root <- project_root()
  store <- new_check_store()
  governance_ok <- tryCatch(
    governance_preflight(root, store),
    error = function(e) {
      add_check(
        store, "BOTH", "governance_preflight_completed", FALSE,
        conditionMessage(e), "all preliminary governance checks complete"
      )
      FALSE
    }
  )

  if (isTRUE(governance_ok)) {
    charls_env <- tryCatch(
      load_stage3_environment(file.path(root, "R", "v43", "04_charls_stage3_primary_mortality.R")),
      error = function(e) {
        add_check(
          store, "CHARLS", "charls_preflight_completed", FALSE,
          paste0("script load failed: ", conditionMessage(e)),
          "CHARLS Stage 3 script loads and all CHARLS preflight operations complete"
        )
        NULL
      }
    )
    nhanes_env <- tryCatch(
      load_stage3_environment(file.path(root, "R", "v43", "05_nhanes_stage3_primary_mortality.R")),
      error = function(e) {
        add_check(
          store, "NHANES", "nhanes_preflight_completed", FALSE,
          paste0("script load failed: ", conditionMessage(e)),
          "NHANES Stage 3 script loads and all NHANES preflight operations complete"
        )
        NULL
      }
    )
    if (!is.null(charls_env)) tryCatch(
      preflight_charls(root, charls_env, store),
      error = function(e) add_check(
        store, "CHARLS", "charls_preflight_completed", FALSE,
        conditionMessage(e), "all CHARLS preflight operations complete"
      )
    )
    if (!is.null(nhanes_env)) tryCatch(
      preflight_nhanes(root, nhanes_env, store),
      error = function(e) add_check(
        store, "NHANES", "nhanes_preflight_completed", FALSE,
        conditionMessage(e), "all NHANES preflight operations complete"
      )
    )
  }

  result <- write_preflight_outputs(root, store)
  if (!identical(result$overall, "PASS")) {
    stop("Stage 3 preflight failed. No mortality outcome model was fitted.", call. = FALSE)
  }
  message("Stage 3 preflight PASS. Outcome models fitted: 0.")
}

if (sys.nframe() == 0L) {
  main()
}
