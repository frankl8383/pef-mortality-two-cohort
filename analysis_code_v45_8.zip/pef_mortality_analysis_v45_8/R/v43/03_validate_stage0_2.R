# v43 independent Stage 0-2 validator.
#
# Deliberate boundary: this script reads only the frozen specification, Stage 0
# manifests/aggregates, and Stage 1-2 aggregate CSV outputs.  It never opens an
# RDS, XPT, DTA, DAT, ZIP, or row-level analytic file and it fits no model.
# Missing or malformed upstream outputs are recorded as FAIL; validation still
# completes and writes both the machine- and human-readable reports.

options(stringsAsFactors = FALSE)

project_root <- function() {
  args <- commandArgs(trailingOnly = FALSE)
  file_arg <- grep("^--file=", args, value = TRUE)
  if (length(file_arg)) {
    script <- sub("^--file=", "", file_arg[[1]])
    return(normalizePath(file.path(dirname(script), "..", ".."), mustWork = TRUE))
  }
  normalizePath(getwd(), mustWork = TRUE)
}

root <- project_root()
results_dir <- file.path(root, "results", "v43")
qa_dir <- file.path(root, "output", "qa", "v43")
dir.create(results_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(qa_dir, recursive = TRUE, showWarnings = FALSE)

validation_csv <- file.path(results_dir, "gate1_2_validation_v43.csv")
validation_md <- file.path(qa_dir, "STAGE0_2_VALIDATION_v43.md")
validated_source_inventory_csv <- file.path(
  results_dir,
  "stage0_2_validated_source_inventory_v43.csv"
)

rel <- function(path) {
  root_prefix <- paste0(normalizePath(root, mustWork = TRUE), .Platform$file.sep)
  normalized <- normalizePath(path, mustWork = FALSE)
  if (startsWith(normalized, root_prefix)) {
    substring(normalized, nchar(root_prefix) + 1L)
  } else {
    normalized
  }
}

one_line <- function(x, empty = "") {
  x <- trimws(as.character(x))
  x <- x[!is.na(x) & nzchar(x)]
  if (!length(x)) return(empty)
  gsub("[\r\n]+", " ", paste(x, collapse = "; "))
}

as_flag <- function(x) {
  if (is.logical(x)) return(x)
  if (is.numeric(x)) return(ifelse(is.na(x), NA, x != 0))
  y <- toupper(trimws(as.character(x)))
  out <- rep(NA, length(y))
  out[y %in% c("TRUE", "T", "1", "YES", "Y", "PASS", "GO", "OK")] <- TRUE
  out[y %in% c("FALSE", "F", "0", "NO", "N", "FAIL", "NO-GO", "NO_GO", "ERROR")] <- FALSE
  out
}

sha256_file <- function(path) {
  if (!requireNamespace("digest", quietly = TRUE) ||
      !file.exists(path) || dir.exists(path)) return(NA_character_)
  digest::digest(file = path, algo = "sha256", serialize = FALSE)
}

is_whole_nonnegative <- function(x, tolerance = 1e-8) {
  x <- suppressWarnings(as.numeric(x))
  !is.na(x) & is.finite(x) & x >= 0 & abs(x - round(x)) <= tolerance
}

checks <- list()
add_check <- function(gate, check_id, pass, expected = "", observed = "",
                      source = "", detail = "", required = TRUE) {
  status <- if (isTRUE(pass)) "PASS" else if (isTRUE(required)) "FAIL" else "WARN"
  checks[[length(checks) + 1L]] <<- data.frame(
    gate = as.character(gate),
    check_id = as.character(check_id),
    required = isTRUE(required),
    status = status,
    expected = one_line(expected),
    observed = one_line(observed),
    source = one_line(source),
    detail = one_line(detail),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
  invisible(status)
}

safe_csv <- function(path) {
  if (!file.exists(path)) return(list(data = NULL, error = "file missing"))
  ext <- tolower(tools::file_ext(path))
  if (!ext %in% c("csv", "tsv")) {
    return(list(data = NULL, error = paste0("extension not permitted: .", ext)))
  }
  sep <- if (ext == "tsv") "\t" else ","
  tryCatch(
    list(
      data = utils::read.table(
        path,
        header = TRUE,
        sep = sep,
        quote = "\"",
        comment.char = "",
        na.strings = c("", "NA", "NaN"),
        check.names = FALSE,
        stringsAsFactors = FALSE,
        fileEncoding = "UTF-8-BOM"
      ),
      error = NULL
    ),
    error = function(e) list(data = NULL, error = conditionMessage(e))
  )
}

pick_col <- function(dat, candidates) {
  if (is.null(dat)) return(NULL)
  lower <- tolower(names(dat))
  hit <- match(tolower(candidates), lower, nomatch = 0L)
  hit <- hit[hit > 0L]
  if (!length(hit)) return(NULL)
  names(dat)[hit[[1]]]
}

col_num <- function(dat, candidates) {
  nm <- pick_col(dat, candidates)
  if (is.null(nm)) return(NULL)
  suppressWarnings(as.numeric(dat[[nm]]))
}

col_chr <- function(dat, candidates) {
  nm <- pick_col(dat, candidates)
  if (is.null(nm)) return(NULL)
  as.character(dat[[nm]])
}

aggregate_boundary <- function(dat) {
  if (is.null(dat)) return(list(pass = FALSE, detail = "unreadable"))
  dangerous <- c(
    "id", "pid", "seqn", "idind", "mergeid", "hhid", "hhidpn", "person_id",
    "participant_id", "respondent_id", "individual_id", "household_id"
  )
  hit <- names(dat)[tolower(names(dat)) %in% dangerous]
  list(
    pass = length(hit) == 0L,
    detail = if (length(hit)) paste("row-level identifier column(s):", paste(hit, collapse = ", ")) else
      paste0(nrow(dat), " aggregate rows; no row-level identifier column")
  )
}

gate_table_pass <- function(dat) {
  if (is.null(dat) || !nrow(dat)) return(list(pass = FALSE, observed = "unreadable or empty"))
  pass_col <- pick_col(dat, c("pass", "passed"))
  status_col <- pick_col(dat, c("status", "decision", "result"))
  if (!is.null(pass_col)) {
    flags <- as_flag(dat[[pass_col]])
    return(list(
      pass = length(flags) > 0L && all(!is.na(flags)) && all(flags),
      observed = paste0(sum(flags %in% TRUE, na.rm = TRUE), "/", length(flags), " PASS")
    ))
  }
  if (!is.null(status_col)) {
    flags <- as_flag(dat[[status_col]])
    return(list(
      pass = length(flags) > 0L && all(!is.na(flags)) && all(flags),
      observed = paste0(sum(flags %in% TRUE, na.rm = TRUE), "/", length(flags), " PASS/GO")
    ))
  }
  list(pass = FALSE, observed = "no pass/status column")
}

scoped_gate_table_pass <- function(dat, gate_number, baseline_core_only = FALSE) {
  if (is.null(dat) || !nrow(dat)) {
    return(list(pass = FALSE, observed = "unreadable or empty", selected = integer(), nonblocking = integer()))
  }
  gate_col <- pick_col(dat, c("gate", "stage"))
  status_col <- pick_col(dat, c("pass", "passed", "status", "decision", "result"))
  if (is.null(gate_col) || is.null(status_col)) {
    return(list(pass = FALSE, observed = "no gate/stage or pass/status column", selected = integer(), nonblocking = integer()))
  }
  gate_text <- tolower(trimws(as.character(dat[[gate_col]])))
  gate_rows <- grepl(paste0("gate[ _-]*", gate_number, "([^0-9]|$)|^", gate_number, "$"), gate_text, perl = TRUE)
  if (!any(gate_rows)) {
    return(list(pass = FALSE, observed = paste0("no identifiable Gate ", gate_number, " rows"), selected = integer(), nonblocking = integer()))
  }

  selected <- gate_rows
  nonblocking <- rep(FALSE, nrow(dat))
  if (baseline_core_only) {
    blocking_col <- pick_col(dat, c("blocks_baseline_e0", "blocks_primary", "blocking"))
    scope_col <- pick_col(dat, c("scope", "module", "analysis_scope"))
    check_col <- pick_col(dat, c("check", "check_id", "criterion"))
    detail_col <- pick_col(dat, c("detail", "notes", "reason"))
    scope_text <- paste(
      if (is.null(scope_col)) "" else as.character(dat[[scope_col]]),
      if (is.null(check_col)) "" else as.character(dat[[check_col]]),
      if (is.null(detail_col)) "" else as.character(dat[[detail_col]])
    )
    longitudinal <- grepl("w3|longitudinal|individual[ _-]*change|change[ _-]*score|slope|cross[ _-]*wave|drift", scope_text, ignore.case = TRUE, perl = TRUE)
    if (!is.null(blocking_col)) {
      blocks <- as_flag(dat[[blocking_col]])
      nonblocking <- gate_rows & (blocks %in% FALSE)
      selected <- gate_rows & (blocks %in% TRUE)
    } else if (!is.null(scope_col)) {
      core_scope <- grepl("core|baseline|primary|e0", as.character(dat[[scope_col]]), ignore.case = TRUE, perl = TRUE)
      nonblocking <- gate_rows & !core_scope
      selected <- gate_rows & core_scope
    } else {
      nonblocking <- gate_rows & longitudinal
      selected <- gate_rows & !longitudinal
    }
  }

  flags <- as_flag(dat[[status_col]][selected])
  list(
    pass = any(selected) && all(!is.na(flags)) && all(flags),
    observed = if (!any(selected)) {
      paste0("no blocking core Gate ", gate_number, " rows")
    } else {
      paste0(sum(flags %in% TRUE, na.rm = TRUE), "/", length(flags), " selected Gate ", gate_number, " rows PASS")
    },
    selected = which(selected),
    nonblocking = which(nonblocking)
  )
}

corpus <- function(...) {
  objects <- list(...)
  pieces <- unlist(lapply(objects, function(dat) {
    if (is.null(dat)) return(character())
    c(names(dat), unlist(lapply(dat, as.character), use.names = FALSE))
  }), use.names = FALSE)
  tolower(paste(pieces[!is.na(pieces)], collapse = " | "))
}

has_all_patterns <- function(text, patterns) {
  all(vapply(patterns, function(pattern) grepl(pattern, text, perl = TRUE), logical(1)))
}

check_required_csv <- function(filename, gate, check_id) {
  path <- file.path(results_dir, filename)
  parsed <- safe_csv(path)
  exists_ok <- file.exists(path) && is.null(parsed$error) && !is.null(parsed$data) && nrow(parsed$data) > 0L
  add_check(
    gate, check_id, exists_ok,
    expected = paste0(filename, " exists, is readable, and is non-empty"),
    observed = if (!file.exists(path)) "missing" else if (!is.null(parsed$error)) parsed$error else paste0(nrow(parsed$data), " rows"),
    source = rel(path),
    detail = "Missing upstream output is a recorded FAIL; validator continues."
  )
  if (!is.null(parsed$data)) {
    boundary <- aggregate_boundary(parsed$data)
    add_check(
      "Boundary", paste0(check_id, "_aggregate_only"), boundary$pass,
      expected = "aggregate table without row-level identifiers",
      observed = boundary$detail,
      source = rel(path)
    )
  }
  parsed$data
}

# -----------------------------------------------------------------------------
# Gate 0: frozen contract, reproducibility assets, and manifest integrity.
# -----------------------------------------------------------------------------

spec_path <- file.path(root, "work_v43", "analysis_spec_v43.yml")
output_contract_path <- file.path(root, "work_v43", "output_contract_v43.yml")
spec <- NULL
spec_error <- NULL
if (!requireNamespace("yaml", quietly = TRUE)) {
  spec_error <- "R package 'yaml' is unavailable"
} else if (!file.exists(spec_path)) {
  spec_error <- "analysis specification is missing"
} else {
  spec <- tryCatch(yaml::read_yaml(spec_path), error = function(e) {
    spec_error <<- conditionMessage(e)
    NULL
  })
}
add_check(
  "Gate 0", "analysis_spec_readable", !is.null(spec),
  expected = "readable work_v43/analysis_spec_v43.yml",
  observed = if (is.null(spec)) spec_error else paste0("spec_version=", spec$spec_version),
  source = rel(spec_path)
)
add_check(
  "Gate 0", "analysis_spec_frozen",
  !is.null(spec) &&
    identical(spec$spec_version, "v43_4") &&
    identical(
      spec$status,
      "frozen_post_outcome_execution_ph_design_alias_amendment"
    ) &&
    !is.null(spec$amended_at) &&
    nzchar(as.character(spec$amended_at)) &&
    !is.null(spec$amendment_scope) &&
    grepl(
      "NHANES outcome-model code then executed",
      as.character(spec$amendment_scope),
      fixed = TRUE
    ) &&
    grepl(
      paste0(
        "no NHANES coefficient magnitude, direction, confidence interval, ",
        "P value, window-test result, or primary-model result was inspected"
      ),
      as.character(spec$amendment_scope),
      fixed = TRUE
    ) &&
    grepl(
      "25 coefficients included exactly two non-finite entries",
      as.character(spec$amendment_scope),
      fixed = TRUE
    ) &&
    grepl(
      paste0(
        "archive/v43/charls_20260719T061050_nhanes_20260719T071156_",
        "log_time_ph_failure/"
      ),
      as.character(spec$amendment_scope),
      fixed = TRUE
    ) &&
    grepl(
      "v43_4 removes factor(cycle_label) only from the supportive log-time formula",
      as.character(spec$amendment_scope),
      fixed = TRUE
    ) &&
    grepl(
      "Both cohorts must rerun in full under one new registry",
      as.character(spec$amendment_scope),
      fixed = TRUE
    ) &&
    !is.null(spec$governance$registered_nonestimability_policy) &&
    grepl(
      "primary analyses and all other registered models remain fail-closed",
      as.character(spec$governance$registered_nonestimability_policy),
      fixed = TRUE
    ) &&
    !is.null(spec$governance$nhanes_ph_design_alias_amendment_policy) &&
    grepl(
      "two exactly redundant cycle indicators",
      as.character(spec$governance$nhanes_ph_design_alias_amendment_policy),
      fixed = TRUE
    ) &&
    grepl(
      "singular.ok=FALSE",
      as.character(spec$governance$nhanes_ph_design_alias_amendment_policy),
      fixed = TRUE
    ) &&
    !is.null(spec$governance$time_varying_reference_policy) &&
    grepl(
      "only v43_s3_nhanes_pn_e0_a1 may reference",
      as.character(spec$governance$time_varying_reference_policy),
      fixed = TRUE
    ) &&
    identical(
      spec$nhanes$mortality$time_heterogeneity$supportive_log_time_role,
      paste0(
        "weighted robust coxph one-degree-of-freedom E0-by-log(time) trend ",
        "diagnostic; supportive only, not an omnibus PH test and not a ",
        "replacement for the complex-survey primary or window models"
      )
    ) &&
    grepl(
      "corrected 23-coefficient contract",
      as.character(spec$governance$nhanes_ph_design_alias_amendment_policy),
      fixed = TRUE
    ) &&
    grepl(
      "ties='efron'",
      as.character(
        spec$nhanes$mortality$time_heterogeneity$supportive_formula
      ),
      fixed = TRUE
    ) &&
    identical(
      spec$nhanes$function_health_boundary$older_adult_sensitivity$status,
      "NOT_ESTIMABLE"
    ) &&
    identical(
      unname(as.integer(
        spec$nhanes$function_health_boundary$older_adult_sensitivity$registered_n
      )),
      3346L
    ) &&
    identical(
      unname(as.integer(
        spec$nhanes$function_health_boundary$older_adult_sensitivity$registered_events
      )),
      701L
    ) &&
    identical(
      unname(unlist(
        spec$nhanes$function_health_boundary$older_adult_sensitivity$registry_ids
      )),
      c(
        "v43_s3_nhanes_pn_e0_age60_79_a1",
        "v43_s3_nhanes_pn_e0_age60_79_a2"
      )
    ) &&
    grepl(
      "do not refit the panel",
      as.character(
        spec$nhanes$function_health_boundary$older_adult_sensitivity$model_attempt_policy
      ),
      fixed = TRUE
    ) &&
    identical(
      length(unlist(
        spec$nhanes$function_health_boundary$older_adult_sensitivity$rescue_prohibitions
      )),
      9L
    ) &&
    identical(
      spec$charls$mortality$time_structure$primary_time_basis,
      "factor(end_wave) + offset(log(nominal_years))"
    ) &&
    identical(
      spec$charls$mortality$time_structure$legacy_window_factor_status,
      "prohibited_nonestimable"
    ) &&
    identical(
      sort(unname(unlist(
        spec$charls$mortality$time_structure$legacy_all_event_windows
      ))),
      sort(c("W1_W3", "W1_W4", "W2_W4"))
    ) &&
    identical(
      unname(as.integer(unlist(
        spec$charls$mortality$time_structure$nominal_wave_year_grid
      ))),
      c(2011L, 2013L, 2015L, 2018L, 2020L)
    ),
  expected = paste(
    "v43_4 frozen_post_outcome_execution_ph_design_alias_amendment with a",
    "dated coefficient-result-blind 25-to-23 NHANES supportive-log-time",
    "alias correction, retained age-60-79 NOT_ESTIMABLE rows, and the",
    "retained estimable CHARLS time basis"
  ),
  observed = if (is.null(spec)) {
    "spec unavailable"
  } else {
    paste0(
      "spec_version=", spec$spec_version,
      "; status=", spec$status,
      "; amended_at=", spec$amended_at,
      "; scope=", spec$amendment_scope
    )
  },
  source = rel(spec_path)
)

private_path <- file.path(results_dir, "input_manifest_private_v43.csv")
public_path <- file.path(results_dir, "input_manifest_public_v43.csv")
gate0_path <- file.path(results_dir, "gate0_reproducibility_v43.csv")
environment_path <- file.path(results_dir, "environment_versions_v43.csv")
authorization_registry_path <- file.path(root, "work_v43", "stage3_authorization_hashes_v43.csv")

private <- safe_csv(private_path)
public <- safe_csv(public_path)
gate0 <- safe_csv(gate0_path)
environment <- safe_csv(environment_path)

for (asset in list(
  list(id = "private_manifest", path = private_path, parsed = private),
  list(id = "public_manifest", path = public_path, parsed = public),
  list(id = "gate0_table", path = gate0_path, parsed = gate0),
  list(id = "environment_inventory", path = environment_path, parsed = environment)
)) {
  ok <- file.exists(asset$path) && is.null(asset$parsed$error) &&
    !is.null(asset$parsed$data) && nrow(asset$parsed$data) > 0L
  add_check(
    "Gate 0", paste0(asset$id, "_readable"), ok,
    expected = "exists, readable, non-empty",
    observed = if (!file.exists(asset$path)) "missing" else if (!is.null(asset$parsed$error)) asset$parsed$error else paste0(nrow(asset$parsed$data), " rows"),
    source = rel(asset$path)
  )
}

add_check(
  "Gate 0", "stage3_authorization_registry_absent_during_preliminary_validation",
  !file.exists(authorization_registry_path),
  expected = "final Stage 3 authorization registry does not exist during preliminary Stage 0-2 validation",
  observed = if (file.exists(authorization_registry_path)) "registry already exists" else "registry absent",
  source = rel(authorization_registry_path),
  detail = "The registry may be generated only by the later --phase=authorize freeze after this validator and the no-model preflight both pass."
)

private_dat <- private$data
private_schema <- c("group", "role", "path", "restricted", "exists", "bytes", "mtime_utc", "sha256")
private_schema_ok <- !is.null(private_dat) && all(private_schema %in% names(private_dat))
add_check(
  "Gate 0", "private_manifest_schema", private_schema_ok,
  expected = paste(private_schema, collapse = ", "),
  observed = if (is.null(private_dat)) "unreadable" else paste(names(private_dat), collapse = ", "),
  source = rel(private_path)
)
if (private_schema_ok) {
  exists_flags <- as_flag(private_dat$exists)
  hashes_ok <- grepl("^[0-9a-fA-F]{64}$", private_dat$sha256)
  sizes_ok <- suppressWarnings(as.numeric(private_dat$bytes)) > 0
  add_check(
    "Gate 0", "private_manifest_all_inputs_present",
    all(!is.na(exists_flags)) && all(exists_flags) && all(hashes_ok) && all(sizes_ok, na.rm = FALSE),
    expected = "all entries exist with positive size and SHA-256",
    observed = paste0(
      sum(exists_flags %in% TRUE, na.rm = TRUE), "/", nrow(private_dat), " present; ",
      sum(hashes_ok, na.rm = TRUE), "/", nrow(private_dat), " hashes; ",
      sum(sizes_ok, na.rm = TRUE), "/", nrow(private_dat), " positive sizes"
    ),
    source = rel(private_path)
  )
  spec_rows <- private_dat$role == "analysis_spec"
  spec_hash_ok <- FALSE
  spec_hash_observed <- "analysis_spec manifest row or digest package unavailable"
  if (sum(spec_rows, na.rm = TRUE) == 1L && requireNamespace("digest", quietly = TRUE) && file.exists(spec_path)) {
    current_spec_hash <- digest::digest(file = spec_path, algo = "sha256", serialize = FALSE)
    current_spec_size <- as.numeric(file.info(spec_path)$size)
    recorded_spec_hash <- as.character(private_dat$sha256[spec_rows])
    recorded_spec_size <- suppressWarnings(as.numeric(private_dat$bytes[spec_rows]))
    spec_hash_ok <- identical(tolower(current_spec_hash), tolower(recorded_spec_hash)) &&
      isTRUE(all.equal(current_spec_size, recorded_spec_size))
    spec_hash_observed <- paste0(
      "recorded=", recorded_spec_hash, "; current=", current_spec_hash,
      "; bytes recorded/current=", recorded_spec_size, "/", current_spec_size
    )
  }
  add_check(
    "Gate 0", "analysis_spec_matches_frozen_manifest", spec_hash_ok,
    expected = "current analysis_spec_v43.yml SHA-256 and size exactly match its private-manifest row",
    observed = spec_hash_observed,
    source = paste(rel(spec_path), rel(private_path), sep = "; "),
    detail = "Only the permitted specification file is re-hashed; restricted raw data are not opened by this validator."
  )
}

public_dat <- public$data
public_schema <- c("group", "role", "path_alias", "restricted", "exists", "bytes", "mtime_utc", "sha256")
public_schema_ok <- !is.null(public_dat) && all(public_schema %in% names(public_dat))
add_check(
  "Gate 0", "public_manifest_schema", public_schema_ok,
  expected = paste(public_schema, collapse = ", "),
  observed = if (is.null(public_dat)) "unreadable" else paste(names(public_dat), collapse = ", "),
  source = rel(public_path)
)
if (public_schema_ok) {
  aliases <- as.character(public_dat$path_alias)
  leaked <- grepl("(^/Users/|/Downloads/|derived_sensitive/)", aliases, ignore.case = TRUE)
  restricted <- as_flag(public_dat$restricted)
  restricted_alias_ok <- is.na(restricted) | !restricted | startsWith(aliases, "LOCAL_RESTRICTED/")
  add_check(
    "Gate 0", "public_manifest_deidentified_paths",
    !any(leaked, na.rm = TRUE) && all(restricted_alias_ok),
    expected = "no absolute/restricted local paths; restricted assets use LOCAL_RESTRICTED/",
    observed = paste0(sum(leaked, na.rm = TRUE), " leaked paths; ", sum(!restricted_alias_ok, na.rm = TRUE), " invalid restricted aliases"),
    source = rel(public_path)
  )
}

if (private_schema_ok && public_schema_ok) {
  private_keys <- paste(private_dat$group, private_dat$role, private_dat$sha256, private_dat$bytes, sep = "|")
  public_keys <- paste(public_dat$group, public_dat$role, public_dat$sha256, public_dat$bytes, sep = "|")
  add_check(
    "Gate 0", "private_public_manifest_alignment",
    identical(sort(private_keys), sort(public_keys)),
    expected = "same group/role/hash/size entries",
    observed = paste0(nrow(private_dat), " private vs ", nrow(public_dat), " public entries"),
    source = paste(rel(private_path), rel(public_path), sep = "; ")
  )
}

gate0_eval <- gate_table_pass(gate0$data)
add_check(
  "Gate 0", "gate0_all_checks_pass", gate0_eval$pass,
  expected = "all Stage 0 checks PASS",
  observed = gate0_eval$observed,
  source = rel(gate0_path)
)

if (!is.null(spec)) {
  governance_paths <- c(
    spec_path,
    output_contract_path,
    file.path(root, spec$governance$deviation_log),
    file.path(root, spec$governance$decision_log),
    file.path(root, spec$governance$seed_ledger),
    file.path(root, spec$software$lockfile)
  )
  governance_ok <- file.exists(governance_paths) & file.info(governance_paths)$size > 0
  add_check(
    "Gate 0", "governance_assets_present", all(governance_ok),
    expected = "specification, output contract, deviation log, decision log, seed ledger, and renv lockfile present",
    observed = paste0(sum(governance_ok), "/", length(governance_ok), " present and non-empty"),
    source = paste(vapply(governance_paths, rel, character(1)), collapse = "; ")
  )
  output_contract <- NULL
  output_contract_error <- NULL
  if (file.exists(output_contract_path)) {
    output_contract <- tryCatch(yaml::read_yaml(output_contract_path), error = function(e) {
      output_contract_error <<- conditionMessage(e)
      NULL
    })
  } else {
    output_contract_error <- "file missing"
  }
  sensitive_ledger_ok <- !is.null(output_contract) &&
    identical(output_contract$contract_version, "v43_10") &&
    identical(output_contract$row_level_outputs_outside_derived_sensitive, FALSE) &&
    identical(output_contract$row_level_output_root, "derived_sensitive/v43") &&
    identical(output_contract$sensitive_ledger_contract$allowed_root, "derived_sensitive/v43") &&
    identical(output_contract$sensitive_ledger_contract$publication_export, FALSE) &&
    all(c(
      "participant_join_keys", "frozen_exposure_inputs", "survey_design_inputs",
      "status_construction_inputs", "row_level_covariates_required_for_prespecified_models"
    ) %in% unlist(output_contract$sensitive_ledger_contract$allowed_content)) &&
    all(c(
      "direct_identifiers_outside_derived_sensitive",
      "participant_ids_outside_derived_sensitive",
      "row_level_covariates_outside_derived_sensitive"
    ) %in% unlist(output_contract$forbidden_output_content)) &&
    grepl(
      "not a formal time-varying-effect-compatible",
      as.character(
        output_contract$cohort_output_transaction$
          nhanes_time_diagnostic_mi_limit
      ),
      fixed = TRUE
    ) &&
    grepl(
      "No D1/F or finite-complete-data-df substitution",
      as.character(
        output_contract$cohort_output_transaction$
          joint_test_reference_policy
      ),
      fixed = TRUE
    ) &&
    grepl(
      "exactly seven unique test IDs",
      as.character(
        output_contract$cohort_output_transaction$
          nhanes_time_varying_output_contract
      ),
      fixed = TRUE
    ) &&
    grepl(
      "same-cohort foreign keys",
      as.character(
        output_contract$aggregate_finalization$diagnostic_reference_gate
      ),
      fixed = TRUE
    )
  add_check(
    "Gate 0", "sensitive_ledger_output_contract_scoped", sensitive_ledger_ok,
    expected = "v43_10 scopes row-level ledgers to derived_sensitive/v43 and freezes the TVE-MI limitation, large-sample joint-test reference, exact-seven diagnostic output, and same-cohort reference gate",
    observed = if (is.null(output_contract)) output_contract_error else paste0(
      "contract_version=", output_contract$contract_version,
      "; root=", output_contract$row_level_output_root,
      "; allowed_root=", output_contract$sensitive_ledger_contract$allowed_root,
      "; publication_export=", output_contract$sensitive_ledger_contract$publication_export,
      "; outside-derived-sensitive prohibitions=",
      sum(grepl("outside_derived_sensitive$", unlist(output_contract$forbidden_output_content))),
      "/", length(unlist(output_contract$forbidden_output_content))
    ),
    source = rel(output_contract_path),
    detail = "This resolves the prior literal conflict between a necessary restricted analytic ledger and the no-row-level-export rule."
  )
  env_dat <- environment$data
  package_ok <- FALSE
  observed_packages <- "environment inventory unavailable"
  if (!is.null(env_dat) && all(c("package", "version") %in% names(env_dat))) {
    required_packages <- unique(c("R", unlist(spec$software$stage0_2_packages)))
    idx <- match(required_packages, env_dat$package)
    package_ok <- all(!is.na(idx)) && all(env_dat$version[idx] != "MISSING")
    observed_packages <- paste0(sum(!is.na(idx) & env_dat$version[idx] != "MISSING"), "/", length(required_packages), " required runtimes/packages available")
  }
  add_check(
    "Gate 0", "stage0_2_software_available", package_ok,
    expected = "R plus all frozen stage0_2_packages available",
    observed = observed_packages,
    source = rel(environment_path)
  )
}

# -----------------------------------------------------------------------------
# Gate 1: flow ledgers, event anchors, and machine assertions.
# -----------------------------------------------------------------------------

charls_status_contract_text <- if (is.null(spec)) "" else tolower(spec$charls$mortality$status_contract)
charls_status_contract_ok <- !is.null(spec) &&
  grepl("4.*nonresponse.*known alive|4.*nr, alive", charls_status_contract_text,
        ignore.case = TRUE, perl = TRUE) &&
  grepl("not proxy", charls_status_contract_text, fixed = TRUE) &&
  grepl("0/7/9", charls_status_contract_text, fixed = TRUE) &&
  grepl("tagged .p is proxy", charls_status_contract_text, fixed = TRUE) &&
  grepl("first.*code 6|first.*5/6", charls_status_contract_text,
        ignore.case = TRUE, perl = TRUE)
add_check(
  "Gate 1", "spec_charls_status_code_contract", charls_status_contract_ok,
  expected = "iwstat 4 is nonrespondent known alive (not proxy); 0/7/9/tagged missing are separated; tagged .p is proxy; first visible code 6 is explicitly handled",
  observed = if (is.null(spec)) "spec unavailable" else spec$charls$mortality$status_contract,
  source = rel(spec_path)
)

charls_flow <- check_required_csv("charls_cohort_flow_v43.csv", "Gate 1", "charls_flow_output")
charls_sequential_flow <- check_required_csv("charls_sequential_flow_v43.csv", "Gate 1", "charls_sequential_flow_output")
charls_anchors <- check_required_csv("charls_status_event_anchors_v43.csv", "Gate 1", "charls_anchor_output")
charls_assertions <- check_required_csv("charls_machine_assertions_v43.csv", "Gate 1", "charls_assertions_output")
charls_gate <- check_required_csv("charls_gate1_2_v43.csv", "Gate 1", "charls_gate_output")

charls_flow_required <- c("wave", "core_n", "status_known", "pef_attempted", "pef_valid")
charls_flow_base_schema <- !is.null(charls_flow) && all(charls_flow_required %in% tolower(names(charls_flow)))
charls_flow_unknown_schema <- !is.null(charls_flow) && !is.null(pick_col(charls_flow, c("unknown", "status_unknown")))
charls_flow_simple_status <- !is.null(charls_flow) && all(c("alive", "death") %in% tolower(names(charls_flow)))
charls_flow_detailed_status <- !is.null(charls_flow) &&
  all(c("status_alive", "status_new_death", "status_carried_death") %in% tolower(names(charls_flow)))
charls_flow_schema <- charls_flow_base_schema && charls_flow_unknown_schema &&
  (charls_flow_simple_status || charls_flow_detailed_status)
add_check(
  "Gate 1", "charls_flow_schema", charls_flow_schema,
  expected = paste0(
    paste(charls_flow_required, collapse = ", "),
    ", unknown/status_unknown, plus alive/death or status_alive/status_new_death/status_carried_death"
  ),
  observed = if (is.null(charls_flow)) "unreadable/missing" else paste(names(charls_flow), collapse = ", "),
  source = "results/v43/charls_cohort_flow_v43.csv"
)
if (charls_flow_schema) {
  wave <- col_num(charls_flow, "wave")
  core_n <- col_num(charls_flow, "core_n")
  known <- col_num(charls_flow, "status_known")
  if (charls_flow_detailed_status) {
    alive <- col_num(charls_flow, "status_alive")
    new_death <- col_num(charls_flow, "status_new_death")
    carried_death <- col_num(charls_flow, "status_carried_death")
    death <- new_death + carried_death
  } else {
    alive <- col_num(charls_flow, "alive")
    death <- col_num(charls_flow, "death")
    new_death <- death
    carried_death <- rep(0, length(death))
  }
  unknown <- col_num(charls_flow, c("unknown", "status_unknown"))
  attempted <- col_num(charls_flow, "pef_attempted")
  valid <- col_num(charls_flow, "pef_valid")
  status_counts <- c(core_n, known, alive, new_death, carried_death, unknown)
  measurement_waves <- if (is.null(spec)) c(1, 2, 3) else as.numeric(unlist(spec$charls$waves$measurement))
  measurement_rows <- wave %in% measurement_waves
  measurement_counts <- c(attempted[measurement_rows], valid[measurement_rows])
  off_wave_pef_ok <- all(is.na(attempted[!measurement_rows]) | attempted[!measurement_rows] == 0) &&
    all(is.na(valid[!measurement_rows]) | valid[!measurement_rows] == 0)
  add_check(
    "Gate 1", "charls_flow_counts_valid",
    all(is_whole_nonnegative(status_counts)) && all(is_whole_nonnegative(measurement_counts)) && off_wave_pef_ok,
    expected = "status counts are integer in every wave; PEF counts are integer in W1-W3 and NA/0 outside measurement waves",
    observed = paste0(length(status_counts), " status cells; ", length(measurement_counts), " W1-W3 PEF cells; off-wave PEF valid=", off_wave_pef_ok),
    source = "results/v43/charls_cohort_flow_v43.csv"
  )
  status_identity <- all(abs(known - (alive + new_death + carried_death)) < 1e-8) &&
    all(abs(core_n - (known + unknown)) < 1e-8)
  measurement_identity <- all(valid[measurement_rows] <= attempted[measurement_rows]) &&
    all(attempted[measurement_rows] <= core_n[measurement_rows])
  add_check(
    "Gate 1", "charls_flow_reconstructable", status_identity && measurement_identity,
    expected = "status_known=alive+new_death+carried_death; core_n=status_known+unknown; PEF valid<=attempted<=core_n",
    observed = paste0(
      "max status residual=", max(abs(known - alive - death)), "; max core residual=", max(abs(core_n - known - unknown)),
      "; W1-W3 valid>attempted rows=", sum(valid[measurement_rows] > attempted[measurement_rows]),
      "; W1-W3 attempted>core rows=", sum(attempted[measurement_rows] > core_n[measurement_rows])
    ),
    source = "results/v43/charls_cohort_flow_v43.csv"
  )
  ordered <- length(wave) > 0L && all(diff(wave) > 0)
  cumulative_death <- length(death) < 2L || all(diff(death) >= 0)
  add_check(
    "Gate 1", "charls_flow_monotonic", ordered && cumulative_death,
    expected = "waves strictly ordered and cumulative deaths non-decreasing",
    observed = paste0("waves=", paste(wave, collapse = ","), "; deaths=", paste(death, collapse = ",")),
    source = "results/v43/charls_cohort_flow_v43.csv"
  )
}

charls_sequential_required <- c(
  "step_order", "step_id", "step_label", "n", "excluded_from_previous", "deaths"
)
charls_sequential_schema <- !is.null(charls_sequential_flow) &&
  all(charls_sequential_required %in% tolower(names(charls_sequential_flow)))
add_check(
  "Gate 1", "charls_sequential_flow_schema", charls_sequential_schema,
  expected = paste(charls_sequential_required, collapse = ", "),
  observed = if (is.null(charls_sequential_flow)) "unreadable/missing" else
    paste(names(charls_sequential_flow), collapse = ", "),
  source = "results/v43/charls_sequential_flow_v43.csv"
)
if (charls_sequential_schema) {
  step_order <- col_num(charls_sequential_flow, "step_order")
  step_id <- tolower(col_chr(charls_sequential_flow, "step_id"))
  step_label <- tolower(col_chr(charls_sequential_flow, "step_label"))
  step_n <- col_num(charls_sequential_flow, "n")
  step_excluded <- col_num(charls_sequential_flow, "excluded_from_previous")
  step_deaths <- col_num(charls_sequential_flow, "deaths")
  sequential_counts_ok <- all(is_whole_nonnegative(step_order)) &&
    all(is_whole_nonnegative(step_n)) && all(is_whole_nonnegative(step_deaths)) &&
    all(is.na(step_excluded) | is_whole_nonnegative(step_excluded)) &&
    all(step_deaths <= step_n)
  sequential_identity_ok <- length(step_order) > 0L &&
    !anyDuplicated(step_order) && all(diff(step_order) > 0) &&
    all(diff(step_n) <= 0) && all(diff(step_deaths) <= 0) &&
    (is.na(step_excluded[[1]]) || step_excluded[[1]] == 0) &&
    (length(step_n) == 1L || all(step_excluded[-1] == head(step_n, -1) - tail(step_n, -1)))
  add_check(
    "Gate 1", "charls_sequential_flow_reconstructable",
    sequential_counts_ok && sequential_identity_ok,
    expected = "ordered unique steps; N/events non-increasing; excluded=previous N-current N; deaths<=N",
    observed = paste0(
      nrow(charls_sequential_flow), " rows; N=", paste(step_n, collapse = ","),
      "; deaths=", paste(step_deaths, collapse = ","),
      "; exclusions=", paste(ifelse(is.na(step_excluded), "NA", step_excluded), collapse = ",")
    ),
    source = "results/v43/charls_sequential_flow_v43.csv"
  )
  sequential_text <- paste(step_id, step_label, collapse = " | ")
  sequential_stage_patterns <- c(
    "source|core", "age", "weight", "sex", "raw.*pef|pef.*raw|trial",
    "valid|quality|qc", "vital|mortality|follow"
  )
  add_check(
    "Gate 1", "charls_sequential_flow_required_stages",
    has_all_patterns(sequential_text, sequential_stage_patterns),
    expected = "source, age, positive weight, sex, raw PEF/trial, valid/QC PEF, and vital-status/follow-up stages",
    observed = paste0(
      sum(vapply(sequential_stage_patterns, function(p) grepl(p, sequential_text, perl = TRUE), logical(1))),
      "/", length(sequential_stage_patterns), " required stage concepts found"
    ),
    source = "results/v43/charls_sequential_flow_v43.csv"
  )
}

anchor_schema_ok <- !is.null(charls_anchors) && !is.null(pick_col(charls_anchors, c("anchor", "anchor_id", "analysis_set"))) &&
  !is.null(pick_col(charls_anchors, c("n", "count")))
add_check(
  "Gate 1", "charls_anchor_schema", anchor_schema_ok,
  expected = "anchor/analysis_set and n columns, with interval/event information",
  observed = if (is.null(charls_anchors)) "unreadable/missing" else paste(names(charls_anchors), collapse = ", "),
  source = "results/v43/charls_status_event_anchors_v43.csv"
)
if (anchor_schema_ok) {
  anchor_n <- col_num(charls_anchors, c("n", "count"))
  event_n <- col_num(charls_anchors, c("deaths", "death", "events", "event_n", "n_events"))
  labels <- tolower(paste(
    ifelse(is.null(col_chr(charls_anchors, "analysis_set")), "", col_chr(charls_anchors, "analysis_set")),
    ifelse(is.null(col_chr(charls_anchors, c("anchor", "anchor_id"))), "", col_chr(charls_anchors, c("anchor", "anchor_id"))),
    ifelse(is.null(col_chr(charls_anchors, "interval")), "", col_chr(charls_anchors, "interval"))
  ))
  counts_valid <- all(is_whole_nonnegative(anchor_n))
  if (!is.null(event_n)) counts_valid <- counts_valid && all(is.na(event_n) | is_whole_nonnegative(event_n))
  add_check(
    "Gate 1", "charls_anchor_counts_valid", counts_valid,
    expected = "non-negative integer sample/event counts",
    observed = paste0(length(anchor_n), " anchor rows"),
    source = "results/v43/charls_status_event_anchors_v43.csv"
  )
  baseline_anchor <- any(anchor_n == 12569, na.rm = TRUE)
  death_rows <- grepl("death|died", labels)
  death_candidates <- c(anchor_n[death_rows], if (!is.null(event_n)) event_n else numeric())
  death_anchor <- any(death_candidates == 1681, na.rm = TRUE) ||
    (any(death_rows) && sum(anchor_n[death_rows], na.rm = TRUE) == 1681)
  reconciliation_probe <- safe_csv(file.path(results_dir, "charls_core_source_reconciliation_v43.csv"))$data
  reconciliation_text <- corpus(reconciliation_probe)
  reconciliation_eval <- gate_table_pass(reconciliation_probe)
  historical_reconciled <- reconciliation_eval$pass &&
    grepl("12,?569|12569", reconciliation_text, perl = TRUE) &&
    grepl("1,?681|1681", reconciliation_text, perl = TRUE)
  add_check(
    "Gate 1", "charls_historical_sample_event_anchor", (baseline_anchor && death_anchor) || historical_reconciled,
    expected = "v42 anchor N=12,569/deaths=1,681 reproduced, decomposed, or explicitly reconciled with PASS",
    observed = paste0("N anchor=", baseline_anchor, "; death anchor/decomposition=", death_anchor, "; explicit reconciliation=", historical_reconciled),
    source = "results/v43/charls_status_event_anchors_v43.csv; results/v43/charls_core_source_reconciliation_v43.csv",
    detail = "This is a reconciliation anchor, not a requirement that every v43 QC sensitivity use the v42 sample."
  )
}

charls_assert_eval <- gate_table_pass(charls_assertions)
add_check(
  "Gate 1", "charls_machine_assertions_pass", charls_assert_eval$pass,
  expected = "all machine assertions PASS",
  observed = charls_assert_eval$observed,
  source = "results/v43/charls_machine_assertions_v43.csv"
)
charls_code6_contract_ok <- FALSE
charls_code6_observed <- "assertion absent"
if (!is.null(charls_assertions)) {
  assertion_check_col <- pick_col(charls_assertions, c("check", "check_id", "criterion"))
  assertion_pass_col <- pick_col(charls_assertions, c("pass", "passed", "status"))
  assertion_observed_col <- pick_col(charls_assertions, "observed")
  if (!is.null(assertion_check_col) && !is.null(assertion_pass_col)) {
    assertion_names <- tolower(as.character(charls_assertions[[assertion_check_col]]))
    code6_rows <- grepl("code.?6.*(earlier|prior).*code.?5|first.*code.?6", assertion_names, perl = TRUE)
    code6_flags <- as_flag(charls_assertions[[assertion_pass_col]][code6_rows])
    charls_code6_contract_ok <- any(code6_rows) && length(code6_flags) > 0L &&
      all(!is.na(code6_flags)) && all(code6_flags)
    charls_code6_observed <- if (!any(code6_rows)) {
      "assertion absent"
    } else if (is.null(assertion_observed_col)) {
      paste0(sum(code6_flags %in% TRUE, na.rm = TRUE), "/", length(code6_flags), " PASS")
    } else {
      paste(as.character(charls_assertions[[assertion_observed_col]][code6_rows]), collapse = ",")
    }
  }
}
add_check(
  "Gate 1", "charls_first_code6_event_contract_reported", charls_code6_contract_ok,
  expected = "first visible code 6 without earlier code 5 is explicitly counted/reported and the event-construction assertion passes",
  observed = charls_code6_observed,
  source = "results/v43/charls_machine_assertions_v43.csv",
  detail = "A non-zero count can be legitimate; the required property is explicit handling rather than silently treating code 6 as alive or missing."
)
charls_gate_eval <- scoped_gate_table_pass(charls_gate, gate_number = 1, baseline_core_only = FALSE)
add_check(
  "Gate 1", "charls_gate1_rows_pass", charls_gate_eval$pass,
  expected = "all CHARLS Gate 1 rows PASS",
  observed = charls_gate_eval$observed,
  source = "results/v43/charls_gate1_2_v43.csv"
)

nhanes_flow <- check_required_csv("nhanes_cohort_flow_v43.csv", "Gate 1", "nhanes_flow_output")
nhanes_anchors <- check_required_csv("nhanes_sample_event_anchors_v43.csv", "Gate 1", "nhanes_anchor_output")
nhanes_merge <- check_required_csv("nhanes_merge_audit_v43.csv", "Gate 1", "nhanes_merge_audit_output")
nhanes_horizon <- check_required_csv("nhanes_followup_horizon_audit_v43.csv", "Gate 1", "nhanes_followup_horizon_output")
nhanes_gate1 <- check_required_csv("gate1_nhanes_flow_v43.csv", "Gate 1", "nhanes_gate1_output")

nhanes_flow_required <- c("flow_branch", "step_order", "step_id", "step_label", "n", "excluded_from_previous", "deaths")
nhanes_flow_schema <- !is.null(nhanes_flow) && all(nhanes_flow_required %in% tolower(names(nhanes_flow)))
add_check(
  "Gate 1", "nhanes_flow_schema", nhanes_flow_schema,
  expected = paste(nhanes_flow_required, collapse = ", "),
  observed = if (is.null(nhanes_flow)) "unreadable/missing" else paste(names(nhanes_flow), collapse = ", "),
  source = "results/v43/nhanes_cohort_flow_v43.csv"
)
if (nhanes_flow_schema) {
  branch <- col_chr(nhanes_flow, "flow_branch")
  ord <- col_num(nhanes_flow, "step_order")
  n <- col_num(nhanes_flow, "n")
  excluded <- col_num(nhanes_flow, "excluded_from_previous")
  deaths <- col_num(nhanes_flow, "deaths")
  count_ok <- all(is_whole_nonnegative(n)) && all(is.na(excluded) | is_whole_nonnegative(excluded)) &&
    all(is.na(deaths) | is_whole_nonnegative(deaths)) && all(is.na(deaths) | deaths <= n)
  add_check(
    "Gate 1", "nhanes_flow_counts_valid", count_ok,
    expected = "integer N/exclusions/events; deaths<=N",
    observed = paste0(nrow(nhanes_flow), " flow rows across ", length(unique(branch)), " branches"),
    source = "results/v43/nhanes_cohort_flow_v43.csv"
  )
  branch_checks <- lapply(split(seq_len(nrow(nhanes_flow)), branch), function(idx) {
    idx <- idx[order(ord[idx])]
    nn <- n[idx]
    xx <- excluded[idx]
    dd <- deaths[idx]
    order_ok <- length(unique(ord[idx])) == length(idx) && all(diff(ord[idx]) > 0)
    monotone_n <- length(nn) < 2L || all(diff(nn) <= 0)
    reconstruct <- length(nn) < 2L || all(abs((head(nn, -1L) - tail(nn, -1L)) - tail(xx, -1L)) < 1e-8)
    first_exclusion_ok <- is.na(xx[[1]]) || xx[[1]] == 0
    known_deaths <- dd[!is.na(dd)]
    monotone_deaths <- length(known_deaths) < 2L || all(diff(known_deaths) <= 0)
    c(order_ok = order_ok, monotone_n = monotone_n, reconstruct = reconstruct,
      first_exclusion_ok = first_exclusion_ok, monotone_deaths = monotone_deaths)
  })
  branch_matrix <- do.call(rbind, branch_checks)
  add_check(
    "Gate 1", "nhanes_flow_monotonic_reconstructable", all(branch_matrix),
    expected = "within each branch: unique increasing order, N/events non-increasing, and excluded=previous N-current N",
    observed = paste0(sum(apply(branch_matrix, 1, all)), "/", nrow(branch_matrix), " branches pass every identity"),
    source = "results/v43/nhanes_cohort_flow_v43.csv"
  )
}

nhanes_anchor_required <- c("cycle_label", "cycle", "anchor_id", "n", "deaths")
nhanes_anchor_schema <- !is.null(nhanes_anchors) && all(nhanes_anchor_required %in% tolower(names(nhanes_anchors)))
add_check(
  "Gate 1", "nhanes_anchor_schema", nhanes_anchor_schema,
  expected = paste(nhanes_anchor_required, collapse = ", "),
  observed = if (is.null(nhanes_anchors)) "unreadable/missing" else paste(names(nhanes_anchors), collapse = ", "),
  source = "results/v43/nhanes_sample_event_anchors_v43.csv"
)
if (nhanes_anchor_schema) {
  anchor_n <- col_num(nhanes_anchors, "n")
  anchor_deaths <- col_num(nhanes_anchors, "deaths")
  anchor_ids <- tolower(col_chr(nhanes_anchors, "anchor_id"))
  anchor_counts_ok <- all(is_whole_nonnegative(anchor_n)) &&
    all(is.na(anchor_deaths) | is_whole_nonnegative(anchor_deaths)) &&
    all(is.na(anchor_deaths) | anchor_deaths <= anchor_n)
  add_check(
    "Gate 1", "nhanes_anchor_counts_valid", anchor_counts_ok,
    expected = "integer N/events and deaths<=N",
    observed = paste0(nrow(nhanes_anchors), " anchor rows"),
    source = "results/v43/nhanes_sample_event_anchors_v43.csv"
  )
  anchor_match <- function(n_expected, deaths_expected = NULL, id_pattern = NULL) {
    hit <- anchor_n == n_expected
    if (!is.null(deaths_expected)) hit <- hit & anchor_deaths == deaths_expected
    if (!is.null(id_pattern) && any(grepl(id_pattern, anchor_ids, perl = TRUE))) {
      hit <- hit & grepl(id_pattern, anchor_ids, perl = TRUE)
    }
    any(hit, na.rm = TRUE)
  }
  anchor_results <- c(
    mec_linkage_45_79 = anchor_match(8750, id_pattern = "mec|link|45.*79"),
    safety_excluded = anchor_match(824, id_pattern = "safety.*excl|excl.*safety"),
    safe_target = anchor_match(7926, 1228, "safe.*target|after.*safety"),
    quality_A = anchor_match(6719, 925, "(^|_)a($|_)|a.only|strict"),
    quality_AC = anchor_match(6971, 967, "a.*c|duration"),
    quality_ABC = anchor_match(7083, 989, "a.*b.*c|broad")
  )
  add_check(
    "Gate 1", "nhanes_frozen_sample_event_anchors", all(anchor_results),
    expected = "8750; exclusion 824; 7926/1228; A 6719/925; A+C 6971/967; A/B/C 7083/989",
    observed = paste(names(anchor_results), anchor_results, sep = "=", collapse = "; "),
    source = "results/v43/nhanes_sample_event_anchors_v43.csv",
    detail = "These are frozen read-only feasibility anchors that the raw-XPT flow must reproduce before outcome modeling."
  )
}

nhanes_gate1_eval <- gate_table_pass(nhanes_gate1)
add_check(
  "Gate 1", "nhanes_gate1_rows_pass", nhanes_gate1_eval$pass,
  expected = "all NHANES Gate 1 checks PASS",
  observed = nhanes_gate1_eval$observed,
  source = "results/v43/gate1_nhanes_flow_v43.csv"
)

nhanes_horizon_required <- c(
  "cycle_label", "cycle", "quality_layer", "horizon_months", "n",
  "deaths_total", "deaths_by_horizon", "known_status_fraction",
  "administratively_complete", "prespecified_role"
)
nhanes_horizon_schema <- !is.null(nhanes_horizon) &&
  all(nhanes_horizon_required %in% tolower(names(nhanes_horizon))) && nrow(nhanes_horizon) == 6L
add_check(
  "Gate 1", "nhanes_followup_horizon_schema", nhanes_horizon_schema,
  expected = "6 rows: E/F/G x 60/120 months with N/events/completeness/role",
  observed = if (is.null(nhanes_horizon)) "unreadable/missing" else paste0(nrow(nhanes_horizon), " rows; ", paste(names(nhanes_horizon), collapse = ", ")),
  source = "results/v43/nhanes_followup_horizon_audit_v43.csv"
)
if (nhanes_horizon_schema) {
  horizon_cycle <- toupper(col_chr(nhanes_horizon, "cycle_label"))
  horizon_months <- col_num(nhanes_horizon, "horizon_months")
  horizon_n <- col_num(nhanes_horizon, "n")
  horizon_deaths <- col_num(nhanes_horizon, "deaths_total")
  horizon_deaths_by <- col_num(nhanes_horizon, "deaths_by_horizon")
  horizon_complete <- as_flag(nhanes_horizon[[pick_col(nhanes_horizon, "administratively_complete")]])
  horizon_role <- tolower(col_chr(nhanes_horizon, "prespecified_role"))
  six_cells <- identical(sort(paste(horizon_cycle, horizon_months, sep = "_")), sort(c("E_60", "E_120", "F_60", "F_120", "G_60", "G_120")))
  counts_coherent <- all(is_whole_nonnegative(c(horizon_n, horizon_deaths, horizon_deaths_by))) &&
    all(horizon_deaths_by <= horizon_deaths) && all(horizon_deaths <= horizon_n)
  five_rows <- horizon_months == 60
  ten_e <- horizon_months == 120 & horizon_cycle == "E"
  ten_fg <- horizon_months == 120 & horizon_cycle %in% c("F", "G")
  completeness_ok <- all(horizon_complete[five_rows] %in% TRUE) &&
    all(horizon_complete[ten_e] %in% TRUE) && all(horizon_complete[ten_fg] %in% FALSE)
  role_ok <- all(grepl("5-year.*allowed|5 year.*allowed", horizon_role[five_rows], perl = TRUE)) &&
    all(grepl("10-year.*allowed|10 year.*allowed", horizon_role[ten_e], perl = TRUE)) &&
    all(grepl("prohibit|forbid|not allowed", horizon_role[ten_fg], perl = TRUE))
  add_check(
    "Gate 1", "nhanes_followup_horizon_contract", six_cells && counts_coherent && completeness_ok && role_ok,
    expected = "5y complete/allowed in E,F,G; 10y complete/allowed only in E and explicitly prohibited in F/G",
    observed = paste0(
      "cells=", six_cells, "; coherent counts=", counts_coherent, "; completeness=",
      paste(horizon_cycle, horizon_months, horizon_complete, sep = ":", collapse = ","),
      "; roles valid=", role_ok
    ),
    source = "results/v43/nhanes_followup_horizon_audit_v43.csv",
    detail = "This prevents outcome-dependent 10-year inclusion and enforces the frozen administrative-follow-up boundary."
  )
}

# -----------------------------------------------------------------------------
# Gate 2: frozen measurement rules, aggregate audit outputs, and exposure scale.
# -----------------------------------------------------------------------------

if (!is.null(spec)) {
  charls_range <- unlist(spec$charls$measurement$plausible_range_l_min)
  add_check(
    "Gate 2", "spec_charls_units_and_range",
    identical(as.numeric(charls_range), c(30, 890)) &&
      identical(as.numeric(spec$charls$measurement$observed_floor_l_min), 30) &&
      identical(as.numeric(spec$charls$measurement$observed_ceiling_l_min), 890),
    expected = "PEF in L/min with inclusive plausible range 30-890",
    observed = paste0("range=", paste(charls_range, collapse = "-"), "; floor=", spec$charls$measurement$observed_floor_l_min, "; ceiling=", spec$charls$measurement$observed_ceiling_l_min),
    source = rel(spec_path)
  )
  add_check(
    "Gate 2", "spec_charls_quality_rules",
    identical(as.integer(spec$charls$measurement$minimum_valid_trials_for_repeatability), 2L) &&
      identical(as.numeric(spec$charls$measurement$top_two_repeatability_flag_l_min), 40) &&
      identical(as.integer(spec$charls$measurement$full_effort_code), 1L) &&
      identical(as.integer(spec$charls$measurement$standing_code), 1L) &&
      grepl("maximum", spec$charls$measurement$primary_summary_candidate, ignore.case = TRUE),
    expected = "maximum valid trial; >=2 valid trials; top-two difference 40 L/min; effort=1; standing=1",
    observed = paste0(
      spec$charls$measurement$primary_summary_candidate, "; min trials=", spec$charls$measurement$minimum_valid_trials_for_repeatability,
      "; repeatability=", spec$charls$measurement$top_two_repeatability_flag_l_min,
      "; effort=", spec$charls$measurement$full_effort_code, "; standing=", spec$charls$measurement$standing_code
    ),
    source = rel(spec_path)
  )
  add_check(
    "Gate 2", "spec_charls_e0_contract",
    identical(spec$charls$primary_exposure$id, "E0") &&
      grepl("sex-specific survey-weighted SD", spec$charls$primary_exposure$definition, fixed = TRUE) &&
      grepl("higher means lower PEF", spec$charls$primary_exposure$direction, fixed = TRUE) &&
      grepl("100 L/min", spec$charls$primary_exposure$physical_scale, fixed = TRUE),
    expected = "outcome-blind lower raw PEF, sex-specific weighted SD; per 100 L/min sensitivity",
    observed = paste(spec$charls$primary_exposure$definition, spec$charls$primary_exposure$physical_scale, sep = "; "),
    source = rel(spec_path)
  )
  add_check(
    "Gate 2", "spec_nhanes_unit_conversion",
    identical(spec$nhanes$measurement$unit_source, "mL/s") &&
      identical(spec$nhanes$measurement$unit_analysis, "L/min") &&
      isTRUE(all.equal(as.numeric(spec$nhanes$measurement$conversion_multiplier), 0.06)),
    expected = "SPXNPEF mL/s x 0.06 = L/min",
    observed = paste0(spec$nhanes$measurement$unit_source, " x ", spec$nhanes$measurement$conversion_multiplier, " -> ", spec$nhanes$measurement$unit_analysis),
    source = rel(spec_path)
  )
  nhanes_quality_text <- paste(
    spec$nhanes$measurement$primary_pef_quality,
    spec$nhanes$measurement$duration_relaxed_pef_sensitivity,
    spec$nhanes$measurement$broad_pef_sensitivity,
    sep = " | "
  )
  add_check(
    "Gate 2", "spec_nhanes_quality_layers",
    grepl("A only", spec$nhanes$measurement$primary_pef_quality, fixed = TRUE) &&
      grepl("A or C", spec$nhanes$measurement$duration_relaxed_pef_sensitivity, fixed = TRUE) &&
      grepl("A/B/C", spec$nhanes$measurement$broad_pef_sensitivity, fixed = TRUE) &&
      grepl("A/B/C", spec$nhanes$measurement$full_spirometry_quality, fixed = TRUE) &&
      grepl("A/B", spec$nhanes$measurement$full_spirometry_quality, fixed = TRUE),
    expected = "PEF primary A-only; A+C duration-relaxed; A/B/C broad; full spirometry A/B/C with A/B strict",
    observed = paste(nhanes_quality_text, spec$nhanes$measurement$full_spirometry_quality, sep = " | "),
    source = rel(spec_path)
  )
  add_check(
    "Gate 2", "spec_nhanes_scale_reuse_and_acc3_sensitivity",
    isTRUE(spec$nhanes$measurement$scale_reuse_across_quality_layers) &&
      grepl("A-only", spec$nhanes$measurement$primary_scale_reference, fixed = TRUE) &&
      grepl("SPDNACC", spec$nhanes$measurement$additional_pef_quality_sensitivity, fixed = TRUE) &&
      grepl(">=3|at least 3", spec$nhanes$measurement$additional_pef_quality_sensitivity, perl = TRUE) &&
      grepl("same A-only constants are reused", spec$nhanes$primary_exposure$definition, fixed = TRUE),
    expected = "A-only mean/SD constants reused unchanged across A+C/A/B/C; A-only+SPDNACC>=3 is prespecified sensitivity",
    observed = paste0(
      "scale_reuse=", spec$nhanes$measurement$scale_reuse_across_quality_layers,
      "; reference=", spec$nhanes$measurement$primary_scale_reference,
      "; added sensitivity=", spec$nhanes$measurement$additional_pef_quality_sensitivity
    ),
    source = rel(spec_path)
  )
  add_check(
    "Gate 2", "spec_nhanes_tail_retention_rule",
    grepl("above 900", spec$nhanes$measurement$tail_rule, fixed = TRUE) &&
      grepl("remain", spec$nhanes$measurement$tail_rule, fixed = TRUE) &&
      grepl("spline", spec$nhanes$measurement$tail_rule, fixed = TRUE) &&
      grepl("influence", spec$nhanes$measurement$tail_rule, fixed = TRUE) &&
      grepl("rather than post hoc deletion", spec$nhanes$measurement$tail_rule, fixed = TRUE),
    expected = "official >900 L/min values retained; tails handled by spline/influence sensitivity, not post-hoc deletion",
    observed = spec$nhanes$measurement$tail_rule,
    source = rel(spec_path)
  )
  add_check(
    "Gate 2", "spec_nhanes_target_population",
    identical(as.integer(spec$nhanes$age_min), 45L) && identical(as.integer(spec$nhanes$age_max), 79L) &&
      identical(as.integer(spec$nhanes$structural_missing_age_gt), 79L) && isTRUE(spec$nhanes$design$domain_after_design),
    expected = "age 45-79; >79 structural missing; survey domain defined after full design",
    observed = paste0("age=", spec$nhanes$age_min, "-", spec$nhanes$age_max, "; structural >", spec$nhanes$structural_missing_age_gt, "; domain_after_design=", spec$nhanes$design$domain_after_design),
    source = rel(spec_path)
  )
  add_check(
    "Gate 2", "spec_nhanes_e0_contract",
    identical(spec$nhanes$primary_exposure$id, "E0") &&
      grepl("sex-specific survey-weighted SD", spec$nhanes$primary_exposure$definition, fixed = TRUE) &&
      grepl("higher means lower PEF", spec$nhanes$primary_exposure$direction, fixed = TRUE) &&
      grepl("100 L/min", spec$nhanes$primary_exposure$physical_scale, fixed = TRUE),
    expected = "lower raw PEF, sex-specific weighted SD; per 100 L/min sensitivity",
    observed = paste(spec$nhanes$primary_exposure$definition, spec$nhanes$primary_exposure$physical_scale, sep = "; "),
    source = rel(spec_path)
  )
}

charls_contract <- check_required_csv("charls_measurement_contract_v43.csv", "Gate 2", "charls_measurement_contract_output")
charls_trial_qc <- check_required_csv("charls_pef_trial_qc_v43.csv", "Gate 2", "charls_trial_qc_output")
charls_reliability <- check_required_csv("charls_pef_reliability_v43.csv", "Gate 2", "charls_reliability_output")
charls_drift <- check_required_csv("charls_cross_wave_drift_v43.csv", "Gate 2", "charls_cross_wave_drift_output")
charls_reconciliation <- check_required_csv("charls_core_source_reconciliation_v43.csv", "Gate 2", "charls_source_reconciliation_output")
charls_e0 <- check_required_csv("charls_e0_scale_v43.csv", "Gate 2", "charls_e0_scale_output")
charls_rowmax <- check_required_csv("charls_reported_rowmax_reconciliation_v43.csv", "Gate 2", "charls_rowmax_reconciliation_output")

charls_contract_eval <- gate_table_pass(charls_contract)
add_check(
  "Gate 2", "charls_measurement_contract_pass", charls_contract_eval$pass,
  expected = "all locked measurement-contract rows PASS",
  observed = charls_contract_eval$observed,
  source = "results/v43/charls_measurement_contract_v43.csv"
)
charls_measurement_text <- corpus(charls_contract, charls_trial_qc, charls_reliability, charls_drift, charls_reconciliation, charls_e0)
charls_rule_patterns <- c("l/min|l.min", "(^|[^0-9])30([^0-9]|$)", "(^|[^0-9])890([^0-9]|$)", "(^|[^0-9])40([^0-9]|$)", "993", "999", "rowmax|maximum|max of valid")
add_check(
  "Gate 2", "charls_aggregate_rules_documented",
  nzchar(charls_measurement_text) && has_all_patterns(charls_measurement_text, charls_rule_patterns),
  expected = "aggregate audit documents L/min, 30/890 bounds, 40 repeatability flag, 993/999 exclusion, and row maximum",
  observed = paste0(sum(vapply(charls_rule_patterns, function(p) grepl(p, charls_measurement_text, perl = TRUE), logical(1))), "/", length(charls_rule_patterns), " rule tokens found"),
  source = "CHARLS Stage 1-2 aggregate outputs"
)

charls_source_identity_ok <- FALSE
charls_source_identity_observed <- "source reconciliation unreadable"
if (!is.null(charls_reconciliation)) {
  source_check_col <- pick_col(charls_reconciliation, c("check", "check_id", "criterion"))
  source_pass_col <- pick_col(charls_reconciliation, c("pass", "passed", "status"))
  source_observed_col <- pick_col(charls_reconciliation, "observed")
  if (!is.null(source_check_col) && !is.null(source_pass_col)) {
    source_names <- tolower(as.character(charls_reconciliation[[source_check_col]]))
    required_source_checks <- c("raw_core_field_communityid", "core_participant_id_equals_raw_id")
    source_idx <- match(required_source_checks, source_names)
    source_flags <- if (anyNA(source_idx)) logical() else
      as_flag(charls_reconciliation[[source_pass_col]][source_idx])
    observed_zero <- TRUE
    if (!is.null(source_observed_col) && !anyNA(source_idx)) {
      observed_zero <- all(suppressWarnings(as.numeric(charls_reconciliation[[source_observed_col]][source_idx])) == 0)
    }
    charls_source_identity_ok <- !anyNA(source_idx) && length(source_flags) == 2L &&
      all(!is.na(source_flags)) && all(source_flags) && observed_zero
    charls_source_identity_observed <- if (anyNA(source_idx)) {
      paste0("missing checks: ", paste(required_source_checks[is.na(source_idx)], collapse = ", "))
    } else {
      paste0(
        paste(required_source_checks, collapse = ", "), "; flags=",
        paste(source_flags, collapse = ","),
        if (is.null(source_observed_col)) "" else paste0(
          "; mismatches=", paste(charls_reconciliation[[source_observed_col]][source_idx], collapse = ",")
        )
      )
    }
  }
}
add_check(
  "Gate 2", "charls_source_identity_fields_reconciled", charls_source_identity_ok,
  expected = "communityID and participant_id/raw ID aggregate reconciliations are present, PASS, and have zero mismatches",
  observed = charls_source_identity_observed,
  source = "results/v43/charls_core_source_reconciliation_v43.csv"
)

charls_prefilter_codes_ok <- FALSE
charls_prefilter_codes_observed <- "trial QC unreadable"
if (!is.null(charls_trial_qc)) {
  trial_metric_col <- pick_col(charls_trial_qc, c("metric", "check", "criterion"))
  trial_wave_col <- pick_col(charls_trial_qc, "wave")
  trial_value_col <- pick_col(charls_trial_qc, c("value", "observed", "n"))
  if (!is.null(trial_metric_col) && !is.null(trial_wave_col) && !is.null(trial_value_col)) {
    trial_metric <- tolower(as.character(charls_trial_qc[[trial_metric_col]]))
    prefilter_rows <- grepl("literal_?993.*999.*prefilter|993.*999.*prefilter", trial_metric, perl = TRUE)
    prefilter_waves <- toupper(as.character(charls_trial_qc[[trial_wave_col]][prefilter_rows]))
    prefilter_values <- suppressWarnings(as.numeric(charls_trial_qc[[trial_value_col]][prefilter_rows]))
    charls_prefilter_codes_ok <- sum(prefilter_rows) == 3L &&
      setequal(prefilter_waves, c("W1", "W2", "W3")) &&
      all(is.finite(prefilter_values)) && all(prefilter_values == 0)
    charls_prefilter_codes_observed <- paste0(
      sum(prefilter_rows), " rows; waves=", paste(prefilter_waves, collapse = ","),
      "; values=", paste(prefilter_values, collapse = ",")
    )
  }
}
add_check(
  "Gate 2", "charls_993_999_checked_before_range_filter", charls_prefilter_codes_ok,
  expected = "one pre-filter 993/999 audit row for each W1-W3, all with zero literal codes after Harmonized mapping",
  observed = charls_prefilter_codes_observed,
  source = "results/v43/charls_pef_trial_qc_v43.csv",
  detail = "This check prevents a tautological audit performed only after values outside 30-890 L/min have already been removed."
)

charls_rowmax_ok <- FALSE
charls_rowmax_observed <- "rowmax reconciliation unreadable"
if (!is.null(charls_rowmax)) {
  rowmax_wave_col <- pick_col(charls_rowmax, "wave")
  mismatch_col <- pick_col(charls_rowmax, "both_nonmissing_mismatch")
  rowmax_only_col <- pick_col(charls_rowmax, "rowmax_only")
  reported_only_col <- pick_col(charls_rowmax, "reported_only")
  if (!is.null(rowmax_wave_col) && !is.null(mismatch_col) &&
      !is.null(rowmax_only_col) && !is.null(reported_only_col)) {
    rowmax_wave <- toupper(as.character(charls_rowmax[[rowmax_wave_col]]))
    mismatch <- suppressWarnings(as.numeric(charls_rowmax[[mismatch_col]]))
    rowmax_only <- suppressWarnings(as.numeric(charls_rowmax[[rowmax_only_col]]))
    reported_only <- suppressWarnings(as.numeric(charls_rowmax[[reported_only_col]]))
    idx <- match(c("W1", "W2", "W3"), rowmax_wave)
    charls_rowmax_ok <- !anyNA(idx) && nrow(charls_rowmax) == 3L &&
      all(mismatch[idx] == 0) && all(reported_only[idx] == 0) &&
      identical(as.numeric(rowmax_only[idx]), c(0, 0, 14))
    charls_rowmax_observed <- if (anyNA(idx)) {
      paste0("waves=", paste(rowmax_wave, collapse = ","))
    } else {
      paste0(
        "mismatch=", paste(mismatch[idx], collapse = ","),
        "; rowmax_only=", paste(rowmax_only[idx], collapse = ","),
        "; reported_only=", paste(reported_only[idx], collapse = ",")
      )
    }
  }
}
add_check(
  "Gate 2", "charls_reported_best_rowmax_reconciliation", charls_rowmax_ok,
  expected = "W1-W3 both-present mismatches 0/0/0; rowmax-only 0/0/14; reported-only 0/0/0",
  observed = charls_rowmax_observed,
  source = "results/v43/charls_reported_rowmax_reconciliation_v43.csv"
)

charls_reliability_text <- corpus(charls_reliability)
charls_reliability_methods_ok <- nzchar(charls_reliability_text) &&
  grepl("icc\\(a,?1\\)|icc\\(2,?1\\)|absolute.agreement", charls_reliability_text, perl = TRUE) &&
  grepl("icc\\(c,?1\\)|icc\\(3,?1\\)|consistency", charls_reliability_text, perl = TRUE) &&
  grepl("agreement", charls_reliability_text, fixed = TRUE) &&
  grepl("consistency", charls_reliability_text, fixed = TRUE)
add_check(
  "Gate 2", "charls_reliability_agreement_consistency_separated", charls_reliability_methods_ok,
  expected = "same-session audit reports absolute-agreement ICC(A,1)/ICC(2,1), consistency ICC(C,1)/ICC(3,1), and distinctly named agreement/consistency error metrics",
  observed = if (!nzchar(charls_reliability_text)) "missing/unreadable" else paste0(
    "absolute ICC=", grepl("icc\\(a,?1\\)|icc\\(2,?1\\)|absolute.agreement", charls_reliability_text, perl = TRUE),
    "; consistency ICC=", grepl("icc\\(c,?1\\)|icc\\(3,?1\\)|consistency", charls_reliability_text, perl = TRUE),
    "; agreement token=", grepl("agreement", charls_reliability_text, fixed = TRUE),
    "; consistency token=", grepl("consistency", charls_reliability_text, fixed = TRUE)
  ),
  source = "results/v43/charls_pef_reliability_v43.csv",
  detail = "sqrt(MSE) is a consistency/residual SEM; an absolute-agreement SEM must also incorporate the trial-position component when that component is treated as random."
)
charls_reliability_formula_ok <- FALSE
charls_reliability_formula_observed <- "reliability table unreadable or required columns absent"
if (!is.null(charls_reliability)) {
  reliability_required <- c(
    "metric_type", "n", "trials_per_person", "icc_absolute_a1", "icc_consistency_c1",
    "ms_subject", "ms_trial", "ms_error", "trial_systematic_variance_l_min2",
    "sem_absolute_l_min", "sem_consistency_l_min",
    "repeatability_coefficient_absolute_l_min",
    "repeatability_coefficient_consistency_l_min",
    "smallest_detectable_difference_l_min",
    "smallest_detectable_difference_consistency_l_min"
  )
  if (all(reliability_required %in% tolower(names(charls_reliability)))) {
    same <- tolower(col_chr(charls_reliability, "metric_type")) == "same_session_reliability"
    n <- col_num(charls_reliability, "n")[same]
    k <- col_num(charls_reliability, "trials_per_person")[same]
    ms_subject <- col_num(charls_reliability, "ms_subject")[same]
    ms_trial <- col_num(charls_reliability, "ms_trial")[same]
    ms_error <- col_num(charls_reliability, "ms_error")[same]
    icc_a <- col_num(charls_reliability, "icc_absolute_a1")[same]
    icc_c <- col_num(charls_reliability, "icc_consistency_c1")[same]
    trial_var <- col_num(charls_reliability, "trial_systematic_variance_l_min2")[same]
    sem_a <- col_num(charls_reliability, "sem_absolute_l_min")[same]
    sem_c <- col_num(charls_reliability, "sem_consistency_l_min")[same]
    rc_a <- col_num(charls_reliability, "repeatability_coefficient_absolute_l_min")[same]
    rc_c <- col_num(charls_reliability, "repeatability_coefficient_consistency_l_min")[same]
    sdd_a <- col_num(charls_reliability, "smallest_detectable_difference_l_min")[same]
    sdd_c <- col_num(charls_reliability, "smallest_detectable_difference_consistency_l_min")[same]
    expected_icc_a <- (ms_subject - ms_error) /
      (ms_subject + (k - 1) * ms_error + k * (ms_trial - ms_error) / n)
    expected_icc_c <- (ms_subject - ms_error) /
      (ms_subject + (k - 1) * ms_error)
    expected_trial_var <- pmax((ms_trial - ms_error) / n, 0)
    expected_sem_a <- sqrt(ms_error + expected_trial_var)
    expected_sem_c <- sqrt(ms_error)
    close <- function(x, y) all(is.finite(x) & is.finite(y) &
      abs(x - y) <= 1e-8 * pmax(1, abs(x), abs(y)))
    charls_reliability_formula_ok <- length(n) == 6L &&
      close(icc_a, expected_icc_a) && close(icc_c, expected_icc_c) &&
      close(trial_var, expected_trial_var) &&
      close(sem_a, expected_sem_a) && close(sem_c, expected_sem_c) &&
      close(rc_a, 1.96 * sqrt(2) * expected_sem_a) &&
      close(rc_c, 1.96 * sqrt(2) * expected_sem_c) &&
      close(sdd_a, 1.96 * sqrt(2) * expected_sem_a) &&
      close(sdd_c, 1.96 * sqrt(2) * expected_sem_c)
    charls_reliability_formula_observed <- paste0(
      length(n), " same-session rows; max |ICC(A)-formula|=",
      format(max(abs(icc_a - expected_icc_a)), scientific = TRUE),
      "; max |ICC(C)-formula|=", format(max(abs(icc_c - expected_icc_c)), scientific = TRUE),
      "; max |SEM(A)-formula|=", format(max(abs(sem_a - expected_sem_a)), scientific = TRUE),
      "; max |SEM(C)-formula|=", format(max(abs(sem_c - expected_sem_c)), scientific = TRUE)
    )
  }
}
add_check(
  "Gate 2", "charls_reliability_formulas_reconstruct", charls_reliability_formula_ok,
  expected = "six W1-W3 same-session rows exactly reconstruct ICC(A,1), ICC(C,1), trial variance, agreement/consistency SEM, RC95 and SDD95",
  observed = charls_reliability_formula_observed,
  source = "results/v43/charls_pef_reliability_v43.csv"
)
charls_e0_text <- corpus(charls_e0)
add_check(
  "Gate 2", "charls_e0_scale_frozen",
  nzchar(charls_e0_text) && has_all_patterns(charls_e0_text, c("sex", "sd|standard", "higher", "lower", "l/min|l.min")),
  expected = "sex-specific weighted-SD E0 scale and higher-means-lower-PEF direction recorded; per-100 scale remains locked in spec",
  observed = if (!nzchar(charls_e0_text)) "missing/unreadable" else "E0 aggregate inspected",
  source = "results/v43/charls_e0_scale_v43.csv"
)

nhanes_contract <- check_required_csv("nhanes_measurement_contract_v43.csv", "Gate 2", "nhanes_measurement_contract_output")
nhanes_pef_quality <- check_required_csv("nhanes_pef_quality_v43.csv", "Gate 2", "nhanes_pef_quality_output")
nhanes_spiro_quality <- check_required_csv("nhanes_spirometry_quality_v43.csv", "Gate 2", "nhanes_spirometry_quality_output")
nhanes_status_comment <- check_required_csv("nhanes_status_comment_v43.csv", "Gate 2", "nhanes_status_comment_output")
nhanes_safety <- check_required_csv("nhanes_safety_reasons_v43.csv", "Gate 2", "nhanes_safety_reasons_output")
nhanes_summary <- check_required_csv("nhanes_measurement_summary_v43.csv", "Gate 2", "nhanes_measurement_summary_output")
nhanes_correlations <- check_required_csv("nhanes_measurement_correlations_v43.csv", "Gate 2", "nhanes_measurement_correlations_output")
nhanes_anomalies <- check_required_csv("nhanes_measurement_anomalies_v43.csv", "Gate 2", "nhanes_measurement_anomalies_output")
nhanes_design <- check_required_csv("nhanes_survey_design_audit_v43.csv", "Gate 2", "nhanes_design_audit_output")
nhanes_observation_contrast <- check_required_csv("nhanes_pef_observation_contrast_v43.csv", "Gate 2", "nhanes_observation_contrast_output")
nhanes_common_sample <- check_required_csv("nhanes_common_sample_audit_v43.csv", "Gate 2", "nhanes_common_sample_output")
nhanes_e0 <- check_required_csv("nhanes_e0_scale_v43.csv", "Gate 2", "nhanes_e0_scale_output")
nhanes_function_routing <- check_required_csv("nhanes_function_routing_audit_v43.csv", "Gate 2", "nhanes_function_routing_output")
nhanes_gate2 <- check_required_csv("gate2_nhanes_measurement_v43.csv", "Gate 2", "nhanes_gate2_output")

nhanes_measurement_text <- corpus(
  nhanes_contract, nhanes_pef_quality, nhanes_spiro_quality, nhanes_status_comment,
  nhanes_safety, nhanes_summary, nhanes_correlations, nhanes_anomalies,
  nhanes_design, nhanes_observation_contrast, nhanes_common_sample, nhanes_e0,
  nhanes_function_routing
)
unit_patterns <- c("spxnpef", "ml/s|ml.s", "l/min|l.min", "0\\.06")
add_check(
  "Gate 2", "nhanes_aggregate_unit_conversion_documented",
  nzchar(nhanes_measurement_text) && has_all_patterns(nhanes_measurement_text, unit_patterns),
  expected = "SPXNPEF mL/s x0.06 to L/min documented in aggregate audit",
  observed = paste0(sum(vapply(unit_patterns, function(p) grepl(p, nhanes_measurement_text, perl = TRUE), logical(1))), "/", length(unit_patterns), " unit tokens found"),
  source = "NHANES Stage 1-2 aggregate outputs"
)
quality_patterns <- c("a.only|a only|strict", "a.?[+/]|a or c|duration", "a.?[/].?b.?[/].?c|broad")
add_check(
  "Gate 2", "nhanes_aggregate_quality_layers_documented",
  nzchar(nhanes_measurement_text) && has_all_patterns(nhanes_measurement_text, quality_patterns),
  expected = "A-only, A+C, and A/B/C PEF layers are separately documented",
  observed = paste0(sum(vapply(quality_patterns, function(p) grepl(p, nhanes_measurement_text, perl = TRUE), logical(1))), "/", length(quality_patterns), " quality-layer tokens found"),
  source = "NHANES Stage 1-2 aggregate outputs"
)
add_check(
  "Gate 2", "nhanes_acc3_quality_sensitivity_documented",
  nzchar(nhanes_measurement_text) &&
    grepl("spdnacc", nhanes_measurement_text, perl = TRUE) &&
    grepl(">= ?3|at least 3|3 acceptable", nhanes_measurement_text, perl = TRUE),
  expected = "A-only plus SPDNACC>=3 acceptable-curves sensitivity is explicitly documented",
  observed = paste0(
    "SPDNACC token=", grepl("spdnacc", nhanes_measurement_text, perl = TRUE),
    "; >=3 rule=", grepl(">= ?3|at least 3|3 acceptable", nhanes_measurement_text, perl = TRUE)
  ),
  source = "NHANES Stage 1-2 aggregate outputs"
)
acc3_anchor_ok <- FALSE
acc3_observed <- "PEF quality table missing required pooled rows"
if (!is.null(nhanes_pef_quality) && all(c("cycle_label", "layer_id", "n", "deaths") %in% tolower(names(nhanes_pef_quality)))) {
  q_cycle <- toupper(col_chr(nhanes_pef_quality, "cycle_label"))
  q_layer <- tolower(col_chr(nhanes_pef_quality, "layer_id"))
  q_n <- col_num(nhanes_pef_quality, "n")
  q_deaths <- col_num(nhanes_pef_quality, "deaths")
  q_a <- q_cycle == "ALL" & q_layer == "pef_a_only"
  q_acc3 <- q_cycle == "ALL" & q_layer == "pef_a_acc3"
  acc3_anchor_ok <- sum(q_a) == 1L && sum(q_acc3) == 1L &&
    q_n[q_a] == 6719 && q_deaths[q_a] == 925 &&
    q_n[q_acc3] == 6634 && q_deaths[q_acc3] == 905 &&
    (q_n[q_a] - q_n[q_acc3]) == 85 && (q_deaths[q_a] - q_deaths[q_acc3]) == 20
  acc3_observed <- paste0(
    "A-only=", q_n[q_a], "/", q_deaths[q_a], "; A+ACC>=3=", q_n[q_acc3], "/", q_deaths[q_acc3],
    "; excluded difference=", q_n[q_a] - q_n[q_acc3], "/", q_deaths[q_a] - q_deaths[q_acc3]
  )
}
add_check(
  "Gate 2", "nhanes_acc3_quality_sensitivity_anchor", acc3_anchor_ok,
  expected = "A-only=6719/925; A-only+SPDNACC>=3=6634/905; difference=85/20",
  observed = acc3_observed,
  source = "results/v43/nhanes_pef_quality_v43.csv"
)

tail_anchor_ok <- FALSE
tail_observed <- "measurement anomaly table missing required pooled tail row"
if (!is.null(nhanes_anomalies) && all(c("cycle_label", "anomaly_id", "n", "deaths", "hard_assertion") %in% tolower(names(nhanes_anomalies)))) {
  a_cycle <- toupper(col_chr(nhanes_anomalies, "cycle_label"))
  a_id <- tolower(col_chr(nhanes_anomalies, "anomaly_id"))
  a_n <- col_num(nhanes_anomalies, "n")
  a_deaths <- col_num(nhanes_anomalies, "deaths")
  a_hard <- as_flag(nhanes_anomalies[[pick_col(nhanes_anomalies, "hard_assertion")]])
  tail_row <- a_cycle == "ALL" & a_id == "pef_above_900"
  tail_anchor_ok <- sum(tail_row) == 1L && a_n[tail_row] == 5 && a_deaths[tail_row] == 0 && a_hard[tail_row] %in% FALSE
  tail_observed <- paste0("pooled >900 L/min=", a_n[tail_row], "/", a_deaths[tail_row], "; hard_assertion=", a_hard[tail_row])
}
add_check(
  "Gate 2", "nhanes_tail_values_retained_as_soft_flag", tail_anchor_ok,
  expected = "5 official-quality PEF >900 L/min values, 0 deaths, descriptive soft flag (not hard exclusion)",
  observed = tail_observed,
  source = "results/v43/nhanes_measurement_anomalies_v43.csv"
)

observation_required <- c("cycle_label", "cycle", "observation_group", "n", "deaths", "weighted_population", "weighted_death_fraction")
observation_schema <- !is.null(nhanes_observation_contrast) &&
  all(observation_required %in% tolower(names(nhanes_observation_contrast))) && nrow(nhanes_observation_contrast) == 8L
add_check(
  "Gate 2", "nhanes_observation_contrast_schema", observation_schema,
  expected = "8 rows: ALL/E/F/G x A-only observed/not-A-only with N, deaths, weighted population and death fraction",
  observed = if (is.null(nhanes_observation_contrast)) "unreadable/missing" else paste0(nrow(nhanes_observation_contrast), " rows; ", paste(names(nhanes_observation_contrast), collapse = ", ")),
  source = "results/v43/nhanes_pef_observation_contrast_v43.csv"
)
if (observation_schema) {
  obs_cycle <- toupper(col_chr(nhanes_observation_contrast, "cycle_label"))
  obs_group <- tolower(col_chr(nhanes_observation_contrast, "observation_group"))
  obs_n <- col_num(nhanes_observation_contrast, "n")
  obs_deaths <- col_num(nhanes_observation_contrast, "deaths")
  obs_fraction <- col_num(nhanes_observation_contrast, "weighted_death_fraction")
  pooled_observed <- obs_cycle == "ALL" & grepl("a-only.*observed", obs_group, perl = TRUE)
  pooled_not_a <- obs_cycle == "ALL" & grepl("not.*a-only", obs_group, perl = TRUE)
  cells_ok <- identical(sort(paste(obs_cycle, ifelse(grepl("not.*a-only", obs_group, perl = TRUE), "not_a", "observed"), sep = "_")),
                        sort(as.vector(outer(c("ALL", "E", "F", "G"), c("observed", "not_a"), paste, sep = "_"))))
  anchor_ok <- sum(pooled_observed) == 1L && sum(pooled_not_a) == 1L &&
    obs_n[pooled_observed] == 6719 && obs_deaths[pooled_observed] == 925 &&
    obs_n[pooled_not_a] == 1207 && obs_deaths[pooled_not_a] == 303
  contrast_direction <- sum(pooled_observed) == 1L && sum(pooled_not_a) == 1L &&
    all(is.finite(obs_fraction)) &&
    isTRUE(obs_fraction[pooled_not_a] > obs_fraction[pooled_observed])
  add_check(
    "Gate 2", "nhanes_observation_contrast_anchor", cells_ok && anchor_ok && contrast_direction,
    expected = "pooled A-only observed=6719/925; not-A-only=1207/303; weighted death fraction higher in not-A-only",
    observed = paste0(
      "cells=", cells_ok, "; observed=", obs_n[pooled_observed], "/", obs_deaths[pooled_observed],
      " (", signif(obs_fraction[pooled_observed], 4), "); not-A=", obs_n[pooled_not_a], "/", obs_deaths[pooled_not_a],
      " (", signif(obs_fraction[pooled_not_a], 4), ")"
    ),
    source = "results/v43/nhanes_pef_observation_contrast_v43.csv",
    detail = "This is a selection/estimand boundary, not an outcome-model result and not a reason to impute structurally excluded participants."
  )
}

common_required <- c("sample_id", "definition", "n", "deaths")
common_schema <- !is.null(nhanes_common_sample) &&
  all(common_required %in% tolower(names(nhanes_common_sample))) && nrow(nhanes_common_sample) == 3L
add_check(
  "Gate 2", "nhanes_common_sample_schema", common_schema,
  expected = "3 rows for A-only, spirometry ABC, and their measurement-only intersection",
  observed = if (is.null(nhanes_common_sample)) "unreadable/missing" else paste0(nrow(nhanes_common_sample), " rows; ", paste(names(nhanes_common_sample), collapse = ", ")),
  source = "results/v43/nhanes_common_sample_audit_v43.csv"
)
if (common_schema) {
  common_id <- tolower(col_chr(nhanes_common_sample, "sample_id"))
  common_n <- col_num(nhanes_common_sample, "n")
  common_deaths <- col_num(nhanes_common_sample, "deaths")
  idx_a <- common_id == "pef_a_only"
  idx_spiro <- common_id == "spirometry_abc"
  idx_intersection <- common_id == "pef_a_x_spirometry_abc"
  common_anchor <- sum(idx_a) == 1L && sum(idx_spiro) == 1L && sum(idx_intersection) == 1L &&
    common_n[idx_a] == 6719 && common_deaths[idx_a] == 925 &&
    common_n[idx_spiro] == 6776 && common_deaths[idx_spiro] == 922 &&
    common_n[idx_intersection] == 6540 && common_deaths[idx_intersection] == 885 &&
    common_n[idx_intersection] <= min(common_n[idx_a], common_n[idx_spiro]) &&
    common_deaths[idx_intersection] <= min(common_deaths[idx_a], common_deaths[idx_spiro])
  add_check(
    "Gate 2", "nhanes_common_sample_anchor", common_anchor,
    expected = "A-only=6719/925; spirometry ABC=6776/922; common sample=6540/885 and nested within both",
    observed = paste(common_id, paste0(common_n, "/", common_deaths), sep = "=", collapse = "; "),
    source = "results/v43/nhanes_common_sample_audit_v43.csv",
    detail = "Later nested incremental models must use one common covariate-complete sample; 6540/885 is the measurement-only upper bound."
  )
}

nhanes_contract_counts <- FALSE
if (!is.null(nhanes_contract)) {
  contract_n <- col_num(nhanes_contract, "n")
  contract_deaths <- col_num(nhanes_contract, "deaths")
  expected_pairs <- rbind(c(6719, 925), c(6971, 967), c(7083, 989))
  nhanes_contract_counts <- !is.null(contract_n) && !is.null(contract_deaths) && all(apply(expected_pairs, 1, function(pair) {
    any(contract_n == pair[[1]] & contract_deaths == pair[[2]], na.rm = TRUE)
  }))
}
add_check(
  "Gate 2", "nhanes_measurement_contract_anchors", nhanes_contract_counts,
  expected = "contract contains A=6719/925, A+C=6971/967, A/B/C=7083/989",
  observed = if (is.null(nhanes_contract)) "missing/unreadable" else paste0(nrow(nhanes_contract), " contract rows inspected"),
  source = "results/v43/nhanes_measurement_contract_v43.csv"
)
nhanes_e0_text <- corpus(nhanes_e0)
add_check(
  "Gate 2", "nhanes_e0_scale_frozen",
  nzchar(nhanes_e0_text) && has_all_patterns(nhanes_e0_text, c("sex", "sd|standard", "higher", "lower", "l/min|l.min")),
  expected = "sex-specific weighted-SD E0 scale and higher-means-lower-PEF direction recorded; per-100 scale remains locked in spec",
  observed = if (!nzchar(nhanes_e0_text)) "missing/unreadable" else "E0 aggregate inspected",
  source = "results/v43/nhanes_e0_scale_v43.csv"
)
nhanes_e0_role_ok <- FALSE
nhanes_e0_role_observed <- "missing required scale-role columns"
if (!is.null(nhanes_e0)) {
  quality_col <- pick_col(nhanes_e0, "quality_layer")
  role_col <- pick_col(nhanes_e0, "outcome_scaling_role")
  physical_col <- pick_col(nhanes_e0, c("e0b_physical_scale", "physical_scale"))
  if (!is.null(quality_col) && !is.null(role_col) && !is.null(physical_col)) {
    quality <- tolower(as.character(nhanes_e0[[quality_col]]))
    role <- tolower(as.character(nhanes_e0[[role_col]]))
    physical <- tolower(as.character(nhanes_e0[[physical_col]]))
    primary_rows <- quality == "pef_a_only"
    sensitivity_rows <- quality %in% c("pef_a_plus_c", "pef_abc")
    nhanes_e0_role_ok <- sum(primary_rows) == 2L && sum(sensitivity_rows) == 4L &&
      all(grepl("primary.*reuse unchanged|reuse unchanged.*primary", role[primary_rows], perl = TRUE)) &&
      all(grepl("descriptive diagnostic only", role[sensitivity_rows], fixed = TRUE)) &&
      all(grepl("do not rescale", role[sensitivity_rows], fixed = TRUE)) &&
      all(grepl("100.*l/min.*lower", physical, perl = TRUE))
    nhanes_e0_role_observed <- paste0(
      sum(primary_rows), " A-only rows; ", sum(sensitivity_rows),
      " sensitivity rows; roles=", paste(unique(role), collapse = " | ")
    )
  }
}
add_check(
  "Gate 2", "nhanes_e0_scale_reuse_roles", nhanes_e0_role_ok,
  expected = "A-only rows are PRIMARY constants reused unchanged; A+C/ABC rows are diagnostic only and must not rescale outcome models; all retain per-100 L/min scale",
  observed = nhanes_e0_role_observed,
  source = "results/v43/nhanes_e0_scale_v43.csv"
)

function_routing_ok <- FALSE
function_routing_observed <- "routing audit missing required columns"
if (!is.null(nhanes_function_routing)) {
  required_columns <- c(
    "coding_variant", "route_component", "route_source", "n", "primary_A_n", "rule"
  )
  if (all(required_columns %in% names(nhanes_function_routing))) {
    variant <- as.character(nhanes_function_routing$coding_variant)
    component <- as.character(nhanes_function_routing$route_component)
    source <- as.character(nhanes_function_routing$route_source)
    n <- suppressWarnings(as.numeric(nhanes_function_routing$n))
    primary_n <- suppressWarnings(as.numeric(nhanes_function_routing$primary_A_n))
    group_key <- paste(variant, component, sep = "|")
    group_totals <- tapply(n, group_key, sum)
    skip_rows <- grepl("age<=59 no-limitation screen", source, fixed = TRUE)
    equipment_rows <- component == "mobility" &
      grepl("PFQ054 established walking difficulty", source, fixed = TRUE)
    function_routing_ok <- nrow(nhanes_function_routing) == 14L &&
      identical(sort(unique(variant)), c("main_code5_missing", "sensitivity_code5_positive")) &&
      identical(sort(unique(component)), c("adl_iadl", "mobility")) &&
      all(primary_n == 6719) &&
      length(group_totals) == 4L && all(group_totals == 6719) &&
      sum(skip_rows) == 4L && all(n[skip_rows] == 2538) &&
      sum(equipment_rows) == 2L && all(n[equipment_rows] == 615)
    function_routing_observed <- paste0(
      nrow(nhanes_function_routing), " rows; group totals=",
      paste(names(group_totals), group_totals, sep = ":", collapse = "; "),
      "; age<=59 structural-zero rows=", paste(n[skip_rows], collapse = ","),
      "; PFQ054 mobility-positive rows=", paste(n[equipment_rows], collapse = ",")
    )
  }
}
add_check(
  "Gate 2", "nhanes_function_routing_reconstructs_primary_domain",
  function_routing_ok,
  expected = "14 aggregate rows; each variant/component partitions N=6719; four age<=59 structural-zero cells each N=2538; PFQ054 mobility-positive cell N=615 in both codings",
  observed = function_routing_observed,
  source = "results/v43/nhanes_function_routing_audit_v43.csv",
  detail = "This validates the routing correction without opening the restricted row-level ledger."
)

nhanes_gate2_eval <- gate_table_pass(nhanes_gate2)
add_check(
  "Gate 2", "nhanes_gate2_rows_pass", nhanes_gate2_eval$pass,
  expected = "all NHANES Gate 2 checks PASS",
  observed = nhanes_gate2_eval$observed,
  source = "results/v43/gate2_nhanes_measurement_v43.csv"
)
charls_gate2_eval <- scoped_gate_table_pass(charls_gate, gate_number = 2, baseline_core_only = TRUE)
add_check(
  "Gate 2", "charls_core_gate2_rows_pass", charls_gate2_eval$pass,
  expected = "all blocking core/baseline E0 Gate 2 rows PASS",
  observed = charls_gate2_eval$observed,
  source = "results/v43/charls_gate1_2_v43.csv",
  detail = "Longitudinal-change/W3 module rows are deliberately excluded from the baseline E0 blocking gate."
)

charls_gate_status_consistent <- FALSE
charls_gate_status_observed <- "gate table unreadable"
charls_gate_scope_ok <- FALSE
charls_gate_scope_observed <- "gate table unreadable"
if (!is.null(charls_gate)) {
  gate_status_col <- pick_col(charls_gate, c("status", "decision", "result"))
  gate_pass_col <- pick_col(charls_gate, c("pass", "passed"))
  gate_blocks_col <- pick_col(charls_gate, c("blocks_baseline_e0", "blocks_primary", "blocking"))
  gate_scope_col <- pick_col(charls_gate, c("scope", "module", "analysis_scope"))
  gate_check_col <- pick_col(charls_gate, c("check", "check_id", "criterion"))
  if (!is.null(gate_status_col) && !is.null(gate_pass_col)) {
    raw_gate_status <- toupper(trimws(as.character(charls_gate[[gate_status_col]])))
    raw_gate_pass <- as_flag(charls_gate[[gate_pass_col]])
    pass_status_ok <- raw_gate_status[raw_gate_pass %in% TRUE] %in% c("PASS", "GO", "OK")
    fail_status_ok <- raw_gate_status[raw_gate_pass %in% FALSE] %in%
      c("FAIL", "NO-GO", "NO_GO", "WARN", "WARNING", "MEASUREMENT-LIMITED")
    charls_gate_status_consistent <- all(!is.na(raw_gate_pass)) &&
      all(pass_status_ok) && all(fail_status_ok)
    charls_gate_status_observed <- paste0(
      "pass/status pairs=", paste(unique(paste(raw_gate_pass, raw_gate_status, sep = "/")), collapse = ",")
    )
  }
  if (!is.null(gate_blocks_col) && !is.null(gate_scope_col) && !is.null(gate_check_col)) {
    blocks <- as_flag(charls_gate[[gate_blocks_col]])
    scope_text <- tolower(as.character(charls_gate[[gate_scope_col]]))
    gate_check_text <- tolower(as.character(charls_gate[[gate_check_col]]))
    w1_icc <- grepl("w1.*same.session|same.session.*w1", gate_check_text, perl = TRUE)
    w2_or_w3 <- grepl("w2|w3|longitudinal|change|slope|drift", paste(scope_text, gate_check_text), perl = TRUE)
    baseline_blockers <- blocks %in% TRUE & grepl("baseline|e0|core", scope_text, perl = TRUE)
    charls_gate_scope_ok <- any(w1_icc & blocks %in% TRUE) &&
      !any(w2_or_w3 & blocks %in% TRUE) &&
      all((blocks %in% TRUE) == baseline_blockers)
    charls_gate_scope_observed <- paste0(
      "blocking rows=", sum(blocks %in% TRUE, na.rm = TRUE),
      "; blocking W1 ICC rows=", sum(w1_icc & blocks %in% TRUE, na.rm = TRUE),
      "; blocking W2/W3/change rows=", sum(w2_or_w3 & blocks %in% TRUE, na.rm = TRUE)
    )
  }
}
add_check(
  "Gate 2", "charls_gate_status_matches_boolean", charls_gate_status_consistent,
  expected = "PASS/GO iff pass=true; FAIL/NO-GO/WARN/measurement-limited iff pass=false",
  observed = charls_gate_status_observed,
  source = "results/v43/charls_gate1_2_v43.csv",
  detail = "This catches hard-coded PASS labels that disagree with the computed condition."
)
add_check(
  "Gate 2", "charls_baseline_e0_gate_scope", charls_gate_scope_ok,
  expected = "baseline E0 blockers are confined to baseline/core rows, W1 reliability blocks baseline, and W2/W3/change rows are non-blocking",
  observed = charls_gate_scope_observed,
  source = "results/v43/charls_gate1_2_v43.csv"
)

longitudinal_no_go_ok <- FALSE
longitudinal_observed <- "no non-blocking longitudinal Gate 2 rows identified"
if (!is.null(charls_gate) && length(charls_gate2_eval$nonblocking)) {
  idx <- charls_gate2_eval$nonblocking
  status_col <- pick_col(charls_gate, c("status", "decision", "result"))
  pass_col <- pick_col(charls_gate, c("pass", "passed"))
  check_col <- pick_col(charls_gate, c("check", "check_id", "criterion"))
  detail_col <- pick_col(charls_gate, c("detail", "notes", "reason"))
  raw_status <- if (is.null(status_col)) rep("", length(idx)) else
    toupper(trimws(as.character(charls_gate[[status_col]][idx])))
  raw_pass <- if (is.null(pass_col)) rep(NA, length(idx)) else as_flag(charls_gate[[pass_col]][idx])
  disable_text <- paste(
    if (is.null(check_col)) "" else as.character(charls_gate[[check_col]][idx]),
    if (is.null(detail_col)) "" else as.character(charls_gate[[detail_col]][idx])
  )
  explicit_no_go <- grepl("NO[ _-]*GO|DISABLED|FORBIDDEN|DO NOT PROCEED|NOT ELIGIBLE", raw_status, perl = TRUE) |
    grepl("NO[ _-]*GO|DISABL|FORBID|DO NOT|MUST NOT|OMIT|DROP|NOT PROCEED|NOT ELIGIBLE", disable_text, ignore.case = TRUE, perl = TRUE)
  explicit_warn_disable <- grepl("^WARN(ING)?$", raw_status, perl = TRUE) &
    grepl("DISABL|DO NOT|MUST NOT|OMIT|DROP|NOT PROCEED|NOT ELIGIBLE|NO[ _-]*GO", disable_text, ignore.case = TRUE, perl = TRUE)
  longitudinal_no_go_ok <- any(explicit_no_go | explicit_warn_disable | ((raw_pass %in% FALSE) & explicit_no_go), na.rm = TRUE)
  longitudinal_observed <- paste0(
    length(idx), " non-blocking longitudinal rows; statuses=",
    paste(unique(raw_status[nzchar(raw_status)]), collapse = ","),
    "; explicitly disabled rows=", sum(explicit_no_go | explicit_warn_disable, na.rm = TRUE)
  )
}
add_check(
  "Gate 2", "charls_w3_change_no_go_is_nonblocking", longitudinal_no_go_ok,
  expected = "W3/individual-change is explicitly NO-GO, or WARN with disablement text, in a non-blocking longitudinal scope",
  observed = longitudinal_observed,
  source = "results/v43/charls_gate1_2_v43.csv",
  detail = "A PASS here means the NO-GO was correctly scoped; it does not rehabilitate individual change or slope analyses."
)

# -----------------------------------------------------------------------------
# Version/output isolation and explicit no-row-level/no-model boundary.
# -----------------------------------------------------------------------------

old_read_only <- !is.null(spec) && isTRUE(spec$governance$old_versions_read_only)
row_export_off <- !is.null(spec) && identical(spec$governance$row_level_export, FALSE)
add_check(
  "Boundary", "frozen_governance_boundaries", old_read_only && row_export_off,
  expected = "old_versions_read_only=true and row_level_export=false",
  observed = if (is.null(spec)) "spec unavailable" else paste0("old_versions_read_only=", spec$governance$old_versions_read_only, "; row_level_export=", spec$governance$row_level_export),
  source = rel(spec_path)
)

v42_dirs <- file.path(root, c("results/v42", "work_v42", "logs/v42", "manuscript/v42", "output/submission_v42", "R/v42"))
v42_files <- unlist(lapply(v42_dirs[file.exists(v42_dirs)], function(path) {
  list.files(path, recursive = TRUE, full.names = TRUE, all.files = TRUE, no.. = TRUE)
}), use.names = FALSE)
historical_scan_roots <- file.path(root, c("results", "work", "logs", "manuscript", "output", "R", "literature"))
historical_named <- unlist(lapply(historical_scan_roots[file.exists(historical_scan_roots)], function(path) {
  list.files(path, recursive = TRUE, full.names = TRUE, all.files = TRUE, no.. = TRUE)
}), use.names = FALSE)
historical_named <- historical_named[
  grepl("(^|/)v42(/|$)|_v42([._/]|$)", historical_named, ignore.case = TRUE, perl = TRUE)
]
v42_files <- unique(c(v42_files, historical_named))
v42_files <- v42_files[file.exists(v42_files) & !dir.exists(v42_files)]
freeze_date <- if (is.null(spec) || is.null(spec$frozen_at)) NA_character_ else substr(spec$frozen_at, 1, 10)
freeze_cutoff <- suppressWarnings(as.POSIXct(freeze_date, tz = "Asia/Shanghai"))
modified_v42 <- character()
if (length(v42_files) && !is.na(freeze_cutoff)) {
  mtimes <- file.info(v42_files)$mtime
  modified_v42 <- v42_files[!is.na(mtimes) & mtimes >= freeze_cutoff]
}
v42_metadata_ok <- length(v42_files) > 0L && !is.na(freeze_cutoff) && length(modified_v42) == 0L
add_check(
  "Boundary", "v42_outputs_not_modified_after_freeze", v42_metadata_ok,
  expected = paste0("no v42-tree file mtime on/after conservative cutoff ", freeze_date, " 00:00 Asia/Shanghai"),
  observed = if (!length(v42_files)) "no v42 files found" else paste0(length(modified_v42), "/", length(v42_files), " v42 files at/after cutoff"),
  source = paste(vapply(v42_dirs, rel, character(1)), collapse = "; "),
  detail = if (length(modified_v42)) paste("recent:", paste(vapply(head(modified_v42, 10), rel, character(1)), collapse = "; ")) else "Filesystem metadata only; no v42 result content was read."
)

stage12_names <- c(
  "charls_cohort_flow_v43.csv", "charls_sequential_flow_v43.csv",
  "charls_status_event_anchors_v43.csv",
  "charls_machine_assertions_v43.csv", "charls_gate1_2_v43.csv",
  "charls_measurement_contract_v43.csv", "charls_pef_trial_qc_v43.csv",
  "charls_pef_reliability_v43.csv", "charls_cross_wave_drift_v43.csv",
  "charls_core_source_reconciliation_v43.csv", "charls_e0_scale_v43.csv",
  "charls_reported_rowmax_reconciliation_v43.csv",
  "nhanes_cohort_flow_v43.csv", "nhanes_sample_event_anchors_v43.csv",
  "nhanes_merge_audit_v43.csv", "nhanes_followup_horizon_audit_v43.csv",
  "gate1_nhanes_flow_v43.csv",
  "nhanes_measurement_contract_v43.csv", "nhanes_pef_quality_v43.csv",
  "nhanes_spirometry_quality_v43.csv", "nhanes_status_comment_v43.csv",
  "nhanes_safety_reasons_v43.csv", "nhanes_measurement_summary_v43.csv",
  "nhanes_measurement_correlations_v43.csv", "nhanes_measurement_anomalies_v43.csv",
  "nhanes_survey_design_audit_v43.csv", "nhanes_pef_observation_contrast_v43.csv",
  "nhanes_common_sample_audit_v43.csv",
  "nhanes_e0_scale_v43.csv", "nhanes_function_routing_audit_v43.csv",
  "gate2_nhanes_measurement_v43.csv"
)
stage12_paths <- file.path(results_dir, stage12_names)
safe_targets <- all(dirname(stage12_paths) == results_dir) && all(grepl("_v43\\.csv$", basename(stage12_paths))) &&
  !any(grepl("(^|[/_])v42([/_]|$)", stage12_paths, ignore.case = TRUE))
add_check(
  "Boundary", "stage1_2_output_targets_are_v43_only", safe_targets,
  expected = "all required aggregate targets are results/v43/*_v43.csv",
  observed = paste0(length(stage12_paths), " declared v43 aggregate targets"),
  source = "validator output contract"
)

manifest_path_values <- character()
if (!is.null(private_dat) && "path" %in% names(private_dat)) manifest_path_values <- c(manifest_path_values, private_dat$path)
if (!is.null(public_dat) && "path_alias" %in% names(public_dat)) manifest_path_values <- c(manifest_path_values, public_dat$path_alias)
manifest_targets_v42 <- grepl("(^|/)(results|work|logs|manuscript)/v42(/|$)|output/submission_v42", manifest_path_values, ignore.case = TRUE)
add_check(
  "Boundary", "manifests_do_not_target_v42_outputs", !any(manifest_targets_v42, na.rm = TRUE),
  expected = "no Stage 0 manifest entry targets a v42 output tree",
  observed = paste0(sum(manifest_targets_v42, na.rm = TRUE), " v42 output-tree paths"),
  source = paste(rel(private_path), rel(public_path), sep = "; ")
)

add_check(
  "Boundary", "validator_read_scope", TRUE,
  expected = "YAML/CSV aggregates and filesystem metadata only; no RDS/XPT/DAT/DTA/ZIP; no model fitting",
  observed = "read_yaml/read.table/file.info only; zero model calls",
  source = rel(file.path(root, "R/v43/03_validate_stage0_2.R")),
  detail = "This invariant is enforced by construction of this standalone script."
)

# -----------------------------------------------------------------------------
# Write reports. No failure is raised: a FAIL report is itself valid output.
# -----------------------------------------------------------------------------

# Private/public manifests are deliberately not duplicated in this inventory:
# their exact preliminary private-manifest hash is embedded below in the
# validator report, while the final freeze is expected to rewrite the manifest
# once—and only because gate_state is promoted after preflight. All other
# upstream aggregate sources must remain byte-identical through authorization.
validated_source_paths <- unique(c(
  spec_path, output_contract_path, gate0_path, environment_path, stage12_paths
))
validated_source_inventory <- data.frame(
  path = normalizePath(validated_source_paths, mustWork = FALSE),
  exists = file.exists(validated_source_paths),
  bytes = ifelse(
    file.exists(validated_source_paths),
    as.numeric(file.info(validated_source_paths)$size),
    NA_real_
  ),
  sha256 = vapply(validated_source_paths, sha256_file, character(1)),
  stringsAsFactors = FALSE
)
validated_source_inventory <- validated_source_inventory[
  order(validated_source_inventory$path),
  ,
  drop = FALSE
]
utils::write.csv(
  validated_source_inventory,
  validated_source_inventory_csv,
  row.names = FALSE,
  na = ""
)
source_inventory_complete <- nrow(validated_source_inventory) ==
  length(validated_source_paths) &&
  !anyDuplicated(validated_source_inventory$path) &&
  all(validated_source_inventory$exists) &&
  all(validated_source_inventory$bytes > 0) &&
  all(grepl("^[0-9a-fA-F]{64}$", validated_source_inventory$sha256))
add_check(
  "Boundary", "validator_source_inventory_complete",
  source_inventory_complete,
  expected = "every upstream YAML/CSV source read by the validator is uniquely inventoried with positive size and SHA-256",
  observed = paste0(
    sum(validated_source_inventory$exists), "/", nrow(validated_source_inventory),
    " present; ",
    sum(grepl("^[0-9a-fA-F]{64}$", validated_source_inventory$sha256)),
    "/", nrow(validated_source_inventory), " hashed"
  ),
  source = rel(validated_source_inventory_csv),
  detail = "The later no-model preflight re-hashes every listed source, preventing a stale validator report from authorizing changed Stage 0-2 aggregates."
)

validation <- do.call(rbind, checks)
validation$validated_at <- format(Sys.time(), tz = "Asia/Shanghai", usetz = TRUE)
validation$validator_script_sha256 <- sha256_file(
  file.path(root, "R", "v43", "03_validate_stage0_2.R")
)
validation$private_manifest_sha256 <- sha256_file(private_path)
validation$validated_source_inventory_sha256 <- sha256_file(
  validated_source_inventory_csv
)
utils::write.csv(validation, validation_csv, row.names = FALSE, na = "")

required_rows <- validation$required
overall <- if (all(validation$status[required_rows] == "PASS")) "PASS" else "FAIL"
gate_levels <- unique(validation$gate)
gate_summary <- do.call(rbind, lapply(gate_levels, function(gate) {
  rows <- validation$gate == gate & validation$required
  data.frame(
    gate = gate,
    status = if (all(validation$status[rows] == "PASS")) "PASS" else "FAIL",
    pass = sum(validation$status[rows] == "PASS"),
    fail = sum(validation$status[rows] == "FAIL"),
    stringsAsFactors = FALSE
  )
}))

md_escape <- function(x) {
  x <- one_line(x)
  x <- gsub("\\|", "\\\\|", x)
  gsub("`", "'", x, fixed = TRUE)
}

md <- c(
  "# v43 Stage 0-2 independent validation",
  "",
  paste0("Generated: ", format(Sys.time(), tz = "Asia/Shanghai", usetz = TRUE)),
  "",
  paste0("**Overall status: ", overall, "**"),
  "",
  "This is an outcome-blind aggregate validation. The validator did not open row-level RDS/XPT/DAT/DTA/ZIP files and did not fit any model. Missing upstream Stage 1-2 files are recorded as FAIL without aborting the run.",
  "",
  "CHARLS core baseline-E0 Gate 2 is evaluated separately from the longitudinal-change/W3 module. A correctly scoped W3 NO-GO (or WARN with explicit disablement) does not block baseline E0 analysis, but the validator requires that the longitudinal module be visibly disabled.",
  "",
  "## Gate summary",
  "",
  "| Gate | Status | PASS | FAIL |",
  "|---|---:|---:|---:|",
  vapply(seq_len(nrow(gate_summary)), function(i) {
    paste0("| ", md_escape(gate_summary$gate[[i]]), " | ", gate_summary$status[[i]], " | ", gate_summary$pass[[i]], " | ", gate_summary$fail[[i]], " |")
  }, character(1)),
  "",
  "## Detailed checks",
  "",
  "| Gate | Check | Required | Status | Expected | Observed | Source | Detail |",
  "|---|---|---:|---:|---|---|---|---|",
  vapply(seq_len(nrow(validation)), function(i) {
    paste0(
      "| ", md_escape(validation$gate[[i]]),
      " | ", md_escape(validation$check_id[[i]]),
      " | ", ifelse(validation$required[[i]], "yes", "no"),
      " | ", validation$status[[i]],
      " | ", md_escape(validation$expected[[i]]),
      " | ", md_escape(validation$observed[[i]]),
      " | ", md_escape(validation$source[[i]]),
      " | ", md_escape(validation$detail[[i]]), " |"
    )
  }, character(1)),
  "",
  "## Interpretation",
  "",
  if (overall == "PASS") {
    "All required Stage 0, Gate 1, Gate 2, and boundary checks passed. This validator alone does not authorize later analyses unless the frozen governance decision log also records the gate decisions."
  } else {
    "At least one required check failed. Stage 3 outcome modeling remains unauthorized under the frozen specification. Re-run this validator after correcting or generating the listed aggregate outputs."
  },
  "",
  paste0("Machine-readable report: `", rel(validation_csv), "`")
)
writeLines(md, validation_md, useBytes = TRUE)

message("Stage 0-2 validation completed with overall status: ", overall)
message("CSV: ", rel(validation_csv))
message("Markdown: ", rel(validation_md))
