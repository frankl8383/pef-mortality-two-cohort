# v43 Stage 3: CHARLS primary all-cause mortality association.
#
# GOVERNANCE WARNING
# ------------------
# This file is intentionally executable only after the independent Stage 0-2
# gate has been promoted to PASS in work_v43/gate_state_v43.yml and a final
# Stage 3 hash registry has been frozen.  The authorization check runs before
# any row-level input is opened and before any mortality model is fitted.
#
# Primary model:
#   survey-weighted person-period complementary log-log regression
# Primary exposure:
#   E0 = (sex-specific frozen weighted mean PEF - W1 row-max PEF) /
#        sex-specific frozen weighted SD PEF
# Primary adjustment tier:
#   A1 (A0 structural terms plus smoking, BMI, education, rurality, and
#       household per-capita consumption)
# Inferential time basis:
#   factor(end_wave) + offset(log(nominal_years))
# The nominal duration is derived only from scheduled survey-wave years. No
# exact death date is invented, and observed transition pathways (window_id)
# remain descriptive provenance rather than inferential strata.
#
# No individual Wave-3 change or slope is used.  Gate 2 classified that module
# as a nonblocking NO-GO because unexplained W3 drift exceeded 0.20 W1 SD.

options(stringsAsFactors = FALSE)

project_root <- function() {
  args <- commandArgs(trailingOnly = FALSE)
  file_arg <- grep("^--file=", args, value = TRUE)
  if (length(file_arg)) {
    script <- sub("^--file=", "", file_arg[[1]])
    return(normalizePath(file.path(dirname(script), "..", ".."), mustWork = TRUE))
  }
  normalizePath(getwd(), mustWork = TRUE)
}

one_line <- function(x, empty = "") {
  x <- trimws(as.character(x))
  x <- x[!is.na(x) & nzchar(x)]
  if (!length(x)) return(empty)
  gsub("[\r\n]+", " ", paste(x, collapse = "; "))
}

as_flag <- function(x) {
  if (is.logical(x)) return(x)
  if (is.numeric(x)) return(ifelse(is.na(x), NA, x != 0))
  y <- toupper(trimws(as.character(x)))
  out <- rep(NA, length(y))
  out[y %in% c("TRUE", "T", "1", "YES", "Y", "PASS", "GO", "OK")] <- TRUE
  out[y %in% c("FALSE", "F", "0", "NO", "N", "FAIL", "NO-GO", "NO_GO", "ERROR")] <- FALSE
  out
}

sha256_file <- function(path) {
  if (!file.exists(path) || dir.exists(path)) return(NA_character_)
  if (!requireNamespace("digest", quietly = TRUE)) return(NA_character_)
  digest::digest(file = path, algo = "sha256", serialize = FALSE)
}

expected_preflight_checks <- function() {
  data.frame(
    cohort = c(
      rep("BOTH", 6L),
      rep("CHARLS", 9L),
      rep("NHANES", 12L)
    ),
    check = c(
      "preflight_packages_available",
      "gate0_2_pass_before_preflight",
      "outcome_execution_disabled_during_preflight",
      "independent_stage0_2_validator_pass",
      "preliminary_manifest_current_and_complete",
      "governance_preflight_completed",
      "structural_sample_time_support_rebuilt",
      "mi_targets_have_predictors",
      "mi_specification_hash_recorded",
      "mi_expanded_dimension_below_rows",
      "two_by_two_mice_dry_run",
      "A0_A2_model_matrices_full_rank",
      "survey_design_df_exceeds_model_dimension",
      "spline_knots_finite",
      "charls_preflight_completed",
      "primary_sample_and_events_rebuilt",
      "full_design_backbone_rebuilt",
      "mi_targets_have_predictors",
      "mi_specification_hash_recorded",
      "mi_expanded_dimension_below_rows",
      "stratum_plus_raw_psu_reconstructs_design_psu",
      "two_by_two_mice_dry_run",
      "full_design_before_domain_preserved",
      "A0_A2_model_matrices_full_rank",
      "survey_design_df_exceeds_model_dimension",
      "start_stop_window_matrix_full_rank",
      "nhanes_preflight_completed"
    ),
    stringsAsFactors = FALSE
  )
}

expected_runtime_authorization_checks <- function() {
  c(
    "required_authorization_assets",
    "gate_state_allows_outcome_execution",
    "independent_stage0_2_validation",
    "stage3_no_model_preflight_pass",
    "private_manifest_rows_current",
    "stable_input_inventory_rows_current",
    "validator_source_inventory_rows_current",
    "final_authorization_audit_pass",
    "final_pre_model_hash_registry",
    "stage3_packages_locked_and_loaded_versions_match"
  )
}

preflight_contract_sha256 <- function() {
  contract <- expected_preflight_checks()
  contract <- contract[order(contract$cohort, contract$check), , drop = FALSE]
  lines <- paste(contract$cohort, contract$check, sep = "|")
  digest::digest(paste(lines, collapse = "\n"), algo = "sha256", serialize = FALSE)
}

inventory_sha256 <- function(manifest, exclude_roles = "gate_state") {
  required <- c("group", "role", "path", "restricted", "exists", "bytes", "sha256")
  if (!all(required %in% names(manifest))) return(NA_character_)
  stable <- dplyr::filter(manifest, !role %in% exclude_roles)
  stable <- dplyr::transmute(
    stable,
    group = as.character(group),
    role = as.character(role),
    path = normalizePath(as.character(path), mustWork = FALSE),
    restricted = toupper(as.character(as_flag(restricted))),
    exists = toupper(as.character(as_flag(exists))),
    bytes = format(as.numeric(bytes), scientific = FALSE, trim = TRUE),
    sha256 = tolower(as.character(sha256))
  )
  stable <- dplyr::arrange(stable, group, role, path)
  tmp <- tempfile("stage3_stable_inventory_", fileext = ".csv")
  on.exit(unlink(tmp), add = TRUE)
  readr::write_csv(stable, tmp)
  sha256_file(tmp)
}

validate_recorded_file_inventory <- function(path, required_extra = character()) {
  required <- unique(c(required_extra, "path", "exists", "bytes", "sha256"))
  dat <- tryCatch(
    utils::read.csv(path, stringsAsFactors = FALSE, check.names = FALSE),
    error = function(e) NULL
  )
  if (is.null(dat) || !nrow(dat) || !all(required %in% names(dat))) {
    return(list(
      pass = FALSE,
      detail = "missing, empty, unreadable, or incomplete inventory schema",
      data = dat
    ))
  }
  normalized <- normalizePath(as.character(dat$path), mustWork = FALSE)
  unique_paths <- !anyDuplicated(normalized)
  recorded_exists <- as_flag(dat$exists)
  current_exists <- file.exists(as.character(dat$path)) & !dir.exists(as.character(dat$path))
  current_bytes <- vapply(as.character(dat$path), function(file) {
    if (!file.exists(file) || dir.exists(file)) return(NA_real_)
    as.numeric(file.info(file)$size)
  }, numeric(1))
  current_hash <- vapply(as.character(dat$path), sha256_file, character(1))
  row_pass <- recorded_exists %in% TRUE &
    current_exists &
    !is.na(current_bytes) &
    current_bytes == suppressWarnings(as.numeric(dat$bytes)) &
    !is.na(current_hash) &
    tolower(current_hash) == tolower(trimws(as.character(dat$sha256)))
  list(
    pass = unique_paths && all(row_pass),
    detail = paste0(
      nrow(dat), " rows; unique_paths=", unique_paths,
      "; current_size_and_sha=", sum(row_pass), "/", nrow(dat)
    ),
    data = dat,
    row_pass = row_pass
  )
}

atomic_write_csv <- function(dat, path) {
  dir.create(dirname(path), recursive = TRUE, showWarnings = FALSE)
  tmp <- tempfile(pattern = paste0(".", basename(path), "."), tmpdir = dirname(path))
  on.exit(if (file.exists(tmp)) unlink(tmp), add = TRUE)
  utils::write.csv(dat, tmp, row.names = FALSE, na = "")
  if (!file.rename(tmp, path)) {
    stop("Could not atomically publish CSV: ", path, call. = FALSE)
  }
  invisible(path)
}

atomic_write_lines <- function(lines, path) {
  dir.create(dirname(path), recursive = TRUE, showWarnings = FALSE)
  tmp <- tempfile(pattern = paste0(".", basename(path), "."), tmpdir = dirname(path))
  on.exit(if (file.exists(tmp)) unlink(tmp), add = TRUE)
  writeLines(lines, tmp, useBytes = TRUE)
  if (!file.rename(tmp, path)) {
    stop("Could not atomically publish text output: ", path, call. = FALSE)
  }
  invisible(path)
}

write_charls_cohort_csv <- function(dat, path) {
  if (!grepl("charls", basename(path), ignore.case = TRUE)) {
    stop(
      "CHARLS Stage 3 may write only cohort-specific CSV files; shared read-modify-write is forbidden: ",
      path,
      call. = FALSE
    )
  }
  if ("cohort" %in% names(dat) &&
      any(!is.na(dat$cohort) & toupper(as.character(dat$cohort)) != "CHARLS")) {
    stop("A CHARLS cohort-specific output contains a non-CHARLS row: ", path, call. = FALSE)
  }
  dir.create(dirname(path), recursive = TRUE, showWarnings = FALSE)
  readr::write_csv(dat, path)
  invisible(path)
}

clear_stale_charls_failure_markers <- function(root) {
  stale <- c(
    file.path(root, "logs", "v43", "stage3_charls_authorization_failure_v43.log"),
    file.path(root, "results", "v43", "stage3_charls_execution_failure_v43.csv"),
    file.path(root, "results", "v43", "stage3_charls_mi_convergence_failure_checkpoints_v43.csv"),
    file.path(root, "logs", "v43", "stage3_charls_execution_failure_v43.log")
  )
  unlink(stale[file.exists(stale)])
  invisible(TRUE)
}

charls_stage3_result_paths <- function(root) {
  cohort_tables <- c(
    "spline_knot_registry",
    "sample_event_audit",
    "model_diagnostics",
    "mi_diagnostics",
    "mi_chain_convergence",
    "mi_trace",
    "time_varying_effects",
    "primary_association_registry",
    "join_audit",
    "assertion_audit",
    "visit_date_audit",
    "psu_influence_summary"
  )
  c(
    file.path(
      root, "results", "v43",
      paste0("stage3_charls_", cohort_tables, "_v43.csv")
    ),
    file.path(root, "derived_sensitive", "v43", "charls_stage3_analysis_ledger_v43.rds"),
    file.path(root, "logs", "v43", "stage3_charls_primary_association_v43.log"),
    file.path(root, "output", "qa", "v43", "STAGE3_CHARLS_PRIMARY_ASSOCIATION_QA_v43.md")
  )
}

charls_stage3_completion_manifest_path <- function(root) {
  file.path(
    root, "results", "v43", "stage3_charls_completion_manifest_v43.csv"
  )
}

published_charls_stage3_paths <- function(root) {
  shared_tables <- c(
    "spline_knot_registry",
    "sample_event_audit",
    "model_diagnostics",
    "mi_diagnostics",
    "mi_chain_convergence",
    "time_varying_effects",
    "primary_association_registry"
  )
  c(
    charls_stage3_result_paths(root),
    file.path(
      root, "results", "v43",
      paste0("stage3_", shared_tables, "_v43.csv")
    ),
    charls_stage3_completion_manifest_path(root),
    file.path(root, "results", "v43", "stage3_output_finalization_manifest_v43.csv"),
    file.path(root, "logs", "v43", "stage3_output_finalization_v43.log"),
    file.path(root, "output", "qa", "v43", "STAGE3_OUTPUT_FINALIZATION_QA_v43.md")
  )
}

write_authorization_success <- function(root, checks) {
  checks <- as.data.frame(checks, stringsAsFactors = FALSE)
  checks$authorization_status <- "PASS"
  checks$row_level_inputs_opened <- FALSE
  checks$mortality_models_fitted <- FALSE
  checks$run_timestamp <- format(Sys.time(), tz = "Asia/Shanghai", usetz = TRUE)
  atomic_write_csv(
    checks,
    file.path(root, "results", "v43", "stage3_charls_authorization_audit_v43.csv")
  )
  invisible(checks)
}

write_authorization_failure <- function(root, checks, reason) {
  out_dir <- file.path(root, "results", "v43")
  log_dir <- file.path(root, "logs", "v43")
  dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)
  dir.create(log_dir, recursive = TRUE, showWarnings = FALSE)

  checks <- as.data.frame(checks, stringsAsFactors = FALSE)
  checks$authorization_status <- "FAIL"
  checks$row_level_inputs_opened <- FALSE
  checks$mortality_models_fitted <- FALSE
  checks$run_timestamp <- format(Sys.time(), tz = "Asia/Shanghai", usetz = TRUE)
  atomic_write_csv(
    checks,
    file.path(out_dir, "stage3_charls_authorization_audit_v43.csv")
  )
  atomic_write_lines(
    c(
      paste0("CHARLS Stage 3 execution denied: ", format(Sys.time(), tz = "Asia/Shanghai", usetz = TRUE)),
      paste0("Reason: ", one_line(reason)),
      "Row-level inputs opened: 0",
      "Mortality models fitted: 0",
      "This is the only output permitted when the authorization gate fails."
    ),
    file.path(log_dir, "stage3_charls_authorization_failure_v43.log")
  )
}

authorization_gate <- function(root) {
  published_paths <- published_charls_stage3_paths(root)
  existing_published <- published_paths[file.exists(published_paths)]
  if (length(existing_published)) {
    stop(
      "Refusing to rerun CHARLS Stage 3 because complete or partial published outputs already exist. ",
      "No authorization audit or failure marker was changed, so Stage 3 finalization remains unblocked. ",
      "Existing paths: ",
      paste(existing_published, collapse = "; "),
      call. = FALSE
    )
  }

  required_gate_packages <- c("yaml", "digest", "dplyr", "readr")
  missing_gate_packages <- required_gate_packages[
    !vapply(required_gate_packages, requireNamespace, logical(1), quietly = TRUE)
  ]
  if (length(missing_gate_packages)) {
    checks <- data.frame(
      check = "authorization_reader_packages",
      status = "FAIL",
      observed = paste(missing_gate_packages, collapse = "; "),
      expected = paste(required_gate_packages, collapse = "; "),
      stringsAsFactors = FALSE
    )
    write_authorization_failure(root, checks, "Packages required to read the authorization state are unavailable.")
    stop("Stage 3 authorization failed before any row-level input was opened.", call. = FALSE)
  }

  paths <- list(
    gate_state = file.path(root, "work_v43", "gate_state_v43.yml"),
    gate0_report = file.path(root, "results", "v43", "gate0_reproducibility_v43.csv"),
    validator = file.path(root, "results", "v43", "gate1_2_validation_v43.csv"),
    validator_source_inventory = file.path(root, "results", "v43", "stage0_2_validated_source_inventory_v43.csv"),
    preflight_validation = file.path(root, "results", "v43", "stage3_preflight_validation_v43.csv"),
    authorization_validation = file.path(root, "results", "v43", "stage3_authorization_validation_v43.csv"),
    spec = file.path(root, "work_v43", "analysis_spec_v43.yml"),
    manifest = file.path(root, "results", "v43", "input_manifest_private_v43.csv"),
    decision_log = file.path(root, "work_v43", "decision_log_v43.md"),
    blueprint = file.path(root, "output", "qa", "v43_STAGE3_MODEL_BLUEPRINT_20260716.md"),
    output_contract = file.path(root, "work_v43", "output_contract_v43.yml"),
    registry_schema = file.path(root, "work_v43", "registry_schema_v43.csv"),
    renv_lock = file.path(root, "work_v43", "renv.lock"),
    stable_input_inventory = file.path(root, "work_v43", "stage3_stable_input_inventory_v43.csv"),
    hash_registry = file.path(root, "work_v43", "stage3_authorization_hashes_v43.csv"),
    stage0_script = file.path(root, "R", "v43", "00_freeze_and_manifest.R"),
    validator_script = file.path(root, "R", "v43", "03_validate_stage0_2.R"),
    preflight_script = file.path(root, "R", "v43", "03b_stage3_preflight.R"),
    charls_script = file.path(root, "R", "v43", "04_charls_stage3_primary_mortality.R"),
    nhanes_script = file.path(root, "R", "v43", "05_nhanes_stage3_primary_mortality.R"),
    finalizer_script = file.path(root, "R", "v43", "06_finalize_stage3_outputs.R"),
    charls_ledger = file.path(root, "derived_sensitive", "v43", "charls_stage1_ledger_v43.rds"),
    charls_e0 = file.path(root, "results", "v43", "charls_e0_scale_v43.csv"),
    nhanes_ledger = file.path(root, "derived_sensitive", "v43", "nhanes_stage1_ledger_v43.rds"),
    nhanes_e0 = file.path(root, "results", "v43", "nhanes_e0_scale_v43.csv"),
    nhanes_function_routing_audit = file.path(root, "results", "v43", "nhanes_function_routing_audit_v43.csv"),
    nhanes_function_proxy_evidence = file.path(root, "output", "qa", "v43_NHANES_FUNCTION_PROXY_EVIDENCE_20260716.md")
  )

  checks <- list()
  add <- function(check, pass, observed, expected) {
    checks[[length(checks) + 1L]] <<- data.frame(
      check = check,
      status = if (isTRUE(pass)) "PASS" else "FAIL",
      observed = one_line(observed),
      expected = one_line(expected),
      stringsAsFactors = FALSE
    )
  }

  path_exists <- vapply(paths, function(x) file.exists(x) && file.info(x)$size > 0, logical(1))
  add(
    "required_authorization_assets",
    all(path_exists),
    paste(names(path_exists), path_exists, sep = "=", collapse = "; "),
    "all required authorization, ledger, scaling, and lock assets present"
  )

  spec <- if (path_exists[["spec"]]) {
    tryCatch(yaml::read_yaml(paths$spec), error = function(e) NULL)
  } else {
    NULL
  }
  resolve_spec_path <- function(path) {
    if (!is.character(path) || length(path) != 1L || is.na(path) || !nzchar(trimws(path))) {
      return(NA_character_)
    }
    path <- path.expand(trimws(path))
    if (grepl("^/", path)) path else file.path(root, path)
  }
  add(
    "analysis_spec_readable_before_row_level_access",
    !is.null(spec),
    if (is.null(spec)) "analysis specification missing or unreadable" else spec$status,
    "frozen analysis specification is readable as aggregate governance metadata"
  )

  expected_gate0_checks <- c(
    "analysis_spec_frozen",
    "governance_files_exist",
    "renv_lock_exists",
    "all_manifest_inputs_exist",
    "stage0_2_packages_available",
    "stage3_packages_available",
    "later_optional_packages_recorded"
  )
  gate0_ok <- FALSE
  gate0_observed <- "Gate 0 report unavailable"
  if (path_exists[["gate0_report"]]) {
    gate0_report <- tryCatch(
      utils::read.csv(paths$gate0_report, stringsAsFactors = FALSE, check.names = FALSE),
      error = function(e) NULL
    )
    if (!is.null(gate0_report) && all(c("check", "pass") %in% names(gate0_report))) {
      observed_checks <- as.character(gate0_report$check)
      pass <- as_flag(gate0_report$pass)
      gate0_ok <- nrow(gate0_report) == length(expected_gate0_checks) &&
        !anyDuplicated(observed_checks) &&
        setequal(observed_checks, expected_gate0_checks) &&
        all(pass %in% TRUE)
      gate0_observed <- paste0(
        sum(pass %in% TRUE), "/", nrow(gate0_report),
        " PASS; unique=", !anyDuplicated(observed_checks),
        "; fixed_contract=", setequal(observed_checks, expected_gate0_checks)
      )
    }
  }
  add(
    "current_gate0_report_pass",
    gate0_ok,
    gate0_observed,
    paste(length(expected_gate0_checks), "unique fixed Gate 0 checks are present and PASS")
  )

  gate_state <- if (path_exists[["gate_state"]]) {
    tryCatch(yaml::read_yaml(paths$gate_state), error = function(e) NULL)
  } else {
    NULL
  }
  gate_ok <- !is.null(gate_state) &&
    identical(toupper(gate_state$gate0$status), "PASS") &&
    identical(toupper(gate_state$gate1$status), "PASS") &&
    identical(toupper(gate_state$gate2$status), "PASS") &&
    isTRUE(gate_state$outcome_execution_allowed)
  add(
    "gate_state_allows_outcome_execution",
    gate_ok,
    if (is.null(gate_state)) "gate state unreadable" else paste0(
      "Gate0=", gate_state$gate0$status,
      "; Gate1=", gate_state$gate1$status,
      "; Gate2=", gate_state$gate2$status,
      "; allowed=", gate_state$outcome_execution_allowed
    ),
    "Gate0=PASS; Gate1=PASS; Gate2=PASS; outcome_execution_allowed=true"
  )

  validator_ok <- FALSE
  validator_observed <- "validator unavailable"
  if (path_exists[["validator"]]) {
    validator <- utils::read.csv(paths$validator, stringsAsFactors = FALSE, check.names = FALSE)
    if (all(c("required", "status") %in% names(validator))) {
      required <- as_flag(validator$required)
      validator_ok <- any(required %in% TRUE) &&
        all(toupper(validator$status[required %in% TRUE]) == "PASS")
      validator_observed <- paste0(
        sum(toupper(validator$status[required %in% TRUE]) == "PASS"), "/",
        sum(required %in% TRUE), " required checks PASS"
      )
    }
  }
  add(
    "independent_stage0_2_validation",
    validator_ok,
    validator_observed,
    "every required row in gate1_2_validation_v43.csv is PASS"
  )

  validator_inventory_check <- validate_recorded_file_inventory(
    paths$validator_source_inventory
  )
  add(
    "stage0_2_validator_source_inventory_current",
    validator_inventory_check$pass,
    validator_inventory_check$detail,
    "every unique validator-source row matches its current file size and SHA-256"
  )

  stable_inventory_check <- validate_recorded_file_inventory(
    paths$stable_input_inventory,
    required_extra = c("group", "role", "restricted")
  )
  add(
    "stable_input_inventory_rows_current",
    stable_inventory_check$pass,
    stable_inventory_check$detail,
    "every unique stable-input row matches its current file size and SHA-256"
  )

  expected_authorization_checks <- c(
    "gate0_recomputed_from_current_files",
    "gate_state_promoted_for_final_authorization",
    "independent_stage0_2_validator_pass",
    "validator_source_inventory_matches_current_files",
    "preflight_report_schema_complete",
    "preflight_fixed_unique_check_contract",
    "preflight_all_fixed_checks_pass",
    "preflight_snapshot_matches_current_scripts_and_inputs"
  )
  final_authorization_audit_ok <- FALSE
  final_authorization_observed <- "final authorization audit unavailable"
  final_authorization_audit <- tryCatch(
    utils::read.csv(
      paths$authorization_validation,
      stringsAsFactors = FALSE,
      check.names = FALSE
    ),
    error = function(e) NULL
  )
  if (!is.null(final_authorization_audit) &&
      all(c("check", "status", "observed", "expected", "checked_at") %in%
          names(final_authorization_audit))) {
    observed_checks <- as.character(final_authorization_audit$check)
    status <- toupper(trimws(as.character(final_authorization_audit$status)))
    final_authorization_audit_ok <-
      nrow(final_authorization_audit) == length(expected_authorization_checks) &&
      !anyDuplicated(observed_checks) &&
      setequal(observed_checks, expected_authorization_checks) &&
      all(status == "PASS")
    final_authorization_observed <- paste0(
      nrow(final_authorization_audit), " rows; unique=", !anyDuplicated(observed_checks),
      "; fixed_contract=", setequal(observed_checks, expected_authorization_checks),
      "; PASS=", sum(status == "PASS"), "/", nrow(final_authorization_audit)
    )
  }
  add(
    "final_authorization_audit_exactly_eight_pass",
    final_authorization_audit_ok,
    final_authorization_observed,
    "exactly eight unique fixed final-authorization checks are present and PASS"
  )

  preflight <- NULL
  preflight_schema <- c(
    "cohort", "check", "status", "hard_gate", "expected_check", "observed", "expected",
    "check_contract_sha256", "stable_input_inventory_sha256",
    "stage0_script_sha256", "validator_script_sha256",
    "preflight_script_sha256", "charls_script_sha256", "nhanes_script_sha256",
    "finalizer_script_sha256",
    "analysis_spec_sha256", "charls_core_sha256", "charls_ledger_sha256",
    "charls_e0_sha256", "nhanes_ledger_sha256", "nhanes_donor_sha256",
    "nhanes_e0_sha256", "nhanes_function_routing_audit_sha256",
    "nhanes_function_proxy_evidence_sha256", "renv_lock_sha256",
    "validator_report_sha256", "validator_source_inventory_sha256",
    "preliminary_manifest_sha256", "run_timestamp"
  )
  preflight_schema_ok <- FALSE
  if (path_exists[["preflight_validation"]]) {
    preflight <- tryCatch(
      utils::read.csv(paths$preflight_validation, stringsAsFactors = FALSE, check.names = FALSE),
      error = function(e) NULL
    )
    preflight_schema_ok <- !is.null(preflight) &&
      ncol(preflight) == 29L &&
      identical(names(preflight), preflight_schema)
  }
  add(
    "stage3_preflight_schema_complete",
    preflight_schema_ok,
    if (is.null(preflight)) "preflight validation unavailable or unreadable" else
      paste0(sum(preflight_schema %in% names(preflight)), "/", length(preflight_schema), " required columns"),
    paste(preflight_schema, collapse = "; ")
  )

  preflight_contract_ok <- FALSE
  preflight_status_ok <- FALSE
  preflight_snapshot_domain_ok <- FALSE
  preflight_current_snapshot_ok <- FALSE
  preflight_observed <- "preflight validation unavailable"
  if (preflight_schema_ok) {
    expected_contract <- expected_preflight_checks()
    expected_contract <- expected_contract[order(expected_contract$cohort, expected_contract$check), , drop = FALSE]
    observed_contract <- data.frame(
      cohort = as.character(preflight$cohort),
      check = as.character(preflight$check),
      stringsAsFactors = FALSE
    )
    observed_contract <- observed_contract[
      order(observed_contract$cohort, observed_contract$check),
      ,
      drop = FALSE
    ]
    rownames(expected_contract) <- NULL
    rownames(observed_contract) <- NULL
    contract_hashes <- unique(tolower(as.character(preflight$check_contract_sha256)))
    preflight_contract_ok <- nrow(preflight) == nrow(expected_contract) &&
      !anyDuplicated(paste(preflight$cohort, preflight$check, sep = "|")) &&
      identical(observed_contract, expected_contract) &&
      length(contract_hashes) == 1L &&
      grepl("^[0-9a-f]{64}$", contract_hashes[[1]]) &&
      identical(contract_hashes[[1]], preflight_contract_sha256())

    hard <- as_flag(preflight$hard_gate)
    expected_flag <- as_flag(preflight$expected_check)
    status <- toupper(trimws(as.character(preflight$status)))
    preflight_timestamp <- unique(as.character(preflight$run_timestamp))
    preflight_status_ok <- all(hard %in% TRUE) &&
      all(expected_flag %in% TRUE) &&
      all(status %in% "PASS") &&
      setequal(unique(as.character(preflight$cohort)), c("BOTH", "CHARLS", "NHANES")) &&
      length(preflight_timestamp) == 1L &&
      !is.na(preflight_timestamp) &&
      nzchar(preflight_timestamp)

    snapshot_columns <- c(
      "check_contract_sha256", "stable_input_inventory_sha256",
      "stage0_script_sha256", "validator_script_sha256",
      "preflight_script_sha256", "charls_script_sha256", "nhanes_script_sha256",
      "finalizer_script_sha256",
      "analysis_spec_sha256", "charls_core_sha256", "charls_ledger_sha256",
      "charls_e0_sha256", "nhanes_ledger_sha256", "nhanes_donor_sha256",
      "nhanes_e0_sha256", "nhanes_function_routing_audit_sha256",
      "nhanes_function_proxy_evidence_sha256", "renv_lock_sha256",
      "validator_report_sha256", "validator_source_inventory_sha256",
      "preliminary_manifest_sha256"
    )
    preflight_snapshot_domain_ok <- all(vapply(snapshot_columns, function(field) {
      values <- unique(tolower(trimws(as.character(preflight[[field]]))))
      length(values) == 1L && !is.na(values) && grepl("^[0-9a-f]{64}$", values)
    }, logical(1)))

    current_snapshot_paths <- c(
      stage0_script_sha256 = paths$stage0_script,
      validator_script_sha256 = paths$validator_script,
      preflight_script_sha256 = paths$preflight_script,
      charls_script_sha256 = paths$charls_script,
      nhanes_script_sha256 = paths$nhanes_script,
      finalizer_script_sha256 = paths$finalizer_script,
      analysis_spec_sha256 = paths$spec,
      charls_core_sha256 = resolve_spec_path(spec$inputs$charls_core),
      charls_ledger_sha256 = paths$charls_ledger,
      charls_e0_sha256 = paths$charls_e0,
      nhanes_ledger_sha256 = paths$nhanes_ledger,
      nhanes_donor_sha256 = resolve_spec_path(spec$inputs$nhanes_ready),
      nhanes_e0_sha256 = paths$nhanes_e0,
      nhanes_function_routing_audit_sha256 = paths$nhanes_function_routing_audit,
      nhanes_function_proxy_evidence_sha256 = paths$nhanes_function_proxy_evidence,
      renv_lock_sha256 = paths$renv_lock,
      validator_report_sha256 = paths$validator,
      validator_source_inventory_sha256 = paths$validator_source_inventory
    )
    current_snapshot_hashes <- vapply(current_snapshot_paths, sha256_file, character(1))
    embedded_snapshot_hashes <- vapply(names(current_snapshot_hashes), function(field) {
      values <- unique(tolower(trimws(as.character(preflight[[field]]))))
      if (length(values) == 1L) values[[1]] else NA_character_
    }, character(1))
    stable_inventory_values <- unique(tolower(trimws(
      as.character(preflight$stable_input_inventory_sha256)
    )))
    stable_inventory_hash <- sha256_file(paths$stable_input_inventory)
    stable_inventory_snapshot_ok <- length(stable_inventory_values) == 1L &&
      !is.na(stable_inventory_hash) &&
      identical(stable_inventory_values[[1]], tolower(stable_inventory_hash))
    preflight_current_snapshot_ok <- all(!is.na(current_snapshot_hashes)) &&
      all(!is.na(embedded_snapshot_hashes)) &&
      identical(
        tolower(unname(current_snapshot_hashes)),
        unname(embedded_snapshot_hashes)
      ) &&
      stable_inventory_snapshot_ok
    preflight_observed <- paste0(
      nrow(preflight), " rows; contract=", preflight_contract_ok,
      "; all_hard_PASS=", preflight_status_ok,
      "; hash_domain=", preflight_snapshot_domain_ok,
      "; stable_inventory=", stable_inventory_snapshot_ok,
      "; current_snapshot=",
      paste(
        names(current_snapshot_hashes),
        paste0(
          substr(embedded_snapshot_hashes, 1, 10), "/",
          substr(current_snapshot_hashes, 1, 10)
        ),
        sep = "=",
        collapse = "; "
      )
    )
  }
  add(
    "stage3_preflight_fixed_unique_contract",
    preflight_contract_ok,
    preflight_observed,
    "exactly 27 unique fixed checks with the frozen BOTH/CHARLS/NHANES domain and contract SHA-256"
  )
  add(
    "stage3_preflight_all_checks_pass",
    preflight_status_ok,
    preflight_observed,
    "every fixed preflight row is a hard gate with status PASS"
  )
  add(
    "stage3_preflight_snapshot_hash_domain",
    preflight_snapshot_domain_ok,
    preflight_observed,
    "every embedded preflight snapshot field has one unique lowercase/uppercase-insensitive 64-hex SHA-256"
  )
  add(
    "stage3_preflight_current_snapshot_hashes",
    preflight_current_snapshot_ok,
    preflight_observed,
    "all current-bound preflight hashes, including the finalizer, validator-source inventory, and written stable-input inventory, match; preliminary_manifest_sha256 remains unique valid historical evidence only"
  )

  manifest <- NULL
  manifest_schema_ok <- FALSE
  manifest_unique <- FALSE
  manifest_required_inputs_ok <- FALSE
  manifest_observed <- "private manifest unavailable"
  manifest_required_schema <- c(
    "group", "role", "path", "restricted", "exists", "bytes", "sha256"
  )
  if (path_exists[["manifest"]]) {
    manifest <- tryCatch(
      utils::read.csv(paths$manifest, stringsAsFactors = FALSE, check.names = FALSE),
      error = function(e) NULL
    )
    manifest_schema_ok <- !is.null(manifest) &&
      nrow(manifest) > 0L &&
      all(manifest_required_schema %in% names(manifest))
  }
  add(
    "private_manifest_schema_complete",
    manifest_schema_ok,
    if (is.null(manifest)) "missing or unreadable" else
      paste0(nrow(manifest), " rows; ", sum(manifest_required_schema %in% names(manifest)), "/",
             length(manifest_required_schema), " required columns"),
    paste(manifest_required_schema, collapse = "; ")
  )

  required_manifest_paths <- character()
  if (!is.null(spec)) {
    required_manifest_paths <- c(
      charls_core = resolve_spec_path(spec$inputs$charls_core),
      charls_harmonized_archive = resolve_spec_path(spec$inputs$charls_harmonized_archive),
      charls_wave5_archive = resolve_spec_path(spec$inputs$charls_wave5_archive),
      charls_stage1_ledger = paths$charls_ledger,
      charls_e0_scale = paths$charls_e0,
      analysis_spec = paths$spec,
      scientific_plan = resolve_spec_path(spec$scientific_plan),
      stage3_blueprint = paths$blueprint,
      deviation_log = resolve_spec_path(spec$governance$deviation_log),
      decision_log = resolve_spec_path(spec$governance$decision_log),
      seed_ledger = resolve_spec_path(spec$governance$seed_ledger),
      output_contract = paths$output_contract,
      registry_schema = paths$registry_schema,
      gate_state = paths$gate_state,
      renv_description = file.path(root, "work_v43", "DESCRIPTION"),
      renv_lock = resolve_spec_path(spec$software$lockfile),
      stage0_freeze_script = paths$stage0_script,
      charls_stage1_2_script = file.path(root, "R", "v43", "01_charls_stage1_2_flow_measurement_audit.R"),
      nhanes_stage1_2_script = file.path(root, "R", "v43", "02_nhanes_stage1_2_flow_measurement_audit.R"),
      stage0_2_validator_script = paths$validator_script,
      stage3_preflight_script = paths$preflight_script,
      charls_stage3_script = paths$charls_script,
      nhanes_stage3_script = paths$nhanes_script,
      stage3_output_finalizer_script = paths$finalizer_script
    )
  }
  if (manifest_schema_ok) {
    normalized_manifest_paths <- normalizePath(as.character(manifest$path), mustWork = FALSE)
    manifest_unique <- !anyDuplicated(normalized_manifest_paths)
    normalized_required <- normalizePath(unname(required_manifest_paths), mustWork = FALSE)
    required_counts <- vapply(
      normalized_required,
      function(path) sum(normalized_manifest_paths == path),
      integer(1)
    )
    current_hashes <- vapply(unname(required_manifest_paths), sha256_file, character(1))
    current_bytes <- vapply(unname(required_manifest_paths), function(path) {
      if (!file.exists(path) || dir.exists(path)) return(NA_real_)
      as.numeric(file.info(path)$size)
    }, numeric(1))
    required_match <- vapply(seq_along(normalized_required), function(i) {
      rows <- which(normalized_manifest_paths == normalized_required[[i]])
      if (length(rows) != 1L) return(FALSE)
      recorded_exists <- as_flag(manifest$exists[[rows]])
      recorded_hash <- tolower(trimws(as.character(manifest$sha256[[rows]])))
      recorded_bytes <- suppressWarnings(as.numeric(manifest$bytes[[rows]]))
      isTRUE(recorded_exists) &&
        !is.na(current_hashes[[i]]) &&
        identical(tolower(current_hashes[[i]]), recorded_hash) &&
        isTRUE(all.equal(current_bytes[[i]], recorded_bytes, check.attributes = FALSE))
    }, logical(1))
    manifest_required_inputs_ok <- manifest_unique &&
      length(required_match) == length(required_manifest_paths) &&
      all(required_counts == 1L) &&
      all(required_match)
    manifest_observed <- paste0(
      "manifest_rows=", nrow(manifest),
      "; unique_paths=", manifest_unique,
      "; required_present_once=", sum(required_counts == 1L), "/", length(required_counts),
      "; required_current_hash_and_size=", sum(required_match), "/", length(required_match)
    )
  }
  add(
    "private_manifest_unique_paths",
    manifest_schema_ok && manifest_unique,
    manifest_observed,
    "every private-manifest path is unique after normalization"
  )
  add(
    "private_manifest_actual_charls_inputs_current",
    manifest_required_inputs_ok,
    manifest_observed,
    "the ledger, harmonized core, both source ZIPs, E0 scale, and every CHARLS Stage 3 governance/code asset are present exactly once and match recorded size/SHA-256"
  )

  registry <- NULL
  registry_schema_ok <- FALSE
  registry_contract_ok <- FALSE
  registry_hash_ok <- FALSE
  registry_observed <- "final Stage 3 hash registry missing or unreadable"
  expected_registry_paths <- character()
  if (!is.null(spec)) {
    expected_registry_paths <- c(
      analysis_spec = paths$spec,
      private_manifest = paths$manifest,
      decision_log = resolve_spec_path(spec$governance$decision_log),
      stage3_blueprint = paths$blueprint,
      stage3_preflight_script = paths$preflight_script,
      charls_stage3_script = paths$charls_script,
      nhanes_stage3_script = paths$nhanes_script,
      stage3_output_finalizer_script = paths$finalizer_script,
      stage3_preflight_validation = paths$preflight_validation,
      gate_state = paths$gate_state,
      stage0_2_validator_report = paths$validator,
      stage0_freeze_script = paths$stage0_script,
      stage0_2_validator_script = paths$validator_script,
      charls_core = resolve_spec_path(spec$inputs$charls_core),
      charls_stage1_ledger = paths$charls_ledger,
      charls_e0_scale = paths$charls_e0,
      nhanes_stage1_ledger = paths$nhanes_ledger,
      nhanes_donor = resolve_spec_path(spec$inputs$nhanes_ready),
      nhanes_e0_scale = paths$nhanes_e0,
      nhanes_function_routing_audit = paths$nhanes_function_routing_audit,
      nhanes_function_proxy_evidence = paths$nhanes_function_proxy_evidence,
      renv_lock = resolve_spec_path(spec$software$lockfile),
      stable_input_inventory = paths$stable_input_inventory,
      stage3_authorization_validation = paths$authorization_validation,
      stage0_2_validator_source_inventory = paths$validator_source_inventory
    )
  }
  if (path_exists[["hash_registry"]]) {
    registry <- tryCatch(
      utils::read.csv(paths$hash_registry, stringsAsFactors = FALSE, check.names = FALSE),
      error = function(e) NULL
    )
    registry_schema_ok <- !is.null(registry) &&
      all(c("asset", "path", "exists", "bytes", "sha256", "frozen_at") %in% names(registry))
  }
  add(
    "final_hash_registry_schema_complete",
    registry_schema_ok,
    if (is.null(registry)) "missing or unreadable" else paste(names(registry), collapse = "; "),
    "asset; path; exists; bytes; sha256; frozen_at"
  )
  if (registry_schema_ok && manifest_schema_ok) {
    expected_assets <- names(expected_registry_paths)
    registry_assets <- as.character(registry$asset)
    registry_contract_ok <- length(expected_assets) == 25L &&
      nrow(registry) == 25L &&
      !anyDuplicated(registry_assets) &&
      !anyDuplicated(normalizePath(as.character(registry$path), mustWork = FALSE)) &&
      setequal(registry_assets, expected_assets)

    current_registry_hashes <- vapply(expected_registry_paths, sha256_file, character(1))
    current_registry_bytes <- vapply(expected_registry_paths, function(file) {
      if (!file.exists(file) || dir.exists(file)) return(NA_real_)
      as.numeric(file.info(file)$size)
    }, numeric(1))
    file_asset_match <- vapply(names(expected_registry_paths), function(asset) {
      row <- which(registry_assets == asset)
      if (length(row) != 1L) return(FALSE)
      recorded_path <- normalizePath(as.character(registry$path[[row]]), mustWork = FALSE)
      expected_path <- normalizePath(expected_registry_paths[[asset]], mustWork = FALSE)
      recorded_hash <- tolower(trimws(as.character(registry$sha256[[row]])))
      recorded_exists <- as_flag(registry$exists[[row]])
      recorded_bytes <- suppressWarnings(as.numeric(registry$bytes[[row]]))
      identical(recorded_path, expected_path) &&
        isTRUE(recorded_exists) &&
        !is.na(current_registry_bytes[[asset]]) &&
        isTRUE(all.equal(
          current_registry_bytes[[asset]],
          recorded_bytes,
          check.attributes = FALSE
        )) &&
        !is.na(current_registry_hashes[[asset]]) &&
        identical(recorded_hash, tolower(current_registry_hashes[[asset]]))
    }, logical(1))
    registry_hash_ok <- registry_contract_ok && all(file_asset_match)
    registry_observed <- paste0(
      "rows=", nrow(registry),
      "; fixed_assets=", registry_contract_ok,
      "; current_size_and_hash=", sum(file_asset_match), "/", length(file_asset_match)
    )
  }
  add(
    "final_hash_registry_fixed_unique_assets",
    registry_contract_ok,
    registry_observed,
    "exactly 25 unique fixed file assets with unique paths"
  )
  add(
    "final_pre_model_hash_registry",
    registry_hash_ok,
    registry_observed,
    "every final frozen file asset has its expected path and current byte size/SHA-256"
  )

  locked_packages <- c(
    "digest", "dplyr", "haven", "mice", "mitools", "readr",
    "survey", "survival", "tibble", "tidyr", "tidyselect", "yaml"
  )
  lock_ok <- FALSE
  lock_observed <- "renv lock unavailable"
  if (path_exists[["renv_lock"]]) {
    lock <- tryCatch(yaml::read_yaml(paths$renv_lock), error = function(e) NULL)
    locked_versions <- vapply(locked_packages, function(pkg) {
      if (is.null(lock) || is.null(lock$Packages[[pkg]]$Version)) return(NA_character_)
      as.character(lock$Packages[[pkg]]$Version)
    }, character(1))
    installed_versions <- vapply(locked_packages, function(pkg) {
      if (!requireNamespace(pkg, quietly = TRUE)) return(NA_character_)
      as.character(utils::packageDescription(pkg, fields = "Version"))
    }, character(1))
    package_versions_match <- !is.na(locked_versions) &
      !is.na(installed_versions) &
      locked_versions == installed_versions
    locked_r <- if (is.null(lock) || is.null(lock$R$Version)) NA_character_ else
      as.character(lock$R$Version)
    installed_r <- as.character(getRversion())
    r_version_match <- !is.na(locked_r) && identical(locked_r, installed_r)
    lock_ok <- all(package_versions_match) && r_version_match
    lock_observed <- paste0(
      "R=", locked_r, "/", installed_r, " match=", r_version_match, "; ",
      paste(
        locked_packages,
        paste0(locked_versions, "/", installed_versions, "=", package_versions_match),
        sep = ":",
        collapse = "; "
      )
    )
  }
  add(
    "stage3_installed_versions_match_lockfile",
    lock_ok,
    lock_observed,
    "the running R version and every required Stage 3 package version exactly equal work_v43/renv.lock"
  )

  fixed_check <- function(check, pass, observed, expected) {
    data.frame(
      check = check,
      status = if (isTRUE(pass)) "PASS" else "FAIL",
      observed = one_line(observed),
      expected = one_line(expected),
      stringsAsFactors = FALSE
    )
  }
  checks_df <- do.call(rbind, list(
    fixed_check(
      "required_authorization_assets",
      all(path_exists) && !is.null(spec) && gate0_ok,
      paste0(
        paste(names(path_exists), path_exists, sep = "=", collapse = "; "),
        "; spec_readable=", !is.null(spec),
        "; current_gate0=", gate0_ok
      ),
      "all required assets exist, the frozen specification is readable, and the exact current Gate 0 report is PASS"
    ),
    fixed_check(
      "gate_state_allows_outcome_execution",
      gate_ok,
      if (is.null(gate_state)) "gate state unreadable" else paste0(
        "Gate0=", gate_state$gate0$status,
        "; Gate1=", gate_state$gate1$status,
        "; Gate2=", gate_state$gate2$status,
        "; allowed=", gate_state$outcome_execution_allowed
      ),
      "Gate0=PASS; Gate1=PASS; Gate2=PASS; outcome_execution_allowed=true"
    ),
    fixed_check(
      "independent_stage0_2_validation",
      validator_ok,
      validator_observed,
      "every required independent Stage 0-2 validator row is PASS"
    ),
    fixed_check(
      "stage3_no_model_preflight_pass",
      preflight_schema_ok && preflight_contract_ok && preflight_status_ok &&
        preflight_snapshot_domain_ok && preflight_current_snapshot_ok,
      preflight_observed,
      "the exact 29-column/27-row fixed hard-gate preflight contract is PASS and every current-bound hash matches"
    ),
    fixed_check(
      "private_manifest_rows_current",
      manifest_schema_ok && manifest_unique && manifest_required_inputs_ok,
      manifest_observed,
      "the private manifest is unique and all CHARLS-opened inputs plus governance/code assets match recorded size/SHA-256"
    ),
    fixed_check(
      "stable_input_inventory_rows_current",
      stable_inventory_check$pass,
      stable_inventory_check$detail,
      "every stable-input row matches current bytes and SHA-256"
    ),
    fixed_check(
      "validator_source_inventory_rows_current",
      validator_inventory_check$pass,
      validator_inventory_check$detail,
      "every validator-source row matches current bytes and SHA-256"
    ),
    fixed_check(
      "final_authorization_audit_pass",
      final_authorization_audit_ok,
      final_authorization_observed,
      "the exact eight final-authorization checks are unique and PASS"
    ),
    fixed_check(
      "final_pre_model_hash_registry",
      registry_schema_ok && registry_contract_ok && registry_hash_ok,
      registry_observed,
      "the exact 25-asset final registry has unique assets/paths and every row matches current bytes/SHA-256"
    ),
    fixed_check(
      "stage3_packages_locked_and_loaded_versions_match",
      lock_ok,
      lock_observed,
      "the running R version and each required package exactly match work_v43/renv.lock"
    )
  ))
  expected_runtime_checks <- expected_runtime_authorization_checks()
  if (nrow(checks_df) != 10L ||
      anyDuplicated(checks_df$check) ||
      !identical(as.character(checks_df$check), expected_runtime_checks)) {
    stop("Internal error: CHARLS runtime authorization audit is not the exact 10-check contract.", call. = FALSE)
  }
  if (!all(checks_df$status == "PASS")) {
    write_authorization_failure(
      root,
      checks_df,
      "One or more frozen Stage 3 authorization conditions failed."
    )
    stop(
      "CHARLS Stage 3 is not authorized. No row-level input was opened and no mortality model was fitted.",
      call. = FALSE
    )
  }

  success_written <- tryCatch(
    {
      clear_stale_charls_failure_markers(root)
      write_authorization_success(root, checks_df)
      TRUE
    },
    error = function(e) structure(FALSE, reason = conditionMessage(e))
  )
  if (!isTRUE(success_written)) {
    audit_error <- attr(success_written, "reason")
    stop(
      "CHARLS Stage 3 authorization checks passed, but the pre-row-level success audit could not be published",
      if (!is.null(audit_error)) paste0(": ", audit_error) else ".",
      " No row-level input was opened and no mortality model was fitted.",
      call. = FALSE
    )
  }

  invisible(list(paths = paths, gate_state = gate_state, checks = checks_df))
}

require_stage3_packages <- function() {
  packages <- c(
    "digest", "dplyr", "haven", "mice", "mitools", "readr",
    "survey", "survival", "tibble", "tidyr", "tidyselect", "yaml"
  )
  missing <- packages[!vapply(packages, requireNamespace, logical(1), quietly = TRUE)]
  if (length(missing)) {
    stop(
      "Authorized execution cannot continue because required packages are unavailable: ",
      paste(missing, collapse = ", "),
      call. = FALSE
    )
  }
  options(survey.lonely.psu = "adjust")
  invisible(packages)
}

as_num <- function(x) {
  suppressWarnings(as.numeric(haven::zap_labels(x)))
}

as_chr <- function(x) {
  out <- as.character(haven::zap_labels(x))
  out[is.na(out) | !nzchar(out)] <- NA_character_
  out
}

weighted_mean_simple <- function(x, w) {
  ok <- is.finite(x) & is.finite(w) & w > 0
  if (!any(ok)) return(NA_real_)
  sum(x[ok] * w[ok]) / sum(w[ok])
}

weighted_quantile_simple <- function(x, w, probs) {
  ok <- is.finite(x) & is.finite(w) & w > 0
  x <- x[ok]
  w <- w[ok]
  if (!length(x)) return(rep(NA_real_, length(probs)))
  ord <- order(x)
  x <- x[ord]
  w <- w[ord]
  cw <- cumsum(w) / sum(w)
  vapply(probs, function(p) x[which(cw >= p)[1]], numeric(1))
}

extract_zip_member <- function(archive, member) {
  if (!file.exists(archive)) stop("Missing archive: ", archive, call. = FALSE)
  td <- tempfile("charls_v43_stage3_")
  dir.create(td, recursive = TRUE)
  extracted <- utils::unzip(archive, files = member, exdir = td, overwrite = TRUE)
  if (!length(extracted) || !file.exists(extracted[[1]])) {
    stop("Could not extract ", member, " from ", archive, call. = FALSE)
  }
  extracted[[1]]
}

read_zip_dta_selected <- function(archive, member, columns) {
  local <- extract_zip_member(archive, member)
  haven::zap_labels(haven::read_dta(
    local,
    col_select = tidyselect::all_of(columns)
  ))
}

assert_unique_id <- function(dat, id, source) {
  if (!id %in% names(dat)) stop(source, " lacks ID column ", id, call. = FALSE)
  ids <- dat[[id]]
  if (anyNA(ids) || anyDuplicated(ids)) {
    stop(source, " does not have one nonmissing row per ", id, call. = FALSE)
  }
  invisible(TRUE)
}

new_audit_store <- function() {
  env <- new.env(parent = emptyenv())
  env$joins <- list()
  env$assertions <- list()
  env
}

record_assertion <- function(store, check, pass, observed, expected, hard_stop = TRUE) {
  store$assertions[[length(store$assertions) + 1L]] <- data.frame(
    check = check,
    status = if (isTRUE(pass)) "PASS" else "FAIL",
    observed = one_line(observed),
    expected = one_line(expected),
    stringsAsFactors = FALSE
  )
  if (!isTRUE(pass) && isTRUE(hard_stop)) {
    stop(check, " failed: ", one_line(observed), call. = FALSE)
  }
  invisible(pass)
}

audited_left_join <- function(x, y, by, source, store) {
  assert_unique_id(y, by, source)
  before <- nrow(x)
  matched <- sum(x[[by]] %in% y[[by]])
  out <- dplyr::left_join(x, y, by = by)
  store$joins[[length(store$joins) + 1L]] <- data.frame(
    source = source,
    source_rows = nrow(y),
    source_unique_ids = length(unique(y[[by]])),
    target_rows_before = before,
    target_rows_after = nrow(out),
    matched_target_ids = matched,
    unmatched_target_ids = before - matched,
    duplicate_source_ids = anyDuplicated(y[[by]]),
    stringsAsFactors = FALSE
  )
  if (nrow(out) != before) stop("Join expanded rows for source ", source, call. = FALSE)
  out
}

status_w24 <- function(x) {
  dplyr::case_when(
    x %in% c(1, 4) ~ "alive",
    x == 5 ~ "death",
    x == 6 ~ "carried_death",
    TRUE ~ "unknown"
  )
}

status_w5 <- function(x) {
  dplyr::case_when(
    x == 0 ~ "alive",
    x == 1 ~ "death",
    TRUE ~ "unknown"
  )
}

validate_status_sequence <- function(iw2, iw3, iw4, died5) {
  codes <- c(iw2, iw3, iw4)
  status <- status_w24(codes)
  first_death <- which(status == "death")
  first_carried <- which(status == "carried_death")

  if (length(first_carried)) {
    for (j in first_carried) {
      if (!any(status[seq_len(j - 1L)] == "death")) {
        return("first code 6 has no earlier code 5")
      }
    }
  }
  if (length(first_death)) {
    death_j <- first_death[[1]]
    if (death_j < 3L && any(status[(death_j + 1L):3L] == "alive")) {
      return("explicit alive status follows an earlier death")
    }
    if (identical(status_w5(died5), "alive")) {
      return("Wave 5 alive status follows an earlier death")
    }
  }
  NA_character_
}

build_period_one <- function(participant_id, community_id, weight, iw2, iw3, iw4, died5) {
  wave_year <- c(`1` = 2011, `2` = 2013, `3` = 2015, `4` = 2018, `5` = 2020)
  statuses <- c(status_w24(iw2), status_w24(iw3), status_w24(iw4), status_w5(died5))
  waves <- 2:5
  last_alive <- 1L
  rows <- list()
  event_seen <- FALSE

  for (j in seq_along(waves)) {
    wave <- waves[[j]]
    status <- statuses[[j]]
    if (event_seen) break
    if (status == "unknown" || status == "carried_death") next
    if (status == "alive") {
      rows[[length(rows) + 1L]] <- data.frame(
        participant_id = participant_id,
        community_id = community_id,
        weight_biomarker_w1 = weight,
        start_wave = last_alive,
        end_wave = wave,
        window_id = paste0("W", last_alive, "_W", wave),
        period_event = 0L,
        nominal_years = unname(wave_year[as.character(wave)] - wave_year[as.character(last_alive)]),
        stringsAsFactors = FALSE
      )
      last_alive <- wave
    } else if (status == "death") {
      rows[[length(rows) + 1L]] <- data.frame(
        participant_id = participant_id,
        community_id = community_id,
        weight_biomarker_w1 = weight,
        start_wave = last_alive,
        end_wave = wave,
        window_id = paste0("W", last_alive, "_W", wave),
        period_event = 1L,
        nominal_years = unname(wave_year[as.character(wave)] - wave_year[as.character(last_alive)]),
        stringsAsFactors = FALSE
      )
      event_seen <- TRUE
    }
  }

  if (!length(rows)) return(NULL)
  do.call(rbind, rows)
}

derive_smoking <- function(ever, current) {
  ever <- if (is.factor(ever)) suppressWarnings(as.numeric(as.character(ever))) else suppressWarnings(as.numeric(ever))
  current <- if (is.factor(current)) suppressWarnings(as.numeric(as.character(current))) else suppressWarnings(as.numeric(current))
  dplyr::case_when(
    ever == 0 & (is.na(current) | current == 0) ~ "never",
    ever == 1 & current == 0 ~ "former",
    ever == 1 & current == 1 ~ "current",
    TRUE ~ NA_character_
  )
}

numeric_code <- function(x) {
  if (is.factor(x)) {
    return(suppressWarnings(as.numeric(as.character(x))))
  }
  suppressWarnings(as.numeric(x))
}

apply_charls_smoking_parent_rule <- function(dat) {
  required <- c("smoke_ever_w1", "smoke_now_w1")
  missing <- setdiff(required, names(dat))
  if (length(missing)) {
    stop(
      "CHARLS smoking routing lacks fields: ",
      paste(missing, collapse = ", "),
      call. = FALSE
    )
  }

  smoke_ever <- numeric_code(dat$smoke_ever_w1)
  smoke_now <- numeric_code(dat$smoke_now_w1)
  invalid_ever <- !is.na(smoke_ever) & !smoke_ever %in% 0:1
  invalid_now <- !is.na(smoke_now) & !smoke_now %in% 0:1
  if (any(invalid_ever) || any(invalid_now)) {
    stop(
      "CHARLS smoking parent/child fields contain values outside 0/1/missing: ",
      "ever_invalid=", sum(invalid_ever),
      "; current_invalid=", sum(invalid_now),
      call. = FALSE
    )
  }

  input_parent_child_conflict <- smoke_ever == 0 & smoke_now == 1
  parent_inferred_from_child <- is.na(smoke_ever) & smoke_now == 1
  structural_current_fill <- smoke_ever == 0 &
    (is.na(smoke_now) | smoke_now != 0)

  # Harmonized CHARLS defines current smoking as a child question asked only
  # after ever smoking=1. The primary routing therefore gives the documented
  # parent response precedence when a harmonized pair conflicts, infers
  # ever=1 only when the parent is missing but current=1 is observed, and
  # deterministically encodes current=0 outside the applicable branch.
  smoke_ever[parent_inferred_from_child] <- 1
  smoke_now[smoke_ever == 0] <- 0

  output_conflict <- smoke_ever == 0 & smoke_now == 1
  if (any(output_conflict, na.rm = TRUE)) {
    stop(
      "The CHARLS smoking parent-rule routing retained an impossible pair.",
      call. = FALSE
    )
  }

  dat$smoke_ever_w1 <- smoke_ever
  dat$smoke_now_w1 <- smoke_now
  attr(dat, "charls_smoking_routing_audit") <- data.frame(
    n_rows = nrow(dat),
    input_parent_zero_child_one_n =
      sum(input_parent_child_conflict, na.rm = TRUE),
    parent_inferred_from_observed_child_one_n =
      sum(parent_inferred_from_child, na.rm = TRUE),
    child_routed_to_structural_zero_n =
      sum(structural_current_fill, na.rm = TRUE),
    output_parent_zero_child_one_n = sum(output_conflict, na.rm = TRUE),
    output_parent_missing_n = sum(is.na(smoke_ever)),
    output_child_missing_n = sum(is.na(smoke_now)),
    output_applicable_child_missing_n =
      sum(smoke_ever == 1 & is.na(smoke_now), na.rm = TRUE),
    output_unresolved_parent_child_missing_n =
      sum(is.na(smoke_ever) & is.na(smoke_now)),
    rule = paste(
      "official Harmonized CHARLS parent-question precedence;",
      "impute ever first without current as a predictor;",
      "impute current only when completed ever=1;",
      "set current=0 deterministically when completed ever=0"
    ),
    stringsAsFactors = FALSE
  )
  dat
}

mice.impute.charls_smoke_now_skip_logreg_v43 <- function(
    y, ry, x, wy = NULL, ...) {
  if (is.null(wy)) wy <- !ry
  if (is.null(colnames(x))) {
    stop(
      "The CHARLS smoking child imputer requires named predictor columns.",
      call. = FALSE
    )
  }
  parent_columns <- which(startsWith(
    colnames(x),
    "smoke_ever_w1"
  ))
  if (length(parent_columns) != 1L) {
    stop(
      "The CHARLS smoking child imputer requires exactly one expanded ",
      "smoke_ever_w1 parent column; observed=",
      paste(colnames(x)[parent_columns], collapse = "|"),
      call. = FALSE
    )
  }

  completed_parent <- suppressWarnings(as.numeric(x[, parent_columns]))
  invalid_parent <- !is.finite(completed_parent) |
    !completed_parent %in% 0:1
  if (any(invalid_parent)) {
    stop(
      "The CHARLS smoking child imputer received an unresolved or invalid ",
      "completed parent state.",
      call. = FALSE
    )
  }
  observed_child <- numeric_code(y)
  if (any(
    ry & completed_parent == 0 & observed_child == 1,
    na.rm = TRUE
  )) {
    stop(
      "Observed CHARLS smoking values violate the parent-child skip logic ",
      "before current-smoking imputation.",
      call. = FALSE
    )
  }

  target_rows <- which(wy)
  target_parent <- completed_parent[target_rows]
  output <- rep(NA_real_, length(target_rows))
  output[target_parent == 0] <- 0

  applicable_target_rows <- target_rows[target_parent == 1]
  applicable_observed <- ry & completed_parent == 1
  observed_values <- numeric_code(y[applicable_observed])
  if (length(applicable_target_rows)) {
    if (length(observed_values) < 2L ||
        !setequal(sort(unique(observed_values)), 0:1)) {
      stop(
        "The applicable CHARLS ever-smoker branch does not contain both ",
        "observed current-smoking categories.",
        call. = FALSE
      )
    }
    model_x <- x[, -parent_columns, drop = FALSE]
    applicable_target <- seq_along(y) %in% applicable_target_rows
    model_rows <- applicable_observed | applicable_target
    draws <- mice::mice.impute.logreg(
      y = y[model_rows],
      ry = applicable_observed[model_rows],
      x = model_x[model_rows, , drop = FALSE],
      wy = applicable_target[model_rows],
      ...
    )
    draws <- numeric_code(draws)
    if (length(draws) != length(applicable_target_rows) ||
        anyNA(draws) || any(!draws %in% 0:1)) {
      stop(
        "The applicable CHARLS current-smoking equation returned invalid draws.",
        call. = FALSE
      )
    }
    output[target_parent == 1] <- draws
  }

  if (anyNA(output) || any(!output %in% 0:1)) {
    stop(
      "The CHARLS smoking child imputer left an unresolved target.",
      call. = FALSE
    )
  }
  if (is.factor(y)) {
    return(factor(as.character(as.integer(output)), levels = levels(y)))
  }
  output
}

register_charls_smoking_imputer <- function() {
  symbol <- "mice.impute.charls_smoke_now_skip_logreg_v43"
  implementation <- mice.impute.charls_smoke_now_skip_logreg_v43
  existed <- exists(symbol, envir = .GlobalEnv, inherits = FALSE)
  previous <- if (existed) get(symbol, envir = .GlobalEnv, inherits = FALSE) else NULL
  assign(symbol, implementation, envir = .GlobalEnv)
  function() {
    if (existed) {
      assign(symbol, previous, envir = .GlobalEnv)
    } else if (exists(symbol, envir = .GlobalEnv, inherits = FALSE)) {
      rm(list = symbol, envir = .GlobalEnv)
    }
    invisible(TRUE)
  }
}

freeze_spline_knots <- function(dat) {
  variables <- c("age_w1", "height_m_w1", "bmi_w1", "E0")
  rows <- lapply(variables, function(v) {
    q <- weighted_quantile_simple(dat[[v]], dat$weight_biomarker_w1, c(0.05, 0.35, 0.65, 0.95))
    data.frame(
      cohort = "CHARLS",
      variable = v,
      n_observed = sum(is.finite(dat[[v]]) & is.finite(dat$weight_biomarker_w1) & dat$weight_biomarker_w1 > 0),
      weighted_q05 = q[[1]],
      weighted_q35 = q[[2]],
      weighted_q65 = q[[3]],
      weighted_q95 = q[[4]],
      rule = "outcome-blind weighted q05/q35/q65/q95 in the structurally eligible observed-exposure cohort",
      stringsAsFactors = FALSE
    )
  })
  knots <- do.call(rbind, rows)
  if (any(!is.finite(unlist(knots[c("weighted_q05", "weighted_q35", "weighted_q65", "weighted_q95")])))) {
    stop("One or more frozen spline knots are non-finite.", call. = FALSE)
  }
  if (any(apply(knots[c("weighted_q05", "weighted_q35", "weighted_q65", "weighted_q95")], 1, function(x) any(diff(x) <= 0)))) {
    stop("One or more frozen spline knot sequences are not strictly increasing.", call. = FALSE)
  }
  knots
}

get_knot_row <- function(knots, variable) {
  out <- knots[knots$variable == variable, , drop = FALSE]
  if (nrow(out) != 1L) stop("Expected exactly one knot row for ", variable, call. = FALSE)
  out
}

fixed_ns <- function(x, knot_row, prefix) {
  basis <- splines::ns(
    x,
    knots = c(knot_row$weighted_q35, knot_row$weighted_q65),
    Boundary.knots = c(knot_row$weighted_q05, knot_row$weighted_q95)
  )
  basis <- as.data.frame(basis)
  names(basis) <- paste0(prefix, "_ns", seq_len(ncol(basis)))
  basis
}

restricted_cubic_basis <- function(x, knot_row, prefix = "E0") {
  k <- as.numeric(knot_row[c("weighted_q05", "weighted_q35", "weighted_q65", "weighted_q95")])
  tp3 <- function(z) pmax(z, 0)^3
  nonlinear <- lapply(1:2, function(j) {
    (tp3(x - k[j]) -
      tp3(x - k[3]) * (k[4] - k[j]) / (k[4] - k[3]) +
      tp3(x - k[4]) * (k[3] - k[j]) / (k[4] - k[3])) /
      (k[4] - k[1])^2
  })
  out <- data.frame(x, nonlinear[[1]], nonlinear[[2]])
  names(out) <- c(paste0(prefix, "_linear"), paste0(prefix, "_nonlinear1"), paste0(prefix, "_nonlinear2"))
  out
}

attach_passive_variables <- function(dat, knots) {
  smoke_ever <- numeric_code(dat$smoke_ever_w1)
  smoke_now <- numeric_code(dat$smoke_now_w1)
  invalid_smoking <- is.na(smoke_ever) | is.na(smoke_now) |
    !smoke_ever %in% 0:1 | !smoke_now %in% 0:1 |
    (smoke_ever == 0 & smoke_now == 1)
  if (any(invalid_smoking)) {
    stop(
      "Completed/common-sample smoking data violate the frozen parent-child ",
      "coherence rule; passive post-hoc repair is forbidden. Invalid rows=",
      sum(invalid_smoking),
      call. = FALSE
    )
  }
  dat$smoking_status_3 <- factor(
    derive_smoking(smoke_ever, smoke_now),
    levels = c("never", "former", "current")
  )
  disease_vars <- c("r1hibpe", "r1diabe", "r1cancre", "r1hearte", "r1stroke", "r1kidneye")
  disease_mat <- do.call(cbind, lapply(dat[disease_vars], numeric_code))
  dat$nonpulmonary_comorbidity_count <- rowSums(disease_mat == 1, na.rm = FALSE)
  dat$frailty_proxy_count_w1 <- pmin(pmax(round(numeric_code(dat$frailty_proxy_count_w1)), 0), 5)
  dat$hh1cperc <- numeric_code(dat$hh1cperc)
  dat$log_hh1cperc <- log1p(dat$hh1cperc)
  dat$raeducl <- droplevels(
    factor(round(numeric_code(dat$raeducl)), levels = 0:3)
  )
  dat$h1rural <- factor(round(numeric_code(dat$h1rural)), levels = 0:1)
  dat$lung_w1 <- numeric_code(dat$lung_w1)
  dat$asthma_w1 <- numeric_code(dat$asthma_w1)
  dat$sex_code <- factor(numeric_code(dat$sex_code), levels = c(1, 2))

  dat <- cbind(
    dat,
    fixed_ns(dat$age_w1, get_knot_row(knots, "age_w1"), "age"),
    fixed_ns(dat$height_m_w1, get_knot_row(knots, "height_m_w1"), "height"),
    fixed_ns(dat$bmi_w1, get_knot_row(knots, "bmi_w1"), "bmi"),
    restricted_cubic_basis(dat$E0, get_knot_row(knots, "E0"), "E0")
  )
  required_complete <- c(
    "E0", "E0b", "age_ns1", "age_ns2", "age_ns3",
    "height_ns1", "height_ns2", "height_ns3",
    "bmi_ns1", "bmi_ns2", "bmi_ns3", "smoking_status_3",
    "raeducl", "h1rural", "log_hh1cperc", "lung_w1", "asthma_w1",
    "nonpulmonary_comorbidity_count", "frailty_proxy_count_w1"
  )
  incomplete <- vapply(dat[required_complete], function(x) any(is.na(x)), logical(1))
  if (any(incomplete)) {
    stop(
      "Completed/common-sample data retain missing model fields: ",
      paste(names(incomplete)[incomplete], collapse = ", "),
      call. = FALSE
    )
  }
  dat
}

make_mi_input <- function(master) {
  keep <- c(
    "participant_id", "community_id", "age_w1", "sex_code", "height_m_w1", "bmi_w1",
    "smoke_ever_w1", "smoke_now_w1", "raeducl", "h1rural", "hh1cperc",
    "lung_w1", "asthma_w1", "r1hibpe", "r1diabe", "r1cancre", "r1hearte",
    "r1stroke", "r1kidneye", "frailty_proxy_count_w1", "E0", "E0b",
    "pef_w1_rowmax", "weight_biomarker_w1", "event_any",
    "last_known_followup_wave", "total_observed_followup_span",
    "known_alive_w2", "known_alive_w3", "known_alive_w4", "known_alive_w5",
    "death_report_w2", "death_report_w3", "death_report_w4", "death_report_w5",
    "log_survey_weight", "grip_kg_w1", "adl6_score_w1", "cesd10_w1"
  )
  missing <- setdiff(keep, names(master))
  if (length(missing)) stop("MI master lacks fields: ", paste(missing, collapse = ", "), call. = FALSE)
  dat <- master[keep]
  dat <- apply_charls_smoking_parent_rule(dat)
  smoking_routing_audit <- attr(
    dat,
    "charls_smoking_routing_audit",
    exact = TRUE
  )
  dat$participant_id <- factor(dat$participant_id)
  dat$community_id <- factor(dat$community_id)
  dat$sex_code <- factor(dat$sex_code, levels = c(1, 2))
  dat$raeducl <- droplevels(factor(dat$raeducl, levels = 0:3))
  dat$last_known_followup_wave <- factor(
    round(numeric_code(dat$last_known_followup_wave)),
    levels = 2:5
  )
  binary_fields <- c(
    "smoke_ever_w1", "smoke_now_w1", "h1rural", "lung_w1", "asthma_w1",
    "r1hibpe", "r1diabe", "r1cancre", "r1hearte", "r1stroke", "r1kidneye"
  )
  for (v in binary_fields) dat[[v]] <- factor(dat[[v]], levels = 0:1)
  attr(dat, "charls_smoking_routing_audit") <- smoking_routing_audit
  dat
}

freeze_mi_specification <- function(mi_data) {
  method <- mice::make.method(mi_data)
  predictor <- mice::make.predictorMatrix(mi_data)

  never_impute <- c(
    "participant_id", "community_id", "age_w1", "sex_code", "E0", "E0b",
    "pef_w1_rowmax", "weight_biomarker_w1", "event_any",
    "last_known_followup_wave", "total_observed_followup_span",
    "known_alive_w2", "known_alive_w3", "known_alive_w4", "known_alive_w5",
    "death_report_w2", "death_report_w3", "death_report_w4", "death_report_w5",
    "log_survey_weight"
  )
  method[never_impute] <- ""
  method[c("height_m_w1", "bmi_w1", "hh1cperc", "frailty_proxy_count_w1", "grip_kg_w1", "adl6_score_w1", "cesd10_w1")] <- "pmm"
  method[c("smoke_ever_w1", "h1rural", "lung_w1", "asthma_w1",
           "r1hibpe", "r1diabe", "r1cancre", "r1hearte", "r1stroke", "r1kidneye")] <- "logreg"
  method["smoke_now_w1"] <- "charls_smoke_now_skip_logreg_v43"
  method["raeducl"] <- "polyreg"
  method[vapply(mi_data, function(x) !anyNA(x), logical(1))] <- ""
  unordered_multicategory_targets <- names(method)[
    nzchar(method) &
      vapply(mi_data, function(x) {
        is.factor(x) && !is.ordered(x) && nlevels(x) > 2L
      }, logical(1))
  ]

  predictor[, c("participant_id", "community_id")] <- 0
  predictor[c("participant_id", "community_id"), ] <- 0
  # E0, E0b, and raw PEF are exact re-expressions within sex; likewise the raw
  # weight and its logarithm are redundant. Retain E0 and log(weight).
  suppressed_reexpression_predictors <- c(
    "E0b", "pef_w1_rowmax", "weight_biomarker_w1"
  )
  # The public CHARLS community identifier has 433 sparse levels in the frozen
  # cohort and exactly determines rurality. Treating all levels as fixed effects
  # in each single-level FCS equation is rank-deficient and is not a substitute
  # for multilevel MI. The identifier remains unchanged for the final survey
  # design; rurality and log(weight) retain design information in the MI model.
  suppressed_cluster_fixed_effect_predictors <- "community_id"
  # Person-level interval-outcome information is represented once by death/event
  # and a categorical last observed wave. The follow-up span and wave-by-wave
  # alive/death flags are deterministic or near-deterministic re-encodings that
  # otherwise make the FCS regressions singular or separated.
  suppressed_redundant_outcome_predictors <- c(
    "total_observed_followup_span",
    "known_alive_w2", "known_alive_w3", "known_alive_w4", "known_alive_w5",
    "death_report_w2", "death_report_w3", "death_report_w4", "death_report_w5"
  )
  suppressed_predictors <- unique(c(
    suppressed_reexpression_predictors,
    suppressed_cluster_fixed_effect_predictors,
    suppressed_redundant_outcome_predictors
  ))
  predictor[, suppressed_predictors] <- 0
  diag(predictor) <- 0
  # The current-smoking child may use the completed ever-smoking parent only
  # for applicability routing. The parent equation must not use the child:
  # otherwise the two mostly jointly missing fields form a self-reinforcing
  # feedback loop that can occupy impossible states inside FCS.
  predictor["smoke_ever_w1", "smoke_now_w1"] <- 0
  predictor["smoke_now_w1", "smoke_ever_w1"] <- 1

  active_targets <- names(method)[nzchar(method)]
  smoking_hierarchy <- intersect(
    c("smoke_ever_w1", "smoke_now_w1"),
    active_targets
  )
  visit_sequence <- c(
    smoking_hierarchy,
    setdiff(active_targets, smoking_hierarchy)
  )

  list(
    method = method,
    predictor_matrix = predictor,
    visit_sequence = visit_sequence,
    unordered_multicategory_targets = unordered_multicategory_targets,
    charls_smoking_skip_pattern = list(
      parent = "smoke_ever_w1",
      child = "smoke_now_w1",
      observed_conflict_rule = "documented_parent_precedence",
      parent_equation_excludes_child = TRUE,
      child_model_applicable_parent_value = 1L,
      child_structural_value_when_parent_zero = 0L,
      visit_sequence_prefix = c("smoke_ever_w1", "smoke_now_w1"),
      per_iteration_completed_pair_gate = "zero_parent0_child1_and_zero_unresolved"
    ),
    retained_reexpression_predictors = c("E0", "log_survey_weight"),
    retained_outcome_predictors = c("event_any", "last_known_followup_wave"),
    suppressed_reexpression_predictors = suppressed_reexpression_predictors,
    suppressed_cluster_fixed_effect_predictors = suppressed_cluster_fixed_effect_predictors,
    suppressed_redundant_outcome_predictors = suppressed_redundant_outcome_predictors,
    suppressed_deterministic_predictors = suppressed_predictors,
    maxit = 20L,
    convergence_iteration_checkpoints = c(20L, 40L, 80L),
    maximum_maxit = 80L,
    initial_m = 50L,
    maximum_m = 100L,
    seed = 430401L,
    monte_carlo_error_fraction_max = 0.10,
    convergence_rhat_max = 1.05,
    trace_release_missing_n_min = 20L
  )
}

record_category_trace_iteration <- function(imp, mi_data, mi_spec) {
  targets <- mi_spec$unordered_multicategory_targets
  if (!length(targets)) {
    return(data.frame(
      variable = character(), category_level = character(),
      iteration = integer(), chain = integer(), missing_n = integer(),
      value = numeric(), stringsAsFactors = FALSE
    ))
  }
  dplyr::bind_rows(lapply(targets, function(variable) {
    levels_expected <- levels(mi_data[[variable]])
    values <- imp$imp[[variable]]
    missing_n <- sum(is.na(mi_data[[variable]]))
    if (is.null(values) || nrow(values) != missing_n || ncol(values) != imp$m ||
        missing_n < 1L || !length(levels_expected)) {
      stop("Invalid current categorical imputation state for ", variable, call. = FALSE)
    }
    dplyr::bind_rows(lapply(seq_len(imp$m), function(chain) {
      observed <- as.character(values[[chain]])
      codes <- match(observed, levels_expected)
      if (length(codes) != missing_n || anyNA(codes)) {
        stop("Categorical imputation contains an invalid level for ", variable, call. = FALSE)
      }
      data.frame(
        variable = variable,
        category_level = levels_expected,
        iteration = as.integer(imp$iteration),
        chain = as.integer(chain),
        missing_n = as.integer(missing_n),
        value = tabulate(codes, nbins = length(levels_expected)) / missing_n,
        stringsAsFactors = FALSE
      )
    }))
  }))
}

completed_binary_mice_variable <- function(imp, mi_data, variable, chain) {
  if (!variable %in% names(mi_data) ||
      !variable %in% names(imp$imp) ||
      chain < 1L || chain > imp$m) {
    stop(
      "Invalid request while reconstructing a completed binary MICE field: ",
      variable,
      call. = FALSE
    )
  }
  output <- numeric_code(mi_data[[variable]])
  missing_rows <- which(is.na(mi_data[[variable]]))
  imputed <- imp$imp[[variable]]
  if (length(missing_rows)) {
    if (is.null(imputed) ||
        nrow(imputed) != length(missing_rows) ||
        ncol(imputed) != imp$m) {
      stop(
        "The MICE state does not match the original missing rows for ",
        variable,
        call. = FALSE
      )
    }
    output[missing_rows] <- numeric_code(imputed[[chain]])
  }
  output
}

record_smoking_coherence_iteration <- function(imp, mi_data) {
  per_chain <- lapply(seq_len(imp$m), function(chain) {
    smoke_ever <- completed_binary_mice_variable(
      imp, mi_data, "smoke_ever_w1", chain
    )
    smoke_now <- completed_binary_mice_variable(
      imp, mi_data, "smoke_now_w1", chain
    )
    unresolved <- is.na(smoke_ever) | is.na(smoke_now) |
      !smoke_ever %in% 0:1 | !smoke_now %in% 0:1
    conflict <- !unresolved & smoke_ever == 0 & smoke_now == 1
    data.frame(
      chain = chain,
      unresolved_n = sum(unresolved),
      parent_zero_child_one_n = sum(conflict),
      stringsAsFactors = FALSE
    )
  })
  per_chain <- dplyr::bind_rows(per_chain)
  if (any(per_chain$unresolved_n != 0L) ||
      any(per_chain$parent_zero_child_one_n != 0L)) {
    bad <- per_chain[
      per_chain$unresolved_n != 0L |
        per_chain$parent_zero_child_one_n != 0L,
      ,
      drop = FALSE
    ]
    stop(
      "The CHARLS smoking skip-pattern coherence gate failed at MICE ",
      "iteration ", imp$iteration, ": ",
      paste0(
        "chain", bad$chain,
        "[unresolved=", bad$unresolved_n,
        ",parent0_child1=", bad$parent_zero_child_one_n, "]",
        collapse = "; "
      ),
      call. = FALSE
    )
  }
  data.frame(
    iteration = as.integer(imp$iteration),
    chains_checked = as.integer(imp$m),
    unresolved_n_across_completed_chains = sum(per_chain$unresolved_n),
    parent_zero_child_one_n_across_completed_chains =
      sum(per_chain$parent_zero_child_one_n),
    rule = paste(
      "ever imputed before current;",
      "current modeled only among completed ever=1;",
      "current deterministically 0 among completed ever=0"
    ),
    stringsAsFactors = FALSE
  )
}

mice_smoking_coherence_trace <- function(imp) {
  trace <- attr(imp, "smoking_coherence_trace", exact = TRUE)
  required <- c(
    "iteration", "chains_checked",
    "unresolved_n_across_completed_chains",
    "parent_zero_child_one_n_across_completed_chains", "rule"
  )
  if (is.null(trace) || !all(required %in% names(trace))) {
    stop(
      "The CHARLS per-iteration smoking coherence trace is missing or malformed.",
      call. = FALSE
    )
  }
  trace <- trace[required]
  valid <- nrow(trace) == imp$iteration &&
    identical(as.integer(trace$iteration), seq_len(imp$iteration)) &&
    all(trace$chains_checked == imp$m) &&
    all(trace$unresolved_n_across_completed_chains == 0L) &&
    all(trace$parent_zero_child_one_n_across_completed_chains == 0L)
  if (!valid) {
    stop(
      "The CHARLS per-iteration smoking coherence trace fails its ",
      "complete zero-conflict grid contract.",
      call. = FALSE
    )
  }
  trace
}

run_mi <- function(mi_data, mi_spec, m, maxit = mi_spec$maxit) {
  maxit <- as.integer(maxit)
  if (!is.finite(maxit) || maxit < 1L) {
    stop("MICE requires at least one monitored iteration.", call. = FALSE)
  }
  restore_imputer <- register_charls_smoking_imputer()
  on.exit(restore_imputer(), add = TRUE)
  imp <- mice::mice(
    data = mi_data,
    m = m,
    maxit = 1L,
    method = mi_spec$method,
    predictorMatrix = mi_spec$predictor_matrix,
    visitSequence = mi_spec$visit_sequence,
    seed = mi_spec$seed,
    printFlag = FALSE,
    remove.collinear = FALSE,
    remove.constant = FALSE
  )
  category_trace <- record_category_trace_iteration(imp, mi_data, mi_spec)
  smoking_coherence_trace <- record_smoking_coherence_iteration(imp, mi_data)
  if (maxit > 1L) {
    for (iteration in seq.int(2L, maxit)) {
      imp <- mice::mice.mids(imp, maxit = 1L, printFlag = FALSE)
      category_trace <- dplyr::bind_rows(
        category_trace,
        record_category_trace_iteration(imp, mi_data, mi_spec)
      )
      smoking_coherence_trace <- dplyr::bind_rows(
        smoking_coherence_trace,
        record_smoking_coherence_iteration(imp, mi_data)
      )
    }
  }
  attr(imp, "category_trace") <- category_trace
  attr(imp, "smoking_coherence_trace") <- smoking_coherence_trace
  imp
}

run_mi_checked <- function(mi_data, mi_spec, m, maxit = mi_spec$maxit) {
  warnings <- character()
  imp <- withCallingHandlers(
    run_mi(mi_data, mi_spec, m = m, maxit = maxit),
    warning = function(w) {
      warnings <<- c(warnings, conditionMessage(w))
      invokeRestart("muffleWarning")
    }
  )
  mice_smoking_coherence_trace(imp)
  warnings <- unique(warnings)
  logged_events <- if (is.null(imp$loggedEvents)) 0L else nrow(imp$loggedEvents)
  if (length(warnings) || logged_events > 0L) {
    stop(
      "CHARLS MICE emitted numerical warnings or logged events: warnings=",
      if (length(warnings)) paste(warnings, collapse = " | ") else "0",
      "; logged_events=", logged_events,
      call. = FALSE
    )
  }
  imp
}

extend_mi_checked <- function(imp, mi_data, mi_spec, additional_iterations) {
  additional_iterations <- as.integer(additional_iterations)
  if (!is.finite(additional_iterations) || additional_iterations < 1L) {
    stop("MICE extension requires at least one additional iteration.", call. = FALSE)
  }
  restore_imputer <- register_charls_smoking_imputer()
  on.exit(restore_imputer(), add = TRUE)
  category_trace <- attr(imp, "category_trace", exact = TRUE)
  if (is.null(category_trace)) {
    category_trace <- data.frame(
      variable = character(), category_level = character(),
      iteration = integer(), chain = integer(), missing_n = integer(),
      value = numeric(), stringsAsFactors = FALSE
    )
  }
  smoking_coherence_trace <- attr(
    imp,
    "smoking_coherence_trace",
    exact = TRUE
  )
  if (is.null(smoking_coherence_trace)) {
    stop(
      "MICE extension requires the prior per-iteration smoking coherence trace.",
      call. = FALSE
    )
  }
  warnings <- character()
  extended <- withCallingHandlers(
    {
      current <- imp
      for (step in seq_len(additional_iterations)) {
        current <- mice::mice.mids(current, maxit = 1L, printFlag = FALSE)
        category_trace <- dplyr::bind_rows(
          category_trace,
          record_category_trace_iteration(current, mi_data, mi_spec)
        )
        smoking_coherence_trace <- dplyr::bind_rows(
          smoking_coherence_trace,
          record_smoking_coherence_iteration(current, mi_data)
        )
      }
      current
    },
    warning = function(w) {
      warnings <<- c(warnings, conditionMessage(w))
      invokeRestart("muffleWarning")
    }
  )
  attr(extended, "category_trace") <- category_trace
  attr(extended, "smoking_coherence_trace") <- smoking_coherence_trace
  mice_smoking_coherence_trace(extended)
  warnings <- unique(warnings)
  logged_events <- if (is.null(extended$loggedEvents)) 0L else nrow(extended$loggedEvents)
  if (length(warnings) || logged_events > 0L) {
    stop(
      "Extended CHARLS MICE emitted numerical warnings or logged events: warnings=",
      if (length(warnings)) paste(warnings, collapse = " | ") else "0",
      "; logged_events=", logged_events,
      call. = FALSE
    )
  }
  extended
}

mice_category_trace <- function(imp, mi_data, mi_spec) {
  targets <- mi_spec$unordered_multicategory_targets
  empty <- data.frame(
    variable = character(), category_level = character(),
    iteration = integer(), chain = integer(), missing_n = integer(),
    value = numeric(), stringsAsFactors = FALSE
  )
  if (!length(targets)) return(empty)
  trace <- attr(imp, "category_trace", exact = TRUE)
  required <- names(empty)
  if (is.null(trace) || !all(required %in% names(trace))) {
    stop("The monitored unordered-category trace is missing or malformed.", call. = FALSE)
  }
  trace <- trace[required]
  expected_rows <- sum(vapply(targets, function(variable) {
    nlevels(mi_data[[variable]]) * imp$iteration * imp$m
  }, numeric(1)))
  key <- paste(
    trace$variable, trace$category_level, trace$iteration, trace$chain,
    sep = "\r"
  )
  basic_ok <- nrow(trace) == expected_rows &&
    !anyDuplicated(key) &&
    setequal(unique(trace$variable), targets) &&
    all(is.finite(trace$value)) &&
    all(trace$value >= 0 & trace$value <= 1) &&
    all(trace$iteration %in% seq_len(imp$iteration)) &&
    all(trace$chain %in% seq_len(imp$m))
  if (!basic_ok) {
    stop("The monitored unordered-category trace fails its complete-grid contract.", call. = FALSE)
  }
  for (variable in targets) {
    levels_expected <- levels(mi_data[[variable]])
    missing_expected <- sum(is.na(mi_data[[variable]]))
    selected <- trace$variable == variable
    current <- trace[selected, , drop = FALSE]
    if (!setequal(unique(current$category_level), levels_expected) ||
        any(current$missing_n != missing_expected)) {
      stop("The monitored category levels or missing count changed for ", variable, call. = FALSE)
    }
    sums <- stats::aggregate(
      value ~ iteration + chain,
      data = current,
      FUN = sum
    )
    grid_ok <- abs(current$value * missing_expected -
                     round(current$value * missing_expected)) <= 1e-10
    if (nrow(sums) != imp$iteration * imp$m ||
        any(abs(sums$value - 1) > 1e-10) || !all(grid_ok)) {
      stop("The monitored category proportions fail simplex/grid checks for ", variable, call. = FALSE)
    }
    final <- current[current$iteration == imp$iteration, , drop = FALSE]
    for (chain in seq_len(imp$m)) {
      values <- as.character(imp$imp[[variable]][[chain]])
      expected <- tabulate(
        match(values, levels_expected),
        nbins = length(levels_expected)
      ) / missing_expected
      chain_final <- final[final$chain == chain, , drop = FALSE]
      observed <- chain_final$value[
        match(levels_expected, chain_final$category_level)
      ]
      if (length(observed) != length(expected) ||
          any(abs(observed - expected) > 1e-12)) {
        stop("The final monitored category proportions do not match mids$imp for ", variable, call. = FALSE)
      }
    }
  }
  trace[order(trace$variable, trace$category_level, trace$iteration, trace$chain), , drop = FALSE]
}

mice_chain_convergence <- function(imp, mi_data, mi_spec) {
  if (length(imp$iteration) != 1L || !is.numeric(imp$iteration) ||
      !is.finite(imp$iteration) ||
      imp$iteration < 0 || imp$iteration != as.integer(imp$iteration) ||
      length(imp$m) != 1L || !is.numeric(imp$m) || !is.finite(imp$m) ||
      imp$m < 1 || imp$m != as.integer(imp$m)) {
    stop("MICE object has an invalid iteration or chain count.", call. = FALSE)
  }
  iteration_count <- as.integer(imp$iteration)
  chain_count <- as.integer(imp$m)
  imputed_variables <- names(mi_spec$method)[nzchar(mi_spec$method)]
  missing_n <- vapply(mi_data[imputed_variables], function(x) sum(is.na(x)), integer(1))
  imputed_variables <- imputed_variables[missing_n > 0L]
  missing_n <- missing_n[imputed_variables]
  unordered_variables <- intersect(
    imputed_variables,
    mi_spec$unordered_multicategory_targets
  )
  quantitative_variables <- setdiff(imputed_variables, unordered_variables)

  split_chains <- function(values) {
    half <- floor(nrow(values) / 2L)
    if (half < 2L) return(NULL)
    cbind(
      values[seq_len(half), , drop = FALSE],
      values[seq.int(nrow(values) - half + 1L, nrow(values)), , drop = FALSE]
    )
  }

  basic_rhat <- function(values) {
    within_chain_variances <- apply(values, 2L, stats::var)
    within <- mean(within_chain_variances)
    between <- nrow(values) * stats::var(colMeans(values))
    if (!all(is.finite(c(within_chain_variances, within, between)))) return(NA_real_)
    if (within == 0 && between > 0) return(Inf)
    if (within <= 0) return(NA_real_)
    variance_plus <- ((nrow(values) - 1) / nrow(values)) * within +
      between / nrow(values)
    if (!is.finite(variance_plus) || variance_plus < 0) return(NA_real_)
    sqrt(variance_plus / within)
  }

  rank_normalize <- function(values) {
    flat <- as.vector(values)
    ranks <- rank(flat, ties.method = "average")
    matrix(
      stats::qnorm((ranks - 3 / 8) / (length(ranks) + 1 / 4)),
      nrow = nrow(values),
      ncol = ncol(values)
    )
  }

  improved_rhat <- function(values) {
    split <- split_chains(values)
    if (is.null(split) || any(!is.finite(split))) {
      return(list(
        rank_normalized = NA_real_, folded = NA_real_, maximum = NA_real_,
        raw_constant = FALSE, folded_identifiable = FALSE
      ))
    }
    raw_constant <- length(unique(as.vector(split))) < 2L
    if (raw_constant) {
      return(list(
        rank_normalized = NA_real_, folded = NA_real_, maximum = NA_real_,
        raw_constant = TRUE, folded_identifiable = FALSE
      ))
    }
    rank_rhat <- basic_rhat(rank_normalize(split))
    folded_values <- abs(split - stats::median(as.vector(split)))
    folded_identifiable <- length(unique(as.vector(folded_values))) >= 2L
    folded_rhat <- if (folded_identifiable) {
      basic_rhat(rank_normalize(folded_values))
    } else {
      NA_real_
    }
    finite_components <- c(rank_rhat, folded_rhat)
    finite_components <- finite_components[is.finite(finite_components) | is.infinite(finite_components)]
    list(
      rank_normalized = rank_rhat,
      folded = folded_rhat,
      maximum = if (length(finite_components)) max(finite_components) else NA_real_,
      raw_constant = FALSE,
      folded_identifiable = folded_identifiable
    )
  }

  classic_final_half_rhat <- function(values) {
    keep <- seq.int(floor(nrow(values) / 2L) + 1L, nrow(values))
    basic_rhat(values[keep, , drop = FALSE])
  }

  summarize_trace <- function(values) {
    lag1 <- apply(values, 2L, function(x) {
      current <- x[-1L]
      lagged <- x[-length(x)]
      if (!all(is.finite(c(current, lagged))) ||
          stats::sd(current) == 0 || stats::sd(lagged) == 0) return(NA_real_)
      stats::cor(current, lagged)
    })
    median_lag1 <- if (any(is.finite(lag1))) {
      stats::median(lag1[is.finite(lag1)])
    } else {
      NA_real_
    }
    standardized_shift <- NA_real_
    if (nrow(values) >= 10L && all(is.finite(values))) {
      previous <- values[seq.int(nrow(values) - 9L, nrow(values) - 5L), , drop = FALSE]
      final <- values[seq.int(nrow(values) - 4L, nrow(values)), , drop = FALSE]
      scale <- stats::mad(as.vector(final), constant = 1.4826)
      if (!is.finite(scale) || scale <= 0) scale <- stats::sd(as.vector(final))
      if (is.finite(scale) && scale > 0) {
        standardized_shift <- abs(mean(final) - mean(previous)) / scale
      }
    }
    list(
      median_lag1_ac = median_lag1,
      standardized_last5_shift = standardized_shift
    )
  }

  diagnostic_row <- function(
      variable, parameter, category_level, values, n_missing,
      role, applicability, detail_prefix) {
    if (is.null(dim(values))) values <- matrix(values, ncol = chain_count)
    finite <- all(is.finite(values))
    distinct_values <- length(unique(as.vector(values[is.finite(values)])))
    improved <- if (finite && nrow(values) >= 6L && ncol(values) >= 2L) {
      improved_rhat(values)
    } else {
      list(
        rank_normalized = NA_real_, folded = NA_real_, maximum = NA_real_,
        raw_constant = FALSE, folded_identifiable = FALSE
      )
    }
    trace_summary <- summarize_trace(values)
    structural_na <- role %in% c("scale", "category_scale") && n_missing == 1L
    supportive <- role == "category_scale" && !structural_na
    constant_acceptable <- improved$raw_constant &&
      role %in% c("scale", "category_location", "category_scale")
    hard_gate <- !structural_na && !supportive && !constant_acceptable
    pass <- if (structural_na || supportive || constant_acceptable) {
      TRUE
    } else {
      finite &&
        nrow(values) >= 6L &&
        ncol(values) >= 2L &&
        !improved$raw_constant &&
        is.finite(improved$rank_normalized) &&
        is.finite(improved$maximum) &&
        improved$maximum <= mi_spec$convergence_rhat_max
    }
    diagnostic_status <- if (structural_na) {
      "NOT_APPLICABLE_SINGLE_MISSING_SD"
    } else if (improved$raw_constant && role == "scale") {
      "NA_CONSTANT_SCALE"
    } else if (improved$raw_constant && role == "category_location") {
      "NA_CONSTANT_LEVEL"
    } else if (improved$raw_constant && role == "category_scale") {
      "NA_CONSTANT_CATEGORY_SCALE"
    } else if (supportive && !improved$folded_identifiable) {
      "SUPPORTIVE_CATEGORY_SCALE_BULK_ONLY"
    } else if (supportive) {
      "SUPPORTIVE_CATEGORY_SCALE"
    } else if (!pass) {
      "FAIL"
    } else if (!improved$folded_identifiable) {
      "PASS_BULK_ONLY_FOLDED_DEGENERATE"
    } else {
      "PASS"
    }
    data.frame(
      cohort = "CHARLS",
      variable = variable,
      parameter = parameter,
      category_level = category_level,
      missing_n = as.integer(n_missing),
      iterations = nrow(values),
      chains = ncol(values),
      retained_iterations = nrow(values),
      applicability = applicability,
      rank_normalized_split_rhat = improved$rank_normalized,
      folded_split_rhat = improved$folded,
      rhat = improved$maximum,
      folded_identifiable = improved$folded_identifiable,
      raw_trace_constant = improved$raw_constant,
      classic_final_half_rhat = if (finite) classic_final_half_rhat(values) else NA_real_,
      distinct_trace_values = distinct_values,
      median_lag1_ac = trace_summary$median_lag1_ac,
      standardized_last5_shift = trace_summary$standardized_last5_shift,
      hard_gate = hard_gate,
      pass = pass,
      diagnostic_status = diagnostic_status,
      detail = paste0(
        detail_prefix,
        "; improved_Rhat_threshold=", mi_spec$convergence_rhat_max,
        if (hard_gate && !pass) "; hard-gate mixing failure" else ""
      ),
      stringsAsFactors = FALSE
    )
  }

  diagnose_array <- function(array, parameter, role, transform = identity) {
    dplyr::bind_rows(lapply(quantitative_variables, function(variable) {
      array_dimensions <- dim(array)
      variable_names <- if (length(array_dimensions) == 3L) dimnames(array)[[1]] else NULL
      array_ok <- !is.null(array) &&
        length(array_dimensions) == 3L &&
        identical(as.integer(array_dimensions[2:3]), c(iteration_count, chain_count)) &&
        !is.null(variable_names) &&
        sum(variable_names == variable, na.rm = TRUE) == 1L
      if (!array_ok) {
        values <- matrix(NA_real_, nrow = iteration_count, ncol = chain_count)
        row <- diagnostic_row(
          variable, parameter, NA_character_, values, missing_n[[variable]],
          role, "DIAGNOSTIC_ARRAY_INVALID",
          "MICE chain array is missing, ambiguously named, or dimensionally inconsistent"
        )
        row$hard_gate <- TRUE
        row$pass <- FALSE
        row$diagnostic_status <- "FAIL"
        return(row)
      }
      values <- transform(array[variable, , , drop = TRUE])
      diagnostic_row(
        variable, parameter, NA_character_, values, missing_n[[variable]],
        role,
        if (role == "location") "QUANTITATIVE_LOCATION_HARD" else "QUANTITATIVE_SCALE_HARD_OR_STRUCTURAL_NA",
        if (role == "location") {
          "chain mean is a numerical hard gate regardless of the number of imputed cells"
        } else {
          "chain SD is a numerical hard gate except when one imputed cell makes SD undefined"
        }
      )
    }))
  }

  categorical_trace <- mice_category_trace(imp, mi_data, mi_spec)
  categorical_rows <- dplyr::bind_rows(lapply(unordered_variables, function(variable) {
    variable_trace <- categorical_trace[
      categorical_trace$variable == variable,
      ,
      drop = FALSE
    ]
    levels_expected <- levels(mi_data[[variable]])
    rows <- dplyr::bind_rows(lapply(levels_expected, function(category_level) {
      selected <- variable_trace[
        variable_trace$category_level == category_level,
        ,
        drop = FALSE
      ]
      values <- matrix(
        NA_real_,
        nrow = iteration_count,
        ncol = chain_count
      )
      values[cbind(selected$iteration, selected$chain)] <- selected$value
      proportion_row <- diagnostic_row(
        variable,
        paste0("category_proportion[level=", category_level, "]"),
        category_level,
        values,
        missing_n[[variable]],
        "category_location",
        "UNORDERED_CATEGORY_LEVEL_PROPORTION",
        paste0(
          "per-level indicator proportion replaces arbitrary integer-coded factor means; observed_level_n=",
          sum(as.character(mi_data[[variable]]) == category_level, na.rm = TRUE)
        )
      )
      sd_values <- if (missing_n[[variable]] > 1L) {
        sqrt(
          missing_n[[variable]] /
            (missing_n[[variable]] - 1) *
            values * (1 - values)
        )
      } else {
        matrix(NA_real_, nrow = iteration_count, ncol = chain_count)
      }
      scale_row <- diagnostic_row(
        variable,
        paste0("category_indicator_sd[level=", category_level, "]"),
        category_level,
        sd_values,
        missing_n[[variable]],
        "category_scale",
        "UNORDERED_CATEGORY_LEVEL_SCALE",
        "sample SD of the per-level indicator"
      )
      dplyr::bind_rows(proportion_row, scale_row)
    }))
    evaluable_levels <- unique(rows$category_level[
      grepl("^category_proportion", rows$parameter) &
        !rows$raw_trace_constant &
        rows$hard_gate
    ])
    coverage_pass <- length(evaluable_levels) >= 2L
    coverage <- data.frame(
      cohort = "CHARLS", variable = variable,
      parameter = "category_level_coverage",
      category_level = NA_character_, missing_n = missing_n[[variable]],
      iterations = iteration_count, chains = chain_count,
      retained_iterations = iteration_count,
      applicability = "UNORDERED_CATEGORY_COVERAGE_HARD",
      rank_normalized_split_rhat = NA_real_, folded_split_rhat = NA_real_,
      rhat = NA_real_, folded_identifiable = NA,
      raw_trace_constant = NA, classic_final_half_rhat = NA_real_,
      distinct_trace_values = length(evaluable_levels),
      median_lag1_ac = NA_real_, standardized_last5_shift = NA_real_,
      hard_gate = TRUE, pass = coverage_pass,
      diagnostic_status = if (coverage_pass) "PASS" else "FAIL",
      detail = paste0(
        "at least two nonconstant per-level proportion traces required; evaluable_levels=",
        paste(evaluable_levels, collapse = "|")
      ),
      stringsAsFactors = FALSE
    )
    dplyr::bind_rows(rows, coverage)
  }))

  final_variation_rows <- dplyr::bind_rows(lapply(imputed_variables, function(variable) {
    values <- imp$imp[[variable]]
    valid <- !is.null(values) &&
      nrow(values) == missing_n[[variable]] &&
      ncol(values) == chain_count &&
      !anyNA(values)
    row_varies <- if (valid) {
      apply(values, 1L, function(x) length(unique(as.character(x))) > 1L)
    } else {
      logical()
    }
    varying_rows <- sum(row_varies)
    variation_pass <- valid && varying_rows > 0L
    data.frame(
      cohort = "CHARLS", variable = variable,
      parameter = "final_between_imputation_variation",
      category_level = NA_character_, missing_n = missing_n[[variable]],
      iterations = iteration_count, chains = chain_count,
      retained_iterations = 0L,
      applicability = "FINAL_IMPUTATION_VARIATION_HARD",
      rank_normalized_split_rhat = NA_real_, folded_split_rhat = NA_real_,
      rhat = NA_real_, folded_identifiable = NA,
      raw_trace_constant = if (valid) !variation_pass else NA,
      classic_final_half_rhat = NA_real_,
      distinct_trace_values = varying_rows,
      median_lag1_ac = NA_real_, standardized_last5_shift = NA_real_,
      hard_gate = TRUE, pass = variation_pass,
      diagnostic_status = if (variation_pass) "PASS" else "FAIL",
      detail = paste0(
        "at least one missing cell must vary across the final ", chain_count,
        " imputations; varying_missing_rows=", varying_rows,
        "/", missing_n[[variable]],
        if (!valid) "; final mids$imp object is missing, incomplete, or contains NA" else ""
      ),
      stringsAsFactors = FALSE
    )
  }))

  diagnostics <- dplyr::bind_rows(
    diagnose_array(imp$chainMean, "chain_mean", "location"),
    diagnose_array(imp$chainVar, "chain_sd", "scale", transform = sqrt),
    categorical_rows,
    final_variation_rows
  )
  if (!nrow(diagnostics)) {
    diagnostics <- data.frame(
      cohort = "CHARLS", variable = NA_character_, parameter = "none",
      category_level = NA_character_, missing_n = 0L,
      iterations = iteration_count, chains = chain_count,
      retained_iterations = 0L, applicability = "NOT_APPLICABLE_NO_MISSING",
      rank_normalized_split_rhat = NA_real_, folded_split_rhat = NA_real_,
      rhat = NA_real_, folded_identifiable = NA,
      raw_trace_constant = NA, classic_final_half_rhat = NA_real_,
      distinct_trace_values = 0L, median_lag1_ac = NA_real_,
      standardized_last5_shift = NA_real_, hard_gate = FALSE, pass = TRUE,
      diagnostic_status = "NOT_APPLICABLE_NO_MISSING",
      detail = "No variable required imputation.", stringsAsFactors = FALSE
    )
  }
  diagnostics
}

mice_chain_trace <- function(imp, convergence, mi_data, mi_spec) {
  arrays <- list(chain_mean = imp$chainMean, chain_sd = sqrt(imp$chainVar))
  categorical_trace <- mice_category_trace(imp, mi_data, mi_spec)
  release <- convergence[
    convergence$hard_gate %in% TRUE &
      convergence$pass %in% TRUE &
      convergence$missing_n >= mi_spec$trace_release_missing_n_min &
      (
        convergence$parameter %in% names(arrays) |
          grepl("^category_proportion", convergence$parameter)
      ),
    c("variable", "parameter", "category_level", "missing_n"),
    drop = FALSE
  ]
  if (!nrow(release)) {
    return(data.frame(
      cohort = "CHARLS", variable = NA_character_, parameter = "none",
      category_level = NA_character_, missing_n = 0L,
      iteration = NA_integer_, chain = NA_integer_, value = NA_real_,
      trace_release_status = "NO_RELEASE_ELIGIBLE_TRACE",
      stringsAsFactors = FALSE
    ))
  }
  dplyr::bind_rows(lapply(seq_len(nrow(release)), function(i) {
    variable <- release$variable[[i]]
    parameter <- release$parameter[[i]]
    category_level <- release$category_level[[i]]
    if (parameter %in% names(arrays)) {
      values <- arrays[[parameter]][variable, , , drop = TRUE]
      if (is.null(dim(values))) values <- matrix(values, ncol = imp$m)
    } else {
      selected <- categorical_trace[
        categorical_trace$variable == variable &
          categorical_trace$category_level == category_level,
        ,
        drop = FALSE
      ]
      values <- matrix(NA_real_, nrow = imp$iteration, ncol = imp$m)
      values[cbind(selected$iteration, selected$chain)] <- selected$value
      if (grepl("^category_indicator_sd", parameter)) {
        n_missing <- release$missing_n[[i]]
        values <- sqrt(n_missing / (n_missing - 1) * values * (1 - values))
      }
    }
    grid <- expand.grid(
      iteration = seq_len(nrow(values)),
      chain = seq_len(ncol(values)),
      KEEP.OUT.ATTRS = FALSE,
      stringsAsFactors = FALSE
    )
    data.frame(
      cohort = "CHARLS", variable = variable, parameter = parameter,
      category_level = category_level, missing_n = release$missing_n[[i]],
      iteration = grid$iteration, chain = grid$chain,
      value = as.vector(values),
      trace_release_status = "RELEASED_HARD_GATE_AGGREGATE",
      stringsAsFactors = FALSE
    )
  }))
}

format_mice_convergence_failures <- function(convergence) {
  failed <- convergence[
    convergence$hard_gate %in% TRUE & !(convergence$pass %in% TRUE),
    ,
    drop = FALSE
  ]
  if (!nrow(failed)) return("none")
  paste(
    paste0(
      failed$variable, "/", failed$parameter,
      "[missing_n=", failed$missing_n,
      ",rank_Rhat=", signif(failed$rank_normalized_split_rhat, 4),
      ",folded_Rhat=", signif(failed$folded_split_rhat, 4),
      ",max_Rhat=", signif(failed$rhat, 4),
      ",status=", failed$diagnostic_status,
      "]"
    ),
    collapse = "; "
  )
}

new_stage3_mice_convergence_error <- function(message, checkpoints) {
  structure(
    list(
      message = one_line(message),
      call = NULL,
      checkpoint_diagnostics = checkpoints
    ),
    class = c("stage3_mice_convergence_error", "error", "condition")
  )
}

run_mi_convergence_schedule <- function(
    mi_data, mi_spec, m, analysis_id, mi_run) {
  checkpoints <- sort(unique(as.integer(mi_spec$convergence_iteration_checkpoints)))
  if (!length(checkpoints) || anyNA(checkpoints) ||
      any(!is.finite(checkpoints)) || any(checkpoints < 1L) ||
      checkpoints[[1]] != mi_spec$maxit ||
      tail(checkpoints, 1L) != mi_spec$maximum_maxit ||
      any(diff(checkpoints) <= 0L)) {
    stop("The frozen MICE convergence checkpoint schedule is invalid.", call. = FALSE)
  }
  imp <- NULL
  history <- list()
  for (checkpoint_order in seq_along(checkpoints)) {
    target <- checkpoints[[checkpoint_order]]
    imp <- tryCatch(
      {
        if (is.null(imp)) {
          run_mi_checked(mi_data, mi_spec, m = m, maxit = target)
        } else {
          extend_mi_checked(
            imp, mi_data, mi_spec,
            target - as.integer(imp$iteration)
          )
        }
      },
      error = function(e) {
        prior <- dplyr::bind_rows(history)
        stop(new_stage3_mice_convergence_error(
          paste0(
            "MICE failed while advancing to checkpoint ", target,
            " for ", analysis_id, "/", mi_run, ": ", conditionMessage(e)
          ),
          prior
        ))
      }
    )
    convergence <- tryCatch(
      mice_chain_convergence(imp, mi_data, mi_spec),
      error = function(e) {
        prior <- dplyr::bind_rows(history)
        stop(new_stage3_mice_convergence_error(
          paste0(
            "MICE convergence diagnostics failed at checkpoint ", target,
            " for ", analysis_id, "/", mi_run, ": ", conditionMessage(e)
          ),
          prior
        ))
      }
    )
    convergence$analysis_id <- analysis_id
    convergence$mi_run <- mi_run
    convergence$checkpoint_order <- checkpoint_order
    convergence$checkpoint_iteration <- target
    convergence$selected_checkpoint <- FALSE
    history[[length(history) + 1L]] <- convergence
    failed <- convergence$hard_gate %in% TRUE &
      !(convergence$pass %in% TRUE)
    if (!any(failed)) {
      convergence$selected_checkpoint <- TRUE
      checkpoint_diagnostics <- dplyr::bind_rows(history)
      checkpoint_diagnostics$selected_checkpoint <-
        checkpoint_diagnostics$checkpoint_order == checkpoint_order
      return(list(
        imp = imp,
        final_convergence = convergence,
        checkpoint_diagnostics = checkpoint_diagnostics,
        selected_maxit = target
      ))
    }
  }
  checkpoint_diagnostics <- dplyr::bind_rows(history)
  checkpoint_diagnostics$selected_checkpoint <-
    checkpoint_diagnostics$checkpoint_order == length(checkpoints)
  stop(new_stage3_mice_convergence_error(
    paste0(
      "MICE mixing fails the frozen improved-Rhat <= ",
      mi_spec$convergence_rhat_max,
      " gate through ", tail(checkpoints, 1L), " iterations for ",
      analysis_id, "/", mi_run, ": ",
      format_mice_convergence_failures(tail(history, 1L)[[1L]])
    ),
    checkpoint_diagnostics
  ))
}

model_formulas <- function(exposure = "E0", spline_exposure = FALSE) {
  exposure_term <- if (spline_exposure) {
    "E0_linear + E0_nonlinear1 + E0_nonlinear2"
  } else {
    exposure
  }
  # Post-estimability amendment: W1_W3, W1_W4, and W2_W4 are all-event
  # transition pathways after skipped unknown waves. Treating
  # those pathways as nuisance-factor levels therefore creates structural
  # separation. End-wave strata retain both outcome states, while the
  # scheduled-wave duration enters as a prespecified log offset.
  time_term <- "factor(end_wave) + offset(log(nominal_years))"
  a0 <- paste(
    "period_event ~", exposure_term,
    "+ age_ns1 + age_ns2 + age_ns3",
    "+ factor(sex_code)",
    "+ height_ns1 + height_ns2 + height_ns3",
    "+", time_term
  )
  a1 <- paste(
    a0,
    "+ factor(smoking_status_3)",
    "+ bmi_ns1 + bmi_ns2 + bmi_ns3",
    "+ factor(raeducl) + factor(h1rural) + log_hh1cperc"
  )
  a2 <- paste(
    a1,
    "+ lung_w1 + asthma_w1",
    "+ nonpulmonary_comorbidity_count + frailty_proxy_count_w1"
  )
  list(A0 = stats::as.formula(a0), A1 = stats::as.formula(a1), A2 = stats::as.formula(a2))
}

validate_inferential_time_formula <- function(formula, model_id) {
  formula_terms <- stats::terms(formula)
  term_labels <- attr(formula_terms, "term.labels")
  required <- "factor(end_wave) + offset(log(nominal_years))"
  formula_text <- paste(deparse(formula), collapse = " ")
  has_required <- "factor(end_wave)" %in% term_labels &&
    length(attr(formula_terms, "offset")) == 1L &&
    grepl(
      "offset\\s*\\(\\s*log\\s*\\(\\s*nominal_years\\s*\\)\\s*\\)",
      formula_text
    )
  uses_window_id <- grepl("\\bwindow_id\\b", formula_text)
  exposure_time_interaction <- any(
    grepl(":", term_labels, fixed = TRUE) &
      grepl("E0", term_labels, fixed = TRUE) &
      grepl("end_wave|nominal_years|window_id", term_labels)
  )
  if (!has_required || uses_window_id || exposure_time_interaction) {
    stop(
      model_id,
      " violates the amended inferential-time contract: required=",
      required,
      paste(
        "; transition-pathway terms and exposure-by-time interactions",
        "are forbidden; formula="
      ),
      formula_text,
      call. = FALSE
    )
  }
  invisible(TRUE)
}

capture_fit <- function(expr) {
  warnings <- character()
  value <- withCallingHandlers(
    tryCatch(expr, error = function(e) structure(list(error = conditionMessage(e)), class = "stage3_fit_error")),
    warning = function(w) {
      warnings <<- c(warnings, conditionMessage(w))
      invokeRestart("muffleWarning")
    }
  )
  list(value = value, warnings = unique(warnings))
}

validate_covariance_matrix <- function(variance, coefficient_names, context) {
  variance <- as.matrix(variance)
  p <- length(coefficient_names)
  if (!identical(dim(variance), c(p, p))) {
    stop(context, " covariance dimension does not match the coefficient vector.", call. = FALSE)
  }
  if (is.null(rownames(variance)) || is.null(colnames(variance)) ||
      !identical(rownames(variance), coefficient_names) ||
      !identical(colnames(variance), coefficient_names)) {
    stop(context, " covariance names/order do not match the coefficient vector.", call. = FALSE)
  }
  if (any(!is.finite(variance))) {
    stop(context, " covariance matrix contains non-finite values.", call. = FALSE)
  }
  scale <- max(.Machine$double.xmin, max(abs(variance)))
  symmetry_error <- max(abs(variance - t(variance)))
  if (!is.finite(symmetry_error) ||
      symmetry_error > sqrt(.Machine$double.eps) * scale) {
    stop(context, " covariance matrix is not symmetric within numerical tolerance.", call. = FALSE)
  }
  symmetric_variance <- (variance + t(variance)) / 2
  eigenvalues <- eigen(symmetric_variance, symmetric = TRUE, only.values = TRUE)$values
  eigenvalue_scale <- max(abs(eigenvalues))
  positive_tolerance <- max(
    .Machine$double.xmin,
    .Machine$double.eps * max(1, p) * eigenvalue_scale
  )
  if (any(!is.finite(eigenvalues)) || min(eigenvalues) <= positive_tolerance) {
    stop(context, " covariance matrix is not numerically positive definite.", call. = FALSE)
  }
  list(
    matrix = symmetric_variance,
    symmetry_error = symmetry_error,
    minimum_eigenvalue = min(eigenvalues),
    condition_number = max(eigenvalues) / min(eigenvalues)
  )
}

time_basis_support_audit <- function(
    person_data, period_skeleton, sample_id, hard_stop = TRUE) {
  person_required <- c(
    "participant_id", "community_id", "weight_biomarker_w1", "E0"
  )
  period_required <- c(
    "participant_id", "community_id", "weight_biomarker_w1",
    "start_wave", "end_wave", "window_id", "period_event", "nominal_years"
  )
  missing_person <- setdiff(person_required, names(person_data))
  missing_period <- setdiff(period_required, names(period_skeleton))
  if (length(missing_person) || length(missing_period)) {
    stop(
      sample_id, " time-basis support audit lacks required fields: person=",
      paste(missing_person, collapse = "|"), "; period=",
      paste(missing_period, collapse = "|"),
      call. = FALSE
    )
  }
  assert_unique_id(
    person_data,
    "participant_id",
    paste0(sample_id, " time-basis-support person-level data")
  )
  if (!nrow(person_data) || !nrow(period_skeleton)) {
    stop(sample_id, " time-basis support audit received an empty sample.", call. = FALSE)
  }
  pp <- dplyr::inner_join(
    period_skeleton[period_required],
    person_data[c(
      "participant_id", "community_id", "weight_biomarker_w1", "E0"
    )],
    by = "participant_id"
  )
  if (nrow(pp) != nrow(period_skeleton) ||
      anyNA(pp$participant_id) ||
      anyNA(pp$community_id.x) ||
      anyNA(pp$community_id.y) ||
      any(!pp$period_event %in% 0:1) ||
      any(!is.finite(pp$end_wave)) ||
      any(!is.finite(pp$nominal_years) | pp$nominal_years <= 0) ||
      any(!is.finite(pp$weight_biomarker_w1.x) |
        pp$weight_biomarker_w1.x <= 0) ||
      any(!is.finite(pp$weight_biomarker_w1.y) |
        pp$weight_biomarker_w1.y <= 0) ||
      any(!is.finite(pp$E0))) {
    stop(
      sample_id,
      " time-basis support audit found an incomplete join, invalid outcome, ",
      "nonpositive nominal duration, or nonfinite E0.",
      call. = FALSE
    )
  }
  if (any(
    as.character(pp$community_id.x) != as.character(pp$community_id.y)
  ) || any(
    abs(pp$weight_biomarker_w1.x - pp$weight_biomarker_w1.y) >
      sqrt(.Machine$double.eps) *
        pmax(1, abs(pp$weight_biomarker_w1.x))
  )) {
    stop(
      sample_id,
      " time-basis support audit found a person/period community or weight mismatch.",
      call. = FALSE
    )
  }
  pp$community_id <- pp$community_id.x
  pp$community_id.x <- NULL
  pp$community_id.y <- NULL
  pp$weight_biomarker_w1 <- pp$weight_biomarker_w1.x
  pp$weight_biomarker_w1.x <- NULL
  pp$weight_biomarker_w1.y <- NULL

  finite_range <- function(x) {
    x <- x[is.finite(x)]
    if (!length(x)) c(NA_real_, NA_real_) else range(x)
  }
  rows <- lapply(sort(unique(pp$end_wave)), function(wave) {
    dat <- pp[pp$end_wave == wave, , drop = FALSE]
    event <- dat$period_event == 1L
    event_range <- finite_range(dat$E0[event])
    nonevent_range <- finite_range(dat$E0[!event])
    event_sd <- if (sum(event) >= 2L) stats::sd(dat$E0[event]) else NA_real_
    nonevent_sd <- if (sum(!event) >= 2L) stats::sd(dat$E0[!event]) else NA_real_
    overlap_low <- max(event_range[[1]], nonevent_range[[1]])
    overlap_high <- min(event_range[[2]], nonevent_range[[2]])
    outcome_overlap <- any(event) && any(!event)
    exposure_overlap <- outcome_overlap &&
      is.finite(overlap_low) && is.finite(overlap_high) &&
      overlap_high > overlap_low
    baseline_stratum_outcome_support <- outcome_overlap &&
      all(is.finite(dat$nominal_years) & dat$nominal_years > 0) &&
      sum(dat$weight_biomarker_w1[event]) > 0 &&
      sum(dat$weight_biomarker_w1[!event]) > 0
    e0_marginal_overlap <- exposure_overlap &&
      is.finite(event_sd) && event_sd > 0 &&
      is.finite(nonevent_sd) && nonevent_sd > 0
    event_psu <- length(unique(dat$community_id[event]))
    nonevent_psu <- length(unique(dat$community_id[!event]))
    cluster_support <- event_psu >= 2L && nonevent_psu >= 2L
    data.frame(
      cohort = "CHARLS",
      audit_type = "time_basis_support_end_wave",
      stratum = paste0(sample_id, "::end_wave_W", wave),
      sample_id = sample_id,
      time_basis = "factor(end_wave) + offset(log(nominal_years))",
      end_wave = as.integer(wave),
      descriptive_start_waves =
        paste(sort(unique(dat$start_wave)), collapse = "|"),
      descriptive_window_ids =
        paste(sort(unique(as.character(dat$window_id))), collapse = "|"),
      n_people = length(unique(dat$participant_id)),
      transition_rows = nrow(dat),
      deaths = sum(event),
      non_deaths = sum(!event),
      weighted_events = sum(dat$weight_biomarker_w1[event]),
      weighted_non_events = sum(dat$weight_biomarker_w1[!event]),
      outcome_event_fraction = mean(event),
      weighted_event_fraction =
        sum(dat$weight_biomarker_w1[event]) /
          sum(dat$weight_biomarker_w1),
      minimum_outcome_cell = min(sum(event), sum(!event)),
      community_psu = length(unique(dat$community_id)),
      event_psu = event_psu,
      non_event_psu = nonevent_psu,
      nominal_years_min = min(dat$nominal_years),
      nominal_years_max = max(dat$nominal_years),
      event_e0_min = event_range[[1]],
      event_e0_max = event_range[[2]],
      event_e0_sd = event_sd,
      non_event_e0_min = nonevent_range[[1]],
      non_event_e0_max = nonevent_range[[2]],
      non_event_e0_sd = nonevent_sd,
      e0_overlap_low = overlap_low,
      e0_overlap_high = overlap_high,
      e0_overlap_width = overlap_high - overlap_low,
      outcome_overlap_pass = outcome_overlap,
      exposure_overlap_pass = exposure_overlap,
      baseline_stratum_outcome_support_pass =
        baseline_stratum_outcome_support,
      e0_marginal_overlap_pass = e0_marginal_overlap,
      cluster_support_pass = cluster_support,
      time_basis_support_pass =
        baseline_stratum_outcome_support &&
          e0_marginal_overlap && cluster_support,
      time_basis_support_status =
        if (outcome_overlap) "OUTCOME_OVERLAP" else "SEPARATED",
      analysis_action = "REGISTERED_TIME_BASIS",
      detail = paste(
        "necessary pre-fit time-basis support gate: both outcome states within",
        "every inferential end-wave stratum, overlapping observed E0 ranges,",
        "and >=2 community PSUs supporting each outcome state; this does not",
        "prove absence of multivariable separation, which is additionally",
        "guarded by rank, warning, boundary, finite-coefficient/covariance, and",
        "fitted-probability checks at runtime; window_id is descriptive only"
      ),
      stringsAsFactors = FALSE
    )
  })
  audit <- dplyr::bind_rows(rows)
  if (!nrow(audit) || anyDuplicated(audit$stratum)) {
    stop(sample_id, " time-basis support audit is empty or duplicated.", call. = FALSE)
  }
  failed <- !(audit$time_basis_support_pass %in% TRUE)
  if (any(failed) && isTRUE(hard_stop)) {
    stop(
      sample_id,
      " fails the necessary pre-fit time-basis outcome-support gate: ",
      paste(
        paste0(
          audit$stratum[failed],
          "[events=", audit$deaths[failed],
          ",non_events=", audit$non_deaths[failed],
          ",event_psu=", audit$event_psu[failed],
          ",non_event_psu=", audit$non_event_psu[failed],
          ",E0_overlap=", signif(audit$e0_overlap_width[failed], 6),
          "]"
        ),
        collapse = "; "
      ),
      call. = FALSE
    )
  }
  audit
}

fit_one_survey_model <- function(person_data, period_skeleton, formula, model_id) {
  validate_inferential_time_formula(formula, model_id)
  assert_unique_id(person_data, "participant_id", paste0(model_id, " person-level data"))
  transition_fields <- c(
    "participant_id", "start_wave", "end_wave", "window_id",
    "period_event", "nominal_years"
  )
  period_ids <- unique(period_skeleton$participant_id)
  if (anyNA(period_ids) || !all(period_ids %in% person_data$participant_id)) {
    stop(model_id, " person-level data do not cover every person-period participant.", call. = FALSE)
  }
  pp <- dplyr::inner_join(
    period_skeleton[transition_fields],
    person_data,
    by = "participant_id"
  )
  if (nrow(pp) != nrow(period_skeleton)) {
    stop("Person-period join did not preserve transition rows for ", model_id, call. = FALSE)
  }
  # Re-run the same aggregate gate immediately before every outcome fit. This
  # covers MI, complete-case, measurement sensitivities, the W2 landmark, and
  # leave-one-PSU refits without retaining any additional row-level object.
  invisible(time_basis_support_audit(
    person_data,
    period_skeleton,
    sample_id = model_id,
    hard_stop = TRUE
  ))
  mm <- stats::model.matrix(formula, data = pp)
  if (nrow(mm) != nrow(pp)) {
    stop(model_id, " model matrix omitted one or more person-period rows.", call. = FALSE)
  }
  rank <- qr(mm)$rank
  full_rank <- rank == ncol(mm)
  if (!full_rank) stop("Rank-deficient design matrix for ", model_id, call. = FALSE)

  design <- survey::svydesign(
    ids = ~community_id + participant_id,
    weights = ~weight_biomarker_w1,
    data = pp,
    nest = TRUE
  )
  fit_obj <- capture_fit(survey::svyglm(
    formula,
    design = design,
    family = stats::quasibinomial(link = "cloglog")
  ))
  if (inherits(fit_obj$value, "stage3_fit_error")) {
    stop(model_id, " failed: ", fit_obj$value$error, call. = FALSE)
  }
  fit <- fit_obj$value
  if (!isTRUE(fit$converged)) {
    stop(model_id, " did not converge.", call. = FALSE)
  }
  if (length(fit_obj$warnings)) {
    stop(
      model_id,
      " emitted one or more survey-GLM warnings: ",
      one_line(fit_obj$warnings),
      call. = FALSE
    )
  }
  if (length(fit$boundary) != 1L || is.na(fit$boundary)) {
    stop(model_id, " did not report a valid GLM boundary diagnostic.", call. = FALSE)
  }
  if (isTRUE(fit$boundary)) {
    stop(model_id, " converged on a GLM boundary.", call. = FALSE)
  }
  coefficients <- stats::coef(fit)
  if (!length(coefficients) || is.null(names(coefficients)) ||
      anyNA(names(coefficients)) || any(!nzchar(names(coefficients))) ||
      anyDuplicated(names(coefficients)) || any(!is.finite(coefficients))) {
    stop(model_id, " produced an empty, unnamed, or non-finite coefficient vector.", call. = FALSE)
  }
  covariance_check <- validate_covariance_matrix(stats::vcov(fit), names(coefficients), model_id)
  variance <- covariance_check$matrix
  design_df <- survey::degf(design)
  if (length(design_df) != 1L || !is.finite(design_df) || design_df <= 0) {
    stop(model_id, " has nonpositive or non-finite survey design degrees of freedom.", call. = FALSE)
  }
  fitted <- stats::fitted(fit)
  if (length(fitted) != nrow(pp) ||
      any(!is.finite(fitted)) || any(fitted <= 0 | fitted >= 1)) {
    stop(model_id, " produced invalid fitted probabilities.", call. = FALSE)
  }
  if (any(fitted > 1 - 1e-6)) {
    stop(
      model_id,
      " produced one or more fitted probabilities within 1e-6 of one; ",
      "the finite multivariable fit gate therefore fails.",
      call. = FALSE
    )
  }

  # Never retain the full svyglm object across imputations. It contains the
  # person-period model frame, QR decomposition, fitted/residual vectors, and
  # survey design. Keeping 3 tiers x 50 imputations can exhaust R's vector heap
  # even though every downstream calculation uses only the validated compact
  # coefficient, covariance, and diagnostic summaries below.
  list(
    coefficients = coefficients,
    variance = variance,
    diagnostics = data.frame(
      cohort = "CHARLS",
      model_id = model_id,
      n_participants = length(unique(pp$participant_id)),
      n_person_period_rows = nrow(pp),
      events = sum(pp$period_event),
      nominal_person_years = sum(pp$nominal_years),
      time_basis = "factor(end_wave) + offset(log(nominal_years))",
      exact_death_date_used = FALSE,
      prefit_time_basis_support_gate = "PASS",
      runtime_multivariable_finite_fit_gate = "PASS",
      design_psu = length(unique(pp$community_id)),
      design_df = design_df,
      glm_converged = isTRUE(fit$converged),
      glm_boundary = isTRUE(fit$boundary),
      glm_iterations = if (length(fit$iter)) as.integer(fit$iter[[1]]) else NA_integer_,
      matrix_columns = ncol(mm),
      matrix_rank = rank,
      covariance_symmetry_error = covariance_check$symmetry_error,
      covariance_minimum_eigenvalue = covariance_check$minimum_eigenvalue,
      covariance_condition_number = covariance_check$condition_number,
      fitted_probability_min = min(fitted, na.rm = TRUE),
      fitted_probability_max = max(fitted, na.rm = TRUE),
      fitted_probability_near_zero = sum(fitted < 1e-6, na.rm = TRUE),
      fitted_probability_near_one = sum(fitted > 1 - 1e-6, na.rm = TRUE),
      warnings = one_line(fit_obj$warnings),
      stringsAsFactors = FALSE
    )
  )
}

fit_across_imputations <- function(imp, period_skeleton, knots, formulas, model_prefix) {
  m <- imp$m
  tiers <- names(formulas)
  fits <- setNames(vector("list", length(tiers)), tiers)
  for (tier in tiers) fits[[tier]] <- vector("list", m)

  for (j in seq_len(m)) {
    completed <- mice::complete(imp, action = j)
    completed <- attach_passive_variables(completed, knots)
    for (tier in tiers) {
      compact_fit <- fit_one_survey_model(
        completed,
        period_skeleton,
        formulas[[tier]],
        paste0(model_prefix, "_", tolower(tier), "_imp", j)
      )
      if (!identical(
        names(compact_fit),
        c("coefficients", "variance", "diagnostics")
      )) {
        stop(
          "The CHARLS imputation fit retained an unauthorized noncompact ",
          "component for ", model_prefix, "/", tier, "/imp", j,
          call. = FALSE
        )
      }
      fits[[tier]][[j]] <- compact_fit
    }
    rm(completed, compact_fit)
    # Explicit collection controls the transient svyglm/survey-design peak.
    # It consumes no random numbers and cannot alter fitted estimates.
    if (j %% 5L == 0L || j == m) invisible(gc(verbose = FALSE))
  }
  fits
}

pool_scalar_rubin <- function(fits, term) {
  if (length(term) != 1L || is.na(term) || !nzchar(term)) {
    stop("Rubin pooling requires one nonempty coefficient term.", call. = FALSE)
  }
  if (length(fits) < 2L) stop("Rubin pooling requires at least two imputations.", call. = FALSE)
  if (!all(vapply(fits, function(x) term %in% names(x$coefficients), logical(1)))) {
    stop("Rubin pooling term is absent from one or more fitted models: ", term, call. = FALSE)
  }
  q <- vapply(fits, function(x) unname(x$coefficients[[term]]), numeric(1))
  u <- vapply(fits, function(x) unname(x$variance[term, term]), numeric(1))
  df_complete <- min(vapply(fits, function(x) x$diagnostics$design_df[[1]], numeric(1)))
  if (any(!is.finite(q)) || any(!is.finite(u)) || any(u <= 0) ||
      !is.finite(df_complete) || df_complete <= 0) {
    stop("Invalid coefficient, within-imputation variance, or complete-data design df for Rubin pooling.", call. = FALSE)
  }
  pooled <- mice::pool.scalar(q, u, n = df_complete + 1, k = 1, rule = "rubin1987")
  m <- pooled$m
  qbar <- pooled$qbar
  ubar <- pooled$ubar
  b <- pooled$b
  total <- pooled$t
  se <- sqrt(total)
  relative_increase <- pooled$r
  df <- pooled$df
  statistic <- qbar / se
  fmi <- pooled$fmi
  if (!is.finite(qbar) || !is.finite(se) || se <= 0 ||
      (!is.finite(df) && !is.infinite(df)) || df <= 0 ||
      !is.finite(fmi) || fmi < -1e-10 || fmi > 1 + 1e-10) {
    stop("Barnard-Rubin scalar pooling produced an invalid estimate, SE, df, or FMI.", call. = FALSE)
  }
  p <- if (is.finite(df)) {
    2 * stats::pt(abs(statistic), df = df, lower.tail = FALSE)
  } else {
    2 * stats::pnorm(abs(statistic), lower.tail = FALSE)
  }
  data.frame(
    term = term,
    pooling_rule = "Rubin 1987 with Barnard-Rubin small-sample df; dfcom=minimum survey design df",
    m = m,
    estimate = qbar,
    standard_error = se,
    ci_low = qbar - stats::qt(0.975, df = df) * se,
    ci_high = qbar + stats::qt(0.975, df = df) * se,
    p_value = p,
    within_variance = ubar,
    between_variance = b,
    total_variance = total,
    df = df,
    complete_data_design_df = df_complete,
    relative_increase_variance = relative_increase,
    fraction_missing_information = fmi,
    relative_efficiency = 1 / (1 + fmi / m),
    monte_carlo_error = sqrt(b / m),
    monte_carlo_error_fraction = sqrt(b / m) / se,
    stringsAsFactors = FALSE
  )
}

pool_linear_combination_rubin <- function(fits, weights, contrast_id) {
  if (length(fits) < 2L || !length(weights) || is.null(names(weights)) ||
      anyNA(names(weights)) || any(!nzchar(names(weights))) ||
      anyDuplicated(names(weights)) || any(!is.finite(weights)) || all(weights == 0)) {
    stop("Invalid fitted-model list or coefficient weights for Rubin contrast pooling.", call. = FALSE)
  }
  if (!all(vapply(fits, function(x) all(names(weights) %in% names(x$coefficients)), logical(1)))) {
    stop("One or more Rubin contrast terms are absent from a fitted model.", call. = FALSE)
  }
  q <- vapply(fits, function(x) {
    beta <- x$coefficients
    sum(beta[names(weights)] * weights)
  }, numeric(1))
  u <- vapply(fits, function(x) {
    variance <- x$variance[names(weights), names(weights), drop = FALSE]
    as.numeric(t(weights) %*% variance %*% weights)
  }, numeric(1))
  df_complete <- min(vapply(fits, function(x) x$diagnostics$design_df[[1]], numeric(1)))
  if (any(!is.finite(q)) || any(!is.finite(u)) || any(u <= 0) ||
      !is.finite(df_complete) || df_complete <= 0) {
    stop("Invalid contrast, within-imputation variance, or complete-data design df for Rubin pooling.", call. = FALSE)
  }
  pooled <- mice::pool.scalar(q, u, n = df_complete + 1, k = 1, rule = "rubin1987")
  m <- pooled$m
  qbar <- pooled$qbar
  total <- pooled$t
  se <- sqrt(total)
  df <- pooled$df
  if (!is.finite(qbar) || !is.finite(se) || se <= 0 ||
      (!is.finite(df) && !is.infinite(df)) || df <= 0) {
    stop("Barnard-Rubin contrast pooling produced an invalid estimate, SE, or df.", call. = FALSE)
  }
  critical <- if (is.finite(df)) stats::qt(0.975, df) else stats::qnorm(0.975)
  data.frame(
    test_id = contrast_id,
    pooling_rule = "Rubin 1987 contrast pooling with Barnard-Rubin small-sample df; dfcom=minimum survey design df",
    terms = paste(paste(names(weights), weights, sep = "*"), collapse = " + "),
    df = df,
    complete_data_design_df = df_complete,
    statistic = qbar / se,
    p_value = if (is.finite(df)) {
      2 * stats::pt(abs(qbar / se), df, lower.tail = FALSE)
    } else {
      2 * stats::pnorm(abs(qbar / se), lower.tail = FALSE)
    },
    m = m,
    estimate = qbar,
    standard_error = se,
    ci_low = qbar - critical * se,
    ci_high = qbar + critical * se,
    exp_estimate = exp(qbar),
    exp_ci_low = exp(qbar - critical * se),
    exp_ci_high = exp(qbar + critical * se),
    stringsAsFactors = FALSE
  )
}

pool_multivariate_rubin <- function(fits, terms, test_id) {
  if (length(fits) < 2L || !length(terms) || anyNA(terms) ||
      any(!nzchar(terms)) || anyDuplicated(terms)) {
    stop("Multivariate Rubin pooling requires at least two fits and unique nonempty terms.", call. = FALSE)
  }
  if (!all(vapply(fits, function(x) all(terms %in% names(x$coefficients)), logical(1)))) {
    stop("One or more multivariate Rubin terms are absent from a fitted model.", call. = FALSE)
  }
  q <- do.call(rbind, lapply(fits, function(x) unname(x$coefficients[terms])))
  q <- as.matrix(q)
  colnames(q) <- terms
  if (!identical(dim(q), c(length(fits), length(terms))) || any(!is.finite(q))) {
    stop("Multivariate Rubin coefficient matrix has invalid dimensions or non-finite values.", call. = FALSE)
  }
  u <- lapply(seq_along(fits), function(i) {
    validate_covariance_matrix(
      fits[[i]]$variance[terms, terms, drop = FALSE],
      terms,
      paste0(test_id, " within-imputation covariance ", i)
    )$matrix
  })
  qbar <- colMeans(q)
  ubar <- Reduce(`+`, u) / length(u)
  b <- stats::cov(q)
  b <- as.matrix(b)
  dimnames(b) <- list(terms, terms)
  if (!identical(dim(b), c(length(terms), length(terms))) ||
      any(!is.finite(b))) {
    stop("Multivariate Rubin between-imputation covariance is invalid.", call. = FALSE)
  }
  total <- ubar + (1 + 1 / nrow(q)) * b
  dimnames(total) <- list(terms, terms)
  total_check <- validate_covariance_matrix(
    total,
    terms,
    paste0(test_id, " total Rubin covariance")
  )
  solution <- tryCatch(
    solve(total_check$matrix, qbar),
    error = function(e) {
      stop(test_id, " total Rubin covariance is not invertible: ", conditionMessage(e), call. = FALSE)
    }
  )
  statistic <- as.numeric(crossprod(qbar, solution))
  if (!is.finite(statistic) || statistic < -1e-8) {
    stop(test_id, " produced an invalid multivariate Wald statistic.", call. = FALSE)
  }
  statistic <- max(0, statistic)
  data.frame(
    test_id = test_id,
    pooling_rule = "multivariate Rubin total covariance; large-sample Wald chi-square",
    terms = paste(terms, collapse = "; "),
    df = length(terms),
    statistic = statistic,
    p_value = stats::pchisq(statistic, df = length(terms), lower.tail = FALSE),
    m = nrow(q),
    stringsAsFactors = FALSE
  )
}

registry_row <- function(
    pooled, analysis_id, exposure_id, sample_id, model_tier, formula,
    model_diagnostic, hashes, e0_hash, knot_hash, mi_m, warnings = "") {
  data.frame(
    analysis_id = analysis_id,
    stage = 3L,
    cohort = "CHARLS",
    estimand_id = "PC",
    exposure_id = exposure_id,
    sample_id = sample_id,
    model_family = "survey_weighted_person_period_cloglog",
    n = model_diagnostic$n_participants[[1]],
    events = model_diagnostic$events[[1]],
    estimate = pooled$estimate,
    standard_error = pooled$standard_error,
    ci_low = pooled$ci_low,
    ci_high = pooled$ci_high,
    p_value = pooled$p_value,
    gate_status = "PASS",
    script = "R/v43/04_charls_stage3_primary_mortality.R",
    spec_sha256 = hashes[["analysis_spec"]],
    manifest_sha256 = hashes[["private_manifest"]],
    warnings = one_line(warnings),
    run_timestamp = format(Sys.time(), tz = "Asia/Shanghai", usetz = TRUE),
    effect_measure = "nominal-duration interval-HR",
    exp_estimate = exp(pooled$estimate),
    exp_ci_low = exp(pooled$ci_low),
    exp_ci_high = exp(pooled$ci_high),
    model_tier = model_tier,
    quality_layer = "Gate2-valid W1 row-max PEF, 30/890 retained as boundary-coded",
    formula_text = paste(deparse(formula), collapse = " "),
    formula_sha256 = digest::digest(paste(deparse(formula), collapse = " "), algo = "sha256"),
    n_participants = model_diagnostic$n_participants[[1]],
    n_person_period_rows = model_diagnostic$n_person_period_rows[[1]],
    person_years = model_diagnostic$nominal_person_years[[1]],
    design_strata = NA_integer_,
    design_psu = model_diagnostic$design_psu[[1]],
    design_df = model_diagnostic$design_df[[1]],
    mi_m = mi_m,
    fraction_missing_information = pooled$fraction_missing_information,
    relative_efficiency = pooled$relative_efficiency,
    monte_carlo_error = pooled$monte_carlo_error,
    monte_carlo_error_fraction = pooled$monte_carlo_error_fraction,
    e0_scaling_path = "results/v43/charls_e0_scale_v43.csv",
    e0_scaling_sha256 = e0_hash,
    spline_knot_registry_path = "results/v43/stage3_charls_spline_knot_registry_v43.csv",
    spline_knot_registry_sha256 = knot_hash,
    convergence_diagnostic_id = paste0(analysis_id, "_convergence"),
    time_basis = "factor(end_wave) + offset(log(nominal_years))",
    exact_death_date_used = FALSE,
    time_varying_effect_diagnostic_id = NA_character_,
    stringsAsFactors = FALSE
  )
}

complete_case_mask <- function(master) {
  required <- c(
    "height_m_w1", "bmi_w1", "smoke_ever_w1", "smoke_now_w1", "raeducl",
    "h1rural", "hh1cperc", "lung_w1", "asthma_w1", "r1hibpe", "r1diabe",
    "r1cancre", "r1hearte", "r1stroke", "r1kidneye", "frailty_proxy_count_w1"
  )
  stats::complete.cases(master[required]) & !is.na(derive_smoking(master$smoke_ever_w1, master$smoke_now_w1))
}

fit_complete_case_set <- function(master, period_skeleton, knots, formulas, prefix) {
  master <- apply_charls_smoking_parent_rule(master)
  keep <- complete_case_mask(master)
  cc <- attach_passive_variables(master[keep, , drop = FALSE], knots)
  pp <- period_skeleton[period_skeleton$participant_id %in% cc$participant_id, , drop = FALSE]
  fits <- lapply(names(formulas), function(tier) {
    fit_one_survey_model(cc, pp, formulas[[tier]], paste0(prefix, "_", tolower(tier)))
  })
  names(fits) <- names(formulas)
  fits
}

make_sample_event_audit <- function(master, period_skeleton, joins, assertions) {
  overall <- data.frame(
    cohort = "CHARLS",
    audit_type = "overall",
    stratum = "primary_structural_cohort",
    n_people = nrow(master),
    transition_rows = nrow(period_skeleton),
    deaths = sum(period_skeleton$period_event),
    non_deaths = sum(period_skeleton$period_event == 0L),
    weighted_events = sum(
      period_skeleton$weight_biomarker_w1[
        period_skeleton$period_event == 1L
      ]
    ),
    weighted_non_events = sum(
      period_skeleton$weight_biomarker_w1[
        period_skeleton$period_event == 0L
      ]
    ),
    outcome_event_fraction = mean(period_skeleton$period_event),
    minimum_outcome_cell = min(
      sum(period_skeleton$period_event == 1L),
      sum(period_skeleton$period_event == 0L)
    ),
    community_psu = length(unique(master$community_id)),
    detail = "last-known-alive to next-known-explicit-status transitions; code 9 skipped; code 6 never a new event",
    stringsAsFactors = FALSE
  )
  by_window <- period_skeleton |>
    dplyr::group_by(window_id) |>
    dplyr::summarise(
      n_people = dplyr::n_distinct(participant_id),
      transition_rows = dplyr::n(),
      deaths = sum(period_event),
      non_deaths = sum(period_event == 0L),
      weighted_events =
        sum(weight_biomarker_w1[period_event == 1L]),
      weighted_non_events =
        sum(weight_biomarker_w1[period_event == 0L]),
      outcome_event_fraction = mean(period_event),
      minimum_outcome_cell =
        min(sum(period_event == 1L), sum(period_event == 0L)),
      descriptive_window_outcome_overlap_pass =
        any(period_event == 1L) && any(period_event == 0L),
      time_basis_support_status = ifelse(
        descriptive_window_outcome_overlap_pass,
        "OUTCOME_OVERLAP",
        "SEPARATED"
      ),
      analysis_action = "DESCRIPTIVE_ONLY_REJECTED_INFERENTIAL_BASIS",
      community_psu = dplyr::n_distinct(community_id),
      .groups = "drop"
    ) |>
    dplyr::mutate(
      cohort = "CHARLS",
      audit_type = "window",
      stratum = window_id,
      detail = paste(
        "descriptive observed transition pathway only;",
        "not an inferential time stratum after the estimability amendment"
      ),
      .before = 1
    ) |>
    dplyr::select(-window_id)
  list(overall = dplyr::bind_rows(overall, by_window), joins = joins, assertions = assertions)
}

visit_date_audit <- function(master) {
  dplyr::bind_rows(lapply(1:5, function(wave) {
    year <- master[[paste0("r", wave, "iwy")]]
    month <- master[[paste0("r", wave, "iwm")]]
    observed <- is.finite(year) & is.finite(month)
    data.frame(
      cohort = "CHARLS",
      wave = wave,
      structural_n = nrow(master),
      year_month_complete_n = sum(observed),
      year_month_complete_fraction = mean(observed),
      invalid_month_n = sum(is.finite(month) & !(month %in% 1:12)),
      year_min = if (any(observed)) min(year[observed]) else NA_real_,
      year_max = if (any(observed)) max(year[observed]) else NA_real_,
      role = if (wave < 5) {
        paste(
          "visit-date completeness diagnostic; inferential time basis uses",
          "end-wave strata plus scheduled nominal-duration offset"
        )
      } else {
        paste(
          "Wave 5 respondent-date field is not a comparable decedent event",
          "date; scheduled nominal duration is used and no exact death date is invented"
        )
      },
      stringsAsFactors = FALSE
    )
  }))
}

build_charls_master <- function(root, paths, store) {
  spec <- yaml::read_yaml(paths$spec)
  scalar_text <- function(value, field) {
    if (!is.character(value) || length(value) != 1L ||
        is.na(value) || !nzchar(trimws(value))) {
      stop("Analysis specification field ", field, " must be one nonempty path string.", call. = FALSE)
    }
    trimws(value)
  }
  resolve_input <- function(path, field) {
    path <- scalar_text(path, field)
    expanded <- path.expand(path)
    if (grepl("^/", expanded)) expanded else file.path(root, path)
  }
  ledger <- readRDS(paths$charls_ledger)
  core_path <- resolve_input(spec$inputs$charls_core, "inputs.charls_core")
  core <- readRDS(core_path)
  assert_unique_id(ledger, "participant_id", "charls_stage1_ledger_v43.rds")
  assert_unique_id(core, "participant_id", "charls_core_harmonized_provisional.rds")

  primary_pef_column <- "pef_w1_rowmax"
  record_assertion(
    store,
    "primary_w1_pef_ledger_column",
    primary_pef_column %in% names(ledger),
    primary_pef_column,
    "Gate 2 primary row-max PEF column exists; no fallback to pef_best_w1_valid_provisional"
  )
  required_e0_ledger_fields <- c(
    "E0_lower_pef_sex_specific_sd",
    "E0b_lower_pef_per_100_l_min"
  )
  record_assertion(
    store,
    "e0_ledger_columns_present",
    all(required_e0_ledger_fields %in% names(ledger)),
    paste(required_e0_ledger_fields, required_e0_ledger_fields %in% names(ledger), sep = "=", collapse = "; "),
    "Gate 2 ledger contains both standardized and physical-unit lower-PEF exposure columns"
  )

  core_fields <- c(
    "participant_id", "bmi_w1", "smoke_ever_w1", "smoke_now_w1",
    "lung_w1", "asthma_w1", "frailty_proxy_count_w1", "grip_kg_w1",
    "adl6_score_w1", "cesd10_w1"
  )
  master <- audited_left_join(
    ledger,
    core[core_fields],
    "participant_id",
    "charls_core_harmonized_provisional.rds",
    store
  )

  h_archive <- resolve_input(
    spec$inputs$charls_harmonized_archive,
    "inputs.charls_harmonized_archive"
  )
  h_member <- scalar_text(
    spec$inputs$charls_harmonized_member,
    "inputs.charls_harmonized_member"
  )
  h_fields <- c(
    "ID", "raeducl", "h1rural", "hh1cperc",
    "r1hibpe", "r1diabe", "r1cancre", "r1hearte", "r1stroke", "r1kidneye",
    "r1iwy", "r1iwm", "r2iwy", "r2iwm", "r3iwy", "r3iwm", "r4iwy", "r4iwm"
  )
  harmonized <- read_zip_dta_selected(h_archive, h_member, h_fields)
  harmonized$participant_id <- as_chr(harmonized$ID)
  harmonized$ID <- NULL
  for (v in setdiff(names(harmonized), "participant_id")) harmonized[[v]] <- as_num(harmonized[[v]])
  master <- audited_left_join(master, harmonized, "participant_id", "H_CHARLS_D_Data.dta", store)

  w5_archive <- resolve_input(
    spec$inputs$charls_wave5_archive,
    "inputs.charls_wave5_archive"
  )
  w5 <- read_zip_dta_selected(w5_archive, "Sample_Infor.dta", c("ID", "died", "iyear", "imonth"))
  w5 <- data.frame(
    participant_id = as_chr(w5$ID),
    died_w5_raw = as_num(w5$died),
    r5iwy = as_num(w5$iyear),
    r5iwm = as_num(w5$imonth),
    stringsAsFactors = FALSE
  )
  master <- audited_left_join(master, w5, "participant_id", "CHARLS2020r.zip::Sample_Infor.dta", store)

  shared_w5 <- !is.na(master$died_w5) & !is.na(master$died_w5_raw)
  record_assertion(
    store,
    "wave5_died_exact_reconciliation",
    all(master$died_w5[shared_w5] == master$died_w5_raw[shared_w5]),
    paste0("compared=", sum(shared_w5), "; mismatches=", sum(master$died_w5[shared_w5] != master$died_w5_raw[shared_w5])),
    "ledger died_w5 equals raw Sample_Infor.dta::died for every shared nonmissing row"
  )

  scale <- utils::read.csv(paths$charls_e0, stringsAsFactors = FALSE, check.names = FALSE)
  primary_scale <- scale[scale$sample_id == "primary_mortality_eligible", , drop = FALSE]
  record_assertion(
    store,
    "e0_primary_scale_two_sex_rows",
    nrow(primary_scale) == 2L && setequal(primary_scale$sex_code, c(1, 2)),
    paste0("rows=", nrow(primary_scale), "; sex=", paste(primary_scale$sex_code, collapse = ",")),
    "exactly one primary-mortality-eligible row for male and female"
  )
  record_assertion(
    store,
    "e0_primary_scale_positive_sd",
    all(is.finite(primary_scale$weighted_sd_l_min) & primary_scale$weighted_sd_l_min > 0),
    paste(primary_scale$weighted_sd_l_min, collapse = ","),
    "both frozen sex-specific weighted SD values are positive"
  )

  mu <- setNames(primary_scale$weighted_mean_l_min, primary_scale$sex_code)
  sigma <- setNames(primary_scale$weighted_sd_l_min, primary_scale$sex_code)
  master$E0_local <- (mu[as.character(master$sex_code)] - master[[primary_pef_column]]) /
    sigma[as.character(master$sex_code)]
  master$E0b_local <- (mu[as.character(master$sex_code)] - master[[primary_pef_column]]) / 100

  future_status_local <- master$iwstat_w2 %in% c(1, 4, 5, 6) |
    master$iwstat_w3 %in% c(1, 4, 5, 6) |
    master$iwstat_w4 %in% c(1, 4, 5, 6) |
    master$died_w5 %in% c(0, 1)
  record_assertion(
    store,
    "future_explicit_status_flag_reconciled",
    identical(as.logical(master$future_status_known), as.logical(future_status_local)),
    paste0(
      "ledger=", sum(master$future_status_known),
      "; local=", sum(future_status_local),
      "; mismatch=", sum(master$future_status_known != future_status_local)
    ),
    "future_status_known means at least one explicit alive/death status; code 9 and missing are not observed endpoints"
  )

  local_primary <- !is.na(master$age_w1) & master$age_w1 >= 45 &
    is.finite(master[[primary_pef_column]]) &
    master[[primary_pef_column]] >= 30 & master[[primary_pef_column]] <= 890 &
    is.finite(master$weight_biomarker_w1) & master$weight_biomarker_w1 > 0 &
    master$sex_code %in% c(1, 2) &
    !is.na(master$participant_id) & !is.na(master$community_id) &
    future_status_local
  record_assertion(
    store,
    "structural_cohort_matches_gate2_ledger",
    identical(as.logical(master$primary_mortality_eligible), as.logical(local_primary)),
    paste0("ledger=", sum(master$primary_mortality_eligible), "; local=", sum(local_primary), "; mismatch=", sum(master$primary_mortality_eligible != local_primary)),
    "Gate 2 primary_mortality_eligible equals the frozen Stage 3 structural rule"
  )

  eligible <- master[local_primary, , drop = FALSE]
  e0_match <- is.finite(eligible$E0_lower_pef_sex_specific_sd) & is.finite(eligible$E0_local)
  e0b_match <- is.finite(eligible$E0b_lower_pef_per_100_l_min) & is.finite(eligible$E0b_local)
  max_abs_difference <- function(x, y) {
    delta <- abs(x - y)
    delta <- delta[is.finite(delta)]
    if (length(delta)) max(delta) else NA_real_
  }
  record_assertion(
    store,
    "e0_checksum_matches_gate2_ledger",
    nrow(eligible) > 0L &&
      all(abs(eligible$E0_lower_pef_sex_specific_sd[e0_match] - eligible$E0_local[e0_match]) < 1e-10) &&
      all(abs(eligible$E0b_lower_pef_per_100_l_min[e0b_match] - eligible$E0b_local[e0b_match]) < 1e-10) &&
      sum(e0_match) == nrow(eligible) && sum(e0b_match) == nrow(eligible),
    paste0(
      "N=", nrow(eligible),
      "; E0 max abs diff=", max_abs_difference(eligible$E0_lower_pef_sex_specific_sd, eligible$E0_local),
      "; E0b max abs diff=", max_abs_difference(eligible$E0b_lower_pef_per_100_l_min, eligible$E0b_local)
    ),
    "locally reconstructed E0/E0b exactly match Gate 2 ledger values"
  )

  scale_counts <- setNames(primary_scale$n, primary_scale$sex_code)
  local_counts <- table(factor(eligible$sex_code, levels = c(1, 2)))
  record_assertion(
    store,
    "e0_scale_source_counts_match",
    identical(as.numeric(scale_counts[c("1", "2")]), as.numeric(local_counts)),
    paste0("scale=", paste(scale_counts[c("1", "2")], collapse = ","), "; local=", paste(local_counts, collapse = ",")),
    "sex-specific structural-cohort counts equal the frozen E0 scale source counts"
  )

  eligible$E0 <- eligible$E0_local
  eligible$E0b <- eligible$E0b_local
  eligible
}

build_period_skeleton <- function(master, store) {
  contradictions <- vapply(seq_len(nrow(master)), function(i) {
    validate_status_sequence(
      master$iwstat_w2[[i]], master$iwstat_w3[[i]], master$iwstat_w4[[i]], master$died_w5[[i]]
    )
  }, character(1))
  bad <- !is.na(contradictions)
  record_assertion(
    store,
    "vital_status_sequence_consistency",
    !any(bad),
    if (any(bad)) paste(names(sort(table(contradictions[bad]), decreasing = TRUE)), collapse = "; ") else "0 contradictions",
    "no alive-after-death sequence and no first code 6 without an earlier code 5"
  )

  rows <- lapply(seq_len(nrow(master)), function(i) {
    build_period_one(
      master$participant_id[[i]],
      master$community_id[[i]],
      master$weight_biomarker_w1[[i]],
      master$iwstat_w2[[i]],
      master$iwstat_w3[[i]],
      master$iwstat_w4[[i]],
      master$died_w5[[i]]
    )
  })
  period <- dplyr::bind_rows(rows)
  record_assertion(
    store,
    "all_structural_people_have_observed_transition",
    length(unique(period$participant_id)) == nrow(master),
    paste0("people with transition=", length(unique(period$participant_id)), "; structural N=", nrow(master)),
    "every structurally eligible participant has at least one last-known-alive to next-known-status transition"
  )
  event_by_person <- period |>
    dplyr::group_by(participant_id) |>
    dplyr::summarise(events = sum(period_event), .groups = "drop")
  record_assertion(
    store,
    "one_death_event_maximum",
    all(event_by_person$events <= 1L),
    paste0("max events/person=", max(event_by_person$events)),
    "code 6 and later Wave 5 confirmations never create a second event"
  )
  local_event <- master$participant_id %in% event_by_person$participant_id[event_by_person$events == 1L]
  ledger_event <- as.logical(master$primary_death_event_aggregate_contract)
  record_assertion(
    store,
    "person_level_death_event_reconciles_gate2_ledger",
    identical(local_event, ledger_event),
    paste0(
      "period deaths=", sum(local_event),
      "; ledger deaths=", sum(ledger_event),
      "; mismatches=", sum(local_event != ledger_event)
    ),
    "the Stage 3 transition algorithm reproduces the frozen Gate 2 person-level death-event contract exactly"
  )
  record_assertion(
    store,
    "positive_nonoverlapping_nominal_windows",
    all(is.finite(period$nominal_years) & period$nominal_years > 0),
    paste0("range=", paste(range(period$nominal_years), collapse = "-")),
    "every observed transition has positive nominal duration"
  )
  period
}

augment_mi_outcome_predictors <- function(master, period) {
  summary <- period |>
    dplyr::group_by(participant_id) |>
    dplyr::summarise(
      event_any = as.integer(any(period_event == 1L)),
      last_known_followup_wave = max(end_wave),
      total_observed_followup_span = sum(nominal_years),
      .groups = "drop"
    )
  master <- dplyr::left_join(master, summary, by = "participant_id")
  master$known_alive_w2 <- as.integer(status_w24(master$iwstat_w2) == "alive")
  master$known_alive_w3 <- as.integer(status_w24(master$iwstat_w3) == "alive")
  master$known_alive_w4 <- as.integer(status_w24(master$iwstat_w4) == "alive")
  master$known_alive_w5 <- as.integer(status_w5(master$died_w5) == "alive")
  master$death_report_w2 <- as.integer(status_w24(master$iwstat_w2) == "death")
  master$death_report_w3 <- as.integer(status_w24(master$iwstat_w3) == "death")
  master$death_report_w4 <- as.integer(status_w24(master$iwstat_w4) == "death")
  master$death_report_w5 <- as.integer(status_w5(master$died_w5) == "death")
  master$log_survey_weight <- log(master$weight_biomarker_w1)
  master
}

build_w2_landmark_period <- function(master, period) {
  required_master <- c("participant_id", "known_alive_w2")
  required_period <- c("participant_id", "start_wave", "end_wave", "period_event")
  if (!all(required_master %in% names(master)) ||
      !all(required_period %in% names(period))) {
    stop("W2 landmark inputs lack required participant/status/window fields.", call. = FALSE)
  }
  w2_known_alive_ids <- master$participant_id[master$known_alive_w2 == 1L]
  landmark <- period[
    period$participant_id %in% w2_known_alive_ids &
      period$start_wave >= 2L,
    ,
    drop = FALSE
  ]
  eligible_ids <- unique(landmark$participant_id)
  if (!nrow(landmark) ||
      any(landmark$start_wave < 2L) ||
      any(!eligible_ids %in% w2_known_alive_ids) ||
      !all(vapply(eligible_ids, function(id) {
        any(landmark$participant_id == id & landmark$start_wave == 2L)
      }, logical(1)))) {
    stop(
      "The W2 landmark sensitivity failed its known-alive/post-W2 risk-window contract.",
      call. = FALSE
    )
  }
  landmark
}

planned_time_basis_support_audit <- function(master, period) {
  cc_routed <- apply_charls_smoking_parent_rule(master)
  sample_masks <- list(
    charls_primary_mortality_eligible_common_mi =
      rep(TRUE, nrow(master)),
    charls_common_A2_complete_case =
      complete_case_mask(cc_routed),
    charls_boundary_excluded_common_mi =
      master$pef_w1_rowmax != 30 & master$pef_w1_rowmax != 890,
    charls_strict_measurement_common_mi =
      master$pef_w1_strict_protocol %in% TRUE &
        master$pef_w1_valid_n >= 2
  )
  audits <- lapply(names(sample_masks), function(sample_id) {
    keep <- sample_masks[[sample_id]] %in% TRUE
    person <- master[keep, , drop = FALSE]
    period_sample <- period[
      period$participant_id %in% person$participant_id,
      ,
      drop = FALSE
    ]
    time_basis_support_audit(
      person,
      period_sample,
      sample_id,
      hard_stop = TRUE
    )
  })

  w2_period <- build_w2_landmark_period(master, period)
  w2_person <- master[
    master$participant_id %in% unique(w2_period$participant_id),
    ,
    drop = FALSE
  ]
  audits[[length(audits) + 1L]] <- time_basis_support_audit(
    w2_person,
    w2_period,
    "charls_known_alive_w2_with_post_w2_explicit_followup_common_mi",
    hard_stop = TRUE
  )
  audit <- dplyr::bind_rows(audits)
  expected_samples <- c(
    names(sample_masks),
    "charls_known_alive_w2_with_post_w2_explicit_followup_common_mi"
  )
  if (!setequal(unique(audit$sample_id), expected_samples) ||
      any(!(audit$time_basis_support_pass %in% TRUE))) {
    stop(
      "The planned CHARLS time-basis support audit is incomplete or failed.",
      call. = FALSE
    )
  }
  audit
}

new_charls_run_context <- function(root) {
  parent <- file.path(root, "derived_sensitive", "v43", ".stage3_staging")
  dir.create(parent, recursive = TRUE, showWarnings = FALSE)
  run_id <- paste0(
    format(Sys.time(), "%Y%m%dT%H%M%S", tz = "Asia/Shanghai"),
    "_pid", Sys.getpid(),
    "_", format(as.integer(proc.time()[["elapsed"]] * 1000), scientific = FALSE)
  )
  staging_root <- file.path(parent, paste0("charls_", run_id))
  if (file.exists(staging_root)) {
    stop("Run-scoped CHARLS staging directory already exists: ", staging_root, call. = FALSE)
  }
  dir.create(staging_root, recursive = TRUE, showWarnings = FALSE)
  if (!dir.exists(staging_root)) {
    stop("Could not create run-scoped CHARLS staging directory: ", staging_root, call. = FALSE)
  }
  list(run_id = run_id, staging_root = staging_root)
}

cleanup_charls_run_staging <- function(run_context) {
  if (!is.null(run_context) &&
      !is.null(run_context$staging_root) &&
      dir.exists(run_context$staging_root)) {
    unlink(run_context$staging_root, recursive = TRUE, force = TRUE)
  }
  invisible(TRUE)
}

write_charls_completion_manifest <- function(root, authorization, run_context) {
  staging_root <- normalizePath(run_context$staging_root, mustWork = TRUE)
  normalized_root <- normalizePath(root, mustWork = TRUE)
  staged_paths <- charls_stage3_result_paths(staging_root)
  final_paths <- charls_stage3_result_paths(normalized_root)
  manifest_staged_path <- charls_stage3_completion_manifest_path(staging_root)
  if (file.exists(manifest_staged_path)) {
    stop("The run-scoped CHARLS completion manifest already exists.", call. = FALSE)
  }
  actual_staged <- list.files(
    staging_root,
    recursive = TRUE,
    full.names = TRUE,
    all.files = TRUE,
    include.dirs = FALSE,
    no.. = TRUE
  )
  actual_staged <- actual_staged[file.exists(actual_staged) & !dir.exists(actual_staged)]
  actual_staged <- normalizePath(actual_staged, mustWork = FALSE)
  expected_staged <- normalizePath(staged_paths, mustWork = FALSE)
  if (!setequal(actual_staged, expected_staged)) {
    stop(
      "CHARLS Stage 3 staging violates the exact artifact whitelist: missing=",
      paste(setdiff(expected_staged, actual_staged), collapse = "; "),
      "; unexpected=",
      paste(setdiff(actual_staged, expected_staged), collapse = "; "),
      call. = FALSE
    )
  }
  exists <- file.exists(staged_paths) & !dir.exists(staged_paths)
  bytes <- ifelse(exists, as.numeric(file.info(staged_paths)$size), NA_real_)
  hashes <- vapply(staged_paths, sha256_file, character(1))
  registry_hash <- sha256_file(authorization$paths$hash_registry)
  if (!all(exists) ||
      any(!is.finite(bytes) | bytes <= 0) ||
      any(is.na(hashes) | !grepl("^[0-9a-fA-F]{64}$", hashes)) ||
      is.na(registry_hash) ||
      !grepl("^[0-9a-fA-F]{64}$", registry_hash)) {
    stop("A staged CHARLS artifact or the authorization registry could not be hash-bound.", call. = FALSE)
  }
  root_prefix <- paste0(normalized_root, .Platform$file.sep)
  normalized_final <- normalizePath(final_paths, mustWork = FALSE)
  if (!all(startsWith(normalized_final, root_prefix))) {
    stop("A CHARLS completion artifact resolves outside the project root.", call. = FALSE)
  }
  artifact <- substring(normalized_final, nchar(root_prefix) + 1L)
  completed_at <- format(Sys.time(), tz = "Asia/Shanghai", usetz = TRUE)
  completion <- data.frame(
    cohort = "CHARLS",
    status = "COMPLETE",
    run_id = basename(staging_root),
    authorization_registry_sha256 = registry_hash,
    artifact = artifact,
    path = normalized_final,
    bytes = bytes,
    sha256 = hashes,
    completed_at = completed_at,
    stringsAsFactors = FALSE
  )
  if (anyDuplicated(completion$artifact) || anyDuplicated(completion$path)) {
    stop("CHARLS completion manifest contains duplicate artifacts or paths.", call. = FALSE)
  }
  write_charls_cohort_csv(completion, manifest_staged_path)
  invisible(completion)
}

atomic_promote_charls_run <- function(root, run_context) {
  staging_root <- normalizePath(run_context$staging_root, mustWork = TRUE)
  staged_files <- list.files(
    staging_root,
    recursive = TRUE,
    full.names = TRUE,
    all.files = TRUE,
    include.dirs = FALSE,
    no.. = TRUE
  )
  staged_files <- staged_files[file.exists(staged_files) & !dir.exists(staged_files)]
  if (!length(staged_files)) {
    stop("CHARLS Stage 3 staging contains no outputs to promote.", call. = FALSE)
  }
  expected_staged <- c(
    charls_stage3_result_paths(staging_root),
    charls_stage3_completion_manifest_path(staging_root)
  )
  normalized_expected <- normalizePath(expected_staged, mustWork = FALSE)
  normalized_actual <- normalizePath(staged_files, mustWork = FALSE)
  if (!setequal(normalized_actual, normalized_expected)) {
    stop(
      "CHARLS Stage 3 promotion violates the exact completed-artifact whitelist: missing=",
      paste(setdiff(normalized_expected, normalized_actual), collapse = "; "),
      "; unexpected=",
      paste(setdiff(normalized_actual, normalized_expected), collapse = "; "),
      call. = FALSE
    )
  }
  prefix <- paste0(staging_root, .Platform$file.sep)
  relative <- substring(normalizePath(staged_files, mustWork = TRUE), nchar(prefix) + 1L)
  allowed_prefix <- grepl("^(results|logs|output|derived_sensitive)/", relative)
  safe_relative <- !grepl("(^|/)\\.\\.(/|$)", relative)
  if (!all(allowed_prefix & safe_relative)) {
    stop(
      "CHARLS Stage 3 staging contains an output outside the approved project output roots: ",
      paste(relative[!(allowed_prefix & safe_relative)], collapse = "; "),
      call. = FALSE
    )
  }
  final_paths <- file.path(root, relative)
  if (anyDuplicated(final_paths)) {
    stop("CHARLS Stage 3 staging resolves to duplicate final output paths.", call. = FALSE)
  }
  backups <- file.path(
    dirname(final_paths),
    paste0(".", basename(final_paths), ".previous.", run_context$run_id)
  )
  if (any(file.exists(backups))) {
    stop("A CHARLS Stage 3 promotion backup path already exists; refusing to overwrite it.", call. = FALSE)
  }
  for (directory in unique(dirname(final_paths))) {
    dir.create(directory, recursive = TRUE, showWarnings = FALSE)
  }

  had_previous <- file.exists(final_paths)
  backup_moved <- rep(FALSE, length(final_paths))
  promoted <- rep(FALSE, length(final_paths))
  last_index <- 0L
  promotion_error <- tryCatch(
    {
      for (i in seq_along(staged_files)) {
        last_index <- i
        if (had_previous[[i]]) {
          if (!file.rename(final_paths[[i]], backups[[i]])) {
            stop("Could not stage the prior successful output for atomic replacement: ", final_paths[[i]], call. = FALSE)
          }
          backup_moved[[i]] <- TRUE
        }
        if (!file.rename(staged_files[[i]], final_paths[[i]])) {
          stop("Could not atomically promote staged output: ", final_paths[[i]], call. = FALSE)
        }
        promoted[[i]] <- TRUE
      }
      NULL
    },
    error = function(e) conditionMessage(e)
  )

  if (!is.null(promotion_error)) {
    rollback_failures <- character()
    if (last_index > 0L) {
      for (i in rev(seq_len(last_index))) {
        if (promoted[[i]] && file.exists(final_paths[[i]])) {
          if (unlink(final_paths[[i]]) != 0L) {
            rollback_failures <- c(
              rollback_failures,
              paste0("could not remove current-run output ", final_paths[[i]])
            )
          }
        }
        if (backup_moved[[i]] && file.exists(backups[[i]])) {
          if (!file.rename(backups[[i]], final_paths[[i]])) {
            rollback_failures <- c(
              rollback_failures,
              paste0("prior output retained at backup path ", backups[[i]])
            )
          }
        }
      }
    }
    stop(
      promotion_error,
      if (length(rollback_failures)) {
        paste0(" Promotion rollback warnings: ", paste(rollback_failures, collapse = "; "))
      } else {
        " Prior successful outputs were restored."
      },
      call. = FALSE
    )
  }

  unlink(backups[file.exists(backups)])
  cleanup_charls_run_staging(run_context)
  invisible(data.frame(
    relative_path = relative,
    final_path = final_paths,
    replaced_prior_success = had_previous,
    stringsAsFactors = FALSE
  ))
}

run_authorized_stage3 <- function(root, authorization, run_context) {
  paths <- authorization$paths
  staging_root <- run_context$staging_root
  out_dir <- file.path(staging_root, "results", "v43")
  log_dir <- file.path(staging_root, "logs", "v43")
  qa_dir <- file.path(staging_root, "output", "qa", "v43")
  sensitive_dir <- file.path(staging_root, "derived_sensitive", "v43")
  dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)
  dir.create(log_dir, recursive = TRUE, showWarnings = FALSE)
  dir.create(qa_dir, recursive = TRUE, showWarnings = FALSE)
  dir.create(sensitive_dir, recursive = TRUE, showWarnings = FALSE)

  store <- new_audit_store()
  master <- build_charls_master(root, paths, store)
  date_audit <- visit_date_audit(master)
  record_assertion(
    store,
    "visit_month_values_valid",
    all(date_audit$invalid_month_n == 0L),
    paste0("invalid month cells=", sum(date_audit$invalid_month_n)),
    "every observed Wave 1-5 visit month is between 1 and 12"
  )

  record_assertion(
    store,
    "no_negative_household_consumption",
    !any(is.finite(master$hh1cperc) & master$hh1cperc < 0),
    paste0("negative observed values=", sum(is.finite(master$hh1cperc) & master$hh1cperc < 0)),
    "negative hh1cperc is invalid and requires mapping review"
  )

  smoking_routed <- apply_charls_smoking_parent_rule(master)
  smoking_routing_audit <- attr(
    smoking_routed,
    "charls_smoking_routing_audit",
    exact = TRUE
  )
  record_assertion(
    store,
    "smoking_parent_child_routing_coherent",
    !is.null(smoking_routing_audit) &&
      nrow(smoking_routing_audit) == 1L &&
      smoking_routing_audit$output_parent_zero_child_one_n == 0L &&
      smoking_routing_audit$output_child_missing_n ==
        smoking_routing_audit$output_applicable_child_missing_n +
          smoking_routing_audit$output_unresolved_parent_child_missing_n,
    if (is.null(smoking_routing_audit)) {
      "routing audit missing"
    } else {
      paste0(
        "input parent0/current1=",
        smoking_routing_audit$input_parent_zero_child_one_n,
        "; parent inferred from current1=",
        smoking_routing_audit$parent_inferred_from_observed_child_one_n,
        "; routed structural current0=",
        smoking_routing_audit$child_routed_to_structural_zero_n,
        "; output conflicts=",
        smoking_routing_audit$output_parent_zero_child_one_n,
        "; parent missing=",
        smoking_routing_audit$output_parent_missing_n,
        "; current missing=",
        smoking_routing_audit$output_child_missing_n,
        "; applicable current missing=",
        smoking_routing_audit$output_applicable_child_missing_n,
        "; both unresolved=",
        smoking_routing_audit$output_unresolved_parent_child_missing_n
      )
    },
    paste(
      "official Harmonized CHARLS parent-question routing leaves zero",
      "ever=0/current=1 pairs, and child missingness is confined to the",
      "ever=1 applicable branch or jointly unresolved parent-child pairs"
    )
  )

  period <- build_period_skeleton(master, store)
  master <- augment_mi_outcome_predictors(master, period)
  time_support_audit <- planned_time_basis_support_audit(master, period)
  record_assertion(
    store,
    "planned_end_wave_time_basis_supported",
    nrow(time_support_audit) > 0L &&
      all(time_support_audit$time_basis_support_pass %in% TRUE),
    paste0(
      "samples=", length(unique(time_support_audit$sample_id)),
      "; end-wave strata=", nrow(time_support_audit),
      "; outcome-overlap pass=",
      sum(time_support_audit$outcome_overlap_pass %in% TRUE),
      "; marginal E0-overlap pass=",
      sum(time_support_audit$e0_marginal_overlap_pass %in% TRUE),
      "; baseline-stratum support pass=",
      sum(time_support_audit$baseline_stratum_outcome_support_pass %in% TRUE),
      "; cluster-support pass=",
      sum(time_support_audit$cluster_support_pass %in% TRUE)
    ),
    paste(
      "every planned inferential sample has both outcome states, overlapping",
      "observed E0 support, and >=2 community PSUs per outcome state within",
      "each factor(end_wave) stratum before any outcome model is fitted; this",
      "necessary time-basis support gate is not claimed to prove absence of",
      "multivariable separation"
    )
  )

  knots <- freeze_spline_knots(master)
  charls_knot_path <- file.path(out_dir, "stage3_charls_spline_knot_registry_v43.csv")
  write_charls_cohort_csv(knots, charls_knot_path)
  knot_hash <- sha256_file(charls_knot_path)
  e0_hash <- sha256_file(paths$charls_e0)

  audit <- make_sample_event_audit(
    master,
    period,
    dplyr::bind_rows(store$joins),
    dplyr::bind_rows(store$assertions)
  )
  audit$overall <- dplyr::bind_rows(audit$overall, time_support_audit)
  write_charls_cohort_csv(
    audit$overall,
    file.path(out_dir, "stage3_charls_sample_event_audit_v43.csv")
  )
  write_charls_cohort_csv(audit$joins, file.path(out_dir, "stage3_charls_join_audit_v43.csv"))
  write_charls_cohort_csv(audit$assertions, file.path(out_dir, "stage3_charls_assertion_audit_v43.csv"))
  write_charls_cohort_csv(date_audit, file.path(out_dir, "stage3_charls_visit_date_audit_v43.csv"))

  mi_data <- make_mi_input(master)
  mi_spec <- freeze_mi_specification(mi_data)
  formulas_e0 <- model_formulas("E0")

  m50_run <- run_mi_convergence_schedule(
    mi_data = mi_data,
    mi_spec = mi_spec,
    m = mi_spec$initial_m,
    analysis_id = "v43_s3_charls_pc_e0",
    mi_run = paste0("m", mi_spec$initial_m)
  )
  imp <- m50_run$imp
  final_chain_convergence <- m50_run$final_convergence
  chain_convergence <- m50_run$checkpoint_diagnostics
  selected_maxit <- m50_run$selected_maxit
  fits <- fit_across_imputations(
    imp,
    period,
    knots,
    formulas_e0,
    "v43_s3_charls_pc_e0"
  )
  pooled <- lapply(names(fits), function(tier) pool_scalar_rubin(fits[[tier]], "E0"))
  names(pooled) <- names(fits)
  maximum_mce_fraction <- max(vapply(pooled, function(x) x$monte_carlo_error_fraction, numeric(1)))

  if (maximum_mce_fraction > mi_spec$monte_carlo_error_fraction_max) {
    m100_run <- tryCatch(
      run_mi_convergence_schedule(
        mi_data = mi_data,
        mi_spec = mi_spec,
        m = mi_spec$maximum_m,
        analysis_id = "v43_s3_charls_pc_e0",
        mi_run = paste0("m", mi_spec$maximum_m)
      ),
      stage3_mice_convergence_error = function(e) {
        e$checkpoint_diagnostics <- dplyr::bind_rows(
          chain_convergence,
          e$checkpoint_diagnostics
        )
        stop(e)
      }
    )
    imp <- m100_run$imp
    final_chain_convergence <- m100_run$final_convergence
    chain_convergence <- dplyr::bind_rows(
      chain_convergence,
      m100_run$checkpoint_diagnostics
    )
    selected_maxit <- m100_run$selected_maxit
    fits <- fit_across_imputations(
      imp,
      period,
      knots,
      formulas_e0,
      "v43_s3_charls_pc_e0"
    )
    pooled <- lapply(names(fits), function(tier) pool_scalar_rubin(fits[[tier]], "E0"))
    names(pooled) <- names(fits)
    maximum_mce_fraction <- max(vapply(pooled, function(x) x$monte_carlo_error_fraction, numeric(1)))
  }
  if (maximum_mce_fraction > mi_spec$monte_carlo_error_fraction_max) {
    stop("MI Monte Carlo error remains above 10% of the pooled E0 SE after 100 imputations.", call. = FALSE)
  }
  mi_spec$selected_maxit <- selected_maxit
  mi_spec$selected_m <- as.integer(imp$m)
  smoking_coherence_trace <- mice_smoking_coherence_trace(imp)

  write_charls_cohort_csv(
    chain_convergence,
    file.path(out_dir, "stage3_charls_mi_chain_convergence_v43.csv")
  )
  write_charls_cohort_csv(
    mice_chain_trace(imp, final_chain_convergence, mi_data, mi_spec),
    file.path(out_dir, "stage3_charls_mi_trace_v43.csv")
  )

  model_diagnostics <- dplyr::bind_rows(lapply(fits, function(tier_fits) {
    dplyr::bind_rows(lapply(tier_fits, `[[`, "diagnostics"))
  }))
  write_charls_cohort_csv(
    model_diagnostics,
    file.path(out_dir, "stage3_charls_model_diagnostics_v43.csv")
  )

  mi_diagnostics <- dplyr::bind_rows(lapply(names(pooled), function(tier) {
    cbind(
      data.frame(
        cohort = "CHARLS",
        model_tier = tier,
        exposure_id = "E0",
        logged_mice_events = if (is.null(imp$loggedEvents)) 0L else nrow(imp$loggedEvents),
        smoking_skip_pattern_method =
          "parent_precedence_then_ever_to_current_IAAC",
        smoking_coherence_iterations_checked =
          nrow(smoking_coherence_trace),
        smoking_coherence_chains_checked = imp$m,
        smoking_coherence_unresolved_n =
          sum(smoking_coherence_trace$unresolved_n_across_completed_chains),
        smoking_coherence_parent0_current1_n =
          sum(
            smoking_coherence_trace$
              parent_zero_child_one_n_across_completed_chains
          ),
        observed_parent0_current1_normalized_n =
          smoking_routing_audit$input_parent_zero_child_one_n,
        stringsAsFactors = FALSE
      ),
      pooled[[tier]]
    )
  }))
  write_charls_cohort_csv(
    mi_diagnostics,
    file.path(out_dir, "stage3_charls_mi_diagnostics_v43.csv")
  )

  hashes <- c(
    analysis_spec = sha256_file(paths$spec),
    private_manifest = sha256_file(paths$manifest),
    decision_log = sha256_file(paths$decision_log),
    stage3_blueprint = sha256_file(paths$blueprint)
  )
  registry <- dplyr::bind_rows(lapply(names(pooled), function(tier) {
    tier_diag <- model_diagnostics[
      grepl(paste0("_", tolower(tier), "_imp1$"), model_diagnostics$model_id),
      ,
      drop = FALSE
    ]
    registry_row(
      pooled[[tier]],
      analysis_id = paste0("v43_s3_charls_pc_e0_", tolower(tier)),
      exposure_id = "E0",
      sample_id = "charls_primary_mortality_eligible_common_mi",
      model_tier = tier,
      formula = formulas_e0[[tier]],
      model_diagnostic = tier_diag,
      hashes = hashes,
      e0_hash = e0_hash,
      knot_hash = knot_hash,
      mi_m = imp$m,
      warnings = model_diagnostics$warnings[grepl(paste0("_", tolower(tier), "_"), model_diagnostics$model_id)]
    )
  }))

  # Physical-unit sensitivity: unchanged participants, imputations, covariates,
  # knots, and frozen E0 means; only the exposure denominator changes to 100 L/min.
  formulas_e0b <- model_formulas("E0b")
  fits_e0b <- fit_across_imputations(
    imp,
    period,
    knots,
    formulas_e0b,
    "v43_s3_charls_pc_e0b"
  )
  model_diagnostics <- dplyr::bind_rows(
    model_diagnostics,
    dplyr::bind_rows(lapply(fits_e0b, function(tier_fits) {
      dplyr::bind_rows(lapply(tier_fits, `[[`, "diagnostics"))
    }))
  )
  pooled_e0b <- lapply(names(fits_e0b), function(tier) pool_scalar_rubin(fits_e0b[[tier]], "E0b"))
  names(pooled_e0b) <- names(fits_e0b)
  registry_e0b <- dplyr::bind_rows(lapply(names(pooled_e0b), function(tier) {
    diag <- fits_e0b[[tier]][[1]]$diagnostics
    registry_row(
      pooled_e0b[[tier]],
      analysis_id = paste0("v43_s3_charls_pc_e0b_", tolower(tier)),
      exposure_id = "E0b",
      sample_id = "charls_primary_mortality_eligible_common_mi",
      model_tier = tier,
      formula = formulas_e0b[[tier]],
      model_diagnostic = diag,
      hashes = hashes,
      e0_hash = e0_hash,
      knot_hash = knot_hash,
      mi_m = imp$m,
      warnings = vapply(fits_e0b[[tier]], function(x) x$diagnostics$warnings, character(1))
    )
  }))
  registry <- dplyr::bind_rows(registry, registry_e0b)

  # Complete-case A0-A2 use one common A2-complete participant set.
  cc_fits <- fit_complete_case_set(
    master,
    period,
    knots,
    formulas_e0,
    "v43_s3_charls_pc_e0_complete_case"
  )
  model_diagnostics <- dplyr::bind_rows(
    model_diagnostics,
    dplyr::bind_rows(lapply(cc_fits, `[[`, "diagnostics"))
  )
  cc_registry <- dplyr::bind_rows(lapply(names(cc_fits), function(tier) {
    fit <- cc_fits[[tier]]
    term <- "E0"
    b <- unname(fit$coefficients[[term]])
    se <- sqrt(unname(fit$variance[term, term]))
    df <- fit$diagnostics$design_df[[1]]
    critical <- stats::qt(0.975, df = df)
    pooled_cc <- data.frame(
      estimate = b,
      standard_error = se,
      ci_low = b - critical * se,
      ci_high = b + critical * se,
      p_value = 2 * stats::pt(abs(b / se), df = df, lower.tail = FALSE),
      fraction_missing_information = 0,
      relative_efficiency = 1,
      monte_carlo_error = 0,
      monte_carlo_error_fraction = 0
    )
    registry_row(
      pooled_cc,
      analysis_id = paste0("v43_s3_charls_pc_e0_", tolower(tier), "_complete_case"),
      exposure_id = "E0",
      sample_id = "charls_common_A2_complete_case",
      model_tier = tier,
      formula = formulas_e0[[tier]],
      model_diagnostic = fit$diagnostics,
      hashes = hashes,
      e0_hash = e0_hash,
      knot_hash = knot_hash,
      mi_m = 0L,
      warnings = fit$diagnostics$warnings
    )
  }))
  registry <- dplyr::bind_rows(registry, cc_registry)

  # Prespecified nonlinear exposure test: E0 linear plus two restricted-cubic
  # nonlinear components. The nonlinear test jointly pools both added terms.
  # No E0-by-time interaction is fitted or reported after the estimability
  # amendment. The existing cohort-specific output filename is retained solely
  # to satisfy the cross-cohort artifact contract.
  spline_formulas <- model_formulas("E0", spline_exposure = TRUE)
  spline_fits <- fit_across_imputations(
    imp,
    period,
    knots,
    list(A1_exposure_spline = spline_formulas$A1),
    "v43_s3_charls_pc_e0_spline"
  )$A1_exposure_spline
  model_diagnostics <- dplyr::bind_rows(
    model_diagnostics,
    dplyr::bind_rows(lapply(spline_fits, `[[`, "diagnostics"))
  )
  spline_overall <- pool_multivariate_rubin(
    spline_fits,
    c("E0_linear", "E0_nonlinear1", "E0_nonlinear2"),
    "v43_s3_charls_pc_e0_a1_spline_overall"
  )
  spline_nonlinear <- pool_multivariate_rubin(
    spline_fits,
    c("E0_nonlinear1", "E0_nonlinear2"),
    "v43_s3_charls_pc_e0_a1_spline_nonlinear"
  )
  nonlinearity_tests <- dplyr::bind_rows(spline_overall, spline_nonlinear)
  nonlinearity_tests$cohort <- "CHARLS"
  nonlinearity_tests <- nonlinearity_tests[
    ,
    c("cohort", setdiff(names(nonlinearity_tests), "cohort"))
  ]
  expected_time_test_ids <- c(
    "v43_s3_charls_pc_e0_a1_spline_overall",
    "v43_s3_charls_pc_e0_a1_spline_nonlinear"
  )
  if (nrow(nonlinearity_tests) != 2L ||
      !setequal(nonlinearity_tests$test_id, expected_time_test_ids) ||
      anyDuplicated(nonlinearity_tests$test_id)) {
    stop(
      "The post-amendment CHARLS time-varying-effects artifact must contain ",
      "exactly the two registered spline tests and no window/time interaction.",
      call. = FALSE
    )
  }
  write_charls_cohort_csv(
    nonlinearity_tests,
    file.path(out_dir, "stage3_charls_time_varying_effects_v43.csv")
  )

  # Boundary-coded and strict-measurement sensitivity samples reuse the primary
  # E0 constants and the same completed covariates. They are never restandardized.
  sensitivity_definitions <- list(
    boundary_excluded = master$pef_w1_rowmax != 30 & master$pef_w1_rowmax != 890,
    strict_measurement = master$pef_w1_strict_protocol %in% TRUE & master$pef_w1_valid_n >= 2
  )
  sensitivity_registry <- list()
  sensitivity_diagnostics <- list()
  for (sensitivity_id in names(sensitivity_definitions)) {
    ids <- master$participant_id[sensitivity_definitions[[sensitivity_id]] %in% TRUE]
    period_s <- period[period$participant_id %in% ids, , drop = FALSE]
    fits_s <- fit_across_imputations(
      imp,
      period_s,
      knots,
      list(A1 = formulas_e0$A1),
      paste0("v43_s3_charls_pc_e0_a1_", sensitivity_id)
    )$A1
    pool_s <- pool_scalar_rubin(fits_s, "E0")
    sensitivity_diagnostics[[sensitivity_id]] <- dplyr::bind_rows(
      lapply(fits_s, `[[`, "diagnostics")
    )
    sensitivity_registry[[sensitivity_id]] <- registry_row(
      pool_s,
      paste0("v43_s3_charls_pc_e0_a1_", sensitivity_id),
      "E0",
      paste0("charls_", sensitivity_id, "_common_mi"),
      "A1",
      formulas_e0$A1,
      fits_s[[1]]$diagnostics,
      hashes,
      e0_hash,
      knot_hash,
      imp$m,
      warnings = vapply(fits_s, function(x) x$diagnostics$warnings, character(1))
    )
  }
  registry <- dplyr::bind_rows(registry, dplyr::bind_rows(sensitivity_registry))
  model_diagnostics <- dplyr::bind_rows(
    model_diagnostics,
    dplyr::bind_rows(sensitivity_diagnostics)
  )

  # W2 landmark sensitivity. Eligibility is conditioned on explicit known
  # survival at W2 and at least one subsequently observed W2-origin follow-up
  # window. Every W1-origin interval is removed, so W2 is time zero. This is a
  # reverse-causation robustness probe among conditional survivors; it is not
  # claimed to eliminate reverse causation or recover a baseline-population
  # estimand.
  w2_landmark_period <- build_w2_landmark_period(master, period)
  w2_landmark_fits <- fit_across_imputations(
    imp,
    w2_landmark_period,
    knots,
    list(A1 = formulas_e0$A1),
    "v43_s3_charls_pc_e0_a1_w2_landmark_conditional_survivor"
  )$A1
  model_diagnostics <- dplyr::bind_rows(
    model_diagnostics,
    dplyr::bind_rows(lapply(w2_landmark_fits, `[[`, "diagnostics"))
  )
  w2_landmark_pool <- pool_scalar_rubin(w2_landmark_fits, "E0")
  w2_landmark_registry <- registry_row(
    w2_landmark_pool,
    "v43_s3_charls_pc_e0_a1_w2_landmark_conditional_survivor",
    "E0",
    "charls_known_alive_w2_with_post_w2_explicit_followup_common_mi",
    "A1",
    formulas_e0$A1,
    w2_landmark_fits[[1]]$diagnostics,
    hashes,
    e0_hash,
    knot_hash,
    imp$m,
    warnings = vapply(
      w2_landmark_fits,
      function(x) x$diagnostics$warnings,
      character(1)
    )
  )
  w2_landmark_registry$sensitivity_role <-
    "reverse-causation robustness probe; conditional on explicit known survival at W2"
  w2_landmark_registry$conditioning_statement <-
    "W2 is time zero; all start_wave<2 intervals excluded; does not eliminate reverse causation"
  registry <- dplyr::bind_rows(registry, w2_landmark_registry)

  # Influence audit: complete-case A1 leave-one-community-PSU refits. This is a
  # prespecified diagnostic, not a model-selection device.
  cc_input <- apply_charls_smoking_parent_rule(master)
  cc_master <- attach_passive_variables(
    cc_input[complete_case_mask(cc_input), , drop = FALSE],
    knots
  )
  cc_period <- period[period$participant_id %in% cc_master$participant_id, , drop = FALSE]
  psus <- sort(unique(cc_master$community_id))
  loo <- lapply(psus, function(psu) {
    ids <- cc_master$participant_id[cc_master$community_id != psu]
    dat <- cc_master[cc_master$participant_id %in% ids, , drop = FALSE]
    pp <- cc_period[cc_period$participant_id %in% ids, , drop = FALSE]
    fit <- fit_one_survey_model(dat, pp, formulas_e0$A1, "complete_case_A1_leave_one_PSU")
    data.frame(
      omitted_psu_rank = match(psu, psus),
      estimate = unname(fit$coefficients[["E0"]]),
      standard_error = sqrt(unname(fit$variance["E0", "E0"])),
      warnings = fit$diagnostics$warnings,
      stringsAsFactors = FALSE
    )
  })
  loo <- dplyr::bind_rows(loo)
  full_cc_a1_estimate <- unname(cc_fits$A1$coefficients[["E0"]])
  full_cc_a1_sign <- sign(full_cc_a1_estimate)
  influence_summary <- data.frame(
    diagnostic_id = "v43_s3_charls_pc_e0_a1_complete_case_leave_one_psu",
    psu_refits = nrow(loo),
    full_complete_case_a1_estimate = full_cc_a1_estimate,
    estimate_min = min(loo$estimate),
    estimate_q05 = stats::quantile(loo$estimate, 0.05),
    estimate_median = stats::median(loo$estimate),
    estimate_q95 = stats::quantile(loo$estimate, 0.95),
    estimate_max = max(loo$estimate),
    sign_reversal_count = if (full_cc_a1_sign == 0) {
      NA_integer_
    } else {
      sum(loo$estimate * full_cc_a1_estimate < 0)
    },
    sign_reversal_reference = "full complete-case A1 E0 estimate; exact zero reference yields NA",
    nonempty_warning_refits = sum(nzchar(loo$warnings)),
    stringsAsFactors = FALSE
  )
  write_charls_cohort_csv(
    influence_summary,
    file.path(out_dir, "stage3_charls_psu_influence_summary_v43.csv")
  )
  write_charls_cohort_csv(
    model_diagnostics,
    file.path(out_dir, "stage3_charls_model_diagnostics_v43.csv")
  )

  primary_scale_registry <- utils::read.csv(paths$charls_e0, stringsAsFactors = FALSE) |>
    dplyr::filter(sample_id == "primary_mortality_eligible") |>
    dplyr::arrange(sex_code)
  registry$e0_mean_male_l_min <- primary_scale_registry$weighted_mean_l_min[
    primary_scale_registry$sex_code == 1
  ]
  registry$e0_sd_male_l_min <- primary_scale_registry$weighted_sd_l_min[
    primary_scale_registry$sex_code == 1
  ]
  registry$e0_mean_female_l_min <- primary_scale_registry$weighted_mean_l_min[
    primary_scale_registry$sex_code == 2
  ]
  registry$e0_sd_female_l_min <- primary_scale_registry$weighted_sd_l_min[
    primary_scale_registry$sex_code == 2
  ]
  primary_pef_checksum <- digest::digest(
    master[c("participant_id", "pef_w1_rowmax")],
    algo = "sha256",
    serialize = TRUE
  )
  registry$primary_pef_ledger_column <- "pef_w1_rowmax"
  registry$primary_pef_construction_checksum <- primary_pef_checksum

  required_registry <- utils::read.csv(
    file.path(root, "work_v43", "registry_schema_v43.csv"),
    stringsAsFactors = FALSE
  )
  missing_registry_fields <- setdiff(required_registry$field[required_registry$required == "yes"], names(registry))
  if (length(missing_registry_fields)) {
    stop("Stage 3 registry lacks required fields: ", paste(missing_registry_fields, collapse = ", "), call. = FALSE)
  }
  if (anyDuplicated(registry$analysis_id)) stop("Stage 3 analysis_id values are not globally unique.", call. = FALSE)
  expected_registry_ids <- c(
    paste0("v43_s3_charls_pc_e0_", c("a0", "a1", "a2")),
    paste0("v43_s3_charls_pc_e0b_", c("a0", "a1", "a2")),
    paste0(
      "v43_s3_charls_pc_e0_",
      c("a0_complete_case", "a1_complete_case", "a2_complete_case")
    ),
    "v43_s3_charls_pc_e0_a1_boundary_excluded",
    "v43_s3_charls_pc_e0_a1_strict_measurement",
    "v43_s3_charls_pc_e0_a1_w2_landmark_conditional_survivor"
  )
  if (nrow(registry) != 12L ||
      !setequal(registry$analysis_id, expected_registry_ids)) {
    stop(
      "The amended CHARLS registry must contain exactly the 12 frozen generic, ",
      "complete-case, measurement-sensitivity, and W2-landmark rows.",
      call. = FALSE
    )
  }
  write_charls_cohort_csv(
    registry,
    file.path(out_dir, "stage3_charls_primary_association_registry_v43.csv")
  )

  # Row-level output boundary. No row-level object is written anywhere else.
  saveRDS(
    list(
      person_master = master,
      person_period_skeleton = period,
      mi_specification = mi_spec,
      spline_knots = knots,
      time_basis_support_audit = time_support_audit,
      inferential_time_basis =
        "factor(end_wave) + offset(log(nominal_years))",
      window_id_role = "descriptive transition-pathway provenance only",
      e0_by_time_interaction_status =
        "NOT FITTED after the post-estimability amendment",
      e0_scale_sha256 = e0_hash,
      primary_pef_column = "pef_w1_rowmax",
      primary_pef_construction_checksum = primary_pef_checksum,
      longitudinal_w3_change_status = "NONBLOCKING NO-GO; no individual W3 change/slope used"
    ),
    file.path(sensitive_dir, "charls_stage3_analysis_ledger_v43.rds")
  )

  hard_rhat_values <- final_chain_convergence$rhat[
    final_chain_convergence$hard_gate %in% TRUE &
      is.finite(final_chain_convergence$rhat)
  ]
  maximum_hard_rhat <- if (length(hard_rhat_values)) {
    max(hard_rhat_values)
  } else {
    NA_real_
  }
  log_lines <- c(
    paste0("CHARLS Stage 3 completed: ", format(Sys.time(), tz = "Asia/Shanghai", usetz = TRUE)),
    "Authorization: Gate0 PASS; Gate1 PASS; core Gate2 PASS; outcome_execution_allowed=true",
    paste0("Primary structural N: ", nrow(master)),
    paste0("Transition rows: ", nrow(period)),
    paste0("Deaths: ", sum(period$period_event)),
    paste0("MI imputations: ", imp$m),
    paste0("MI iterations: ", mi_spec$selected_maxit),
    paste0("Maximum hard-gate improved R-hat: ", signif(maximum_hard_rhat, 6)),
    paste0("Registered coefficient rows: ", nrow(registry)),
    paste0(
      "Pre-fit necessary time-basis support strata: ",
      nrow(time_support_audit), "/", nrow(time_support_audit), " PASS"
    ),
    paste(
      "Inferential time basis:",
      "factor(end_wave) + offset(log(nominal_years))"
    ),
    paste(
      "Primary interpretation: nominal-duration interval-hazard ratio;",
      "scheduled wave-year duration only, not an exact-date Cox HR"
    ),
    paste(
      "Post-estimability amendment: no primary participant or death removed;",
      "window_id retained only as descriptive transition-pathway provenance"
    ),
    "Exposure-by-time interaction: not fitted or reported",
    "Reverse-causation sensitivity: W2 landmark among participants explicitly known alive at W2 with post-W2 follow-up; conditional-survivor probe only",
    "Wave-3 individual change/slope: not analyzed (nonblocking measurement NO-GO)",
    "Row-level outputs: derived_sensitive/v43/charls_stage3_analysis_ledger_v43.rds only"
  )
  writeLines(log_lines, file.path(log_dir, "stage3_charls_primary_association_v43.log"), useBytes = TRUE)

  qa_lines <- c(
    "# CHARLS v43 Stage 3 primary association QA",
    "",
    paste0("Generated: ", format(Sys.time(), tz = "Asia/Shanghai", usetz = TRUE)),
    "",
    paste(
      "Authorization, one-to-one joins, frozen E0 constants, vital-status",
      "sequence mapping, pre-fit time-basis support, common MI samples,",
      "fixed spline knots, survey design, model rank, MI Monte Carlo error,",
      "and output boundaries were checked before registration."
    ),
    "",
    paste0("- Structural participants: ", nrow(master)),
    paste0("- Person-period transitions: ", nrow(period)),
    paste0("- Death events: ", sum(period$period_event)),
    paste0("- Community PSUs: ", length(unique(master$community_id))),
    paste0("- MI imputations: ", imp$m),
    paste0("- MI iterations: ", mi_spec$selected_maxit),
    paste0("- Maximum hard-gate improved R-hat: ", signif(maximum_hard_rhat, 6)),
    paste0("- Registered models/sensitivities: ", nrow(registry)),
    paste0(
      "- Pre-fit inferential end-wave strata passing necessary support gate: ",
      sum(time_support_audit$time_basis_support_pass %in% TRUE),
      "/", nrow(time_support_audit)
    ),
    "",
    paste(
      "The primary A1 coefficient is a nominal-duration interval-hazard",
      "association from a survey-weighted complementary log-log model using",
      "factor(end_wave) plus offset(log(nominal_years)). Nominal years come",
      "only from scheduled wave years. Unknown status waves were skipped, code",
      "6 was never counted as a new death, and no exact death date was invented."
    ),
    "",
    paste(
      "Before any outcome fit, every planned sample had both outcome states,",
      "overlapping observed E0 ranges, positive weighted support, and at least",
      "two community PSUs per outcome state within every inferential end-wave",
      "stratum. The amendment changed only the time structure; no primary",
      "participant or death was removed. window_id remains descriptive",
      "transition-pathway provenance and no E0-by-time interaction was fitted."
    ),
    "",
    "The reverse-causation robustness analysis uses W2 as a landmark, conditions on explicit known survival at W2, requires a later observed follow-up window, and removes every W1-origin interval. It is a conditional-survivor probe and is not interpreted as eliminating reverse causation.",
    "",
    "MICE mixing used rank-normalized and folded split R-hat for every computable quantitative chain-mean/SD trace and per-level unordered-category proportion trace. Low-support aggregate traces were hard-gated internally but were not released.",
    "",
    "Wave-3 person-specific change and slope remain disabled because Gate 2 found unexplained drift above 0.20 W1 SD; this does not block the baseline E0 analysis."
  )
  writeLines(
    qa_lines,
    file.path(qa_dir, "STAGE3_CHARLS_PRIMARY_ASSOCIATION_QA_v43.md"),
    useBytes = TRUE
  )

  completion_manifest <- write_charls_completion_manifest(
    root,
    authorization,
    run_context
  )
  message(
    "CHARLS Stage 3 completed in run-scoped staging with ",
    nrow(completion_manifest),
    " hash-bound artifacts; final outputs are not yet promoted."
  )
}

write_authorized_execution_failure <- function(
    root, error_message, checkpoint_diagnostics = NULL) {
  out_dir <- file.path(root, "results", "v43")
  log_dir <- file.path(root, "logs", "v43")
  dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)
  dir.create(log_dir, recursive = TRUE, showWarnings = FALSE)
  failure <- data.frame(
    cohort = "CHARLS",
    stage = 3L,
    status = "FAIL",
    reason = one_line(error_message),
    row_level_result_published = FALSE,
    coefficient_registry_published = FALSE,
    run_timestamp = format(Sys.time(), tz = "Asia/Shanghai", usetz = TRUE),
    stringsAsFactors = FALSE
  )
  atomic_write_csv(
    failure,
    file.path(out_dir, "stage3_charls_execution_failure_v43.csv")
  )
  if (!is.null(checkpoint_diagnostics) && nrow(checkpoint_diagnostics)) {
    aggregate_columns <- c(
      "cohort", "analysis_id", "mi_run", "checkpoint_order",
      "checkpoint_iteration", "selected_checkpoint", "variable", "parameter",
      "category_level", "missing_n", "iterations", "chains",
      "retained_iterations", "applicability", "rank_normalized_split_rhat",
      "folded_split_rhat", "rhat", "folded_identifiable",
      "raw_trace_constant", "classic_final_half_rhat",
      "distinct_trace_values", "median_lag1_ac",
      "standardized_last5_shift", "hard_gate", "pass",
      "diagnostic_status", "detail"
    )
    diagnostics <- checkpoint_diagnostics[
      intersect(aggregate_columns, names(checkpoint_diagnostics))
    ]
    atomic_write_csv(
      diagnostics,
      file.path(
        out_dir,
        "stage3_charls_mi_convergence_failure_checkpoints_v43.csv"
      )
    )
  }
  atomic_write_lines(
    c(
      paste0("Authorized CHARLS Stage 3 execution failed: ", failure$run_timestamp),
      paste0("Reason: ", failure$reason),
      "Only the current run-scoped staging directory was removed.",
      "Any prior successfully promoted CHARLS Stage 3 outputs were preserved.",
      "No failed or partial coefficient is eligible for reporting."
    ),
    file.path(log_dir, "stage3_charls_execution_failure_v43.log")
  )
  invisible(failure)
}

main <- function() {
  root <- project_root()

  # This is the first executable action. It reads only aggregate governance
  # assets. Row-level data and outcome fields remain unopened until it passes.
  authorization <- authorization_gate(root)

  run_context <- NULL
  tryCatch(
    {
      require_stage3_packages()
      run_context <- new_charls_run_context(root)
      run_authorized_stage3(root, authorization, run_context)
      atomic_promote_charls_run(root, run_context)
      run_context <- NULL
      message("CHARLS Stage 3 completed, atomically promoted, and registered under v43.")
    },
    error = function(e) {
      original_error <- conditionMessage(e)
      checkpoint_diagnostics <- if (inherits(e, "stage3_mice_convergence_error")) {
        e$checkpoint_diagnostics
      } else {
        NULL
      }
      cleanup_error <- tryCatch(
        {
          cleanup_charls_run_staging(run_context)
          NULL
        },
        error = function(clean_e) conditionMessage(clean_e)
      )
      failure_write_error <- tryCatch(
        {
          write_authorized_execution_failure(
            root,
            original_error,
            checkpoint_diagnostics
          )
          NULL
        },
        error = function(write_e) conditionMessage(write_e)
      )
      stop(
        "Authorized CHARLS Stage 3 execution failed; prior successful outputs were preserved. ",
        original_error,
        if (!is.null(cleanup_error)) paste0(" Staging cleanup also failed: ", cleanup_error) else "",
        if (!is.null(failure_write_error)) {
          paste0(" Failure-marker writing also failed: ", failure_write_error)
        } else {
          ""
        },
        call. = FALSE
      )
    }
  )
}

if (sys.nframe() == 0L) {
  main()
}
