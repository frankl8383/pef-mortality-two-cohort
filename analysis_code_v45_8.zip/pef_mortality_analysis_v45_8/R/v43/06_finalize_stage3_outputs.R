# v43 Stage 3 aggregate-output finalizer.
#
# This script never opens row-level ledgers and never fits a model. CHARLS and
# NHANES write cohort-specific, transactionally promoted outputs. Only after
# both successful output sets exist does this finalizer create the shared
# manuscript-facing aggregate tables in a deterministic order.

options(stringsAsFactors = FALSE)

project_root <- function() {
  args <- commandArgs(trailingOnly = FALSE)
  file_arg <- grep("^--file=", args, value = TRUE)
  if (length(file_arg)) {
    script <- sub("^--file=", "", file_arg[[1]])
    return(normalizePath(file.path(dirname(script), "..", ".."), mustWork = TRUE))
  }
  normalizePath(getwd(), mustWork = TRUE)
}

sha256_file <- function(path) {
  if (!file.exists(path) || dir.exists(path)) return(NA_character_)
  digest::digest(file = path, algo = "sha256", serialize = FALSE)
}

table_minimum_schema <- function(stem) {
  schemas <- list(
    spline_knot_registry = c(
      "cohort", "variable", "weighted_q05", "weighted_q35",
      "weighted_q65", "weighted_q95"
    ),
    sample_event_audit = c(
      "cohort", "audit_type", "stratum", "n_people", "deaths"
    ),
    model_diagnostics = c(
      "cohort", "model_id", "n_participants", "events",
      "matrix_columns", "matrix_rank"
    ),
    mi_diagnostics = c(
      "cohort", "model_tier", "exposure_id", "estimate", "standard_error"
    ),
    mi_chain_convergence = c(
      "cohort", "variable", "parameter", "hard_gate", "pass"
    ),
    time_varying_effects = c(
      "cohort", "test_id", "pooling_rule", "p_value"
    ),
    primary_association_registry = c(
      "cohort", "analysis_id", "stage", "estimand_id", "exposure_id",
      "sample_id", "estimate", "standard_error"
    )
  )
  schema <- schemas[[stem]]
  if (is.null(schema)) stop("Unknown Stage 3 shared-table stem: ", stem, call. = FALSE)
  schema
}

read_cohort_csv <- function(
    path, cohort, stem, expected_bytes, expected_sha256) {
  if (!file.exists(path) || file.info(path)$size <= 0) {
    stop("Missing cohort-specific Stage 3 output: ", path, call. = FALSE)
  }
  bytes_before <- as.numeric(file.info(path)$size)
  hash_before <- sha256_file(path)
  provenance_before <- is.finite(bytes_before) &&
    bytes_before == suppressWarnings(as.numeric(expected_bytes)) &&
    grepl("^[0-9a-fA-F]{64}$", as.character(expected_sha256)) &&
    identical(tolower(hash_before), tolower(as.character(expected_sha256)))
  if (!provenance_before) {
    stop("Cohort-specific source changed before read: ", path, call. = FALSE)
  }
  dat <- utils::read.csv(path, stringsAsFactors = FALSE, check.names = FALSE)
  bytes_after <- as.numeric(file.info(path)$size)
  hash_after <- sha256_file(path)
  provenance_after <- is.finite(bytes_after) &&
    bytes_after == suppressWarnings(as.numeric(expected_bytes)) &&
    identical(tolower(hash_after), tolower(as.character(expected_sha256)))
  if (!provenance_after) {
    stop("Cohort-specific source changed during read: ", path, call. = FALSE)
  }
  required <- table_minimum_schema(stem)
  if (!nrow(dat) || !all(required %in% names(dat))) {
    stop(
      "Cohort-specific output is empty or lacks its minimum schema (",
      paste(setdiff(required, names(dat)), collapse = "; "), "): ", path,
      call. = FALSE
    )
  }
  if (any(is.na(dat$cohort)) || any(toupper(dat$cohort) != toupper(cohort))) {
    stop("Unexpected cohort value in ", path, call. = FALSE)
  }
  identifier <- switch(
    stem,
    spline_knot_registry = "variable",
    sample_event_audit = NULL,
    model_diagnostics = "model_id",
    mi_diagnostics = NULL,
    mi_chain_convergence = NULL,
    time_varying_effects = "test_id",
    primary_association_registry = "analysis_id"
  )
  if (!is.null(identifier)) {
    values <- as.character(dat[[identifier]])
    if (any(is.na(values) | !nzchar(values))) {
      stop("Missing ", identifier, " in cohort-specific output: ", path, call. = FALSE)
    }
    if (stem %in% c(
      "spline_knot_registry", "time_varying_effects",
      "primary_association_registry"
    ) && anyDuplicated(values)) {
      stop("Duplicate ", identifier, " in cohort-specific output: ", path, call. = FALSE)
    }
  }
  dat
}

completion_expectation <- function(manifest, path) {
  normalized <- normalizePath(path, mustWork = FALSE)
  manifest_paths <- normalizePath(as.character(manifest$path), mustWork = FALSE)
  row <- manifest[manifest_paths == normalized, , drop = FALSE]
  if (nrow(row) != 1L) {
    stop("Completion manifest does not uniquely bind source path: ", path, call. = FALSE)
  }
  list(bytes = row$bytes[[1]], sha256 = row$sha256[[1]])
}

deterministic_sort <- function(dat) {
  candidate_keys <- c(
    "cohort", "audit_type", "stratum", "time_basis", "start_wave",
    "end_wave", "analysis_id", "test_id", "diagnostic_id", "model_id",
    "model_prefix", "imputation_id", "model_tier", "exposure_id", "sample_id",
    "variable", "parameter", "cycle_label", "quality_layer"
  )
  keys <- intersect(candidate_keys, names(dat))
  if (!length(keys) || nrow(dat) < 2L) return(dat)
  order_args <- lapply(keys, function(key) {
    value <- dat[[key]]
    if (is.numeric(value)) value else as.character(value)
  })
  ord <- do.call(order, c(order_args, list(na.last = TRUE, method = "radix")))
  dat[ord, , drop = FALSE]
}

expected_charls_time_varying_ids <- function() {
  c(
    "v43_s3_charls_pc_e0_a1_spline_overall",
    "v43_s3_charls_pc_e0_a1_spline_nonlinear"
  )
}

expected_nhanes_time_varying_ids <- function() {
  c(
    "v43_s3_nhanes_pn_e0_a1_window_heterogeneity",
    "v43_s3_nhanes_pn_e0_a1_window_0_2",
    "v43_s3_nhanes_pn_e0_a1_window_2_5",
    "v43_s3_nhanes_pn_e0_a1_window_gt5",
    "v43_s3_nhanes_pn_e0_a1_log_time_supportive",
    "v43_s3_nhanes_pn_e0_a1_spline_overall",
    "v43_s3_nhanes_pn_e0_a1_spline_nonlinear"
  )
}

expected_nhanes_registry_ids <- function() {
  c(
    "v43_s3_nhanes_pn_e0_a0",
    "v43_s3_nhanes_pn_e0_a1",
    "v43_s3_nhanes_pn_e0_a2",
    "v43_s3_nhanes_pn_e0_code5_positive_a2",
    "v43_s3_nhanes_pn_e0_age60_79_a1",
    "v43_s3_nhanes_pn_e0_age60_79_a2",
    "v43_s3_nhanes_pn_e0b_a0",
    "v43_s3_nhanes_pn_e0b_a1",
    "v43_s3_nhanes_pn_e0b_a2",
    "v43_s3_nhanes_pn_e0_a0_complete_case",
    "v43_s3_nhanes_pn_e0_a1_complete_case",
    "v43_s3_nhanes_pn_e0_a2_complete_case",
    "v43_s3_nhanes_pn_e0_two_year_landmark_a1",
    "v43_s3_nhanes_pn_e0_pef_A_acc3_a0",
    "v43_s3_nhanes_pn_e0_pef_A_acc3_a1",
    "v43_s3_nhanes_pn_e0_pef_A_acc3_a2",
    "v43_s3_nhanes_pn_e0_pef_A_plus_C_a0",
    "v43_s3_nhanes_pn_e0_pef_A_plus_C_a1",
    "v43_s3_nhanes_pn_e0_pef_A_plus_C_a2",
    "v43_s3_nhanes_pn_e0_pef_ABC_a0",
    "v43_s3_nhanes_pn_e0_pef_ABC_a1",
    "v43_s3_nhanes_pn_e0_pef_ABC_a2",
    "v43_s3_nhanes_pn_e0_gt900_influence_exclusion_a1",
    "v43_s3_nhanes_pn_e0_leave_cycle_E_a1",
    "v43_s3_nhanes_pn_e0_leave_cycle_F_a1",
    "v43_s3_nhanes_pn_e0_leave_cycle_G_a1"
  )
}

validate_time_varying_contract <- function(charls, nhanes) {
  common_fields <- c(
    "test_id", "pooling_rule", "terms", "df", "statistic", "p_value"
  )
  if (!all(common_fields %in% names(charls)) ||
      !all(common_fields %in% names(nhanes))) {
    stop(
      "A cohort time-varying-effects table lacks the frozen finalizer fields.",
      call. = FALSE
    )
  }
  exact_id_contract <- function(dat, expected) {
    nrow(dat) == length(expected) &&
      !anyDuplicated(as.character(dat$test_id)) &&
      setequal(as.character(dat$test_id), expected)
  }
  common_numeric_contract <- function(dat) {
    df <- suppressWarnings(as.numeric(dat$df))
    statistic <- suppressWarnings(as.numeric(dat$statistic))
    p <- suppressWarnings(as.numeric(dat$p_value))
    all(is.finite(df) & df > 0) &&
      all(is.finite(statistic)) &&
      all(is.finite(p) & p >= 0 & p <= 1) &&
      all(!is.na(dat$pooling_rule) &
            nzchar(trimws(as.character(dat$pooling_rule)))) &&
      all(!is.na(dat$terms) & nzchar(trimws(as.character(dat$terms))))
  }
  charls_ok <-
    exact_id_contract(charls, expected_charls_time_varying_ids()) &&
    common_numeric_contract(charls)

  nhanes_effect_ids <- c(
    "v43_s3_nhanes_pn_e0_a1_window_0_2",
    "v43_s3_nhanes_pn_e0_a1_window_2_5",
    "v43_s3_nhanes_pn_e0_a1_window_gt5",
    "v43_s3_nhanes_pn_e0_a1_log_time_supportive"
  )
  effect_fields <- c(
    "estimate", "standard_error", "ci_low", "ci_high",
    "exp_estimate", "exp_ci_low", "exp_ci_high"
  )
  effect <- as.character(nhanes$test_id) %in% nhanes_effect_ids
  nhanes_effect_ok <- all(effect_fields %in% names(nhanes)) &&
    all(vapply(
      effect_fields,
      function(field) {
        all(is.finite(suppressWarnings(as.numeric(nhanes[[field]][effect]))))
      },
      logical(1)
    )) &&
    all(suppressWarnings(as.numeric(nhanes$standard_error[effect])) > 0) &&
    all(suppressWarnings(as.numeric(nhanes$ci_low[effect])) <=
          suppressWarnings(as.numeric(nhanes$ci_high[effect]))) &&
    isTRUE(all.equal(
      suppressWarnings(as.numeric(nhanes$exp_estimate[effect])),
      exp(suppressWarnings(as.numeric(nhanes$estimate[effect]))),
      tolerance = 1e-12,
      check.attributes = FALSE
    )) &&
    isTRUE(all.equal(
      suppressWarnings(as.numeric(nhanes$exp_ci_low[effect])),
      exp(suppressWarnings(as.numeric(nhanes$ci_low[effect]))),
      tolerance = 1e-12,
      check.attributes = FALSE
    )) &&
    isTRUE(all.equal(
      suppressWarnings(as.numeric(nhanes$exp_ci_high[effect])),
      exp(suppressWarnings(as.numeric(nhanes$ci_high[effect]))),
      tolerance = 1e-12,
      check.attributes = FALSE
    )) &&
    all(vapply(
      effect_fields,
      function(field) all(is.na(nhanes[[field]][!effect])),
      logical(1)
    ))
  nhanes_status_ok <-
    all(c("diagnostic_role", "diagnostic_status") %in% names(nhanes)) &&
    all(as.character(nhanes$diagnostic_status) == "PASS") &&
    identical(
      as.character(nhanes$diagnostic_role[
        match(
          expected_nhanes_time_varying_ids(),
          as.character(nhanes$test_id)
        )
      ]),
      c(
        "PRINCIPAL_TIME_HETEROGENEITY",
        rep("PRINCIPAL_WINDOW_ESTIMATE", 3L),
        "SUPPORTIVE_LOG_LINEAR_TIME_TREND",
        rep("EXPOSURE_FUNCTIONAL_FORM", 2L)
      )
    )
  nhanes_ok <-
    exact_id_contract(nhanes, expected_nhanes_time_varying_ids()) &&
    common_numeric_contract(nhanes) &&
    nhanes_effect_ok &&
    nhanes_status_ok
  if (!charls_ok || !nhanes_ok) {
    stop(
      "Cohort time-varying-effects tables violate exact ID/value/status ",
      "contracts: CHARLS=", charls_ok, "; NHANES=", nhanes_ok,
      call. = FALSE
    )
  }
  invisible(TRUE)
}

validate_time_varying_references <- function(
    charls_registry, nhanes_registry, charls_time, nhanes_time) {
  field <- "time_varying_effect_diagnostic_id"
  if (!field %in% names(charls_registry) ||
      !field %in% names(nhanes_registry)) {
    stop(
      "A cohort primary registry lacks time_varying_effect_diagnostic_id.",
      call. = FALSE
    )
  }
  normalize_refs <- function(x) {
    refs <- trimws(as.character(x))
    refs[is.na(x) | !nzchar(refs)] <- NA_character_
    refs
  }
  charls_refs <- normalize_refs(charls_registry[[field]])
  nhanes_refs <- normalize_refs(nhanes_registry[[field]])
  charls_resolved <- all(vapply(
    charls_refs[!is.na(charls_refs)],
    function(ref) sum(as.character(charls_time$test_id) == ref) == 1L,
    logical(1)
  ))
  nhanes_resolved <- all(vapply(
    nhanes_refs[!is.na(nhanes_refs)],
    function(ref) sum(as.character(nhanes_time$test_id) == ref) == 1L,
    logical(1)
  ))
  nhanes_rows <- which(!is.na(nhanes_refs))
  nhanes_exact <-
    length(nhanes_rows) == 1L &&
    identical(
      as.character(nhanes_registry$analysis_id[nhanes_rows]),
      "v43_s3_nhanes_pn_e0_a1"
    ) &&
    identical(
      nhanes_refs[nhanes_rows],
      "v43_s3_nhanes_pn_e0_a1_window_heterogeneity"
    )
  if (any(!is.na(charls_refs)) || !charls_resolved ||
      !nhanes_resolved || !nhanes_exact) {
    stop(
      "Primary-registry time-varying references violate the same-cohort ",
      "foreign-key contract: CHARLS_nonmissing=", sum(!is.na(charls_refs)),
      "; CHARLS_resolved=", charls_resolved,
      "; NHANES_nonmissing=", length(nhanes_rows),
      "; NHANES_resolved=", nhanes_resolved,
      "; NHANES_exact=", nhanes_exact,
      call. = FALSE
    )
  }
  invisible(TRUE)
}

validate_primary_registry_gate_semantics <- function(charls, nhanes) {
  inferential_fields <- c(
    "estimate", "standard_error", "ci_low", "ci_high", "p_value"
  )
  common_required <- c(
    "cohort", "analysis_id", "gate_status", "n", "events",
    inferential_fields
  )
  missing_charls <- setdiff(common_required, names(charls))
  missing_nhanes <- setdiff(
    c(common_required, "nonestimability_reason", "model_attempt_status"),
    names(nhanes)
  )
  if (length(missing_charls) || length(missing_nhanes)) {
    stop(
      "Primary association registry lacks gate-semantics fields: ",
      if (length(missing_charls)) {
        paste0("CHARLS=", paste(missing_charls, collapse = ","))
      } else {
        "CHARLS=none"
      },
      "; ",
      if (length(missing_nhanes)) {
        paste0("NHANES=", paste(missing_nhanes, collapse = ","))
      } else {
        "NHANES=none"
      },
      call. = FALSE
    )
  }

  normalize_status <- function(x) {
    toupper(trimws(as.character(x)))
  }
  finite_inference <- function(dat) {
    vapply(
      inferential_fields,
      function(field) {
        values <- suppressWarnings(as.numeric(dat[[field]]))
        length(values) == nrow(dat) && all(is.finite(values))
      },
      logical(1)
    )
  }
  nonempty_text <- function(x) {
    values <- trimws(as.character(x))
    !is.na(values) & nzchar(values)
  }

  charls_status <- normalize_status(charls$gate_status)
  if (nrow(charls) != 12L ||
      any(is.na(charls_status) | charls_status != "PASS") ||
      !all(finite_inference(charls))) {
    stop(
      "CHARLS primary registry must contain exactly 12 PASS rows with finite ",
      "estimate, standard_error, confidence limits, and p_value.",
      call. = FALSE
    )
  }

  expected_nhanes_ne_ids <- c(
    "v43_s3_nhanes_pn_e0_age60_79_a1",
    "v43_s3_nhanes_pn_e0_age60_79_a2"
  )
  expected_nhanes_ids <- expected_nhanes_registry_ids()
  if (nrow(nhanes) != length(expected_nhanes_ids) ||
      anyDuplicated(as.character(nhanes$analysis_id)) ||
      !setequal(as.character(nhanes$analysis_id), expected_nhanes_ids)) {
    stop(
      "NHANES primary registry violates the finalizer exact 26-ID contract: ",
      "rows=", nrow(nhanes),
      "; missing=",
      paste(
        setdiff(expected_nhanes_ids, as.character(nhanes$analysis_id)),
        collapse = "|"
      ),
      "; unexpected=",
      paste(
        setdiff(as.character(nhanes$analysis_id), expected_nhanes_ids),
        collapse = "|"
      ),
      call. = FALSE
    )
  }
  nhanes_status <- normalize_status(nhanes$gate_status)
  if (any(is.na(nhanes_status)) ||
      any(!nhanes_status %in% c("PASS", "NOT_ESTIMABLE"))) {
    stop(
      "NHANES primary registry contains a prohibited or unknown gate_status; ",
      "only PASS and the two prespecified NOT_ESTIMABLE rows are allowed.",
      call. = FALSE
    )
  }
  observed_ne_ids <- as.character(
    nhanes$analysis_id[nhanes_status == "NOT_ESTIMABLE"]
  )
  age60_79_ids <- as.character(
    nhanes$analysis_id[
      grepl("^v43_s3_nhanes_pn_e0_age60_79_", as.character(nhanes$analysis_id))
    ]
  )
  if (length(observed_ne_ids) != 2L ||
      !setequal(observed_ne_ids, expected_nhanes_ne_ids) ||
      length(age60_79_ids) != 2L ||
      !setequal(age60_79_ids, expected_nhanes_ne_ids)) {
    stop(
      "NHANES must contain exactly the prespecified age60_79 A1/A2 ",
      "NOT_ESTIMABLE rows and no other age60_79 registry row.",
      call. = FALSE
    )
  }

  ne <- nhanes_status == "NOT_ESTIMABLE"
  ne_inference_is_na <- vapply(
    inferential_fields,
    function(field) all(is.na(nhanes[[field]][ne])),
    logical(1)
  )
  ne_reason_present <- all(
    nonempty_text(nhanes$nonestimability_reason[ne]) &
      nonempty_text(nhanes$model_attempt_status[ne])
  )
  ne_ordered <- nhanes[
    match(expected_nhanes_ne_ids, as.character(nhanes$analysis_id)),
    ,
    drop = FALSE
  ]
  expected_attempt_status <- c(
    "ARCHIVED_NUMERICAL_HARD_GATE_FAILURE",
    "NOT_ATTEMPTED_PANEL_DEPENDENCY"
  )
  ne_metadata_ok <-
    identical(as.integer(ne_ordered$n), c(3346L, 3346L)) &&
    identical(as.integer(ne_ordered$events), c(701L, 701L)) &&
    identical(
      as.character(ne_ordered$model_attempt_status),
      expected_attempt_status
    ) &&
    all(grepl(
      "no post-hoc rescue",
      as.character(ne_ordered$nonestimability_reason),
      fixed = TRUE
    ))
  if (!all(ne_inference_is_na) || !ne_reason_present || !ne_metadata_ok) {
    stop(
      "NHANES NOT_ESTIMABLE rows must have NA inferential values and ",
      "the exact N=3346/events=701 attempt-status/no-rescue metadata.",
      call. = FALSE
    )
  }

  pass <- !ne
  if (!any(pass) ||
      any(nhanes_status[pass] != "PASS") ||
      !all(finite_inference(nhanes[pass, , drop = FALSE]))) {
    stop(
      "Every remaining NHANES primary registry row must be PASS with finite ",
      "estimate, standard_error, confidence limits, and p_value.",
      call. = FALSE
    )
  }
  invisible(TRUE)
}

expected_authorization_assets <- function(root) {
  spec_path <- file.path(root, "work_v43", "analysis_spec_v43.yml")
  spec <- yaml::read_yaml(spec_path)
  resolve <- function(path) {
    if (grepl("^/", path)) path else file.path(root, path)
  }
  data.frame(
    asset = c(
      "analysis_spec", "private_manifest", "decision_log", "stage3_blueprint",
      "stage3_preflight_script", "charls_stage3_script", "nhanes_stage3_script",
      "stage3_output_finalizer_script", "stage3_preflight_validation",
      "gate_state", "stage0_2_validator_report", "stage0_freeze_script",
      "stage0_2_validator_script", "charls_core", "charls_stage1_ledger",
      "charls_e0_scale", "nhanes_stage1_ledger", "nhanes_donor",
      "nhanes_e0_scale", "nhanes_function_routing_audit",
      "nhanes_function_proxy_evidence", "renv_lock",
      "stable_input_inventory", "stage3_authorization_validation",
      "stage0_2_validator_source_inventory"
    ),
    path = c(
      spec_path,
      file.path(root, "results", "v43", "input_manifest_private_v43.csv"),
      resolve(spec$governance$decision_log),
      file.path(root, "output", "qa", "v43_STAGE3_MODEL_BLUEPRINT_20260716.md"),
      file.path(root, "R", "v43", "03b_stage3_preflight.R"),
      file.path(root, "R", "v43", "04_charls_stage3_primary_mortality.R"),
      file.path(root, "R", "v43", "05_nhanes_stage3_primary_mortality.R"),
      file.path(root, "R", "v43", "06_finalize_stage3_outputs.R"),
      file.path(root, "results", "v43", "stage3_preflight_validation_v43.csv"),
      file.path(root, "work_v43", "gate_state_v43.yml"),
      file.path(root, "results", "v43", "gate1_2_validation_v43.csv"),
      file.path(root, "R", "v43", "00_freeze_and_manifest.R"),
      file.path(root, "R", "v43", "03_validate_stage0_2.R"),
      resolve(spec$inputs$charls_core),
      file.path(root, "derived_sensitive", "v43", "charls_stage1_ledger_v43.rds"),
      file.path(root, "results", "v43", "charls_e0_scale_v43.csv"),
      file.path(root, "derived_sensitive", "v43", "nhanes_stage1_ledger_v43.rds"),
      resolve(spec$inputs$nhanes_ready),
      file.path(root, "results", "v43", "nhanes_e0_scale_v43.csv"),
      file.path(root, "results", "v43", "nhanes_function_routing_audit_v43.csv"),
      file.path(root, "output", "qa", "v43_NHANES_FUNCTION_PROXY_EVIDENCE_20260716.md"),
      resolve(spec$software$lockfile),
      file.path(root, "work_v43", "stage3_stable_input_inventory_v43.csv"),
      file.path(root, "results", "v43", "stage3_authorization_validation_v43.csv"),
      file.path(root, "results", "v43", "stage0_2_validated_source_inventory_v43.csv")
    ),
    stringsAsFactors = FALSE
  )
}

validate_final_authorization_registry <- function(root) {
  registry_path <- file.path(root, "work_v43", "stage3_authorization_hashes_v43.csv")
  if (!file.exists(registry_path) || file.info(registry_path)$size <= 0) {
    stop("Final Stage 3 authorization registry is unavailable.", call. = FALSE)
  }
  registry <- utils::read.csv(registry_path, stringsAsFactors = FALSE, check.names = FALSE)
  required_columns <- c("asset", "path", "exists", "bytes", "sha256", "frozen_at")
  if (!all(required_columns %in% names(registry)) ||
      !nrow(registry) ||
      anyDuplicated(registry$asset) ||
      anyDuplicated(registry$path)) {
    stop("Final Stage 3 authorization registry fails its schema/uniqueness contract.", call. = FALSE)
  }
  expected <- expected_authorization_assets(root)
  expected_lookup <- setNames(
    normalizePath(expected$path, mustWork = FALSE), expected$asset
  )
  observed_lookup <- setNames(
    normalizePath(as.character(registry$path), mustWork = FALSE),
    as.character(registry$asset)
  )
  asset_contract_ok <- nrow(registry) == nrow(expected) &&
    setequal(as.character(registry$asset), expected$asset) &&
    identical(
      unname(observed_lookup[expected$asset]),
      unname(expected_lookup[expected$asset])
    )
  if (!asset_contract_ok) {
    stop("Final Stage 3 authorization registry does not match the exact 25-file asset/path contract.", call. = FALSE)
  }
  current_exists <- file.exists(registry$path) & !dir.exists(registry$path)
  current_bytes <- ifelse(current_exists, as.numeric(file.info(registry$path)$size), NA_real_)
  current_hash <- vapply(registry$path, sha256_file, character(1))
  recorded_exists <- toupper(trimws(as.character(registry$exists))) %in%
    c("TRUE", "T", "1", "YES", "Y", "PASS")
  frozen_at_ok <- length(unique(as.character(registry$frozen_at))) == 1L &&
    all(!is.na(registry$frozen_at) & nzchar(as.character(registry$frozen_at)))
  pass <- recorded_exists & current_exists &
    current_bytes == suppressWarnings(as.numeric(registry$bytes)) &
    !is.na(current_hash) &
    grepl("^[0-9a-fA-F]{64}$", as.character(registry$sha256)) &
    tolower(current_hash) == tolower(registry$sha256)
  if (!all(pass) || !frozen_at_ok) {
    stop(
      "One or more final-authorization assets changed before Stage 3 output finalization: ",
      paste(registry$asset[!pass], collapse = "; "),
      if (!frozen_at_ok) "; frozen_at contract failed" else "",
      call. = FALSE
    )
  }
  invisible(registry)
}

authorization_audit_passed <- function(path, cohort) {
  if (!file.exists(path) || file.info(path)$size <= 0) return(FALSE)
  dat <- tryCatch(
    utils::read.csv(path, stringsAsFactors = FALSE, check.names = FALSE),
    error = function(e) NULL
  )
  expected_checks <- c(
    "required_authorization_assets",
    "gate_state_allows_outcome_execution",
    "independent_stage0_2_validation",
    "stage3_no_model_preflight_pass",
    "private_manifest_rows_current",
    "stable_input_inventory_rows_current",
    "validator_source_inventory_rows_current",
    "final_authorization_audit_pass",
    "final_pre_model_hash_registry",
    "stage3_packages_locked_and_loaded_versions_match"
  )
  expected_file <- paste0("stage3_", tolower(cohort), "_authorization_audit_v43.csv")
  !is.null(dat) &&
    identical(basename(path), expected_file) &&
    all(c("check", "status", "observed", "expected", "run_timestamp") %in% names(dat)) &&
    nrow(dat) == length(expected_checks) &&
    !anyDuplicated(dat$check) &&
    setequal(as.character(dat$check), expected_checks) &&
    all(toupper(as.character(dat$status)) == "PASS") &&
    length(unique(as.character(dat$run_timestamp))) == 1L &&
    all(!is.na(dat$run_timestamp) & nzchar(as.character(dat$run_timestamp)))
}

cohort_completion_manifest_path <- function(root, cohort) {
  file.path(
    root, "results", "v43",
    paste0("stage3_", tolower(cohort), "_completion_manifest_v43.csv")
  )
}

required_cohort_completion_paths <- function(root, cohort) {
  cohort_lower <- tolower(cohort)
  table_stems <- c(
    "spline_knot_registry",
    "sample_event_audit",
    "model_diagnostics",
    "mi_diagnostics",
    "mi_chain_convergence",
    "mi_trace",
    "time_varying_effects",
    "primary_association_registry"
  )
  c(
    file.path(
      root, "results", "v43",
      paste0("stage3_", cohort_lower, "_", table_stems, "_v43.csv")
    ),
    file.path(
      root, "derived_sensitive", "v43",
      paste0(cohort_lower, "_stage3_analysis_ledger_v43.rds")
    ),
    file.path(
      root, "logs", "v43",
      paste0("stage3_", cohort_lower, "_primary_association_v43.log")
    ),
    file.path(
      root, "output", "qa", "v43",
      paste0("STAGE3_", toupper(cohort), "_PRIMARY_ASSOCIATION_QA_v43.md")
    )
  )
}

validate_cohort_completion <- function(root, cohort, registry_sha256) {
  path <- cohort_completion_manifest_path(root, cohort)
  if (!file.exists(path) || file.info(path)$size <= 0) {
    stop("Missing ", cohort, " Stage 3 completion manifest.", call. = FALSE)
  }
  dat <- utils::read.csv(path, stringsAsFactors = FALSE, check.names = FALSE)
  required_columns <- c(
    "cohort", "status", "run_id", "authorization_registry_sha256",
    "artifact", "path", "bytes", "sha256", "completed_at"
  )
  if (!all(required_columns %in% names(dat)) || !nrow(dat) ||
      anyDuplicated(dat$artifact) || anyDuplicated(dat$path)) {
    stop(cohort, " completion manifest fails schema/uniqueness checks.", call. = FALSE)
  }
  scalar_ok <- function(x) {
    values <- unique(as.character(x))
    length(values) == 1L && !is.na(values) && nzchar(values)
  }
  cohort_ok <- all(toupper(as.character(dat$cohort)) == toupper(cohort))
  status_ok <- all(toupper(as.character(dat$status)) == "COMPLETE")
  run_ok <- scalar_ok(dat$run_id)
  time_ok <- scalar_ok(dat$completed_at)
  registry_values <- unique(tolower(as.character(dat$authorization_registry_sha256)))
  registry_ok <- length(registry_values) == 1L &&
    grepl("^[0-9a-f]{64}$", registry_values) &&
    identical(registry_values, tolower(registry_sha256))

  root_prefix <- paste0(normalizePath(root, mustWork = TRUE), .Platform$file.sep)
  normalized_paths <- normalizePath(as.character(dat$path), mustWork = FALSE)
  inside_root <- startsWith(normalized_paths, root_prefix)
  current_exists <- file.exists(normalized_paths) & !dir.exists(normalized_paths)
  current_bytes <- ifelse(
    current_exists, as.numeric(file.info(normalized_paths)$size), NA_real_
  )
  current_hash <- vapply(normalized_paths, sha256_file, character(1))
  byte_match <- current_exists & is.finite(current_bytes) &
    current_bytes == suppressWarnings(as.numeric(dat$bytes))
  hash_match <- current_exists & !is.na(current_hash) &
    grepl("^[0-9a-fA-F]{64}$", as.character(dat$sha256)) &
    tolower(current_hash) == tolower(as.character(dat$sha256))
  required_paths <- normalizePath(
    required_cohort_completion_paths(root, cohort),
    mustWork = FALSE
  )
  required_present <- all(required_paths %in% normalized_paths)
  self_absent <- !normalizePath(path, mustWork = FALSE) %in% normalized_paths

  if (!all(c(
    cohort_ok, status_ok, run_ok, time_ok, registry_ok, all(inside_root),
    all(byte_match), all(hash_match), required_present, self_absent
  ))) {
    stop(
      cohort, " completion manifest is stale or incomplete: ",
      "cohort=", cohort_ok,
      "; status=", status_ok,
      "; run=", run_ok,
      "; registry=", registry_ok,
      "; outside_root=", sum(!inside_root),
      "; byte_mismatches=", sum(!byte_match),
      "; hash_mismatches=", sum(!hash_match),
      "; required_paths=", required_present,
      "; self_absent=", self_absent,
      call. = FALSE
    )
  }
  invisible(dat)
}

make_staging_root <- function(root) {
  run_id <- paste0(
    "finalize_",
    format(Sys.time(), tz = "Asia/Shanghai", format = "%Y%m%dT%H%M%S"),
    "_", Sys.getpid()
  )
  path <- file.path(root, "derived_sensitive", "v43", ".stage3_staging", run_id)
  dir.create(path, recursive = TRUE, showWarnings = FALSE)
  if (!dir.exists(path)) stop("Could not create finalizer staging root.", call. = FALSE)
  path
}

cleanup_staging <- function(path) {
  if (!is.null(path) && nzchar(path) && dir.exists(path)) {
    unlink(path, recursive = TRUE, force = TRUE)
  }
  invisible(TRUE)
}

promote_staging <- function(staging_root, root) {
  files <- list.files(staging_root, recursive = TRUE, full.names = TRUE)
  files <- files[!dir.exists(files)]
  if (!length(files)) stop("Finalizer staging produced no files.", call. = FALSE)
  prefix <- paste0(normalizePath(staging_root, mustWork = TRUE), .Platform$file.sep)
  files <- normalizePath(files, mustWork = TRUE)
  relative <- substring(files, nchar(prefix) + 1L)
  destination <- file.path(root, relative)
  if (any(file.exists(destination))) {
    stop(
      "Refusing to overwrite an existing finalized Stage 3 output: ",
      paste(destination[file.exists(destination)], collapse = "; "),
      call. = FALSE
    )
  }
  promoted <- character()
  on.exit({
    if (length(promoted) && length(promoted) < length(destination)) {
      unlink(promoted[file.exists(promoted)], force = TRUE)
    }
  }, add = TRUE)
  for (i in seq_along(files)) {
    dir.create(dirname(destination[[i]]), recursive = TRUE, showWarnings = FALSE)
    if (!file.rename(files[[i]], destination[[i]])) {
      stop("Atomic finalizer promotion failed for ", relative[[i]], call. = FALSE)
    }
    promoted <- c(promoted, destination[[i]])
  }
  cleanup_staging(staging_root)
  invisible(destination)
}

main <- function() {
  root <- project_root()
  required_packages <- c("digest", "dplyr", "readr", "yaml")
  missing_packages <- required_packages[
    !vapply(required_packages, requireNamespace, logical(1), quietly = TRUE)
  ]
  if (length(missing_packages)) {
    stop("Finalizer packages unavailable: ", paste(missing_packages, collapse = ", "), call. = FALSE)
  }
  validate_final_authorization_registry(root)
  authorization_registry_path <- file.path(
    root, "work_v43", "stage3_authorization_hashes_v43.csv"
  )
  authorization_registry_sha256 <- sha256_file(authorization_registry_path)

  authorization_audits <- c(
    CHARLS = file.path(root, "results", "v43", "stage3_charls_authorization_audit_v43.csv"),
    NHANES = file.path(root, "results", "v43", "stage3_nhanes_authorization_audit_v43.csv")
  )
  audit_pass <- vapply(
    names(authorization_audits),
    function(cohort) authorization_audit_passed(authorization_audits[[cohort]], cohort),
    logical(1)
  )
  if (!all(audit_pass)) {
    stop(
      "Both cohort authorization audits must be PASS before finalization: ",
      paste(names(audit_pass), audit_pass, sep = "=", collapse = "; "),
      call. = FALSE
    )
  }

  completion_manifests <- lapply(
    names(authorization_audits),
    function(cohort) {
      validate_cohort_completion(
        root, cohort, authorization_registry_sha256
      )
    }
  )
  names(completion_manifests) <- names(authorization_audits)

  execution_failures <- c(
    file.path(root, "results", "v43", "stage3_charls_execution_failure_v43.csv"),
    file.path(root, "logs", "v43", "stage3_charls_execution_failure_v43.log"),
    file.path(
      root, "results", "v43",
      "stage3_charls_mi_convergence_failure_checkpoints_v43.csv"
    ),
    file.path(root, "results", "v43", "stage3_nhanes_execution_failure_v43.csv"),
    file.path(root, "logs", "v43", "stage3_nhanes_execution_failure_v43.log"),
    file.path(
      root, "results", "v43",
      "stage3_nhanes_mi_convergence_failure_checkpoints_v43.csv"
    )
  )
  if (any(file.exists(execution_failures))) {
    stop("An execution-failure marker exists; shared Stage 3 outputs cannot be finalized.", call. = FALSE)
  }

  table_contract <- data.frame(
    stem = c(
      "spline_knot_registry",
      "sample_event_audit",
      "model_diagnostics",
      "mi_diagnostics",
      "mi_chain_convergence",
      "time_varying_effects",
      "primary_association_registry"
    ),
    shared = c(
      "stage3_spline_knot_registry_v43.csv",
      "stage3_sample_event_audit_v43.csv",
      "stage3_model_diagnostics_v43.csv",
      "stage3_mi_diagnostics_v43.csv",
      "stage3_mi_chain_convergence_v43.csv",
      "stage3_time_varying_effects_v43.csv",
      "stage3_primary_association_registry_v43.csv"
    ),
    stringsAsFactors = FALSE
  )

  staging_root <- make_staging_root(root)
  tryCatch(
    {
      source_rows <- list()
      output_rows <- list()
      time_varying_by_cohort <- list()
      for (i in seq_len(nrow(table_contract))) {
        stem <- table_contract$stem[[i]]
        charls_path <- file.path(
          root, "results", "v43", paste0("stage3_charls_", stem, "_v43.csv")
        )
        nhanes_path <- file.path(
          root, "results", "v43", paste0("stage3_nhanes_", stem, "_v43.csv")
        )
        charls_expected <- completion_expectation(
          completion_manifests$CHARLS, charls_path
        )
        nhanes_expected <- completion_expectation(
          completion_manifests$NHANES, nhanes_path
        )
        charls <- read_cohort_csv(
          charls_path, "CHARLS", stem,
          charls_expected$bytes, charls_expected$sha256
        )
        nhanes <- read_cohort_csv(
          nhanes_path, "NHANES", stem,
          nhanes_expected$bytes, nhanes_expected$sha256
        )
        if (stem == "time_varying_effects") {
          validate_time_varying_contract(charls, nhanes)
          time_varying_by_cohort <- list(
            CHARLS = charls,
            NHANES = nhanes
          )
        }
        if (stem == "primary_association_registry") {
          validate_primary_registry_gate_semantics(charls, nhanes)
          if (!identical(sort(names(time_varying_by_cohort)),
                         c("CHARLS", "NHANES"))) {
            stop(
              "The finalizer reached primary registries before validating ",
              "both cohort time-varying tables.",
              call. = FALSE
            )
          }
          validate_time_varying_references(
            charls,
            nhanes,
            time_varying_by_cohort$CHARLS,
            time_varying_by_cohort$NHANES
          )
        }
        combined <- deterministic_sort(dplyr::bind_rows(charls, nhanes))
        if (stem == "primary_association_registry" &&
            anyDuplicated(as.character(combined$analysis_id))) {
          stop("Combined Stage 3 registry contains duplicate analysis_id values.", call. = FALSE)
        }
        staged_path <- file.path(
          staging_root, "results", "v43", table_contract$shared[[i]]
        )
        dir.create(dirname(staged_path), recursive = TRUE, showWarnings = FALSE)
        readr::write_csv(combined, staged_path)
        source_rows[[length(source_rows) + 1L]] <- data.frame(
          table = stem,
          cohort = c("CHARLS", "NHANES"),
          path = c(charls_path, nhanes_path),
          rows = c(nrow(charls), nrow(nhanes)),
          sha256 = c(charls_expected$sha256, nhanes_expected$sha256),
          stringsAsFactors = FALSE
        )
        output_rows[[length(output_rows) + 1L]] <- data.frame(
          table = stem,
          path = file.path(root, "results", "v43", table_contract$shared[[i]]),
          rows = nrow(combined),
          sha256 = sha256_file(staged_path),
          stringsAsFactors = FALSE
        )
      }

      source_manifest <- dplyr::bind_rows(source_rows)
      output_manifest <- dplyr::bind_rows(output_rows)
      finalization_manifest <- dplyr::bind_rows(
        source_manifest |>
          dplyr::transmute(record_type = "cohort_source", table, cohort, path, rows, sha256),
        output_manifest |>
          dplyr::transmute(record_type = "shared_output", table, cohort = "BOTH", path, rows, sha256)
      )
      completion_manifest_rows <- dplyr::bind_rows(lapply(
        names(completion_manifests),
        function(cohort) {
          path <- cohort_completion_manifest_path(root, cohort)
          data.frame(
            record_type = "cohort_completion_manifest",
            table = "completion_manifest",
            cohort = cohort,
            path = path,
            rows = nrow(completion_manifests[[cohort]]),
            sha256 = sha256_file(path),
            stringsAsFactors = FALSE
          )
        }
      ))
      finalization_manifest <- dplyr::bind_rows(
        finalization_manifest, completion_manifest_rows
      )
      manifest_path <- file.path(
        staging_root, "results", "v43", "stage3_output_finalization_manifest_v43.csv"
      )
      readr::write_csv(finalization_manifest, manifest_path)

      log_path <- file.path(
        staging_root, "logs", "v43", "stage3_output_finalization_v43.log"
      )
      dir.create(dirname(log_path), recursive = TRUE, showWarnings = FALSE)
      writeLines(
        c(
          paste0("Stage 3 aggregate finalization completed: ",
                 format(Sys.time(), tz = "Asia/Shanghai", usetz = TRUE)),
          "Cohort-specific source tables: 14",
          paste0("Shared aggregate tables: ", nrow(table_contract)),
          "Row-level records parsed or deserialized: 0",
          "Outcome models fitted: 0",
          "Overwrite policy: existing shared outputs are never replaced"
        ),
        log_path,
        useBytes = TRUE
      )

      qa_path <- file.path(
        staging_root, "output", "qa", "v43", "STAGE3_OUTPUT_FINALIZATION_QA_v43.md"
      )
      dir.create(dirname(qa_path), recursive = TRUE, showWarnings = FALSE)
      writeLines(
        c(
          "# Stage 3 output finalization QA",
          "",
          paste0("Generated: ", format(Sys.time(), tz = "Asia/Shanghai", usetz = TRUE)),
          "",
          "- Both cohort authorization audits were PASS.",
          "- Both cohort completion manifests were bound to the current final-authorization registry and every listed artifact was rehashed.",
          "- No cohort execution-failure or MI-convergence failure-checkpoint marker existed.",
          "- Seven shared aggregate tables were rebuilt from two cohort-specific sources.",
          "- Combined analysis identifiers were globally unique.",
          "- The final authorization registry, including this finalizer script, was rehashed before merging.",
          "- Row-level records parsed or deserialized: 0.",
          "- Outcome models fitted: 0."
        ),
        qa_path,
        useBytes = TRUE
      )

      promote_staging(staging_root, root)
      staging_root <- NULL
      message("Stage 3 cohort outputs were deterministically finalized.")
    },
    error = function(e) {
      cleanup_staging(staging_root)
      stop("Stage 3 output finalization failed; no shared output was promoted. ",
           conditionMessage(e), call. = FALSE)
    }
  )
}

if (sys.nframe() == 0L) {
  main()
}
