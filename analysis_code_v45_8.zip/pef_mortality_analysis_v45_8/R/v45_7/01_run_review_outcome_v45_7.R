#!/usr/bin/env Rscript

# Restricted execution for the V45.7 NHANES GLI A2 sensitivity.
# Coefficients remain in derived_sensitive until the separate validator passes.

options(stringsAsFactors = FALSE, warn = 1)

v457_root <- function() {
  args <- commandArgs(trailingOnly = FALSE)
  file_arg <- grep("^--file=", args, value = TRUE)
  if (!length(file_arg)) return(normalizePath(getwd(), mustWork = TRUE))
  script <- sub("^--file=", "", file_arg[[1L]])
  normalizePath(file.path(dirname(script), "..", ".."), mustWork = TRUE)
}

root <- v457_root()
source(file.path(root, "R", "v45", "01_nhanes_common_utilities_v45.R"))
source(file.path(root, "R", "v45", "02_gli_functions_v45.R"))
source(file.path(root, "R", "v45", "11_nhanes_outcome_utilities_v45.R"))
v45_require_packages(root)
options(
  survey.lonely.psu = "adjust",
  survey.adjust.domain.lonely = TRUE,
  survey.replicates.mse = TRUE,
  survey.multicore = FALSE
)

args <- commandArgs(trailingOnly = TRUE)
arg_value <- function(prefix, default = NULL) {
  hit <- grep(paste0("^", prefix, "="), args, value = TRUE)
  if (!length(hit)) return(default)
  sub(paste0("^", prefix, "="), "", tail(hit, 1L))
}
module_requested <- arg_value("--module", "all")
allowed_modules <- c("standard", "paired-prefix", "paired-full", "all")
if (!module_requested %in% allowed_modules) {
  stop(
    "Unknown --module. Expected: ",
    paste(allowed_modules, collapse = ", "), call. = FALSE
  )
}
workers <- suppressWarnings(as.integer(arg_value("--workers", "4")))
if (!is.finite(workers) || workers < 1L || workers > 8L) {
  stop("--workers must be an integer from 1 to 8.", call. = FALSE)
}
workers <- min(workers, max(1L, parallel::detectCores() - 1L))

read_tsv <- function(path) {
  utils::read.delim(
    path, stringsAsFactors = FALSE, check.names = FALSE,
    na.strings = c("", "NA")
  )
}

expected <- list(
  v456_sha256 =
    "c3db3a67ef179e87a5a81a0dfdb90ed55aafc509a9d5bf039b234fce695b1dd5",
  mig_sha256 =
    "41bcc3e5fbfd8f19501682e93354856ffc06adf6e426937327e07138d17733d3",
  rw_sha256 =
    "2d795d61aabcce42603b1cfa7b254239a716980821ad1865347a8a8327c9f152",
  m = 50L,
  n = 6540L,
  deaths = 885L,
  design_df = 49L
)

public_root <- file.path(root, "results", "v45_7", "review_addendum")
restricted_root <- file.path(
  root, "derived_sensitive", "v45_7", "review_addendum"
)
log_root <- file.path(root, "logs", "v45_7", "review_addendum")
dir.create(public_root, recursive = TRUE, showWarnings = FALSE)
dir.create(restricted_root, recursive = TRUE, showWarnings = FALSE)
dir.create(log_root, recursive = TRUE, showWarnings = FALSE)

preflight_path <- file.path(
  public_root, "v45_7_structural_preflight.tsv"
)
preflight_manifest_path <- file.path(
  public_root, "v45_7_preflight_input_manifest.tsv"
)
if (!file.exists(preflight_path) || !file.exists(preflight_manifest_path)) {
  stop("V45.7 structural preflight outputs are absent.", call. = FALSE)
}
preflight <- read_tsv(preflight_path)
if (nrow(preflight) < 1L || any(preflight$status != "PASS")) {
  stop("V45.7 structural preflight is not all PASS.", call. = FALSE)
}
preflight_manifest <- read_tsv(preflight_manifest_path)
manifest_current <- vapply(
  file.path(root, preflight_manifest$path_alias),
  v45_sha256_file, character(1)
)
if (any(is.na(manifest_current)) ||
    !identical(
      unname(manifest_current), as.character(preflight_manifest$sha256)
    )) {
  stop("One or more preflight-frozen inputs changed.", call. = FALSE)
}

v456_path <- file.path(
  root, "output", "submission_package_v45_6_FINAL_2026-07-29.zip"
)
rw_path <- file.path(
  root, "derived_sensitive", "v45",
  "v45_rao_wu_replicate_contract.rds"
)
mig_pointer_path <- file.path(
  root, "results", "v45", "production_mi", "MI_G_m50_current.tsv"
)
mig_pointer <- read_tsv(mig_pointer_path)
mig_path <- file.path(root, mig_pointer$mids_path_alias[[1L]])
if (
  !identical(v45_sha256_file(v456_path), expected$v456_sha256) ||
  !identical(v45_sha256_file(rw_path), expected$rw_sha256) ||
  !identical(v45_sha256_file(mig_path), expected$mig_sha256) ||
  nrow(mig_pointer) != 1L ||
  mig_pointer$requested_m[[1L]] != expected$m ||
  !identical(
    mig_pointer$status[[1L]], "INDEPENDENT_VALIDATION_PASS"
  )
) {
  stop("A frozen V45.7 execution input failed identity checks.",
       call. = FALSE)
}

current_path <- file.path(
  public_root, "v45_7_restricted_current.tsv"
)
run_id_arg <- arg_value("--run-id", NULL)
if (!is.null(run_id_arg) && !grepl(
  "^v45_7_gli_a2_m50_[0-9]{8}T[0-9]{6}_pid[0-9]+$",
  run_id_arg
)) {
  stop("Unsafe or invalid --run-id.", call. = FALSE)
}
if (!is.null(run_id_arg)) {
  run_id <- run_id_arg
} else if (file.exists(current_path)) {
  current <- read_tsv(current_path)
  if (nrow(current) != 1L ||
      !grepl("^v45_7_gli_a2_m50_", current$run_id[[1L]])) {
    stop("The V45.7 current-run pointer is invalid.", call. = FALSE)
  }
  run_id <- current$run_id[[1L]]
} else {
  run_id <- paste0(
    "v45_7_gli_a2_m50_",
    format(Sys.time(), "%Y%m%dT%H%M%S"), "_pid", Sys.getpid()
  )
}

run_dir <- file.path(restricted_root, run_id)
state_dir <- file.path(public_root, run_id)
dir.create(run_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(state_dir, recursive = TRUE, showWarnings = FALSE)
state_path <- file.path(state_dir, "module_state.tsv")
log_path <- file.path(log_root, paste0(run_id, ".log"))

state <- if (file.exists(state_path)) {
  read_tsv(state_path)
} else {
  data.frame(
    module = c("standard", "paired-prefix", "paired-full"),
    status = "NOT_RUN",
    output_path_alias = NA_character_,
    output_sha256 = NA_character_,
    completed_at = NA_character_,
    stringsAsFactors = FALSE
  )
}
if (!identical(
  state$module, c("standard", "paired-prefix", "paired-full")
)) {
  stop("V45.7 restricted module-state schema drifted.", call. = FALSE)
}

log_lines <- if (file.exists(log_path)) {
  readLines(log_path, warn = FALSE)
} else {
  c(
    paste0("run_id: ", run_id),
    "coefficient_visibility: restricted",
    "participant_level_output: forbidden",
    paste0("workers: ", workers)
  )
}
append_log <- function(text) {
  line <- paste0(
    format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z"), " ", text
  )
  log_lines <<- c(log_lines, line)
  v45_atomic_write_lines(log_lines, log_path)
  message(text)
}

module_alias <- function(module) {
  file.path(
    "derived_sensitive", "v45_7", "review_addendum", run_id,
    paste0(gsub("-", "_", module, fixed = TRUE), "_restricted.rds")
  )
}
module_path <- function(module) file.path(root, module_alias(module))

publish_module <- function(module, object) {
  path <- module_path(module)
  if (file.exists(path)) {
    stop("Refusing to overwrite restricted output: ", path, call. = FALSE)
  }
  v45_atomic_save_rds(object, path)
  row <- match(module, state$module)
  state$status[[row]] <<- "RESTRICTED_COMPLETE"
  state$output_path_alias[[row]] <<- module_alias(module)
  state$output_sha256[[row]] <<- v45_sha256_file(path)
  state$completed_at[[row]] <<- format(
    Sys.time(), "%Y-%m-%dT%H:%M:%S%z"
  )
  v45_atomic_write_tsv(state, state_path)
  pointer <- data.frame(
    run_id = run_id,
    state_path_alias = substring(state_path, nchar(root) + 2L),
    state_sha256 = v45_sha256_file(state_path),
    coefficient_visibility = "RESTRICTED",
    independent_validation_status = "NOT_RUN",
    stringsAsFactors = FALSE
  )
  v45_atomic_write_tsv(pointer, current_path)
  append_log(paste0(
    module, " completed; restricted SHA-256=",
    state$output_sha256[[row]]
  ))
  invisible(path)
}

read_module <- function(module) {
  row <- match(module, state$module)
  if (
    is.na(row) ||
    !identical(state$status[[row]], "RESTRICTED_COMPLETE") ||
    is.na(state$output_path_alias[[row]]) ||
    is.na(state$output_sha256[[row]])
  ) {
    stop(module, " prerequisite is not complete.", call. = FALSE)
  }
  path <- file.path(root, state$output_path_alias[[row]])
  if (!file.exists(path) ||
      !identical(v45_sha256_file(path), state$output_sha256[[row]])) {
    stop(module, " restricted output hash no longer verifies.",
         call. = FALSE)
  }
  readRDS(path)
}

parallel_map <- function(indices, fun, label) {
  append_log(paste0(
    label, " started for ", length(indices),
    " imputations with ", workers, " worker(s)."
  ))
  wrapper <- function(i) {
    tryCatch(
      list(ok = TRUE, value = fun(i), error = ""),
      error = function(e) list(
        ok = FALSE, value = NULL, error = conditionMessage(e)
      )
    )
  }
  result <- if (workers == 1L) {
    lapply(indices, wrapper)
  } else {
    parallel::mclapply(
      indices, wrapper, mc.cores = workers,
      mc.preschedule = FALSE, mc.set.seed = FALSE
    )
  }
  failed <- !vapply(result, `[[`, logical(1), "ok")
  if (any(failed)) {
    stop(
      label, " failed for imputation(s) ",
      paste(indices[failed], collapse = ", "), ": ",
      paste(
        vapply(result[failed], `[[`, character(1), "error"),
        collapse = " | "
      ),
      call. = FALSE
    )
  }
  append_log(paste0(label, " finished for all imputations."))
  lapply(result, `[[`, "value")
}

input_hashes <- list(
  v45_6_archive = expected$v456_sha256,
  mi_g_m50 = expected$mig_sha256,
  rao_wu_contract = expected$rw_sha256,
  preflight = v45_sha256_file(preflight_path),
  preflight_manifest = v45_sha256_file(preflight_manifest_path),
  addendum = v45_sha256_file(file.path(
    root, "protocol",
    "pef_mortality_analysis_plan_v45_7_review_addendum.md"
  )),
  execution_script = v45_sha256_file(file.path(
    root, "R", "v45_7", "01_run_review_outcome_v45_7.R"
  ))
)

mig <- readRDS(mig_path)
if (!isTRUE(as.numeric(mig$m) == expected$m)) {
  stop("MI-G is not the frozen m=50 object.", call. = FALSE)
}
ledger <- v45_read_nhanes_ledger(root)
v43 <- v45_load_v43_nhanes_functions(root)
rw <- readRDS(rw_path)
design_data <- v45_outcome_design_data(ledger, rw)

formulas <- list(
  A1_separate = v45_outcome_formula("E0", "A1"),
  A1_conditional = v45_outcome_formula(
    c("E0", "L_FEV1", "L_RATIO"), "A1"
  ),
  A2_separate = v45_outcome_formula("E0", "A2"),
  A2_conditional = v45_outcome_formula(
    c("E0", "L_FEV1", "L_RATIO"), "A2"
  )
)

run_standard <- function() {
  if (state$status[state$module == "standard"] != "NOT_RUN") {
    append_log("standard already complete; skipped.")
    return(invisible(NULL))
  }
  results <- parallel_map(seq_len(expected$m), function(i) {
    completed <- v45_prepare_mig_completed(
      mice::complete(mig, action = i), ledger, v43
    )
    merged <- v45_merge_completed_design(design_data, completed)
    domain <- merged$analysis_domain
    design <- v45_make_taylor_design(merged)
    rows <- list()
    diagnostics <- list()
    for (model_id in names(formulas)) {
      fit <- v45_fit_taylor_cox_prebuilt(
        merged, design, domain, formulas[[model_id]],
        paste0("v45_7_", model_id, "_imp", i)
      )
      if (!"E0" %in% names(fit$coefficients)) {
        stop(model_id, " lacks E0.", call. = FALSE)
      }
      rows[[model_id]] <- data.frame(
        model_id = model_id,
        imputation = i,
        estimate = unname(fit$coefficients[["E0"]]),
        within_variance = unname(fit$variance["E0", "E0"]),
        design_df = fit$diagnostics$design_df[[1L]],
        stringsAsFactors = FALSE
      )
      fit$diagnostics$model_id <- model_id
      fit$diagnostics$imputation <- i
      diagnostics[[model_id]] <- fit$diagnostics
    }
    list(
      estimates = dplyr::bind_rows(rows),
      diagnostics = dplyr::bind_rows(diagnostics)
    )
  }, "V45.7 Taylor models")
  object <- list(
    schema_version = "v45_7_review_standard_restricted",
    run_id = run_id,
    created_at_utc = format(
      Sys.time(), tz = "UTC", format = "%Y-%m-%dT%H:%M:%SZ"
    ),
    input_hashes = input_hashes,
    coefficient_visibility = "RESTRICTED",
    participant_level_data_saved = FALSE,
    fit_objects_saved = FALSE,
    per_imputation = dplyr::bind_rows(
      lapply(results, `[[`, "estimates")
    ),
    diagnostics = dplyr::bind_rows(
      lapply(results, `[[`, "diagnostics")
    )
  )
  publish_module("standard", object)
}

domain_weights <- function(completed) {
  merged <- v45_merge_completed_design(design_data, completed)
  rows <- which(merged$analysis_domain)
  cluster_index <- as.integer(rw$full_design_cluster_index[rows])
  base_weight <- as.numeric(rw$full_design_pweights[rows])
  if (
    length(rows) != expected$n ||
    sum(as.integer(merged$death[rows]) == 1L) != expected$deaths ||
    any(cluster_index < 1L | cluster_index > 94L) ||
    any(!is.finite(base_weight) | base_weight <= 0)
  ) {
    stop("The MI-G Rao-Wu analysis domain drifted.", call. = FALSE)
  }
  list(
    data = merged[rows, , drop = FALSE],
    cluster_index = cluster_index,
    base_weight = base_weight
  )
}

paired_one_imputation <- function(
    imputation, replicate_indices, prefix_object = NULL) {
  completed <- v45_prepare_mig_completed(
    mice::complete(mig, action = imputation), ledger, v43
  )
  domain <- domain_weights(completed)
  point_models <- c(
    A2_separate = v45_weighted_cox_coefficients(
      domain$data, domain$base_weight, formulas$A2_separate, "E0",
      paste0("v45_7_A2_separate_point_imp", imputation)
    )[[1L]],
    A2_conditional = v45_weighted_cox_coefficients(
      domain$data, domain$base_weight, formulas$A2_conditional, "E0",
      paste0("v45_7_A2_conditional_point_imp", imputation)
    )[[1L]],
    A1_conditional = v45_weighted_cox_coefficients(
      domain$data, domain$base_weight, formulas$A1_conditional, "E0",
      paste0("v45_7_A1_conditional_point_imp", imputation)
    )[[1L]]
  )
  point <- c(
    point_models,
    A2_conditional_minus_A2_separate =
      point_models[["A2_conditional"]] -
        point_models[["A2_separate"]],
    A2_conditional_minus_A1_conditional =
      point_models[["A2_conditional"]] -
        point_models[["A1_conditional"]]
  )
  new_replicates <- matrix(
    NA_real_, nrow = length(replicate_indices), ncol = length(point),
    dimnames = list(paste0("rep", replicate_indices), names(point))
  )
  errors <- character()
  for (j in seq_along(replicate_indices)) {
    r <- replicate_indices[[j]]
    weight <- domain$base_weight *
      rw$modules[["RW-GLI"]]$matrix[domain$cluster_index, r]
    value <- tryCatch({
      estimates <- c(
        A2_separate = v45_weighted_cox_coefficients(
          domain$data, weight, formulas$A2_separate, "E0",
          paste0("v45_7_A2_separate_imp", imputation, "_rep", r)
        )[[1L]],
        A2_conditional = v45_weighted_cox_coefficients(
          domain$data, weight, formulas$A2_conditional, "E0",
          paste0("v45_7_A2_conditional_imp", imputation, "_rep", r)
        )[[1L]],
        A1_conditional = v45_weighted_cox_coefficients(
          domain$data, weight, formulas$A1_conditional, "E0",
          paste0("v45_7_A1_conditional_imp", imputation, "_rep", r)
        )[[1L]]
      )
      c(
        estimates,
        A2_conditional_minus_A2_separate =
          estimates[["A2_conditional"]] -
            estimates[["A2_separate"]],
        A2_conditional_minus_A1_conditional =
          estimates[["A2_conditional"]] -
            estimates[["A1_conditional"]]
      )
    }, error = function(e) {
      errors <<- c(errors, conditionMessage(e))
      rep(NA_real_, length(point))
    })
    new_replicates[j, ] <- value
  }

  if (is.null(prefix_object)) {
    all_replicates <- new_replicates
  } else {
    if (
      !identical(prefix_object$imputation, as.integer(imputation)) ||
      !identical(
        rownames(prefix_object$replicates), paste0("rep", 1:250)
      ) ||
      !identical(colnames(prefix_object$replicates), names(point))
    ) {
      stop("Paired prefix object does not match its imputation.",
           call. = FALSE)
    }
    all_replicates <- rbind(prefix_object$replicates, new_replicates)
  }

  replicate_count <- nrow(all_replicates)
  contrast_names <- c(
    "A2_conditional_minus_A2_separate",
    "A2_conditional_minus_A1_conditional"
  )
  variance <- lapply(contrast_names, function(contrast) {
    result <- v45_replicate_variance(
      all_replicates[, contrast], point[[contrast]], replicate_count
    )
    data.frame(
      contrast = contrast,
      estimate = point[[contrast]],
      within_variance = result$variance,
      valid_fraction = result$valid_fraction,
      valid_n = result$valid_n,
      stringsAsFactors = FALSE
    )
  })
  list(
    imputation = as.integer(imputation),
    point = point,
    replicates = all_replicates,
    contrast_variance = dplyr::bind_rows(variance),
    error_count = length(errors),
    unique_error_count = length(unique(errors))
  )
}

run_paired_prefix <- function() {
  if (state$status[state$module == "paired-prefix"] != "NOT_RUN") {
    append_log("paired-prefix already complete; skipped.")
    return(invisible(NULL))
  }
  results <- parallel_map(seq_len(expected$m), function(i) {
    paired_one_imputation(i, seq_len(250L))
  }, "V45.7 paired first-250 Rao-Wu replicates")
  minimum_valid <- min(vapply(results, function(x) {
    min(x$contrast_variance$valid_fraction)
  }, numeric(1)))
  object <- list(
    schema_version = "v45_7_review_paired_prefix_restricted",
    run_id = run_id,
    created_at_utc = format(
      Sys.time(), tz = "UTC", format = "%Y-%m-%dT%H:%M:%SZ"
    ),
    input_hashes = input_hashes,
    coefficient_visibility = "RESTRICTED",
    participant_level_data_saved = FALSE,
    fit_objects_saved = FALSE,
    replicate_indices = seq_len(250L),
    results = results,
    minimum_valid_replicate_fraction = minimum_valid,
    prefix_gate = if (minimum_valid >= 0.90) "PASS" else "STOP"
  )
  publish_module("paired-prefix", object)
  if (minimum_valid < 0.90) {
    stop(
      "First-250 valid replicate fraction is below 0.90; ",
      "full execution is blocked.", call. = FALSE
    )
  }
}

run_paired_full <- function() {
  if (state$status[state$module == "paired-full"] != "NOT_RUN") {
    append_log("paired-full already complete; skipped.")
    return(invisible(NULL))
  }
  prefix <- read_module("paired-prefix")
  if (
    !identical(prefix$prefix_gate, "PASS") ||
    !identical(prefix$replicate_indices, seq_len(250L))
  ) {
    stop("Paired prefix did not authorize columns 251-500.",
         call. = FALSE)
  }
  results <- parallel_map(seq_len(expected$m), function(i) {
    paired_one_imputation(
      i, 251:500, prefix_object = prefix$results[[i]]
    )
  }, "V45.7 paired Rao-Wu columns 251-500")
  minimum_valid <- min(vapply(results, function(x) {
    min(x$contrast_variance$valid_fraction)
  }, numeric(1)))
  object <- list(
    schema_version = "v45_7_review_paired_full_restricted",
    run_id = run_id,
    created_at_utc = format(
      Sys.time(), tz = "UTC", format = "%Y-%m-%dT%H:%M:%SZ"
    ),
    input_hashes = input_hashes,
    coefficient_visibility = "RESTRICTED",
    participant_level_data_saved = FALSE,
    fit_objects_saved = FALSE,
    replicate_indices = seq_len(500L),
    prefix_sha256 = state$output_sha256[
      state$module == "paired-prefix"
    ],
    results = results,
    minimum_valid_replicate_fraction = minimum_valid
  )
  publish_module("paired-full", object)
}

requested <- if (module_requested == "all") {
  c("standard", "paired-prefix", "paired-full")
} else {
  module_requested
}
for (module in requested) {
  switch(
    module,
    standard = run_standard(),
    `paired-prefix` = run_paired_prefix(),
    `paired-full` = run_paired_full()
  )
}

append_log(paste0(
  "Requested module sequence finished: ", paste(requested, collapse = ", "),
  ". Coefficients remain restricted."
))
