#!/usr/bin/env Rscript

# Independent aggregate validator and release gate for the V45.7 NHANES GLI
# A2 sensitivity. No participant-level or completed-imputation data are read
# from the restricted execution objects.

options(stringsAsFactors = FALSE, warn = 1)

v457_root <- function() {
  args <- commandArgs(trailingOnly = FALSE)
  file_arg <- grep("^--file=", args, value = TRUE)
  if (!length(file_arg)) return(normalizePath(getwd(), mustWork = TRUE))
  script <- sub("^--file=", "", file_arg[[1L]])
  normalizePath(file.path(dirname(script), "..", ".."), mustWork = TRUE)
}

root <- v457_root()
source(file.path(root, "R", "v45", "01_nhanes_common_utilities_v45.R"))
v45_require_packages(root)
options(
  survey.lonely.psu = "adjust",
  survey.adjust.domain.lonely = TRUE,
  survey.replicates.mse = TRUE,
  survey.multicore = FALSE
)

read_tsv <- function(path) {
  utils::read.delim(
    path, stringsAsFactors = FALSE, check.names = FALSE,
    na.strings = c("", "NA")
  )
}

expected <- list(
  v456_sha256 =
    "c3db3a67ef179e87a5a81a0dfdb90ed55aafc509a9d5bf039b234fce695b1dd5",
  mig_sha256 =
    "41bcc3e5fbfd8f19501682e93354856ffc06adf6e426937327e07138d17733d3",
  rw_sha256 =
    "2d795d61aabcce42603b1cfa7b254239a716980821ad1865347a8a8327c9f152",
  m = 50L,
  n = 6540L,
  deaths = 885L,
  design_df = 49L,
  valid_fraction_min = 0.90,
  mce_fraction_max = 0.10
)

public_root <- file.path(root, "results", "v45_7", "review_addendum")
current_path <- file.path(public_root, "v45_7_restricted_current.tsv")
current <- read_tsv(current_path)
if (
  nrow(current) != 1L ||
  !identical(current$coefficient_visibility[[1L]], "RESTRICTED") ||
  !identical(
    v45_sha256_file(file.path(root, current$state_path_alias[[1L]])),
    current$state_sha256[[1L]]
  )
) {
  stop("The V45.7 current restricted-run pointer is invalid.",
       call. = FALSE)
}
run_id <- current$run_id[[1L]]
state_path <- file.path(root, current$state_path_alias[[1L]])
state <- read_tsv(state_path)
expected_modules <- c("standard", "paired-prefix", "paired-full")
if (
  !identical(state$module, expected_modules) ||
  any(state$status != "RESTRICTED_COMPLETE")
) {
  stop("All three V45.7 restricted modules are required.", call. = FALSE)
}

module_paths <- file.path(root, state$output_path_alias)
module_hashes <- vapply(module_paths, v45_sha256_file, character(1))
if (!identical(unname(module_hashes), as.character(state$output_sha256))) {
  stop("A restricted module hash failed verification.", call. = FALSE)
}
objects <- setNames(lapply(module_paths, readRDS), state$module)
standard <- objects[["standard"]]
prefix <- objects[["paired-prefix"]]
full <- objects[["paired-full"]]

checks <- list()
add_check <- function(check, pass, observed, expected_value) {
  checks[[length(checks) + 1L]] <<- data.frame(
    check = check,
    status = if (isTRUE(pass)) "PASS" else "FAIL",
    observed = as.character(observed),
    expected = as.character(expected_value),
    stringsAsFactors = FALSE
  )
}

add_check(
  "restricted_module_hashes",
  all(!is.na(module_hashes)),
  paste(state$output_sha256, collapse = ";"),
  "three exact-hash restricted modules"
)
schema_ok <- identical(
  standard$schema_version, "v45_7_review_standard_restricted"
) && identical(
  prefix$schema_version, "v45_7_review_paired_prefix_restricted"
) && identical(
  full$schema_version, "v45_7_review_paired_full_restricted"
)
add_check(
  "restricted_schemas",
  schema_ok,
  paste(
    standard$schema_version, prefix$schema_version,
    full$schema_version, sep = ";"
  ),
  "three V45.7 restricted schemas"
)
flags_ok <- all(vapply(objects, function(x) {
  identical(x$coefficient_visibility, "RESTRICTED") &&
    identical(x$participant_level_data_saved, FALSE) &&
    identical(x$fit_objects_saved, FALSE)
}, logical(1)))
add_check(
  "no_participant_level_or_fit_objects",
  flags_ok, flags_ok, TRUE
)

same_inputs <- identical(standard$input_hashes, prefix$input_hashes) &&
  identical(prefix$input_hashes, full$input_hashes)
current_input_hashes <- list(
  v45_6_archive = v45_sha256_file(file.path(
    root, "output", "submission_package_v45_6_FINAL_2026-07-29.zip"
  )),
  mi_g_m50 = v45_sha256_file(file.path(
    root,
    read_tsv(file.path(
      root, "results", "v45", "production_mi", "MI_G_m50_current.tsv"
    ))$mids_path_alias[[1L]]
  )),
  rao_wu_contract = v45_sha256_file(file.path(
    root, "derived_sensitive", "v45",
    "v45_rao_wu_replicate_contract.rds"
  )),
  preflight = v45_sha256_file(file.path(
    public_root, "v45_7_structural_preflight.tsv"
  )),
  preflight_manifest = v45_sha256_file(file.path(
    public_root, "v45_7_preflight_input_manifest.tsv"
  )),
  addendum = v45_sha256_file(file.path(
    root, "protocol",
    "pef_mortality_analysis_plan_v45_7_review_addendum.md"
  )),
  execution_script = v45_sha256_file(file.path(
    root, "R", "v45_7", "01_run_review_outcome_v45_7.R"
  ))
)
inputs_current <- same_inputs &&
  identical(standard$input_hashes, current_input_hashes) &&
  identical(current_input_hashes$v45_6_archive, expected$v456_sha256) &&
  identical(current_input_hashes$mi_g_m50, expected$mig_sha256) &&
  identical(current_input_hashes$rao_wu_contract, expected$rw_sha256)
add_check(
  "frozen_input_hashes_current",
  inputs_current,
  if (inputs_current) "all exact" else "one or more mismatch",
  "all exact"
)

standard_models <- c(
  "A1_separate", "A1_conditional", "A2_separate", "A2_conditional"
)
per <- standard$per_imputation
standard_complete <- nrow(per) == expected$m * length(standard_models) &&
  identical(sort(unique(per$model_id)), sort(standard_models)) &&
  all(vapply(standard_models, function(model) {
    rows <- per[per$model_id == model, , drop = FALSE]
    nrow(rows) == expected$m &&
      identical(as.integer(rows$imputation), seq_len(expected$m)) &&
      all(is.finite(rows$estimate)) &&
      all(is.finite(rows$within_variance) & rows$within_variance > 0) &&
      all(rows$design_df == expected$design_df)
  }, logical(1)))
add_check(
  "standard_model_completeness",
  standard_complete,
  paste(nrow(per), "rows and", length(unique(per$model_id)), "models"),
  "200 rows and 4 models"
)

diagnostics <- standard$diagnostics
diagnostics_ok <- nrow(diagnostics) == 200L &&
  all(diagnostics$n == expected$n) &&
  all(diagnostics$events == expected$deaths) &&
  all(diagnostics$design_strata == 45L) &&
  all(diagnostics$design_psu == 94L) &&
  all(diagnostics$design_df == expected$design_df) &&
  all(diagnostics$matrix_columns == diagnostics$matrix_rank)
add_check(
  "standard_model_diagnostics",
  diagnostics_ok,
  paste(nrow(diagnostics), "full-rank diagnostics"),
  "200 full-rank diagnostics with frozen anchors"
)

independent_pool <- function(estimates, variances, design_df = 49) {
  pooled <- mice::pool.scalar(
    as.numeric(estimates), as.numeric(variances),
    n = as.numeric(design_df) + 1, k = 1, rule = "rubin1987"
  )
  critical <- if (is.finite(pooled$df)) {
    stats::qt(0.975, df = pooled$df)
  } else {
    stats::qnorm(0.975)
  }
  se <- sqrt(pooled$t)
  statistic <- pooled$qbar / se
  p_value <- if (is.finite(pooled$df)) {
    2 * stats::pt(abs(statistic), df = pooled$df, lower.tail = FALSE)
  } else {
    2 * stats::pnorm(abs(statistic), lower.tail = FALSE)
  }
  data.frame(
    m = pooled$m,
    estimate = pooled$qbar,
    standard_error = se,
    ci_low = pooled$qbar - critical * se,
    ci_high = pooled$qbar + critical * se,
    p_value = p_value,
    within_variance = pooled$ubar,
    between_variance = pooled$b,
    total_variance = pooled$t,
    df = pooled$df,
    complete_data_design_df = design_df,
    fraction_missing_information = pooled$fmi,
    relative_efficiency = 1 / (1 + pooled$fmi / pooled$m),
    monte_carlo_error = sqrt(pooled$b / pooled$m),
    monte_carlo_error_fraction = sqrt(pooled$b / pooled$m) / se,
    stringsAsFactors = FALSE
  )
}

standard_pooled <- dplyr::bind_rows(lapply(standard_models, function(model) {
  rows <- per[per$model_id == model, , drop = FALSE]
  cbind(
    data.frame(model_id = model, stringsAsFactors = FALSE),
    independent_pool(
      rows$estimate, rows$within_variance, expected$design_df
    )
  )
}))

v45_release <- read_tsv(file.path(
  root, "results", "v45", "outcome_execution",
  "v45_nhanes_released_results.tsv"
))
anchors <- data.frame(
  model_id = c("A1_separate", "A1_conditional"),
  analysis_id = c("v45_g1", "v45_g6a"),
  stringsAsFactors = FALSE
)
anchor_differences <- lapply(seq_len(nrow(anchors)), function(i) {
  old <- v45_release[
    v45_release$analysis_id == anchors$analysis_id[[i]] &
      v45_release$term == "E0",
    , drop = FALSE
  ]
  new <- standard_pooled[
    standard_pooled$model_id == anchors$model_id[[i]],
    , drop = FALSE
  ]
  fields <- c(
    "estimate", "standard_error", "ci_low", "ci_high", "p_value",
    "within_variance", "between_variance", "total_variance", "df",
    "fraction_missing_information", "monte_carlo_error_fraction"
  )
  max(abs(
    as.numeric(unlist(new[1L, fields], use.names = FALSE)) -
      as.numeric(unlist(old[1L, fields], use.names = FALSE))
  ))
})
maximum_anchor_difference <- max(unlist(anchor_differences))
add_check(
  "a1_frozen_release_reproduction",
  is.finite(maximum_anchor_difference) &&
    maximum_anchor_difference <= 1e-10,
  paste0("maximum absolute difference=", maximum_anchor_difference),
  "<=1e-10"
)

prefix_full_identity <- vapply(seq_len(expected$m), function(i) {
  p <- prefix$results[[i]]
  f <- full$results[[i]]
  identical(p$imputation, f$imputation) &&
    identical(p$point, f$point) &&
    identical(
      p$replicates,
      f$replicates[seq_len(250L), , drop = FALSE]
    )
}, logical(1))
add_check(
  "paired_prefix_full_identity",
  all(prefix_full_identity),
  paste(sum(prefix_full_identity), "/50 exact"),
  "50/50 exact"
)

contrast_names <- c(
  "A2_conditional_minus_A2_separate",
  "A2_conditional_minus_A1_conditional"
)
paired_rows <- list()
variance_differences <- numeric()
valid_fractions <- numeric()
for (i in seq_len(expected$m)) {
  result <- full$results[[i]]
  for (contrast in contrast_names) {
    values <- as.numeric(result$replicates[, contrast])
    valid <- is.finite(values)
    variance <- if (sum(valid) >= 2L) {
      as.numeric(survey::svrVar(
        values,
        scale = 1 / 499,
        rscales = rep(1, 500L),
        na.action = "na.omit",
        mse = TRUE,
        coef = as.numeric(result$point[[contrast]])
      ))
    } else {
      NA_real_
    }
    stored <- result$contrast_variance[
      result$contrast_variance$contrast == contrast,
      , drop = FALSE
    ]
    variance_differences <- c(
      variance_differences,
      abs(variance - stored$within_variance[[1L]])
    )
    valid_fractions <- c(valid_fractions, mean(valid))
    paired_rows[[length(paired_rows) + 1L]] <- data.frame(
      contrast = contrast,
      imputation = i,
      estimate = result$point[[contrast]],
      within_variance = variance,
      design_df = expected$design_df,
      valid_replicate_fraction = mean(valid),
      valid_replicate_n = sum(valid),
      stringsAsFactors = FALSE
    )
  }
}
paired_per <- dplyr::bind_rows(paired_rows)
maximum_variance_difference <- max(variance_differences)
add_check(
  "independent_replicate_variance",
  all(is.finite(variance_differences)) &&
    maximum_variance_difference <= 1e-12 &&
    min(valid_fractions) >= expected$valid_fraction_min,
  paste0(
    "max difference=", maximum_variance_difference,
    "; minimum valid fraction=", min(valid_fractions)
  ),
  "difference <=1e-12 and valid fraction >=0.90"
)

paired_pooled <- dplyr::bind_rows(lapply(contrast_names, function(contrast) {
  rows <- paired_per[paired_per$contrast == contrast, , drop = FALSE]
  cbind(
    data.frame(contrast = contrast, stringsAsFactors = FALSE),
    independent_pool(
      rows$estimate, rows$within_variance, expected$design_df
    ),
    minimum_valid_replicate_fraction =
      min(rows$valid_replicate_fraction)
  )
}))

mce_values <- c(
  standard_pooled$monte_carlo_error_fraction,
  paired_pooled$monte_carlo_error_fraction
)
add_check(
  "m50_monte_carlo_error_gate",
  all(is.finite(mce_values)) &&
    max(mce_values) < expected$mce_fraction_max,
  paste0("maximum fraction=", max(mce_values)),
  "<0.10"
)
add_check(
  "paired_valid_replicate_gate",
  all(paired_pooled$minimum_valid_replicate_fraction >=
        expected$valid_fraction_min),
  paste0(
    "minimum fraction=",
    min(paired_pooled$minimum_valid_replicate_fraction)
  ),
  ">=0.90"
)

validation <- dplyr::bind_rows(checks)
validation_path <- file.path(
  public_root, "v45_7_independent_validation.tsv"
)
v45_atomic_write_tsv(validation, validation_path)
if (any(validation$status != "PASS")) {
  stop(
    "V45.7 independent validation failed: ",
    paste(validation$check[validation$status != "PASS"], collapse = ", "),
    call. = FALSE
  )
}

standard_release <- standard_pooled
standard_release$analysis_id <- paste0(
  "v45_7_", tolower(standard_release$model_id)
)
standard_release$analysis_type <- "reviewer_motivated_sensitivity"
standard_release$term <- "E0"
standard_release$effect_measure <- "hazard_ratio_per_1_SD_lower_PEF"
standard_release$hazard_ratio <- exp(standard_release$estimate)
standard_release$hazard_ratio_ci_low <- exp(standard_release$ci_low)
standard_release$hazard_ratio_ci_high <- exp(standard_release$ci_high)
standard_release$minimum_valid_replicate_fraction <- NA_real_

paired_release <- paired_pooled
paired_release$analysis_id <- paste0(
  "v45_7_", tolower(paired_release$contrast)
)
paired_release$model_id <- paired_release$contrast
paired_release$analysis_type <- "paired_review_sensitivity_contrast"
paired_release$term <- paired_release$contrast
paired_release$effect_measure <- "ratio_of_PEF_hazard_ratios"
paired_release$hazard_ratio <- exp(paired_release$estimate)
paired_release$hazard_ratio_ci_low <- exp(paired_release$ci_low)
paired_release$hazard_ratio_ci_high <- exp(paired_release$ci_high)

release_fields <- c(
  "analysis_id", "model_id", "analysis_type", "term", "effect_measure",
  "m", "estimate", "standard_error", "ci_low", "ci_high", "p_value",
  "hazard_ratio", "hazard_ratio_ci_low", "hazard_ratio_ci_high",
  "within_variance", "between_variance", "total_variance", "df",
  "complete_data_design_df", "fraction_missing_information",
  "relative_efficiency", "monte_carlo_error",
  "monte_carlo_error_fraction", "minimum_valid_replicate_fraction"
)
release <- dplyr::bind_rows(
  standard_release[release_fields],
  paired_release[release_fields]
)
release$gate_status <- "PASS"
release_path <- file.path(
  public_root, "v45_7_nhanes_gli_a2_sensitivity.tsv"
)
v45_atomic_write_tsv(release, release_path)

diagnostic_summary <- dplyr::bind_rows(lapply(
  standard_models, function(model) {
    rows <- diagnostics[diagnostics$model_id == model, , drop = FALSE]
    data.frame(
      model_id = model,
      imputations = nrow(rows),
      n_min = min(rows$n),
      n_max = max(rows$n),
      events_min = min(rows$events),
      events_max = max(rows$events),
      design_df_min = min(rows$design_df),
      design_df_max = max(rows$design_df),
      matrix_columns_min = min(rows$matrix_columns),
      matrix_columns_max = max(rows$matrix_columns),
      warning_count = sum(nzchar(rows$warnings)),
      stringsAsFactors = FALSE
    )
  }
))
diagnostic_path <- file.path(
  public_root, "v45_7_nhanes_gli_a2_model_diagnostics.tsv"
)
v45_atomic_write_tsv(diagnostic_summary, diagnostic_path)

qa_path <- file.path(
  root, "output", "qa", "v45_7",
  "NHANES_GLI_A2_SENSITIVITY_QA_v45_7.md"
)
format_effect <- function(row) {
  sprintf(
    "%.3f (95%% CI %.3f to %.3f); P=%s",
    row$hazard_ratio, row$hazard_ratio_ci_low,
    row$hazard_ratio_ci_high,
    format.pval(row$p_value, digits = 3, eps = 0.001)
  )
}
qa_lines <- c(
  "# V45.7 NHANES GLI A2 sensitivity: validated release",
  "",
  paste0("- Run ID: `", run_id, "`."),
  paste0("- Validation: all ", nrow(validation), " gates PASS."),
  paste0(
    "- Frozen V45.6 archive SHA-256: `", expected$v456_sha256, "`."
  ),
  "- Population: 6,540 participants and 885 deaths; MI-G, m=50.",
  "- Design: 45 strata, 94 PSUs, complete-data design df=49.",
  "- Paired contrasts: the frozen 500-column Rao-Wu matrix.",
  "",
  "## Aggregate results",
  ""
)
for (i in seq_len(nrow(release))) {
  qa_lines <- c(
    qa_lines,
    paste0(
      "- `", release$analysis_id[[i]], "`: ",
      format_effect(release[i, , drop = FALSE]), "."
    )
  )
}
qa_lines <- c(
  qa_lines, "",
  "## Interpretation boundary", "",
  paste(
    "This reviewer-motivated sensitivity does not change the original A1",
    "estimand. It evaluates whether the conditional PEF association is",
    "materially altered by the broader A2 health and functional-status",
    "adjustment. It is not evidence of causality, mechanism, or incremental",
    "prediction."
  )
)
v45_atomic_write_lines(qa_lines, qa_path)

manifest_paths <- c(
  validation = validation_path,
  released_results = release_path,
  model_diagnostics = diagnostic_path,
  qa_report = qa_path,
  standard_restricted = module_paths[state$module == "standard"],
  paired_prefix_restricted =
    module_paths[state$module == "paired-prefix"],
  paired_full_restricted = module_paths[state$module == "paired-full"],
  validator_script = file.path(
    root, "R", "v45_7", "02_validate_review_outcome_v45_7.R"
  )
)
manifest <- data.frame(
  object = names(manifest_paths),
  path_alias = substring(manifest_paths, nchar(root) + 2L),
  sha256 = vapply(manifest_paths, v45_sha256_file, character(1)),
  visibility = c(
    "public", "public", "public", "public",
    "restricted", "restricted", "restricted", "public_code"
  ),
  stringsAsFactors = FALSE
)
manifest_path <- file.path(
  public_root, "v45_7_release_output_manifest.tsv"
)
v45_atomic_write_tsv(manifest, manifest_path)

current$state_sha256[[1L]] <- v45_sha256_file(state_path)
current$independent_validation_status[[1L]] <- "PASS"
current$release_manifest_path_alias <-
  substring(manifest_path, nchar(root) + 2L)
current$release_manifest_sha256 <- v45_sha256_file(manifest_path)
v45_atomic_write_tsv(current, current_path)

message(
  "V45.7 independent validation PASS; aggregate A2 sensitivity released."
)
