#!/usr/bin/env Rscript

# Outcome-blind structural preflight for the V45.7 reviewer-motivated
# NHANES GLI A2 sensitivity. This script builds model matrices but never
# fits an outcome model, reads a coefficient, or writes participant-level data.

options(stringsAsFactors = FALSE, warn = 1)

v457_root <- function() {
  args <- commandArgs(trailingOnly = FALSE)
  file_arg <- grep("^--file=", args, value = TRUE)
  if (!length(file_arg)) return(normalizePath(getwd(), mustWork = TRUE))
  script <- sub("^--file=", "", file_arg[[1L]])
  normalizePath(file.path(dirname(script), "..", ".."), mustWork = TRUE)
}

root <- v457_root()
source(file.path(root, "R", "v45", "01_nhanes_common_utilities_v45.R"))
source(file.path(root, "R", "v45", "02_gli_functions_v45.R"))
source(file.path(root, "R", "v45", "11_nhanes_outcome_utilities_v45.R"))
runtime <- v45_require_packages(root)
options(
  survey.lonely.psu = "adjust",
  survey.adjust.domain.lonely = TRUE,
  survey.replicates.mse = TRUE,
  survey.multicore = FALSE
)

expected <- list(
  v456_sha256 =
    "c3db3a67ef179e87a5a81a0dfdb90ed55aafc509a9d5bf039b234fce695b1dd5",
  mig_sha256 =
    "41bcc3e5fbfd8f19501682e93354856ffc06adf6e426937327e07138d17733d3",
  rw_sha256 =
    "2d795d61aabcce42603b1cfa7b254239a716980821ad1865347a8a8327c9f152",
  n = 6540L,
  deaths = 885L,
  strata = 45L,
  psu = 94L,
  design_df = 49L,
  m = 50L,
  replicates = 500L
)

paths <- list(
  v456 = file.path(
    root, "output", "submission_package_v45_6_FINAL_2026-07-29.zip"
  ),
  mig_pointer = file.path(
    root, "results", "v45", "production_mi", "MI_G_m50_current.tsv"
  ),
  rw = file.path(
    root, "derived_sensitive", "v45",
    "v45_rao_wu_replicate_contract.rds"
  ),
  addendum = file.path(
    root, "protocol",
    "pef_mortality_analysis_plan_v45_7_review_addendum.md"
  ),
  script = file.path(
    root, "R", "v45_7", "00_preflight_review_addendum_v45_7.R"
  )
)

read_tsv <- function(path) {
  utils::read.delim(
    path, stringsAsFactors = FALSE, check.names = FALSE,
    na.strings = c("", "NA")
  )
}

checks <- list()
add_check <- function(check, pass, observed, expected_value) {
  checks[[length(checks) + 1L]] <<- data.frame(
    check = check,
    status = if (isTRUE(pass)) "PASS" else "FAIL",
    observed = as.character(observed),
    expected = as.character(expected_value),
    stringsAsFactors = FALSE
  )
}

add_check(
  "v45_6_archive_hash",
  identical(v45_sha256_file(paths$v456), expected$v456_sha256),
  v45_sha256_file(paths$v456), expected$v456_sha256
)
add_check(
  "rao_wu_contract_hash",
  identical(v45_sha256_file(paths$rw), expected$rw_sha256),
  v45_sha256_file(paths$rw), expected$rw_sha256
)
add_check(
  "review_addendum_present",
  file.exists(paths$addendum),
  file.exists(paths$addendum), TRUE
)

mig_pointer <- read_tsv(paths$mig_pointer)
pointer_ok <- nrow(mig_pointer) == 1L &&
  identical(mig_pointer$object_id[[1L]], "MI-G") &&
  mig_pointer$requested_m[[1L]] == expected$m &&
  identical(
    mig_pointer$status[[1L]], "INDEPENDENT_VALIDATION_PASS"
  ) &&
  identical(mig_pointer$mids_sha256[[1L]], expected$mig_sha256)
add_check(
  "mi_g_pointer",
  pointer_ok,
  paste(
    mig_pointer$object_id[[1L]], mig_pointer$requested_m[[1L]],
    mig_pointer$status[[1L]], mig_pointer$mids_sha256[[1L]],
    sep = "|"
  ),
  paste(
    "MI-G", expected$m, "INDEPENDENT_VALIDATION_PASS",
    expected$mig_sha256, sep = "|"
  )
)

mig_path <- file.path(root, mig_pointer$mids_path_alias[[1L]])
add_check(
  "mi_g_object_hash",
  identical(v45_sha256_file(mig_path), expected$mig_sha256),
  v45_sha256_file(mig_path), expected$mig_sha256
)

rw <- readRDS(paths$rw)
rw_module <- rw$modules[["RW-GLI"]]
rw_ok <- !is.null(rw_module) &&
  identical(dim(rw_module$matrix), c(expected$psu, expected$replicates)) &&
  length(rw$full_design_cluster_index) == 29353L &&
  length(rw$full_design_pweights) == 29353L &&
  all(is.finite(rw_module$matrix))
add_check(
  "rao_wu_gli_dimensions",
  rw_ok,
  if (is.null(rw_module)) {
    "RW-GLI absent"
  } else {
    paste(dim(rw_module$matrix), collapse = "x")
  },
  paste(expected$psu, expected$replicates, sep = "x")
)

mig <- readRDS(mig_path)
add_check(
  "mi_g_m",
  length(mig$m) == 1L && isTRUE(as.numeric(mig$m) == expected$m),
  mig$m, expected$m
)

ledger <- v45_read_nhanes_ledger(root)
v43 <- v45_load_v43_nhanes_functions(root)
design_data <- v45_outcome_design_data(ledger, rw)

formulas <- list(
  A1_separate = v45_outcome_formula("E0", "A1"),
  A1_conditional = v45_outcome_formula(
    c("E0", "L_FEV1", "L_RATIO"), "A1"
  ),
  A2_separate = v45_outcome_formula("E0", "A2"),
  A2_conditional = v45_outcome_formula(
    c("E0", "L_FEV1", "L_RATIO"), "A2"
  )
)
required_a2 <- c(
  "self_reported_emphysema_or_bronchitis",
  "ever_asthma",
  "nhanes_function_health_proxy_count"
)
add_check(
  "a2_is_strict_a1_extension",
  identical(
    setdiff(v45_outcome_a2_terms(), v45_outcome_a1_terms()),
    required_a2
  ),
  paste(
    setdiff(v45_outcome_a2_terms(), v45_outcome_a1_terms()),
    collapse = ";"
  ),
  paste(required_a2, collapse = ";")
)

matrix_rows <- list()
reference_ids <- NULL
all_structural_ok <- TRUE

for (i in seq_len(expected$m)) {
  completed <- v45_prepare_mig_completed(
    mice::complete(mig, action = i), ledger, v43
  )
  merged <- v45_merge_completed_design(design_data, completed)
  domain_index <- merged$analysis_domain
  domain <- merged[domain_index, , drop = FALSE]
  ids <- as.integer(domain$SEQN)
  if (is.null(reference_ids)) reference_ids <- ids

  membership_ok <- identical(ids, reference_ids)
  anchor_ok <- nrow(domain) == expected$n &&
    sum(as.integer(domain$death) == 1L) == expected$deaths &&
    length(unique(domain$design_strata)) == expected$strata &&
    length(unique(domain$design_psu)) == expected$psu
  a2_complete <- all(vapply(
    domain[required_a2], function(x) !anyNA(x), logical(1)
  ))
  design <- v45_make_taylor_design(merged)
  df_ok <- identical(
    as.integer(survey::degf(design[domain_index, ])),
    expected$design_df
  )

  for (model_id in names(formulas)) {
    matrix <- stats::model.matrix(
      stats::delete.response(stats::terms(formulas[[model_id]])),
      data = domain
    )
    finite <- all(is.finite(matrix))
    rank <- qr(matrix)$rank
    full_rank <- rank == ncol(matrix)
    row_ok <- membership_ok && anchor_ok && a2_complete &&
      df_ok && finite && full_rank
    all_structural_ok <- all_structural_ok && row_ok
    matrix_rows[[length(matrix_rows) + 1L]] <- data.frame(
      imputation = i,
      model_id = model_id,
      n = nrow(domain),
      deaths = sum(as.integer(domain$death) == 1L),
      design_strata = length(unique(domain$design_strata)),
      design_psu = length(unique(domain$design_psu)),
      design_df = survey::degf(design[domain_index, ]),
      matrix_columns = ncol(matrix),
      matrix_rank = rank,
      finite_matrix = finite,
      identical_membership = membership_ok,
      a2_fields_complete = a2_complete,
      status = if (row_ok) "PASS" else "FAIL",
      stringsAsFactors = FALSE
    )
  }
  rm(completed, merged, domain, design)
  if (i %% 10L == 0L) {
    message("Structural preflight completed imputation ", i, "/50.")
    invisible(gc(verbose = FALSE))
  }
}

matrix_diagnostics <- dplyr::bind_rows(matrix_rows)
add_check(
  "all_50_imputations_same_membership",
  all(matrix_diagnostics$identical_membership),
  sum(matrix_diagnostics$identical_membership), nrow(matrix_diagnostics)
)
add_check(
  "all_model_matrices_full_rank_and_finite",
  all_structural_ok && all(matrix_diagnostics$status == "PASS"),
  paste(
    sum(matrix_diagnostics$status == "PASS"), "/", nrow(matrix_diagnostics)
  ),
  paste(nrow(matrix_diagnostics), "/", nrow(matrix_diagnostics))
)
add_check(
  "sample_and_design_anchors",
  all(
    matrix_diagnostics$n == expected$n &
      matrix_diagnostics$deaths == expected$deaths &
      matrix_diagnostics$design_strata == expected$strata &
      matrix_diagnostics$design_psu == expected$psu &
      matrix_diagnostics$design_df == expected$design_df
  ),
  paste(
    expected$n, expected$deaths, expected$strata, expected$psu,
    expected$design_df, sep = "/"
  ),
  paste(
    expected$n, expected$deaths, expected$strata, expected$psu,
    expected$design_df, sep = "/"
  )
)
add_check(
  "coefficient_firewall",
  TRUE,
  "no model fit and no coefficient access in this script",
  "PASS"
)

validation <- dplyr::bind_rows(checks)
result_root <- file.path(root, "results", "v45_7", "review_addendum")
matrix_path <- file.path(
  result_root, "v45_7_model_matrix_diagnostics.tsv"
)
validation_path <- file.path(
  result_root, "v45_7_structural_preflight.tsv"
)
manifest_path <- file.path(
  result_root, "v45_7_preflight_input_manifest.tsv"
)

manifest_paths <- c(
  v45_6_frozen_archive = paths$v456,
  mi_g_m50_object = mig_path,
  rao_wu_contract = paths$rw,
  v45_7_review_addendum = paths$addendum,
  v45_7_preflight_script = paths$script,
  v45_common_utilities = file.path(
    root, "R", "v45", "01_nhanes_common_utilities_v45.R"
  ),
  v45_gli_functions = file.path(
    root, "R", "v45", "02_gli_functions_v45.R"
  ),
  v45_outcome_utilities = file.path(
    root, "R", "v45", "11_nhanes_outcome_utilities_v45.R"
  )
)
manifest <- data.frame(
  object = names(manifest_paths),
  path_alias = substring(manifest_paths, nchar(root) + 2L),
  sha256 = vapply(manifest_paths, v45_sha256_file, character(1)),
  stringsAsFactors = FALSE
)

v45_atomic_write_tsv(matrix_diagnostics, matrix_path)
v45_atomic_write_tsv(validation, validation_path)
v45_atomic_write_tsv(manifest, manifest_path)

if (any(validation$status != "PASS")) {
  stop(
    "V45.7 structural preflight failed: ",
    paste(validation$check[validation$status != "PASS"], collapse = ", "),
    call. = FALSE
  )
}

message(
  "V45.7 structural preflight PASS: 50 imputations, four full-rank ",
  "model matrices per imputation, no coefficient inspected."
)
