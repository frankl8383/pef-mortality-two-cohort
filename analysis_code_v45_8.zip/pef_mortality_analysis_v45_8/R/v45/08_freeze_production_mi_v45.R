# v45 Stage 3 freeze: authorize production m=50 MI-B/MI-G/MI-S creation.
#
# This script freezes code and the complete transitive v43 function closure
# used for MICE execution/convergence. It opens the authorized row-level
# ledger read-only to reconstruct and hash the three frozen inputs, but never
# persists or exports row-level data and never fits an outcome model.

options(stringsAsFactors = FALSE)

stage3_root <- function() {
  args <- commandArgs(trailingOnly = FALSE)
  file_arg <- grep("^--file=", args, value = TRUE)
  if (!length(file_arg)) return(normalizePath(getwd(), mustWork = TRUE))
  script <- sub("^--file=", "", file_arg[[1]])
  normalizePath(file.path(dirname(script), "..", ".."), mustWork = TRUE)
}

root <- stage3_root()
source(file.path(root, "R", "v45", "01_nhanes_common_utilities_v45.R"))
source(file.path(root, "R", "v45", "02_gli_functions_v45.R"))
source(file.path(root, "R", "v45", "legacy_gli_reference_pure_v45.R"))
source(file.path(root, "R", "v45", "production_mi_hashes_v45.R"))
v45_prepend_frozen_library(root)
stage3_packages <- c(
  "digest", "dplyr", "haven", "mice", "readr", "rspiro",
  "tibble", "tidyr", "yaml"
)
missing_stage3_packages <- stage3_packages[
  !vapply(stage3_packages, requireNamespace, logical(1), quietly = TRUE)
]
if (length(missing_stage3_packages) ||
    !identical(as.character(utils::packageVersion("mice")), "3.19.0") ||
    !identical(as.character(utils::packageVersion("rspiro")), "0.5")) {
  stop(
    "Stage 3 production-MI package runtime is incomplete or drifted: ",
    paste(missing_stage3_packages, collapse = ", "),
    call. = FALSE
  )
}
v45_verify_frozen_manifests(root)

output_paths <- c(
  code = file.path(root, "work_v45", "v45_production_mi_code_manifest.tsv"),
  functions = file.path(
    root, "work_v45", "v45_production_mi_function_manifest.tsv"
  ),
  roots = file.path(root, "work_v45", "v45_production_mi_freeze_roots.tsv"),
  input_contract = file.path(
    root, "derived_sensitive", "v45",
    "v45_production_mi_input_contract.rds"
  ),
  input_summary = file.path(
    root, "results", "v45", "v45_production_mi_input_contracts.tsv"
  ),
  validation = file.path(
    root, "results", "v45", "v45_production_mi_freeze_validation.tsv"
  )
)

function_body_sha <- function(fun) {
  digest::digest(
    paste(c(deparse(formals(fun)), deparse(body(fun))), collapse = "\n"),
    algo = "sha256", serialize = FALSE
  )
}

manifest_root <- function(dat, key, fields) {
  dat <- dat[order(dat[[key]]), fields, drop = FALSE]
  payload <- apply(dat, 1L, function(x) paste(x, collapse = "\u241f"))
  digest::digest(
    paste(payload, collapse = "\n"), algo = "sha256", serialize = FALSE
  )
}

same_manifest <- function(recorded, current, key, fields) {
  recorded <- recorded[order(recorded[[key]]), fields, drop = FALSE]
  current <- current[order(current[[key]]), fields, drop = FALSE]
  normalize <- function(dat) {
    lapply(dat, function(x) {
      out <- as.character(x)
      out[is.na(out) | !nzchar(out)] <- NA_character_
      out
    })
  }
  identical(normalize(recorded), normalize(current))
}

build_code_manifest <- function() {
  rel <- c(
    "work_v45/production_mi_spec_v45.yml",
    "work_v45/v45_analysis_registry.tsv",
    "work_v45/v45_estimand_registry.tsv",
    "work_v45/v45_production_mi_decision_log.md",
    "work_v45/v45_stage3_mi_amendment_log.md",
    "derived_sensitive/v45/v45_mi_object_definitions_v45.rds",
    "R/v45/01_nhanes_common_utilities_v45.R",
    "R/v45/02_gli_functions_v45.R",
    "R/v45/legacy_gli_reference_pure_v45.R",
    "R/v45/production_mi_hashes_v45.R",
    "R/v45/08_freeze_production_mi_v45.R",
    "R/v45/09_run_production_mi_v45.R",
    "R/v45/independent_mi_validation_helpers_v45.R",
    "R/v45/10_validate_production_mi_v45.R",
    paste0(
      "output/code_archive/PEF_mortality_v44_2_code_candidate/",
      "R/v43/05_nhanes_stage3_primary_mortality.R"
    ),
    "R/nhanes/07_nhanes_v0_5_gli_lln_prism_lock.R"
  )
  dplyr::bind_rows(lapply(rel, function(path) {
    full <- file.path(root, path)
    data.frame(
      asset_id = paste0("V45_STAGE3_MI::", path),
      path_private = normalizePath(full, mustWork = FALSE),
      path_alias = path,
      exists = file.exists(full) && !dir.exists(full),
      bytes = if (file.exists(full)) as.numeric(file.info(full)$size) else NA_real_,
      sha256 = v45_sha256_file(full),
      immutable = TRUE,
      authorized_purpose =
        "production multiple-imputation object creation without outcome fitting",
      stringsAsFactors = FALSE
    )
  }))
}

transitive_v43_functions <- function(v43, roots) {
  seen <- character()
  pending <- roots
  while (length(pending)) {
    name <- pending[[1]]
    pending <- pending[-1]
    if (name %in% seen) next
    if (!exists(name, envir = v43, inherits = FALSE) ||
        !is.function(get(name, envir = v43, inherits = FALSE))) {
      stop("Required v43 production-MI function is absent: ", name, call. = FALSE)
    }
    seen <- c(seen, name)
    globals <- codetools::findGlobals(
      get(name, envir = v43, inherits = FALSE),
      merge = FALSE
    )$functions
    local_functions <- globals[vapply(
      globals,
      function(candidate) {
        exists(candidate, envir = v43, inherits = FALSE) &&
          is.function(get(candidate, envir = v43, inherits = FALSE))
      },
      logical(1)
    )]
    pending <- unique(c(pending, setdiff(local_functions, seen)))
  }
  sort(seen)
}

transitive_v45_functions <- function(roots) {
  seen <- character()
  pending <- roots
  while (length(pending)) {
    name <- pending[[1]]
    pending <- pending[-1]
    if (name %in% seen) next
    if (!exists(name, envir = globalenv(), inherits = FALSE) ||
        !is.function(get(name, envir = globalenv(), inherits = FALSE))) {
      stop("Required v45 production-MI function is absent: ", name, call. = FALSE)
    }
    seen <- c(seen, name)
    globals <- codetools::findGlobals(
      get(name, envir = globalenv(), inherits = FALSE),
      merge = FALSE
    )$functions
    local_functions <- globals[
      grepl("^v45_", globals) &
        vapply(
          globals,
          function(candidate) {
            exists(candidate, envir = globalenv(), inherits = FALSE) &&
              is.function(get(candidate, envir = globalenv(), inherits = FALSE))
          },
          logical(1)
        )
    ]
    pending <- unique(c(pending, setdiff(local_functions, seen)))
  }
  sort(seen)
}

build_function_manifest <- function() {
  v43 <- v45_load_v43_nhanes_functions(root)
  v43_roots <- c(
    "run_mi_convergence_schedule",
    "mice_chain_convergence",
    "mice_chain_trace",
    "format_mice_convergence_failures",
    "validate_nhanes_passive_bmi_state"
  )
  v43_functions <- transitive_v43_functions(v43, v43_roots)
  v43_rows <- data.frame(
    asset_id = paste0("v43::", v43_functions),
    function_name = v43_functions,
    source = paste0(
      "output/code_archive/PEF_mortality_v44_2_code_candidate/",
      "R/v43/05_nhanes_stage3_primary_mortality.R"
    ),
    sha256 = vapply(
      v43_functions,
      function(name) {
        function_body_sha(get(name, envir = v43, inherits = FALSE))
      },
      character(1)
    ),
    hash_rule = "SHA-256 of formals plus deparsed function body",
    stringsAsFactors = FALSE
  )
  v45_roots <- c(
    "v45_make_mi_b", "v45_make_mi_g", "v45_make_mi_s",
    "v45_mi_signature_v43_nhanes", "v45_compute_gli",
    "v45_validate_gli_against_pure_reference",
    "v45_passive_bmi_audit", "v45_canonical_data_frame_contract",
    "v45_canonical_array_sha256",
    "v45_canonical_imputation_payload_sha256",
    "v45_canonical_object_sha256"
  )
  v45_functions <- transitive_v45_functions(v45_roots)
  source_for <- function(name) {
    if (name %in% c("v45_compute_gli")) {
      "R/v45/02_gli_functions_v45.R"
    } else if (grepl("^v45_legacy_|^v45_validate_gli_against_pure", name)) {
      "R/v45/legacy_gli_reference_pure_v45.R"
    } else if (grepl("^v45_canonical_", name)) {
      "R/v45/production_mi_hashes_v45.R"
    } else {
      "R/v45/01_nhanes_common_utilities_v45.R"
    }
  }
  v45_rows <- data.frame(
    asset_id = paste0("v45::", v45_functions),
    function_name = v45_functions,
    source = vapply(v45_functions, source_for, character(1)),
    sha256 = vapply(
      v45_functions,
      function(name) {
        function_body_sha(get(name, envir = globalenv(), inherits = FALSE))
      },
      character(1)
    ),
    hash_rule = "SHA-256 of formals plus deparsed function body",
    stringsAsFactors = FALSE
  )
  dplyr::bind_rows(v43_rows, v45_rows)
}

verify_stage2 <- function() {
  output <- system2(
    file.path(R.home("bin"), "Rscript"),
    c(
      "--vanilla",
      file.path(root, "R", "v45", "05_freeze_rao_wu_preflight_v45.R"),
      "--verify"
    ),
    stdout = TRUE,
    stderr = TRUE
  )
  status <- attr(output, "status")
  is.null(status) || status == 0L
}

verify_stage2_validated_outputs <- function() {
  manifest_path <- file.path(
    root, "results", "v45", "v45_rao_wu_output_manifest.tsv"
  )
  validation_path <- file.path(
    root, "results", "v45", "v45_rao_wu_independent_validation.tsv"
  )
  if (!file.exists(manifest_path) || !file.exists(validation_path)) {
    stop("Stage 2 validated-output manifest is absent.", call. = FALSE)
  }
  manifest <- utils::read.delim(
    manifest_path, stringsAsFactors = FALSE, check.names = FALSE
  )
  required_assets <- c(
    "code", "functions", "roots", "validation", "contracts",
    "structural", "interfaces", "contract", "log",
    "independent_validation", "qa_report"
  )
  manifest_ok <- !anyDuplicated(manifest$asset_id) &&
    setequal(manifest$asset_id, required_assets) &&
    all(vapply(seq_len(nrow(manifest)), function(i) {
      path <- file.path(root, manifest$path_alias[[i]])
      file.exists(path) &&
        !dir.exists(path) &&
        identical(
          as.numeric(file.info(path)$size),
          as.numeric(manifest$bytes[[i]])
        ) &&
        identical(
          tolower(v45_sha256_file(path)),
          tolower(manifest$sha256[[i]])
        )
    }, logical(1)))
  validation <- utils::read.delim(
    validation_path, stringsAsFactors = FALSE, check.names = FALSE
  )
  required_checks <- c(
    "stage0_1_and_stage2_freezes_verify",
    "execution_structural_checks_complete",
    "synthetic_interface_contract_complete",
    "restricted_contract_design_and_compression",
    "both_replicate_modules_rehash_and_balance",
    "aggregate_contract_table_matches_restricted_RDS",
    "static_no_true_outcome_or_exposure_reference",
    "no_result_or_row_level_public_leak"
  )
  validation_ok <- !anyDuplicated(validation$check) &&
    setequal(validation$check, required_checks) &&
    all(validation$status == "PASS")
  if (!manifest_ok || !validation_ok) {
    stop(
      "Stage 2 validated outputs no longer satisfy their frozen manifest.",
      call. = FALSE
    )
  }
  manifest_root(
    manifest, "asset_id",
    c("asset_id", "path_alias", "bytes", "sha256", "local_restricted")
  )
}

build_input_contract <- function() {
  definition_path <- file.path(
    root, "derived_sensitive", "v45", "v45_mi_object_definitions_v45.rds"
  )
  definitions <- readRDS(definition_path)
  production_spec <- yaml::read_yaml(
    file.path(root, "work_v45", "production_mi_spec_v45.yml")
  )
  ledger <- v45_read_nhanes_ledger(root)
  v43 <- v45_load_v43_nhanes_functions(root)
  objects <- list(
    `MI-B` = v45_make_mi_b(ledger, v43),
    `MI-G` = v45_make_mi_g(ledger, v43, seed = 450201L),
    `MI-S` = v45_make_mi_s(ledger, v43, seed = 450301L)
  )
  contracts <- list()
  summary_rows <- list()
  for (object_id in names(objects)) {
    object <- objects[[object_id]]
    definition_name <- gsub("-", "_", object_id, fixed = TRUE)
    definition <- definitions[[definition_name]]
    data_contract <- v45_canonical_data_frame_contract(object$data)
    column_contract_sha <- v45_canonical_data_frame_contract(
      data_contract$columns
    )$sha256
    specification <- object$specification
    missing_n <- vapply(object$data, function(x) sum(is.na(x)), integer(1))
    missing_contract <- data.frame(
      column_index = seq_along(missing_n),
      column_name = names(missing_n),
      missing_n = unname(missing_n),
      stringsAsFactors = FALSE
    )
    ids <- v45_as_num(as.character(object$data$SEQN))
    specification_sha <- v45_object_sha256(specification)
    canonical_specification_sha <-
      v45_canonical_object_sha256(specification)
    canonical_id_sha <- v45_canonical_array_sha256(as.integer(ids))
    registered <- production_spec$objects[[object_id]]
    checks <- c(
      denominator_n = nrow(object$data) == definition$denominator_n,
      columns = identical(names(object$data), definition$columns),
      specification = identical(specification, definition$specification),
      specification_sha = identical(
        specification_sha,
        v45_object_sha256(definition$specification)
      ),
      ordered_id = identical(
        v45_object_sha256(ids), definition$ordered_id_sha256
      ),
      registered_denominator =
        identical(as.integer(registered$denominator_n), nrow(object$data)),
      registered_seed =
        identical(as.integer(registered$seed), as.integer(specification$seed)),
      registered_canonical_data =
        identical(registered$canonical_data_sha256, data_contract$sha256),
      registered_canonical_specification = identical(
        registered$canonical_specification_sha256,
        canonical_specification_sha
      ),
      registered_canonical_ordered_id =
        identical(registered$canonical_ordered_id_sha256, canonical_id_sha)
    )
    if (!all(checks)) {
      stop(
        object_id, " input no longer matches its Stage 1 definition: ",
        paste(names(checks)[!checks], collapse = ", "),
        call. = FALSE
      )
    }
    event_n <- sum(v45_as_num(object$data$death) == 1L)
    response_n <- if ("R_A" %in% names(object$data)) {
      sum(as.character(object$data$R_A) == "1")
    } else {
      NA_integer_
    }
    contract <- list(
      object_id = object_id,
      denominator_n = nrow(object$data),
      event_anchor_n = event_n,
      response_anchor_n = response_n,
      column_contract = data_contract$columns,
      column_contract_sha256 = column_contract_sha,
      canonical_data_sha256 = data_contract$sha256,
      missing_contract = missing_contract,
      missing_contract_sha256 =
        v45_canonical_data_frame_contract(missing_contract)$sha256,
      ordered_id_sha256_canonical =
        canonical_id_sha,
      specification_sha256_canonical =
        canonical_specification_sha,
      method_sha256 =
        v45_canonical_named_character_sha256(specification$method),
      predictor_matrix_sha256 =
        v45_canonical_array_sha256(specification$predictor_matrix),
      where_sha256 = v45_canonical_array_sha256(specification$where),
      visit_sequence_sha256 =
        v45_canonical_vector_contract(specification$visit_sequence)$values_sha256,
      seed = as.integer(specification$seed),
      initial_m = as.integer(specification$initial_m),
      maximum_m = as.integer(specification$maximum_m),
      convergence_checkpoints =
        as.integer(specification$convergence_iteration_checkpoints),
      convergence_rhat_max = specification$convergence_rhat_max,
      trace_release_missing_n_min =
        as.integer(specification$trace_release_missing_n_min)
    )
    contracts[[object_id]] <- contract
    summary_rows[[object_id]] <- data.frame(
      object_id = object_id,
      denominator_n = contract$denominator_n,
      event_anchor_n = contract$event_anchor_n,
      response_anchor_n = contract$response_anchor_n,
      input_column_n = ncol(object$data),
      active_target_n = sum(nzchar(specification$method)),
      imputed_cell_n_per_chain = sum(
        missing_n[names(specification$method)[nzchar(specification$method)]]
      ),
      seed = contract$seed,
      canonical_data_sha256 = contract$canonical_data_sha256,
      column_contract_sha256 = contract$column_contract_sha256,
      missing_contract_sha256 = contract$missing_contract_sha256,
      ordered_id_sha256 = contract$ordered_id_sha256_canonical,
      specification_sha256 =
        contract$specification_sha256_canonical,
      specification_sha256_canonical =
        contract$specification_sha256_canonical,
      method_sha256 = contract$method_sha256,
      predictor_matrix_sha256 = contract$predictor_matrix_sha256,
      where_sha256 = contract$where_sha256,
      visit_sequence_sha256 = contract$visit_sequence_sha256,
      status = "PASS",
      stringsAsFactors = FALSE
    )
  }
  rm(ledger, objects)
  invisible(gc(verbose = FALSE))
  list(
    contract = list(
      contract_version = "v45_0_stage3",
      hash_rule = "canonical_UTF8_type_explicit_v1",
      R_version = as.character(getRversion()),
      RNGkind = c(
        kind = "Mersenne-Twister",
        normal_kind = "Inversion",
        sample_kind = "Rejection"
      ),
      definitions_file_sha256 = v45_sha256_file(definition_path),
      objects = contracts
    ),
    summary = dplyr::bind_rows(summary_rows)
  )
}

build_objects <- function() {
  if (!identical(as.character(getRversion()), "4.5.1") ||
      !identical(
        unname(RNGkind()),
        c("Mersenne-Twister", "Inversion", "Rejection")
      )) {
    stop("Stage 3 production-MI R version or RNGkind drifted.",
         call. = FALSE)
  }
  if (!verify_stage2()) {
    stop("Stage 2 freeze no longer verifies; production MI is blocked.",
         call. = FALSE)
  }
  code <- build_code_manifest()
  functions <- build_function_manifest()
  input <- build_input_contract()
  stage2_validated_output_root <- verify_stage2_validated_outputs()
  if (any(!code$exists) || any(!grepl("^[0-9a-f]{64}$", code$sha256))) {
    stop("Stage 3 production-MI code/specification assets are incomplete.",
         call. = FALSE)
  }
  required_functions <- c(
    "assert_nhanes_visit_sequence", "extend_mi_checked",
    "format_mice_convergence_failures", "mice_category_trace",
    "mice_chain_convergence", "mice_chain_trace",
    "new_stage3_mice_convergence_error", "one_line",
    "reconstruct_released_nhanes_bmi", "record_category_trace_iteration",
    "run_mi", "run_mi_checked", "run_mi_convergence_schedule",
    "stage3_basic_rhat", "stage3_classic_final_half_rhat",
    "stage3_improved_rhat", "stage3_rank_normalize",
    "stage3_split_chains", "stage3_summarize_trace",
    "validate_nhanes_passive_bmi_state"
  )
  required_assets <- paste0("v43::", sort(required_functions))
  required_v45_assets <- paste0(
    "v45::",
    c(
      "v45_make_mi_b", "v45_make_mi_g", "v45_make_mi_s",
      "v45_mi_signature_v43_nhanes", "v45_compute_gli",
      "v45_validate_gli_against_pure_reference",
      "v45_passive_bmi_audit", "v45_canonical_data_frame_contract",
      "v45_canonical_array_sha256",
      "v45_canonical_imputation_payload_sha256",
      "v45_canonical_object_sha256"
    )
  )
  if (!all(c(required_assets, required_v45_assets) %in% functions$asset_id) ||
      anyDuplicated(functions$asset_id) ||
      any(!grepl("^[0-9a-f]{64}$", functions$sha256))) {
    stop("Stage 3 v43 production-MI function closure is incomplete.",
         call. = FALSE)
  }
  stage01_roots <- utils::read.delim(
    file.path(root, "work_v45", "v45_freeze_roots.tsv"),
    stringsAsFactors = FALSE, check.names = FALSE
  )
  stage2_roots <- utils::read.delim(
    file.path(root, "work_v45", "v45_rao_wu_freeze_roots.tsv"),
    stringsAsFactors = FALSE, check.names = FALSE
  )
  roots <- data.frame(
    root_id = c(
      "stage3_production_mi_code_root",
      "stage3_production_mi_function_root",
      "stage3_production_mi_input_root",
      "stage0_1_input_root", "stage0_1_code_root",
      "stage0_1_runtime_root", "stage2_code_root",
      "stage2_survey_function_root", "stage2_validated_output_root"
    ),
    sha256 = c(
      manifest_root(
        code, "asset_id",
        c("asset_id", "path_alias", "bytes", "sha256", "immutable")
      ),
      manifest_root(
        functions, "asset_id",
        c("asset_id", "function_name", "source", "sha256")
      ),
      manifest_root(
        input$summary, "object_id",
        c(
          "object_id", "denominator_n", "event_anchor_n",
          "response_anchor_n", "input_column_n", "active_target_n",
          "imputed_cell_n_per_chain", "seed", "canonical_data_sha256",
          "column_contract_sha256", "missing_contract_sha256",
          "ordered_id_sha256", "specification_sha256", "method_sha256",
          "specification_sha256_canonical",
          "predictor_matrix_sha256", "where_sha256",
          "visit_sequence_sha256", "status"
        )
      ),
      stage01_roots$sha256[
        stage01_roots$root_id == "input_manifest_root"
      ],
      stage01_roots$sha256[
        stage01_roots$root_id == "code_manifest_root"
      ],
      stage01_roots$sha256[
        stage01_roots$root_id == "runtime_manifest_root"
      ],
      stage2_roots$sha256[stage2_roots$root_id == "stage2_code_root"],
      stage2_roots$sha256[
        stage2_roots$root_id == "stage2_survey_function_root"
      ],
      stage2_validated_output_root
    ),
    stringsAsFactors = FALSE
  )
  if (anyNA(roots$sha256) || any(!grepl("^[0-9a-f]{64}$", roots$sha256))) {
    stop("Stage 3 production-MI parent roots are incomplete.", call. = FALSE)
  }
  list(
    code = code, functions = functions, roots = roots,
    input_contract = input$contract, input_summary = input$summary
  )
}

verify_stage3 <- function(objects) {
  if (any(!file.exists(output_paths))) {
    stop("Stage 3 production-MI frozen manifests are absent.", call. = FALSE)
  }
  validation_sha <- v45_sha256_file(output_paths[["validation"]])
  if (length(validation_sha) != 1L || is.na(validation_sha) ||
      !grepl("^[0-9a-f]{64}$", validation_sha)) {
    stop("Stage 3 freeze-validation file cannot be hash-bound.",
         call. = FALSE)
  }
  objects$roots <- rbind(
    objects$roots,
    data.frame(
      root_id = "stage3_production_mi_freeze_validation_file",
      sha256 = validation_sha,
      stringsAsFactors = FALSE
    )
  )
  recorded_code <- utils::read.delim(
    output_paths[["code"]], stringsAsFactors = FALSE, check.names = FALSE
  )
  recorded_functions <- utils::read.delim(
    output_paths[["functions"]], stringsAsFactors = FALSE, check.names = FALSE
  )
  recorded_roots <- utils::read.delim(
    output_paths[["roots"]], stringsAsFactors = FALSE, check.names = FALSE
  )
  recorded_input_contract <- readRDS(output_paths[["input_contract"]])
  recorded_input_summary <- utils::read.delim(
    output_paths[["input_summary"]],
    stringsAsFactors = FALSE, check.names = FALSE
  )
  ok <- c(
    code = same_manifest(
      recorded_code, objects$code, "asset_id",
      c(
        "asset_id", "path_private", "path_alias", "exists", "bytes",
        "sha256", "immutable", "authorized_purpose"
      )
    ),
    functions = same_manifest(
      recorded_functions, objects$functions, "asset_id",
      c(
        "asset_id", "function_name", "source", "sha256", "hash_rule"
      )
    ),
    roots = same_manifest(
      recorded_roots, objects$roots, "root_id", c("root_id", "sha256")
    ),
    input_contract = identical(
      recorded_input_contract, objects$input_contract
    ),
    input_summary = same_manifest(
      recorded_input_summary, objects$input_summary, "object_id",
      names(objects$input_summary)
    )
  )
  if (!all(ok)) {
    stop(
      "Stage 3 production-MI frozen assets changed: ",
      paste(names(ok)[!ok], collapse = ", "),
      call. = FALSE
    )
  }
  invisible(TRUE)
}

mode <- if ("--verify" %in% commandArgs(trailingOnly = TRUE)) {
  "verify"
} else {
  "freeze"
}
objects <- build_objects()

if (identical(mode, "verify")) {
  verify_stage3(objects)
  message("v45 Stage 3 production-MI authorization verifies exactly.")
} else {
  if (any(file.exists(output_paths))) {
    stop("Stage 3 production-MI freeze outputs already exist; use --verify.",
         call. = FALSE)
  }
  gate_path <- file.path(root, "work_v45", "gate_state_v45.yml")
  gate <- yaml::read_yaml(gate_path)
  required_gate <- list(
    stage0 = gate$stage0_predecessor_and_source_freeze$status,
    stage1 = gate$stage1_mi_object_structural_preflight$status,
    stage1_independent = gate$stage1_independent_validation$status,
    stage2_freeze = gate$stage2_rao_wu_preflight_freeze$status,
    stage2_structural = gate$stage2_rao_wu_structural_preflight$status,
    stage2_independent =
      gate$stage2_rao_wu_independent_validation$status
  )
  required_gate_ok <- vapply(
    required_gate, identical, logical(1), y = "PASS"
  )
  if (!all(required_gate_ok) ||
      !identical(gate$outcome_execution_allowed, FALSE) ||
      !identical(
        gate$new_mortality_coefficient_inspection_allowed, FALSE
      ) ||
      !identical(gate$production_m50_objects_allowed, FALSE)) {
    stop("Gate state does not authorize the production-MI freeze.",
         call. = FALSE)
  }
  freeze_id <- paste0(
    "v45_stage3_mi_freeze_", format(Sys.time(), "%Y%m%dT%H%M%S"),
    "_pid", Sys.getpid()
  )
  frozen_at <- format(Sys.time(), "%Y-%m-%dT%H:%M:%SZ", tz = "UTC")
  validation <- data.frame(
    check = c(
      "stage0_2_freezes_current",
      "production_mi_code_and_specification_complete",
      "complete_v43_mice_function_closure_frozen",
      "canonical_MI_B_MI_G_MI_S_inputs_frozen",
      "RNGkind_and_runtime_exact",
      "production_m50_only_authorized_without_outcome_fitting"
    ),
    status = rep("PASS", 6L),
    detail = c(
      "all predecessor/input/code/runtime and Stage 2 roots verify",
      paste0("assets=", nrow(objects$code)),
      paste0("functions=", nrow(objects$functions)),
      paste0(
        "objects=", nrow(objects$input_summary),
        "; canonical_data_hashes=",
        paste(
          substr(objects$input_summary$canonical_data_sha256, 1L, 12L),
          collapse = "|"
        )
      ),
      paste0(
        "R=", getRversion(),
        "; RNGkind=Mersenne-Twister/Inversion/Rejection"
      ),
      "m=50 MI object construction only; m=100 and all outcomes remain blocked"
    ),
    freeze_id = freeze_id,
    frozen_at_utc = frozen_at,
    stringsAsFactors = FALSE
  )
  v45_atomic_write_tsv(objects$code, output_paths[["code"]])
  v45_atomic_write_tsv(objects$functions, output_paths[["functions"]])
  v45_atomic_save_rds(
    objects$input_contract, output_paths[["input_contract"]]
  )
  v45_atomic_write_tsv(
    objects$input_summary, output_paths[["input_summary"]]
  )
  v45_atomic_write_tsv(validation, output_paths[["validation"]])
  validation_sha <- v45_sha256_file(output_paths[["validation"]])
  if (length(validation_sha) != 1L || is.na(validation_sha) ||
      !grepl("^[0-9a-f]{64}$", validation_sha)) {
    stop("Stage 3 freeze-validation file cannot be hash-bound.",
         call. = FALSE)
  }
  objects$roots <- rbind(
    objects$roots,
    data.frame(
      root_id = "stage3_production_mi_freeze_validation_file",
      sha256 = validation_sha,
      stringsAsFactors = FALSE
    )
  )
  v45_atomic_write_tsv(objects$roots, output_paths[["roots"]])

  gate$updated_at <- format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")
  gate$stage3_production_mi_freeze <- list(status = "PASS")
  gate$stage3_production_mi_execution <- list(status = "NOT_RUN")
  gate$stage3_production_mi_independent_validation <-
    list(status = "NOT_RUN")
  gate$outcome_execution_allowed <- FALSE
  gate$new_mortality_coefficient_inspection_allowed <- FALSE
  gate$production_m50_objects_allowed <- TRUE
  gate$production_m100_objects_allowed <- FALSE
  gate$next_authorized_step <- "run_production_m50_MI_B_MI_G_MI_S"
  v45_atomic_write_yaml(gate, gate_path)
  message("v45 Stage 3 production m=50 MI authorization frozen.")
}
