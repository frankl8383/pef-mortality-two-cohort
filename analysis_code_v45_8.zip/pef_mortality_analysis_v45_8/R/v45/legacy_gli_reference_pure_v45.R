# Side-effect-free GLI reference implementation for v45 production QA.
#
# These functions are a mechanical extraction of the calculation-only
# empty_numeric/fill_gli_global/fill_gli2012 path in
# R/nhanes/07_nhanes_v0_5_gli_lln_prism_lock.R. They deliberately contain no
# library(), options(), file reads, model fits, or writes.

v45_legacy_empty_numeric <- function(n) rep(NA_real_, n)

v45_legacy_fill_gli_global <- function(data) {
  n <- nrow(data)
  idx_ref <- with(
    data,
    adult_45plus == 1 &
      !is.na(age_years) & age_years >= 3 & age_years <= 95 &
      !is.na(height_cm) & height_cm > 0 &
      sex_code %in% c(1, 2)
  )
  age <- data$age_years[idx_ref]
  height_m <- data$height_cm[idx_ref] / 100
  gender <- data$sex_code[idx_ref]

  pred <- rspiro::pred_GLIgl(
    age, height_m, gender, param = c("FEV1", "FVC", "FEV1FVC")
  )
  lln <- rspiro::LLN_GLIgl(
    age, height_m, gender, param = c("FEV1", "FVC", "FEV1FVC")
  )

  data$gli_global2022_pred_fev1_l <- v45_legacy_empty_numeric(n)
  data$gli_global2022_pred_fvc_l <- v45_legacy_empty_numeric(n)
  data$gli_global2022_pred_fev1_fvc <- v45_legacy_empty_numeric(n)
  data$gli_global2022_lln_fev1_l <- v45_legacy_empty_numeric(n)
  data$gli_global2022_lln_fvc_l <- v45_legacy_empty_numeric(n)
  data$gli_global2022_lln_fev1_fvc <- v45_legacy_empty_numeric(n)
  data$gli_global2022_pred_fev1_l[idx_ref] <- pred$pred.FEV1
  data$gli_global2022_pred_fvc_l[idx_ref] <- pred$pred.FVC
  data$gli_global2022_pred_fev1_fvc[idx_ref] <- pred$pred.FEV1FVC
  data$gli_global2022_lln_fev1_l[idx_ref] <- lln$LLN.FEV1
  data$gli_global2022_lln_fvc_l[idx_ref] <- lln$LLN.FVC
  data$gli_global2022_lln_fev1_fvc[idx_ref] <- lln$LLN.FEV1FVC

  idx_obs <- idx_ref &
    !is.na(data$fev1_l) &
    !is.na(data$fvc_l) &
    !is.na(data$fev1_fvc)
  z <- rspiro::zscore_GLIgl(
    age = data$age_years[idx_obs],
    height = data$height_cm[idx_obs] / 100,
    gender = data$sex_code[idx_obs],
    FEV1 = data$fev1_l[idx_obs],
    FVC = data$fvc_l[idx_obs],
    FEV1FVC = data$fev1_fvc[idx_obs]
  )
  pct <- rspiro::pctpred_GLIgl(
    age = data$age_years[idx_obs],
    height = data$height_cm[idx_obs] / 100,
    gender = data$sex_code[idx_obs],
    FEV1 = data$fev1_l[idx_obs],
    FVC = data$fvc_l[idx_obs],
    FEV1FVC = data$fev1_fvc[idx_obs]
  )

  data$gli_global2022_z_fev1 <- v45_legacy_empty_numeric(n)
  data$gli_global2022_z_fvc <- v45_legacy_empty_numeric(n)
  data$gli_global2022_z_fev1_fvc <- v45_legacy_empty_numeric(n)
  data$gli_global2022_ppred_fev1 <- v45_legacy_empty_numeric(n)
  data$gli_global2022_ppred_fvc <- v45_legacy_empty_numeric(n)
  data$gli_global2022_ppred_fev1_fvc <- v45_legacy_empty_numeric(n)
  data$gli_global2022_z_fev1[idx_obs] <- z$z.score.FEV1
  data$gli_global2022_z_fvc[idx_obs] <- z$z.score.FVC
  data$gli_global2022_z_fev1_fvc[idx_obs] <- z$z.score.FEV1FVC
  data$gli_global2022_ppred_fev1[idx_obs] <- pct$pctpred.FEV1
  data$gli_global2022_ppred_fvc[idx_obs] <- pct$pctpred.FVC
  data$gli_global2022_ppred_fev1_fvc[idx_obs] <- pct$pctpred.FEV1FVC
  data
}

v45_legacy_fill_gli2012 <- function(data) {
  n <- nrow(data)
  data$gli2012_ethnicity_code <- dplyr::case_when(
    data$race_ethnicity_code == 3 ~ 1,
    data$race_ethnicity_code == 4 ~ 2,
    data$race_ethnicity_code %in% c(1, 2, 5) ~ 5,
    TRUE ~ NA_real_
  )
  data$gli2012_ethnicity_label <- dplyr::case_when(
    data$gli2012_ethnicity_code == 1 ~ "Caucasian",
    data$gli2012_ethnicity_code == 2 ~ "African-American",
    data$gli2012_ethnicity_code == 5 ~ "Other/mixed",
    TRUE ~ NA_character_
  )

  idx_ref <- with(
    data,
    adult_45plus == 1 &
      !is.na(age_years) & age_years >= 3 & age_years <= 95 &
      !is.na(height_cm) & height_cm > 0 &
      sex_code %in% c(1, 2) &
      !is.na(gli2012_ethnicity_code)
  )
  age <- data$age_years[idx_ref]
  height_m <- data$height_cm[idx_ref] / 100
  gender <- data$sex_code[idx_ref]
  ethnicity <- data$gli2012_ethnicity_code[idx_ref]

  pred <- rspiro::pred_GLI(
    age, height_m, gender, ethnicity,
    param = c("FEV1", "FVC", "FEV1FVC")
  )
  lln <- rspiro::LLN_GLI(
    age, height_m, gender, ethnicity,
    param = c("FEV1", "FVC", "FEV1FVC")
  )

  data$gli2012_pred_fev1_l <- v45_legacy_empty_numeric(n)
  data$gli2012_pred_fvc_l <- v45_legacy_empty_numeric(n)
  data$gli2012_pred_fev1_fvc <- v45_legacy_empty_numeric(n)
  data$gli2012_lln_fev1_l <- v45_legacy_empty_numeric(n)
  data$gli2012_lln_fvc_l <- v45_legacy_empty_numeric(n)
  data$gli2012_lln_fev1_fvc <- v45_legacy_empty_numeric(n)
  data$gli2012_pred_fev1_l[idx_ref] <- pred$pred.FEV1
  data$gli2012_pred_fvc_l[idx_ref] <- pred$pred.FVC
  data$gli2012_pred_fev1_fvc[idx_ref] <- pred$pred.FEV1FVC
  data$gli2012_lln_fev1_l[idx_ref] <- lln$LLN.FEV1
  data$gli2012_lln_fvc_l[idx_ref] <- lln$LLN.FVC
  data$gli2012_lln_fev1_fvc[idx_ref] <- lln$LLN.FEV1FVC

  idx_obs <- idx_ref &
    !is.na(data$fev1_l) &
    !is.na(data$fvc_l) &
    !is.na(data$fev1_fvc)
  z <- rspiro::zscore_GLI(
    age = data$age_years[idx_obs],
    height = data$height_cm[idx_obs] / 100,
    gender = data$sex_code[idx_obs],
    ethnicity = data$gli2012_ethnicity_code[idx_obs],
    FEV1 = data$fev1_l[idx_obs],
    FVC = data$fvc_l[idx_obs],
    FEV1FVC = data$fev1_fvc[idx_obs]
  )
  pct <- rspiro::pctpred_GLI(
    age = data$age_years[idx_obs],
    height = data$height_cm[idx_obs] / 100,
    gender = data$sex_code[idx_obs],
    ethnicity = data$gli2012_ethnicity_code[idx_obs],
    FEV1 = data$fev1_l[idx_obs],
    FVC = data$fvc_l[idx_obs],
    FEV1FVC = data$fev1_fvc[idx_obs]
  )

  data$gli2012_z_fev1 <- v45_legacy_empty_numeric(n)
  data$gli2012_z_fvc <- v45_legacy_empty_numeric(n)
  data$gli2012_z_fev1_fvc <- v45_legacy_empty_numeric(n)
  data$gli2012_ppred_fev1 <- v45_legacy_empty_numeric(n)
  data$gli2012_ppred_fvc <- v45_legacy_empty_numeric(n)
  data$gli2012_ppred_fev1_fvc <- v45_legacy_empty_numeric(n)
  data$gli2012_z_fev1[idx_obs] <- z$z.score.FEV1
  data$gli2012_z_fvc[idx_obs] <- z$z.score.FVC
  data$gli2012_z_fev1_fvc[idx_obs] <- z$z.score.FEV1FVC
  data$gli2012_ppred_fev1[idx_obs] <- pct$pctpred.FEV1
  data$gli2012_ppred_fvc[idx_obs] <- pct$pctpred.FVC
  data$gli2012_ppred_fev1_fvc[idx_obs] <- pct$pctpred.FEV1FVC
  data
}

v45_validate_gli_against_pure_reference <- function(
    data, tolerance = 1e-12) {
  new <- v45_compute_gli(data)
  reference_input <- data.frame(
    adult_45plus = 1L,
    age_years = as.numeric(data$RIDAGEYR),
    height_cm = as.numeric(data$height_cm),
    sex_code = as.numeric(as.character(data$RIAGENDR)),
    race_ethnicity_code = as.numeric(as.character(data$RIDRETH1)),
    fev1_l = as.numeric(data$fev1_l),
    fvc_l = as.numeric(data$fvc_l),
    fev1_fvc = as.numeric(data$fev1_fvc),
    stringsAsFactors = FALSE
  )
  old <- v45_legacy_fill_gli_global(reference_input)
  old <- v45_legacy_fill_gli2012(old)
  compare <- intersect(
    c(
      "gli_global2022_pred_fev1_l", "gli_global2022_pred_fvc_l",
      "gli_global2022_pred_fev1_fvc", "gli_global2022_lln_fev1_l",
      "gli_global2022_lln_fvc_l", "gli_global2022_lln_fev1_fvc",
      "gli_global2022_z_fev1", "gli_global2022_z_fvc",
      "gli_global2022_z_fev1_fvc", "gli_global2022_ppred_fev1",
      "gli_global2022_ppred_fvc", "gli_global2022_ppred_fev1_fvc",
      "gli2012_pred_fev1_l", "gli2012_pred_fvc_l",
      "gli2012_pred_fev1_fvc", "gli2012_lln_fev1_l",
      "gli2012_lln_fvc_l", "gli2012_lln_fev1_fvc",
      "gli2012_z_fev1", "gli2012_z_fvc", "gli2012_z_fev1_fvc",
      "gli2012_ppred_fev1", "gli2012_ppred_fvc",
      "gli2012_ppred_fev1_fvc"
    ),
    intersect(names(new), names(old))
  )
  differences <- vapply(
    compare,
    function(name) max(abs(new[[name]] - old[[name]])),
    numeric(1)
  )
  maximum <- if (length(differences)) max(differences) else Inf
  list(
    pass = length(compare) == 24L &&
      is.finite(maximum) &&
      maximum <= tolerance,
    fields_compared = length(compare),
    maximum_absolute_difference = maximum,
    tolerance = tolerance
  )
}
