# Pure GLI calculations for v45.
#
# GLI fields are deterministic children of completed height plus observed age,
# sex, race/ethnicity (GLI-2012 only), FEV1, FVC, and FEV1/FVC. They are never
# part of a MICE predictor matrix and this file has no model-fitting or write
# side effects.

v45_gli_lln_z <- -1.64485362695147

v45_compute_gli <- function(data, lln_z = v45_gli_lln_z) {
  required <- c(
    "RIDAGEYR", "RIAGENDR", "RIDRETH1", "height_cm",
    "fev1_l", "fvc_l", "fev1_fvc"
  )
  missing <- setdiff(required, names(data))
  if (length(missing)) {
    stop("GLI input lacks fields: ", paste(missing, collapse = ", "), call. = FALSE)
  }
  n <- nrow(data)
  age <- as.numeric(data$RIDAGEYR)
  sex <- as.numeric(as.character(data$RIAGENDR))
  race <- as.numeric(as.character(data$RIDRETH1))
  height_m <- as.numeric(data$height_cm) / 100
  fev1 <- as.numeric(data$fev1_l)
  fvc <- as.numeric(data$fvc_l)
  ratio <- as.numeric(data$fev1_fvc)
  valid <- is.finite(age) & age >= 3 & age <= 95 &
    is.finite(height_m) & height_m > 0 &
    sex %in% c(1, 2) &
    is.finite(fev1) & fev1 > 0 &
    is.finite(fvc) & fvc > 0 &
    is.finite(ratio) & ratio > 0
  if (!all(valid)) {
    stop("GLI input contains ", sum(!valid), " invalid rows.", call. = FALSE)
  }

  global_pred <- rspiro::pred_GLIgl(
    age, height_m, sex, param = c("FEV1", "FVC", "FEV1FVC")
  )
  global_lln <- rspiro::LLN_GLIgl(
    age, height_m, sex, param = c("FEV1", "FVC", "FEV1FVC")
  )
  global_z <- rspiro::zscore_GLIgl(
    age = age, height = height_m, gender = sex,
    FEV1 = fev1, FVC = fvc, FEV1FVC = ratio
  )
  global_pct <- rspiro::pctpred_GLIgl(
    age = age, height = height_m, gender = sex,
    FEV1 = fev1, FVC = fvc, FEV1FVC = ratio
  )

  ethnicity <- ifelse(
    race == 3, 1,
    ifelse(race == 4, 2, ifelse(race %in% c(1, 2, 5), 5, NA_real_))
  )
  if (anyNA(ethnicity)) {
    stop("GLI-2012 ethnicity mapping failed for one or more rows.", call. = FALSE)
  }
  gli2012_pred <- rspiro::pred_GLI(
    age, height_m, sex, ethnicity,
    param = c("FEV1", "FVC", "FEV1FVC")
  )
  gli2012_lln <- rspiro::LLN_GLI(
    age, height_m, sex, ethnicity,
    param = c("FEV1", "FVC", "FEV1FVC")
  )
  gli2012_z <- rspiro::zscore_GLI(
    age = age, height = height_m, gender = sex, ethnicity = ethnicity,
    FEV1 = fev1, FVC = fvc, FEV1FVC = ratio
  )
  gli2012_pct <- rspiro::pctpred_GLI(
    age = age, height = height_m, gender = sex, ethnicity = ethnicity,
    FEV1 = fev1, FVC = fvc, FEV1FVC = ratio
  )

  out <- data.frame(
    gli_global2022_pred_fev1_l = global_pred$pred.FEV1,
    gli_global2022_pred_fvc_l = global_pred$pred.FVC,
    gli_global2022_pred_fev1_fvc = global_pred$pred.FEV1FVC,
    gli_global2022_lln_fev1_l = global_lln$LLN.FEV1,
    gli_global2022_lln_fvc_l = global_lln$LLN.FVC,
    gli_global2022_lln_fev1_fvc = global_lln$LLN.FEV1FVC,
    gli_global2022_z_fev1 = global_z$z.score.FEV1,
    gli_global2022_z_fvc = global_z$z.score.FVC,
    gli_global2022_z_fev1_fvc = global_z$z.score.FEV1FVC,
    gli_global2022_ppred_fev1 = global_pct$pctpred.FEV1,
    gli_global2022_ppred_fvc = global_pct$pctpred.FVC,
    gli_global2022_ppred_fev1_fvc = global_pct$pctpred.FEV1FVC,
    gli2012_ethnicity_code = ethnicity,
    gli2012_pred_fev1_l = gli2012_pred$pred.FEV1,
    gli2012_pred_fvc_l = gli2012_pred$pred.FVC,
    gli2012_pred_fev1_fvc = gli2012_pred$pred.FEV1FVC,
    gli2012_lln_fev1_l = gli2012_lln$LLN.FEV1,
    gli2012_lln_fvc_l = gli2012_lln$LLN.FVC,
    gli2012_lln_fev1_fvc = gli2012_lln$LLN.FEV1FVC,
    gli2012_z_fev1 = gli2012_z$z.score.FEV1,
    gli2012_z_fvc = gli2012_z$z.score.FVC,
    gli2012_z_fev1_fvc = gli2012_z$z.score.FEV1FVC,
    gli2012_ppred_fev1 = gli2012_pct$pctpred.FEV1,
    gli2012_ppred_fvc = gli2012_pct$pctpred.FVC,
    gli2012_ppred_fev1_fvc = gli2012_pct$pctpred.FEV1FVC,
    stringsAsFactors = FALSE
  )
  out$L_FEV1 <- -out$gli_global2022_z_fev1
  out$L_FVC <- -out$gli_global2022_z_fvc
  out$L_RATIO <- -out$gli_global2022_z_fev1_fvc
  out$gli_global2022_fev1_within_reference <-
    as.integer(out$gli_global2022_z_fev1 >= lln_z)
  out$gli_global2022_fvc_within_reference <-
    as.integer(out$gli_global2022_z_fvc >= lln_z)
  out$gli_global2022_ratio_within_reference <-
    as.integer(out$gli_global2022_z_fev1_fvc >= lln_z)
  out$gli_global2022_all_three_within_reference <- as.integer(
    out$gli_global2022_fev1_within_reference == 1L &
      out$gli_global2022_fvc_within_reference == 1L &
      out$gli_global2022_ratio_within_reference == 1L
  )
  out$gli2012_fev1_within_reference <-
    as.integer(out$gli2012_z_fev1 >= lln_z)
  out$gli2012_fvc_within_reference <-
    as.integer(out$gli2012_z_fvc >= lln_z)
  out$gli2012_ratio_within_reference <-
    as.integer(out$gli2012_z_fev1_fvc >= lln_z)
  out$gli2012_all_three_within_reference <- as.integer(
    out$gli2012_fev1_within_reference == 1L &
      out$gli2012_fvc_within_reference == 1L &
      out$gli2012_ratio_within_reference == 1L
  )
  if (nrow(out) != n || any(!is.finite(as.matrix(out)))) {
    stop("GLI calculation returned non-finite or dimensionally invalid output.",
         call. = FALSE)
  }
  out
}

v45_load_legacy_gli_functions <- function(root) {
  path <- file.path(
    root, "R", "nhanes", "07_nhanes_v0_5_gli_lln_prism_lock.R"
  )
  if (!file.exists(path)) stop("Legacy GLI implementation is missing.", call. = FALSE)
  env <- new.env(parent = globalenv())
  sys.source(path, envir = env)
  required <- c("fill_gli_global", "fill_gli2012")
  missing <- required[!vapply(required, exists, logical(1), envir = env, inherits = FALSE)]
  if (length(missing)) {
    stop("Legacy GLI file lacks pure calculation functions.", call. = FALSE)
  }
  env
}

v45_validate_gli_against_legacy <- function(data, root, tolerance = 1e-12) {
  new <- v45_compute_gli(data)
  legacy_input <- data.frame(
    adult_45plus = 1L,
    age_years = as.numeric(data$RIDAGEYR),
    height_cm = as.numeric(data$height_cm),
    sex_code = as.numeric(as.character(data$RIAGENDR)),
    race_ethnicity_code = as.numeric(as.character(data$RIDRETH1)),
    fev1_l = as.numeric(data$fev1_l),
    fvc_l = as.numeric(data$fvc_l),
    fev1_fvc = as.numeric(data$fev1_fvc),
    stringsAsFactors = FALSE
  )
  legacy_env <- v45_load_legacy_gli_functions(root)
  old <- legacy_env$fill_gli_global(legacy_input)
  old <- legacy_env$fill_gli2012(old)
  compare <- intersect(
    c(
      "gli_global2022_pred_fev1_l", "gli_global2022_pred_fvc_l",
      "gli_global2022_pred_fev1_fvc", "gli_global2022_lln_fev1_l",
      "gli_global2022_lln_fvc_l", "gli_global2022_lln_fev1_fvc",
      "gli_global2022_z_fev1", "gli_global2022_z_fvc",
      "gli_global2022_z_fev1_fvc", "gli_global2022_ppred_fev1",
      "gli_global2022_ppred_fvc", "gli_global2022_ppred_fev1_fvc",
      "gli2012_pred_fev1_l", "gli2012_pred_fvc_l",
      "gli2012_pred_fev1_fvc", "gli2012_lln_fev1_l",
      "gli2012_lln_fvc_l", "gli2012_lln_fev1_fvc",
      "gli2012_z_fev1", "gli2012_z_fvc", "gli2012_z_fev1_fvc",
      "gli2012_ppred_fev1", "gli2012_ppred_fvc",
      "gli2012_ppred_fev1_fvc"
    ),
    intersect(names(new), names(old))
  )
  differences <- vapply(
    compare,
    function(name) max(abs(new[[name]] - old[[name]])),
    numeric(1)
  )
  maximum <- if (length(differences)) max(differences) else Inf
  list(
    pass = length(compare) == 24L && is.finite(maximum) && maximum <= tolerance,
    fields_compared = length(compare),
    maximum_absolute_difference = maximum,
    tolerance = tolerance
  )
}

v45_rspiro_function_names <- function() {
  c(
    "pred_GLIgl", "LLN_GLIgl", "zscore_GLIgl", "pctpred_GLIgl",
    "pred_GLI", "LLN_GLI", "zscore_GLI", "pctpred_GLI"
  )
}

