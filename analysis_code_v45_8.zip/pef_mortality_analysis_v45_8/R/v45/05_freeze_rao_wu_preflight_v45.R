# v45 Stage 2 freeze: authorize the no-outcome Rao-Wu replicate preflight.

options(stringsAsFactors = FALSE)

stage2_root <- function() {
  args <- commandArgs(trailingOnly = FALSE)
  file_arg <- grep("^--file=", args, value = TRUE)
  if (!length(file_arg)) return(normalizePath(getwd(), mustWork = TRUE))
  script <- sub("^--file=", "", file_arg[[1]])
  normalizePath(file.path(dirname(script), "..", ".."), mustWork = TRUE)
}

root <- stage2_root()
source(file.path(root, "R", "v45", "01_nhanes_common_utilities_v45.R"))
v45_require_packages(root)
v45_verify_frozen_manifests(root)

output_paths <- c(
  code = file.path(root, "work_v45", "v45_rao_wu_code_manifest.tsv"),
  functions = file.path(root, "work_v45", "v45_rao_wu_function_manifest.tsv"),
  roots = file.path(root, "work_v45", "v45_rao_wu_freeze_roots.tsv"),
  validation = file.path(
    root, "results", "v45", "v45_rao_wu_stage2_freeze_validation.tsv"
  )
)

function_body_sha <- function(fun) {
  digest::digest(
    paste(c(deparse(formals(fun)), deparse(body(fun))), collapse = "\n"),
    algo = "sha256", serialize = FALSE
  )
}

build_code_manifest <- function() {
  rel <- c(
    "work_v45/rao_wu_preflight_spec_v45.yml",
    "work_v45/v45_full_plan_authorization.md",
    "work_v45/v45_stage2_decision_log.md",
    "work_v45/v45_stage2_amendment_log.md",
    "R/v45/05_freeze_rao_wu_preflight_v45.R",
    "R/v45/06_rao_wu_replicate_preflight_v45.R",
    "R/v45/07_validate_rao_wu_replicate_preflight_v45.R"
  )
  dplyr::bind_rows(lapply(rel, function(path) {
    full <- file.path(root, path)
    data.frame(
      asset_id = paste0("V45_STAGE2::", path),
      path_private = normalizePath(full, mustWork = FALSE),
      path_alias = path,
      exists = file.exists(full) && !dir.exists(full),
      bytes = if (file.exists(full)) as.numeric(file.info(full)$size) else NA_real_,
      sha256 = v45_sha256_file(full),
      immutable = TRUE,
      authorized_purpose = "no-outcome Rao-Wu replicate preflight only",
      stringsAsFactors = FALSE
    )
  }))
}

build_function_manifest <- function() {
  functions <- list(
    "survey:::as.svrepdesign.default" =
      getFromNamespace("as.svrepdesign.default", "survey"),
    "survey:::subbootweights" =
      getFromNamespace("subbootweights", "survey"),
    "survey:::subbootstratum" =
      getFromNamespace("subbootstratum", "survey"),
    "survey:::weights.svyrep.design" =
      getFromNamespace("weights.svyrep.design", "survey"),
    "survey:::withReplicates.svyrep.design" =
      getFromNamespace("withReplicates.svyrep.design", "survey"),
    "survey:::svyglm.svyrep.design" =
      getFromNamespace("svyglm.svyrep.design", "survey"),
    "survey:::svycoxph.svyrep.design" =
      getFromNamespace("svycoxph.svyrep.design", "survey"),
    "survey:::degf.svyrep.design" =
      getFromNamespace("degf.svyrep.design", "survey"),
    "survey:::svrVar" = getFromNamespace("svrVar", "survey")
  )
  data.frame(
    asset_id = names(functions),
    package = "survey",
    package_version = as.character(utils::packageVersion("survey")),
    sha256 = vapply(functions, function_body_sha, character(1)),
    hash_rule = "SHA-256 of formals plus deparsed function body",
    stringsAsFactors = FALSE
  )
}

manifest_root <- function(dat, key, fields) {
  dat <- dat[order(dat[[key]]), fields, drop = FALSE]
  payload <- apply(dat, 1L, function(x) paste(x, collapse = "\u241f"))
  digest::digest(paste(payload, collapse = "\n"), algo = "sha256", serialize = FALSE)
}

build_objects <- function() {
  code <- build_code_manifest()
  functions <- build_function_manifest()
  if (any(!code$exists) || any(!grepl("^[0-9a-f]{64}$", code$sha256))) {
    stop("Stage 2 code/specification assets are incomplete.", call. = FALSE)
  }
  if (!all(functions$package_version == "4.5") ||
      !all(grepl("^[0-9a-f]{64}$", functions$sha256))) {
    stop("Stage 2 survey function contract is invalid.", call. = FALSE)
  }
  stage01_roots <- utils::read.delim(
    file.path(root, "work_v45", "v45_freeze_roots.tsv"),
    stringsAsFactors = FALSE, check.names = FALSE
  )
  roots <- data.frame(
    root_id = c(
      "stage2_code_root", "stage2_survey_function_root",
      "stage0_1_input_root", "stage0_1_code_root",
      "stage0_1_runtime_root"
    ),
    sha256 = c(
      manifest_root(
        code, "asset_id",
        c("asset_id", "path_alias", "bytes", "sha256", "immutable")
      ),
      manifest_root(
        functions, "asset_id",
        c("asset_id", "package", "package_version", "sha256")
      ),
      stage01_roots$sha256[
        stage01_roots$root_id == "input_manifest_root"
      ],
      stage01_roots$sha256[
        stage01_roots$root_id == "code_manifest_root"
      ],
      stage01_roots$sha256[
        stage01_roots$root_id == "runtime_manifest_root"
      ]
    ),
    stringsAsFactors = FALSE
  )
  list(code = code, functions = functions, roots = roots)
}

same_manifest <- function(recorded, current, key, fields) {
  recorded <- recorded[order(recorded[[key]]), fields, drop = FALSE]
  current <- current[order(current[[key]]), fields, drop = FALSE]
  normalize <- function(dat) {
    lapply(dat, function(x) {
      out <- as.character(x)
      out[is.na(out) | !nzchar(out)] <- NA_character_
      out
    })
  }
  identical(normalize(recorded), normalize(current))
}

verify_stage2 <- function(objects) {
  if (any(!file.exists(output_paths))) {
    stop("Stage 2 frozen manifests are absent.", call. = FALSE)
  }
  recorded_code <- utils::read.delim(
    output_paths[["code"]], stringsAsFactors = FALSE, check.names = FALSE
  )
  recorded_functions <- utils::read.delim(
    output_paths[["functions"]], stringsAsFactors = FALSE, check.names = FALSE
  )
  recorded_roots <- utils::read.delim(
    output_paths[["roots"]], stringsAsFactors = FALSE, check.names = FALSE
  )
  ok <- c(
    code = same_manifest(
      recorded_code, objects$code, "asset_id",
      c(
        "asset_id", "path_private", "path_alias", "exists", "bytes",
        "sha256", "immutable", "authorized_purpose"
      )
    ),
    functions = same_manifest(
      recorded_functions, objects$functions, "asset_id",
      c(
        "asset_id", "package", "package_version", "sha256", "hash_rule"
      )
    ),
    roots = same_manifest(
      recorded_roots, objects$roots, "root_id",
      c("root_id", "sha256")
    )
  )
  if (!all(ok)) {
    stop(
      "Stage 2 frozen assets changed: ",
      paste(names(ok)[!ok], collapse = ", "),
      call. = FALSE
    )
  }
  invisible(TRUE)
}

mode <- if ("--verify" %in% commandArgs(trailingOnly = TRUE)) {
  "verify"
} else {
  "freeze"
}
objects <- build_objects()

if (identical(mode, "verify")) {
  verify_stage2(objects)
  message("v45 Stage 2 Rao-Wu authorization verifies exactly.")
} else {
  if (any(file.exists(output_paths))) {
    stop("Stage 2 freeze outputs already exist; use --verify.", call. = FALSE)
  }
  freeze_id <- paste0(
    "v45_stage2_freeze_", format(Sys.time(), "%Y%m%dT%H%M%S"),
    "_pid", Sys.getpid()
  )
  frozen_at <- format(Sys.time(), "%Y-%m-%dT%H:%M:%SZ", tz = "UTC")
  for (name in names(objects)) {
    objects[[name]]$freeze_id <- freeze_id
    objects[[name]]$frozen_at_utc <- frozen_at
  }
  validation <- data.frame(
    check = c(
      "stage0_1_manifests_current",
      "stage2_code_and_specification_complete",
      "survey_4_5_subbootstrap_functions_frozen",
      "true_outcome_and_exposure_execution_blocked"
    ),
    status = rep("PASS", 4L),
    detail = c(
      "all predecessor/input/code/runtime hashes current",
      paste0("assets=", nrow(objects$code)),
      paste0("functions=", nrow(objects$functions)),
      "Stage 2 authorizes synthetic-interface and replicate-structure tests only"
    ),
    freeze_id = freeze_id,
    frozen_at_utc = frozen_at,
    stringsAsFactors = FALSE
  )
  v45_atomic_write_tsv(objects$code, output_paths[["code"]])
  v45_atomic_write_tsv(objects$functions, output_paths[["functions"]])
  v45_atomic_write_tsv(objects$roots, output_paths[["roots"]])
  v45_atomic_write_tsv(validation, output_paths[["validation"]])

  gate_path <- file.path(root, "work_v45", "gate_state_v45.yml")
  gate <- yaml::read_yaml(gate_path)
  gate$updated_at <- format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")
  gate$stage2_rao_wu_preflight_freeze <- list(status = "PASS")
  gate$stage2_rao_wu_structural_preflight <- list(status = "NOT_RUN")
  gate$stage2_rao_wu_independent_validation <- list(status = "NOT_RUN")
  gate$outcome_execution_allowed <- FALSE
  gate$new_mortality_coefficient_inspection_allowed <- FALSE
  gate$production_m50_objects_allowed <- FALSE
  gate$next_authorized_step <- "run_no_outcome_Rao_Wu_preflight"
  v45_atomic_write_yaml(gate, gate_path)
  message("v45 Stage 2 no-outcome Rao-Wu preflight authorization frozen.")
}
