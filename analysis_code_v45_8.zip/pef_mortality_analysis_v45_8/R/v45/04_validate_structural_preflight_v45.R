# Independent aggregate-only validator for v45 Stage 0-1.
#
# This script re-verifies frozen hashes, MI contracts, dry-run determinism,
# passive-variable audits, design/model-matrix structure, and output schemas.
# It never opens the NHANES row-level ledger and never fits an outcome model.

options(stringsAsFactors = FALSE)

script_root <- function() {
  args <- commandArgs(trailingOnly = FALSE)
  file_arg <- grep("^--file=", args, value = TRUE)
  if (!length(file_arg)) return(normalizePath(getwd(), mustWork = TRUE))
  script <- sub("^--file=", "", file_arg[[1]])
  normalizePath(file.path(dirname(script), "..", ".."), mustWork = TRUE)
}

root <- script_root()
source(file.path(root, "R", "v45", "01_nhanes_common_utilities_v45.R"))
source(file.path(root, "R", "v45", "02_gli_functions_v45.R"))
runtime <- v45_require_packages(root)

validation_path <- file.path(
  root, "results", "v45", "v45_structural_preflight_validation.tsv"
)
output_manifest_path <- file.path(
  root, "results", "v45", "v45_output_manifest.tsv"
)
qa_path <- file.path(
  root, "output", "qa", "v45",
  "V45_STAGE0_1_FREEZE_MI_PREFLIGHT_QA.md"
)
existing <- c(validation_path, output_manifest_path, qa_path)
if (any(file.exists(existing))) {
  stop(
    "Independent-validation outputs already exist; refusing overwrite: ",
    paste(existing[file.exists(existing)], collapse = "; "),
    call. = FALSE
  )
}

paths <- c(
  contracts = file.path(root, "results", "v45", "v45_mi_object_contracts.tsv"),
  predictors = file.path(root, "results", "v45", "v45_predictor_matrix_audit.tsv"),
  structural = file.path(root, "results", "v45", "v45_structural_preflight.tsv"),
  gli = file.path(root, "results", "v45", "v45_passive_gli_validation.tsv"),
  matrices = file.path(root, "results", "v45", "v45_model_matrix_audit.tsv"),
  collinearity = file.path(root, "results", "v45", "v45_exposure_collinearity_audit.tsv"),
  definitions = file.path(
    root, "derived_sensitive", "v45", "v45_mi_object_definitions_v45.rds"
  ),
  run_log = file.path(root, "logs", "v45", "v45_structural_preflight.log")
)
if (any(!file.exists(paths))) {
  stop(
    "Structural preflight is incomplete: ",
    paste(names(paths)[!file.exists(paths)], collapse = ", "),
    call. = FALSE
  )
}

gate_path <- file.path(root, "work_v45", "gate_state_v45.yml")
gate <- yaml::read_yaml(gate_path)
if (!identical(
  gate$stage1_mi_object_structural_preflight$status,
  "PASS_PENDING_INDEPENDENT_VALIDATION"
)) {
  stop("Stage 1 is not awaiting independent validation.", call. = FALSE)
}
if (isTRUE(gate$outcome_execution_allowed) ||
    isTRUE(gate$new_mortality_coefficient_inspection_allowed) ||
    isTRUE(gate$production_m50_objects_allowed)) {
  stop("A blocked v45 execution gate was unexpectedly opened.", call. = FALSE)
}

tables <- lapply(paths[1:6], function(path) {
  utils::read.delim(path, stringsAsFactors = FALSE, check.names = FALSE)
})
contracts <- tables$contracts
predictors <- tables$predictors
structural <- tables$structural
gli <- tables$gli
matrices <- tables$matrices
collinearity <- tables$collinearity
definitions <- readRDS(paths[["definitions"]])

checks <- list()
add_check <- function(check, pass, observed, expected) {
  checks[[length(checks) + 1L]] <<- data.frame(
    check = check,
    status = if (isTRUE(pass)) "PASS" else "FAIL",
    observed = v45_one_line(observed),
    expected = v45_one_line(expected),
    stringsAsFactors = FALSE
  )
  invisible(pass)
}

freeze_checks <- tryCatch(
  v45_verify_frozen_manifests(root),
  error = function(e) e
)
add_check(
  "frozen_manifests_independently_current",
  !inherits(freeze_checks, "error") &&
    all(freeze_checks$status == "PASS"),
  if (inherits(freeze_checks, "error")) {
    conditionMessage(freeze_checks)
  } else {
    paste(freeze_checks$check, freeze_checks$status,
          sep = "=", collapse = ";")
  },
  "all frozen predecessor/input/code/runtime hashes remain current"
)

expected_objects <- c("MI-B", "MI-G", "MI-S")
anchor_ok <-
  identical(as.character(contracts$object_id), expected_objects) &&
  identical(as.integer(contracts$denominator_n), c(6719L, 6540L, 7926L)) &&
  identical(as.integer(contracts$frozen_event_n), c(925L, 885L, 1228L)) &&
  identical(as.integer(contracts$height_missing_n), c(31L, 30L, 109L)) &&
  identical(as.integer(contracts$weight_missing_n), c(34L, 32L, 110L)) &&
  identical(as.integer(contracts$bmi_missing_n), c(42L, 40L, 125L)) &&
  all(contracts$status == "PASS") &&
  all(contracts$dry_m == 2L) &&
  all(contracts$dry_maxit == 2L) &&
  all(contracts$warning_count == 0L) &&
  all(contracts$logged_event_count == 0L) &&
  all(grepl("^[0-9a-f]{64}$", contracts$dry_payload_sha256))
add_check(
  "MI_object_contracts_and_dry_runs",
  anchor_ok,
  paste0(
    "objects=", paste(contracts$object_id, collapse = "/"),
    "; N=", paste(contracts$denominator_n, collapse = "/"),
    "; dry_status=", paste(contracts$status, collapse = "/")
  ),
  "MI-B/MI-G/MI-S anchors, m=2/maxit=2 determinism, and zero warning/logged-event contracts all match"
)

definition_hash <- v45_sha256_file(paths[["definitions"]])
definition_hash_ok <- all(
  contracts$definition_sha256 == definition_hash
)
mi_b_signature <- v45_mi_signature_v43_nhanes(
  definitions$MI_B$specification
)
mi_b_signature_ok <- identical(
  mi_b_signature,
  "f02674d75f213a424cbcc4f1617a89c6cfbc8258af45c64d779ca3fb5153e685"
)
mi_g_spec <- definitions$MI_G$specification
mi_s_spec <- definitions$MI_S$specification
mi_g_contract_ok <-
  definitions$MI_G$denominator_n == 6540L &&
  identical(mi_g_spec$seed, 450201L) &&
  all(mi_g_spec$predictor_matrix[, c("E0", "E0b")] == 0) &&
  !any(grepl("^gli", definitions$MI_G$columns, ignore.case = TRUE)) &&
  isTRUE(definitions$MI_G$GLI_rule$recompute_after_completed_height)
mi_s_forbidden <- v45_forbidden_mi_s_fields(definitions$MI_S$columns)
mi_s_active_nonpassive <- setdiff(
  names(mi_s_spec$method)[nzchar(mi_s_spec$method)],
  "bmi"
)
mi_s_contract_ok <-
  definitions$MI_S$denominator_n == 7926L &&
  identical(mi_s_spec$seed, 450301L) &&
  !length(mi_s_forbidden) &&
  !nzchar(mi_s_spec$method[["R_A"]]) &&
  all(mi_s_spec$predictor_matrix[mi_s_active_nonpassive, "R_A"] == 1) &&
  !grepl(
    "death|nelson_aalen|followup|PERMTH",
    definitions$MI_S$response_formula,
    ignore.case = TRUE
  )
add_check(
  "saved_MI_definitions_match_frozen_contracts",
  definition_hash_ok && mi_b_signature_ok &&
    mi_g_contract_ok && mi_s_contract_ok &&
    isTRUE(definitions$no_completed_data_or_mids_saved),
  paste0(
    "definition_sha256=", definition_hash,
    "; MI-B_signature=", mi_b_signature,
    "; MI-G=", mi_g_contract_ok,
    "; MI-S=", mi_s_contract_ok,
    "; completed_data_saved=", !isTRUE(definitions$no_completed_data_or_mids_saved)
  ),
  "one row-restricted definition artifact, exact inherited MI-B signature, MI-G passive-GLI rule, MI-S exclusion/response rule, and no completed datasets or mids"
)

add_check(
  "predictor_matrix_audits_all_pass",
  nrow(predictors) > 0L &&
    all(predictors$status == "PASS") &&
    all(predictors$matrix_rank == predictors$expanded_columns) &&
    all(predictors$expanded_columns < predictors$observed_target_rows) &&
    all(is.finite(predictors$normalized_crossprod_rcond) &
          predictors$normalized_crossprod_rcond > 0),
  paste0(
    "rows=", nrow(predictors),
    "; failures=", sum(predictors$status != "PASS"),
    "; minimum_rcond=",
    signif(min(predictors$normalized_crossprod_rcond), 5)
  ),
  "every active FCS target has a smaller full-rank expanded predictor matrix with positive normalized reciprocal condition"
)

add_check(
  "passive_BMI_and_GLI_audits_all_pass",
  nrow(gli) >= 6L && all(gli$status == "PASS") &&
    any(gli$check == "legacy_numerical_concordance") &&
    any(gli$check == "observed_height_rows_invariant_across_imputations") &&
    any(gli$check == "completed_height_drives_passive_GLI") &&
    sum(gli$check == "passive_BMI_identity") == 3L,
  paste0(
    "rows=", nrow(gli),
    "; failures=", sum(gli$status != "PASS")
  ),
  "three passive-BMI audits plus legacy GLI concordance, observed-height invariance and completed-height dependency all PASS"
)

g_rows <- matrices$analysis_id != "v45_ipw_d1"
d1_rows <- matrices$analysis_id == "v45_ipw_d1"
matrix_ok <-
  sum(g_rows) == 22L &&
  all(matrices$status == "PASS") &&
  all(matrices$matrix_rank == matrices$columns) &&
  sum(d1_rows) == 2L &&
  all(matrices$columns[d1_rows] == 28L) &&
  all(matrices$matrix_rank[d1_rows] == 28L) &&
  all(matrices$design_df[d1_rows] == 49L) &&
  all(matrices$formula_outcome_auxiliary_count[d1_rows] == 0L)
add_check(
  "registered_model_matrices_full_rank_without_fitting",
  matrix_ok,
  paste0(
    "G-matrices=", sum(g_rows),
    "; D1-matrices=", sum(d1_rows),
    "; failures=", sum(matrices$status != "PASS")
  ),
  "eleven registered G structures across two imputations and two 28/28 D1 matrices are full rank; no outcome model fit"
)

collinearity_ok <-
  nrow(collinearity) == 16L &&
  all(collinearity$status == "PASS") &&
  !any(collinearity$structural_state == "NUMERICAL_STOP") &&
  all(collinearity$residual_matrix_rank == collinearity$exposure_count)
add_check(
  "residual_exposure_collinearity_precheck",
  collinearity_ok,
  paste0(
    "rows=", nrow(collinearity),
    "; GO=", sum(collinearity$structural_state == "GO"),
    "; CAUTION=", sum(collinearity$structural_state == "CAUTION"),
    "; STOP=", sum(collinearity$structural_state == "NUMERICAL_STOP")
  ),
  "full-sample and leave-one-cycle-out exposure blocks remain full rank; CAUTION is retained rather than tuned away"
)

add_check(
  "all_first_pass_structural_checks_pass",
  nrow(structural) > 0L && all(structural$status == "PASS"),
  paste0(
    "checks=", nrow(structural),
    "; failures=", sum(structural$status != "PASS")
  ),
  "every first-pass structural check is PASS"
)

forbidden_column_pattern <- paste0(
  "(^|_)(coefficient|coef|hazard_ratio|hr|estimate|",
  "ci_low|ci_high|p_value|pvalue|direction)(_|$)"
)
forbidden_columns <- unique(unlist(lapply(tables, function(dat) {
  grep(
    forbidden_column_pattern, names(dat),
    value = TRUE, ignore.case = TRUE, perl = TRUE
  )
})))
identifier_columns <- unique(unlist(lapply(tables, function(dat) {
  grep(
    "^(SEQN|participant_id|ID)$", names(dat),
    value = TRUE, ignore.case = TRUE
  )
})))
v45_code_paths <- file.path(
  root, "R", "v45",
  c(
    "00_freeze_and_manifest_v45.R",
    "01_nhanes_common_utilities_v45.R",
    "02_gli_functions_v45.R",
    "03_nhanes_mi_preflight_v45.R",
    "04_validate_structural_preflight_v45.R"
  )
)
code_text <- paste(
  unlist(lapply(v45_code_paths, readLines, warn = FALSE)),
  collapse = "\n"
)
prohibited_fit_calls <- gregexpr(
  "(svycoxph|coxph)\\s*\\(",
  code_text,
  ignore.case = TRUE,
  perl = TRUE
)[[1]]
prohibited_fit_count <- if (identical(prohibited_fit_calls[[1]], -1L)) {
  0L
} else {
  length(prohibited_fit_calls)
}
add_check(
  "blind_output_schema_and_static_fit_guard",
  !length(forbidden_columns) &&
    !length(identifier_columns) &&
    prohibited_fit_count == 0L,
  paste0(
    "forbidden_result_columns=",
    if (length(forbidden_columns)) {
      paste(forbidden_columns, collapse = "|")
    } else {
      "none"
    },
    "; row_identifier_columns=",
    if (length(identifier_columns)) {
      paste(identifier_columns, collapse = "|")
    } else {
      "none"
    },
    "; prohibited_outcome_fit_calls=", prohibited_fit_count
  ),
  "no coefficient/HR/CI/P/direction columns, no row identifiers, and no Cox fit call in Stage 0-1 code"
)

all_checks <- dplyr::bind_rows(checks)
if (any(all_checks$status != "PASS")) {
  v45_atomic_write_tsv(all_checks, validation_path)
  stop(
    "Independent v45 Stage 0-1 validation failed: ",
    paste(all_checks$check[all_checks$status != "PASS"], collapse = ", "),
    call. = FALSE
  )
}

roots <- utils::read.delim(
  file.path(root, "work_v45", "v45_freeze_roots.tsv"),
  stringsAsFactors = FALSE, check.names = FALSE
)
manifest_assets <- c(paths, validation = validation_path)
asset_rows <- lapply(names(manifest_assets), function(name) {
  path <- manifest_assets[[name]]
  exists <- file.exists(path) && !dir.exists(path)
  dat <- if (
    exists && grepl("\\.tsv$", path, ignore.case = TRUE) &&
      !identical(name, "validation")
  ) {
    tryCatch(
      utils::read.delim(path, stringsAsFactors = FALSE, check.names = FALSE),
      error = function(e) NULL
    )
  } else {
    NULL
  }
  data.frame(
    artifact_id = name,
    path_alias = if (startsWith(path, paste0(root, "/"))) {
      substring(path, nchar(root) + 2L)
    } else {
      path
    },
    restricted = grepl("^derived_sensitive/", if (startsWith(path, paste0(root, "/"))) {
      substring(path, nchar(root) + 2L)
    } else {
      path
    }),
    exists = exists,
    bytes = if (exists) as.numeric(file.info(path)$size) else NA_real_,
    sha256 = if (exists) v45_sha256_file(path) else NA_character_,
    rows = if (is.null(dat)) NA_integer_ else nrow(dat),
    columns = if (is.null(dat)) NA_integer_ else ncol(dat),
    input_manifest_root_sha256 =
      roots$sha256[roots$root_id == "input_manifest_root"],
    code_manifest_root_sha256 =
      roots$sha256[roots$root_id == "code_manifest_root"],
    runtime_manifest_root_sha256 =
      roots$sha256[roots$root_id == "runtime_manifest_root"],
    gate_status = "STAGE0_1_PASS_OUTCOME_BLOCKED",
    stringsAsFactors = FALSE
  )
})
output_manifest <- dplyr::bind_rows(asset_rows)

v45_atomic_write_tsv(all_checks, validation_path)
output_manifest$sha256[output_manifest$artifact_id == "validation"] <-
  v45_sha256_file(validation_path)
output_manifest$bytes[output_manifest$artifact_id == "validation"] <-
  as.numeric(file.info(validation_path)$size)
output_manifest$exists[output_manifest$artifact_id == "validation"] <- TRUE
v45_atomic_write_tsv(output_manifest, output_manifest_path)

qa_lines <- c(
  "# V45 Stage 0–1 freeze and MI structural-preflight QA",
  "",
  paste0("**Validated:** ",
         format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")),
  "",
  "## Outcome",
  "",
  "- Authoritative v44.2 archive and the three protected live-drift files remain hash-bound.",
  "- MI-B, MI-G and MI-S definitions passed denominator, seed, predictor-matrix and passive-BMI contracts.",
  "- Each object reproduced the same imputation payload in two independent `m=2/maxit=2` runs with zero warnings or logged events.",
  "- GLI Global 2022 and GLI-2012 matched the legacy implementation on observed-height rows and were recomputed from completed height.",
  "- All registered G matrices and the 28-column D1 response matrix were full rank; collinearity cautions, if any, were retained without tuning.",
  "- No mortality model was fitted. No new coefficient, HR, CI, P value or direction was generated or inspected.",
  "- No completed imputation datasets or `mids` objects were saved; only the local object definitions and aggregate QA were retained.",
  "",
  "## Gate",
  "",
  "Outcome execution, new mortality-coefficient inspection and production `m=50` objects remain blocked.",
  "The next technical step is a separately frozen, no-outcome Rao–Wu replicate preflight, followed by a new explicit authorization gate.",
  "",
  paste0("Independent checks passed: ", nrow(all_checks), "/", nrow(all_checks), ".")
)
v45_atomic_write_lines(qa_lines, qa_path)

gate$updated_at <- format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")
gate$stage1_mi_object_structural_preflight$status <- "PASS"
gate$stage1_independent_validation$status <- "PASS"
gate$outcome_execution_allowed <- FALSE
gate$new_mortality_coefficient_inspection_allowed <- FALSE
gate$production_m50_objects_allowed <- FALSE
gate$next_authorized_step <-
  "freeze_and_run_no_outcome_Rao_Wu_replicate_preflight"
v45_atomic_write_yaml(gate, gate_path)

message(
  "Independent v45 Stage 0-1 validation passed. Outcome and production-MI ",
  "gates remain closed."
)
