#!/usr/bin/env Rscript

# Freeze the complete v45 NHANES outcome execution contract.
#
# This script may read hashes, aggregate anchors, formulas, and design
# metadata. It never completes a mids object, fits a mortality model, calls a
# Cox routine, or writes any coefficient-bearing output.

options(stringsAsFactors = FALSE, warn = 2)

stage4_root <- function() {
  args <- commandArgs(trailingOnly = FALSE)
  file_arg <- grep("^--file=", args, value = TRUE)
  if (!length(file_arg)) return(normalizePath(getwd(), mustWork = TRUE))
  script <- sub("^--file=", "", file_arg[[1L]])
  normalizePath(file.path(dirname(script), "..", ".."), mustWork = TRUE)
}

root <- stage4_root()
source(file.path(root, "R", "v45", "01_nhanes_common_utilities_v45.R"))
source(file.path(root, "R", "v45", "02_gli_functions_v45.R"))
source(file.path(root, "R", "v45", "11_nhanes_outcome_utilities_v45.R"))
v45_require_packages(root)

paths <- list(
  spec = file.path(root, "work_v45", "outcome_execution_spec_v45.yml"),
  decision = file.path(
    root, "work_v45", "v45_outcome_decision_log.md"
  ),
  amendment = file.path(
    root, "work_v45", "v45_outcome_amendment_log.md"
  ),
  code = file.path(
    root, "work_v45", "v45_outcome_code_manifest.tsv"
  ),
  functions = file.path(
    root, "work_v45", "v45_outcome_function_manifest.tsv"
  ),
  inputs = file.path(
    root, "work_v45", "v45_outcome_input_manifest.tsv"
  ),
  registry = file.path(
    root, "work_v45", "v45_outcome_model_registry.tsv"
  ),
  thresholds = file.path(
    root, "work_v45", "v45_outcome_threshold_registry.tsv"
  ),
  roots = file.path(
    root, "work_v45", "v45_outcome_freeze_roots.tsv"
  ),
  contract = file.path(
    root, "derived_sensitive", "v45",
    "v45_nhanes_outcome_execution_contract.rds"
  ),
  validation = file.path(
    root, "results", "v45",
    "v45_nhanes_outcome_freeze_validation.tsv"
  ),
  output_manifest = file.path(
    root, "results", "v45",
    "v45_nhanes_outcome_freeze_output_manifest.tsv"
  ),
  gate = file.path(root, "work_v45", "gate_state_v45.yml")
)

manifest_root <- function(data, key, fields) {
  data <- data[order(data[[key]]), fields, drop = FALSE]
  normalized <- lapply(data, function(x) {
    out <- as.character(x)
    out[is.na(out) | !nzchar(out)] <- "<MISSING>"
    out
  })
  normalized <- as.data.frame(
    normalized, stringsAsFactors = FALSE, check.names = FALSE
  )
  rows <- apply(
    normalized, 1L, function(x) paste(x, collapse = "\u241f")
  )
  digest::digest(
    paste(rows, collapse = "\n"), algo = "sha256", serialize = FALSE
  )
}

function_sha <- function(fun) {
  digest::digest(
    paste(c(deparse(formals(fun)), deparse(body(fun))), collapse = "\n"),
    algo = "sha256", serialize = FALSE
  )
}

read_tsv <- function(path) {
  utils::read.delim(
    path, stringsAsFactors = FALSE, check.names = FALSE,
    na.strings = c("", "NA")
  )
}

gate_yes <- function(x) {
  isTRUE(x) ||
    tolower(as.character(x)) %in% c("yes", "true", "1")
}

gate_no <- function(x) {
  identical(x, FALSE) ||
    tolower(as.character(x)) %in% c("no", "false", "0")
}

assert_regular <- function(path, label) {
  if (!file.exists(path) || dir.exists(path)) {
    stop("Required ", label, " is absent: ", path, call. = FALSE)
  }
  invisible(path)
}

build_code_manifest <- function() {
  aliases <- c(
    "work_v45/outcome_execution_spec_v45.yml",
    "work_v45/v45_analysis_registry.tsv",
    "work_v45/v45_estimand_registry.tsv",
    "work_v45/v45_outcome_decision_log.md",
    "work_v45/v45_outcome_amendment_log.md",
    "R/v45/01_nhanes_common_utilities_v45.R",
    "R/v45/02_gli_functions_v45.R",
    "R/v45/production_mi_hashes_v45.R",
    "R/v45/11_nhanes_outcome_utilities_v45.R",
    "R/v45/12_freeze_nhanes_outcome_execution_v45.R",
    "R/v45/13_run_nhanes_outcome_execution_v45.R",
    "R/v45/14_validate_nhanes_outcome_execution_v45.R",
    paste0(
      "output/code_archive/PEF_mortality_v44_2_code_candidate/",
      "R/v43/05_nhanes_stage3_primary_mortality.R"
    ),
    "output/qa/V45_0_LITERATURE_INFORMED_REVISION_AND_ANALYSIS_PLAN_20260723.md"
  )
  dplyr::bind_rows(lapply(aliases, function(alias) {
    path <- file.path(root, alias)
    data.frame(
      asset_id = paste0("V45_STAGE4_OUTCOME::", alias),
      path_alias = alias,
      bytes = if (file.exists(path)) as.numeric(file.info(path)$size) else NA_real_,
      sha256 = v45_sha256_file(path),
      immutable = TRUE,
      authorized_purpose =
        "frozen NHANES outcome execution and independent aggregate release",
      stringsAsFactors = FALSE
    )
  }))
}

build_function_manifest <- function() {
  utility_env <- new.env(parent = globalenv())
  sys.source(
    file.path(root, "R", "v45", "11_nhanes_outcome_utilities_v45.R"),
    envir = utility_env
  )
  utility_names <- sort(ls(utility_env, pattern = "^v45_"))
  utility_names <- utility_names[vapply(
    utility_names,
    function(name) is.function(get(name, envir = utility_env)),
    logical(1)
  )]
  v43 <- v45_load_v43_nhanes_functions(root)
  v43_names <- c(
    "attach_passive_variables", "fixed_ns", "get_knot_row",
    "model_formulas"
  )
  if (any(!vapply(
    v43_names, exists, logical(1), envir = v43, inherits = FALSE
  ))) {
    stop("The authoritative v43 function closure is incomplete.",
         call. = FALSE)
  }
  dplyr::bind_rows(
    data.frame(
      asset_id = paste0("v45_outcome::", utility_names),
      function_name = utility_names,
      source = "R/v45/11_nhanes_outcome_utilities_v45.R",
      sha256 = vapply(
        utility_names,
        function(name) function_sha(get(name, envir = utility_env)),
        character(1)
      ),
      hash_rule = "SHA-256 of formals plus deparsed function body",
      stringsAsFactors = FALSE
    ),
    data.frame(
      asset_id = paste0("v43_authority::", v43_names),
      function_name = v43_names,
      source = paste0(
        "output/code_archive/PEF_mortality_v44_2_code_candidate/",
        "R/v43/05_nhanes_stage3_primary_mortality.R"
      ),
      sha256 = vapply(
        v43_names,
        function(name) function_sha(get(name, envir = v43)),
        character(1)
      ),
      hash_rule = "SHA-256 of formals plus deparsed function body",
      stringsAsFactors = FALSE
    )
  )
}

production_pointer_path <- function(object_id) {
  file.path(
    root, "results", "v45", "production_mi",
    paste0(gsub("-", "_", object_id, fixed = TRUE), "_m50_current.tsv")
  )
}

validate_stage3_pointers <- function(spec) {
  object_ids <- c("MI-B", "MI-G", "MI-S")
  rows <- lapply(object_ids, function(object_id) {
    pointer_path <- production_pointer_path(object_id)
    pointer <- read_tsv(assert_regular(pointer_path, object_id))
    if (
      nrow(pointer) != 1L ||
      !identical(pointer$object_id[[1L]], object_id) ||
      as.integer(pointer$requested_m[[1L]]) != 50L ||
      !identical(
        pointer$status[[1L]], "INDEPENDENT_VALIDATION_PASS"
      )
    ) {
      stop(object_id, " production pointer is not independently validated.",
           call. = FALSE)
    }
    mids_path <- file.path(root, pointer$mids_path_alias[[1L]])
    mids_sha <- v45_sha256_file(assert_regular(mids_path, object_id))
    expected <- spec$frozen_inputs[[object_id]]$mids_sha256
    if (
      !identical(mids_sha, pointer$mids_sha256[[1L]]) ||
      !identical(mids_sha, expected)
    ) {
      stop(object_id, " mids hash differs from the Stage 4 specification.",
           call. = FALSE)
    }
    data.frame(
      asset_id = paste0("mids_", object_id),
      object_id = object_id,
      path_alias = pointer$mids_path_alias[[1L]],
      bytes = as.numeric(file.info(mids_path)$size),
      sha256 = mids_sha,
      local_restricted = TRUE,
      status = "PASS",
      stringsAsFactors = FALSE
    )
  })
  dplyr::bind_rows(rows)
}

build_input_manifest <- function(spec) {
  mids <- validate_stage3_pointers(spec)
  aliases <- c(
    "derived_sensitive/v43/nhanes_stage3_analysis_ledger_v43.rds",
    "derived_sensitive/v45/v45_rao_wu_replicate_contract.rds",
    "derived_sensitive/v45/v45_production_mi_input_contract.rds",
    "results/v45/v45_production_mi_independent_validation.tsv",
    "results/v45/v45_production_mi_independent_object_summary.tsv",
    "results/v45/v45_production_mi_independent_validation_output_manifest.tsv",
    "results/v45/v45_exposure_collinearity_audit.tsv",
    paste0(
      "output/code_archive/PEF_mortality_v44_2_code_candidate/",
      "results/v43/stage3_nhanes_primary_association_registry_v43.csv"
    )
  )
  fixed <- dplyr::bind_rows(lapply(seq_along(aliases), function(i) {
    alias <- aliases[[i]]
    path <- assert_regular(file.path(root, alias), alias)
    data.frame(
      asset_id = paste0("frozen_input_", sprintf("%02d", i)),
      object_id = NA_character_,
      path_alias = alias,
      bytes = as.numeric(file.info(path)$size),
      sha256 = v45_sha256_file(path),
      local_restricted = grepl(
        "^derived_sensitive/", alias
      ),
      status = "PASS",
      stringsAsFactors = FALSE
    )
  }))
  pointer_rows <- dplyr::bind_rows(lapply(c("MI-B", "MI-G", "MI-S"), function(id) {
    path <- production_pointer_path(id)
    alias <- substring(path, nchar(root) + 2L)
    data.frame(
      asset_id = paste0("pointer_", id),
      object_id = id,
      path_alias = alias,
      bytes = as.numeric(file.info(path)$size),
      sha256 = v45_sha256_file(path),
      local_restricted = FALSE,
      status = "PASS",
      stringsAsFactors = FALSE
    )
  }))
  dplyr::bind_rows(fixed, pointer_rows, mids)
}

threshold_registry <- function(spec) {
  gate <- spec$hard_gates
  data.frame(
    metric = c(
      "response_probability_p01",
      "availability_factor_p99",
      "ESS_ratio",
      "maximum_absolute_SMD",
      "valid_replicate_fraction",
      "monte_carlo_error_fraction"
    ),
    go_rule = c(
      ">=0.05", "<=10", ">=0.50", "<=0.10", ">=0.95", "<0.10"
    ),
    caution_rule = c(
      ">0.01 and <0.05", ">10 and <=20", ">=0.30 and <0.50",
      ">0.10 and <=0.20", ">=0.90 and <0.95",
      ">=0.10 and <0.20"
    ),
    stop_rule = c(
      "<=0.01", ">20", "<0.30", ">0.20", "<0.90", ">=0.20"
    ),
    m100_trigger = c(rep(FALSE, 5L), TRUE),
    stringsAsFactors = FALSE
  )
}

build_components <- function() {
  spec <- yaml::read_yaml(paths$spec)
  gate <- yaml::read_yaml(paths$gate)
  stage3_ok <-
    identical(gate$stage3_production_mi_freeze$status, "PASS") &&
    identical(
      gate$stage3_production_mi_execution$status,
      "INDEPENDENT_VALIDATION_PASS"
    ) &&
    identical(
      gate$stage3_production_mi_independent_validation$status,
      "INDEPENDENT_VALIDATION_PASS"
    ) &&
    gate_no(gate$outcome_execution_allowed) &&
    gate_no(gate$new_mortality_coefficient_inspection_allowed)
  if (!stage3_ok) {
    stop("Stage 3 gates do not authorize the Stage 4 freeze.",
         call. = FALSE)
  }
  packages <- c("mice", "survey", "survival", "rspiro")
  expected_versions <- unlist(spec$runtime[
    paste0(packages, "_version")
  ], use.names = FALSE)
  observed_versions <- vapply(
    packages,
    function(pkg) as.character(utils::packageVersion(pkg)),
    character(1)
  )
  if (!identical(unname(observed_versions), unname(expected_versions)) ||
      !identical(as.character(getRversion()), spec$runtime$R_version)) {
    stop("Stage 4 runtime versions drifted.", call. = FALSE)
  }
  code <- build_code_manifest()
  functions <- build_function_manifest()
  inputs <- build_input_manifest(spec)
  registry <- v45_outcome_model_registry()
  thresholds <- threshold_registry(spec)
  self_test <- v45_outcome_static_self_test()
  v43 <- v45_load_v43_nhanes_functions(root)
  anchor_formula_ok <- all(vapply(c("A0", "A1", "A2"), function(tier) {
    identical(
      paste(deparse(v45_outcome_formula("E0", tier)), collapse = " "),
      paste(deparse(v43$model_formulas("E0")[[tier]]), collapse = " ")
    )
  }, logical(1)))
  registered <- read_tsv(
    file.path(root, "work_v45", "v45_analysis_registry.tsv")
  )
  registry_ok <-
    !anyDuplicated(registry$analysis_id) &&
    all(registry$analysis_id %in% registered$analysis_id) &&
    all(
      registered$status[
        match(registry$analysis_id, registered$analysis_id)
      ] == "FROZEN_NOT_RUN"
    )
  rw <- readRDS(file.path(
    root, "derived_sensitive", "v45",
    "v45_rao_wu_replicate_contract.rds"
  ))
  rw_ok <-
    identical(dim(rw$modules[["RW-GLI"]]$matrix), c(94L, 500L)) &&
    identical(dim(rw$modules[["RW-IPW"]]$matrix), c(94L, 500L)) &&
    identical(as.numeric(rw$modules[["RW-GLI"]]$scale), 1 / 499) &&
    identical(as.numeric(rw$modules[["RW-IPW"]]$scale), 1 / 499) &&
    isTRUE(rw$modules[["RW-GLI"]]$mse) &&
    isTRUE(rw$modules[["RW-IPW"]]$mse)
  checks <- data.frame(
    check = c(
      "stage3_independent_validation_gate",
      "runtime_versions",
      "code_assets_complete",
      "function_manifest_complete",
      "input_assets_and_mids_hashes",
      "registered_analysis_alignment",
      "static_formula_self_test",
      "exact_v43_anchor_formula_equivalence",
      "frozen_Rao_Wu_contract",
      "coefficient_generation_count",
      "coefficient_export_count"
    ),
    status = c(
      if (stage3_ok) "PASS" else "FAIL",
      "PASS",
      if (
        nrow(code) == 14L &&
        all(is.finite(code$bytes) & code$bytes > 0) &&
        all(grepl("^[0-9a-f]{64}$", code$sha256))
      ) "PASS" else "FAIL",
      if (
        nrow(functions) >= 30L &&
        !anyDuplicated(functions$asset_id) &&
        all(grepl("^[0-9a-f]{64}$", functions$sha256))
      ) "PASS" else "FAIL",
      if (
        nrow(inputs) == 14L &&
        !anyDuplicated(inputs$asset_id) &&
        all(inputs$status == "PASS") &&
        all(grepl("^[0-9a-f]{64}$", inputs$sha256))
      ) "PASS" else "FAIL",
      if (registry_ok) "PASS" else "FAIL",
      if (all(self_test$status == "PASS") &&
          nrow(self_test) == 10L) "PASS" else "FAIL",
      if (anchor_formula_ok) "PASS" else "FAIL",
      if (rw_ok) "PASS" else "FAIL",
      "PASS",
      "PASS"
    ),
    observed = c(
      "Stage 3 freeze/execution/independent validation PASS",
      paste(names(observed_versions), observed_versions, collapse = "; "),
      paste0(nrow(code), " assets"),
      paste0(nrow(functions), " functions"),
      paste0(nrow(inputs), " immutable inputs"),
      paste0(nrow(registry), " registered analyses"),
      paste0(sum(self_test$status == "PASS"), "/", nrow(self_test)),
      as.character(anchor_formula_ok),
      paste0(
        "RW-GLI/RW-IPW=",
        paste(dim(rw$modules[["RW-GLI"]]$matrix), collapse = "x"),
        "/",
        paste(dim(rw$modules[["RW-IPW"]]$matrix), collapse = "x")
      ),
      "0",
      "0"
    ),
    expected = c(
      "all Stage 3 gates PASS and coefficient gates closed",
      "R 4.5.1; mice 3.19.0; survey 4.5; survival 3.8.3; rspiro 0.5",
      "14 immutable code/specification assets",
      "complete v45 outcome and v43 formula helper closure",
      "14 immutable inputs including 3 exact m=50 objects",
      "18 frozen registered analyses",
      "10/10 PASS",
      "A0/A1/A2 deparse-identical to authoritative v43",
      "two 94x500 matrices; mse=true; scale=1/499",
      "0",
      "0"
    ),
    stringsAsFactors = FALSE
  )
  if (any(checks$status != "PASS")) {
    stop(
      "Stage 4 freeze checks failed: ",
      paste(checks$check[checks$status != "PASS"], collapse = ", "),
      call. = FALSE
    )
  }
  roots <- data.frame(
    root_id = c(
      "stage4_outcome_code_root",
      "stage4_outcome_function_root",
      "stage4_outcome_input_root",
      "stage4_outcome_model_registry_root",
      "stage4_outcome_threshold_registry_root"
    ),
    sha256 = c(
      manifest_root(
        code, "asset_id",
        c("asset_id", "path_alias", "bytes", "sha256", "immutable")
      ),
      manifest_root(
        functions, "asset_id",
        c("asset_id", "function_name", "source", "sha256", "hash_rule")
      ),
      manifest_root(
        inputs, "asset_id",
        c(
          "asset_id", "object_id", "path_alias", "bytes", "sha256",
          "local_restricted", "status"
        )
      ),
      manifest_root(
        registry, "analysis_id",
        names(registry)
      ),
      manifest_root(
        thresholds, "metric",
        names(thresholds)
      )
    ),
    stringsAsFactors = FALSE
  )
  contract <- list(
    contract_version = "v45_0_stage4",
    created_at_utc = format(
      Sys.time(), tz = "UTC", format = "%Y-%m-%dT%H:%M:%SZ"
    ),
    coefficient_generation_count = 0L,
    coefficient_export_count = 0L,
    code_root_sha256 = roots$sha256[
      roots$root_id == "stage4_outcome_code_root"
    ],
    function_root_sha256 = roots$sha256[
      roots$root_id == "stage4_outcome_function_root"
    ],
    input_root_sha256 = roots$sha256[
      roots$root_id == "stage4_outcome_input_root"
    ],
    model_registry_root_sha256 = roots$sha256[
      roots$root_id == "stage4_outcome_model_registry_root"
    ],
    threshold_registry_root_sha256 = roots$sha256[
      roots$root_id == "stage4_outcome_threshold_registry_root"
    ],
    model_registry = registry,
    threshold_registry = thresholds,
    mids = inputs[grepl("^mids_", inputs$asset_id), ],
    rao_wu_contract_sha256 = inputs$sha256[
      inputs$path_alias ==
        "derived_sensitive/v45/v45_rao_wu_replicate_contract.rds"
    ],
    full_mec = list(n = 29353L, strata = 45L, psu = 94L, df = 49L),
    release_gate = list(
      outcome_execution_allowed = TRUE,
      new_mortality_coefficient_inspection_allowed = FALSE
    )
  )
  list(
    code = code, functions = functions, inputs = inputs,
    registry = registry, thresholds = thresholds, roots = roots,
    contract = contract, checks = checks
  )
}

verify_mode <- "--verify" %in% commandArgs(trailingOnly = TRUE)

if (verify_mode) {
  required <- unlist(paths[c(
    "code", "functions", "inputs", "registry", "thresholds",
    "roots", "contract", "validation", "output_manifest"
  )])
  invisible(lapply(required, assert_regular, label = "Stage 4 freeze output"))
  recorded <- list(
    code = read_tsv(paths$code),
    functions = read_tsv(paths$functions),
    inputs = read_tsv(paths$inputs),
    registry = read_tsv(paths$registry),
    thresholds = read_tsv(paths$thresholds),
    roots = read_tsv(paths$roots)
  )
  current_code <- build_code_manifest()
  code_equal <-
    identical(names(recorded$code), names(current_code)) &&
    nrow(recorded$code) == nrow(current_code) &&
    identical(recorded$code$asset_id, current_code$asset_id) &&
    identical(recorded$code$path_alias, current_code$path_alias) &&
    identical(
      as.numeric(recorded$code$bytes),
      as.numeric(current_code$bytes)
    ) &&
    identical(recorded$code$sha256, current_code$sha256) &&
    identical(
      as.logical(recorded$code$immutable),
      as.logical(current_code$immutable)
    ) &&
    identical(
      recorded$code$authorized_purpose,
      current_code$authorized_purpose
    )
  if (!code_equal) {
    stop("Stage 4 code manifest no longer verifies.", call. = FALSE)
  }
  if (any(!vapply(seq_len(nrow(recorded$inputs)), function(i) {
    path <- file.path(root, recorded$inputs$path_alias[[i]])
    file.exists(path) &&
      identical(
        v45_sha256_file(path), recorded$inputs$sha256[[i]]
      )
  }, logical(1)))) {
    stop("Stage 4 input manifest no longer verifies.", call. = FALSE)
  }
  current_roots <- c(
    manifest_root(
      recorded$code, "asset_id",
      c("asset_id", "path_alias", "bytes", "sha256", "immutable")
    ),
    manifest_root(
      recorded$functions, "asset_id",
      c("asset_id", "function_name", "source", "sha256", "hash_rule")
    ),
    manifest_root(
      recorded$inputs, "asset_id",
      c(
        "asset_id", "object_id", "path_alias", "bytes", "sha256",
        "local_restricted", "status"
      )
    ),
    manifest_root(recorded$registry, "analysis_id", names(recorded$registry)),
    manifest_root(recorded$thresholds, "metric", names(recorded$thresholds))
  )
  if (!identical(unname(recorded$roots$sha256), unname(current_roots))) {
    stop("Stage 4 freeze roots no longer verify.", call. = FALSE)
  }
  contract <- readRDS(paths$contract)
  if (
    !identical(contract$code_root_sha256, current_roots[[1L]]) ||
    !identical(contract$function_root_sha256, current_roots[[2L]]) ||
    !identical(contract$input_root_sha256, current_roots[[3L]]) ||
    !identical(contract$model_registry_root_sha256, current_roots[[4L]]) ||
    !identical(contract$threshold_registry_root_sha256, current_roots[[5L]]) ||
    contract$coefficient_generation_count != 0L ||
    contract$coefficient_export_count != 0L
  ) {
    stop("Stage 4 restricted contract no longer verifies.", call. = FALSE)
  }
  gate <- yaml::read_yaml(paths$gate)
  semantic_state_ok <- (
    gate_yes(gate$outcome_execution_allowed) &&
      gate_no(gate$new_mortality_coefficient_inspection_allowed)
  ) || (
    gate_no(gate$outcome_execution_allowed) &&
      (
        gate_yes(gate$new_mortality_coefficient_inspection_allowed) ||
          gate_no(gate$new_mortality_coefficient_inspection_allowed)
      ) &&
      !is.null(gate$stage4_nhanes_outcome_execution$status)
  )
  if (
    !identical(gate$stage4_nhanes_outcome_freeze$status, "PASS") ||
    !semantic_state_ok
  ) {
    stop("Stage 4 semantic gate no longer verifies.", call. = FALSE)
  }
  cat("V45_STAGE4_NHANES_OUTCOME_FREEZE_VERIFY_PASS\n")
  quit(save = "no", status = 0L)
}

existing <- unlist(paths[c(
  "code", "functions", "inputs", "registry", "thresholds",
  "roots", "contract", "validation", "output_manifest"
)])
if (any(file.exists(existing))) {
  stop(
    "Stage 4 freeze outputs already exist; use --verify or archive first: ",
    paste(existing[file.exists(existing)], collapse = "; "),
    call. = FALSE
  )
}

components <- build_components()
v45_atomic_write_tsv(components$code, paths$code)
v45_atomic_write_tsv(components$functions, paths$functions)
v45_atomic_write_tsv(components$inputs, paths$inputs)
v45_atomic_write_tsv(components$registry, paths$registry)
v45_atomic_write_tsv(components$thresholds, paths$thresholds)
v45_atomic_write_tsv(components$roots, paths$roots)
v45_atomic_save_rds(components$contract, paths$contract)
v45_atomic_write_tsv(components$checks, paths$validation)

gate <- yaml::read_yaml(paths$gate)
freeze_id <- paste0(
  "v45_stage4_outcome_freeze_",
  format(Sys.time(), "%Y%m%dT%H%M%S"), "_pid", Sys.getpid()
)
gate$updated_at <- format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")
gate$stage4_nhanes_outcome_freeze <- list(
  status = "PASS",
  freeze_id = freeze_id,
  code_root_sha256 = components$contract$code_root_sha256,
  input_root_sha256 = components$contract$input_root_sha256,
  coefficient_generation_count = 0L,
  coefficient_export_count = 0L
)
gate$outcome_execution_allowed <- "yes"
gate$new_mortality_coefficient_inspection_allowed <- "no"
gate$production_m50_objects_allowed <- "no"
gate$production_m100_objects_allowed <- "no"
gate$next_authorized_step <- "run_NHANES_outcome_restricted_m50"
v45_atomic_write_yaml(gate, paths$gate)

output_aliases <- c(
  code = "work_v45/v45_outcome_code_manifest.tsv",
  functions = "work_v45/v45_outcome_function_manifest.tsv",
  inputs = "work_v45/v45_outcome_input_manifest.tsv",
  registry = "work_v45/v45_outcome_model_registry.tsv",
  thresholds = "work_v45/v45_outcome_threshold_registry.tsv",
  roots = "work_v45/v45_outcome_freeze_roots.tsv",
  contract =
    "derived_sensitive/v45/v45_nhanes_outcome_execution_contract.rds",
  validation = "results/v45/v45_nhanes_outcome_freeze_validation.tsv"
)
output_manifest <- dplyr::bind_rows(lapply(
  names(output_aliases), function(id) {
    alias <- output_aliases[[id]]
    path <- file.path(root, alias)
    data.frame(
      asset_id = id,
      path_alias = alias,
      bytes = as.numeric(file.info(path)$size),
      sha256 = v45_sha256_file(path),
      local_restricted = grepl("^derived_sensitive/", alias),
      stringsAsFactors = FALSE
    )
  }
))
v45_atomic_write_tsv(output_manifest, paths$output_manifest)

cat("V45_STAGE4_NHANES_OUTCOME_FREEZE_PASS\n")
cat("freeze_id=", freeze_id, "\n", sep = "")
cat("registered_analyses=", nrow(components$registry), "\n", sep = "")
cat("coefficient_generation_count=0\n")
cat("coefficient_export_count=0\n")
