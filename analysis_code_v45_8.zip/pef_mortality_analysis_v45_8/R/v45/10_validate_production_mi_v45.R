#!/usr/bin/env Rscript

# v45 Stage 3 independent, read-only production-MI validation.
#
# This script does not generate imputations, consume random numbers, fit an
# outcome model, or release coefficients.  It validates the three restricted
# m=50 mids objects against the frozen Stage 3 contract and promotes their
# pointers only after every independent check passes.

options(stringsAsFactors = FALSE, warn = 2)

stage3_root <- function() {
  args <- commandArgs(trailingOnly = FALSE)
  file_arg <- grep("^--file=", args, value = TRUE)
  if (!length(file_arg)) return(normalizePath(getwd(), mustWork = TRUE))
  script <- sub("^--file=", "", file_arg[[1L]])
  normalizePath(file.path(dirname(script), "..", ".."), mustWork = TRUE)
}

iv_stop <- function(...) stop(..., call. = FALSE)

iv_require <- function(packages) {
  missing <- packages[
    !vapply(packages, requireNamespace, logical(1), quietly = TRUE)
  ]
  if (length(missing)) {
    iv_stop(
      "Independent validator package runtime is incomplete: ",
      paste(missing, collapse = ", ")
    )
  }
  invisible(TRUE)
}

iv_sha256_file <- function(path) {
  if (length(path) != 1L || is.na(path) || !file.exists(path) ||
      dir.exists(path)) {
    iv_stop("Cannot hash required regular file: ", path)
  }
  digest::digest(file = path, algo = "sha256")
}

iv_scalar_character <- function(x, label) {
  if (!is.character(x) || length(x) != 1L || is.na(x) || !nzchar(x)) {
    iv_stop(label, " must be one non-empty character value.")
  }
  x
}

iv_safe_alias <- function(root, alias, allowed_prefix, regular_file = TRUE) {
  alias <- iv_scalar_character(alias, "Path alias")
  if (grepl("^(/|~|[A-Za-z]:)", alias) ||
      any(strsplit(alias, "/", fixed = TRUE)[[1L]] %in% c("", ".", ".."))) {
    iv_stop("Unsafe path alias: ", alias)
  }
  prefix <- normalizePath(
    file.path(root, allowed_prefix), mustWork = TRUE
  )
  path <- normalizePath(file.path(root, alias), mustWork = TRUE)
  if (!startsWith(path, paste0(prefix, .Platform$file.sep))) {
    iv_stop("Path alias escapes its frozen directory: ", alias)
  }
  if (regular_file && (!file.exists(path) || dir.exists(path))) {
    iv_stop("Expected a regular file: ", alias)
  }
  if (!regular_file && !dir.exists(path)) {
    iv_stop("Expected a directory: ", alias)
  }
  path
}

iv_read_tsv_stable <- function(
    path, exact_names = NULL, exact_rows = NULL, label = basename(path)) {
  before <- iv_sha256_file(path)
  bytes_before <- as.numeric(file.info(path)$size)
  value <- utils::read.delim(
    path, stringsAsFactors = FALSE, check.names = FALSE,
    na.strings = c("", "NA")
  )
  after <- iv_sha256_file(path)
  bytes_after <- as.numeric(file.info(path)$size)
  if (!identical(before, after) ||
      !identical(bytes_before, bytes_after)) {
    iv_stop(label, " changed while it was read.")
  }
  if (!is.null(exact_names) && !identical(names(value), exact_names)) {
    iv_stop(
      label, " schema differs. Observed: ", paste(names(value), collapse = "|")
    )
  }
  if (!is.null(exact_rows) && nrow(value) != exact_rows) {
    iv_stop(label, " must contain exactly ", exact_rows, " row(s).")
  }
  list(data = value, sha256 = before, bytes = bytes_before)
}

iv_read_rds_stable <- function(path, label = basename(path)) {
  before <- iv_sha256_file(path)
  bytes_before <- as.numeric(file.info(path)$size)
  value <- readRDS(path)
  after <- iv_sha256_file(path)
  bytes_after <- as.numeric(file.info(path)$size)
  if (!identical(before, after) ||
      !identical(bytes_before, bytes_after)) {
    iv_stop(label, " changed while it was read.")
  }
  list(data = value, sha256 = before, bytes = bytes_before)
}

iv_atomic_write_tsv <- function(data, path) {
  dir.create(dirname(path), recursive = TRUE, showWarnings = FALSE)
  temporary <- tempfile(
    pattern = paste0(".", basename(path), "."), tmpdir = dirname(path)
  )
  on.exit(if (file.exists(temporary)) unlink(temporary), add = TRUE)
  utils::write.table(
    data, temporary, sep = "\t", quote = FALSE,
    row.names = FALSE, col.names = TRUE, na = "", fileEncoding = "UTF-8"
  )
  if (!file.rename(temporary, path)) {
    iv_stop("Could not atomically publish TSV: ", path)
  }
  invisible(path)
}

iv_atomic_write_lines <- function(lines, path) {
  dir.create(dirname(path), recursive = TRUE, showWarnings = FALSE)
  temporary <- tempfile(
    pattern = paste0(".", basename(path), "."), tmpdir = dirname(path)
  )
  on.exit(if (file.exists(temporary)) unlink(temporary), add = TRUE)
  writeLines(enc2utf8(lines), temporary, useBytes = TRUE)
  if (!file.rename(temporary, path)) {
    iv_stop("Could not atomically publish text: ", path)
  }
  invisible(path)
}

iv_atomic_write_yaml <- function(value, path) {
  dir.create(dirname(path), recursive = TRUE, showWarnings = FALSE)
  temporary <- tempfile(
    pattern = paste0(".", basename(path), "."), tmpdir = dirname(path)
  )
  on.exit(if (file.exists(temporary)) unlink(temporary), add = TRUE)
  yaml::write_yaml(value, temporary)
  if (!file.rename(temporary, path)) {
    iv_stop("Could not atomically publish YAML: ", path)
  }
  invisible(path)
}

iv_assert_exact_names <- function(value, expected, label) {
  if (!identical(names(value), expected)) {
    iv_stop(
      label, " names differ. Observed: ", paste(names(value), collapse = "|")
    )
  }
  invisible(TRUE)
}

iv_check_scalar_equal <- function(observed, expected, label) {
  if (length(observed) != 1L || is.na(observed) ||
      !identical(as.character(observed), as.character(expected))) {
    iv_stop(
      label, " differs: observed=", paste(observed, collapse = "|"),
      "; expected=", paste(expected, collapse = "|")
    )
  }
  invisible(TRUE)
}

iv_manifest_root <- function(data, key, fields) {
  data <- data[order(data[[key]]), fields, drop = FALSE]
  records <- apply(data, 1L, function(row) paste(row, collapse = "\u241f"))
  digest::digest(
    paste(records, collapse = "\n"), algo = "sha256", serialize = FALSE
  )
}

iv_validate_frozen_manifests <- function(root) {
  code_path <- file.path(
    root, "work_v45", "v45_production_mi_code_manifest.tsv"
  )
  function_path <- file.path(
    root, "work_v45", "v45_production_mi_function_manifest.tsv"
  )
  roots_path <- file.path(
    root, "work_v45", "v45_production_mi_freeze_roots.tsv"
  )
  code <- iv_read_tsv_stable(
    code_path,
    c(
      "asset_id", "path_private", "path_alias", "exists", "bytes",
      "sha256", "immutable", "authorized_purpose"
    )
  )
  functions <- iv_read_tsv_stable(
    function_path,
    c("asset_id", "function_name", "source", "sha256", "hash_rule")
  )
  roots <- iv_read_tsv_stable(
    roots_path, c("root_id", "sha256")
  )
  if (!nrow(code$data) || anyDuplicated(code$data$asset_id) ||
      anyDuplicated(code$data$path_alias) ||
      !nrow(functions$data) || anyDuplicated(functions$data$asset_id) ||
      anyDuplicated(functions$data$function_name) ||
      !nrow(roots$data) || anyDuplicated(roots$data$root_id) ||
      any(!grepl("^[0-9a-f]{64}$", c(
        code$data$sha256, functions$data$sha256, roots$data$sha256
      )))) {
    iv_stop("Stage 3 code/function/root manifest structure is invalid.")
  }
  required_code <- c(
    "work_v45/production_mi_spec_v45.yml",
    "work_v45/v45_analysis_registry.tsv",
    "work_v45/v45_estimand_registry.tsv",
    "work_v45/v45_production_mi_decision_log.md",
    "work_v45/v45_stage3_mi_amendment_log.md",
    "derived_sensitive/v45/v45_mi_object_definitions_v45.rds",
    "R/v45/01_nhanes_common_utilities_v45.R",
    "R/v45/02_gli_functions_v45.R",
    "R/v45/legacy_gli_reference_pure_v45.R",
    "R/v45/production_mi_hashes_v45.R",
    "R/v45/08_freeze_production_mi_v45.R",
    "R/v45/09_run_production_mi_v45.R",
    "R/v45/independent_mi_validation_helpers_v45.R"
    ,"R/v45/10_validate_production_mi_v45.R",
    paste0(
      "output/code_archive/PEF_mortality_v44_2_code_candidate/",
      "R/v43/05_nhanes_stage3_primary_mortality.R"
    ),
    "R/nhanes/07_nhanes_v0_5_gli_lln_prism_lock.R"
  )
  if (!setequal(required_code, code$data$path_alias)) {
    iv_stop("Stage 3 code manifest differs from the exact asset whitelist.")
  }
  code_hashes_after <- vapply(seq_len(nrow(code$data)), function(index) {
    alias <- code$data$path_alias[[index]]
    path <- iv_safe_alias(root, alias, dirname(alias), regular_file = TRUE)
    if (!isTRUE(code$data$exists[[index]]) ||
        !isTRUE(code$data$immutable[[index]]) ||
        !identical(
          as.numeric(file.info(path)$size),
          as.numeric(code$data$bytes[[index]])
        ) ||
        !identical(
          normalizePath(path, mustWork = TRUE),
          normalizePath(code$data$path_private[[index]], mustWork = TRUE)
        )) {
      iv_stop("Stage 3 code-manifest metadata mismatch: ", alias)
    }
    iv_sha256_file(path)
  }, character(1))
  if (!identical(
        unname(code_hashes_after), unname(as.character(code$data$sha256))
      )) {
    iv_stop("A Stage 3 frozen code/specification asset changed.")
  }
  required_functions <- c(
    "run_mi_convergence_schedule", "mice_chain_convergence",
    "v45_compute_gli", "v45_validate_gli_against_pure_reference"
  )
  if (!all(required_functions %in% functions$data$function_name)) {
    iv_stop("Stage 3 function manifest lacks a required function.")
  }
  allowed_function_sources <- c(
    paste0(
      "output/code_archive/PEF_mortality_v44_2_code_candidate/",
      "R/v43/05_nhanes_stage3_primary_mortality.R"
    ),
    "R/v45/01_nhanes_common_utilities_v45.R",
    "R/v45/02_gli_functions_v45.R",
    "R/v45/legacy_gli_reference_pure_v45.R",
    "R/v45/production_mi_hashes_v45.R"
  )
  if (!all(functions$data$source %in% allowed_function_sources) ||
      !all(
        functions$data$asset_id ==
          paste0(
            ifelse(
              startsWith(functions$data$source, "output/"), "v43::", "v45::"
            ),
            functions$data$function_name
          )
      )) {
    iv_stop("Stage 3 function-manifest source binding is invalid.")
  }
  input_summary <- iv_read_tsv_stable(
    file.path(root, "results", "v45", "v45_production_mi_input_contracts.tsv"),
    c(
      "object_id", "denominator_n", "event_anchor_n", "response_anchor_n",
      "input_column_n", "active_target_n", "imputed_cell_n_per_chain",
      "seed", "canonical_data_sha256", "column_contract_sha256",
      "missing_contract_sha256", "ordered_id_sha256",
      "specification_sha256", "specification_sha256_canonical",
      "method_sha256", "predictor_matrix_sha256", "where_sha256",
      "visit_sequence_sha256", "status"
    ),
    3L, "Stage 3 input summary"
  )
  freeze_validation_path <- file.path(
    root, "results", "v45", "v45_production_mi_freeze_validation.tsv"
  )
  freeze_validation <- iv_read_tsv_stable(
    freeze_validation_path,
    c("check", "status", "detail", "freeze_id", "frozen_at_utc"),
    6L, "Stage 3 freeze validation"
  )
  if (anyDuplicated(freeze_validation$data$check) ||
      !all(freeze_validation$data$status == "PASS")) {
    iv_stop("Stage 3 freeze-validation table no longer passes.")
  }
  expected_root_ids <- c(
    "stage3_production_mi_code_root",
    "stage3_production_mi_function_root",
    "stage3_production_mi_input_root",
    "stage0_1_input_root", "stage0_1_code_root", "stage0_1_runtime_root",
    "stage2_code_root", "stage2_survey_function_root",
    "stage2_validated_output_root",
    "stage3_production_mi_freeze_validation_file"
  )
  if (!setequal(roots$data$root_id, expected_root_ids)) {
    iv_stop("Stage 3 freeze-root set is incomplete.")
  }
  root_values <- setNames(roots$data$sha256, roots$data$root_id)
  independent_roots <- c(
    stage3_production_mi_code_root = iv_manifest_root(
      code$data, "asset_id",
      c("asset_id", "path_alias", "bytes", "sha256", "immutable")
    ),
    stage3_production_mi_function_root = iv_manifest_root(
      functions$data, "asset_id",
      c("asset_id", "function_name", "source", "sha256")
    ),
    stage3_production_mi_input_root = iv_manifest_root(
      input_summary$data, "object_id",
      c(
        "object_id", "denominator_n", "event_anchor_n",
        "response_anchor_n", "input_column_n", "active_target_n",
        "imputed_cell_n_per_chain", "seed", "canonical_data_sha256",
        "column_contract_sha256", "missing_contract_sha256",
        "ordered_id_sha256", "specification_sha256", "method_sha256",
        "specification_sha256_canonical", "predictor_matrix_sha256",
        "where_sha256", "visit_sequence_sha256", "status"
      )
    ),
    stage3_production_mi_freeze_validation_file = freeze_validation$sha256
  )
  if (!identical(
        unname(root_values[names(independent_roots)]),
        unname(independent_roots)
      )) {
    iv_stop("Stage 3 independently recomputed freeze roots differ.")
  }
  stage01 <- iv_read_tsv_stable(
    file.path(root, "work_v45", "v45_freeze_roots.tsv"),
    c("root_id", "sha256", "freeze_id", "frozen_at_utc")
  )
  stage2 <- iv_read_tsv_stable(
    file.path(root, "work_v45", "v45_rao_wu_freeze_roots.tsv"),
    c("root_id", "sha256", "freeze_id", "frozen_at_utc")
  )
  stage01_values <- setNames(stage01$data$sha256, stage01$data$root_id)
  stage2_values <- setNames(stage2$data$sha256, stage2$data$root_id)
  parent_expected <- c(
    stage0_1_input_root = stage01_values[["input_manifest_root"]],
    stage0_1_code_root = stage01_values[["code_manifest_root"]],
    stage0_1_runtime_root = stage01_values[["runtime_manifest_root"]],
    stage2_code_root = stage2_values[["stage2_code_root"]],
    stage2_survey_function_root =
      stage2_values[["stage2_survey_function_root"]]
  )
  parent_recorded <- c(
    stage0_1_input_root = root_values[["stage0_1_input_root"]],
    stage0_1_code_root = root_values[["stage0_1_code_root"]],
    stage0_1_runtime_root = root_values[["stage0_1_runtime_root"]],
    stage2_code_root = root_values[["stage2_code_root"]],
    stage2_survey_function_root =
      root_values[["stage2_survey_function_root"]]
  )
  if (anyNA(parent_expected) ||
      !identical(unname(parent_recorded), unname(parent_expected))) {
    iv_stop("Stage 3 parent Stage-0/2 roots differ.")
  }
  stage2_output <- iv_read_tsv_stable(
    file.path(root, "results", "v45", "v45_rao_wu_output_manifest.tsv"),
    c("asset_id", "path_alias", "bytes", "sha256", "local_restricted")
  )
  required_stage2_assets <- c(
    "code", "functions", "roots", "validation", "contracts",
    "structural", "interfaces", "contract", "log",
    "independent_validation", "qa_report"
  )
  if (anyDuplicated(stage2_output$data$asset_id) ||
      !setequal(stage2_output$data$asset_id, required_stage2_assets)) {
    iv_stop("Stage 2 validated-output manifest is malformed.")
  }
  stage2_asset_paths <- character(nrow(stage2_output$data))
  for (index in seq_len(nrow(stage2_output$data))) {
    alias <- stage2_output$data$path_alias[[index]]
    path <- iv_safe_alias(root, alias, dirname(alias), regular_file = TRUE)
    stage2_asset_paths[[index]] <- path
    if (!identical(
          as.numeric(file.info(path)$size),
          as.numeric(stage2_output$data$bytes[[index]])
        ) ||
        !identical(
          iv_sha256_file(path), stage2_output$data$sha256[[index]]
        )) {
      iv_stop("Stage 2 validated output changed: ", alias)
    }
  }
  stage2_validation <- iv_read_tsv_stable(
    file.path(root, "results", "v45",
              "v45_rao_wu_independent_validation.tsv"),
    c("check", "status", "detail", "validated_at_utc"), 8L
  )
  if (anyDuplicated(stage2_validation$data$check) ||
      !all(stage2_validation$data$status == "PASS")) {
    iv_stop("Stage 2 independent validation no longer passes.")
  }
  stage2_output_root <- iv_manifest_root(
    stage2_output$data, "asset_id",
    c("asset_id", "path_alias", "bytes", "sha256", "local_restricted")
  )
  if (!identical(
        root_values[["stage2_validated_output_root"]],
        stage2_output_root
      )) {
    iv_stop("Stage 2 validated-output root differs.")
  }
  stable_files <- c(
    setNames(code$sha256, code_path),
    setNames(functions$sha256, function_path),
    setNames(roots$sha256, roots_path),
    setNames(input_summary$sha256, file.path(
      root, "results", "v45", "v45_production_mi_input_contracts.tsv"
    )),
    setNames(freeze_validation$sha256, freeze_validation_path),
    setNames(stage01$sha256, file.path(
      root, "work_v45", "v45_freeze_roots.tsv"
    )),
    setNames(stage2$sha256, file.path(
      root, "work_v45", "v45_rao_wu_freeze_roots.tsv"
    )),
    setNames(stage2_output$sha256, file.path(
      root, "results", "v45", "v45_rao_wu_output_manifest.tsv"
    )),
    setNames(stage2_validation$sha256, file.path(
      root, "results", "v45", "v45_rao_wu_independent_validation.tsv"
    )),
    setNames(as.character(stage2_output$data$sha256), stage2_asset_paths)
  )
  duplicate_stable <- unique(
    names(stable_files)[duplicated(names(stable_files))]
  )
  if (length(duplicate_stable) && any(vapply(
        duplicate_stable,
        function(path) {
          length(unique(stable_files[names(stable_files) == path])) != 1L
        },
        logical(1)
      ))) {
    iv_stop("Frozen-manifest stable-file ledger conflicts.")
  }
  stable_files <- stable_files[!duplicated(names(stable_files))]
  list(
    code = code, functions = functions, roots = roots,
    stable_files = stable_files
  )
}

iv_pointer_schema <- c(
  "object_id", "requested_m", "run_id", "run_manifest_path_alias",
  "mids_path_alias", "mids_sha256", "status"
)

iv_run_manifest_schema <- c(
  "run_id", "object_id", "requested_m", "selected_maxit",
  "elapsed_seconds", "denominator_n", "event_anchor_n",
  "response_anchor_n", "hard_convergence_rows",
  "failed_hard_convergence_rows", "warning_count",
  "logged_event_count", "mortality_model_fit_count",
  "coefficient_export_count", "completed_dataset_persistence_count",
  "mids_path_alias", "mids_bytes", "mids_sha256",
  "result_path_alias", "status", "completed_at_utc"
)

iv_component_schema <- c("component", "sha256", "hash_rule")

iv_required_components <- c(
  "canonical_source_input_data",
  "canonical_column_types_factor_levels_and_ordered_flags",
  "canonical_frozen_specification",
  "canonical_ordered_participant_ids",
  "canonical_imputation_payload", "canonical_chain_mean",
  "canonical_chain_variance", "canonical_categorical_trace",
  "canonical_final_convergence", "canonical_checkpoint_diagnostics",
  "canonical_released_trace", "mids_method", "mids_predictor_matrix",
  "mids_where", "mids_visit_sequence", "mids_last_seed_value",
  "final_mids_file"
)

iv_standard_mids_names <- c(
  "data", "imp", "m", "where", "blocks", "call", "nmis", "method",
  "predictorMatrix", "visitSequence", "formulas", "calltype", "post", "blots",
  "ignore", "seed", "iteration", "lastSeedValue", "chainMean",
  "chainVar", "loggedEvents", "version", "date"
)

iv_load_object_files <- function(root, object_id) {
  object_token <- gsub("-", "_", object_id, fixed = TRUE)
  pointer_path <- file.path(
    root, "results", "v45", "production_mi",
    paste0(object_token, "_m50_current.tsv")
  )
  pointer <- iv_read_tsv_stable(
    pointer_path, iv_pointer_schema, 1L,
    paste0(object_id, " pointer")
  )
  p <- pointer$data
  if (!identical(as.character(p$object_id), object_id) ||
      !identical(as.integer(p$requested_m), 50L) ||
      !grepl(
        paste0("^v45_", tolower(gsub("-", "", object_id)), "_m50_"),
        p$run_id
      ) ||
      !p$status %in% c(
        "GENERATED_AWAITING_INDEPENDENT_VALIDATION",
        "INDEPENDENT_VALIDATION_PASS"
      ) ||
      !grepl("^[0-9a-f]{64}$", p$mids_sha256)) {
    iv_stop(object_id, " pointer values are invalid.")
  }
  run_id <- as.character(p$run_id)
  expected_result_alias <- file.path(
    "results", "v45", "production_mi", object_id, "m50", run_id
  )
  expected_private_alias <- file.path(
    "derived_sensitive", "v45", "production_mi", object_id, "m50",
    run_id, paste0(object_id, "_m50.mids.rds")
  )
  expected_manifest_alias <- file.path(
    expected_result_alias, "run_manifest.tsv"
  )
  if (!identical(p$run_manifest_path_alias, expected_manifest_alias) ||
      !identical(p$mids_path_alias, expected_private_alias)) {
    iv_stop(object_id, " pointer path aliases differ from the frozen layout.")
  }
  result_dir <- iv_safe_alias(
    root, expected_result_alias,
    file.path("results", "v45", "production_mi", object_id, "m50"),
    regular_file = FALSE
  )
  mids_path <- iv_safe_alias(
    root, expected_private_alias,
    file.path("derived_sensitive", "v45", "production_mi", object_id, "m50"),
    regular_file = TRUE
  )
  expected_result_files <- c(
    "run_manifest.tsv", "component_hashes.tsv", "structural_checks.tsv",
    "checkpoint_diagnostics.tsv", "final_convergence.tsv",
    "released_chain_trace.tsv", "passive_bmi_audit.tsv", "run.log"
  )
  if (identical(object_id, "MI-G")) {
    expected_result_files <- c(
      expected_result_files, "passive_gli_audit.tsv",
      "passive_gli_hashes.tsv"
    )
  }
  observed_result_files <- list.files(
    result_dir, all.files = TRUE, no.. = TRUE, recursive = FALSE
  )
  if (!setequal(observed_result_files, expected_result_files) ||
      any(file.info(file.path(result_dir, observed_result_files))$isdir)) {
    iv_stop(
      object_id, " aggregate run directory violates its exact whitelist: ",
      paste(sort(observed_result_files), collapse = "|")
    )
  }
  private_dir <- dirname(mids_path)
  observed_private_files <- list.files(
    private_dir, all.files = TRUE, no.. = TRUE, recursive = FALSE
  )
  if (!identical(sort(observed_private_files), sort(basename(mids_path))) ||
      any(file.info(file.path(private_dir, observed_private_files))$isdir)) {
    iv_stop(object_id, " restricted run directory must contain only its mids.")
  }
  manifest <- iv_read_tsv_stable(
    file.path(result_dir, "run_manifest.tsv"),
    iv_run_manifest_schema, 1L, paste0(object_id, " run manifest")
  )
  m <- manifest$data
  scalar_checks <- c(
    run_id = identical(as.character(m$run_id), run_id),
    object_id = identical(as.character(m$object_id), object_id),
    requested_m = identical(as.integer(m$requested_m), 50L),
    denominator_positive =
      length(m$denominator_n) == 1L && is.finite(m$denominator_n) &&
        m$denominator_n > 0,
    selected_checkpoint =
      as.integer(m$selected_maxit) %in% c(20L, 40L, 80L),
    warning_zero = identical(as.integer(m$warning_count), 0L),
    logged_events_zero = identical(as.integer(m$logged_event_count), 0L),
    mortality_fit_zero =
      identical(as.integer(m$mortality_model_fit_count), 0L),
    coefficient_export_zero =
      identical(as.integer(m$coefficient_export_count), 0L),
    completed_persistence_zero =
      identical(as.integer(m$completed_dataset_persistence_count), 0L),
    hard_rows_positive =
      is.finite(m$hard_convergence_rows) && m$hard_convergence_rows > 0,
    failed_hard_rows_zero =
      identical(as.integer(m$failed_hard_convergence_rows), 0L),
    mids_alias = identical(as.character(m$mids_path_alias), expected_private_alias),
    result_alias = identical(as.character(m$result_path_alias), expected_result_alias),
    mids_hash = identical(as.character(m$mids_sha256), as.character(p$mids_sha256)),
    mids_bytes =
      identical(as.numeric(m$mids_bytes), as.numeric(file.info(mids_path)$size)),
    generated_status = as.character(m$status) %in%
      c("GENERATED_AWAITING_INDEPENDENT_VALIDATION")
  )
  if (!all(scalar_checks)) {
    iv_stop(
      object_id, " run manifest failed: ",
      paste(names(scalar_checks)[!scalar_checks], collapse = ", ")
    )
  }
  component <- iv_read_tsv_stable(
    file.path(result_dir, "component_hashes.tsv"),
    iv_component_schema, length(iv_required_components),
    paste0(object_id, " component hashes")
  )
  if (anyDuplicated(component$data$component) ||
      !setequal(component$data$component, iv_required_components) ||
      any(!grepl("^[0-9a-f]{64}$", component$data$sha256))) {
    iv_stop(object_id, " component-hash table is incomplete or malformed.")
  }
  mids <- iv_read_rds_stable(mids_path, paste0(object_id, " mids"))
  if (!identical(mids$sha256, as.character(p$mids_sha256)) ||
      !identical(mids$sha256, as.character(m$mids_sha256)) ||
      !identical(
        mids$sha256,
        component$data$sha256[
          match("final_mids_file", component$data$component)
        ]
      )) {
    iv_stop(object_id, " restricted mids byte hash differs across contracts.")
  }
  list(
    object_id = object_id, run_id = run_id,
    pointer_path = pointer_path, pointer = pointer,
    result_dir = result_dir, mids_path = mids_path,
    manifest = manifest, component = component, mids = mids
  )
}

iv_validate_mids_schema <- function(
    imp, source_data, specification, expected_object_id, expected_run_id,
    expected_selected_maxit, expected_m = 50L) {
  where_values_exact <- is.matrix(imp$where) &&
    is.matrix(specification$where) &&
    identical(typeof(imp$where), "logical") &&
    identical(dim(imp$where), dim(specification$where)) &&
    identical(unname(imp$where), unname(specification$where))
  where_dimnames_normalized_to_input <- identical(
    dimnames(imp$where), dimnames(source_data)
  )
  if (!inherits(imp, "mids") ||
      !identical(names(imp), iv_standard_mids_names) ||
      anyDuplicated(names(imp)) ||
      !identical(as.integer(imp$m), as.integer(expected_m)) ||
      !is.data.frame(imp$data) || !identical(imp$data, source_data) ||
      !identical(names(imp$imp), names(source_data)) ||
      !identical(imp$method, specification$method) ||
      !identical(imp$predictorMatrix, specification$predictor_matrix) ||
      !where_values_exact ||
      !where_dimnames_normalized_to_input ||
      !identical(
        as.character(imp$visitSequence),
        as.character(specification$visit_sequence)
      ) ||
      !identical(
        names(imp$nmis), names(source_data)
      ) ||
      !identical(
        as.integer(imp$nmis),
        as.integer(vapply(source_data, function(x) sum(is.na(x)), integer(1)))
      ) ||
      !identical(as.integer(imp$seed), as.integer(specification$seed)) ||
      !(
        is.null(imp$loggedEvents) ||
          (is.data.frame(imp$loggedEvents) && nrow(imp$loggedEvents) == 0L)
      )) {
    iv_stop("mids top-level schema or frozen MICE specification differs.")
  }
  expected_chains <- as.character(seq_len(expected_m))
  mapping_rows <- lapply(names(source_data), function(variable) {
    expected_rows <- which(specification$where[, variable])
    payload <- imp$imp[[variable]]
    active <- nzchar(specification$method[[variable]])
    if (is.null(payload)) {
      pass <- !active
      observed_rows <- 0L
      observed_columns <- 0L
    } else {
      pass <- if (active) {
        is.data.frame(payload) &&
          identical(rownames(payload), as.character(expected_rows)) &&
          identical(names(payload), expected_chains) &&
          nrow(payload) == length(expected_rows) &&
          ncol(payload) == expected_m &&
          !anyNA(payload)
      } else {
        is.data.frame(payload) &&
          identical(rownames(payload), as.character(expected_rows)) &&
          identical(names(payload), expected_chains) &&
          nrow(payload) == length(expected_rows) &&
          ncol(payload) == expected_m &&
          all(is.na(payload))
      }
      observed_rows <- if (is.data.frame(payload)) nrow(payload) else NA_integer_
      observed_columns <-
        if (is.data.frame(payload)) ncol(payload) else NA_integer_
    }
    data.frame(
      variable = variable, active = active,
      expected_missing_rows = length(expected_rows),
      payload_rows = observed_rows, payload_chains = observed_columns,
      row_names_exact = if (is.null(payload)) {
        !active
      } else {
        is.data.frame(payload) && if (active) {
          identical(rownames(payload), as.character(expected_rows))
        } else {
          identical(rownames(payload), as.character(expected_rows))
        }
      },
      chain_names_exact = if (is.null(payload)) {
        !active
      } else {
        is.data.frame(payload) && if (active) {
          identical(names(payload), expected_chains)
        } else {
          identical(names(payload), expected_chains)
        }
      },
      status = if (pass) "PASS" else "FAIL",
      stringsAsFactors = FALSE
    )
  })
  mapping <- do.call(rbind, mapping_rows)
  if (!all(mapping$status == "PASS")) {
    iv_stop(
      "mids$imp row-index/chain mapping failed: ",
      paste(mapping$variable[mapping$status != "PASS"], collapse = ", ")
    )
  }
  metadata <- attr(imp, "v45_production_metadata", exact = TRUE)
  metadata_names <- c(
    "contract_version", "run_id", "object_id", "requested_m",
    "selected_maxit", "generation_status", "mortality_model_fit_count",
    "coefficient_export_count", "completed_dataset_persistence_count",
    "component_hashes_before_file_save"
  )
  zero_fields <- c(
    "mortality_model_fit_count", "coefficient_export_count",
    "completed_dataset_persistence_count"
  )
  zero_exact <- if (is.list(metadata)) {
    vapply(zero_fields, function(field) {
      value <- metadata[[field]]
      length(value) == 1L && !is.na(value) &&
        identical(as.integer(value), 0L)
    }, logical(1))
  } else {
    setNames(rep(FALSE, length(zero_fields)), zero_fields)
  }
  if (!is.list(metadata) || !identical(names(metadata), metadata_names) ||
      !identical(metadata$contract_version, "v45_0_stage3") ||
      !identical(as.integer(metadata$requested_m), expected_m) ||
      !identical(metadata$object_id, expected_object_id) ||
      !identical(metadata$run_id, expected_run_id) ||
      !identical(
        as.integer(metadata$selected_maxit),
        as.integer(expected_selected_maxit)
      ) ||
      !identical(metadata$generation_status,
                 "GENERATED_AWAITING_INDEPENDENT_VALIDATION") ||
      !all(zero_exact)) {
    iv_stop("Restricted mids production metadata is malformed.")
  }
  list(mapping = mapping, metadata = metadata)
}

iv_validate_input_contract <- function(
    object_id, imp, specification, contract, definition) {
  expected_names <- c(
    "object_id", "denominator_n", "event_anchor_n", "response_anchor_n",
    "column_contract", "column_contract_sha256",
    "canonical_data_sha256", "missing_contract",
    "missing_contract_sha256", "ordered_id_sha256_canonical",
    "specification_sha256_canonical", "method_sha256",
    "predictor_matrix_sha256", "where_sha256",
    "visit_sequence_sha256", "seed", "initial_m", "maximum_m",
    "convergence_checkpoints", "convergence_rhat_max",
    "trace_release_missing_n_min"
  )
  iv_assert_exact_names(contract, expected_names, paste0(object_id, " contract"))
  data_contract <- iv_canonical_data_frame_contract(imp$data)
  missing_contract <- data.frame(
    column_index = seq_along(imp$data),
    column_name = names(imp$data),
    missing_n = unname(
      vapply(imp$data, function(x) sum(is.na(x)), integer(1))
    ),
    stringsAsFactors = FALSE
  )
  participant_id_text <- as.character(imp$data$SEQN)
  if (anyNA(participant_id_text) ||
      any(!grepl("^[0-9]+$", participant_id_text))) {
    iv_stop(object_id, " has a non-integral frozen participant ID.")
  }
  participant_id_numeric <- as.numeric(participant_id_text)
  if (any(!is.finite(participant_id_numeric)) ||
      any(participant_id_numeric > .Machine$integer.max)) {
    iv_stop(object_id, " has a participant ID outside the integer range.")
  }
  participant_ids <- as.integer(participant_id_numeric)
  if (anyDuplicated(participant_ids)) {
    iv_stop(object_id, " has invalid or duplicated frozen participant IDs.")
  }
  checks <- c(
    object_id = identical(contract$object_id, object_id),
    denominator = identical(as.integer(contract$denominator_n), nrow(imp$data)),
    definition_denominator =
      identical(as.integer(definition$denominator_n), nrow(imp$data)),
    definition_columns = identical(definition$columns, names(imp$data)),
    definition_specification = identical(definition$specification, specification),
    column_contract = identical(contract$column_contract, data_contract$columns),
    column_contract_hash = identical(
      contract$column_contract_sha256,
      iv_canonical_data_frame_contract(data_contract$columns)$sha256
    ),
    data_hash = identical(
      contract$canonical_data_sha256, data_contract$sha256
    ),
    missing_contract = identical(contract$missing_contract, missing_contract),
    missing_hash = identical(
      contract$missing_contract_sha256,
      iv_canonical_data_frame_contract(missing_contract)$sha256
    ),
    id_hash = identical(
      contract$ordered_id_sha256_canonical,
      iv_canonical_array_sha256(participant_ids)
    ),
    specification_hash = identical(
      contract$specification_sha256_canonical,
      iv_canonical_object_sha256(specification)
    ),
    method_hash = identical(
      contract$method_sha256,
      iv_canonical_named_character_sha256(specification$method)
    ),
    predictor_hash = identical(
      contract$predictor_matrix_sha256,
      iv_canonical_array_sha256(specification$predictor_matrix)
    ),
    where_hash = identical(
      contract$where_sha256,
      iv_canonical_array_sha256(specification$where)
    ),
    visit_hash = identical(
      contract$visit_sequence_sha256,
      iv_canonical_vector_contract(
        specification$visit_sequence
      )$values_sha256
    ),
    seed = identical(as.integer(contract$seed), as.integer(specification$seed)),
    initial_m = identical(as.integer(contract$initial_m), 50L),
    maximum_m = identical(as.integer(contract$maximum_m), 100L),
    checkpoints = identical(
      as.integer(contract$convergence_checkpoints), c(20L, 40L, 80L)
    ),
    rhat_threshold = identical(
      as.numeric(contract$convergence_rhat_max), 1.05
    ),
    trace_threshold = identical(
      as.integer(contract$trace_release_missing_n_min),
      as.integer(specification$trace_release_missing_n_min)
    )
  )
  if (!all(checks)) {
    iv_stop(
      object_id, " independent frozen-input reconstruction failed: ",
      paste(names(checks)[!checks], collapse = ", ")
    )
  }
  event_anchor <- sum(as.integer(as.character(imp$data$death)) == 1L)
  response_anchor <- if ("R_A" %in% names(imp$data)) {
    sum(as.character(imp$data$R_A) == "1")
  } else {
    NA_integer_
  }
  if (!identical(as.integer(contract$event_anchor_n), as.integer(event_anchor)) ||
      !identical(
        as.integer(contract$response_anchor_n), as.integer(response_anchor)
      )) {
    iv_stop(object_id, " frozen event/response anchor differs.")
  }
  list(
    checks = checks, participant_ids = participant_ids,
    data_contract = data_contract, missing_contract = missing_contract
  )
}

iv_convergence_schema <- c(
  "cohort", "imputation_id", "variable", "parameter", "category_level",
  "missing_n", "iterations", "chains", "retained_iterations",
  "applicability", "rank_normalized_split_rhat", "folded_split_rhat",
  "rhat", "folded_identifiable", "raw_trace_constant",
  "classic_final_half_rhat", "distinct_trace_values", "median_lag1_ac",
  "standardized_last5_shift", "hard_gate", "pass", "diagnostic_status",
  "detail"
)

iv_checkpoint_schema <- c(
  iv_convergence_schema, "mi_run", "checkpoint_order",
  "checkpoint_iteration", "selected_checkpoint"
)

iv_released_trace_schema <- c(
  "cohort", "imputation_id", "variable", "parameter", "category_level",
  "missing_n", "iteration", "chain", "value", "trace_release_status"
)

iv_coerce_convergence_types <- function(data, checkpoint = FALSE) {
  character_fields <- c(
    "cohort", "imputation_id", "variable", "parameter", "category_level",
    "applicability", "diagnostic_status", "detail"
  )
  integer_fields <- c(
    "missing_n", "iterations", "chains", "retained_iterations",
    "distinct_trace_values"
  )
  numeric_fields <- c(
    "rank_normalized_split_rhat", "folded_split_rhat", "rhat",
    "classic_final_half_rhat", "median_lag1_ac",
    "standardized_last5_shift"
  )
  logical_fields <- c(
    "folded_identifiable", "raw_trace_constant", "hard_gate", "pass"
  )
  if (checkpoint) {
    character_fields <- c(character_fields, "mi_run")
    integer_fields <- c(
      integer_fields, "checkpoint_order", "checkpoint_iteration"
    )
    logical_fields <- c(logical_fields, "selected_checkpoint")
  }
  for (field in character_fields) data[[field]] <- as.character(data[[field]])
  for (field in integer_fields) data[[field]] <- as.integer(data[[field]])
  for (field in numeric_fields) data[[field]] <- as.numeric(data[[field]])
  for (field in logical_fields) data[[field]] <- as.logical(data[[field]])
  data
}

iv_coerce_trace_types <- function(data) {
  for (field in c(
    "cohort", "imputation_id", "variable", "parameter", "category_level",
    "trace_release_status"
  )) {
    data[[field]] <- as.character(data[[field]])
  }
  for (field in c("missing_n", "iteration", "chain")) {
    data[[field]] <- as.integer(data[[field]])
  }
  data$value <- as.numeric(data$value)
  data
}

iv_load_diagnostics <- function(files) {
  object_id <- files$object_id
  result_dir <- files$result_dir
  read <- function(name, schema) {
    iv_read_tsv_stable(
      file.path(result_dir, name), schema, label = paste(object_id, name)
    )
  }
  structural <- read(
    "structural_checks.tsv", c("check", "status", "run_id")
  )
  checkpoint <- read("checkpoint_diagnostics.tsv", iv_checkpoint_schema)
  checkpoint$data <- iv_coerce_convergence_types(
    checkpoint$data, checkpoint = TRUE
  )
  final <- read("final_convergence.tsv", iv_checkpoint_schema)
  final$data <- iv_coerce_convergence_types(final$data, checkpoint = TRUE)
  trace <- read("released_chain_trace.tsv", iv_released_trace_schema)
  trace$data <- iv_coerce_trace_types(trace$data)
  bmi <- read(
    "passive_bmi_audit.tsv",
    c(
      "object_id", "requested_m", "bmi_missing_n", "observed_bmi_n",
      "observed_bmi_change_n", "maximum_identity_difference",
      "invalid_completed_parent_n", "all_observed_field_change_n",
      "response_change_n", "completed_structure_failure_n", "status"
    )
  )
  if (!nrow(structural$data) || anyDuplicated(structural$data$check) ||
      !all(structural$data$status == "PASS") ||
      !all(structural$data$run_id == files$run_id) ||
      !nrow(checkpoint$data) || !nrow(final$data) || !nrow(trace$data) ||
      nrow(bmi$data) != 1L) {
    iv_stop(object_id, " aggregate diagnostic files are empty or malformed.")
  }
  log_path <- file.path(result_dir, "run.log")
  log_hash_before <- iv_sha256_file(log_path)
  log_lines <- readLines(log_path, warn = TRUE, encoding = "UTF-8")
  exact_log_lines <- c(
    "status: GENERATED_AWAITING_INDEPENDENT_VALIDATION",
    "mortality_model_fit_count: 0",
    "coefficient_export_count: 0",
    "completed_dataset_persistence_count: 0"
  )
  log_prefixes <- c(
    "^status:", "^mortality_model_fit_count:",
    "^coefficient_export_count:", "^completed_dataset_persistence_count:"
  )
  if (!identical(log_hash_before, iv_sha256_file(log_path)) ||
      !all(vapply(
        exact_log_lines,
        function(line) sum(log_lines == line) == 1L,
        logical(1)
      )) ||
      !all(vapply(
        seq_along(log_prefixes),
        function(index) {
          matching <- grep(log_prefixes[[index]], log_lines, value = TRUE)
          length(matching) == 1L &&
            identical(matching, exact_log_lines[[index]])
        },
        logical(1)
      ))) {
    iv_stop(object_id, " production log contract failed.")
  }
  gli <- NULL
  gli_hashes <- NULL
  if (identical(object_id, "MI-G")) {
    gli <- read(
      "passive_gli_audit.tsv",
      c("check", "observed", "threshold", "status")
    )
    gli_hashes <- read(
      "passive_gli_hashes.tsv",
      c("object_id", "imputation", "gli_canonical_sha256")
    )
    if (nrow(gli$data) != 6L || anyDuplicated(gli$data$check) ||
        !all(gli$data$status == "PASS") ||
        nrow(gli_hashes$data) != 50L ||
        !identical(as.integer(gli_hashes$data$imputation), seq_len(50L)) ||
        any(!grepl("^[0-9a-f]{64}$", gli_hashes$data$gli_canonical_sha256)) ||
        !all(gli_hashes$data$object_id == object_id)) {
      iv_stop("MI-G aggregate passive-GLI diagnostics are malformed.")
    }
  }
  list(
    structural = structural, checkpoint = checkpoint, final = final,
    trace = trace, bmi = bmi, gli = gli, gli_hashes = gli_hashes,
    log_sha256 = log_hash_before
  )
}

iv_validate_component_hashes <- function(
    files, diagnostics, specification, participant_ids, category_trace) {
  imp <- files$mids$data
  recorded <- setNames(
    as.character(files$component$data$sha256),
    files$component$data$component
  )
  independent <- c(
    canonical_source_input_data =
      iv_canonical_data_frame_contract(imp$data)$sha256,
    canonical_column_types_factor_levels_and_ordered_flags =
      iv_canonical_data_frame_contract(
        iv_canonical_data_frame_contract(imp$data)$columns
      )$sha256,
    canonical_frozen_specification =
      iv_canonical_object_sha256(specification),
    canonical_ordered_participant_ids =
      iv_canonical_array_sha256(participant_ids),
    canonical_imputation_payload =
      iv_canonical_imputation_payload_sha256(imp),
    canonical_chain_mean = iv_canonical_array_sha256(imp$chainMean),
    canonical_chain_variance = iv_canonical_array_sha256(imp$chainVar),
    canonical_categorical_trace =
      iv_canonical_data_frame_contract(category_trace)$sha256,
    canonical_final_convergence =
      recorded[["canonical_final_convergence"]],
    canonical_checkpoint_diagnostics =
      recorded[["canonical_checkpoint_diagnostics"]],
    canonical_released_trace =
      recorded[["canonical_released_trace"]],
    mids_method = iv_canonical_named_character_sha256(imp$method),
    mids_predictor_matrix =
      iv_canonical_array_sha256(imp$predictorMatrix),
    mids_where = iv_canonical_array_sha256(imp$where),
    mids_visit_sequence = iv_canonical_vector_contract(
      as.character(imp$visitSequence)
    )$values_sha256,
    mids_last_seed_value =
      iv_canonical_array_sha256(as.integer(imp$lastSeedValue)),
    final_mids_file = files$mids$sha256
  )
  recorded <- recorded[names(independent)]
  if (!identical(unname(recorded), unname(independent))) {
    failed <- names(independent)[recorded != independent | is.na(recorded)]
    iv_stop(
      files$object_id, " independent component rehash failed: ",
      paste(failed, collapse = ", ")
    )
  }
  metadata_components <-
    attr(imp, "v45_production_metadata", exact = TRUE)$
      component_hashes_before_file_save
  if (!is.data.frame(metadata_components) ||
      !identical(names(metadata_components), iv_component_schema) ||
      !setequal(
        metadata_components$component,
        setdiff(iv_required_components, "final_mids_file")
      )) {
    iv_stop(files$object_id, " embedded pre-save component contract is invalid.")
  }
  metadata_recorded <- setNames(
    metadata_components$sha256, metadata_components$component
  )
  if (!identical(
        unname(metadata_recorded[names(independent)[-length(independent)]]),
        unname(independent[-length(independent)])
      )) {
    iv_stop(files$object_id, " embedded component hashes fail revalidation.")
  }
  independent
}

iv_trace_key <- function(data) {
  paste(
    data$variable,
    data$parameter,
    ifelse(is.na(data$category_level), "<NA>", data$category_level),
    sep = "\r"
  )
}

iv_extract_chain_array <- function(
    array, variable, iterations, chains, transform = identity) {
  dimensions <- dim(array)
  variables <- if (length(dimensions) == 3L) dimnames(array)[[1L]] else NULL
  if (is.null(array) || length(dimensions) != 3L ||
      !identical(as.integer(dimensions[2:3]), c(iterations, chains)) ||
      is.null(variables) || sum(variables == variable) != 1L) {
    iv_stop("MICE chain array is dimensionally invalid for ", variable, ".")
  }
  values <- transform(array[variable, , , drop = TRUE])
  if (is.null(dim(values))) values <- matrix(values, ncol = chains)
  values
}

iv_make_diagnostic <- function(
    variable, parameter, category_level, values, missing_n, role,
    threshold) {
  audit <- iv_rhat_audit(values)
  structural_na <- identical(role, "scale") && missing_n == 1L
  supportive <- identical(role, "category_scale")
  constant_acceptable <- isTRUE(audit$raw_trace_constant) &&
    role %in% c("scale", "category_location", "category_scale")
  hard_gate <- !structural_na && !supportive && !constant_acceptable
  pass <- if (!hard_gate) {
    TRUE
  } else {
    isTRUE(audit$finite) &&
      audit$iterations >= 6L && audit$chains >= 2L &&
      !isTRUE(audit$raw_trace_constant) &&
      is.finite(audit$rank_normalized_split_rhat) &&
      is.finite(audit$rhat) &&
      audit$rhat <= threshold
  }
  data.frame(
    variable = variable, parameter = parameter,
    category_level = category_level, missing_n = as.integer(missing_n),
    hard_gate = hard_gate, pass = pass, rhat = audit$rhat,
    rank_normalized_split_rhat = audit$rank_normalized_split_rhat,
    folded_split_rhat = audit$folded_split_rhat,
    distinct_trace_values = audit$distinct_trace_values,
    raw_trace_constant = audit$raw_trace_constant,
    stringsAsFactors = FALSE
  )
}

iv_independent_convergence <- function(
    imp, specification, iteration_count, include_final_variation = FALSE) {
  chain_count <- as.integer(imp$m)
  threshold <- as.numeric(specification$convergence_rhat_max)
  active <- names(specification$method)[nzchar(specification$method)]
  missing_n <- vapply(
    imp$data[active], function(x) sum(is.na(x)), integer(1)
  )
  active <- active[missing_n > 0L]
  missing_n <- missing_n[active]
  unordered <- intersect(
    active, specification$unordered_multicategory_targets
  )
  quantitative <- setdiff(active, unordered)
  rows <- list()
  append_row <- function(value) rows[[length(rows) + 1L]] <<- value
  for (variable in quantitative) {
    means <- iv_extract_chain_array(
      imp$chainMean, variable, as.integer(imp$iteration), chain_count
    )[seq_len(iteration_count), , drop = FALSE]
    variances <- iv_extract_chain_array(
      imp$chainVar, variable, as.integer(imp$iteration), chain_count
    )[seq_len(iteration_count), , drop = FALSE]
    if (any(!is.finite(variances)) && missing_n[[variable]] != 1L) {
      iv_stop(variable, " chain variance contains non-finite values.")
    }
    append_row(iv_make_diagnostic(
      variable, "chain_mean", NA_character_, means,
      missing_n[[variable]], "location", threshold
    ))
    append_row(iv_make_diagnostic(
      variable, "chain_sd", NA_character_, sqrt(variances),
      missing_n[[variable]], "scale", threshold
    ))
  }
  category_trace <- attr(imp, "category_trace", exact = TRUE)
  for (variable in unordered) {
    levels_expected <- levels(imp$data[[variable]])
    variable_rows <- list()
    for (level in levels_expected) {
      selected <- category_trace[
        category_trace$variable == variable &
          category_trace$category_level == level &
          category_trace$iteration <= iteration_count,
        ,
        drop = FALSE
      ]
      key <- paste(selected$iteration, selected$chain, sep = "\r")
      expected_grid <- expand.grid(
        iteration = seq_len(iteration_count),
        chain = seq_len(chain_count),
        KEEP.OUT.ATTRS = FALSE, stringsAsFactors = FALSE
      )
      expected_key <- paste(
        expected_grid$iteration, expected_grid$chain, sep = "\r"
      )
      if (nrow(selected) != nrow(expected_grid) || anyDuplicated(key) ||
          !setequal(key, expected_key)) {
        iv_stop(variable, " categorical trace prefix grid is incomplete.")
      }
      values <- matrix(
        NA_real_, nrow = iteration_count, ncol = chain_count
      )
      values[cbind(selected$iteration, selected$chain)] <- selected$value
      location <- iv_make_diagnostic(
        variable, paste0("category_proportion[level=", level, "]"),
        level, values, missing_n[[variable]], "category_location", threshold
      )
      scale_values <- if (missing_n[[variable]] > 1L) {
        sqrt(
          missing_n[[variable]] / (missing_n[[variable]] - 1) *
            values * (1 - values)
        )
      } else {
        matrix(NA_real_, nrow = iteration_count, ncol = chain_count)
      }
      scale <- iv_make_diagnostic(
        variable, paste0("category_indicator_sd[level=", level, "]"),
        level, scale_values, missing_n[[variable]], "category_scale", threshold
      )
      append_row(location)
      append_row(scale)
      variable_rows[[length(variable_rows) + 1L]] <- location
    }
    location_rows <- do.call(rbind, variable_rows)
    evaluable <- unique(location_rows$category_level[
      location_rows$hard_gate %in% TRUE &
        !(location_rows$raw_trace_constant %in% TRUE)
    ])
    append_row(data.frame(
      variable = variable, parameter = "category_level_coverage",
      category_level = NA_character_,
      missing_n = as.integer(missing_n[[variable]]),
      hard_gate = TRUE, pass = length(evaluable) >= 2L,
      rhat = NA_real_, rank_normalized_split_rhat = NA_real_,
      folded_split_rhat = NA_real_,
      distinct_trace_values = as.integer(length(evaluable)),
      raw_trace_constant = NA, stringsAsFactors = FALSE
    ))
  }
  if (include_final_variation) {
    for (variable in active) {
      payload <- imp$imp[[variable]]
      valid <- is.data.frame(payload) &&
        nrow(payload) == missing_n[[variable]] &&
        ncol(payload) == chain_count && !anyNA(payload)
      varying_rows <- if (valid) {
        sum(apply(
          payload, 1L,
          function(values) length(unique(as.character(values))) > 1L
        ))
      } else {
        0L
      }
      append_row(data.frame(
        variable = variable,
        parameter = "final_between_imputation_variation",
        category_level = NA_character_,
        missing_n = as.integer(missing_n[[variable]]),
        hard_gate = TRUE, pass = valid && varying_rows > 0L,
        rhat = NA_real_, rank_normalized_split_rhat = NA_real_,
        folded_split_rhat = NA_real_,
        distinct_trace_values = as.integer(varying_rows),
        raw_trace_constant = if (valid) varying_rows == 0L else NA,
        stringsAsFactors = FALSE
      ))
    }
  }
  if (!length(rows)) iv_stop("No independent convergence rows were generated.")
  do.call(rbind, rows)
}

iv_compare_convergence <- function(
    recorded, independent, object_id, checkpoint_label) {
  recorded_key <- iv_trace_key(recorded)
  independent_key <- iv_trace_key(independent)
  if (anyDuplicated(recorded_key) || anyDuplicated(independent_key) ||
      !setequal(recorded_key, independent_key)) {
    iv_stop(object_id, " ", checkpoint_label, " convergence row set differs.")
  }
  recorded <- recorded[match(independent_key, recorded_key), , drop = FALSE]
  exact <- c(
    hard_gate = identical(
      as.logical(recorded$hard_gate), as.logical(independent$hard_gate)
    ),
    pass = identical(as.logical(recorded$pass), as.logical(independent$pass)),
    missing_n = identical(
      as.integer(recorded$missing_n), as.integer(independent$missing_n)
    ),
    distinct_values = identical(
      as.integer(recorded$distinct_trace_values),
      as.integer(independent$distinct_trace_values)
    )
  )
  finite <- is.finite(independent$rhat)
  rhat_equal <- all(
    abs(recorded$rhat[finite] - independent$rhat[finite]) <= 1e-12
  ) && all(is.na(recorded$rhat[!finite]) == is.na(independent$rhat[!finite]))
  if (!all(exact) || !rhat_equal) {
    iv_stop(
      object_id, " ", checkpoint_label,
      " recorded diagnostics disagree with independent recalculation."
    )
  }
  invisible(TRUE)
}

iv_validate_released_trace <- function(
    imp, final, trace, specification, object_id) {
  eligible <- final[
    final$hard_gate %in% TRUE & final$pass %in% TRUE &
      final$missing_n >= specification$trace_release_missing_n_min &
      (
        final$parameter %in% c("chain_mean", "chain_sd") |
          grepl("^category_proportion", final$parameter)
      ),
    c("variable", "parameter", "category_level", "missing_n"),
    drop = FALSE
  ]
  if (!nrow(eligible)) {
    if (nrow(trace) != 1L ||
        !identical(trace$trace_release_status,
                   "NO_RELEASE_ELIGIBLE_TRACE")) {
      iv_stop(object_id, " released-trace no-release sentinel is invalid.")
    }
    return(invisible(TRUE))
  }
  expected_keys <- iv_trace_key(eligible)
  observed_groups <- unique(
    trace[c("variable", "parameter", "category_level", "missing_n")]
  )
  observed_keys <- iv_trace_key(observed_groups)
  if (anyDuplicated(expected_keys) || anyDuplicated(observed_keys) ||
      !setequal(expected_keys, observed_keys) ||
      !all(trace$cohort == "NHANES") ||
      !all(trace$imputation_id == object_id) ||
      !all(trace$trace_release_status ==
             "RELEASED_HARD_GATE_AGGREGATE")) {
    iv_stop(object_id, " released-trace group contract differs.")
  }
  category_trace <- attr(imp, "category_trace", exact = TRUE)
  for (index in seq_len(nrow(eligible))) {
    current <- eligible[index, , drop = FALSE]
    selected <- trace[
      iv_trace_key(trace) == iv_trace_key(current), , drop = FALSE
    ]
    grid_key <- paste(selected$iteration, selected$chain, sep = "\r")
    expected_grid <- expand.grid(
      iteration = seq_len(as.integer(imp$iteration)),
      chain = seq_len(as.integer(imp$m)),
      KEEP.OUT.ATTRS = FALSE, stringsAsFactors = FALSE
    )
    expected_grid_key <- paste(
      expected_grid$iteration, expected_grid$chain, sep = "\r"
    )
    if (nrow(selected) != nrow(expected_grid) ||
        anyDuplicated(grid_key) || !setequal(grid_key, expected_grid_key)) {
      iv_stop(object_id, " released-trace grid is incomplete.")
    }
    selected <- selected[match(expected_grid_key, grid_key), , drop = FALSE]
    if (current$parameter %in% c("chain_mean", "chain_sd")) {
      array <- if (current$parameter == "chain_mean") {
        imp$chainMean
      } else {
        sqrt(imp$chainVar)
      }
      expected_values <- as.vector(
        array[current$variable, , , drop = TRUE]
      )
    } else {
      source <- category_trace[
        category_trace$variable == current$variable &
          category_trace$category_level == current$category_level,
        , drop = FALSE
      ]
      source_key <- paste(source$iteration, source$chain, sep = "\r")
      expected_values <- source$value[match(expected_grid_key, source_key)]
    }
    tolerance <- 1e-12 * pmax(1, abs(expected_values))
    if (anyNA(expected_values) || anyNA(selected$value) ||
        any(abs(selected$value - expected_values) > tolerance)) {
      iv_stop(object_id, " released-trace values differ from the mids arrays.")
    }
  }
  invisible(TRUE)
}

iv_validate_convergence <- function(files, diagnostics, specification) {
  imp <- files$mids$data
  object_id <- files$object_id
  selected <- as.integer(imp$iteration)
  chain_count <- as.integer(imp$m)
  category <- iv_category_trace_audit(
    imp = imp, mi_data = imp$data, mi_spec = specification
  )
  independent_final <- iv_independent_convergence(
    imp, specification, selected, include_final_variation = TRUE
  )
  hard <- independent_final$hard_gate %in% TRUE
  variation <- independent_final$parameter ==
    "final_between_imputation_variation"
  if (!any(hard) || !all(independent_final$pass[hard] %in% TRUE) ||
      !any(variation) || !all(independent_final$pass[variation] %in% TRUE)) {
    iv_stop(
      object_id,
      " fails independently recalculated R-hat or variation hard gates."
    )
  }
  final <- diagnostics$final$data
  if (!all(final$cohort == "NHANES") ||
      !all(final$imputation_id == object_id) ||
      !all(as.integer(final$iterations) == selected) ||
      !all(as.integer(final$chains) == chain_count) ||
      !all(final$mi_run == "m50") ||
      !all(final$selected_checkpoint %in% TRUE) ||
      length(unique(as.integer(final$checkpoint_order))) != 1L ||
      !all(as.integer(final$checkpoint_iteration) == selected)) {
    iv_stop(object_id, " final-convergence identity/dimensions differ.")
  }
  iv_compare_convergence(
    final, independent_final, object_id, "selected-final"
  )
  iv_validate_released_trace(
    imp, final, diagnostics$trace$data, specification, object_id
  )
  checkpoint <- diagnostics$checkpoint$data
  orders <- sort(unique(as.integer(checkpoint$checkpoint_order)))
  expected_iterations <- c(20L, 40L, 80L)[seq_along(orders)]
  if (!identical(orders, seq_along(orders)) ||
      !identical(
        sort(unique(as.integer(checkpoint$checkpoint_iteration))),
        expected_iterations
      ) ||
      tail(expected_iterations, 1L) != selected) {
    iv_stop(object_id, " checkpoint schedule/selection is malformed.")
  }
  selected_pairs <- unique(checkpoint[
    checkpoint$selected_checkpoint %in% TRUE,
    c("checkpoint_order", "checkpoint_iteration")
  ])
  if (nrow(selected_pairs) != 1L ||
      as.integer(selected_pairs$checkpoint_iteration) != selected) {
    iv_stop(object_id, " selected checkpoint is not unique.")
  }
  for (index in seq_along(expected_iterations)) {
    iteration <- expected_iterations[[index]]
    recorded <- checkpoint[
      as.integer(checkpoint$checkpoint_order) == index,
      , drop = FALSE
    ]
    if (!nrow(recorded) ||
        !all(as.integer(recorded$checkpoint_iteration) == iteration)) {
      iv_stop(object_id, " checkpoint block is incomplete.")
    }
    recorded_full <- recorded
    independent <- iv_independent_convergence(
      imp, specification, iteration,
      include_final_variation = identical(iteration, selected)
    )
    if (!identical(iteration, selected)) {
      recorded <- recorded[
        recorded$parameter != "final_between_imputation_variation",
        , drop = FALSE
      ]
    }
    iv_compare_convergence(
      recorded, independent, object_id, paste0("checkpoint-", iteration)
    )
    recorded_hard <- recorded_full$hard_gate %in% TRUE
    if (!identical(iteration, selected) &&
        (!any(recorded_hard) ||
          !any(!(recorded_full$pass[recorded_hard] %in% TRUE)))) {
      iv_stop(object_id, " an earlier checkpoint lacks its required failure.")
    }
  }
  list(
    independent = independent_final,
    category = category,
    maximum_hard_rhat = {
      values <- independent_final$rhat[
        hard & is.finite(independent_final$rhat)
      ]
      if (length(values)) max(values) else NA_real_
    }
  )
}

iv_forbidden_mi_s_fields <- function(field_names) {
  field_names[grepl(
    paste0(
      "(^SPX)|(^pef($|_))|(^E0b?$)|(^fev1($|_))|(^fvc($|_))|",
      "(spirometr)|(^status_)|(quality)|(comment)|(effort)"
    ),
    field_names, ignore.case = TRUE, perl = TRUE
  )]
}

iv_validate_completed_data <- function(
    files, specification, diagnostics) {
  imp <- files$mids$data
  source_data <- imp$data
  object_id <- files$object_id
  observed_change_n <- 0L
  structure_failure_n <- 0L
  id_change_n <- 0L
  for (chain in seq_len(as.integer(imp$m))) {
    completed <- mice::complete(imp, action = chain)
    if (!identical(names(completed), names(source_data)) ||
        nrow(completed) != nrow(source_data)) {
      iv_stop(object_id, " completed-data dimensions differ at chain ", chain)
    }
    for (variable in names(source_data)) {
      structure_ok <- identical(
        class(completed[[variable]]), class(source_data[[variable]])
      ) && (
        !is.factor(source_data[[variable]]) ||
          (
            identical(
              levels(completed[[variable]]), levels(source_data[[variable]])
            ) &&
              identical(
                is.ordered(completed[[variable]]),
                is.ordered(source_data[[variable]])
              )
          )
      )
      structure_failure_n <- structure_failure_n + as.integer(!structure_ok)
      observed <- !is.na(source_data[[variable]])
      changed <- if (is.factor(source_data[[variable]]) ||
                     is.character(source_data[[variable]])) {
        as.character(completed[[variable]][observed]) !=
          as.character(source_data[[variable]][observed])
      } else {
        completed[[variable]][observed] != source_data[[variable]][observed]
      }
      observed_change_n <- observed_change_n + sum(is.na(changed) | changed)
    }
    id_changed <- as.character(completed$SEQN) != as.character(source_data$SEQN)
    id_change_n <- id_change_n + sum(is.na(id_changed) | id_changed)
    if (identical(object_id, "MI-S")) {
      response_changed <-
        as.character(completed$R_A) != as.character(source_data$R_A)
      if (any(is.na(response_changed) | response_changed)) {
        iv_stop("MI-S fixed response changed in completed chain ", chain, ".")
      }
    }
    rm(completed)
  }
  if (observed_change_n != 0L || structure_failure_n != 0L ||
      id_change_n != 0L) {
    iv_stop(
      object_id, " completed-data preservation failed: observed=",
      observed_change_n, "; structure=", structure_failure_n,
      "; IDs=", id_change_n
    )
  }
  bmi <- iv_passive_bmi_audit(
    imp, mi_data = source_data, mi_spec = specification, tolerance = 1e-12
  )
  if (nrow(bmi) != 1L || !identical(bmi$status, "PASS")) {
    iv_stop(object_id, " independently reconstructed passive BMI failed.")
  }
  if (identical(object_id, "MI-S")) {
    forbidden <- iv_forbidden_mi_s_fields(names(source_data))
    active_nonpassive <- setdiff(
      names(specification$method)[nzchar(specification$method)], "bmi"
    )
    response_checks <- c(
      response_present = "R_A" %in% names(source_data),
      response_fixed = identical(specification$method[["R_A"]], ""),
      response_not_imputed = {
        payload <- imp$imp[["R_A"]]
        is.null(payload) ||
          (
            is.data.frame(payload) && nrow(payload) == 0L &&
              ncol(payload) == as.integer(imp$m) && all(is.na(payload))
          )
      },
      response_where_false =
        "R_A" %in% colnames(specification$where) &&
          !any(specification$where[, "R_A"]),
      forbidden_absent = !length(forbidden),
      predicts_every_active =
        length(active_nonpassive) > 0L &&
          all(
            specification$predictor_matrix[
              active_nonpassive, "R_A", drop = TRUE
            ] == 1
          )
    )
    if (!all(response_checks)) {
      iv_stop(
        "MI-S measurement exclusion/fixed-response contract failed: ",
        paste(names(response_checks)[!response_checks], collapse = ", ")
      )
    }
  }
  recorded_bmi <- diagnostics$bmi$data
  if (!identical(as.character(recorded_bmi$status), "PASS") ||
      !identical(
        as.integer(recorded_bmi$bmi_missing_n),
        as.integer(bmi$bmi_missing_n)
      ) ||
      !identical(
        as.integer(recorded_bmi$observed_bmi_n),
        as.integer(bmi$observed_bmi_n)
      ) ||
      abs(
        as.numeric(recorded_bmi$maximum_identity_difference) -
          as.numeric(bmi$maximum_identity_difference)
      ) > 1e-12) {
    iv_stop(object_id, " runner BMI summary differs from independent audit.")
  }
  list(
    bmi = bmi, observed_change_n = observed_change_n,
    structure_failure_n = structure_failure_n, id_change_n = id_change_n
  )
}

iv_validate_passive_gli <- function(files, diagnostics) {
  if (!identical(files$object_id, "MI-G")) return(NULL)
  imp <- files$mids$data
  source_data <- imp$data
  observed_height <- !is.na(source_data$height_cm)
  missing_height <- !observed_height
  if (!any(missing_height) ||
      any(grepl("^gli|^L_", names(imp$data), ignore.case = TRUE))) {
    iv_stop("MI-G GLI persistence or missing-height contract failed.")
  }
  reference <- NULL
  height_values <- matrix(
    NA_real_, nrow = sum(missing_height), ncol = as.integer(imp$m)
  )
  gli_values <- height_values
  independent_hashes <- character(as.integer(imp$m))
  maximum_observed_difference <- 0
  for (chain in seq_len(as.integer(imp$m))) {
    completed <- mice::complete(imp, action = chain)
    gli <- v45_compute_gli(completed)
    if (any(!is.finite(as.matrix(gli)))) {
      iv_stop("MI-G passive GLI contains non-finite values.")
    }
    independent_hashes[[chain]] <-
      iv_canonical_data_frame_contract(gli)$sha256
    if (chain == 1L) {
      reference <- gli[observed_height, , drop = FALSE]
    } else {
      maximum_observed_difference <- max(
        maximum_observed_difference,
        abs(
          as.matrix(gli[observed_height, , drop = FALSE]) -
            as.matrix(reference)
        )
      )
    }
    height_values[, chain] <- completed$height_cm[missing_height]
    gli_values[, chain] <- gli$gli_global2022_z_fev1[missing_height]
    rm(completed, gli)
  }
  legacy <- v45_validate_gli_against_pure_reference(
    source_data[observed_height, , drop = FALSE]
  )
  first_missing <- which(missing_height)[[1L]]
  before_data <- mice::complete(imp, action = 1L)[
    first_missing, , drop = FALSE
  ]
  after_data <- before_data
  after_data$height_cm <- after_data$height_cm + 0.1
  before <- v45_compute_gli(before_data)
  after <- v45_compute_gli(after_data)
  fields <- c(
    "gli_global2022_z_fev1", "gli_global2022_z_fvc",
    "gli_global2022_z_fev1_fvc", "gli2012_z_fev1",
    "gli2012_z_fvc", "gli2012_z_fev1_fvc"
  )
  varying_height <- sum(apply(
    height_values, 1L, function(values) length(unique(values)) > 1L
  ))
  varying_gli <- sum(apply(
    gli_values, 1L, function(values) length(unique(values)) > 1L
  ))
  recorded_hashes <- as.character(
    diagnostics$gli_hashes$data$gli_canonical_sha256
  )
  checks <- c(
    observed_invariant = maximum_observed_difference == 0,
    legacy_exact = isTRUE(legacy$pass),
    height_dependency =
      all(vapply(fields, function(field) {
        abs(before[[field]] - after[[field]]) > 0
      }, logical(1))),
    imputed_height_varies = varying_height > 0L,
    imputed_gli_varies = varying_gli > 0L,
    hashes_exact = identical(recorded_hashes, independent_hashes)
  )
  if (!all(checks)) {
    iv_stop(
      "MI-G independent passive-GLI audit failed: ",
      paste(names(checks)[!checks], collapse = ", ")
    )
  }
  data.frame(
    observed_height_maximum_difference = maximum_observed_difference,
    legacy_maximum_difference = legacy$maximum_absolute_difference,
    varying_imputed_height_rows = varying_height,
    varying_imputed_gli_rows = varying_gli,
    chains_checked = as.integer(imp$m),
    status = "PASS", stringsAsFactors = FALSE
  )
}

iv_read_yaml_stable <- function(path, label = basename(path)) {
  before <- iv_sha256_file(path)
  value <- yaml::read_yaml(path)
  after <- iv_sha256_file(path)
  if (!identical(before, after)) iv_stop(label, " changed while read.")
  list(data = value, sha256 = before)
}

iv_commit_validation <- function(
    root, object_results, gate, gate_initial_sha256,
    output_manifest_sha256, staged_outputs, final_outputs,
    stable_inputs) {
  lock <- file.path(
    root, "derived_sensitive", "v45", "production_mi",
    ".stage3_independent_validation.lock"
  )
  if (!dir.create(lock, showWarnings = FALSE)) {
    iv_stop("Another Stage 3 independent validator holds the commit lock.")
  }
  on.exit(if (dir.exists(lock)) unlink(lock, recursive = TRUE), add = TRUE)
  transaction_temporaries <- character()
  on.exit(
    unlink(transaction_temporaries[file.exists(transaction_temporaries)]),
    add = TRUE
  )
  current_hashes <- vapply(
    names(stable_inputs), iv_sha256_file, character(1)
  )
  if (!identical(unname(current_hashes), unname(stable_inputs)) ||
      !identical(
        iv_sha256_file(file.path(root, "work_v45", "gate_state_v45.yml")),
        gate_initial_sha256
      )) {
    iv_stop("A validated input or gate changed before commit.")
  }
  pointer_temporaries <- character()
  pointer_paths <- character()
  for (object_id in names(object_results)) {
    files <- object_results[[object_id]]$files
    if (!identical(
          iv_sha256_file(files$pointer_path), files$pointer$sha256
        )) {
      iv_stop(object_id, " pointer changed before validation commit.")
    }
    pointer <- files$pointer$data
    pointer$status <- "INDEPENDENT_VALIDATION_PASS"
    temporary <- tempfile(
      pattern = paste0(".", basename(files$pointer_path), "."),
      tmpdir = dirname(files$pointer_path)
    )
    transaction_temporaries <- c(transaction_temporaries, temporary)
    utils::write.table(
      pointer, temporary, sep = "\t", quote = FALSE,
      row.names = FALSE, col.names = TRUE, na = ""
    )
    pointer_temporaries <- c(pointer_temporaries, temporary)
    pointer_paths <- c(pointer_paths, files$pointer_path)
  }
  gate$stage3_production_mi_execution$status <-
    "INDEPENDENT_VALIDATION_PASS"
  if (is.null(gate$stage3_production_mi_execution$objects)) {
    gate$stage3_production_mi_execution$objects <- list()
  }
  for (object_id in names(object_results)) {
    result <- object_results[[object_id]]
    gate$stage3_production_mi_execution$objects[[object_id]] <- list(
      status = "INDEPENDENT_VALIDATION_PASS",
      m = 50L, run_id = result$files$run_id,
      selected_maxit = as.integer(result$files$mids$data$iteration),
      mids_sha256 = result$files$mids$sha256
    )
  }
  gate$stage3_production_mi_independent_validation <- list(
    status = "INDEPENDENT_VALIDATION_PASS",
    output_manifest_sha256 = output_manifest_sha256
  )
  gate$outcome_execution_allowed <- FALSE
  gate$new_mortality_coefficient_inspection_allowed <- FALSE
  gate$production_m50_objects_allowed <- FALSE
  gate$production_m100_objects_allowed <- FALSE
  gate$next_authorized_step <- "freeze_NHANES_outcome_execution"
  gate$updated_at <- format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")
  gate_path <- file.path(root, "work_v45", "gate_state_v45.yml")
  gate_temporary <- tempfile(
    pattern = paste0(".", basename(gate_path), "."),
    tmpdir = dirname(gate_path)
  )
  transaction_temporaries <- c(transaction_temporaries, gate_temporary)
  yaml::write_yaml(gate, gate_temporary)
  targets <- c(
    final_outputs, setNames(pointer_paths, paste0("pointer_", names(object_results))),
    gate = gate_path
  )
  staged <- c(
    staged_outputs,
    setNames(pointer_temporaries, paste0("pointer_", names(object_results))),
    gate = gate_temporary
  )
  if (!identical(names(targets), names(staged)) ||
      any(!file.exists(staged))) {
    iv_stop("Validation transaction staging is incomplete.")
  }
  backup_dir <- file.path(lock, "backup")
  dir.create(backup_dir, showWarnings = FALSE)
  original_exists <- file.exists(targets)
  backup_paths <- file.path(
    backup_dir, paste0(seq_along(targets), "_", basename(targets))
  )
  for (index in which(original_exists)) {
    if (!file.copy(targets[[index]], backup_paths[[index]], overwrite = TRUE)) {
      iv_stop("Could not back up validation target before commit.")
    }
  }
  committed <- FALSE
  on.exit({
    if (!committed) {
      for (index in seq_along(targets)) {
        if (original_exists[[index]]) {
          file.copy(
            backup_paths[[index]], targets[[index]], overwrite = TRUE
          )
        } else if (file.exists(targets[[index]])) {
          unlink(targets[[index]])
        }
      }
    }
    unlink(staged[file.exists(staged)])
  }, add = TRUE)
  publish_order <- c(
    setdiff(seq_along(targets), match("gate", names(targets))),
    match("gate", names(targets))
  )
  for (index in publish_order) {
    dir.create(dirname(targets[[index]]), recursive = TRUE, showWarnings = FALSE)
    local_temporary <- tempfile(
      pattern = paste0(".", basename(targets[[index]]), "."),
      tmpdir = dirname(targets[[index]])
    )
    if (!file.copy(staged[[index]], local_temporary, overwrite = TRUE) ||
        !file.rename(local_temporary, targets[[index]])) {
      if (file.exists(local_temporary)) unlink(local_temporary)
      iv_stop("Could not publish validation transaction target: ",
              targets[[index]])
    }
  }
  committed <- TRUE
  invisible(TRUE)
}

main <- function() {
  root <- stage3_root()
  if ("--self-test" %in% commandArgs(trailingOnly = TRUE)) {
    message("v45 Stage 3 independent validator parses and loads.")
    return(invisible(TRUE))
  }
  random_seed_before <- get0(
    ".Random.seed", envir = .GlobalEnv, inherits = FALSE, ifnotfound = NULL
  )
  library_root <- file.path(root, "work_v43", "renv", "library")
  candidates <- list.dirs(library_root, recursive = TRUE, full.names = TRUE)
  mice_paths <- candidates[basename(candidates) == "mice"]
  if (!length(mice_paths)) iv_stop("Frozen Stage 3 R library is absent.")
  .libPaths(unique(c(dirname(mice_paths[[1L]]), .libPaths())))
  iv_require(c("digest", "dplyr", "mice", "rspiro", "yaml"))
  if (!identical(as.character(getRversion()), "4.5.1") ||
      !identical(as.character(utils::packageVersion("mice")), "3.19.0") ||
      !identical(as.character(utils::packageVersion("rspiro")), "0.5")) {
    iv_stop("Independent-validator R/package runtime drifted.")
  }
  manifests <- iv_validate_frozen_manifests(root)
  source(file.path(
    root, "R", "v45", "independent_mi_validation_helpers_v45.R"
  ))
  source(file.path(root, "R", "v45", "02_gli_functions_v45.R"))
  source(file.path(root, "R", "v45", "legacy_gli_reference_pure_v45.R"))
  input_contract_file <- iv_read_rds_stable(file.path(
    root, "derived_sensitive", "v45", "v45_production_mi_input_contract.rds"
  ))
  input_contract <- input_contract_file$data
  iv_assert_exact_names(
    input_contract,
    c(
      "contract_version", "hash_rule", "R_version", "RNGkind",
      "definitions_file_sha256", "objects"
    ),
    "Stage 3 input contract"
  )
  if (!identical(input_contract$contract_version, "v45_0_stage3") ||
      !identical(input_contract$hash_rule,
                 "canonical_UTF8_type_explicit_v1") ||
      !identical(input_contract$R_version, "4.5.1") ||
      !setequal(names(input_contract$objects), c("MI-B", "MI-G", "MI-S"))) {
    iv_stop("Stage 3 top-level input contract is invalid.")
  }
  definition_path <- file.path(
    root, "derived_sensitive", "v45", "v45_mi_object_definitions_v45.rds"
  )
  definitions_file <- iv_read_rds_stable(definition_path)
  if (!identical(
        definitions_file$sha256, input_contract$definitions_file_sha256
      )) {
    iv_stop("Stage 1 MI-object definition hash differs from Stage 3 contract.")
  }
  gate_path <- file.path(root, "work_v45", "gate_state_v45.yml")
  gate_file <- iv_read_yaml_stable(gate_path, "Stage 3 gate")
  gate <- gate_file$data
  allowed_execution <- c(
    "GENERATED_ALL_AWAITING_INDEPENDENT_VALIDATION",
    "INDEPENDENT_VALIDATION_PASS"
  )
  if (!identical(gate$stage3_production_mi_freeze$status, "PASS") ||
      !gate$stage3_production_mi_execution$status %in% allowed_execution ||
      !identical(gate$outcome_execution_allowed, FALSE) ||
      !identical(
        gate$new_mortality_coefficient_inspection_allowed, FALSE
      ) ||
      !identical(gate$production_m100_objects_allowed, FALSE)) {
    iv_stop("Global gate does not authorize independent m=50 validation.")
  }
  object_ids <- c("MI-B", "MI-G", "MI-S")
  object_results <- setNames(vector("list", length(object_ids)), object_ids)
  for (object_id in object_ids) {
    files <- iv_load_object_files(root, object_id)
    gate_object <- gate$stage3_production_mi_execution$objects[[object_id]]
    if (!is.list(gate_object) ||
        !identical(
          names(gate_object),
          c("status", "m", "run_id", "selected_maxit", "mids_sha256")
        ) ||
        !gate_object$status %in% c(
          "GENERATED_AWAITING_INDEPENDENT_VALIDATION",
          "INDEPENDENT_VALIDATION_PASS"
        ) ||
        !identical(as.integer(gate_object$m), 50L) ||
        !identical(gate_object$run_id, files$run_id) ||
        !identical(gate_object$mids_sha256, files$mids$sha256) ||
        !identical(
          as.integer(gate_object$selected_maxit),
          as.integer(files$manifest$data$selected_maxit)
        )) {
      iv_stop(object_id, " gate-object record differs from pointer/manifest.")
    }
    definition_name <- gsub("-", "_", object_id, fixed = TRUE)
    definition <- definitions_file$data[[definition_name]]
    if (is.null(definition) || !is.list(definition)) {
      iv_stop(object_id, " Stage 1 definition is absent.")
    }
    specification <- definition$specification
    contract <- input_contract$objects[[object_id]]
    schema <- iv_validate_mids_schema(
      files$mids$data, files$mids$data$data, specification,
      expected_object_id = object_id, expected_run_id = files$run_id,
      expected_selected_maxit = files$manifest$data$selected_maxit
    )
    contract_audit <- iv_validate_input_contract(
      object_id, files$mids$data, specification, contract, definition
    )
    diagnostics <- iv_load_diagnostics(files)
    manifest_row <- files$manifest$data
    final_table <- diagnostics$final$data
    manifest_checks <- c(
      denominator = identical(
        as.integer(manifest_row$denominator_n),
        as.integer(contract$denominator_n)
      ),
      event_anchor = identical(
        as.integer(manifest_row$event_anchor_n),
        as.integer(contract$event_anchor_n)
      ),
      response_anchor = identical(
        as.integer(manifest_row$response_anchor_n),
        as.integer(contract$response_anchor_n)
      ),
      selected_maxit = identical(
        as.integer(manifest_row$selected_maxit),
        as.integer(files$mids$data$iteration)
      ),
      hard_rows = identical(
        as.integer(manifest_row$hard_convergence_rows),
        as.integer(sum(final_table$hard_gate %in% TRUE))
      ),
      failed_hard_rows = identical(
        as.integer(manifest_row$failed_hard_convergence_rows),
        as.integer(sum(
          final_table$hard_gate %in% TRUE &
            !(final_table$pass %in% TRUE)
        ))
      )
    )
    if (!all(manifest_checks)) {
      iv_stop(
        object_id, " run-manifest anchors differ: ",
        paste(names(manifest_checks)[!manifest_checks], collapse = ", ")
      )
    }
    convergence <- iv_validate_convergence(
      files, diagnostics, specification
    )
    components <- iv_validate_component_hashes(
      files, diagnostics, specification,
      contract_audit$participant_ids, convergence$category$trace
    )
    completed <- iv_validate_completed_data(
      files, specification, diagnostics
    )
    gli <- iv_validate_passive_gli(files, diagnostics)
    suspicious <- c(
      list.files(files$result_dir, recursive = TRUE, full.names = FALSE),
      list.files(dirname(files$mids_path), recursive = TRUE, full.names = FALSE)
    )
    if (any(grepl(
          "(^|[/_.-])(completed|model[_-]?fit|coefficient|prediction|survey[_-]?design)([/_.-]|$)",
          suspicious, ignore.case = TRUE, perl = TRUE
        ))) {
      iv_stop(object_id, " selected run contains a forbidden artifact.")
    }
    object_results[[object_id]] <- list(
      files = files, schema = schema, contract = contract_audit,
      diagnostics = diagnostics, convergence = convergence,
      components = components, completed = completed, gli = gli
    )
  }
  random_seed_after <- get0(
    ".Random.seed", envir = .GlobalEnv, inherits = FALSE, ifnotfound = NULL
  )
  if (!identical(random_seed_before, random_seed_after)) {
    iv_stop("Independent validation changed the R random-number state.")
  }
  validation_rows <- do.call(rbind, lapply(object_ids, function(object_id) {
    result <- object_results[[object_id]]
    checks <- c(
      pointer_manifest_path_hash_schema = TRUE,
      frozen_input_and_specification_rebuilt = TRUE,
      mids_imp_missing_row_and_chain_mapping = TRUE,
      methods_predictor_where_values_normalization_visit_nmis_exact = TRUE,
      category_grid_simplex_and_final_state = result$convergence$category$pass,
      independent_rhat_hard_gates = all(
        result$convergence$independent$pass[
          result$convergence$independent$hard_gate %in% TRUE
        ] %in% TRUE
      ),
      final_between_imputation_variation = all(
        result$convergence$independent$pass[
          result$convergence$independent$parameter ==
            "final_between_imputation_variation"
        ] %in% TRUE
      ),
      observed_values_types_factors_and_ids = TRUE,
      passive_bmi_all_50 = identical(result$completed$bmi$status, "PASS"),
      passive_gli_all_50_or_not_applicable =
        !identical(object_id, "MI-G") ||
          identical(result$gli$status, "PASS"),
      no_completed_model_or_coefficient_artifacts = TRUE,
      component_hashes_bound_and_diagnostics_semantically_recomputed = TRUE
    )
    data.frame(
      object_id = object_id, check = names(checks),
      status = ifelse(checks, "PASS", "FAIL"),
      run_id = result$files$run_id, stringsAsFactors = FALSE
    )
  }))
  if (!all(validation_rows$status == "PASS")) {
    iv_stop("One or more independent validation rows failed.")
  }
  summary <- do.call(rbind, lapply(object_ids, function(object_id) {
    result <- object_results[[object_id]]
    data.frame(
      object_id = object_id, run_id = result$files$run_id,
      denominator_n = nrow(result$files$mids$data$data),
      m = as.integer(result$files$mids$data$m),
      selected_maxit = as.integer(result$files$mids$data$iteration),
      active_target_n = sum(nzchar(result$files$mids$data$method)),
      independent_hard_gate_n = sum(
        result$convergence$independent$hard_gate %in% TRUE
      ),
      maximum_independent_hard_rhat =
        result$convergence$maximum_hard_rhat,
      warning_count = 0L, logged_event_count = 0L,
      mortality_model_fit_count = 0L, coefficient_export_count = 0L,
      completed_dataset_persistence_count = 0L,
      mids_sha256 = result$files$mids$sha256,
      run_manifest_sha256 = result$files$manifest$sha256,
      component_hashes_sha256 = result$files$component$sha256,
      pointer_precommit_sha256 = result$files$pointer$sha256,
      status = "INDEPENDENT_VALIDATION_PASS",
      stringsAsFactors = FALSE
    )
  }))
  validation_path <- file.path(
    root, "results", "v45",
    "v45_production_mi_independent_validation.tsv"
  )
  summary_path <- file.path(
    root, "results", "v45",
    "v45_production_mi_independent_object_summary.tsv"
  )
  qa_path <- file.path(
    root, "output", "qa", "v45",
    "V45_STAGE3_PRODUCTION_MI_INDEPENDENT_VALIDATION_QA.md"
  )
  manifest_path <- file.path(
    root, "results", "v45",
    "v45_production_mi_independent_validation_output_manifest.tsv"
  )
  staging_dir <- file.path(
    root, "derived_sensitive", "v45", "production_mi",
    paste0(".independent_validation_staging_pid", Sys.getpid())
  )
  if (!dir.create(staging_dir, showWarnings = FALSE)) {
    iv_stop("Could not create independent-validation transaction staging.")
  }
  on.exit(if (dir.exists(staging_dir)) {
    unlink(staging_dir, recursive = TRUE)
  }, add = TRUE)
  staged_validation <- file.path(staging_dir, basename(validation_path))
  staged_summary <- file.path(staging_dir, basename(summary_path))
  staged_qa <- file.path(staging_dir, basename(qa_path))
  staged_manifest <- file.path(staging_dir, basename(manifest_path))
  iv_atomic_write_tsv(validation_rows, staged_validation)
  iv_atomic_write_tsv(summary, staged_summary)
  qa_lines <- c(
    "# V45 Stage 3 production-MI independent validation",
    "",
    "Status: **INDEPENDENT_VALIDATION_PASS**",
    "",
    paste0(
      "All ", nrow(validation_rows),
      " independent checks passed for MI-B, MI-G, and MI-S at m=50."
    ),
    "No imputation was generated, no random state changed, no outcome model was fitted, and no coefficient was released.",
    "",
    "| Object | N | m | selected maxit | maximum independent hard-gate R-hat |",
    "|---|---:|---:|---:|---:|",
    vapply(seq_len(nrow(summary)), function(index) {
      paste0(
        "| ", summary$object_id[[index]], " | ",
        summary$denominator_n[[index]], " | ", summary$m[[index]], " | ",
        summary$selected_maxit[[index]], " | ",
        sprintf("%.6f", summary$maximum_independent_hard_rhat[[index]]),
        " |"
      )
    }, character(1)),
    "",
    "Outcome execution and new mortality-coefficient inspection remain blocked."
  )
  iv_atomic_write_lines(qa_lines, staged_qa)
  output_aliases <- c(
    validation = "results/v45/v45_production_mi_independent_validation.tsv",
    object_summary =
      "results/v45/v45_production_mi_independent_object_summary.tsv",
    qa_report =
      "output/qa/v45/V45_STAGE3_PRODUCTION_MI_INDEPENDENT_VALIDATION_QA.md"
  )
  output_manifest <- data.frame(
    asset_id = names(output_aliases), path_alias = unname(output_aliases),
    bytes = vapply(
      c(staged_validation, staged_summary, staged_qa),
      function(path) as.numeric(file.info(path)$size), numeric(1)
    ),
    sha256 = vapply(
      c(staged_validation, staged_summary, staged_qa),
      iv_sha256_file, character(1)
    ),
    local_restricted = FALSE, stringsAsFactors = FALSE
  )
  iv_atomic_write_tsv(output_manifest, staged_manifest)
  manifest_sha <- iv_sha256_file(staged_manifest)
  staged_outputs <- c(
    validation = staged_validation, object_summary = staged_summary,
    qa_report = staged_qa, output_manifest = staged_manifest
  )
  final_outputs <- c(
    validation = validation_path, object_summary = summary_path,
    qa_report = qa_path, output_manifest = manifest_path
  )
  stable_inputs <- c(
    manifests$stable_files,
    setNames(
      as.character(manifests$code$data$sha256),
      normalizePath(manifests$code$data$path_private, mustWork = TRUE)
    ),
    setNames(
      c(
        manifests$code$sha256, manifests$functions$sha256,
        manifests$roots$sha256, input_contract_file$sha256,
        definitions_file$sha256
      ),
      c(
        file.path(root, "work_v45", "v45_production_mi_code_manifest.tsv"),
        file.path(root, "work_v45",
                  "v45_production_mi_function_manifest.tsv"),
        file.path(root, "work_v45",
                  "v45_production_mi_freeze_roots.tsv"),
        file.path(root, "derived_sensitive", "v45",
                  "v45_production_mi_input_contract.rds"),
        definition_path
      )
    )
  )
  for (object_id in object_ids) {
    result <- object_results[[object_id]]
    stable_inputs <- c(
      stable_inputs,
      setNames(
        c(
          result$files$pointer$sha256, result$files$manifest$sha256,
          result$files$component$sha256, result$files$mids$sha256,
          result$diagnostics$structural$sha256,
          result$diagnostics$checkpoint$sha256,
          result$diagnostics$final$sha256,
          result$diagnostics$trace$sha256,
          result$diagnostics$bmi$sha256,
          result$diagnostics$log_sha256
        ),
        c(
          result$files$pointer_path,
          file.path(result$files$result_dir, "run_manifest.tsv"),
          file.path(result$files$result_dir, "component_hashes.tsv"),
          result$files$mids_path,
          file.path(result$files$result_dir, "structural_checks.tsv"),
          file.path(result$files$result_dir, "checkpoint_diagnostics.tsv"),
          file.path(result$files$result_dir, "final_convergence.tsv"),
          file.path(result$files$result_dir, "released_chain_trace.tsv"),
          file.path(result$files$result_dir, "passive_bmi_audit.tsv"),
          file.path(result$files$result_dir, "run.log")
        )
      )
    )
    if (identical(object_id, "MI-G")) {
      stable_inputs <- c(
        stable_inputs,
        setNames(
          c(
            result$diagnostics$gli$sha256,
            result$diagnostics$gli_hashes$sha256
          ),
          c(
            file.path(result$files$result_dir, "passive_gli_audit.tsv"),
            file.path(result$files$result_dir, "passive_gli_hashes.tsv")
          )
        )
      )
    }
  }
  duplicate_paths <- unique(names(stable_inputs)[duplicated(names(stable_inputs))])
  if (length(duplicate_paths) && any(vapply(
        duplicate_paths,
        function(path) length(unique(stable_inputs[names(stable_inputs) == path])) != 1L,
        logical(1)
      ))) {
    iv_stop("A pre-commit input has conflicting recorded hashes.")
  }
  stable_inputs <- stable_inputs[!duplicated(names(stable_inputs))]
  if (any(!grepl("^[0-9a-f]{64}$", stable_inputs))) {
    iv_stop("Pre-commit stable-input hash ledger is invalid.")
  }
  iv_commit_validation(
    root, object_results, gate, gate_file$sha256, manifest_sha,
    staged_outputs, final_outputs, stable_inputs
  )
  message(
    "v45 Stage 3 MI-B/MI-G/MI-S m=50 independent validation PASS. ",
    "Outcome execution and coefficient inspection remain blocked."
  )
  invisible(TRUE)
}

if (sys.nframe() == 0L) {
  withCallingHandlers(
    main(),
    warning = function(w) {
      iv_stop(
        "Stage 3 independent-validator warning promoted to fatal: ",
        conditionMessage(w)
      )
    }
  )
}
