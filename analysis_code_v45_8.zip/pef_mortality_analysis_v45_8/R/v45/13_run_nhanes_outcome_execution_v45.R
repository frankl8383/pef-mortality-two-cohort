#!/usr/bin/env Rscript

# Execute the frozen v45 NHANES outcome modules.
#
# Coefficient-bearing intermediates remain in derived_sensitive until the
# independent Stage 4 validator releases aggregate tables. Logs and public
# state files contain module status and hashes only.

options(stringsAsFactors = FALSE, warn = 1)

stage4_root <- function() {
  args <- commandArgs(trailingOnly = FALSE)
  file_arg <- grep("^--file=", args, value = TRUE)
  if (!length(file_arg)) return(normalizePath(getwd(), mustWork = TRUE))
  script <- sub("^--file=", "", file_arg[[1L]])
  normalizePath(file.path(dirname(script), "..", ".."), mustWork = TRUE)
}

root <- stage4_root()
source(file.path(root, "R", "v45", "01_nhanes_common_utilities_v45.R"))
source(file.path(root, "R", "v45", "02_gli_functions_v45.R"))
source(file.path(root, "R", "v45", "11_nhanes_outcome_utilities_v45.R"))
v45_require_packages(root)
options(
  survey.lonely.psu = "adjust",
  survey.adjust.domain.lonely = TRUE,
  survey.replicates.mse = TRUE,
  survey.multicore = FALSE
)

args <- commandArgs(trailingOnly = TRUE)
arg_value <- function(prefix, default = NULL) {
  hit <- grep(paste0("^", prefix, "="), args, value = TRUE)
  if (!length(hit)) return(default)
  sub(paste0("^", prefix, "="), "", tail(hit, 1L))
}
module_requested <- arg_value(
  "--module", "all"
)
allowed_modules <- c(
  "standard", "paired-prefix", "paired-full",
  "ipw-prefix", "ipw-full", "all"
)
if (!module_requested %in% allowed_modules) {
  stop(
    "Unknown --module. Expected one of: ",
    paste(allowed_modules, collapse = ", "), call. = FALSE
  )
}
workers <- suppressWarnings(as.integer(arg_value("--workers", "4")))
if (!is.finite(workers) || workers < 1L || workers > 8L) {
  stop("--workers must be an integer from 1 to 8.", call. = FALSE)
}
workers <- min(workers, max(1L, parallel::detectCores() - 1L))

freeze_script <- file.path(
  root, "R", "v45", "12_freeze_nhanes_outcome_execution_v45.R"
)
freeze_verify <- system2(
  file.path(R.home("bin"), "Rscript"),
  c("--vanilla", freeze_script, "--verify"),
  stdout = TRUE, stderr = TRUE
)
freeze_status <- attr(freeze_verify, "status")
if (!is.null(freeze_status) && freeze_status != 0L) {
  stop(
    "Stage 4 freeze verification failed: ",
    paste(freeze_verify, collapse = " | "), call. = FALSE
  )
}

gate_path <- file.path(root, "work_v45", "gate_state_v45.yml")
gate <- yaml::read_yaml(gate_path)
gate_yes <- function(x) {
  isTRUE(x) ||
    tolower(as.character(x)) %in% c("yes", "true", "1")
}
gate_no <- function(x) {
  identical(x, FALSE) ||
    tolower(as.character(x)) %in% c("no", "false", "0")
}
if (
  !identical(gate$stage4_nhanes_outcome_freeze$status, "PASS") ||
  !gate_yes(gate$outcome_execution_allowed) ||
  !gate_no(gate$new_mortality_coefficient_inspection_allowed)
) {
  stop("Stage 4 semantic gates do not authorize restricted execution.",
       call. = FALSE)
}

contract_path <- file.path(
  root, "derived_sensitive", "v45",
  "v45_nhanes_outcome_execution_contract.rds"
)
contract <- readRDS(contract_path)
if (
  !identical(contract$contract_version, "v45_0_stage4") ||
  contract$coefficient_generation_count != 0L ||
  contract$coefficient_export_count != 0L
) {
  stop("Stage 4 restricted contract is invalid.", call. = FALSE)
}

public_root <- file.path(root, "results", "v45", "outcome_execution")
restricted_root <- file.path(
  root, "derived_sensitive", "v45", "outcome_execution", "m50"
)
log_root <- file.path(root, "logs", "v45", "outcome_execution")
dir.create(public_root, recursive = TRUE, showWarnings = FALSE)
dir.create(restricted_root, recursive = TRUE, showWarnings = FALSE)
dir.create(log_root, recursive = TRUE, showWarnings = FALSE)
current_path <- file.path(public_root, "v45_stage4_restricted_current.tsv")

read_tsv <- function(path) {
  utils::read.delim(
    path, stringsAsFactors = FALSE, check.names = FALSE,
    na.strings = c("", "NA")
  )
}

run_id_arg <- arg_value("--run-id", NULL)
if (!is.null(run_id_arg) && !grepl(
  "^v45_nhanes_outcome_m50_[0-9]{8}T[0-9]{6}_pid[0-9]+$",
  run_id_arg
)) {
  stop("Unsafe or invalid --run-id.", call. = FALSE)
}

if (!is.null(run_id_arg)) {
  run_id <- run_id_arg
} else if (file.exists(current_path)) {
  current <- read_tsv(current_path)
  if (nrow(current) != 1L ||
      !grepl("^v45_nhanes_outcome_m50_", current$run_id[[1L]])) {
    stop("Current restricted-run pointer is invalid.", call. = FALSE)
  }
  run_id <- current$run_id[[1L]]
} else {
  run_id <- paste0(
    "v45_nhanes_outcome_m50_",
    format(Sys.time(), "%Y%m%dT%H%M%S"), "_pid", Sys.getpid()
  )
}

run_dir <- file.path(restricted_root, run_id)
state_dir <- file.path(public_root, run_id)
dir.create(run_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(state_dir, recursive = TRUE, showWarnings = FALSE)
log_path <- file.path(log_root, paste0(run_id, ".log"))
state_path <- file.path(state_dir, "module_state.tsv")

log_lines <- if (file.exists(log_path)) readLines(log_path, warn = FALSE) else c(
  paste0("run_id: ", run_id),
  "coefficient_visibility: restricted",
  "row_level_output: forbidden",
  paste0("workers: ", workers)
)
append_log <- function(text) {
  line <- paste0(
    format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z"), " ", text
  )
  log_lines <<- c(log_lines, line)
  v45_atomic_write_lines(log_lines, log_path)
  message(text)
}

state <- if (file.exists(state_path)) {
  read_tsv(state_path)
} else {
  data.frame(
    module = c(
      "standard", "paired-prefix", "paired-full",
      "ipw-prefix", "ipw-full"
    ),
    status = "NOT_RUN",
    output_path_alias = NA_character_,
    output_sha256 = NA_character_,
    completed_at = NA_character_,
    stringsAsFactors = FALSE
  )
}
if (!identical(
  state$module,
  c("standard", "paired-prefix", "paired-full", "ipw-prefix", "ipw-full")
)) {
  stop("Restricted module state schema drifted.", call. = FALSE)
}

module_alias <- function(module) {
  file.path(
    "derived_sensitive", "v45", "outcome_execution", "m50", run_id,
    paste0(gsub("-", "_", module, fixed = TRUE), "_restricted.rds")
  )
}

module_path <- function(module) file.path(root, module_alias(module))

publish_module <- function(module, object) {
  path <- module_path(module)
  if (file.exists(path)) {
    stop("Refusing to overwrite restricted module output: ", path,
         call. = FALSE)
  }
  v45_atomic_save_rds(object, path)
  row <- match(module, state$module)
  state$status[[row]] <<- "RESTRICTED_COMPLETE"
  state$output_path_alias[[row]] <<- module_alias(module)
  state$output_sha256[[row]] <<- v45_sha256_file(path)
  state$completed_at[[row]] <<- format(
    Sys.time(), "%Y-%m-%dT%H:%M:%S%z"
  )
  v45_atomic_write_tsv(state, state_path)
  pointer <- data.frame(
    run_id = run_id,
    state_path_alias = substring(state_path, nchar(root) + 2L),
    state_sha256 = v45_sha256_file(state_path),
    coefficient_visibility = "RESTRICTED",
    independent_validation_status = "NOT_RUN",
    stringsAsFactors = FALSE
  )
  v45_atomic_write_tsv(pointer, current_path)
  append_log(paste0(
    module, " completed; restricted SHA-256=",
    state$output_sha256[[row]]
  ))
  invisible(path)
}

read_module <- function(module) {
  row <- match(module, state$module)
  if (
    is.na(row) ||
    !identical(state$status[[row]], "RESTRICTED_COMPLETE") ||
    is.na(state$output_path_alias[[row]]) ||
    is.na(state$output_sha256[[row]])
  ) {
    stop(module, " prerequisite is not complete.", call. = FALSE)
  }
  path <- file.path(root, state$output_path_alias[[row]])
  if (!file.exists(path) ||
      !identical(v45_sha256_file(path), state$output_sha256[[row]])) {
    stop(module, " restricted output hash no longer verifies.",
         call. = FALSE)
  }
  readRDS(path)
}

load_mids <- function(object_id) {
  pointer_path <- file.path(
    root, "results", "v45", "production_mi",
    paste0(gsub("-", "_", object_id, fixed = TRUE), "_m50_current.tsv")
  )
  pointer <- read_tsv(pointer_path)
  path <- file.path(root, pointer$mids_path_alias[[1L]])
  expected <- contract$mids$sha256[
    contract$mids$object_id == object_id
  ]
  if (
    nrow(pointer) != 1L ||
    pointer$requested_m[[1L]] != 50L ||
    !identical(pointer$status[[1L]], "INDEPENDENT_VALIDATION_PASS") ||
    !identical(v45_sha256_file(path), expected)
  ) {
    stop(object_id, " mids no longer matches the frozen contract.",
         call. = FALSE)
  }
  readRDS(path)
}

ledger <- v45_read_nhanes_ledger(root)
v43 <- v45_load_v43_nhanes_functions(root)
rw <- readRDS(file.path(
  root, "derived_sensitive", "v45",
  "v45_rao_wu_replicate_contract.rds"
))
design_data <- v45_outcome_design_data(ledger, rw)

parallel_map <- function(indices, fun, label) {
  append_log(paste0(
    label, " started for ", length(indices),
    " imputations with ", workers, " worker(s)."
  ))
  wrapper <- function(i) {
    tryCatch(
      list(ok = TRUE, value = fun(i), error = ""),
      error = function(e) list(
        ok = FALSE, value = NULL, error = conditionMessage(e)
      )
    )
  }
  result <- if (workers == 1L) {
    lapply(indices, wrapper)
  } else {
    parallel::mclapply(
      indices, wrapper, mc.cores = workers,
      mc.preschedule = FALSE, mc.set.seed = FALSE
    )
  }
  failed <- !vapply(result, `[[`, logical(1), "ok")
  if (any(failed)) {
    stop(
      label, " failed for imputation(s) ",
      paste(indices[failed], collapse = ", "), ": ",
      paste(
        vapply(result[failed], `[[`, character(1), "error"),
        collapse = " | "
      ),
      call. = FALSE
    )
  }
  append_log(paste0(label, " finished for all imputations."))
  lapply(result, `[[`, "value")
}

pool_qu_table <- function(per_imputation) {
  keys <- unique(per_imputation[c(
    "analysis_id", "term", "mi_object", "module", "variant"
  )])
  rows <- lapply(seq_len(nrow(keys)), function(i) {
    key <- keys[i, , drop = FALSE]
    use <- rep(TRUE, nrow(per_imputation))
    for (field in names(key)) {
      value <- key[[field]][[1L]]
      if (is.na(value)) {
        use <- use & is.na(per_imputation[[field]])
      } else {
        use <- use & per_imputation[[field]] == value
      }
    }
    data <- per_imputation[use, , drop = FALSE]
    data <- data[order(data$imputation), , drop = FALSE]
    if (
      nrow(data) != 50L ||
      !identical(data$imputation, seq_len(50L))
    ) {
      stop(
        "Pooling key ", key$analysis_id, "/", key$term,
        " does not contain all 50 imputations.", call. = FALSE
      )
    }
    pooled <- v45_pool_scalar_qu(
      data$estimate, data$within_variance,
      complete_data_df = min(data$design_df)
    )
    cbind(key, pooled)
  })
  dplyr::bind_rows(rows)
}

fit_rows <- function(
    fit, analysis_id, terms, imputation, mi_object, module,
    variant = NA_character_) {
  if (!length(terms)) {
    return(data.frame(
      analysis_id = character(), term = character(),
      mi_object = character(), module = character(),
      variant = character(), imputation = integer(),
      estimate = numeric(), within_variance = numeric(),
      design_df = numeric(), stringsAsFactors = FALSE
    ))
  }
  missing <- setdiff(terms, names(fit$coefficients))
  if (length(missing)) {
    stop(
      analysis_id, " lacks focal term(s): ",
      paste(missing, collapse = ", "), call. = FALSE
    )
  }
  data.frame(
    analysis_id = analysis_id,
    term = terms,
    mi_object = mi_object,
    module = module,
    variant = variant,
    imputation = as.integer(imputation),
    estimate = unname(fit$coefficients[terms]),
    within_variance = unname(diag(fit$variance)[
      match(terms, names(fit$coefficients))
    ]),
    design_df = as.numeric(fit$diagnostics$design_df[[1L]]),
    stringsAsFactors = FALSE
  )
}

run_standard <- function() {
  if (state$status[state$module == "standard"] != "NOT_RUN") {
    stop("standard was already attempted for this run.", call. = FALSE)
  }
  mib <- load_mids("MI-B")
  mig <- load_mids("MI-G")
  if (mib$m != 50L || mig$m != 50L) {
    stop("Standard modules require exact m=50 mids objects.",
         call. = FALSE)
  }
  anchor_results <- parallel_map(seq_len(50L), function(i) {
    completed <- v45_prepare_mib_completed(
      mice::complete(mib, action = i), ledger, v43
    )
    merged <- v45_merge_completed_design(design_data, completed)
    design <- v45_make_taylor_design(merged)
    rows <- list()
    diagnostics <- list()
    for (tier in c("A0", "A1", "A2")) {
      analysis_id <- paste0("v45_anchor_nhanes_", tolower(tier))
      fit <- v45_fit_taylor_cox_prebuilt(
        merged, design, merged$analysis_domain,
        v45_outcome_formula("E0", tier),
        paste0(analysis_id, "_imp", i)
      )
      rows[[tier]] <- fit_rows(
        fit, analysis_id, "E0", i, "MI-B", "anchor"
      )
      fit$diagnostics$analysis_id <- analysis_id
      fit$diagnostics$imputation <- i
      diagnostics[[tier]] <- fit$diagnostics
    }
    list(
      coefficients = dplyr::bind_rows(rows),
      diagnostics = dplyr::bind_rows(diagnostics)
    )
  }, "MI-B A0/A1/A2")
  rm(mib)
  invisible(gc(verbose = FALSE))

  g_exposures <- v45_outcome_g_exposures()
  gli_results <- parallel_map(seq_len(50L), function(i) {
    completed <- v45_prepare_mig_completed(
      mice::complete(mig, action = i), ledger, v43
    )
    merged <- v45_merge_completed_design(design_data, completed)
    design <- v45_make_taylor_design(merged)
    rows <- list()
    diagnostics <- list()
    for (analysis_id in names(g_exposures)) {
      terms <- g_exposures[[analysis_id]]
      fit <- v45_fit_taylor_cox_prebuilt(
        merged, design, merged$analysis_domain,
        v45_outcome_formula(terms, "A1"),
        paste0(analysis_id, "_imp", i)
      )
      rows[[analysis_id]] <- fit_rows(
        fit, analysis_id, terms, i, "MI-G", "GLI_same_sample"
      )
      fit$diagnostics$analysis_id <- analysis_id
      fit$diagnostics$imputation <- i
      diagnostics[[analysis_id]] <- fit$diagnostics
    }
    reference_specs <- list(
      v45_gli_ref_2022 =
        completed$gli_global2022_all_three_within_reference == 1L,
      v45_gli_ref_2012 =
        completed$gli2012_all_three_within_reference == 1L
    )
    for (analysis_id in names(reference_specs)) {
      domain <- merged$analysis_domain
      local_flag <- reference_specs[[analysis_id]]
      domain[merged$analysis_domain] <- local_flag
      terms <- c("E0", "L_FEV1", "L_RATIO")
      fit <- v45_fit_taylor_cox_prebuilt(
        merged, design, domain,
        v45_outcome_formula(terms, "A1"),
        paste0(analysis_id, "_imp", i)
      )
      rows[[analysis_id]] <- fit_rows(
        fit, analysis_id, terms, i, "MI-G", "GLI_reference_range"
      )
      fit$diagnostics$analysis_id <- analysis_id
      fit$diagnostics$imputation <- i
      diagnostics[[analysis_id]] <- fit$diagnostics
    }
    list(
      coefficients = dplyr::bind_rows(rows),
      diagnostics = dplyr::bind_rows(diagnostics)
    )
  }, "MI-G same-sample and reference-range models")
  rm(mig)
  invisible(gc(verbose = FALSE))
  per <- dplyr::bind_rows(
    lapply(anchor_results, `[[`, "coefficients"),
    lapply(gli_results, `[[`, "coefficients")
  )
  diagnostics <- dplyr::bind_rows(
    lapply(anchor_results, `[[`, "diagnostics"),
    lapply(gli_results, `[[`, "diagnostics")
  )
  pooled <- pool_qu_table(per)
  object <- list(
    schema_version = "v45_0_stage4_standard_restricted",
    run_id = run_id,
    created_at_utc = format(
      Sys.time(), tz = "UTC", format = "%Y-%m-%dT%H:%M:%SZ"
    ),
    freeze_contract_sha256 = v45_sha256_file(contract_path),
    coefficient_visibility = "RESTRICTED",
    completed_dataset_saved = FALSE,
    model_object_saved = FALSE,
    row_level_data_saved = FALSE,
    per_imputation = per,
    pooled = pooled,
    diagnostics = diagnostics
  )
  publish_module("standard", object)
}

rw_domain_weights <- function(
    completed, module_id, replicate_index = NULL) {
  merged <- v45_merge_completed_design(design_data, completed)
  domain_rows <- which(merged$analysis_domain)
  full_cluster_index <- rw$full_design_cluster_index[domain_rows]
  base <- rw$full_design_pweights[domain_rows]
  if (is.null(replicate_index)) {
    weight <- base
  } else {
    weight <- base * rw$modules[[module_id]]$matrix[
      full_cluster_index, replicate_index
    ]
  }
  list(
    data = merged[domain_rows, , drop = FALSE],
    weight = as.numeric(weight),
    full_rows = domain_rows,
    cluster_index = full_cluster_index,
    base_weight = as.numeric(base)
  )
}

paired_one_imputation <- function(
    mig, imputation, replicate_indices, prefix_object = NULL) {
  completed <- v45_prepare_mig_completed(
    mice::complete(mig, action = imputation), ledger, v43
  )
  domain <- rw_domain_weights(completed, "RW-GLI")
  formula_g1 <- v45_outcome_formula("E0", "A1")
  formula_g6a <- v45_outcome_formula(
    c("E0", "L_FEV1", "L_RATIO"), "A1"
  )
  point_g1 <- v45_weighted_cox_coefficients(
    domain$data, domain$base_weight, formula_g1, "E0",
    paste0("paired_g1_point_imp", imputation)
  )[[1L]]
  point_g6a <- v45_weighted_cox_coefficients(
    domain$data, domain$base_weight, formula_g6a, "E0",
    paste0("paired_g6a_point_imp", imputation)
  )[[1L]]
  point <- c(
    G1_E0 = unname(point_g1),
    G6a_E0 = unname(point_g6a),
    G6a_minus_G1 = unname(point_g6a - point_g1)
  )
  new_replicates <- matrix(
    NA_real_, nrow = length(replicate_indices), ncol = 3L,
    dimnames = list(
      paste0("rep", replicate_indices),
      names(point)
    )
  )
  errors <- character()
  for (j in seq_along(replicate_indices)) {
    r <- replicate_indices[[j]]
    weight <- domain$base_weight *
      rw$modules[["RW-GLI"]]$matrix[domain$cluster_index, r]
    value <- tryCatch({
      g1 <- v45_weighted_cox_coefficients(
        domain$data, weight, formula_g1, "E0",
        paste0("paired_g1_imp", imputation, "_rep", r)
      )[[1L]]
      g6a <- v45_weighted_cox_coefficients(
        domain$data, weight, formula_g6a, "E0",
        paste0("paired_g6a_imp", imputation, "_rep", r)
      )[[1L]]
      c(G1_E0 = g1, G6a_E0 = g6a, G6a_minus_G1 = g6a - g1)
    }, error = function(e) {
      errors <<- c(errors, conditionMessage(e))
      rep(NA_real_, 3L)
    })
    new_replicates[j, ] <- value
  }
  if (is.null(prefix_object)) {
    all_replicates <- new_replicates
  } else {
    if (
      !identical(prefix_object$imputation, as.integer(imputation)) ||
      !identical(rownames(prefix_object$replicates), paste0("rep", 1:250))
    ) {
      stop("Paired prefix object does not match its imputation.",
           call. = FALSE)
    }
    all_replicates <- rbind(prefix_object$replicates, new_replicates)
  }
  replicate_count <- nrow(all_replicates)
  variance <- v45_replicate_variance(
    all_replicates[, "G6a_minus_G1"],
    point[["G6a_minus_G1"]], replicate_count
  )
  list(
    imputation = as.integer(imputation),
    point = point,
    replicates = all_replicates,
    within_variance = variance$variance,
    valid_fraction = variance$valid_fraction,
    valid_n = variance$valid_n,
    error_count = length(errors),
    unique_error_count = length(unique(errors))
  )
}

paired_pool <- function(results) {
  per <- dplyr::bind_rows(lapply(results, function(x) {
    data.frame(
      analysis_id = "v45_paired_g6a_minus_g1",
      term = "G6a_minus_G1",
      mi_object = "MI-G",
      module = "paired_GLI",
      variant = NA_character_,
      imputation = x$imputation,
      estimate = unname(x$point[["G6a_minus_G1"]]),
      within_variance = x$within_variance,
      design_df = 49,
      valid_replicate_fraction = x$valid_fraction,
      valid_replicate_n = x$valid_n,
      replicate_error_count = x$error_count,
      stringsAsFactors = FALSE
    )
  }))
  list(per_imputation = per, pooled = pool_qu_table(per))
}

run_paired_prefix <- function() {
  if (state$status[state$module == "paired-prefix"] != "NOT_RUN") {
    stop("paired-prefix was already attempted.", call. = FALSE)
  }
  mig <- load_mids("MI-G")
  results <- parallel_map(seq_len(50L), function(i) {
    paired_one_imputation(mig, i, seq_len(250L))
  }, "MI-G paired first-250 Rao-Wu replicates")
  pooled <- paired_pool(results)
  minimum_valid <- min(pooled$per_imputation$valid_replicate_fraction)
  object <- list(
    schema_version = "v45_0_stage4_paired_prefix_restricted",
    run_id = run_id,
    created_at_utc = format(
      Sys.time(), tz = "UTC", format = "%Y-%m-%dT%H:%M:%SZ"
    ),
    replicate_indices = seq_len(250L),
    freeze_contract_sha256 = v45_sha256_file(contract_path),
    coefficient_visibility = "RESTRICTED",
    row_level_data_saved = FALSE,
    results = results,
    per_imputation = pooled$per_imputation,
    pooled = pooled$pooled,
    minimum_valid_replicate_fraction = minimum_valid,
    prefix_gate = if (minimum_valid >= 0.90) "PASS" else "STOP"
  )
  publish_module("paired-prefix", object)
  if (minimum_valid < 0.90) {
    stop(
      "Paired first-250 valid replicate fraction is below 0.90; ",
      "full paired execution is blocked.", call. = FALSE
    )
  }
}

run_paired_full <- function() {
  if (state$status[state$module == "paired-full"] != "NOT_RUN") {
    stop("paired-full was already attempted.", call. = FALSE)
  }
  prefix <- read_module("paired-prefix")
  if (
    !identical(prefix$prefix_gate, "PASS") ||
    !identical(prefix$replicate_indices, seq_len(250L))
  ) {
    stop("Paired prefix did not authorize columns 251-500.",
         call. = FALSE)
  }
  mig <- load_mids("MI-G")
  results <- parallel_map(seq_len(50L), function(i) {
    paired_one_imputation(
      mig, i, 251:500, prefix_object = prefix$results[[i]]
    )
  }, "MI-G paired Rao-Wu columns 251-500")
  pooled <- paired_pool(results)
  object <- list(
    schema_version = "v45_0_stage4_paired_full_restricted",
    run_id = run_id,
    created_at_utc = format(
      Sys.time(), tz = "UTC", format = "%Y-%m-%dT%H:%M:%SZ"
    ),
    replicate_indices = seq_len(500L),
    prefix_sha256 = state$output_sha256[
      state$module == "paired-prefix"
    ],
    freeze_contract_sha256 = v45_sha256_file(contract_path),
    coefficient_visibility = "RESTRICTED",
    row_level_data_saved = FALSE,
    results = results,
    per_imputation = pooled$per_imputation,
    pooled = pooled$pooled,
    minimum_valid_replicate_fraction =
      min(pooled$per_imputation$valid_replicate_fraction)
  )
  publish_module("paired-full", object)
}

ipw_compact_diagnostics <- function(
    diagnostics, imputation, response_specification) {
  probability <- diagnostics$probability
  availability <- diagnostics$availability
  variant <- diagnostics$variants
  variant$imputation <- as.integer(imputation)
  variant$response_specification <- response_specification
  list(
    summary = data.frame(
      imputation = as.integer(imputation),
      response_specification = response_specification,
      probability_min = min(probability),
      probability_p01 = as.numeric(stats::quantile(
        probability, 0.01, names = FALSE, type = 7
      )),
      probability_p99 = as.numeric(stats::quantile(
        probability, 0.99, names = FALSE, type = 7
      )),
      probability_max = max(probability),
      availability_p99 = as.numeric(stats::quantile(
        availability, 0.99, names = FALSE, type = 7
      )),
      availability_max = max(availability),
      cap_p99 = unname(diagnostics$caps[["cap_p99"]]),
      cap_p975 = unname(diagnostics$caps[["cap_p975"]]),
      response_matrix_columns = diagnostics$response_matrix_columns,
      response_matrix_rank = diagnostics$response_matrix_rank,
      stringsAsFactors = FALSE
    ),
    variants = variant
  )
}

ipw_one_imputation <- function(
    mis, imputation, replicate_indices, prefix_object = NULL) {
  completed <- v45_prepare_mis_completed(
    mice::complete(mis, action = imputation), ledger, v43
  )
  full_rows <- match(
    as.integer(completed$SEQN), design_data$SEQN
  )
  if (anyNA(full_rows)) {
    stop("MI-S target IDs are absent from the full MEC design.",
         call. = FALSE)
  }
  base_weight <- as.numeric(rw$full_design_pweights[full_rows])
  cluster_index <- rw$full_design_cluster_index[full_rows]
  point_primary <- v45_ipw_theta(
    completed, base_weight, outcome_augmented = FALSE,
    variants = c("original", "uncapped", "cap_p99", "cap_p975"),
    model_id = paste0("ipw_primary_point_imp", imputation)
  )
  point_augmented <- v45_ipw_theta(
    completed, base_weight, outcome_augmented = TRUE,
    variants = "uncapped",
    model_id = paste0("ipw_augmented_point_imp", imputation)
  )
  point <- c(
    primary_original = point_primary[["original"]],
    primary_uncapped = point_primary[["uncapped"]],
    primary_cap_p99 = point_primary[["cap_p99"]],
    primary_cap_p975 = point_primary[["cap_p975"]],
    augmented_uncapped = point_augmented[["uncapped"]]
  )
  primary_diagnostics <- ipw_compact_diagnostics(
    v45_ipw_balance_diagnostics(
      completed, base_weight, outcome_augmented = FALSE
    ),
    imputation, "primary"
  )
  augmented_diagnostics <- ipw_compact_diagnostics(
    v45_ipw_balance_diagnostics(
      completed, base_weight, outcome_augmented = TRUE
    ),
    imputation, "outcome_augmented"
  )
  new_replicates <- matrix(
    NA_real_, nrow = length(replicate_indices), ncol = length(point),
    dimnames = list(paste0("rep", replicate_indices), names(point))
  )
  primary_errors <- character()
  augmented_errors <- character()
  for (j in seq_along(replicate_indices)) {
    r <- replicate_indices[[j]]
    weight <- base_weight *
      rw$modules[["RW-IPW"]]$matrix[cluster_index, r]
    primary <- tryCatch(
      v45_ipw_theta(
        completed, weight, outcome_augmented = FALSE,
        variants = c("original", "uncapped", "cap_p99", "cap_p975"),
        model_id = paste0("ipw_primary_imp", imputation, "_rep", r)
      ),
      error = function(e) {
        primary_errors <<- c(primary_errors, conditionMessage(e))
        setNames(rep(NA_real_, 4L), c(
          "original", "uncapped", "cap_p99", "cap_p975"
        ))
      }
    )
    augmented <- tryCatch(
      v45_ipw_theta(
        completed, weight, outcome_augmented = TRUE,
        variants = "uncapped",
        model_id = paste0("ipw_augmented_imp", imputation, "_rep", r)
      ),
      error = function(e) {
        augmented_errors <<- c(
          augmented_errors, conditionMessage(e)
        )
        setNames(NA_real_, "uncapped")
      }
    )
    new_replicates[j, ] <- c(
      primary_original = primary[["original"]],
      primary_uncapped = primary[["uncapped"]],
      primary_cap_p99 = primary[["cap_p99"]],
      primary_cap_p975 = primary[["cap_p975"]],
      augmented_uncapped = augmented[["uncapped"]]
    )
  }
  if (is.null(prefix_object)) {
    all_replicates <- new_replicates
  } else {
    if (
      !identical(prefix_object$imputation, as.integer(imputation)) ||
      !identical(rownames(prefix_object$replicates), paste0("rep", 1:250))
    ) {
      stop("IPW prefix object does not match its imputation.",
           call. = FALSE)
    }
    all_replicates <- rbind(prefix_object$replicates, new_replicates)
  }
  replicate_count <- nrow(all_replicates)
  variance <- lapply(names(point), function(term) {
    v45_replicate_variance(
      all_replicates[, term], point[[term]], replicate_count
    )
  })
  names(variance) <- names(point)
  list(
    imputation = as.integer(imputation),
    point = point,
    replicates = all_replicates,
    within_variance = vapply(
      variance, `[[`, numeric(1), "variance"
    ),
    valid_fraction = vapply(
      variance, `[[`, numeric(1), "valid_fraction"
    ),
    valid_n = vapply(variance, `[[`, numeric(1), "valid_n"),
    primary_error_count = length(primary_errors),
    primary_unique_error_count = length(unique(primary_errors)),
    augmented_error_count = length(augmented_errors),
    augmented_unique_error_count = length(unique(augmented_errors)),
    response_summary = dplyr::bind_rows(
      primary_diagnostics$summary, augmented_diagnostics$summary
    ),
    balance = dplyr::bind_rows(
      primary_diagnostics$variants, augmented_diagnostics$variants
    )
  )
}

ipw_pool <- function(results) {
  per <- dplyr::bind_rows(lapply(results, function(x) {
    terms <- names(x$point)
    data.frame(
      analysis_id = "v45_ipw_a1",
      term = "E0",
      mi_object = "MI-S",
      module = "observation_IPW",
      variant = terms,
      imputation = x$imputation,
      estimate = unname(x$point),
      within_variance = unname(x$within_variance[terms]),
      design_df = 49,
      valid_replicate_fraction = unname(x$valid_fraction[terms]),
      valid_replicate_n = unname(x$valid_n[terms]),
      replicate_error_count = c(
        rep(x$primary_error_count, 4L),
        x$augmented_error_count
      ),
      stringsAsFactors = FALSE
    )
  }))
  list(
    per_imputation = per,
    pooled = pool_qu_table(per),
    response_summary = dplyr::bind_rows(lapply(
      results, `[[`, "response_summary"
    )),
    balance = dplyr::bind_rows(lapply(results, `[[`, "balance"))
  )
}

run_ipw_prefix <- function() {
  if (state$status[state$module == "ipw-prefix"] != "NOT_RUN") {
    stop("ipw-prefix was already attempted.", call. = FALSE)
  }
  mis <- load_mids("MI-S")
  results <- parallel_map(seq_len(50L), function(i) {
    ipw_one_imputation(mis, i, seq_len(250L))
  }, "MI-S IPW first-250 Rao-Wu replicates")
  pooled <- ipw_pool(results)
  minimum_valid <- min(pooled$per_imputation$valid_replicate_fraction)
  object <- list(
    schema_version = "v45_0_stage4_ipw_prefix_restricted",
    run_id = run_id,
    created_at_utc = format(
      Sys.time(), tz = "UTC", format = "%Y-%m-%dT%H:%M:%SZ"
    ),
    replicate_indices = seq_len(250L),
    freeze_contract_sha256 = v45_sha256_file(contract_path),
    coefficient_visibility = "RESTRICTED",
    row_level_data_saved = FALSE,
    results = results,
    per_imputation = pooled$per_imputation,
    pooled = pooled$pooled,
    response_summary = pooled$response_summary,
    balance = pooled$balance,
    minimum_valid_replicate_fraction = minimum_valid,
    prefix_gate = if (minimum_valid >= 0.90) "PASS" else "STOP"
  )
  publish_module("ipw-prefix", object)
  if (minimum_valid < 0.90) {
    stop(
      "IPW first-250 valid replicate fraction is below 0.90; ",
      "full IPW execution is blocked.", call. = FALSE
    )
  }
}

run_ipw_full <- function() {
  if (state$status[state$module == "ipw-full"] != "NOT_RUN") {
    stop("ipw-full was already attempted.", call. = FALSE)
  }
  prefix <- read_module("ipw-prefix")
  if (
    !identical(prefix$prefix_gate, "PASS") ||
    !identical(prefix$replicate_indices, seq_len(250L))
  ) {
    stop("IPW prefix did not authorize columns 251-500.",
         call. = FALSE)
  }
  mis <- load_mids("MI-S")
  results <- parallel_map(seq_len(50L), function(i) {
    ipw_one_imputation(
      mis, i, 251:500, prefix_object = prefix$results[[i]]
    )
  }, "MI-S IPW Rao-Wu columns 251-500")
  pooled <- ipw_pool(results)
  object <- list(
    schema_version = "v45_0_stage4_ipw_full_restricted",
    run_id = run_id,
    created_at_utc = format(
      Sys.time(), tz = "UTC", format = "%Y-%m-%dT%H:%M:%SZ"
    ),
    replicate_indices = seq_len(500L),
    prefix_sha256 = state$output_sha256[
      state$module == "ipw-prefix"
    ],
    freeze_contract_sha256 = v45_sha256_file(contract_path),
    coefficient_visibility = "RESTRICTED",
    row_level_data_saved = FALSE,
    results = results,
    per_imputation = pooled$per_imputation,
    pooled = pooled$pooled,
    response_summary = pooled$response_summary,
    balance = pooled$balance,
    minimum_valid_replicate_fraction =
      min(pooled$per_imputation$valid_replicate_fraction)
  )
  publish_module("ipw-full", object)
}

dispatch <- switch(
  module_requested,
  standard = list(run_standard),
  `paired-prefix` = list(run_paired_prefix),
  `paired-full` = list(run_paired_full),
  `ipw-prefix` = list(run_ipw_prefix),
  `ipw-full` = list(run_ipw_full),
  all = list(
    run_standard, run_paired_prefix, run_paired_full,
    run_ipw_prefix, run_ipw_full
  )
)

append_log(paste0("Requested module: ", module_requested))
for (fun in dispatch) fun()

append_log("Requested restricted execution completed.")
cat("V45_STAGE4_RESTRICTED_EXECUTION_COMPLETE\n")
cat("run_id=", run_id, "\n", sep = "")
cat("coefficient_visibility=RESTRICTED\n")
cat("independent_validation_status=NOT_RUN\n")
