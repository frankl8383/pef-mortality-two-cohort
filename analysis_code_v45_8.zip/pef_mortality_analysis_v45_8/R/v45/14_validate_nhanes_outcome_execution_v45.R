#!/usr/bin/env Rscript

# Independently validate and release aggregate v45 NHANES outcome results.
#
# Until every object-level m=50 Monte Carlo-error gate passes, this script
# keeps coefficient-bearing outputs restricted. It never writes row-level
# data, completed imputations, or fitted model objects.

options(stringsAsFactors = FALSE, warn = 1)

stage4_root <- function() {
  args <- commandArgs(trailingOnly = FALSE)
  file_arg <- grep("^--file=", args, value = TRUE)
  if (!length(file_arg)) return(normalizePath(getwd(), mustWork = TRUE))
  script <- sub("^--file=", "", file_arg[[1L]])
  normalizePath(file.path(dirname(script), "..", ".."), mustWork = TRUE)
}

root <- stage4_root()
source(file.path(root, "R", "v45", "01_nhanes_common_utilities_v45.R"))
source(file.path(root, "R", "v45", "11_nhanes_outcome_utilities_v45.R"))
v45_require_packages(root)

gate_yes <- function(x) {
  isTRUE(x) ||
    tolower(as.character(x)) %in% c("yes", "true", "1")
}
gate_no <- function(x) {
  identical(x, FALSE) ||
    tolower(as.character(x)) %in% c("no", "false", "0")
}

freeze_script <- file.path(
  root, "R", "v45", "12_freeze_nhanes_outcome_execution_v45.R"
)
freeze_verify <- system2(
  file.path(R.home("bin"), "Rscript"),
  c("--vanilla", freeze_script, "--verify"),
  stdout = TRUE, stderr = TRUE
)
freeze_status <- attr(freeze_verify, "status")
if (!is.null(freeze_status) && freeze_status != 0L) {
  stop(
    "Stage 4 freeze verification failed: ",
    paste(freeze_verify, collapse = " | "), call. = FALSE
  )
}

public_root <- file.path(root, "results", "v45", "outcome_execution")
current_path <- file.path(public_root, "v45_stage4_restricted_current.tsv")
gate_path <- file.path(root, "work_v45", "gate_state_v45.yml")
qa_path <- file.path(
  root, "output", "qa", "v45",
  "V45_STAGE4_NHANES_OUTCOME_INDEPENDENT_VALIDATION_QA.md"
)
manifest_path <- file.path(
  public_root, "v45_stage4_release_output_manifest.tsv"
)
validation_path <- file.path(
  public_root, "v45_stage4_independent_validation.tsv"
)
object_summary_path <- file.path(
  public_root, "v45_stage4_object_gate_summary.tsv"
)
standard_path <- file.path(
  public_root, "v45_nhanes_standard_pooled.tsv"
)
paired_path <- file.path(
  public_root, "v45_nhanes_paired_gli_pooled.tsv"
)
ipw_path <- file.path(
  public_root, "v45_nhanes_ipw_pooled.tsv"
)
model_diagnostics_path <- file.path(
  public_root, "v45_nhanes_model_diagnostics.tsv"
)
ipw_diagnostics_path <- file.path(
  public_root, "v45_nhanes_ipw_diagnostics.tsv"
)
combined_path <- file.path(
  public_root, "v45_nhanes_released_results.tsv"
)
m100_path <- file.path(
  public_root, "v45_stage4_m100_requirement.tsv"
)

read_tsv <- function(path) {
  utils::read.delim(
    path, stringsAsFactors = FALSE, check.names = FALSE,
    na.strings = c("", "NA")
  )
}

verify_release_mode <- "--verify" %in% commandArgs(trailingOnly = TRUE)
if (verify_release_mode) {
  if (!file.exists(manifest_path)) {
    stop("Stage 4 release manifest is absent.", call. = FALSE)
  }
  manifest <- read_tsv(manifest_path)
  ok <- !anyDuplicated(manifest$asset_id) &&
    all(vapply(seq_len(nrow(manifest)), function(i) {
      path <- file.path(root, manifest$path_alias[[i]])
      file.exists(path) &&
        !dir.exists(path) &&
        identical(v45_sha256_file(path), manifest$sha256[[i]]) &&
        identical(
          as.numeric(file.info(path)$size),
          as.numeric(manifest$bytes[[i]])
        )
    }, logical(1)))
  gate <- yaml::read_yaml(gate_path)
  if (
    !ok ||
    !identical(
      gate$stage4_nhanes_outcome_execution$status,
      "INDEPENDENT_VALIDATION_PASS"
    ) ||
    !gate_yes(gate$new_mortality_coefficient_inspection_allowed)
  ) {
    stop("Stage 4 released outputs no longer verify.", call. = FALSE)
  }
  cat("V45_STAGE4_NHANES_OUTCOME_RELEASE_VERIFY_PASS\n")
  quit(save = "no", status = 0L)
}

gate <- yaml::read_yaml(gate_path)
if (
  !identical(gate$stage4_nhanes_outcome_freeze$status, "PASS") ||
  !gate_yes(gate$outcome_execution_allowed) ||
  !gate_no(gate$new_mortality_coefficient_inspection_allowed)
) {
  stop("Stage 4 gates do not authorize independent validation.",
       call. = FALSE)
}

if (!file.exists(current_path)) {
  stop("Restricted Stage 4 current-run pointer is absent.", call. = FALSE)
}
current <- read_tsv(current_path)
if (nrow(current) != 1L ||
    !identical(current$coefficient_visibility[[1L]], "RESTRICTED")) {
  stop("Restricted Stage 4 current-run pointer is invalid.",
       call. = FALSE)
}
run_id <- current$run_id[[1L]]
state_path <- file.path(root, current$state_path_alias[[1L]])
if (
  !file.exists(state_path) ||
  !identical(v45_sha256_file(state_path), current$state_sha256[[1L]])
) {
  stop("Restricted module-state hash does not verify.", call. = FALSE)
}
state <- read_tsv(state_path)
expected_modules <- c(
  "standard", "paired-prefix", "paired-full", "ipw-prefix", "ipw-full"
)
if (
  !identical(state$module, expected_modules) ||
  any(state$status != "RESTRICTED_COMPLETE") ||
  anyNA(state$output_path_alias) ||
  anyNA(state$output_sha256)
) {
  stop("Not all restricted Stage 4 modules are complete.", call. = FALSE)
}

restricted <- setNames(lapply(seq_len(nrow(state)), function(i) {
  path <- file.path(root, state$output_path_alias[[i]])
  if (
    !file.exists(path) ||
    !identical(v45_sha256_file(path), state$output_sha256[[i]])
  ) {
    stop(
      state$module[[i]], " restricted hash does not verify.",
      call. = FALSE
    )
  }
  readRDS(path)
}), state$module)

recursive_names <- function(x) {
  out <- names(x)
  if (is.list(x)) {
    out <- c(out, unlist(lapply(x, recursive_names), use.names = FALSE))
  }
  unique(out)
}
forbidden_names <- c(
  "SEQN", "completed", "completed_data", "mids", "fit", "fits",
  "model_object", "person_level_data", "row_level_data"
)
no_row_level_or_fit <- all(vapply(restricted, function(x) {
  !any(recursive_names(x) %in% forbidden_names) &&
    isFALSE(x$row_level_data_saved) &&
    identical(x$coefficient_visibility, "RESTRICTED")
}, logical(1)))
if (!no_row_level_or_fit) {
  stop("A restricted module retained a forbidden row-level or fit object.",
       call. = FALSE)
}

independent_pool <- function(data) {
  data <- data[order(data$imputation), , drop = FALSE]
  if (
    nrow(data) != 50L ||
    !identical(as.integer(data$imputation), seq_len(50L)) ||
    any(!is.finite(data$estimate)) ||
    any(!is.finite(data$within_variance) |
        data$within_variance <= 0)
  ) {
    stop("Independent Rubin input is invalid.", call. = FALSE)
  }
  qbar <- mean(data$estimate)
  ubar <- mean(data$within_variance)
  b <- stats::var(data$estimate)
  total <- ubar + (1 + 1 / nrow(data)) * b
  data.frame(
    m = nrow(data),
    estimate = qbar,
    within_variance = ubar,
    between_variance = b,
    total_variance = total,
    standard_error = sqrt(total),
    monte_carlo_error = sqrt(b / nrow(data)),
    monte_carlo_error_fraction =
      sqrt(b / nrow(data)) / sqrt(total),
    stringsAsFactors = FALSE
  )
}

compare_pool <- function(per, pooled, label) {
  key_fields <- c(
    "analysis_id", "term", "mi_object", "module", "variant"
  )
  keys <- unique(per[key_fields])
  if (nrow(keys) != nrow(pooled)) {
    stop(label, " pooled key count differs.", call. = FALSE)
  }
  comparisons <- lapply(seq_len(nrow(keys)), function(i) {
    key <- keys[i, , drop = FALSE]
    use <- rep(TRUE, nrow(per))
    pooled_use <- rep(TRUE, nrow(pooled))
    for (field in key_fields) {
      value <- key[[field]][[1L]]
      if (is.na(value)) {
        use <- use & is.na(per[[field]])
        pooled_use <- pooled_use & is.na(pooled[[field]])
      } else {
        use <- use & per[[field]] == value
        pooled_use <- pooled_use & pooled[[field]] == value
      }
    }
    if (sum(pooled_use) != 1L) {
      stop(label, " has a duplicated or absent pooled key.",
           call. = FALSE)
    }
    independent <- independent_pool(per[use, , drop = FALSE])
    recorded <- pooled[pooled_use, , drop = FALSE]
    fields <- c(
      "estimate", "within_variance", "between_variance",
      "total_variance", "standard_error", "monte_carlo_error",
      "monte_carlo_error_fraction"
    )
    difference <- max(abs(
      unlist(independent[fields], use.names = FALSE) -
        unlist(recorded[fields], use.names = FALSE)
    ))
    data.frame(
      analysis_id = key$analysis_id,
      term = key$term,
      variant = key$variant,
      maximum_absolute_difference = difference,
      status = if (
        is.finite(difference) && difference <= 1e-10
      ) "PASS" else "FAIL",
      stringsAsFactors = FALSE
    )
  })
  dplyr::bind_rows(comparisons)
}

standard <- restricted[["standard"]]
standard_expected_rows <- 1500L
standard_expected_pooled <- 30L
standard_expected_diagnostics <- 800L
standard_structure_ok <-
  identical(
    standard$schema_version,
    "v45_0_stage4_standard_restricted"
  ) &&
  nrow(standard$per_imputation) == standard_expected_rows &&
  nrow(standard$pooled) == standard_expected_pooled &&
  nrow(standard$diagnostics) == standard_expected_diagnostics &&
  setequal(unique(standard$per_imputation$mi_object), c("MI-B", "MI-G")) &&
  all(is.finite(standard$per_imputation$estimate)) &&
  all(is.finite(standard$per_imputation$within_variance) &
      standard$per_imputation$within_variance > 0) &&
  all(standard$diagnostics$matrix_columns ==
      standard$diagnostics$matrix_rank) &&
  all(standard$diagnostics$design_df == 49)
if (!standard_structure_ok) {
  stop("Restricted standard-model structure failed.", call. = FALSE)
}
standard_pool_check <- compare_pool(
  standard$per_imputation, standard$pooled, "standard"
)
if (any(standard_pool_check$status != "PASS")) {
  stop("Independent standard-model pooling differs.", call. = FALSE)
}

anchor_map <- c(
  v45_anchor_nhanes_a0 = "v43_s3_nhanes_pn_e0_a0",
  v45_anchor_nhanes_a1 = "v43_s3_nhanes_pn_e0_a1",
  v45_anchor_nhanes_a2 = "v43_s3_nhanes_pn_e0_a2"
)
predecessor <- utils::read.csv(
  file.path(
    root, "output", "code_archive",
    "PEF_mortality_v44_2_code_candidate", "results", "v43",
    "stage3_nhanes_primary_association_registry_v43.csv"
  ),
  stringsAsFactors = FALSE, check.names = FALSE
)
anchor_rows <- lapply(names(anchor_map), function(v45_id) {
  current_row <- standard$pooled[
    standard$pooled$analysis_id == v45_id &
      standard$pooled$term == "E0",
    ,
    drop = FALSE
  ]
  old_row <- predecessor[
    predecessor$analysis_id == anchor_map[[v45_id]],
    ,
    drop = FALSE
  ]
  if (nrow(current_row) != 1L || nrow(old_row) != 1L) {
    stop("Anchor comparison row is absent or duplicated.", call. = FALSE)
  }
  differences <- c(
    estimate = abs(current_row$estimate - old_row$estimate),
    standard_error =
      abs(current_row$standard_error - old_row$standard_error),
    ci_low = abs(current_row$ci_low - old_row$ci_low),
    ci_high = abs(current_row$ci_high - old_row$ci_high)
  )
  data.frame(
    analysis_id = v45_id,
    maximum_absolute_difference = max(differences),
    status = if (max(differences) <= 1e-8) "PASS" else "FAIL",
    stringsAsFactors = FALSE
  )
})
anchor_check <- dplyr::bind_rows(anchor_rows)
if (any(anchor_check$status != "PASS")) {
  stop("One or more v45 anchors do not reproduce v43.", call. = FALSE)
}

validate_prefix_full <- function(prefix, full, module_label, columns) {
  if (
    length(prefix$results) != 50L ||
    length(full$results) != 50L ||
    !identical(prefix$replicate_indices, seq_len(250L)) ||
    !identical(full$replicate_indices, seq_len(500L)) ||
    !identical(prefix$prefix_gate, "PASS")
  ) {
    stop(module_label, " prefix/full structure failed.", call. = FALSE)
  }
  rows <- lapply(seq_len(50L), function(i) {
    pre <- prefix$results[[i]]
    complete <- full$results[[i]]
    exact_prefix <- identical(
      pre$replicates,
      complete$replicates[seq_len(250L), , drop = FALSE]
    )
    point_equal <- identical(pre$point, complete$point)
    dimensions <- identical(
      dim(pre$replicates), c(250L, as.integer(columns))
    ) && identical(
      dim(complete$replicates), c(500L, as.integer(columns))
    )
    data.frame(
      imputation = i,
      exact_prefix = exact_prefix,
      point_equal = point_equal,
      dimensions = dimensions,
      status = if (
        exact_prefix && point_equal && dimensions
      ) "PASS" else "FAIL",
      stringsAsFactors = FALSE
    )
  })
  out <- dplyr::bind_rows(rows)
  if (any(out$status != "PASS")) {
    stop(module_label, " prefix/full identity failed.", call. = FALSE)
  }
  out
}

paired_prefix <- restricted[["paired-prefix"]]
paired_full <- restricted[["paired-full"]]
paired_identity <- validate_prefix_full(
  paired_prefix, paired_full, "paired GLI", 3L
)
paired_variance_rows <- lapply(seq_len(50L), function(i) {
  result <- paired_full$results[[i]]
  independent <- v45_replicate_variance(
    result$replicates[, "G6a_minus_G1"],
    result$point[["G6a_minus_G1"]], 500L
  )
  difference <- abs(
    independent$variance - result$within_variance
  )
  data.frame(
    imputation = i,
    variance_difference = difference,
    valid_fraction = independent$valid_fraction,
    status = if (
      is.finite(difference) && difference <= 1e-12 &&
      independent$valid_fraction >= 0.90
    ) "PASS" else "FAIL",
    stringsAsFactors = FALSE
  )
})
paired_variance_check <- dplyr::bind_rows(paired_variance_rows)
if (any(paired_variance_check$status != "PASS")) {
  stop("Paired GLI replicate variance validation failed.", call. = FALSE)
}
paired_pool_check <- compare_pool(
  paired_full$per_imputation, paired_full$pooled, "paired GLI"
)
if (any(paired_pool_check$status != "PASS")) {
  stop("Independent paired-GLI pooling differs.", call. = FALSE)
}

ipw_prefix <- restricted[["ipw-prefix"]]
ipw_full <- restricted[["ipw-full"]]
ipw_identity <- validate_prefix_full(
  ipw_prefix, ipw_full, "observation IPW", 5L
)
ipw_variance_rows <- lapply(seq_len(50L), function(i) {
  result <- ipw_full$results[[i]]
  dplyr::bind_rows(lapply(names(result$point), function(term) {
    independent <- v45_replicate_variance(
      result$replicates[, term], result$point[[term]], 500L
    )
    difference <- abs(
      independent$variance - result$within_variance[[term]]
    )
    data.frame(
      imputation = i,
      variant = term,
      variance_difference = difference,
      valid_fraction = independent$valid_fraction,
      status = if (
        is.finite(difference) && difference <= 1e-12 &&
        independent$valid_fraction >= 0.90
      ) "PASS" else "FAIL",
      stringsAsFactors = FALSE
    )
  }))
})
ipw_variance_check <- dplyr::bind_rows(ipw_variance_rows)
if (any(ipw_variance_check$status != "PASS")) {
  stop("Observation-IPW replicate variance validation failed.",
       call. = FALSE)
}
ipw_pool_check <- compare_pool(
  ipw_full$per_imputation, ipw_full$pooled, "observation IPW"
)
if (any(ipw_pool_check$status != "PASS")) {
  stop("Independent observation-IPW pooling differs.", call. = FALSE)
}
if (
  nrow(ipw_full$response_summary) != 100L ||
  nrow(ipw_full$balance) != 400L ||
  any(ipw_full$response_summary$response_matrix_rank <
      ipw_full$response_summary$response_matrix_columns + 1L)
) {
  stop("Observation-IPW diagnostic structure failed.", call. = FALSE)
}

primary_response <- ipw_full$response_summary[
  ipw_full$response_summary$response_specification == "primary",
  ,
  drop = FALSE
]
primary_balance <- ipw_full$balance[
  ipw_full$balance$response_specification == "primary" &
    ipw_full$balance$variant == "uncapped",
  ,
  drop = FALSE
]
ipw_metrics <- data.frame(
  metric = c(
    "response_probability_p01",
    "availability_factor_p99",
    "ESS_ratio",
    "maximum_absolute_SMD",
    "valid_replicate_fraction"
  ),
  value = c(
    min(primary_response$probability_p01),
    max(primary_response$availability_p99),
    min(primary_balance$ess_ratio),
    max(primary_balance$maximum_absolute_smd),
    min(ipw_full$per_imputation$valid_replicate_fraction)
  ),
  state = NA_character_,
  stringsAsFactors = FALSE
)
ipw_metrics$state[ipw_metrics$metric == "response_probability_p01"] <-
  v45_gate_state_three_level(
    ipw_metrics$value[
      ipw_metrics$metric == "response_probability_p01"
    ],
    function(x) x >= 0.05,
    function(x) x <= 0.01
  )
ipw_metrics$state[ipw_metrics$metric == "availability_factor_p99"] <-
  v45_gate_state_three_level(
    ipw_metrics$value[
      ipw_metrics$metric == "availability_factor_p99"
    ],
    function(x) x <= 10,
    function(x) x > 20
  )
ipw_metrics$state[ipw_metrics$metric == "ESS_ratio"] <-
  v45_gate_state_three_level(
    ipw_metrics$value[ipw_metrics$metric == "ESS_ratio"],
    function(x) x >= 0.50,
    function(x) x < 0.30
  )
ipw_metrics$state[ipw_metrics$metric == "maximum_absolute_SMD"] <-
  v45_gate_state_three_level(
    ipw_metrics$value[
      ipw_metrics$metric == "maximum_absolute_SMD"
    ],
    function(x) x <= 0.10,
    function(x) x > 0.20
  )
ipw_metrics$state[
  ipw_metrics$metric == "valid_replicate_fraction"
] <- v45_gate_state_three_level(
  ipw_metrics$value[
    ipw_metrics$metric == "valid_replicate_fraction"
  ],
  function(x) x >= 0.95,
  function(x) x < 0.90
)
ipw_overall_state <- if (any(ipw_metrics$state == "STOP")) {
  "STOP"
} else if (any(ipw_metrics$state == "CAUTION")) {
  "CAUTION"
} else {
  "GO"
}

object_mce <- dplyr::bind_rows(
  data.frame(
    object_id = "MI-B",
    monte_carlo_error_fraction =
      max(standard$pooled$monte_carlo_error_fraction[
        standard$pooled$mi_object == "MI-B"
      ]),
    stringsAsFactors = FALSE
  ),
  data.frame(
    object_id = "MI-G",
    monte_carlo_error_fraction = max(c(
      standard$pooled$monte_carlo_error_fraction[
        standard$pooled$mi_object == "MI-G"
      ],
      paired_full$pooled$monte_carlo_error_fraction
    )),
    stringsAsFactors = FALSE
  ),
  data.frame(
    object_id = "MI-S",
    monte_carlo_error_fraction =
      max(ipw_full$pooled$monte_carlo_error_fraction),
    stringsAsFactors = FALSE
  )
)
object_mce$m50_gate <- ifelse(
  object_mce$monte_carlo_error_fraction < 0.10,
  "PASS", "M100_REQUIRED"
)
object_mce$coefficient_release_allowed <-
  object_mce$m50_gate == "PASS"
v45_atomic_write_tsv(object_mce, object_summary_path)

checks <- data.frame(
  check = c(
    "restricted_module_hashes_and_schemas",
    "no_row_level_or_fit_object_retained",
    "standard_model_completeness",
    "standard_independent_Rubin_pooling",
    "v43_anchor_reproduction",
    "paired_prefix_full_identity",
    "paired_replicate_variance",
    "paired_independent_Rubin_pooling",
    "ipw_prefix_full_identity",
    "ipw_replicate_variance",
    "ipw_independent_Rubin_pooling",
    "ipw_diagnostic_hard_gates_recorded",
    "object_level_m50_MCE_gate"
  ),
  status = c(
    "PASS",
    if (no_row_level_or_fit) "PASS" else "FAIL",
    if (standard_structure_ok) "PASS" else "FAIL",
    if (all(standard_pool_check$status == "PASS")) "PASS" else "FAIL",
    if (all(anchor_check$status == "PASS")) "PASS" else "FAIL",
    if (all(paired_identity$status == "PASS")) "PASS" else "FAIL",
    if (all(paired_variance_check$status == "PASS")) "PASS" else "FAIL",
    if (all(paired_pool_check$status == "PASS")) "PASS" else "FAIL",
    if (all(ipw_identity$status == "PASS")) "PASS" else "FAIL",
    if (all(ipw_variance_check$status == "PASS")) "PASS" else "FAIL",
    if (all(ipw_pool_check$status == "PASS")) "PASS" else "FAIL",
    "PASS",
    if (all(object_mce$m50_gate == "PASS")) "PASS" else "M100_REQUIRED"
  ),
  observed = c(
    paste0(nrow(state), " restricted modules"),
    as.character(no_row_level_or_fit),
    paste0(
      nrow(standard$per_imputation), "/",
      nrow(standard$pooled), "/",
      nrow(standard$diagnostics)
    ),
    paste0(
      "max difference=",
      max(standard_pool_check$maximum_absolute_difference)
    ),
    paste0(
      "max difference=",
      max(anchor_check$maximum_absolute_difference)
    ),
    "50/50 exact first-250 matrices",
    paste0(
      "max difference=", max(
        paired_variance_check$variance_difference
      )
    ),
    paste0(
      "max difference=",
      max(paired_pool_check$maximum_absolute_difference)
    ),
    "50/50 exact first-250 matrices",
    paste0(
      "max difference=", max(ipw_variance_check$variance_difference)
    ),
    paste0(
      "max difference=",
      max(ipw_pool_check$maximum_absolute_difference)
    ),
    paste0(
      "overall=", ipw_overall_state, "; ",
      paste(ipw_metrics$metric, ipw_metrics$state, collapse = "; ")
    ),
    paste(
      object_mce$object_id,
      format(object_mce$monte_carlo_error_fraction, digits = 6),
      object_mce$m50_gate,
      collapse = "; "
    )
  ),
  expected = c(
    "5/5 exact-hash restricted modules",
    "no rows, completed data, mids, or fit objects",
    "1500 per-imputation rows; 30 pooled rows; 800 diagnostics",
    "maximum absolute difference <=1e-10",
    "A0/A1/A2 estimate/SE/CI absolute difference <=1e-8",
    "all first-250 values and points identical",
    "maximum absolute difference <=1e-12; valid fraction >=0.90",
    "maximum absolute difference <=1e-10",
    "all first-250 values and points identical",
    "maximum absolute difference <=1e-12; valid fraction >=0.90",
    "maximum absolute difference <=1e-10",
    "all prespecified GO/CAUTION/STOP states retained",
    "all three object-level fractions <0.10"
  ),
  stringsAsFactors = FALSE
)
v45_atomic_write_tsv(checks, validation_path)

if (any(object_mce$m50_gate != "PASS")) {
  requirement <- object_mce[
    object_mce$m50_gate == "M100_REQUIRED",
    c("object_id", "monte_carlo_error_fraction", "m50_gate"),
    drop = FALSE
  ]
  requirement$required_action <-
    "freeze full affected object and complete registered model set at m=100"
  v45_atomic_write_tsv(requirement, m100_path)
  gate$updated_at <- format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")
  gate$stage4_nhanes_outcome_execution <- list(
    status = "M100_REQUIRED",
    run_id = run_id,
    affected_objects = as.list(requirement$object_id),
    aggregate_coefficient_release = "BLOCKED"
  )
  gate$outcome_execution_allowed <- "no"
  gate$new_mortality_coefficient_inspection_allowed <- "no"
  gate$production_m100_objects_allowed <- "no"
  gate$next_authorized_step <- "freeze_affected_m100_objects_and_models"
  v45_atomic_write_yaml(gate, gate_path)
  qa <- c(
    "# V45 Stage 4 NHANES outcome validation",
    "",
    "- Restricted model execution and independent structural checks passed.",
    "- At least one imputation object did not pass the frozen m=50 Monte Carlo-error gate.",
    "- No new coefficient, HR, confidence interval, P value, or direction was released.",
    paste0(
      "- Affected object(s): ",
      paste(requirement$object_id, collapse = ", "), "."
    ),
    "- The next step is a separately frozen full-object m=100 rerun; selective extension is prohibited."
  )
  v45_atomic_write_lines(qa, qa_path)
  cat("V45_STAGE4_M100_REQUIRED\n")
  cat("coefficient_release=BLOCKED\n")
  quit(save = "no", status = 0L)
}

release_table <- function(data, analysis_type) {
  out <- data
  out$analysis_type <- analysis_type
  out$effect_measure <- "hazard_ratio"
  out$hazard_ratio <- exp(out$estimate)
  out$hazard_ratio_ci_low <- exp(out$ci_low)
  out$hazard_ratio_ci_high <- exp(out$ci_high)
  out$gate_status <- "PASS"
  out
}
standard_release <- release_table(standard$pooled, "standard")
standard_release$holm_adjusted_p_value <- NA_real_
focal_index <- which(
  (standard_release$analysis_id == "v45_g6a" &
     standard_release$term == "E0") |
    (standard_release$analysis_id == "v45_gli_ref_2022" &
       standard_release$term == "E0")
)
if (length(focal_index) != 2L) {
  stop("The two frozen Holm-family focal rows are not unique.",
       call. = FALSE)
}
standard_release$holm_adjusted_p_value[focal_index] <-
  stats::p.adjust(
    standard_release$p_value[focal_index], method = "holm"
  )
paired_release <- release_table(paired_full$pooled, "paired_GLI")
ipw_release <- release_table(ipw_full$pooled, "observation_IPW")
ipw_release$selection_diagnostic_state <- ipw_overall_state
ipw_release$gate_status <- if (
  ipw_overall_state == "STOP"
) "SELECTION_DIAGNOSTIC_STOP" else ipw_overall_state

model_diagnostics <- dplyr::bind_rows(lapply(
  split(standard$diagnostics, standard$diagnostics$analysis_id),
  function(data) {
    data.frame(
      analysis_id = data$analysis_id[[1L]],
      imputations = nrow(data),
      minimum_n = min(data$n),
      maximum_n = max(data$n),
      minimum_events = min(data$events),
      maximum_events = max(data$events),
      minimum_design_df = min(data$design_df),
      maximum_design_df = max(data$design_df),
      maximum_matrix_columns = max(data$matrix_columns),
      warning_imputation_n = sum(nzchar(data$warnings)),
      stringsAsFactors = FALSE
    )
  }
))
ipw_diagnostics <- dplyr::bind_rows(
  data.frame(
    diagnostic_type = "hard_gate_summary",
    metric = ipw_metrics$metric,
    value = ipw_metrics$value,
    state = ipw_metrics$state,
    imputation = NA_integer_,
    response_specification = NA_character_,
    variant = NA_character_,
    stringsAsFactors = FALSE
  ),
  data.frame(
    diagnostic_type = "response_distribution",
    metric = c(
      rep("probability_p01", nrow(ipw_full$response_summary)),
      rep("availability_p99", nrow(ipw_full$response_summary))
    ),
    value = c(
      ipw_full$response_summary$probability_p01,
      ipw_full$response_summary$availability_p99
    ),
    state = NA_character_,
    imputation = rep(
      ipw_full$response_summary$imputation, 2L
    ),
    response_specification = rep(
      ipw_full$response_summary$response_specification, 2L
    ),
    variant = NA_character_,
    stringsAsFactors = FALSE
  ),
  data.frame(
    diagnostic_type = "balance",
    metric = rep(
      c("ESS_ratio", "maximum_absolute_SMD"),
      each = nrow(ipw_full$balance)
    ),
    value = c(
      ipw_full$balance$ess_ratio,
      ipw_full$balance$maximum_absolute_smd
    ),
    state = NA_character_,
    imputation = rep(ipw_full$balance$imputation, 2L),
    response_specification = rep(
      ipw_full$balance$response_specification, 2L
    ),
    variant = rep(ipw_full$balance$variant, 2L),
    stringsAsFactors = FALSE
  )
)

combined <- dplyr::bind_rows(
  standard_release,
  paired_release,
  ipw_release
)
v45_atomic_write_tsv(standard_release, standard_path)
v45_atomic_write_tsv(paired_release, paired_path)
v45_atomic_write_tsv(ipw_release, ipw_path)
v45_atomic_write_tsv(model_diagnostics, model_diagnostics_path)
v45_atomic_write_tsv(ipw_diagnostics, ipw_diagnostics_path)
v45_atomic_write_tsv(combined, combined_path)

qa <- c(
  "# V45 Stage 4 NHANES outcome independent validation",
  "",
  paste0("- Restricted run: `", run_id, "`."),
  "- All five restricted modules matched their recorded SHA-256 hashes.",
  "- Standard models contained all 50 imputations, 30 registered pooled coefficients, and 800 compact fit-diagnostic rows.",
  "- A0/A1/A2 reproduced the authoritative v43 NHANES anchors within the frozen absolute tolerance.",
  "- The paired GLI and observation-IPW first-250 replicate matrices were exactly identical to the first half of their 500-replicate objects.",
  "- Replicate variances and Rubin components were independently recomputed and matched the restricted results.",
  paste0(
    "- Observation-IPW diagnostic state: **",
    ipw_overall_state, "**."
  ),
  paste0(
    "- Maximum m=50 Monte Carlo-error fractions: ",
    paste(
      object_mce$object_id,
      format(object_mce$monte_carlo_error_fraction, digits = 5),
      sep = "=",
      collapse = "; "
    ),
    "."
  ),
  "- All object-level m=50 Monte Carlo-error gates passed; aggregate coefficient inspection is now authorized.",
  "- Released files contain aggregate results and diagnostics only. No completed imputation, person-level record, replicate person-weight matrix, or fitted model object was exported."
)
v45_atomic_write_lines(qa, qa_path)

release_aliases <- c(
  validation =
    "results/v45/outcome_execution/v45_stage4_independent_validation.tsv",
  object_gates =
    "results/v45/outcome_execution/v45_stage4_object_gate_summary.tsv",
  standard =
    "results/v45/outcome_execution/v45_nhanes_standard_pooled.tsv",
  paired =
    "results/v45/outcome_execution/v45_nhanes_paired_gli_pooled.tsv",
  ipw = "results/v45/outcome_execution/v45_nhanes_ipw_pooled.tsv",
  model_diagnostics =
    "results/v45/outcome_execution/v45_nhanes_model_diagnostics.tsv",
  ipw_diagnostics =
    "results/v45/outcome_execution/v45_nhanes_ipw_diagnostics.tsv",
  combined =
    "results/v45/outcome_execution/v45_nhanes_released_results.tsv",
  qa =
    "output/qa/v45/V45_STAGE4_NHANES_OUTCOME_INDEPENDENT_VALIDATION_QA.md"
)
manifest <- dplyr::bind_rows(lapply(
  names(release_aliases), function(id) {
    alias <- release_aliases[[id]]
    path <- file.path(root, alias)
    data.frame(
      asset_id = id,
      path_alias = alias,
      bytes = as.numeric(file.info(path)$size),
      sha256 = v45_sha256_file(path),
      local_restricted = FALSE,
      stringsAsFactors = FALSE
    )
  }
))
v45_atomic_write_tsv(manifest, manifest_path)

gate$updated_at <- format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")
gate$stage4_nhanes_outcome_execution <- list(
  status = "INDEPENDENT_VALIDATION_PASS",
  run_id = run_id,
  restricted_modules = 5L,
  released_aggregate_assets = nrow(manifest),
  observation_IPW_state = ipw_overall_state,
  output_manifest_sha256 = v45_sha256_file(manifest_path)
)
gate$outcome_execution_allowed <- "no"
gate$new_mortality_coefficient_inspection_allowed <- "yes"
gate$production_m100_objects_allowed <- "no"
gate$next_authorized_step <- "run_CHARLS_production_MI_and_outcomes"
v45_atomic_write_yaml(gate, gate_path)

current$coefficient_visibility <- "AGGREGATE_RELEASED"
current$independent_validation_status <- "INDEPENDENT_VALIDATION_PASS"
v45_atomic_write_tsv(current, current_path)

cat("V45_STAGE4_NHANES_OUTCOME_INDEPENDENT_VALIDATION_PASS\n")
cat("run_id=", run_id, "\n", sep = "")
cat("aggregate_coefficient_release=AUTHORIZED\n")
cat("observation_IPW_state=", ipw_overall_state, "\n", sep = "")
