# Canonical, cross-process hashes for v45 production multiple imputation.
#
# These helpers avoid R serialization for row-bearing data and numeric arrays.
# Values are converted to type-explicit UTF-8 records before SHA-256 hashing.

v45_canonical_text_sha256 <- function(lines) {
  digest::digest(
    enc2utf8(paste(lines, collapse = "\n")),
    algo = "sha256",
    serialize = FALSE
  )
}

v45_canonical_string <- function(x) {
  ifelse(
    is.na(x),
    "N",
    paste0("S", nchar(enc2utf8(x), type = "bytes"), ":", enc2utf8(x))
  )
}

v45_canonical_numeric <- function(x) {
  out <- character(length(x))
  out[is.na(x) & !is.nan(x)] <- "NA"
  out[is.nan(x)] <- "NaN"
  out[is.infinite(x) & x > 0] <- "Inf"
  out[is.infinite(x) & x < 0] <- "-Inf"
  finite <- is.finite(x)
  out[finite] <- sprintf("%.17g", as.double(x[finite]))
  out
}

v45_canonical_vector_contract <- function(x) {
  classes <- paste(class(x), collapse = "|")
  type <- typeof(x)
  ordered_flag <- is.ordered(x)
  levels_value <- if (is.factor(x)) levels(x) else character()
  values <- if (is.factor(x)) {
    ifelse(is.na(x), "NA", paste0("F", as.integer(x)))
  } else if (is.character(x)) {
    v45_canonical_string(x)
  } else if (is.logical(x)) {
    ifelse(is.na(x), "NA", ifelse(x, "T", "F"))
  } else if (is.integer(x)) {
    ifelse(is.na(x), "NA", paste0("I", sprintf("%d", x)))
  } else if (is.numeric(x)) {
    paste0("D", v45_canonical_numeric(x))
  } else if (is.raw(x)) {
    paste0("R", sprintf("%02x", as.integer(x)))
  } else {
    stop(
      "Unsupported canonical vector type/classes: ",
      type, "/", classes,
      call. = FALSE
    )
  }
  list(
    length = length(x),
    typeof = type,
    classes = classes,
    ordered = ordered_flag,
    levels_sha256 = v45_canonical_text_sha256(
      c(paste0("level_count=", length(levels_value)),
        v45_canonical_string(levels_value))
    ),
    values_sha256 = v45_canonical_text_sha256(
      c(paste0("value_count=", length(values)), values)
    )
  )
}

v45_canonical_data_frame_contract <- function(data) {
  if (!is.data.frame(data)) stop("Expected a data frame.", call. = FALSE)
  columns <- lapply(data, v45_canonical_vector_contract)
  column_table <- dplyr::bind_rows(lapply(seq_along(columns), function(i) {
    item <- columns[[i]]
    data.frame(
      column_index = as.integer(i),
      column_name = names(data)[[i]],
      length = as.integer(item$length),
      typeof = item$typeof,
      classes = item$classes,
      ordered = item$ordered,
      levels_sha256 = item$levels_sha256,
      values_sha256 = item$values_sha256,
      stringsAsFactors = FALSE
    )
  }))
  rows <- apply(column_table, 1L, function(x) paste(x, collapse = "\u241f"))
  list(
    nrow = nrow(data),
    ncol = ncol(data),
    columns = column_table,
    sha256 = v45_canonical_text_sha256(c(
      "canonical_data_frame_v1",
      paste0("nrow=", nrow(data)),
      paste0("ncol=", ncol(data)),
      rows
    ))
  )
}

v45_canonical_array_sha256 <- function(x) {
  if (is.null(x)) {
    return(v45_canonical_text_sha256("canonical_NULL_v1"))
  }
  dimensions <- dim(x)
  if (is.null(dimensions)) dimensions <- length(x)
  dim_names <- dimnames(x)
  dim_name_hashes <- if (is.null(dim_names)) {
    character()
  } else {
    dim_name_values <- dim_names
    vapply(
      seq_along(dim_name_values),
      function(i) {
        values <- dim_name_values[[i]]
        if (is.null(values)) values <- character()
        v45_canonical_text_sha256(c(
          paste0("dimension=", i),
          v45_canonical_string(values)
        ))
      },
      character(1)
    )
  }
  vector_contract <- v45_canonical_vector_contract(as.vector(x))
  v45_canonical_text_sha256(c(
    "canonical_array_v1",
    paste0("dimensions=", paste(dimensions, collapse = "x")),
    paste0("dimname_hashes=", paste(dim_name_hashes, collapse = "|")),
    paste0("typeof=", vector_contract$typeof),
    paste0("classes=", vector_contract$classes),
    paste0("values=", vector_contract$values_sha256)
  ))
}

v45_canonical_imputation_payload_sha256 <- function(imp) {
  variable_names <- names(imp$imp)
  rows <- vapply(variable_names, function(name) {
    value <- imp$imp[[name]]
    contract <- if (is.null(value)) {
      v45_canonical_text_sha256("canonical_NULL_v1")
    } else if (is.data.frame(value)) {
      v45_canonical_data_frame_contract(value)$sha256
    } else {
      v45_canonical_array_sha256(value)
    }
    paste(name, contract, sep = "\u241f")
  }, character(1))
  v45_canonical_text_sha256(c(
    "canonical_mids_imp_payload_v1",
    paste0("variable_count=", length(variable_names)),
    rows
  ))
}

v45_canonical_named_character_sha256 <- function(x) {
  if (is.null(names(x))) stop("Named vector required.", call. = FALSE)
  v45_canonical_text_sha256(c(
    "canonical_named_character_v1",
    paste(
      v45_canonical_string(names(x)),
      v45_canonical_string(as.character(x)),
      sep = "\u241f"
    )
  ))
}

v45_canonical_object_sha256 <- function(x) {
  if (is.null(x)) {
    return(v45_canonical_text_sha256("canonical_NULL_v1"))
  }
  if (is.data.frame(x)) {
    return(v45_canonical_data_frame_contract(x)$sha256)
  }
  if (!is.null(dim(x))) {
    return(v45_canonical_array_sha256(x))
  }
  if (is.list(x)) {
    item_names <- names(x)
    if (is.null(item_names)) item_names <- rep("", length(x))
    item_hashes <- vapply(x, v45_canonical_object_sha256, character(1))
    return(v45_canonical_text_sha256(c(
      "canonical_list_v1",
      paste0("length=", length(x)),
      paste(
        seq_along(x),
        v45_canonical_string(item_names),
        item_hashes,
        sep = "\u241f"
      )
    )))
  }
  vector_contract <- v45_canonical_vector_contract(x)
  vector_names <- names(x)
  if (is.null(vector_names)) vector_names <- character()
  v45_canonical_text_sha256(c(
    "canonical_atomic_object_v1",
    paste0("length=", vector_contract$length),
    paste0("typeof=", vector_contract$typeof),
    paste0("classes=", vector_contract$classes),
    paste0("ordered=", vector_contract$ordered),
    paste0("levels=", vector_contract$levels_sha256),
    paste0("names=", v45_canonical_text_sha256(
      v45_canonical_string(vector_names)
    )),
    paste0("values=", vector_contract$values_sha256)
  ))
}
