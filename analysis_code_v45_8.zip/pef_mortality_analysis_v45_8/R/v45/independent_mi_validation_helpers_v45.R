# Independent, read-only validation helpers for v45 production MI objects.
#
# Contract:
# - no file I/O;
# - no random-number generation or imputation;
# - no statistical model fitting;
# - no mutation of the supplied mids object or source data;
# - no dependency on production_mi_hashes_v45.R or the archived v43 code.
#
# The iv_* canonical hashes deliberately reproduce the public
# canonical_*_v1 byte contract.  The implementations below are kept in this
# separate file so the Stage 3 validator can cross-check production outputs
# without sourcing the production hash implementation.

iv_require_namespace <- function(package) {
  if (!requireNamespace(package, quietly = TRUE)) {
    stop("Independent validation requires package: ", package, call. = FALSE)
  }
  invisible(TRUE)
}

iv_canonical_text_sha256 <- function(lines) {
  iv_require_namespace("digest")
  text <- enc2utf8(paste(lines, collapse = "\n"))
  digest::digest(text, algo = "sha256", serialize = FALSE)
}

iv_canonical_string <- function(x) {
  encoded <- enc2utf8(as.character(x))
  ifelse(
    is.na(x),
    "N",
    paste0("S", nchar(encoded, type = "bytes"), ":", encoded)
  )
}

iv_canonical_numeric <- function(x) {
  x <- as.double(x)
  result <- rep.int("", length(x))
  result[is.na(x) & !is.nan(x)] <- "NA"
  result[is.nan(x)] <- "NaN"
  result[is.infinite(x) & x > 0] <- "Inf"
  result[is.infinite(x) & x < 0] <- "-Inf"
  finite <- is.finite(x)
  result[finite] <- sprintf("%.17g", x[finite])
  result
}

iv_canonical_vector_contract <- function(x) {
  classes <- paste(class(x), collapse = "|")
  storage_type <- typeof(x)
  ordered_flag <- is.ordered(x)
  factor_levels <- if (is.factor(x)) levels(x) else character()

  values <- if (is.factor(x)) {
    ifelse(is.na(x), "NA", paste0("F", as.integer(x)))
  } else if (is.character(x)) {
    iv_canonical_string(x)
  } else if (is.logical(x)) {
    ifelse(is.na(x), "NA", ifelse(x, "T", "F"))
  } else if (is.integer(x)) {
    ifelse(is.na(x), "NA", paste0("I", sprintf("%d", x)))
  } else if (is.numeric(x)) {
    paste0("D", iv_canonical_numeric(x))
  } else if (is.raw(x)) {
    paste0("R", sprintf("%02x", as.integer(x)))
  } else {
    stop(
      "Unsupported independent canonical vector type/classes: ",
      storage_type, "/", classes,
      call. = FALSE
    )
  }

  list(
    length = length(x),
    typeof = storage_type,
    classes = classes,
    ordered = ordered_flag,
    levels_sha256 = iv_canonical_text_sha256(c(
      paste0("level_count=", length(factor_levels)),
      iv_canonical_string(factor_levels)
    )),
    values_sha256 = iv_canonical_text_sha256(c(
      paste0("value_count=", length(values)),
      values
    ))
  )
}

iv_canonical_data_frame_contract <- function(data) {
  if (!is.data.frame(data)) {
    stop("Independent canonical data-frame hash requires a data frame.",
         call. = FALSE)
  }
  column_contracts <- lapply(data, iv_canonical_vector_contract)
  column_rows <- lapply(seq_along(column_contracts), function(index) {
    contract <- column_contracts[[index]]
    data.frame(
      column_index = as.integer(index),
      column_name = names(data)[[index]],
      length = as.integer(contract$length),
      typeof = contract$typeof,
      classes = contract$classes,
      ordered = contract$ordered,
      levels_sha256 = contract$levels_sha256,
      values_sha256 = contract$values_sha256,
      stringsAsFactors = FALSE
    )
  })
  column_table <- if (length(column_rows)) {
    do.call(rbind, column_rows)
  } else {
    data.frame(
      column_index = integer(), column_name = character(),
      length = integer(), typeof = character(), classes = character(),
      ordered = logical(), levels_sha256 = character(),
      values_sha256 = character(), stringsAsFactors = FALSE
    )
  }
  row_records <- if (nrow(column_table)) {
    apply(
      column_table,
      1L,
      function(record) paste(record, collapse = "\u241f")
    )
  } else {
    character()
  }
  list(
    nrow = nrow(data),
    ncol = ncol(data),
    columns = column_table,
    sha256 = iv_canonical_text_sha256(c(
      "canonical_data_frame_v1",
      paste0("nrow=", nrow(data)),
      paste0("ncol=", ncol(data)),
      row_records
    ))
  )
}

iv_canonical_array_sha256 <- function(x) {
  if (is.null(x)) {
    return(iv_canonical_text_sha256("canonical_NULL_v1"))
  }
  dimensions <- dim(x)
  if (is.null(dimensions)) dimensions <- length(x)
  dimension_names <- dimnames(x)
  dimension_name_hashes <- if (is.null(dimension_names)) {
    character()
  } else {
    vapply(seq_along(dimension_names), function(index) {
      values <- dimension_names[[index]]
      if (is.null(values)) values <- character()
      iv_canonical_text_sha256(c(
        paste0("dimension=", index),
        iv_canonical_string(values)
      ))
    }, character(1))
  }
  vector_contract <- iv_canonical_vector_contract(as.vector(x))
  iv_canonical_text_sha256(c(
    "canonical_array_v1",
    paste0("dimensions=", paste(dimensions, collapse = "x")),
    paste0(
      "dimname_hashes=",
      paste(dimension_name_hashes, collapse = "|")
    ),
    paste0("typeof=", vector_contract$typeof),
    paste0("classes=", vector_contract$classes),
    paste0("values=", vector_contract$values_sha256)
  ))
}

iv_canonical_imputation_payload_sha256 <- function(imp) {
  if (is.null(imp$imp) || is.null(names(imp$imp))) {
    stop("mids$imp must be a named list for canonical hashing.",
         call. = FALSE)
  }
  variable_names <- names(imp$imp)
  records <- vapply(variable_names, function(variable) {
    value <- imp$imp[[variable]]
    value_hash <- if (is.null(value)) {
      iv_canonical_text_sha256("canonical_NULL_v1")
    } else if (is.data.frame(value)) {
      iv_canonical_data_frame_contract(value)$sha256
    } else {
      iv_canonical_array_sha256(value)
    }
    paste(variable, value_hash, sep = "\u241f")
  }, character(1))
  iv_canonical_text_sha256(c(
    "canonical_mids_imp_payload_v1",
    paste0("variable_count=", length(variable_names)),
    records
  ))
}

iv_canonical_named_character_sha256 <- function(x) {
  if (is.null(names(x))) {
    stop("Independent named-character hash requires names.", call. = FALSE)
  }
  iv_canonical_text_sha256(c(
    "canonical_named_character_v1",
    paste(
      iv_canonical_string(names(x)),
      iv_canonical_string(as.character(x)),
      sep = "\u241f"
    )
  ))
}

iv_canonical_object_sha256 <- function(x) {
  if (is.null(x)) {
    return(iv_canonical_text_sha256("canonical_NULL_v1"))
  }
  if (is.data.frame(x)) {
    return(iv_canonical_data_frame_contract(x)$sha256)
  }
  if (!is.null(dim(x))) {
    return(iv_canonical_array_sha256(x))
  }
  if (is.list(x)) {
    item_names <- names(x)
    if (is.null(item_names)) item_names <- rep("", length(x))
    item_hashes <- vapply(x, iv_canonical_object_sha256, character(1))
    return(iv_canonical_text_sha256(c(
      "canonical_list_v1",
      paste0("length=", length(x)),
      paste(
        seq_along(x),
        iv_canonical_string(item_names),
        item_hashes,
        sep = "\u241f"
      )
    )))
  }
  vector_contract <- iv_canonical_vector_contract(x)
  vector_names <- names(x)
  if (is.null(vector_names)) vector_names <- character()
  iv_canonical_text_sha256(c(
    "canonical_atomic_object_v1",
    paste0("length=", vector_contract$length),
    paste0("typeof=", vector_contract$typeof),
    paste0("classes=", vector_contract$classes),
    paste0("ordered=", vector_contract$ordered),
    paste0("levels=", vector_contract$levels_sha256),
    paste0(
      "names=",
      iv_canonical_text_sha256(iv_canonical_string(vector_names))
    ),
    paste0("values=", vector_contract$values_sha256)
  ))
}

iv_chain_matrix <- function(values) {
  if (is.data.frame(values)) values <- as.matrix(values)
  if (is.null(dim(values))) values <- matrix(values, ncol = 1L)
  if (!is.matrix(values) || !is.numeric(values)) {
    stop("R-hat input must be a numeric iteration-by-chain matrix.",
         call. = FALSE)
  }
  values
}

iv_split_chains <- function(values) {
  values <- iv_chain_matrix(values)
  half <- floor(nrow(values) / 2L)
  if (half < 2L) return(NULL)
  cbind(
    values[seq_len(half), , drop = FALSE],
    values[seq.int(nrow(values) - half + 1L, nrow(values)), , drop = FALSE]
  )
}

iv_basic_rhat <- function(values) {
  values <- iv_chain_matrix(values)
  if (nrow(values) < 2L || ncol(values) < 2L) return(NA_real_)
  within_by_chain <- vapply(
    seq_len(ncol(values)),
    function(chain) stats::var(values[, chain]),
    numeric(1)
  )
  within <- mean(within_by_chain)
  between <- nrow(values) * stats::var(colMeans(values))
  if (!all(is.finite(c(within_by_chain, within, between)))) {
    return(NA_real_)
  }
  if (within == 0 && between > 0) return(Inf)
  if (within <= 0) return(NA_real_)
  pooled <- ((nrow(values) - 1) / nrow(values)) * within +
    between / nrow(values)
  if (!is.finite(pooled) || pooled < 0) return(NA_real_)
  sqrt(pooled / within)
}

iv_rank_normalize <- function(values) {
  values <- iv_chain_matrix(values)
  flattened <- as.vector(values)
  ranks <- rank(flattened, ties.method = "average")
  normalized <- stats::qnorm(
    (ranks - 3 / 8) / (length(ranks) + 1 / 4)
  )
  matrix(normalized, nrow = nrow(values), ncol = ncol(values))
}

iv_improved_rhat <- function(values) {
  values <- iv_chain_matrix(values)
  split <- iv_split_chains(values)
  if (is.null(split) || any(!is.finite(split))) {
    return(list(
      rank_normalized = NA_real_,
      folded = NA_real_,
      maximum = NA_real_,
      raw_constant = FALSE,
      folded_identifiable = FALSE
    ))
  }
  raw_constant <- length(unique(as.vector(split))) < 2L
  if (raw_constant) {
    return(list(
      rank_normalized = NA_real_,
      folded = NA_real_,
      maximum = NA_real_,
      raw_constant = TRUE,
      folded_identifiable = FALSE
    ))
  }
  bulk <- iv_basic_rhat(iv_rank_normalize(split))
  folded_values <- abs(split - stats::median(as.vector(split)))
  folded_identifiable <-
    length(unique(as.vector(folded_values))) >= 2L
  folded <- if (folded_identifiable) {
    iv_basic_rhat(iv_rank_normalize(folded_values))
  } else {
    NA_real_
  }
  components <- c(bulk, folded)
  components <- components[is.finite(components) | is.infinite(components)]
  list(
    rank_normalized = bulk,
    folded = folded,
    maximum = if (length(components)) max(components) else NA_real_,
    raw_constant = FALSE,
    folded_identifiable = folded_identifiable
  )
}

iv_classic_final_half_rhat <- function(values) {
  values <- iv_chain_matrix(values)
  if (nrow(values) < 2L) return(NA_real_)
  keep <- seq.int(floor(nrow(values) / 2L) + 1L, nrow(values))
  iv_basic_rhat(values[keep, , drop = FALSE])
}

iv_trace_summary <- function(values) {
  values <- iv_chain_matrix(values)
  lag1 <- if (nrow(values) >= 2L) {
    vapply(seq_len(ncol(values)), function(chain) {
      current <- values[-1L, chain]
      previous <- values[-nrow(values), chain]
      if (!all(is.finite(c(current, previous)))) return(NA_real_)
      current_sd <- stats::sd(current)
      previous_sd <- stats::sd(previous)
      if (!is.finite(current_sd) || !is.finite(previous_sd) ||
          current_sd == 0 || previous_sd == 0) {
        return(NA_real_)
      }
      stats::cor(current, previous)
    }, numeric(1))
  } else {
    rep(NA_real_, ncol(values))
  }
  median_lag1 <- if (any(is.finite(lag1))) {
    stats::median(lag1[is.finite(lag1)])
  } else {
    NA_real_
  }

  standardized_shift <- NA_real_
  if (nrow(values) >= 10L && all(is.finite(values))) {
    previous <- values[
      seq.int(nrow(values) - 9L, nrow(values) - 5L),
      ,
      drop = FALSE
    ]
    final <- values[
      seq.int(nrow(values) - 4L, nrow(values)),
      ,
      drop = FALSE
    ]
    scale <- stats::mad(as.vector(final), constant = 1.4826)
    if (!is.finite(scale) || scale <= 0) {
      scale <- stats::sd(as.vector(final))
    }
    if (is.finite(scale) && scale > 0) {
      standardized_shift <- abs(mean(final) - mean(previous)) / scale
    }
  }
  list(
    median_lag1_ac = median_lag1,
    standardized_last5_shift = standardized_shift
  )
}

iv_rhat_audit <- function(values) {
  values <- iv_chain_matrix(values)
  improved <- iv_improved_rhat(values)
  summary <- iv_trace_summary(values)
  data.frame(
    iterations = as.integer(nrow(values)),
    chains = as.integer(ncol(values)),
    finite = all(is.finite(values)),
    distinct_trace_values =
      as.integer(length(unique(as.vector(values[is.finite(values)])))),
    rank_normalized_split_rhat = improved$rank_normalized,
    folded_split_rhat = improved$folded,
    rhat = improved$maximum,
    folded_identifiable = improved$folded_identifiable,
    raw_trace_constant = improved$raw_constant,
    classic_final_half_rhat = iv_classic_final_half_rhat(values),
    median_lag1_ac = summary$median_lag1_ac,
    standardized_last5_shift = summary$standardized_last5_shift,
    stringsAsFactors = FALSE
  )
}

iv_empty_category_trace <- function() {
  data.frame(
    variable = character(),
    category_level = character(),
    iteration = integer(),
    chain = integer(),
    missing_n = integer(),
    value = numeric(),
    stringsAsFactors = FALSE
  )
}

iv_category_trace_audit <- function(
    imp, mi_data = imp$data, mi_spec, trace = NULL,
    simplex_tolerance = 1e-10, final_tolerance = 1e-12) {
  if (missing(mi_spec) || is.null(mi_spec$unordered_multicategory_targets)) {
    stop("Categorical trace validation requires frozen MI specification.",
         call. = FALSE)
  }
  if (!is.data.frame(mi_data)) {
    stop("Categorical trace validation requires the original data frame.",
         call. = FALSE)
  }
  raw_iteration_count <- imp$iteration
  raw_chain_count <- imp$m
  iteration_count <- as.integer(raw_iteration_count)
  chain_count <- as.integer(raw_chain_count)
  if (length(raw_iteration_count) != 1L ||
      !is.numeric(raw_iteration_count) ||
      !is.finite(raw_iteration_count) ||
      raw_iteration_count != iteration_count || iteration_count < 0L ||
      length(raw_chain_count) != 1L || !is.numeric(raw_chain_count) ||
      !is.finite(raw_chain_count) ||
      raw_chain_count != chain_count || chain_count < 1L) {
    stop("mids iteration or chain count is invalid.", call. = FALSE)
  }
  targets <- as.character(mi_spec$unordered_multicategory_targets)
  required <- names(iv_empty_category_trace())
  if (is.null(trace)) {
    trace <- attr(imp, "category_trace", exact = TRUE)
  }

  if (!length(targets)) {
    if (is.null(trace)) trace <- iv_empty_category_trace()
    if (!is.data.frame(trace) || !all(required %in% names(trace)) ||
        nrow(trace) != 0L) {
      stop("Unexpected categorical trace exists when no target is frozen.",
           call. = FALSE)
    }
    return(list(
      trace = trace[required],
      sorted_trace = trace[required],
      audit = data.frame(
        variable = character(), expected_rows = integer(),
        observed_rows = integer(), levels = integer(),
        missing_n = integer(), complete_grid = logical(),
        simplex = logical(), count_lattice = logical(),
        final_state = logical(), status = character(),
        stringsAsFactors = FALSE
      ),
      pass = TRUE
    ))
  }

  if (is.null(trace) || !is.data.frame(trace) ||
      !all(required %in% names(trace))) {
    stop("Categorical trace is missing or malformed.", call. = FALSE)
  }
  trace <- trace[required]
  missing_targets <- setdiff(targets, names(mi_data))
  if (length(missing_targets)) {
    stop(
      "Categorical trace targets are absent from source data: ",
      paste(missing_targets, collapse = ", "),
      call. = FALSE
    )
  }
  invalid_targets <- targets[!vapply(targets, function(variable) {
    x <- mi_data[[variable]]
    is.factor(x) && !is.ordered(x) && nlevels(x) > 2L
  }, logical(1))]
  if (length(invalid_targets)) {
    stop(
      "Frozen unordered targets are not unordered factors with >2 levels: ",
      paste(invalid_targets, collapse = ", "),
      call. = FALSE
    )
  }
  integral_indices <-
    is.numeric(trace$iteration) && is.numeric(trace$chain) &&
    is.numeric(trace$missing_n) &&
    all(is.finite(trace$iteration) &
          trace$iteration == as.integer(trace$iteration)) &&
    all(is.finite(trace$chain) &
          trace$chain == as.integer(trace$chain)) &&
    all(is.finite(trace$missing_n) &
          trace$missing_n == as.integer(trace$missing_n))
  if (anyNA(trace$variable) || anyNA(trace$category_level) ||
      anyNA(trace$iteration) || anyNA(trace$chain) ||
      anyNA(trace$missing_n) || anyNA(trace$value) ||
      !integral_indices ||
      any(!is.finite(trace$value)) ||
      any(trace$value < 0 | trace$value > 1)) {
    stop("Categorical trace contains missing, non-finite, or invalid values.",
         call. = FALSE)
  }
  if (!setequal(unique(as.character(trace$variable)), targets)) {
    stop("Categorical trace target set differs from the frozen target set.",
         call. = FALSE)
  }

  audits <- lapply(targets, function(variable) {
    expected_levels <- levels(mi_data[[variable]])
    missing_count <- sum(is.na(mi_data[[variable]]))
    if (missing_count < 1L) {
      stop("Categorical trace target has no missing source values: ",
           variable, call. = FALSE)
    }
    current <- trace[as.character(trace$variable) == variable, , drop = FALSE]
    expected_grid <- expand.grid(
      category_level = expected_levels,
      iteration = seq_len(iteration_count),
      chain = seq_len(chain_count),
      KEEP.OUT.ATTRS = FALSE,
      stringsAsFactors = FALSE
    )
    current_key <- paste(
      as.character(current$category_level),
      as.integer(current$iteration),
      as.integer(current$chain),
      sep = "\r"
    )
    expected_key <- paste(
      expected_grid$category_level,
      expected_grid$iteration,
      expected_grid$chain,
      sep = "\r"
    )
    complete_grid <- nrow(current) == nrow(expected_grid) &&
      !anyDuplicated(current_key) &&
      setequal(current_key, expected_key) &&
      all(as.integer(current$missing_n) == missing_count)

    sums <- stats::aggregate(
      current$value,
      by = list(
        iteration = as.integer(current$iteration),
        chain = as.integer(current$chain)
      ),
      FUN = sum
    )
    simplex <- nrow(sums) == iteration_count * chain_count &&
      all(abs(sums$x - 1) <= simplex_tolerance)
    count_lattice <- all(
      abs(current$value * missing_count -
            round(current$value * missing_count)) <= simplex_tolerance
    )

    final_state <- TRUE
    final <- current[
      as.integer(current$iteration) == iteration_count,
      ,
      drop = FALSE
    ]
    imputed <- imp$imp[[variable]]
    if (is.null(imputed) || !is.data.frame(imputed) ||
        nrow(imputed) != missing_count || ncol(imputed) != chain_count) {
      final_state <- FALSE
    } else {
      for (chain in seq_len(chain_count)) {
        imputed_values <- as.character(imputed[[chain]])
        codes <- match(imputed_values, expected_levels)
        if (length(codes) != missing_count || anyNA(codes)) {
          final_state <- FALSE
          break
        }
        expected <- tabulate(
          codes,
          nbins = length(expected_levels)
        ) / missing_count
        chain_final <- final[
          as.integer(final$chain) == chain,
          ,
          drop = FALSE
        ]
        observed <- chain_final$value[
          match(expected_levels, as.character(chain_final$category_level))
        ]
        if (length(observed) != length(expected) || anyNA(observed) ||
            any(abs(observed - expected) > final_tolerance)) {
          final_state <- FALSE
          break
        }
      }
    }
    pass <- complete_grid && simplex && count_lattice && final_state
    data.frame(
      variable = variable,
      expected_rows = as.integer(nrow(expected_grid)),
      observed_rows = as.integer(nrow(current)),
      levels = as.integer(length(expected_levels)),
      missing_n = as.integer(missing_count),
      complete_grid = complete_grid,
      simplex = simplex,
      count_lattice = count_lattice,
      final_state = final_state,
      status = if (pass) "PASS" else "FAIL",
      stringsAsFactors = FALSE
    )
  })
  audit <- do.call(rbind, audits)
  if (!all(audit$status == "PASS")) {
    failed <- paste(
      audit$variable[audit$status != "PASS"],
      collapse = ", "
    )
    stop("Independent categorical trace audit failed: ", failed,
         call. = FALSE)
  }
  sorted <- trace[
    order(
      as.character(trace$variable),
      as.character(trace$category_level),
      as.integer(trace$iteration),
      as.integer(trace$chain)
    ),
    ,
    drop = FALSE
  ]
  rownames(sorted) <- NULL
  list(trace = trace, sorted_trace = sorted, audit = audit, pass = TRUE)
}

iv_validate_category_trace <- function(
    imp, mi_data = imp$data, mi_spec, trace = NULL,
    simplex_tolerance = 1e-10, final_tolerance = 1e-12) {
  result <- iv_category_trace_audit(
    imp = imp,
    mi_data = mi_data,
    mi_spec = mi_spec,
    trace = trace,
    simplex_tolerance = simplex_tolerance,
    final_tolerance = final_tolerance
  )
  result$sorted_trace
}

iv_reconstruct_released_nhanes_bmi <- function(
    weight_kg, height_cm, cycle_label) {
  lengths <- c(length(weight_kg), length(height_cm), length(cycle_label))
  if (length(unique(lengths)) > 1L) {
    stop("BMI reconstruction inputs must have identical lengths.",
         call. = FALSE)
  }
  cycle <- as.character(cycle_label)
  unsupported <- !is.na(cycle) & !cycle %in% c("E", "F", "G")
  if (any(unsupported)) {
    stop(
      "Unsupported NHANES cycle in independent BMI reconstruction: ",
      paste(sort(unique(cycle[unsupported])), collapse = ", "),
      call. = FALSE
    )
  }
  raw <- as.double(weight_kg) / (as.double(height_cm) / 100)^2
  precision_scale <- ifelse(cycle == "G", 10, 100)
  floor((raw + 1e-8) * precision_scale + 0.5) / precision_scale
}

iv_passive_bmi_audit <- function(
    imp, mi_data = imp$data, mi_spec = NULL, tolerance = 1e-12) {
  iv_require_namespace("mice")
  if (!is.data.frame(mi_data)) {
    stop("Passive BMI audit requires the original MI data frame.",
         call. = FALSE)
  }
  required <- c("height_cm", "weight_kg", "bmi", "cycle_label")
  missing_fields <- setdiff(required, intersect(names(mi_data), names(imp$data)))
  if (length(missing_fields)) {
    stop(
      "Passive BMI audit lacks fields: ",
      paste(missing_fields, collapse = ", "),
      call. = FALSE
    )
  }
  chain_count <- as.integer(imp$m)
  if (length(chain_count) != 1L || is.na(chain_count) || chain_count < 1L) {
    stop("mids chain count is invalid.", call. = FALSE)
  }
  missing_bmi <- is.na(mi_data$bmi)
  missingness_contract <- identical(
    missing_bmi,
    is.na(mi_data$height_cm) | is.na(mi_data$weight_kg)
  )
  where_mask_preserved <- !is.null(imp$where) &&
    "bmi" %in% colnames(imp$where) &&
    identical(
      unname(as.logical(imp$where[, "bmi"])),
      unname(missing_bmi)
    )
  visit_sequence_preserved <- if (is.null(mi_spec)) {
    NA
  } else {
    identical(
      as.character(imp$visitSequence),
      as.character(mi_spec$visit_sequence)
    )
  }
  if (!missingness_contract || !where_mask_preserved ||
      (!is.null(mi_spec) && !isTRUE(visit_sequence_preserved))) {
    stop("Passive BMI source mask or visit-sequence contract failed.",
         call. = FALSE)
  }

  observed <- !missing_bmi
  observed_expected <- iv_reconstruct_released_nhanes_bmi(
    mi_data$weight_kg[observed],
    mi_data$height_cm[observed],
    mi_data$cycle_label[observed]
  )
  observed_exact <- !is.na(observed_expected) &
    mi_data$bmi[observed] == observed_expected
  observed_exact_n <- sum(observed_exact)
  observed_exact_pass <- observed_exact_n == sum(observed)

  observed_change_n <- 0L
  maximum_identity_difference <- 0
  invalid_completed_parent_n <- 0L
  for (chain in seq_len(chain_count)) {
    completed <- mice::complete(imp, action = chain)
    changes <- completed$bmi[observed] != mi_data$bmi[observed]
    observed_change_n <- observed_change_n + sum(is.na(changes) | changes)

    expected <- iv_reconstruct_released_nhanes_bmi(
      completed$weight_kg[missing_bmi],
      completed$height_cm[missing_bmi],
      completed$cycle_label[missing_bmi]
    )
    differences <- abs(completed$bmi[missing_bmi] - expected)
    if (length(differences)) {
      if (all(is.finite(differences))) {
        maximum_identity_difference <- max(
          maximum_identity_difference,
          differences
        )
      } else {
        maximum_identity_difference <- Inf
      }
    }
    invalid_completed_parent_n <- invalid_completed_parent_n + sum(
      !is.finite(completed$height_cm) | completed$height_cm <= 0 |
        !is.finite(completed$weight_kg) | completed$weight_kg <= 0 |
        !is.finite(completed$bmi) | completed$bmi <= 0
    )
    rm(completed)
  }

  pass <- observed_exact_pass &&
    observed_change_n == 0L &&
    invalid_completed_parent_n == 0L &&
    is.finite(maximum_identity_difference) &&
    maximum_identity_difference <= tolerance
  data.frame(
    chains_checked = chain_count,
    bmi_missing_n = as.integer(sum(missing_bmi)),
    observed_bmi_n = as.integer(sum(observed)),
    observed_bmi_exact_reconstruction_n = as.integer(observed_exact_n),
    observed_bmi_change_n = as.integer(observed_change_n),
    maximum_identity_difference = maximum_identity_difference,
    invalid_completed_parent_n = as.integer(invalid_completed_parent_n),
    missingness_contract = missingness_contract,
    where_mask_preserved = where_mask_preserved,
    visit_sequence_preserved = visit_sequence_preserved,
    tolerance = tolerance,
    status = if (pass) "PASS" else "FAIL",
    stringsAsFactors = FALSE
  )
}
