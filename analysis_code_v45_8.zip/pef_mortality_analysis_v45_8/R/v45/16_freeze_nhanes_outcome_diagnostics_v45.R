#!/usr/bin/env Rscript

# Freeze the prespecified v45 NHANES influence and PH diagnostics.
# No diagnostic outcome model is fitted by this script.

options(stringsAsFactors = FALSE, warn = 2)

stage4b_root <- function() {
  args <- commandArgs(trailingOnly = FALSE)
  file_arg <- grep("^--file=", args, value = TRUE)
  if (!length(file_arg)) return(normalizePath(getwd(), mustWork = TRUE))
  script <- sub("^--file=", "", file_arg[[1L]])
  normalizePath(file.path(dirname(script), "..", ".."), mustWork = TRUE)
}

root <- stage4b_root()
source(file.path(root, "R", "v45", "01_nhanes_common_utilities_v45.R"))
source(file.path(root, "R", "v45", "02_gli_functions_v45.R"))
source(file.path(root, "R", "v45", "11_nhanes_outcome_utilities_v45.R"))
source(file.path(
  root, "R", "v45", "15_nhanes_outcome_diagnostics_utilities_v45.R"
))
v45_require_packages(root)

gate_yes <- function(x) {
  isTRUE(x) || tolower(as.character(x)) %in% c("yes", "true", "1")
}

normalized_root <- function(data, key, fields) {
  data <- data[order(data[[key]]), fields, drop = FALSE]
  normalized <- lapply(data, function(x) {
    out <- as.character(x)
    out[is.na(out) | !nzchar(out)] <- "<MISSING>"
    out
  })
  normalized <- as.data.frame(
    normalized, stringsAsFactors = FALSE, check.names = FALSE
  )
  rows <- apply(
    normalized, 1L, function(x) paste(x, collapse = "\u241f")
  )
  digest::digest(
    paste(rows, collapse = "\n"), algo = "sha256", serialize = FALSE
  )
}

function_sha <- function(fun) {
  digest::digest(
    paste(c(deparse(formals(fun)), deparse(body(fun))), collapse = "\n"),
    algo = "sha256", serialize = FALSE
  )
}

paths <- list(
  spec = file.path(
    root, "work_v45", "outcome_diagnostics_spec_v45.yml"
  ),
  decision = file.path(
    root, "work_v45", "v45_outcome_diagnostics_decision_log.md"
  ),
  code = file.path(
    root, "work_v45", "v45_outcome_diagnostics_code_manifest.tsv"
  ),
  functions = file.path(
    root, "work_v45", "v45_outcome_diagnostics_function_manifest.tsv"
  ),
  inputs = file.path(
    root, "work_v45", "v45_outcome_diagnostics_input_manifest.tsv"
  ),
  roots = file.path(
    root, "work_v45", "v45_outcome_diagnostics_freeze_roots.tsv"
  ),
  contract = file.path(
    root, "derived_sensitive", "v45",
    "v45_nhanes_outcome_diagnostics_contract.rds"
  ),
  validation = file.path(
    root, "results", "v45",
    "v45_nhanes_outcome_diagnostics_freeze_validation.tsv"
  ),
  output_manifest = file.path(
    root, "results", "v45",
    "v45_nhanes_outcome_diagnostics_freeze_output_manifest.tsv"
  ),
  gate = file.path(root, "work_v45", "gate_state_v45.yml")
)

assert_file <- function(path) {
  if (!file.exists(path) || dir.exists(path)) {
    stop("Required file is absent: ", path, call. = FALSE)
  }
  path
}

read_tsv <- function(path) {
  utils::read.delim(
    path, stringsAsFactors = FALSE, check.names = FALSE,
    na.strings = c("", "NA")
  )
}

build_code <- function() {
  aliases <- c(
    "work_v45/outcome_diagnostics_spec_v45.yml",
    "work_v45/v45_outcome_diagnostics_decision_log.md",
    "R/v45/01_nhanes_common_utilities_v45.R",
    "R/v45/02_gli_functions_v45.R",
    "R/v45/11_nhanes_outcome_utilities_v45.R",
    "R/v45/15_nhanes_outcome_diagnostics_utilities_v45.R",
    "R/v45/16_freeze_nhanes_outcome_diagnostics_v45.R",
    "R/v45/17_run_nhanes_outcome_diagnostics_v45.R",
    "R/v45/18_validate_nhanes_outcome_diagnostics_v45.R",
    "output/qa/V45_0_LITERATURE_INFORMED_REVISION_AND_ANALYSIS_PLAN_20260723.md"
  )
  dplyr::bind_rows(lapply(aliases, function(alias) {
    path <- file.path(root, alias)
    data.frame(
      asset_id = paste0("V45_STAGE4B::", alias),
      path_alias = alias,
      bytes = as.numeric(file.info(path)$size),
      sha256 = v45_sha256_file(path),
      immutable = TRUE,
      stringsAsFactors = FALSE
    )
  }))
}

build_functions <- function() {
  names_new <- c(
    "v45_diag_models", "v45_diag_fatal_warning_patterns",
    "v45_diag_assert_no_fatal_warning", "v45_diag_failure_class",
    "v45_diag_safe_row", "v45_diag_ph_formula",
    "v45_diag_ph_structural_check",
    "v45_diag_fit_ph_one", "v45_diag_fit_taylor_prebuilt",
    "v45_diag_fit_influence_one",
    "v45_diag_pool_table", "v45_diag_static_self_test"
  )
  names_inherited <- c(
    "v45_prepare_mig_completed", "v45_outcome_design_data",
    "v45_merge_completed_design", "v45_make_taylor_design",
    "v45_fit_taylor_cox_prebuilt", "v45_outcome_formula",
    "v45_outcome_a1_terms", "v45_capture_model",
    "v45_validate_cox_compact", "v45_pool_scalar_qu"
  )
  all_names <- c(names_new, names_inherited)
  if (any(!vapply(
    all_names, exists, logical(1), envir = globalenv(),
    inherits = FALSE
  ))) {
    stop("Diagnostic function closure is incomplete.", call. = FALSE)
  }
  data.frame(
    asset_id = paste0("function::", all_names),
    function_name = all_names,
    source = ifelse(
      all_names %in% names_new,
      "R/v45/15_nhanes_outcome_diagnostics_utilities_v45.R",
      "R/v45/11_nhanes_outcome_utilities_v45.R"
    ),
    sha256 = vapply(
      all_names,
      function(name) function_sha(get(name, envir = globalenv())),
      character(1)
    ),
    stringsAsFactors = FALSE
  )
}

build_inputs <- function() {
  pointer_path <- file.path(
    root, "results", "v45", "production_mi", "MI_G_m50_current.tsv"
  )
  pointer <- read_tsv(pointer_path)
  mids_path <- file.path(root, pointer$mids_path_alias[[1L]])
  aliases <- c(
    "results/v45/production_mi/MI_G_m50_current.tsv",
    pointer$mids_path_alias[[1L]],
    "derived_sensitive/v43/nhanes_stage3_analysis_ledger_v43.rds",
    "results/v45/outcome_execution/v45_stage4_release_output_manifest.tsv",
    "results/v45/outcome_execution/v45_nhanes_standard_pooled.tsv",
    "results/v45/outcome_execution/v45_nhanes_model_diagnostics.tsv",
    "results/v45/outcome_execution/v45_stage4_object_gate_summary.tsv",
    "work_v45/v45_outcome_freeze_roots.tsv",
    "work_v45/v45_fatal_warning_whitelist.yml",
    paste0(
      "output/code_archive/PEF_mortality_v44_2_code_candidate/",
      "results/v43/stage3_nhanes_time_varying_effects_v43.csv"
    )
  )
  out <- dplyr::bind_rows(lapply(seq_along(aliases), function(i) {
    alias <- aliases[[i]]
    path <- assert_file(file.path(root, alias))
    data.frame(
      asset_id = paste0("input_", sprintf("%02d", i)),
      path_alias = alias,
      bytes = as.numeric(file.info(path)$size),
      sha256 = v45_sha256_file(path),
      local_restricted = grepl("^derived_sensitive/", alias),
      stringsAsFactors = FALSE
    )
  }))
  if (
    nrow(pointer) != 1L ||
    !identical(pointer$object_id[[1L]], "MI-G") ||
    pointer$requested_m[[1L]] != 50L ||
    !identical(
      pointer$mids_sha256[[1L]],
      "41bcc3e5fbfd8f19501682e93354856ffc06adf6e426937327e07138d17733d3"
    ) ||
    !identical(
      v45_sha256_file(mids_path), pointer$mids_sha256[[1L]]
    )
  ) {
    stop("MI-G pointer/hash differs from the diagnostic specification.",
         call. = FALSE)
  }
  out
}

build_components <- function() {
  stage4_verify <- system2(
    file.path(R.home("bin"), "Rscript"),
    c(
      "--vanilla",
      file.path(
        root, "R", "v45",
        "14_validate_nhanes_outcome_execution_v45.R"
      ),
      "--verify"
    ),
    stdout = TRUE, stderr = TRUE
  )
  status <- attr(stage4_verify, "status")
  if (!is.null(status) && status != 0L) {
    stop(
      "Released Stage 4 outputs do not verify: ",
      paste(stage4_verify, collapse = " | "), call. = FALSE
    )
  }
  gate <- yaml::read_yaml(paths$gate)
  stage4_ok <-
    identical(
      gate$stage4_nhanes_outcome_execution$status,
      "INDEPENDENT_VALIDATION_PASS"
    ) &&
    gate_yes(gate$new_mortality_coefficient_inspection_allowed)
  if (!stage4_ok) {
    stop("Released Stage 4 gate is not PASS.", call. = FALSE)
  }
  code <- build_code()
  functions <- build_functions()
  inputs <- build_inputs()
  self_test <- v45_diag_static_self_test()
  ledger <- v45_read_nhanes_ledger(root)
  design <- v45_outcome_design_data(ledger)
  psu_values <- sort(
    unique(as.character(design$design_psu)), method = "radix"
  )
  pointer <- read_tsv(file.path(
    root, "results", "v45", "production_mi", "MI_G_m50_current.tsv"
  ))
  mig <- readRDS(file.path(root, pointer$mids_path_alias[[1L]]))
  v43 <- v45_load_v43_nhanes_functions(root)
  completed_one <- v45_prepare_mig_completed(
    mice::complete(mig, action = 1L), ledger, v43
  )
  ph_structure <- v45_diag_ph_structural_check(completed_one)
  merged <- v45_merge_completed_design(design, completed_one)
  full_design <- v45_make_taylor_design(merged)
  cycle_design_df <- setNames(vapply(
    c("E", "F", "G"), function(cycle) {
      domain <- merged$analysis_domain &
        as.character(merged$cycle_label) != cycle
      as.numeric(survey::degf(full_design[domain, ]))
    }, numeric(1)
  ), c("E", "F", "G"))
  psu_design_df <- setNames(vapply(psu_values, function(psu) {
    domain <- merged$analysis_domain &
      as.character(merged$design_psu) != psu
    as.numeric(survey::degf(full_design[domain, ]))
  }, numeric(1)), psu_values)
  warning_contract <- yaml::read_yaml(file.path(
    root, "work_v45", "v45_fatal_warning_whitelist.yml"
  ))
  warning_contract_ok <- identical(
    unlist(warning_contract$fatal_warning_patterns, use.names = FALSE),
    v45_diag_fatal_warning_patterns()
  ) && !length(warning_contract$allowed_warning_patterns)
  anchor_ph <- utils::read.csv(
    file.path(
      root, "output", "code_archive",
      "PEF_mortality_v44_2_code_candidate", "results", "v43",
      "stage3_nhanes_time_varying_effects_v43.csv"
    ),
    stringsAsFactors = FALSE, check.names = FALSE
  )
  anchor_ph <- anchor_ph[
    anchor_ph$test_id ==
      "v43_s3_nhanes_pn_e0_a1_log_time_supportive",
    ,
    drop = FALSE
  ]
  anchor_ph_ok <- nrow(anchor_ph) == 1L &&
    identical(anchor_ph$terms[[1L]], "tt(E0)") &&
    anchor_ph$m[[1L]] == 50L &&
    identical(anchor_ph$diagnostic_status[[1L]], "PASS") &&
    all(is.finite(as.numeric(unlist(
      anchor_ph[1L, c(
        "estimate", "standard_error", "ci_low", "ci_high", "p_value"
      )],
      use.names = FALSE
    ))))
  released <- read_tsv(file.path(
    root, "results", "v45", "outcome_execution",
    "v45_nhanes_standard_pooled.tsv"
  ))
  reference_ok <- all(vapply(c("v45_g1", "v45_g6a"), function(id) {
    sum(released$analysis_id == id & released$term == "E0") == 1L
  }, logical(1)))
  checks <- data.frame(
    check = c(
      "released_stage4_verifies",
      "code_assets_complete",
      "function_closure_complete",
      "input_assets_complete",
      "diagnostic_static_self_test",
      "fatal_warning_contract_exact",
      "PH_structural_contract",
      "full_design_and_exclusion_anchors",
      "anchor_A1_PH_reuse_unique",
      "released_reference_rows_unique",
      "diagnostic_model_fit_count",
      "diagnostic_coefficient_export_count"
    ),
    status = c(
      if (stage4_ok) "PASS" else "FAIL",
      if (
        nrow(code) == 10L &&
        all(is.finite(code$bytes) & code$bytes > 0) &&
        all(grepl("^[0-9a-f]{64}$", code$sha256))
      ) "PASS" else "FAIL",
      if (
        nrow(functions) == 22L &&
        !anyDuplicated(functions$asset_id) &&
        all(grepl("^[0-9a-f]{64}$", functions$sha256))
      ) "PASS" else "FAIL",
      if (
        nrow(inputs) == 10L &&
        all(is.finite(inputs$bytes) & inputs$bytes > 0) &&
        all(grepl("^[0-9a-f]{64}$", inputs$sha256))
      ) "PASS" else "FAIL",
      if (
        nrow(self_test) == 10L &&
        all(self_test$status == "PASS")
      ) "PASS" else "FAIL",
      if (warning_contract_ok) "PASS" else "FAIL",
      if (
        nrow(ph_structure) == 2L &&
        all(ph_structure$status == "PASS")
      ) "PASS" else "FAIL",
      if (
        nrow(design) == 29353L &&
        length(psu_values) == 94L &&
        nlevels(design$design_strata) == 45L &&
        identical(
          unname(cycle_design_df), c(33, 33, 32)
        ) &&
        all(psu_design_df == 48)
      ) "PASS" else "FAIL",
      if (anchor_ph_ok) "PASS" else "FAIL",
      if (reference_ok) "PASS" else "FAIL",
      "PASS", "PASS"
    ),
    observed = c(
      "Stage 4 release exact-hash PASS",
      paste0(nrow(code), " assets"),
      paste0(nrow(functions), " functions"),
      paste0(nrow(inputs), " inputs"),
      paste0(sum(self_test$status == "PASS"), "/", nrow(self_test)),
      as.character(warning_contract_ok),
      paste0(
        sum(ph_structure$status == "PASS"), "/",
        nrow(ph_structure), " models"
      ),
      paste0(
        nrow(design), " rows; ", nlevels(design$design_strata),
        " strata; ", length(psu_values), " PSU; cycle df ",
        paste(cycle_design_df, collapse = "/"),
        "; PSU df ", paste(unique(psu_design_df), collapse = "/")
      ),
      as.character(anchor_ph_ok),
      as.character(reference_ok),
      "0", "0"
    ),
    expected = c(
      "released Stage 4 independent validation remains PASS",
      "10 immutable assets",
      "22 exact function hashes",
      "10 immutable inputs",
      "10/10 PASS",
      "fatal patterns exactly match frozen whitelist",
      "2/2 structural PH models PASS",
      "29353 rows; 45 strata; 94 PSU; cycle df 33/33/32; PSU df 48",
      "one exact v43 A1 tt(E0), m=50, PASS row",
      "one E0 row for each G1/G6a",
      "0", "0"
    ),
    stringsAsFactors = FALSE
  )
  if (any(checks$status != "PASS")) {
    stop(
      "Diagnostic freeze failed: ",
      paste(checks$check[checks$status != "PASS"], collapse = ", "),
      call. = FALSE
    )
  }
  exclusion_lines <- c(
    paste0("cycles=", paste(c("E", "F", "G"), collapse = ",")),
    paste0("psu=", paste(psu_values, collapse = ",")),
    paste0("models=", paste(names(v45_diag_models()), collapse = ",")),
    paste0(
      "v45_g1=", paste(v45_diag_models()$v45_g1, collapse = ",")
    ),
    paste0(
      "v45_g6a=", paste(v45_diag_models()$v45_g6a, collapse = ",")
    ),
    "influence_per_imputation=194",
    "ph_per_imputation=2",
    "total_refits=9800"
  )
  roots <- data.frame(
    root_id = c(
      "code_root", "function_root", "input_root", "exclusion_root"
    ),
    sha256 = c(
      normalized_root(
        code, "asset_id",
        c("asset_id", "path_alias", "bytes", "sha256", "immutable")
      ),
      normalized_root(
        functions, "asset_id",
        c("asset_id", "function_name", "source", "sha256")
      ),
      normalized_root(
        inputs, "asset_id",
        c(
          "asset_id", "path_alias", "bytes", "sha256",
          "local_restricted"
        )
      ),
      digest::digest(
        paste(exclusion_lines, collapse = "\n"),
        algo = "sha256", serialize = FALSE
      )
    ),
    stringsAsFactors = FALSE
  )
  contract <- list(
    contract_version = "v45_0_stage4b",
    created_at_utc = format(
      Sys.time(), tz = "UTC", format = "%Y-%m-%dT%H:%M:%SZ"
    ),
    code_root_sha256 = roots$sha256[roots$root_id == "code_root"],
    function_root_sha256 =
      roots$sha256[roots$root_id == "function_root"],
    input_root_sha256 = roots$sha256[roots$root_id == "input_root"],
    exclusion_root_sha256 =
      roots$sha256[roots$root_id == "exclusion_root"],
    cycles = c("E", "F", "G"),
    design_psu_values = psu_values,
    models = v45_diag_models(),
    fatal_warning_patterns = v45_diag_fatal_warning_patterns(),
    ph_structure = ph_structure,
    cycle_design_df = cycle_design_df,
    psu_design_df = psu_design_df,
    reused_anchor_ph = anchor_ph,
    failure_policy = list(
      all_registered_keys_attempted = TRUE,
      registered_failure_status = "NOT_ESTIMABLE",
      unexpected_implementation_error = "FAIL_COMPLETE_RUN"
    ),
    mce_policy = list(
      go_below = 0.10,
      at_or_above_action =
        "FREEZE_AND_RERUN_COMPLETE_MI_G_STAGE4_AND_STAGE4B_AT_M100"
    ),
    expected = list(
      influence_per_imputation = 194L,
      ph_per_imputation = 2L,
      total_refits = 9800L,
      pooled_influence = 194L,
      pooled_ph = 2L
    ),
    diagnostic_model_fit_count = 0L,
    diagnostic_coefficient_export_count = 0L
  )
  list(
    code = code, functions = functions, inputs = inputs,
    roots = roots, contract = contract, checks = checks
  )
}

verify <- "--verify" %in% commandArgs(trailingOnly = TRUE)
output_paths <- unlist(paths[c(
  "code", "functions", "inputs", "roots", "contract",
  "validation", "output_manifest"
)])

if (verify) {
  if (any(!file.exists(output_paths))) {
    stop("Diagnostic freeze outputs are incomplete.", call. = FALSE)
  }
  current <- build_components()
  recorded_code <- read_tsv(paths$code)
  recorded_functions <- read_tsv(paths$functions)
  recorded_inputs <- read_tsv(paths$inputs)
  recorded_roots <- read_tsv(paths$roots)
  code_ok <-
    identical(recorded_code$asset_id, current$code$asset_id) &&
    identical(recorded_code$path_alias, current$code$path_alias) &&
    identical(
      as.numeric(recorded_code$bytes), as.numeric(current$code$bytes)
    ) &&
    identical(recorded_code$sha256, current$code$sha256) &&
    identical(
      as.logical(recorded_code$immutable),
      as.logical(current$code$immutable)
    )
  function_ok <- identical(
    normalized_root(
      recorded_functions, "asset_id",
      c("asset_id", "function_name", "source", "sha256")
    ),
    current$contract$function_root_sha256
  )
  input_ok <- identical(
    normalized_root(
      recorded_inputs, "asset_id",
      c(
        "asset_id", "path_alias", "bytes", "sha256",
        "local_restricted"
      )
    ),
    current$contract$input_root_sha256
  )
  roots_ok <- identical(
    as.character(recorded_roots$root_id),
    as.character(current$roots$root_id)
  ) && identical(
    as.character(recorded_roots$sha256),
    as.character(current$roots$sha256)
  )
  recorded_contract <- readRDS(paths$contract)
  recorded_deterministic <- recorded_contract
  current_deterministic <- current$contract
  recorded_deterministic$created_at_utc <- NULL
  current_deterministic$created_at_utc <- NULL
  contract_ok <- identical(
    recorded_deterministic, current_deterministic
  )
  output_manifest <- read_tsv(paths$output_manifest)
  output_manifest_ok <- !anyDuplicated(output_manifest$asset_id) &&
    all(vapply(seq_len(nrow(output_manifest)), function(i) {
      path <- file.path(root, output_manifest$path_alias[[i]])
      file.exists(path) && !dir.exists(path) &&
        identical(
          v45_sha256_file(path), output_manifest$sha256[[i]]
        ) &&
        identical(
          as.numeric(file.info(path)$size),
          as.numeric(output_manifest$bytes[[i]])
        )
    }, logical(1)))
  gate <- yaml::read_yaml(paths$gate)
  frozen_gate <- gate$stage4b_nhanes_outcome_diagnostics_freeze
  semantic_ok <-
    identical(
      frozen_gate$status, "PASS"
    ) &&
    identical(
      frozen_gate$contract_sha256, v45_sha256_file(paths$contract)
    ) &&
    identical(
      names(frozen_gate$roots), as.character(recorded_roots$root_id)
    ) &&
    identical(
      as.character(unlist(frozen_gate$roots, use.names = FALSE)),
      as.character(recorded_roots$sha256)
    ) &&
    (
      gate_yes(gate$nhanes_diagnostic_execution_allowed) ||
        gate$stage4b_nhanes_outcome_diagnostics_execution$status %in% c(
          "RESTRICTED_COMPLETE",
          "INDEPENDENT_VALIDATION_PASS"
        )
    )
  if (
    !code_ok || !function_ok || !input_ok || !roots_ok ||
    !contract_ok || !output_manifest_ok || !semantic_ok
  ) {
    stop("Diagnostic freeze no longer verifies.", call. = FALSE)
  }
  cat("V45_STAGE4B_DIAGNOSTIC_FREEZE_VERIFY_PASS\n")
  quit(save = "no", status = 0L)
}

if (any(file.exists(output_paths))) {
  stop("Diagnostic freeze outputs already exist; use --verify.",
       call. = FALSE)
}
components <- build_components()
v45_atomic_write_tsv(components$code, paths$code)
v45_atomic_write_tsv(components$functions, paths$functions)
v45_atomic_write_tsv(components$inputs, paths$inputs)
v45_atomic_write_tsv(components$roots, paths$roots)
v45_atomic_save_rds(components$contract, paths$contract)
v45_atomic_write_tsv(components$checks, paths$validation)

gate <- yaml::read_yaml(paths$gate)
freeze_id <- paste0(
  "v45_stage4b_diagnostics_",
  format(Sys.time(), "%Y%m%dT%H%M%S"), "_pid", Sys.getpid()
)
gate$updated_at <- format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")
gate$stage4b_nhanes_outcome_diagnostics_freeze <- list(
  status = "PASS",
  freeze_id = freeze_id,
  contract_sha256 = v45_sha256_file(paths$contract),
  roots = as.list(setNames(
    components$roots$sha256, components$roots$root_id
  )),
  code_root_sha256 = components$contract$code_root_sha256,
  function_root_sha256 = components$contract$function_root_sha256,
  input_root_sha256 = components$contract$input_root_sha256,
  exclusion_root_sha256 = components$contract$exclusion_root_sha256,
  diagnostic_model_fit_count = 0L,
  diagnostic_coefficient_export_count = 0L
)
gate$nhanes_diagnostic_execution_allowed <- "yes"
gate$nhanes_diagnostic_aggregate_inspection_allowed <- "no"
gate$next_authorized_step <- "run_NHANES_influence_and_PH_diagnostics"
v45_atomic_write_yaml(gate, paths$gate)

aliases <- c(
  code = "work_v45/v45_outcome_diagnostics_code_manifest.tsv",
  functions =
    "work_v45/v45_outcome_diagnostics_function_manifest.tsv",
  inputs = "work_v45/v45_outcome_diagnostics_input_manifest.tsv",
  roots = "work_v45/v45_outcome_diagnostics_freeze_roots.tsv",
  contract =
    "derived_sensitive/v45/v45_nhanes_outcome_diagnostics_contract.rds",
  validation =
    "results/v45/v45_nhanes_outcome_diagnostics_freeze_validation.tsv"
)
manifest <- dplyr::bind_rows(lapply(names(aliases), function(id) {
  alias <- aliases[[id]]
  path <- file.path(root, alias)
  data.frame(
    asset_id = id,
    path_alias = alias,
    bytes = as.numeric(file.info(path)$size),
    sha256 = v45_sha256_file(path),
    local_restricted = grepl("^derived_sensitive/", alias),
    stringsAsFactors = FALSE
  )
}))
v45_atomic_write_tsv(manifest, paths$output_manifest)
cat("V45_STAGE4B_DIAGNOSTIC_FREEZE_PASS\n")
cat("freeze_id=", freeze_id, "\n", sep = "")
cat("diagnostic_model_fit_count=0\n")
