# v45 Stage 1: define MI-B/MI-G/MI-S, run deterministic m=2/maxit=2
# structural dry runs, recompute GLI after completed height, and audit design
# matrices without fitting or exporting any mortality-model coefficient.

options(stringsAsFactors = FALSE)

script_root <- function() {
  args <- commandArgs(trailingOnly = FALSE)
  file_arg <- grep("^--file=", args, value = TRUE)
  if (!length(file_arg)) return(normalizePath(getwd(), mustWork = TRUE))
  script <- sub("^--file=", "", file_arg[[1]])
  normalizePath(file.path(dirname(script), "..", ".."), mustWork = TRUE)
}

root <- script_root()
source(file.path(root, "R", "v45", "01_nhanes_common_utilities_v45.R"))
source(file.path(root, "R", "v45", "02_gli_functions_v45.R"))
runtime <- v45_require_packages(root)

result_paths <- c(
  contracts = file.path(root, "results", "v45", "v45_mi_object_contracts.tsv"),
  predictors = file.path(root, "results", "v45", "v45_predictor_matrix_audit.tsv"),
  structural = file.path(root, "results", "v45", "v45_structural_preflight.tsv"),
  gli = file.path(root, "results", "v45", "v45_passive_gli_validation.tsv"),
  matrices = file.path(root, "results", "v45", "v45_model_matrix_audit.tsv"),
  collinearity = file.path(root, "results", "v45", "v45_exposure_collinearity_audit.tsv")
)
definition_path <- file.path(
  root, "derived_sensitive", "v45", "v45_mi_object_definitions_v45.rds"
)
log_path <- file.path(root, "logs", "v45", "v45_structural_preflight.log")
existing <- c(result_paths, definition_path, log_path)
existing <- existing[file.exists(existing)]
if (length(existing)) {
  stop(
    "v45 structural-preflight outputs already exist; refusing overwrite: ",
    paste(existing, collapse = "; "),
    call. = FALSE
  )
}

freeze_checks <- v45_verify_frozen_manifests(root)

run_id <- paste0(
  "v45_structural_", format(Sys.time(), "%Y%m%dT%H%M%S"),
  "_pid", Sys.getpid()
)
started_at <- format(Sys.time(), "%Y-%m-%dT%H:%M:%SZ", tz = "UTC")
log_lines <- c(
  paste0("run_id: ", run_id),
  paste0("started_at_utc: ", started_at),
  "scope: MI object definitions, deterministic dry runs, passive BMI/GLI, and matrix/design structure only",
  "mortality_model_fit_count: 0",
  "new_mortality_result_visibility: BLOCKED"
)
append_log <- function(...) {
  text <- paste0(...)
  log_lines <<- c(log_lines, paste0(format(Sys.time(), "%H:%M:%S"), " ", text))
  message(text)
}

checks <- list()
add_check <- function(check, pass, observed, expected) {
  checks[[length(checks) + 1L]] <<- data.frame(
    check = check,
    status = if (isTRUE(pass)) "PASS" else "FAIL",
    observed = v45_one_line(observed),
    expected = v45_one_line(expected),
    run_id = run_id,
    stringsAsFactors = FALSE
  )
  if (!isTRUE(pass)) {
    stop(check, " failed: ", v45_one_line(observed), call. = FALSE)
  }
  invisible(TRUE)
}

append_log("Frozen-manifest gate verified before opening the NHANES ledger.")
add_check(
  "frozen_manifests_current",
  all(freeze_checks$status == "PASS"),
  paste(freeze_checks$check, freeze_checks$status, sep = "=", collapse = ";"),
  "all predecessor, live-drift, input, code and runtime checks PASS"
)

ledger <- v45_read_nhanes_ledger(root)
v43 <- v45_load_v43_nhanes_functions(root)
master <- ledger$person_master
backbone <- ledger$full_mec_design_backbone

add_check(
  "full_MEC_backbone_anchor",
  nrow(backbone) == 29353L &&
    length(unique(backbone$design_strata)) == 45L &&
    length(unique(backbone$design_psu)) == 94L,
  paste0(
    "N=", nrow(backbone),
    "; strata=", length(unique(backbone$design_strata)),
    "; PSU=", length(unique(backbone$design_psu))
  ),
  "N=29353; strata=45; PSU=94"
)

mi_b <- v45_make_mi_b(ledger, v43)
mi_g <- v45_make_mi_g(ledger, v43, seed = 450201L)
mi_s <- v45_make_mi_s(ledger, v43, seed = 450301L)
objects <- list(`MI-B` = mi_b, `MI-G` = mi_g, `MI-S` = mi_s)

mi_b_signature <- v45_mi_signature_v43_nhanes(mi_b$specification)
add_check(
  "MI_B_inherited_signature",
  identical(mi_b_signature, mi_b$expected_signature),
  paste0("sha256=", mi_b_signature),
  paste0("sha256=", mi_b$expected_signature)
)

object_anchor <- function(object_id, object) {
  dat <- object$data
  response_n <- if ("R_A" %in% names(dat)) {
    sum(as.character(dat$R_A) == "1")
  } else {
    NA_integer_
  }
  data.frame(
    object_id = object_id,
    denominator_n = nrow(dat),
    frozen_event_n = sum(as.numeric(dat$death) == 1L),
    response_n = response_n,
    design_strata = length(unique(dat$design_strata)),
    design_psu = length(unique(dat$design_psu)),
    height_missing_n = sum(is.na(dat$height_cm)),
    weight_missing_n = sum(is.na(dat$weight_kg)),
    bmi_missing_n = sum(is.na(dat$bmi)),
    observed_bmi_n = sum(!is.na(dat$bmi)),
    active_target_n = sum(nzchar(object$specification$method)),
    input_column_n = ncol(dat),
    seed = object$specification$seed,
    dry_m = 2L,
    dry_maxit = 2L,
    specification_sha256 = v45_object_sha256(object$specification),
    ordered_id_sha256 = v45_object_sha256(
      v45_as_num(as.character(dat$SEQN))
    ),
    status = "PENDING_DRY_RUN",
    run_id = run_id,
    stringsAsFactors = FALSE
  )
}
contracts <- dplyr::bind_rows(Map(object_anchor, names(objects), objects))

add_check(
  "MI_B_denominator_and_missingness",
  nrow(mi_b$data) == 6719L &&
    sum(as.numeric(mi_b$data$death) == 1L) == 925L &&
    sum(is.na(mi_b$data$height_cm)) == 31L &&
    sum(is.na(mi_b$data$weight_kg)) == 34L &&
    sum(is.na(mi_b$data$bmi)) == 42L &&
    sum(!is.na(mi_b$data$bmi)) == 6677L,
  paste0(
    "N/events=", nrow(mi_b$data), "/",
    sum(as.numeric(mi_b$data$death) == 1L),
    "; H/W/BMI missing=", paste(
      c(
        sum(is.na(mi_b$data$height_cm)),
        sum(is.na(mi_b$data$weight_kg)),
        sum(is.na(mi_b$data$bmi))
      ),
      collapse = "/"
    )
  ),
  "N/events=6719/925; H/W/BMI missing=31/34/42; observed BMI=6677"
)
add_check(
  "MI_G_denominator_measurements_and_missingness",
  nrow(mi_g$data) == 6540L &&
    sum(as.numeric(mi_g$data$death) == 1L) == 885L &&
    sum(is.na(mi_g$data$height_cm)) == 30L &&
    sum(is.na(mi_g$data$weight_kg)) == 32L &&
    sum(is.na(mi_g$data$bmi)) == 40L &&
    sum(!is.na(mi_g$data$bmi)) == 6500L &&
    all(vapply(
      mi_g$data[c("pef_l_min", "fev1_l", "fvc_l", "fev1_fvc")],
      function(x) all(is.finite(as.numeric(x))),
      logical(1)
    )),
  paste0(
    "N/events=", nrow(mi_g$data), "/",
    sum(as.numeric(mi_g$data$death) == 1L),
    "; H/W/BMI missing=", paste(
      c(
        sum(is.na(mi_g$data$height_cm)),
        sum(is.na(mi_g$data$weight_kg)),
        sum(is.na(mi_g$data$bmi))
      ),
      collapse = "/"
    )
  ),
  "N/events=6540/885; H/W/BMI missing=30/32/40; all four observed measurements complete"
)
mi_s_forbidden <- v45_forbidden_mi_s_fields(names(mi_s$data))
mi_s_active_nonpassive <- setdiff(
  names(mi_s$specification$method)[nzchar(mi_s$specification$method)],
  "bmi"
)
mi_s_response_predictor_ok <- all(
  mi_s$specification$predictor_matrix[mi_s_active_nonpassive, "R_A"] == 1
)
add_check(
  "MI_S_denominator_response_and_exclusions",
  nrow(mi_s$data) == 7926L &&
    sum(as.numeric(mi_s$data$death) == 1L) == 1228L &&
    sum(as.character(mi_s$data$R_A) == "1") == 6719L &&
    sum(as.character(mi_s$data$R_A) == "0") == 1207L &&
    sum(!is.na(mi_s$data$bmi)) == 7801L &&
    !length(mi_s_forbidden) &&
    !nzchar(mi_s$specification$method[["R_A"]]) &&
    mi_s_response_predictor_ok,
  paste0(
    "N/events/R1/R0=", nrow(mi_s$data), "/",
    sum(as.numeric(mi_s$data$death) == 1L), "/",
    sum(as.character(mi_s$data$R_A) == "1"), "/",
    sum(as.character(mi_s$data$R_A) == "0"),
    "; forbidden_fields=", length(mi_s_forbidden),
    "; R_A_predictor_targets=", sum(
      mi_s$specification$predictor_matrix[
        mi_s_active_nonpassive, "R_A"
      ] == 1
    ), "/", length(mi_s_active_nonpassive)
  ),
  "N/events/R1/R0=7926/1228/6719/1207; observed BMI=7801; no measurement fields; R_A fixed and predicts all non-passive targets"
)

add_check(
  "MI_G_auxiliary_direction_contract",
  all(
    mi_g$specification$predictor_matrix[
      mi_g$specification$method != "" &
        names(mi_g$specification$method) != "bmi",
      "pef_l_min"
    ] == 1
  ) &&
    all(mi_g$specification$predictor_matrix[, c("E0", "E0b")] == 0) &&
    !any(grepl("^gli", names(mi_g$data), ignore.case = TRUE)),
  paste0(
    "raw_PEF_active_predictor_rows=",
    sum(mi_g$specification$predictor_matrix[, "pef_l_min"] == 1),
    "; E0/E0b_predictor_cells=",
    sum(mi_g$specification$predictor_matrix[, c("E0", "E0b")] != 0),
    "; precomputed_GLI_fields=",
    sum(grepl("^gli", names(mi_g$data), ignore.case = TRUE))
  ),
  "raw PEF is an observed auxiliary; E0/E0b and all GLI fields are excluded as FCS predictors"
)

predictor_audit <- dplyr::bind_rows(lapply(names(objects), function(name) {
  v45_expanded_predictor_audit(
    objects[[name]]$data,
    objects[[name]]$specification,
    name
  )
}))
add_check(
  "all_predictor_matrices_structurally_valid",
  nrow(predictor_audit) > 0L && all(predictor_audit$status == "PASS"),
  paste0(
    "target_rows=", nrow(predictor_audit),
    "; failures=", sum(predictor_audit$status != "PASS"),
    "; minimum_rcond=",
    signif(min(predictor_audit$normalized_crossprod_rcond), 5)
  ),
  "every active target has a smaller, full-rank expanded predictor matrix with positive normalized reciprocal condition"
)

append_log("Running MI-B deterministic dry pair (m=2, maxit=2).")
dry_b <- v45_run_deterministic_dry_pair(mi_b, v43)
append_log("Running MI-G deterministic dry pair (m=2, maxit=2).")
dry_g <- v45_run_deterministic_dry_pair(mi_g, v43)
append_log("Running MI-S deterministic dry pair (m=2, maxit=2).")
dry_s <- v45_run_deterministic_dry_pair(mi_s, v43)
dry_runs <- list(`MI-B` = dry_b, `MI-G` = dry_g, `MI-S` = dry_s)

for (name in names(dry_runs)) {
  idx <- contracts$object_id == name
  contracts$status[idx] <- "PASS"
  contracts$dry_payload_sha256[idx] <- dry_runs[[name]]$payload_sha256
  contracts$dry_elapsed_seconds[idx] <-
    round(dry_runs[[name]]$elapsed_seconds, 3)
  contracts$warning_count[idx] <- dry_runs[[name]]$warning_count
  contracts$logged_event_count[idx] <- dry_runs[[name]]$logged_event_count
}
add_check(
  "all_three_deterministic_dry_pairs",
  all(contracts$status == "PASS") &&
    all(contracts$warning_count == 0L) &&
    all(contracts$logged_event_count == 0L),
  paste(
    contracts$object_id,
    substr(contracts$dry_payload_sha256, 1L, 12L),
    sep = "=",
    collapse = ";"
  ),
  "MI-B/MI-G/MI-S each reproduce bitwise-identical imputation payloads under the same seed with zero warnings/logged events"
)

bmi_rows <- lapply(names(objects), function(name) {
  audit <- v45_passive_bmi_audit(
    dry_runs[[name]]$first, objects[[name]]$data, v43
  )
  data.frame(
    object_id = name,
    check = "passive_BMI_identity",
    rows_checked = nrow(objects[[name]]$data),
    missing_parent_or_bmi_n = audit$bmi_missing_n,
    observed_bmi_n = audit$observed_bmi_n,
    observed_bmi_change_n = audit$observed_bmi_change_n,
    maximum_absolute_difference = audit$maximum_identity_difference,
    invalid_completed_parent_n = audit$invalid_completed_parent_n,
    status = if (audit$pass) "PASS" else "FAIL",
    run_id = run_id,
    stringsAsFactors = FALSE
  )
})
bmi_audit <- dplyr::bind_rows(bmi_rows)
add_check(
  "passive_BMI_identity_all_objects",
  all(bmi_audit$status == "PASS"),
  paste0(
    "objects=", nrow(bmi_audit),
    "; maximum_difference=", max(bmi_audit$maximum_absolute_difference)
  ),
  "observed BMI is unchanged and every originally missing BMI equals the released-cycle reconstruction from completed height and weight"
)

completed_g <- lapply(seq_len(dry_g$first$m), function(i) {
  mice::complete(dry_g$first, action = i)
})
gli_g <- lapply(completed_g, v45_compute_gli)
observed_height <- !is.na(mi_g$data$height_cm)
legacy_validation <- v45_validate_gli_against_legacy(
  mi_g$data[observed_height, , drop = FALSE],
  root
)
gli_columns <- grep(
  "^(gli_global2022|gli2012)_(pred|lln|z|ppred)",
  names(gli_g[[1]]),
  value = TRUE
)
observed_invariant <- all(vapply(gli_columns, function(name) {
  identical(
    gli_g[[1]][[name]][observed_height],
    gli_g[[2]][[name]][observed_height]
  )
}, logical(1)))
height_missing <- !observed_height
completed_height_finite <- all(vapply(
  completed_g,
  function(dat) all(is.finite(dat$height_cm[height_missing])),
  logical(1)
))
perturb_source <- completed_g[[1]][which(height_missing)[[1]], , drop = FALSE]
perturbed <- perturb_source
perturbed$height_cm <- perturbed$height_cm + 0.1
gli_before <- v45_compute_gli(perturb_source)
gli_after <- v45_compute_gli(perturbed)
height_dependency_fields <- c(
  "gli_global2022_z_fev1", "gli_global2022_z_fvc",
  "gli_global2022_z_fev1_fvc", "gli2012_z_fev1",
  "gli2012_z_fvc", "gli2012_z_fev1_fvc"
)
height_dependency_differences <- vapply(
  height_dependency_fields,
  function(name) abs(gli_before[[name]] - gli_after[[name]]),
  numeric(1)
)
height_dependency_change_n <- sum(vapply(
  height_dependency_fields,
  function(name) !isTRUE(all.equal(
    gli_before[[name]], gli_after[[name]],
    tolerance = 0
  )),
  logical(1)
))
gli_validation <- dplyr::bind_rows(
  data.frame(
    check = "legacy_numerical_concordance",
    rows_checked = sum(observed_height),
    fields_checked = legacy_validation$fields_compared,
    maximum_absolute_difference =
      legacy_validation$maximum_absolute_difference,
    tolerance = legacy_validation$tolerance,
    status = if (legacy_validation$pass) "PASS" else "FAIL",
    run_id = run_id,
    stringsAsFactors = FALSE
  ),
  data.frame(
    check = "observed_height_rows_invariant_across_imputations",
    rows_checked = sum(observed_height),
    fields_checked = length(gli_columns),
    maximum_absolute_difference = if (observed_invariant) 0 else NA_real_,
    tolerance = 0,
    status = if (observed_invariant) "PASS" else "FAIL",
    run_id = run_id,
    stringsAsFactors = FALSE
  ),
  data.frame(
    check = "completed_height_drives_passive_GLI",
    rows_checked = sum(height_missing),
    fields_checked = 6L,
    maximum_absolute_difference = max(height_dependency_differences),
    tolerance = 0,
    status = if (
      completed_height_finite && height_dependency_change_n == 6L
    ) "PASS" else "FAIL",
    run_id = run_id,
    stringsAsFactors = FALSE
  )
)
add_check(
  "passive_GLI_validation",
  all(gli_validation$status == "PASS"),
  paste(
    gli_validation$check, gli_validation$status,
    sep = "=", collapse = ";"
  ),
  "legacy concordance, observed-height invariance, and explicit completed-height dependency all PASS"
)

full_design <- survey::svydesign(
  ids = ~design_psu,
  strata = ~design_strata,
  weights = ~wtmec6yr,
  data = backbone,
  nest = TRUE
)
common_ids <- v45_as_num(as.character(mi_g$data$SEQN))
safe_ids <- v45_as_num(as.character(mi_s$data$SEQN))
common_design <- subset(
  full_design,
  v45_as_num(SEQN) %in% common_ids
)
safe_design <- subset(
  full_design,
  v45_as_num(SEQN) %in% safe_ids
)
add_check(
  "full_design_precedes_domains",
  nrow(full_design$variables) == 29353L &&
    nrow(common_design$variables) == 6540L &&
    nrow(safe_design$variables) == 7926L &&
    survey::degf(full_design) == 49L &&
    survey::degf(common_design) == 49L &&
    survey::degf(safe_design) == 49L,
  paste0(
    "full/common/safe=", nrow(full_design$variables), "/",
    nrow(common_design$variables), "/", nrow(safe_design$variables),
    "; df=", survey::degf(full_design), "/",
    survey::degf(common_design), "/", survey::degf(safe_design)
  ),
  "29353-row full MEC design is created first; common and safe-target domains retain design df=49"
)

a1_rhs <- paste(
  "age_ns1 + age_ns2 + age_ns3 + factor(RIAGENDR) +",
  "height_ns1 + height_ns2 + height_ns3 + factor(race_ethnicity) +",
  "factor(cycle_label) + factor(smoking_status) +",
  "bmi_ns1 + bmi_ns2 + bmi_ns3 + factor(education) +",
  "income_poverty_ratio"
)
exposure_terms <- list(
  v45_g0 = character(),
  v45_g1 = "E0",
  v45_g2 = "L_FEV1",
  v45_g3 = "L_FVC",
  v45_g4 = "L_RATIO",
  v45_g5a = c("L_FEV1", "L_RATIO"),
  v45_g5b = c("L_FVC", "L_RATIO"),
  v45_g6a = c("E0", "L_FEV1", "L_RATIO"),
  v45_g6b = c("E0", "L_FVC", "L_RATIO"),
  v45_g5c = c("L_FEV1", "L_FVC", "L_RATIO"),
  v45_g6c = c("E0", "L_FEV1", "L_FVC", "L_RATIO")
)
matrix_rows <- list()
completed_g_model <- list()
for (i in seq_along(completed_g)) {
  prepared <- v43$attach_passive_variables(
    completed_g[[i]], ledger$spline_knots
  )
  prepared <- cbind(prepared, gli_g[[i]])
  completed_g_model[[i]] <- prepared
  for (analysis_id in names(exposure_terms)) {
    rhs <- c(a1_rhs, exposure_terms[[analysis_id]])
    formula <- stats::as.formula(paste("~", paste(rhs, collapse = " + ")))
    matrix_rows[[length(matrix_rows) + 1L]] <-
      v45_model_matrix_audit(formula, prepared, analysis_id, i)
  }
}
model_matrix_audit <- dplyr::bind_rows(matrix_rows)
add_check(
  "G0_to_G6_model_matrices_full_rank",
  nrow(model_matrix_audit) == length(exposure_terms) * 2L &&
    all(model_matrix_audit$status == "PASS"),
  paste0(
    "matrices=", nrow(model_matrix_audit),
    "; failures=", sum(model_matrix_audit$status != "PASS")
  ),
  "all registered fixed-denominator G0-G6 and gated three-index sensitivity matrices are full column rank in both dry imputations"
)

weighted_residual_collinearity <- function(
    dat, exposure_names, block_id, imputation, omitted_cycle = "none") {
  use <- if (identical(omitted_cycle, "none")) {
    rep(TRUE, nrow(dat))
  } else {
    as.character(dat$cycle_label) != omitted_cycle
  }
  d <- dat[use, , drop = FALSE]
  w <- as.numeric(d$wtmec6yr)
  base <- stats::model.matrix(
    stats::as.formula(paste("~", a1_rhs)),
    data = d
  )
  residuals <- sapply(exposure_names, function(name) {
    stats::lm.wfit(base, as.numeric(d[[name]]), w = w)$residuals
  })
  if (is.null(dim(residuals))) residuals <- matrix(residuals, ncol = 1L)
  centered <- sweep(
    residuals, 2L,
    colSums(residuals * w) / sum(w),
    "-"
  )
  scales <- sqrt(colSums(centered^2 * w) / sum(w))
  standardized <- sweep(centered, 2L, scales, "/")
  correlation <- crossprod(standardized, standardized * w) / sum(w)
  eigenvalues <- eigen(correlation, symmetric = TRUE, only.values = TRUE)$values
  rank <- qr(standardized)$rank
  condition_index <- if (min(eigenvalues) > 0) {
    sqrt(max(eigenvalues) / min(eigenvalues))
  } else {
    Inf
  }
  off_diagonal <- correlation[row(correlation) != col(correlation)]
  state <- if (rank < length(exposure_names) ||
               !is.finite(condition_index)) {
    "NUMERICAL_STOP"
  } else if (condition_index >= 30) {
    "CAUTION"
  } else {
    "GO"
  }
  data.frame(
    block_id = block_id,
    imputation = as.integer(imputation),
    omitted_cycle = omitted_cycle,
    rows = nrow(d),
    exposure_count = length(exposure_names),
    residual_matrix_rank = rank,
    maximum_absolute_weighted_correlation =
      max(abs(off_diagonal)),
    residual_condition_index = condition_index,
    structural_state = state,
    status = if (state == "NUMERICAL_STOP") "FAIL" else "PASS",
    run_id = run_id,
    stringsAsFactors = FALSE
  )
}
collinearity_rows <- list()
blocks <- list(
  three_spirometric_indices = c("L_FEV1", "L_FVC", "L_RATIO"),
  pef_plus_three_spirometric_indices =
    c("E0", "L_FEV1", "L_FVC", "L_RATIO")
)
for (i in seq_along(completed_g_model)) {
  for (block_id in names(blocks)) {
    for (omitted in c("none", "E", "F", "G")) {
      collinearity_rows[[length(collinearity_rows) + 1L]] <-
        weighted_residual_collinearity(
          completed_g_model[[i]], blocks[[block_id]],
          block_id, i, omitted
        )
    }
  }
}
collinearity_audit <- dplyr::bind_rows(collinearity_rows)
add_check(
  "exposure_collinearity_structural_gate",
  all(collinearity_audit$status == "PASS"),
  paste0(
    "rows=", nrow(collinearity_audit),
    "; GO=", sum(collinearity_audit$structural_state == "GO"),
    "; CAUTION=", sum(collinearity_audit$structural_state == "CAUTION"),
    "; STOP=", sum(collinearity_audit$structural_state == "NUMERICAL_STOP")
  ),
  "full-sample and leave-one-cycle-out residual exposure blocks may be GO or CAUTION but never rank-deficient/NUMERICAL_STOP"
)

prepare_d1 <- function(completed) {
  out <- completed
  out$R_A <- factor(as.character(out$R_A), levels = c("0", "1"))
  out$age_centered <-
    as.numeric(out$RIDAGEYR) -
    sum(as.numeric(out$RIDAGEYR) * out$wtmec6yr) / sum(out$wtmec6yr)
  out$age_centered_squared <- out$age_centered^2
  out$sex <- factor(
    as.numeric(as.character(out$RIAGENDR)),
    levels = c(1, 2), labels = c("Male", "Female")
  )
  out$race_ethnicity <- factor(
    as.character(out$race_ethnicity),
    levels = c(
      "Mexican American", "Other Hispanic", "Non-Hispanic White",
      "Non-Hispanic Black", "Other/Multi-Racial"
    )
  )
  out$cycle_label <- factor(as.character(out$cycle_label), levels = c("E", "F", "G"))
  out$bmi_category <- cut(
    as.numeric(out$bmi),
    breaks = c(-Inf, 18.5, 25, 30, Inf), right = FALSE,
    labels = c("<18.5", "18.5-<25", "25-<30", ">=30")
  )
  out$smoking_status <- factor(
    as.character(out$smoking_status),
    levels = c("never", "former", "current")
  )
  education <- as.character(out$education)
  education_3 <- ifelse(
    education %in% c("<9th grade", "9-11th grade"), "<HS",
    ifelse(
      education == "High school/GED", "HS/GED",
      ifelse(
        education %in% c("Some college/AA", "College graduate+"),
        ">HS", NA_character_
      )
    )
  )
  out$education_3 <- factor(education_3, levels = c("<HS", "HS/GED", ">HS"))
  out$pir_category <- cut(
    as.numeric(out$income_poverty_ratio),
    breaks = c(-Inf, 1, 2, 4, Inf), right = FALSE,
    labels = c("<1", "1-<2", "2-<4", ">=4")
  )
  out$lung_disease <- factor(
    as.numeric(as.character(out$self_reported_emphysema_or_bronchitis)),
    levels = c(0, 1)
  )
  out$ever_asthma <- factor(
    as.numeric(as.character(out$ever_asthma)), levels = c(0, 1)
  )
  out$mobility_difficulty_routed <- factor(
    as.numeric(as.character(out$mobility_difficulty_routed)),
    levels = c(0, 1)
  )
  out$adl_iadl_difficulty_routed <- factor(
    as.numeric(as.character(out$adl_iadl_difficulty_routed)),
    levels = c(0, 1)
  )
  out$phq9_category <- cut(
    as.numeric(out$phq9_score),
    breaks = c(-Inf, 5, 10, Inf), right = FALSE,
    labels = c("0-4", "5-9", ">=10")
  )
  out$low_physical_activity <- factor(
    as.numeric(as.character(out$low_physical_activity)),
    levels = c(0, 1)
  )
  out
}
d1_formula <- stats::as.formula(paste(
  "R_A ~ age_centered + age_centered_squared + sex + race_ethnicity +",
  "cycle_label + height_cm + bmi_category + smoking_status + education_3 +",
  "pir_category + lung_disease + ever_asthma + mobility_difficulty_routed +",
  "adl_iadl_difficulty_routed + phq9_category + low_physical_activity"
))
d1_forbidden <- intersect(
  all.vars(d1_formula),
  c("death", "nelson_aalen", "followup_years", "PERMTH_EXM")
)
d1_rows <- lapply(seq_len(dry_s$first$m), function(i) {
  completed <- mice::complete(dry_s$first, action = i)
  prepared <- prepare_d1(completed)
  audit <- v45_model_matrix_audit(d1_formula, prepared, "v45_ipw_d1", i)
  audit$response_unchanged <- identical(
    as.character(prepared$R_A),
    as.character(mi_s$data$R_A)
  )
  audit$design_df <- survey::degf(safe_design)
  audit$formula_outcome_auxiliary_count <- length(d1_forbidden)
  audit$status <- if (
    audit$columns == 28L && audit$matrix_rank == 28L &&
      audit$response_unchanged &&
      audit$design_df > audit$columns &&
      audit$formula_outcome_auxiliary_count == 0L
  ) "PASS" else "FAIL"
  audit
})
d1_matrix_audit <- dplyr::bind_rows(d1_rows)
model_matrix_audit <- dplyr::bind_rows(model_matrix_audit, d1_matrix_audit)
add_check(
  "D1_response_matrix_full_rank",
  nrow(d1_matrix_audit) == 2L &&
    all(d1_matrix_audit$status == "PASS"),
  paste0(
    "columns/rank=",
    paste(
      paste0(d1_matrix_audit$columns, "/", d1_matrix_audit$matrix_rank),
      collapse = "|"
    ),
    "; df=", paste(d1_matrix_audit$design_df, collapse = "|"),
    "; outcome_auxiliary_terms=",
    paste(d1_matrix_audit$formula_outcome_auxiliary_count, collapse = "|")
  ),
  "D1 is 28/28 full rank in both completed dry imputations; design df=49; R_A unchanged; death/Nelson-Aalen absent from the response formula"
)

all_checks <- dplyr::bind_rows(checks)
add_check(
  "no_new_mortality_model_or_result_artifact",
  TRUE,
  "mortality_model_fit_count=0; coefficient_export_count=0; production_m50_count=0",
  "zero mortality models, zero new coefficient/result exports, and no production MI object"
)
all_checks <- dplyr::bind_rows(checks)

definitions <- list(
  contract_version = "v45_0",
  created_at_utc = format(Sys.time(), "%Y-%m-%dT%H:%M:%SZ", tz = "UTC"),
  run_id = run_id,
  no_completed_data_or_mids_saved = TRUE,
  MI_B = list(
    denominator = "primary_domain",
    denominator_n = nrow(mi_b$data),
    ordered_id_sha256 = contracts$ordered_id_sha256[contracts$object_id == "MI-B"],
    columns = names(mi_b$data),
    specification = mi_b$specification,
    inherited_signature_sha256 = mi_b_signature
  ),
  MI_G = list(
    denominator = "primary_domain & spirometry_abc",
    denominator_n = nrow(mi_g$data),
    ordered_id_sha256 = contracts$ordered_id_sha256[contracts$object_id == "MI-G"],
    columns = names(mi_g$data),
    specification = mi_g$specification,
    GLI_rule = list(
      package = "rspiro",
      package_version = as.character(utils::packageVersion("rspiro")),
      primary = "GLI Global 2022",
      sensitivity = "GLI-2012",
      lln_z = v45_gli_lln_z,
      recompute_after_completed_height = TRUE
    )
  ),
  MI_S = list(
    denominator = "safe_target",
    denominator_n = nrow(mi_s$data),
    ordered_id_sha256 = contracts$ordered_id_sha256[contracts$object_id == "MI-S"],
    columns = names(mi_s$data),
    specification = mi_s$specification,
    response_formula = paste(deparse(d1_formula), collapse = " ")
  )
)

staging_tag <- paste0(".staging_", run_id)
results_staging <- file.path(root, "results", "v45", staging_tag)
derived_staging <- file.path(root, "derived_sensitive", "v45", staging_tag)
logs_staging <- file.path(root, "logs", "v45", staging_tag)
dir.create(results_staging, recursive = TRUE, showWarnings = FALSE)
dir.create(derived_staging, recursive = TRUE, showWarnings = FALSE)
dir.create(logs_staging, recursive = TRUE, showWarnings = FALSE)
on.exit({
  if (dir.exists(results_staging)) unlink(results_staging, recursive = TRUE)
  if (dir.exists(derived_staging)) unlink(derived_staging, recursive = TRUE)
  if (dir.exists(logs_staging)) unlink(logs_staging, recursive = TRUE)
}, add = TRUE)

definition_staging_path <- file.path(
  derived_staging, basename(definition_path)
)
v45_atomic_save_rds(definitions, definition_staging_path)
contracts$definition_sha256 <- v45_sha256_file(definition_staging_path)
contracts <- contracts[
  c(
    "object_id", "denominator_n", "frozen_event_n", "response_n",
    "design_strata", "design_psu", "height_missing_n", "weight_missing_n",
    "bmi_missing_n", "observed_bmi_n", "active_target_n",
    "input_column_n", "seed", "dry_m", "dry_maxit",
    "specification_sha256", "ordered_id_sha256", "dry_payload_sha256",
    "definition_sha256", "dry_elapsed_seconds", "warning_count",
    "logged_event_count", "status", "run_id"
  )
]

tables <- list(
  contracts = contracts,
  predictors = predictor_audit,
  structural = all_checks,
  gli = dplyr::bind_rows(gli_validation, bmi_audit),
  matrices = model_matrix_audit,
  collinearity = collinearity_audit
)
for (name in names(tables)) {
  v45_atomic_write_tsv(
    tables[[name]],
    file.path(results_staging, basename(result_paths[[name]]))
  )
}
append_log("All structural gates passed; publishing aggregate-only outputs.")
log_lines <- c(
  log_lines,
  paste0("completed_at_utc: ",
         format(Sys.time(), "%Y-%m-%dT%H:%M:%SZ", tz = "UTC")),
  paste0("structural_checks: ", nrow(all_checks), " PASS"),
  "mortality_model_fit_count: 0",
  "coefficient_export_count: 0",
  "completed_mids_saved: 0",
  "next_gate: independent validation"
)
v45_atomic_write_lines(log_lines, file.path(logs_staging, basename(log_path)))

for (name in names(result_paths)) {
  source_path <- file.path(results_staging, basename(result_paths[[name]]))
  if (!file.rename(source_path, result_paths[[name]])) {
    stop("Could not promote aggregate preflight output: ", name, call. = FALSE)
  }
}
if (!file.rename(definition_staging_path, definition_path)) {
  stop("Could not promote MI object definitions.", call. = FALSE)
}
if (!file.rename(file.path(logs_staging, basename(log_path)), log_path)) {
  stop("Could not promote structural-preflight log.", call. = FALSE)
}
unlink(results_staging, recursive = TRUE)
unlink(derived_staging, recursive = TRUE)
unlink(logs_staging, recursive = TRUE)

gate_path <- file.path(root, "work_v45", "gate_state_v45.yml")
gate <- yaml::read_yaml(gate_path)
gate$updated_at <- format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")
gate$stage1_mi_object_structural_preflight$status <-
  "PASS_PENDING_INDEPENDENT_VALIDATION"
gate$stage1_independent_validation$status <- "NOT_RUN"
gate$outcome_execution_allowed <- FALSE
gate$new_mortality_coefficient_inspection_allowed <- FALSE
gate$production_m50_objects_allowed <- FALSE
gate$next_authorized_step <- "independent_validate_stage1"
v45_atomic_write_yaml(gate, gate_path)

message(
  "v45 Stage 1 structural preflight passed. No mortality model was fitted ",
  "and no new coefficient was generated or inspected."
)
