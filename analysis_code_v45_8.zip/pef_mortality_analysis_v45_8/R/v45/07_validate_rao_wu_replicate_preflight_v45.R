# v45 Stage 2 independent validation of the no-outcome Rao-Wu preflight.
#
# This validator never opens the source row-level ledger. It validates the
# frozen aggregate outputs and the local restricted replicate contract.

options(stringsAsFactors = FALSE)

stage2_root <- function() {
  args <- commandArgs(trailingOnly = FALSE)
  file_arg <- grep("^--file=", args, value = TRUE)
  if (!length(file_arg)) return(normalizePath(getwd(), mustWork = TRUE))
  script <- sub("^--file=", "", file_arg[[1]])
  normalizePath(file.path(dirname(script), "..", ".."), mustWork = TRUE)
}

root <- stage2_root()
source(file.path(root, "R", "v45", "01_nhanes_common_utilities_v45.R"))
v45_require_packages(root)
v45_verify_frozen_manifests(root)

stage2_object_sha256 <- function(object) {
  digest::digest(
    object,
    algo = "sha256",
    serialize = TRUE,
    serializeVersion = 3L
  )
}
stage2_text_sha256 <- function(lines) {
  digest::digest(
    enc2utf8(paste(lines, collapse = "\n")),
    algo = "sha256",
    serialize = FALSE
  )
}
stage2_integer_sha256 <- function(x) {
  stage2_text_sha256(c(
    paste0("integer_length=", length(x)),
    paste(sprintf("%d", as.integer(x)), collapse = "\u241f")
  ))
}
stage2_numeric_sha256 <- function(x) {
  raw_value <- writeBin(
    as.double(x),
    con = raw(),
    size = 8L,
    endian = "little"
  )
  stage2_text_sha256(c(
    paste0("float64_length=", length(x)),
    digest::digest(
      raw_value, algo = "sha256", serialize = FALSE
    )
  ))
}
stage2_matrix_sha256 <- function(x) {
  stage2_text_sha256(c(
    paste0("dimensions=", paste(dim(x), collapse = "x")),
    paste0(
      "rownames=",
      paste(rownames(x), collapse = "\u241f")
    ),
    paste0(
      "colnames=",
      paste(colnames(x), collapse = "\u241f")
    ),
    paste0(
      "float64_values=",
      stage2_numeric_sha256(as.vector(x))
    )
  ))
}
stage2_key_sha256 <- function(key) {
  rows <- paste(
    sprintf("%d", as.integer(key$cluster_row)),
    as.character(key$design_psu),
    as.character(key$design_strata),
    as.character(key$raw_within_stratum_psu),
    as.character(key$cycle_label),
    sep = "\u241f"
  )
  stage2_text_sha256(c(
    paste(names(key), collapse = "\u241f"),
    rows
  ))
}

run_paths <- c(
  contracts = file.path(
    root, "results", "v45", "v45_rao_wu_matrix_contracts.tsv"
  ),
  structural = file.path(
    root, "results", "v45", "v45_rao_wu_structural_preflight.tsv"
  ),
  interfaces = file.path(
    root, "results", "v45",
    "v45_rao_wu_synthetic_interface_validation.tsv"
  ),
  contract = file.path(
    root, "derived_sensitive", "v45",
    "v45_rao_wu_replicate_contract.rds"
  ),
  log = file.path(
    root, "logs", "v45", "v45_rao_wu_replicate_preflight.log"
  )
)
freeze_paths <- c(
  code = file.path(
    root, "work_v45", "v45_rao_wu_code_manifest.tsv"
  ),
  functions = file.path(
    root, "work_v45", "v45_rao_wu_function_manifest.tsv"
  ),
  roots = file.path(
    root, "work_v45", "v45_rao_wu_freeze_roots.tsv"
  ),
  validation = file.path(
    root, "results", "v45",
    "v45_rao_wu_stage2_freeze_validation.tsv"
  )
)
validation_path <- file.path(
  root, "results", "v45",
  "v45_rao_wu_independent_validation.tsv"
)
manifest_path <- file.path(
  root, "results", "v45",
  "v45_rao_wu_output_manifest.tsv"
)
qa_path <- file.path(
  root, "output", "qa", "v45",
  "V45_STAGE2_RAO_WU_PREFLIGHT_QA.md"
)

if (any(!file.exists(c(run_paths, freeze_paths)))) {
  absent <- c(run_paths, freeze_paths)[
    !file.exists(c(run_paths, freeze_paths))
  ]
  stop(
    "Stage 2 validation inputs are incomplete: ",
    paste(absent, collapse = "; "),
    call. = FALSE
  )
}
if (any(file.exists(c(validation_path, manifest_path, qa_path)))) {
  stop(
    "Independent Stage 2 outputs already exist; refusing overwrite.",
    call. = FALSE
  )
}

verify_output <- system2(
  file.path(R.home("bin"), "Rscript"),
  c(
    "--vanilla",
    file.path(root, "R", "v45", "05_freeze_rao_wu_preflight_v45.R"),
    "--verify"
  ),
  stdout = TRUE,
  stderr = TRUE
)
verify_status <- attr(verify_output, "status")
freeze_verifies <- is.null(verify_status) || verify_status == 0L

spec <- yaml::read_yaml(
  file.path(root, "work_v45", "rao_wu_preflight_spec_v45.yml")
)
code_manifest <- utils::read.delim(
  freeze_paths[["code"]], stringsAsFactors = FALSE, check.names = FALSE
)
function_manifest <- utils::read.delim(
  freeze_paths[["functions"]],
  stringsAsFactors = FALSE, check.names = FALSE
)
freeze_roots <- utils::read.delim(
  freeze_paths[["roots"]],
  stringsAsFactors = FALSE, check.names = FALSE
)
freeze_validation <- utils::read.delim(
  freeze_paths[["validation"]],
  stringsAsFactors = FALSE, check.names = FALSE
)
contracts <- utils::read.delim(
  run_paths[["contracts"]],
  stringsAsFactors = FALSE, check.names = FALSE
)
structural <- utils::read.delim(
  run_paths[["structural"]],
  stringsAsFactors = FALSE, check.names = FALSE
)
interfaces <- utils::read.delim(
  run_paths[["interfaces"]],
  stringsAsFactors = FALSE, check.names = FALSE
)
contract <- readRDS(run_paths[["contract"]])
log_lines <- readLines(run_paths[["log"]], warn = FALSE)

checks <- list()
add_check <- function(check, pass, detail) {
  checks[[length(checks) + 1L]] <<- data.frame(
    check = check,
    status = if (isTRUE(pass)) "PASS" else "FAIL",
    detail = v45_one_line(detail),
    stringsAsFactors = FALSE
  )
}

add_check(
  "stage0_1_and_stage2_freezes_verify",
  freeze_verifies &&
    nrow(code_manifest) == 7L &&
    all(code_manifest$exists) &&
    all(code_manifest$immutable) &&
    nrow(function_manifest) == 9L &&
    all(function_manifest$package == "survey") &&
    all(function_manifest$package_version == "4.5") &&
    all(freeze_validation$status == "PASS"),
  paste0(
    "stage2_verify_exit=", if (freeze_verifies) 0L else verify_status,
    "; code_assets=", nrow(code_manifest),
    "; survey_functions=", nrow(function_manifest)
  )
)

required_structural <- c(
  "full_MEC_design_allowlist_and_anchors",
  "ordered_full_MEC_design_slice_hash",
  "full_MEC_design_df",
  "same_seed_bitwise_regeneration",
  "both_module_matrices_structurally_valid",
  "module_compressed_index_and_key_identical",
  "module_seeds_and_hashes_distinct",
  "independent_multiplier_value_hash_anchors",
  "runnable_250_prefix_contract",
  "production_theta_manual_and_survey_interface_concordance",
  "all_synthetic_interfaces_pass",
  "no_actual_outcome_or_exposure_downstream_reference"
)
add_check(
  "execution_structural_checks_complete",
  !anyDuplicated(structural$check) &&
    setequal(structural$check, required_structural) &&
    all(structural$status == "PASS"),
  paste0(
    "checks=", nrow(structural),
    "; failures=", sum(structural$status != "PASS"),
    "; missing=",
    paste(setdiff(required_structural, structural$check), collapse = "|")
  )
)

expected_interfaces <- data.frame(
  interface_id = c(
    "synthetic_survey_mean",
    "synthetic_survey_mean",
    "synthetic_response_logistic",
    "synthetic_paired_Cox",
    "synthetic_composite_response_Cox_full",
    "synthetic_composite_response_Cox_prefix"
  ),
  module_id = c(
    "RW-GLI", "RW-IPW", "RW-IPW", "RW-GLI", "RW-IPW", "RW-IPW"
  ),
  replicates_requested = c(500L, 500L, 500L, 500L, 500L, 250L),
  stringsAsFactors = FALSE
)
observed_interface_key <- interfaces[
  , c("interface_id", "module_id", "replicates_requested"),
  drop = FALSE
]
ordered_key <- function(x) {
  x[order(x$interface_id, x$module_id), , drop = FALSE]
}
rownames(observed_interface_key) <- NULL
expected_interfaces <- ordered_key(expected_interfaces)
observed_interface_key <- ordered_key(observed_interface_key)
rownames(expected_interfaces) <- NULL
rownames(observed_interface_key) <- NULL
add_check(
  "synthetic_interface_contract_complete",
  identical(observed_interface_key, expected_interfaces) &&
    all(interfaces$replicates_finite ==
          interfaces$replicates_requested) &&
    all(interfaces$warning_count == 0L) &&
    all(interfaces$variance_finite) &&
    all(interfaces$variance_positive) &&
    all(interfaces$status == "PASS"),
  paste0(
    "interfaces=", nrow(interfaces),
    "; requested/finite=",
    paste0(
      interfaces$replicates_requested, "/",
      interfaces$replicates_finite,
      collapse = "|"
    ),
    "; warnings=", sum(interfaces$warning_count)
  )
)

allowed_fields <- c(
  "SEQN", "design_psu", "design_strata", "SDMVPSU",
  "cycle_label", "wtmec6yr"
)
key <- contract$cluster_key
index <- contract$full_design_cluster_index
pweights <- contract$full_design_pweights
stratum_sizes <- table(key$design_strata)
design_contract_ok <-
  identical(contract$contract_version, "v45_0_stage2") &&
  identical(contract$design$allowed_fields, allowed_fields) &&
  identical(as.integer(contract$design$n), 29353L) &&
  identical(as.integer(contract$design$strata), 45L) &&
  identical(as.integer(contract$design$psu), 94L) &&
  identical(as.integer(contract$design$design_df), 49L) &&
  identical(
    contract$design$ordered_design_slice_sha256,
    spec$design$ordered_design_slice_sha256
  ) &&
  is.data.frame(key) &&
  nrow(key) == 94L &&
  !anyDuplicated(key$design_psu) &&
  length(unique(key$design_strata)) == 45L &&
  sum(stratum_sizes == 2L) == 41L &&
  sum(stratum_sizes == 3L) == 4L &&
  length(index) == 29353L &&
  all(is.finite(index) & index %in% seq_len(94L)) &&
  setequal(unique(index), seq_len(94L)) &&
  length(pweights) == 29353L &&
  all(is.finite(pweights) & pweights > 0) &&
  identical(
    stage2_integer_sha256(index),
    contract$full_design_cluster_index_sha256
  ) &&
  identical(
    stage2_numeric_sha256(pweights),
    contract$full_design_pweights_sha256
  )
add_check(
  "restricted_contract_design_and_compression",
  design_contract_ok,
  paste0(
    "N/strata/PSU/df=",
    contract$design$n, "/", contract$design$strata, "/",
    contract$design$psu, "/", contract$design$design_df,
    "; index_n=", length(index),
    "; pweight_n=", length(pweights)
  )
)

canonical_module_hash <- function(module_id, module) {
  fields <- c(
    contract_version = "v45_0_stage2",
    matrix_id = module_id,
    seed = as.character(module$seed),
    RNGkind = paste(
      c("Mersenne-Twister", "Inversion", "Rejection"),
      collapse = "|"
    ),
    type = "subbootstrap",
    replicates = "500",
    R_version = as.character(getRversion()),
    survey_version = as.character(utils::packageVersion("survey")),
    matrix_sha256 = stage2_matrix_sha256(module$matrix),
    index_sha256 = stage2_integer_sha256(index),
    key_sha256 = stage2_key_sha256(key),
    pweights_sha256 = stage2_numeric_sha256(pweights),
    ordered_design_slice_sha256 =
      contract$design$ordered_design_slice_sha256,
    seqn_order_sha256 = contract$design$seqn_order_sha256,
    scale = sprintf("%.17g", module$scale),
    rscales_sha256 = stage2_numeric_sha256(module$rscales),
    mse = tolower(as.character(module$mse)),
    combined_weights =
      tolower(as.character(module$combined_weights)),
    design_df = "49",
    stage0_1_input_root = freeze_roots$sha256[
      freeze_roots$root_id == "stage0_1_input_root"
    ],
    survey_function_root = freeze_roots$sha256[
      freeze_roots$root_id == "stage2_survey_function_root"
    ]
  )
  stage2_text_sha256(paste(
    names(fields), fields, sep = "\u241f"
  ))
}
prefix_matrix_hash <- function(module) {
  stage2_matrix_sha256(
    module$matrix[, seq_len(250L), drop = FALSE]
  )
}
prefix_contract_hash <- function(module) {
  fields <- c(
    matrix_sha256 = prefix_matrix_hash(module),
    scale = sprintf("%.17g", 1 / 249),
    rscales_sha256 = stage2_numeric_sha256(rep(1, 250L)),
    mse = "true",
    combined_weights = "false"
  )
  stage2_text_sha256(paste(
    names(fields), fields, sep = "\u241f"
  ))
}
multiplier_value_hash <- function(module, columns) {
  stage2_object_sha256(unname(
    module$matrix[, seq_len(columns), drop = FALSE]
  ))
}
validate_module <- function(module_id, module, module_spec) {
  matrix <- module$matrix
  groups <- split(seq_len(nrow(key)), key$design_strata)
  balance <- max(vapply(
    groups,
    function(rows) {
      max(abs(colSums(matrix[rows, , drop = FALSE]) - length(rows)))
    },
    numeric(1)
  ))
  zero_support <- all(vapply(
    groups,
    function(rows) {
      all(apply(
        matrix[rows, , drop = FALSE],
        2L,
        function(x) any(x == 0)
      ))
    },
    logical(1)
  ))
  c(
    dimensions = identical(dim(matrix), c(94L, 500L)),
    dimnames = identical(rownames(matrix), key$design_psu),
    finite_nonnegative = all(is.finite(matrix) & matrix >= 0),
    stratum_balance = is.finite(balance) && balance <= 1e-12,
    zero_support = zero_support,
    seed = identical(as.integer(module$seed), as.integer(module_spec$seed)),
    production_scale =
      isTRUE(all.equal(module$scale, 1 / 499, tolerance = 0)) &&
      isTRUE(all.equal(module$production_scale, 1 / 499, tolerance = 0)),
    prefix_scale =
      isTRUE(all.equal(
        module$stability_prefix_scale, 1 / 249, tolerance = 0
      )),
    rscales = length(module$rscales) == 500L &&
      all(module$rscales == 1),
    flags = isTRUE(module$mse) && !isTRUE(module$combined_weights),
    canonical_hash = identical(
      canonical_module_hash(module_id, module),
      module$full_sha256
    ),
    full_value_hash = identical(
      multiplier_value_hash(module, 500L),
      module_spec$multiplier_value_sha256_500
    ) && identical(
      module$multiplier_value_sha256_500,
      module_spec$multiplier_value_sha256_500
    ),
    prefix_value_hash = identical(
      multiplier_value_hash(module, 250L),
      module_spec$multiplier_value_sha256_prefix_250
    ) && identical(
      module$multiplier_value_sha256_prefix_250,
      module_spec$multiplier_value_sha256_prefix_250
    ),
    prefix_matrix_hash = identical(
      prefix_matrix_hash(module),
      module$prefix_250_matrix_sha256
    ),
    prefix_contract_hash = identical(
      prefix_contract_hash(module),
      module$prefix_250_contract_sha256
    )
  )
}
gli_audit <- validate_module(
  "RW-GLI", contract$modules[["RW-GLI"]],
  spec$modules$paired_GLI
)
ipw_audit <- validate_module(
  "RW-IPW", contract$modules[["RW-IPW"]],
  spec$modules$observation_IPW
)
add_check(
  "both_replicate_modules_rehash_and_balance",
  all(gli_audit) &&
    all(ipw_audit) &&
    !identical(
      contract$modules[["RW-GLI"]]$full_sha256,
      contract$modules[["RW-IPW"]]$full_sha256
    ),
  paste0(
    "GLI=", paste(names(gli_audit)[!gli_audit], collapse = "|"),
    "; IPW=", paste(names(ipw_audit)[!ipw_audit], collapse = "|")
  )
)

contract_sha <- v45_sha256_file(run_paths[["contract"]])
contract_table_ok <-
  nrow(contracts) == 2L &&
  setequal(contracts$matrix_id, c("RW-GLI", "RW-IPW")) &&
  setequal(as.integer(contracts$seed), c(450401L, 450402L)) &&
  all(contracts$cluster_rows == 94L) &&
  all(contracts$replicate_columns == 500L) &&
  all(contracts$stability_prefix_columns == 250L) &&
  all(contracts$scale == 1 / 499) &&
  all(contracts$rscales_unique_n == 1L) &&
  all(contracts$mse) &&
  all(!contracts$combined_weights) &&
  all(contracts$design_df == 49L) &&
  all(contracts$contract_sha256 == contract_sha) &&
  all(contracts$status == "PASS")
for (i in seq_len(nrow(contracts))) {
  module <- contract$modules[[contracts$matrix_id[[i]]]]
  contract_table_ok <- contract_table_ok &&
    identical(contracts$full_sha256[[i]], module$full_sha256) &&
    identical(
      contracts$prefix_250_matrix_sha256[[i]],
      module$prefix_250_matrix_sha256
    ) &&
    identical(
      contracts$prefix_250_contract_sha256[[i]],
      module$prefix_250_contract_sha256
    )
}
add_check(
  "aggregate_contract_table_matches_restricted_RDS",
  contract_table_ok,
  paste0(
    "rows=", nrow(contracts),
    "; contract_sha=", contract_sha
  )
)

script_path <- file.path(
  root, "R", "v45", "06_rao_wu_replicate_preflight_v45.R"
)
parsed <- parse(file = script_path, keep.source = TRUE)
parse_data <- getParseData(parsed)
code_tokens <- parse_data$text[
  parse_data$token %in% c(
    "SYMBOL", "SYMBOL_FUNCTION_CALL", "STR_CONST"
  )
]
code_tokens <- gsub("^['\"]|['\"]$", "", code_tokens)
forbidden_fields <- c(
  "death", "followup_years", "pef_l_min",
  "E0", "E0b", "fev1_l", "fvc_l"
)
all_code_names <- all.names(parsed, functions = TRUE, unique = FALSE)
add_check(
  "static_no_true_outcome_or_exposure_reference",
  !any(tolower(code_tokens) %in% tolower(forbidden_fields)) &&
    !"suppressWarnings" %in% all_code_names &&
    all(c(
      "withReplicates", "glm", "coxph", "quantile"
    ) %in% all_code_names),
  paste0(
    "forbidden_tokens=",
    paste(
      unique(code_tokens[
        tolower(code_tokens) %in% tolower(forbidden_fields)
      ]),
      collapse = "|"
    ),
    "; suppressWarnings=",
    "suppressWarnings" %in% all_code_names
  )
)

forbidden_public_columns <- c(
  "coef", "coefficient", "beta", "hazard_ratio",
  "hr", "standard_error", "se", "p_value"
)
public_columns <- unique(c(
  names(contracts), names(structural), names(interfaces)
))
log_ok <- all(c(
  "actual_outcome_field_use: 0",
  "actual_exposure_field_use: 0",
  "actual_mortality_model_fit_count: 0",
  "synthetic_interface_only: true"
) %in% log_lines)
add_check(
  "no_result_or_row_level_public_leak",
  !any(tolower(public_columns) %in% forbidden_public_columns) &&
    isFALSE(contract$person_level_expanded_matrix_saved) &&
    isFALSE(contract$true_outcome_or_exposure_saved) &&
    isFALSE(contract$synthetic_parameter_values_saved) &&
    log_ok,
  paste0(
    "public_columns=", length(public_columns),
    "; forbidden_columns=",
    paste(
      public_columns[
        tolower(public_columns) %in% forbidden_public_columns
      ],
      collapse = "|"
    ),
    "; log_contract=", log_ok
  )
)

validation <- dplyr::bind_rows(checks)
validation$validated_at_utc <- format(
  Sys.time(), "%Y-%m-%dT%H:%M:%SZ", tz = "UTC"
)
if (any(validation$status != "PASS")) {
  stop(
    "Independent Stage 2 validation failed: ",
    paste(
      validation$check[validation$status != "PASS"],
      collapse = ", "
    ),
    call. = FALSE
  )
}

qa_lines <- c(
  "# v45 Stage 2 Rao–Wu no-outcome preflight QA",
  "",
  "**Disposition: PASS.**",
  "",
  paste0(
    "The complete NHANES MEC design contract was independently validated at ",
    "N=", contract$design$n, ", ", contract$design$strata,
    " strata, ", contract$design$psu, " PSUs and design df ",
    contract$design$design_df, "."
  ),
  "",
  paste0(
    "Two prospectively seeded 94×500 Rao–Wu n−1 multiplier matrices passed ",
    "same-seed regeneration, independent value-hash, stratum-balance, ",
    "compressed-index, pweight, 1/499 production-scale and literal ",
    "1/249 250-prefix checks."
  ),
  "",
  paste0(
    "Synthetic-only interfaces passed for survey means, response logistic ",
    "regression, paired Cox regression and the full original/uncapped/p99/",
    "p97.5 response–weight–Cox chain. All 500 production-interface and all ",
    "250 prefix-interface replicates were finite, their covariance matrices ",
    "were finite/symmetric/positive-semidefinite, and no fitted warning was ",
    "suppressed."
  ),
  "",
  paste0(
    "The source RDS had to be physically deserialized because RDS does not ",
    "support column-selective reads. The execution immediately extracted only ",
    "the six frozen design fields. Static parsing and output-schema checks ",
    "confirmed that no true exposure or mortality field was referenced ",
    "downstream and no true model coefficient was fitted, inspected or ",
    "exported."
  ),
  "",
  "Outcome execution and production m=50 gates remain closed.",
  "",
  "Next authorized action: freeze the production MI execution contract."
)

v45_atomic_write_tsv(validation, validation_path)
v45_atomic_write_lines(qa_lines, qa_path)

manifest_members <- c(
  freeze_paths,
  run_paths,
  independent_validation = validation_path,
  qa_report = qa_path
)
output_manifest <- data.frame(
  asset_id = names(manifest_members),
  path_alias = substring(
    normalizePath(manifest_members, mustWork = TRUE),
    nchar(normalizePath(root, mustWork = TRUE)) + 2L
  ),
  bytes = as.numeric(file.info(manifest_members)$size),
  sha256 = vapply(
    manifest_members, v45_sha256_file, character(1)
  ),
  local_restricted = names(manifest_members) == "contract",
  stringsAsFactors = FALSE
)
v45_atomic_write_tsv(output_manifest, manifest_path)

gate_path <- file.path(root, "work_v45", "gate_state_v45.yml")
gate <- yaml::read_yaml(gate_path)
gate$updated_at <- format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")
gate$stage2_rao_wu_preflight_freeze$status <- "PASS"
gate$stage2_rao_wu_structural_preflight$status <- "PASS"
gate$stage2_rao_wu_independent_validation$status <- "PASS"
gate$outcome_execution_allowed <- FALSE
gate$new_mortality_coefficient_inspection_allowed <- FALSE
gate$production_m50_objects_allowed <- FALSE
gate$next_authorized_step <- "freeze_production_MI_execution"
v45_atomic_write_yaml(gate, gate_path)

message(
  "v45 Stage 2 independent Rao-Wu validation PASS. Production MI and ",
  "outcome gates remain closed."
)
