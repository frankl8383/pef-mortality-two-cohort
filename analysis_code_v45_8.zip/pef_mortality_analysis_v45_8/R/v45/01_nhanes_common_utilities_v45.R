# v45 common utilities for the NHANES freeze and no-coefficient preflight.
#
# This file contains data preparation, imputation-contract, deterministic
# hashing, and matrix-dimension helpers only. It never fits an outcome model.

options(stringsAsFactors = FALSE)

v45_project_root <- function() {
  args <- commandArgs(trailingOnly = FALSE)
  file_arg <- grep("^--file=", args, value = TRUE)
  if (length(file_arg)) {
    script <- sub("^--file=", "", file_arg[[1]])
    return(normalizePath(file.path(dirname(script), "..", ".."), mustWork = TRUE))
  }
  normalizePath(getwd(), mustWork = TRUE)
}

v45_prepend_frozen_library <- function(root) {
  library_root <- file.path(root, "work_v43", "renv", "library")
  candidates <- list.dirs(library_root, recursive = TRUE, full.names = TRUE)
  mice_paths <- candidates[basename(candidates) == "mice"]
  if (!length(mice_paths)) {
    stop("The inherited v43 library containing mice is unavailable.", call. = FALSE)
  }
  frozen_lib <- dirname(mice_paths[[1]])
  .libPaths(unique(c(frozen_lib, .libPaths())))
  invisible(frozen_lib)
}

v45_require_packages <- function(root) {
  frozen_lib <- v45_prepend_frozen_library(root)
  packages <- c(
    "digest", "dplyr", "haven", "mice", "readr", "rspiro",
    "survey", "survival", "tibble", "tidyr", "yaml"
  )
  missing <- packages[
    !vapply(packages, requireNamespace, logical(1), quietly = TRUE)
  ]
  if (length(missing)) {
    stop(
      "v45 cannot continue because frozen runtime packages are unavailable: ",
      paste(missing, collapse = ", "),
      call. = FALSE
    )
  }
  observed <- vapply(
    packages,
    function(pkg) as.character(utils::packageVersion(pkg)),
    character(1)
  )
  if (!identical(unname(observed[["mice"]]), "3.19.0")) {
    stop("Expected mice 3.19.0; observed ", observed[["mice"]], ".", call. = FALSE)
  }
  if (!identical(unname(observed[["rspiro"]]), "0.5")) {
    stop("Expected rspiro 0.5; observed ", observed[["rspiro"]], ".", call. = FALSE)
  }
  options(survey.lonely.psu = "adjust")
  invisible(list(library = frozen_lib, packages = observed))
}

v45_sha256_file <- function(path) {
  if (!file.exists(path) || dir.exists(path)) return(NA_character_)
  digest::digest(file = path, algo = "sha256", serialize = FALSE)
}

v45_object_sha256 <- function(object) {
  digest::digest(object, algo = "sha256", serialize = TRUE)
}

v45_one_line <- function(x, empty = "") {
  x <- trimws(as.character(x))
  x <- x[!is.na(x) & nzchar(x)]
  if (!length(x)) return(empty)
  gsub("[\r\n]+", " ", paste(x, collapse = "; "))
}

v45_atomic_write_tsv <- function(dat, path) {
  dir.create(dirname(path), recursive = TRUE, showWarnings = FALSE)
  tmp <- tempfile(pattern = paste0(".", basename(path), "."), tmpdir = dirname(path))
  on.exit(if (file.exists(tmp)) unlink(tmp), add = TRUE)
  utils::write.table(
    dat, tmp, sep = "\t", quote = FALSE, row.names = FALSE,
    col.names = TRUE, na = ""
  )
  if (!file.rename(tmp, path)) {
    stop("Could not atomically publish TSV: ", path, call. = FALSE)
  }
  invisible(path)
}

v45_atomic_write_lines <- function(lines, path) {
  dir.create(dirname(path), recursive = TRUE, showWarnings = FALSE)
  tmp <- tempfile(pattern = paste0(".", basename(path), "."), tmpdir = dirname(path))
  on.exit(if (file.exists(tmp)) unlink(tmp), add = TRUE)
  writeLines(lines, tmp, useBytes = TRUE)
  if (!file.rename(tmp, path)) {
    stop("Could not atomically publish text: ", path, call. = FALSE)
  }
  invisible(path)
}

v45_atomic_write_yaml <- function(object, path) {
  dir.create(dirname(path), recursive = TRUE, showWarnings = FALSE)
  tmp <- tempfile(pattern = paste0(".", basename(path), "."), tmpdir = dirname(path))
  on.exit(if (file.exists(tmp)) unlink(tmp), add = TRUE)
  yaml::write_yaml(object, tmp)
  if (!file.rename(tmp, path)) {
    stop("Could not atomically publish YAML: ", path, call. = FALSE)
  }
  invisible(path)
}

v45_atomic_save_rds <- function(object, path, version = 3L) {
  dir.create(dirname(path), recursive = TRUE, showWarnings = FALSE)
  tmp <- tempfile(pattern = paste0(".", basename(path), "."), tmpdir = dirname(path))
  on.exit(if (file.exists(tmp)) unlink(tmp), add = TRUE)
  saveRDS(object, tmp, version = version, compress = "xz")
  if (!file.rename(tmp, path)) {
    stop("Could not atomically publish RDS: ", path, call. = FALSE)
  }
  invisible(path)
}

v45_verify_frozen_manifests <- function(root) {
  paths <- c(
    predecessor = file.path(root, "work_v45", "v45_predecessor_manifest.tsv"),
    inputs = file.path(root, "work_v45", "v45_input_manifest_private.tsv"),
    code = file.path(root, "work_v45", "v45_code_authorization_manifest.tsv"),
    runtime = file.path(root, "work_v45", "v45_runtime_manifest.tsv"),
    source = file.path(root, "work_v45", "v45_source_hash_manifest.tsv"),
    roots = file.path(root, "work_v45", "v45_freeze_roots.tsv")
  )
  if (any(!file.exists(paths))) {
    stop(
      "v45 frozen manifests are incomplete: ",
      paste(names(paths)[!file.exists(paths)], collapse = ", "),
      call. = FALSE
    )
  }
  predecessor <- utils::read.delim(
    paths[["predecessor"]], stringsAsFactors = FALSE, check.names = FALSE
  )
  stable_predecessor <- predecessor$layer != "live_working_copy"
  stable_paths <- file.path(
    root,
    sub("^[^/]+/", "", predecessor$path_alias[stable_predecessor])
  )
  archive_rows <- predecessor$layer[stable_predecessor] ==
    "predecessor_code_archive"
  stable_paths[archive_rows] <- file.path(
    root, "output", "code_archive", "PEF_mortality_v44_2_code_candidate",
    sub("^V44_2_CODE_ARCHIVE/", "",
        predecessor$path_alias[stable_predecessor][archive_rows])
  )
  submission_rows <- predecessor$layer[stable_predecessor] ==
    "predecessor_submission_candidate"
  stable_paths[submission_rows] <- file.path(
    root, "output", "submission_v44_2",
    "BMC_Pulmonary_Medicine_PEF_v44_2_candidate",
    sub("^V44_2_SUBMISSION/", "",
        predecessor$path_alias[stable_predecessor][submission_rows])
  )
  stable_current <- vapply(stable_paths, v45_sha256_file, character(1))
  stable_ok <- all(
    !is.na(stable_current) &
      tolower(stable_current) ==
        tolower(predecessor$current_sha256[stable_predecessor])
  )
  live <- predecessor$layer == "live_working_copy"
  live_paths <- file.path(root, predecessor$path_alias[live])
  live_current <- vapply(live_paths, v45_sha256_file, character(1))
  live_ok <- all(
    !is.na(live_current) &
      tolower(live_current) == tolower(predecessor$current_sha256[live]) &
      grepl("DO_NOT_OVERWRITE$", predecessor$status[live])
  )
  verify_files <- function(path) {
    dat <- utils::read.delim(
      path, stringsAsFactors = FALSE, check.names = FALSE
    )
    current <- vapply(dat$path_private, v45_sha256_file, character(1))
    all(!is.na(current) & tolower(current) == tolower(dat$sha256))
  }
  inputs_ok <- verify_files(paths[["inputs"]])
  code_ok <- verify_files(paths[["code"]])
  runtime <- utils::read.delim(
    paths[["runtime"]], stringsAsFactors = FALSE, check.names = FALSE
  )
  package_rows <- runtime$kind == "R_package"
  runtime_versions <- vapply(
    runtime$component[package_rows],
    function(pkg) as.character(utils::packageVersion(pkg)),
    character(1)
  )
  runtime_ok <- all(
    runtime_versions == runtime$version[package_rows]
  )
  checks <- data.frame(
    check = c(
      "stable_predecessor_hashes_current",
      "registered_live_drift_unchanged",
      "private_input_hashes_current",
      "code_authorization_hashes_current",
      "runtime_package_versions_current",
      "coefficient_gate_false"
    ),
    status = c(
      if (stable_ok) "PASS" else "FAIL",
      if (live_ok) "PASS" else "FAIL",
      if (inputs_ok) "PASS" else "FAIL",
      if (code_ok) "PASS" else "FAIL",
      if (runtime_ok) "PASS" else "FAIL",
      "PASS"
    ),
    stringsAsFactors = FALSE
  )
  if (any(checks$status != "PASS")) {
    stop(
      "v45 frozen-manifest verification failed: ",
      paste(checks$check[checks$status != "PASS"], collapse = ", "),
      call. = FALSE
    )
  }
  checks
}

v45_as_num <- function(x) {
  out <- haven::zap_labels(x)
  if (is.factor(out)) out <- as.character(out)
  suppressWarnings(as.numeric(out))
}

v45_as_chr <- function(x) {
  out <- as.character(haven::zap_labels(x))
  out[is.na(out) | !nzchar(out)] <- NA_character_
  out
}

v45_assert_unique_id <- function(dat, id, source) {
  if (!id %in% names(dat)) stop(source, " lacks ID column ", id, call. = FALSE)
  if (anyNA(dat[[id]]) || anyDuplicated(dat[[id]])) {
    stop(source, " does not have one nonmissing row per ", id, ".", call. = FALSE)
  }
  invisible(TRUE)
}

v45_forbidden_mi_s_fields <- function(field_names) {
  field_names[grepl(
    paste0(
      "(^SPX)|(^pef($|_))|(^E0b?$)|(^fev1($|_))|(^fvc($|_))|",
      "(spirometr)|(^status_)|(quality)|(comment)|(effort)"
    ),
    field_names,
    ignore.case = TRUE,
    perl = TRUE
  )]
}

v45_load_v43_nhanes_functions <- function(root) {
  path <- file.path(
    root, "output", "code_archive", "PEF_mortality_v44_2_code_candidate",
    "R", "v43", "05_nhanes_stage3_primary_mortality.R"
  )
  if (!file.exists(path)) stop("Authoritative v43 NHANES code is missing.", call. = FALSE)
  env <- new.env(parent = globalenv())
  sys.source(path, envir = env)
  required <- c(
    "make_mi_input", "freeze_mi_specification", "run_mi_checked",
    "reconstruct_released_nhanes_bmi", "attach_passive_variables",
    "nelson_aalen_at_time"
  )
  missing <- required[!vapply(required, exists, logical(1), envir = env, inherits = FALSE)]
  if (length(missing)) {
    stop("Authoritative v43 code lacks required pure helpers: ",
         paste(missing, collapse = ", "), call. = FALSE)
  }
  env
}

v45_read_nhanes_ledger <- function(root) {
  path <- file.path(
    root, "derived_sensitive", "v43",
    "nhanes_stage3_analysis_ledger_v43.rds"
  )
  ledger <- readRDS(path)
  required <- c(
    "person_master", "full_mec_design_backbone", "primary_domain_ids",
    "primary_mi_specification", "spline_knots"
  )
  missing <- setdiff(required, names(ledger))
  if (length(missing)) {
    stop("NHANES Stage 3 ledger lacks: ", paste(missing, collapse = ", "), call. = FALSE)
  }
  ledger
}

v45_mi_signature_v43_nhanes <- function(mi_spec) {
  signature <- list(
    cohort = "NHANES",
    method = mi_spec$method,
    predictor_matrix = mi_spec$predictor_matrix,
    visit_sequence = mi_spec$visit_sequence,
    charls_smoking_skip_pattern = NULL,
    nhanes_passive_bmi = mi_spec$nhanes_passive_bmi,
    nhanes_bmi_where_sha256 = digest::digest(
      unname(mi_spec$where[, "bmi"]),
      algo = "sha256",
      serialize = TRUE
    ),
    unordered_multicategory_targets =
      sort(mi_spec$unordered_multicategory_targets),
    seed = mi_spec$seed,
    convergence_iteration_checkpoints =
      as.integer(mi_spec$convergence_iteration_checkpoints),
    initial_m = mi_spec$initial_m,
    maximum_m = mi_spec$maximum_m,
    monte_carlo_error_fraction_max =
      mi_spec$monte_carlo_error_fraction_max,
    convergence_rhat_max = mi_spec$convergence_rhat_max,
    trace_release_missing_n_min =
      mi_spec$trace_release_missing_n_min,
    monitored_iteration_algorithm =
      "mice(maxit=1) then same-chain mice.mids(maxit=1) per iteration",
    convergence_algorithm_version =
      "rank_normalized_split_plus_folded_split_per_level_v4_directed_cycle_scaled_passive_bmi"
  )
  v45_object_sha256(signature)
}

v45_make_mi_b <- function(ledger, v43) {
  master <- ledger$person_master
  domain <- master$primary_domain %in% TRUE
  mi_data <- v43$make_mi_input(master, domain)
  mi_spec <- ledger$primary_mi_specification
  observed_ids <- sort(v45_as_num(as.character(mi_data$SEQN)))
  frozen_ids <- sort(v45_as_num(ledger$primary_domain_ids))
  if (!identical(observed_ids, frozen_ids)) {
    stop("MI-B IDs do not match the frozen v43 primary domain.", call. = FALSE)
  }
  if (!identical(names(mi_spec$method), names(mi_data))) {
    stop("MI-B column order differs from the inherited specification.", call. = FALSE)
  }
  list(
    object_id = "MI-B",
    data = mi_data,
    specification = mi_spec,
    expected_signature =
      "f02674d75f213a424cbcc4f1617a89c6cfbc8258af45c64d779ca3fb5153e685"
  )
}

v45_make_mi_g <- function(ledger, v43, seed = 450201L) {
  master <- ledger$person_master
  domain <- master$primary_domain %in% TRUE & master$spirometry_abc %in% TRUE
  selected <- master[domain, , drop = FALSE]
  mi_data <- v43$make_mi_input(master, domain)
  match_index <- match(
    v45_as_num(as.character(mi_data$SEQN)),
    v45_as_num(selected$SEQN)
  )
  if (anyNA(match_index)) stop("MI-G auxiliary merge failed.", call. = FALSE)
  auxiliaries <- c("RIDRETH1", "fev1_l", "fvc_l", "fev1_fvc")
  missing <- setdiff(auxiliaries, names(selected))
  if (length(missing)) {
    stop("MI-G source lacks auxiliaries: ", paste(missing, collapse = ", "), call. = FALSE)
  }
  for (name in auxiliaries) mi_data[[name]] <- selected[[name]][match_index]
  mi_data$RIDRETH1 <- factor(mi_data$RIDRETH1, levels = c(1, 2, 3, 4, 5))
  mi_spec <- v43$freeze_mi_specification(mi_data, seed = seed)
  mi_spec$nhanes_passive_bmi$primary_observed_bmi_exact_reconstruction_n <-
    as.integer(sum(!is.na(mi_data$bmi)))

  active_nonpassive <- setdiff(
    names(mi_spec$method)[nzchar(mi_spec$method)],
    "bmi"
  )
  mi_spec$predictor_matrix[, c("E0", "E0b", "RIDRETH1")] <- 0
  mi_spec$predictor_matrix[active_nonpassive, "pef_l_min"] <- 1
  diag(mi_spec$predictor_matrix) <- 0
  list(
    object_id = "MI-G",
    data = mi_data,
    specification = mi_spec,
    domain_ids = v45_as_num(as.character(mi_data$SEQN))
  )
}

v45_make_mi_s_data <- function(ledger, v43) {
  master <- ledger$person_master
  domain <- master$safe_target %in% TRUE
  selected <- master[domain, , drop = FALSE]
  mi_data <- v43$make_mi_input(master, domain)
  drop <- intersect(
    c(
      "pef_l_min", "E0", "E0b",
      "mobility_difficulty_code5_positive",
      "adl_iadl_difficulty_code5_positive"
    ),
    names(mi_data)
  )
  mi_data <- mi_data[setdiff(names(mi_data), drop)]
  match_index <- match(
    v45_as_num(as.character(mi_data$SEQN)),
    v45_as_num(selected$SEQN)
  )
  if (anyNA(match_index)) stop("MI-S response merge failed.", call. = FALSE)
  mi_data$R_A <- factor(
    as.integer(selected$pef_A[match_index] %in% TRUE),
    levels = c(0, 1)
  )
  mi_data
}

v45_freeze_mi_s_specification <- function(mi_data, seed = 450301L) {
  method <- mice::make.method(mi_data)
  predictor <- mice::make.predictorMatrix(mi_data)
  where <- is.na(mi_data)
  passive_bmi_method <- paste0(
    "~I(floor(((weight_kg / (height_cm / 100)^2 + 1e-8) * ",
    "ifelse(cycle_label == 'G', 10, 100)) + 0.5) / ",
    "ifelse(cycle_label == 'G', 10, 100))"
  )
  passive_bmi_contract <- list(
    parent_methods = c(height_cm = "pmm", weight_kg = "pmm"),
    bmi_method = passive_bmi_method,
    bmi_formula_fields = c("height_cm", "weight_kg", "cycle_label"),
    bmi_cycle_precision = c(E = 2L, F = 2L, G = 1L),
    bmi_rounding_rule = "positive_decimal_half_up",
    primary_observed_bmi_exact_reconstruction_n =
      as.integer(sum(!is.na(mi_data$bmi))),
    waist_method = "pmm",
    visit_sequence_prefix = c("height_cm", "waist_cm", "weight_kg", "bmi"),
    bmi_parent_predictors_only = c("height_cm", "weight_kg"),
    anthropometric_equations_exclude_bmi =
      c("height_cm", "weight_kg", "waist_cm"),
    anthropometric_update_graph = list(
      height_cm = character(),
      waist_cm = "height_cm",
      weight_kg = c("height_cm", "waist_cm"),
      bmi = c("height_cm", "weight_kg")
    ),
    weight_predictor_target_whitelist = "bmi",
    weight_outcome_covariate = FALSE,
    observed_bmi_preserved = TRUE,
    same_seed_dry_run_replicates = 2L
  )
  never_impute <- c(
    "SEQN", "design_psu", "design_strata", "SDMVPSU", "cycle_label",
    "RIDAGEYR", "RIAGENDR", "wtmec6yr", "death", "PERMTH_EXM",
    "followup_years", "nelson_aalen", "log_survey_weight", "R_A"
  )
  method[never_impute] <- ""
  method[c(
    "height_cm", "weight_kg", "income_poverty_ratio", "waist_cm", "phq9_score"
  )] <- "pmm"
  method[["bmi"]] <- passive_bmi_method
  method[c("race_ethnicity", "smoking_status", "education")] <- "polyreg"
  method[c(
    "self_reported_emphysema_or_bronchitis", "ever_asthma",
    "low_physical_activity", "mobility_difficulty_routed",
    "adl_iadl_difficulty_routed"
  )] <- "logreg"
  method[vapply(mi_data, function(x) !anyNA(x), logical(1))] <- ""

  predictor[, "SEQN"] <- 0
  predictor["SEQN", ] <- 0
  predictor[, c(
    "design_psu", "cycle_label", "wtmec6yr", "PERMTH_EXM",
    "followup_years"
  )] <- 0
  predictor[, "weight_kg"] <- 0
  predictor["height_cm", c("waist_cm", "weight_kg", "bmi")] <- 0
  predictor["waist_cm", c("weight_kg", "bmi")] <- 0
  predictor["waist_cm", "height_cm"] <- 1
  predictor["weight_kg", c("height_cm", "waist_cm")] <- 1
  predictor["weight_kg", "bmi"] <- 0
  predictor["bmi", ] <- 0
  predictor["bmi", c("height_cm", "weight_kg")] <- 1
  active_nonpassive <- setdiff(names(method)[nzchar(method)], "bmi")
  predictor[active_nonpassive, "R_A"] <- 1
  diag(predictor) <- 0
  active_targets <- names(method)[nzchar(method)]
  visit_sequence <- c(
    intersect(passive_bmi_contract$visit_sequence_prefix, active_targets),
    setdiff(active_targets, passive_bmi_contract$visit_sequence_prefix)
  )
  unordered_targets <- names(method)[
    nzchar(method) &
      vapply(mi_data, function(x) {
        is.factor(x) && !is.ordered(x) && nlevels(x) > 2L
      }, logical(1))
  ]
  list(
    method = method,
    predictor_matrix = predictor,
    where = where,
    visit_sequence = visit_sequence,
    nhanes_passive_bmi = passive_bmi_contract,
    unordered_multicategory_targets = unordered_targets,
    maxit = 20L,
    convergence_iteration_checkpoints = c(20L, 40L, 80L),
    maximum_maxit = 80L,
    initial_m = 50L,
    maximum_m = 100L,
    seed = as.integer(seed),
    monte_carlo_error_fraction_max = 0.10,
    convergence_rhat_max = 1.05,
    trace_release_missing_n_min = 20L
  )
}

v45_make_mi_s <- function(ledger, v43, seed = 450301L) {
  mi_data <- v45_make_mi_s_data(ledger, v43)
  forbidden <- v45_forbidden_mi_s_fields(names(mi_data))
  if (length(forbidden)) {
    stop("MI-S contains forbidden measurement fields: ",
         paste(forbidden, collapse = ", "), call. = FALSE)
  }
  list(
    object_id = "MI-S",
    data = mi_data,
    specification = v45_freeze_mi_s_specification(mi_data, seed),
    domain_ids = v45_as_num(as.character(mi_data$SEQN))
  )
}

v45_imputation_payload_hash <- function(imp) {
  payload <- lapply(imp$imp, function(x) {
    if (is.data.frame(x)) {
      out <- lapply(x, function(column) {
        if (is.factor(column)) {
          list(values = as.character(column), levels = levels(column))
        } else {
          unname(column)
        }
      })
      names(out) <- names(x)
      out
    } else {
      unname(x)
    }
  })
  v45_object_sha256(payload)
}

v45_run_deterministic_dry_pair <- function(object, v43, m = 2L, maxit = 2L) {
  run_once <- function() {
    started <- proc.time()[["elapsed"]]
    warnings <- character()
    value <- tryCatch(
      withCallingHandlers(
        v43$run_mi_checked(
          object$data, object$specification,
          m = as.integer(m), maxit = as.integer(maxit)
        ),
        warning = function(w) {
          warnings <<- c(warnings, conditionMessage(w))
          invokeRestart("muffleWarning")
        }
      ),
      error = function(e) e
    )
    list(
      value = value,
      warnings = unique(warnings),
      elapsed = proc.time()[["elapsed"]] - started
    )
  }
  first <- run_once()
  if (inherits(first$value, "error")) stop(conditionMessage(first$value), call. = FALSE)
  second <- run_once()
  if (inherits(second$value, "error")) stop(conditionMessage(second$value), call. = FALSE)
  first_events <- if (is.null(first$value$loggedEvents)) 0L else nrow(first$value$loggedEvents)
  second_events <- if (is.null(second$value$loggedEvents)) 0L else nrow(second$value$loggedEvents)
  first_hash <- v45_imputation_payload_hash(first$value)
  second_hash <- v45_imputation_payload_hash(second$value)
  if (length(first$warnings) || length(second$warnings) ||
      first_events != 0L || second_events != 0L ||
      !identical(first_hash, second_hash)) {
    stop(
      object$object_id,
      " deterministic dry-run contract failed: warnings=",
      length(first$warnings) + length(second$warnings),
      "; logged_events=", first_events + second_events,
      "; identical=", identical(first_hash, second_hash),
      call. = FALSE
    )
  }
  list(
    first = first$value,
    second = second$value,
    payload_sha256 = first_hash,
    elapsed_seconds = first$elapsed + second$elapsed,
    warning_count = 0L,
    logged_event_count = 0L
  )
}

v45_fill_for_matrix_dimension <- function(dat) {
  out <- dat
  for (name in names(out)) {
    x <- out[[name]]
    if (is.factor(x)) {
      if (!nlevels(x)) next
      x[is.na(x)] <- levels(x)[[1]]
    } else if (is.character(x)) {
      observed <- x[!is.na(x) & nzchar(x)]
      x[is.na(x) | !nzchar(x)] <-
        if (length(observed)) observed[[1]] else "missing"
      x <- factor(x)
    } else {
      x <- suppressWarnings(as.numeric(x))
      replacement <- if (any(is.finite(x))) {
        stats::median(x[is.finite(x)])
      } else {
        0
      }
      x[!is.finite(x)] <- replacement
    }
    out[[name]] <- x
  }
  out
}

v45_expanded_predictor_audit <- function(mi_data, mi_spec, object_id) {
  targets <- names(mi_spec$method)[nzchar(mi_spec$method)]
  rows <- lapply(targets, function(target) {
    predictors <- names(which(mi_spec$predictor_matrix[target, ] != 0))
    observed_target <- !is.na(mi_data[[target]])
    if (!length(predictors)) {
      return(data.frame(
        object_id = object_id, target = target,
        observed_target_rows = sum(observed_target),
        predictor_variables = 0L, expanded_columns = 0L,
        matrix_rank = 0L, full_rank = FALSE,
        unused_factor_level_count = 0L,
        normalized_crossprod_rcond = NA_real_,
        status = "FAIL", stringsAsFactors = FALSE
      ))
    }
    design_data <- v45_fill_for_matrix_dimension(
      mi_data[observed_target, predictors, drop = FALSE]
    )
    unused <- unlist(lapply(predictors, function(name) {
      x <- mi_data[[name]][observed_target]
      if (!is.factor(x)) return(character())
      setdiff(levels(x), unique(as.character(x[!is.na(x)])))
    }), use.names = FALSE)
    mm <- stats::model.matrix(~ ., data = design_data)
    qr_mm <- qr(mm)
    norms <- sqrt(colSums(mm^2))
    normalized_rcond <- if (
      all(is.finite(norms) & norms > 0) && qr_mm$rank == ncol(mm)
    ) {
      rcond(crossprod(sweep(mm, 2L, norms, "/")))
    } else {
      0
    }
    pass <- ncol(mm) < sum(observed_target) &&
      qr_mm$rank == ncol(mm) && !length(unused) &&
      is.finite(normalized_rcond) && normalized_rcond > 0
    data.frame(
      object_id = object_id, target = target,
      observed_target_rows = sum(observed_target),
      predictor_variables = length(predictors),
      expanded_columns = ncol(mm), matrix_rank = qr_mm$rank,
      full_rank = qr_mm$rank == ncol(mm),
      unused_factor_level_count = length(unused),
      normalized_crossprod_rcond = normalized_rcond,
      status = if (pass) "PASS" else "FAIL",
      stringsAsFactors = FALSE
    )
  })
  dplyr::bind_rows(rows)
}

v45_passive_bmi_audit <- function(imp, mi_data, v43) {
  missing <- is.na(mi_data$bmi)
  max_difference <- 0
  observed_change_n <- 0L
  invalid_n <- 0L
  for (chain in seq_len(imp$m)) {
    completed <- mice::complete(imp, chain)
    expected <- v43$reconstruct_released_nhanes_bmi(
      completed$weight_kg[missing],
      completed$height_cm[missing],
      completed$cycle_label[missing]
    )
    if (length(expected)) {
      max_difference <- max(
        max_difference,
        abs(completed$bmi[missing] - expected)
      )
    }
    observed_change_n <- observed_change_n +
      sum(completed$bmi[!missing] != mi_data$bmi[!missing])
    invalid_n <- invalid_n + sum(
      !is.finite(completed$height_cm) | completed$height_cm <= 0 |
        !is.finite(completed$weight_kg) | completed$weight_kg <= 0 |
        !is.finite(completed$bmi) | completed$bmi <= 0
    )
  }
  list(
    bmi_missing_n = sum(missing),
    observed_bmi_n = sum(!missing),
    observed_bmi_change_n = observed_change_n,
    maximum_identity_difference = max_difference,
    invalid_completed_parent_n = invalid_n,
    pass = observed_change_n == 0L && invalid_n == 0L &&
      is.finite(max_difference) && max_difference <= 1e-12
  )
}

v45_model_matrix_audit <- function(formula, data, analysis_id, imputation) {
  mm <- stats::model.matrix(formula, data = data)
  qr_mm <- qr(mm)
  singular_values <- svd(mm, nu = 0, nv = 0)$d
  condition_index <- if (length(singular_values) && min(singular_values) > 0) {
    max(singular_values) / min(singular_values)
  } else {
    Inf
  }
  data.frame(
    analysis_id = analysis_id,
    imputation = as.integer(imputation),
    rows = nrow(mm),
    columns = ncol(mm),
    matrix_rank = qr_mm$rank,
    full_rank = qr_mm$rank == ncol(mm),
    condition_index = condition_index,
    status = if (qr_mm$rank == ncol(mm) && all(is.finite(mm))) "PASS" else "FAIL",
    stringsAsFactors = FALSE
  )
}
