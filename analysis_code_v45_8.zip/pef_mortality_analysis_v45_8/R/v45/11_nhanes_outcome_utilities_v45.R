# Pure utilities for the frozen v45 NHANES outcome stage.
#
# Defining these functions has no model-fitting, RNG, file-writing, or
# coefficient-release side effect. The execution and independent release
# scripts call them only after the Stage 4 outcome contract has been frozen.

options(stringsAsFactors = FALSE)

v45_outcome_a0_terms <- function() {
  c(
    "age_ns1", "age_ns2", "age_ns3", "factor(RIAGENDR)",
    "height_ns1", "height_ns2", "height_ns3",
    "factor(race_ethnicity)", "factor(cycle_label)"
  )
}

v45_outcome_a1_terms <- function() {
  c(
    v45_outcome_a0_terms(),
    "factor(smoking_status)",
    "bmi_ns1", "bmi_ns2", "bmi_ns3",
    "factor(education)", "income_poverty_ratio"
  )
}

v45_outcome_a2_terms <- function() {
  c(
    v45_outcome_a1_terms(),
    "self_reported_emphysema_or_bronchitis", "ever_asthma",
    "nhanes_function_health_proxy_count"
  )
}

v45_outcome_formula <- function(exposures = character(), tier = "A1") {
  tier <- match.arg(tier, c("A0", "A1", "A2"))
  covariates <- switch(
    tier,
    A0 = v45_outcome_a0_terms(),
    A1 = v45_outcome_a1_terms(),
    A2 = v45_outcome_a2_terms()
  )
  rhs <- c(exposures, covariates)
  if (!length(rhs)) stop("Outcome formula has an empty RHS.", call. = FALSE)
  stats::as.formula(paste(
    "survival::Surv(followup_years, death) ~",
    paste(rhs, collapse = " + ")
  ))
}

v45_outcome_g_exposures <- function() {
  list(
    v45_g0 = character(),
    v45_g1 = "E0",
    v45_g2 = "L_FEV1",
    v45_g3 = "L_FVC",
    v45_g4 = "L_RATIO",
    v45_g5a = c("L_FEV1", "L_RATIO"),
    v45_g5b = c("L_FVC", "L_RATIO"),
    v45_g6a = c("E0", "L_FEV1", "L_RATIO"),
    v45_g6b = c("E0", "L_FVC", "L_RATIO"),
    v45_g5c = c("L_FEV1", "L_FVC", "L_RATIO"),
    v45_g6c = c("E0", "L_FEV1", "L_FVC", "L_RATIO")
  )
}

v45_outcome_model_registry <- function() {
  anchor <- data.frame(
    analysis_id = c(
      "v45_anchor_nhanes_a0", "v45_anchor_nhanes_a1",
      "v45_anchor_nhanes_a2"
    ),
    module = "anchor",
    mi_object = "MI-B",
    sample_id = "nhanes_pef_A_only",
    model_tier = c("A0", "A1", "A2"),
    exposures = "E0",
    focal_terms = "E0",
    role = "original_primary_anchor",
    stringsAsFactors = FALSE
  )
  g <- v45_outcome_g_exposures()
  gli <- data.frame(
    analysis_id = names(g),
    module = "GLI_same_sample",
    mi_object = "MI-G",
    sample_id = "nhanes_pef_A_x_spirometry_ABC",
    model_tier = "A1",
    exposures = vapply(g, paste, collapse = ";", character(1)),
    focal_terms = vapply(g, paste, collapse = ";", character(1)),
    role = c(
      "covariate_only", "PEF_same_sample", "FEV1_same_sample",
      "FVC_same_sample", "ratio_same_sample",
      "prespecified_spirometry_block", "alternative_spirometry_block",
      "focal_secondary", "prespecified_alternative",
      "collinearity_gated_sensitivity",
      "collinearity_gated_sensitivity"
    ),
    stringsAsFactors = FALSE
  )
  reference <- data.frame(
    analysis_id = c("v45_gli_ref_2022", "v45_gli_ref_2012"),
    module = "GLI_reference_range",
    mi_object = "MI-G",
    sample_id = c(
      "gli2022_all_three_within_reference",
      "gli2012_all_three_within_reference"
    ),
    model_tier = "A1",
    exposures = "E0;L_FEV1;L_RATIO",
    focal_terms = "E0;L_FEV1;L_RATIO",
    role = c("focal_exploratory", "equation_sensitivity"),
    stringsAsFactors = FALSE
  )
  ipw <- data.frame(
    analysis_id = c("v45_ipw_d1", "v45_ipw_a1"),
    module = "observation_IPW",
    mi_object = "MI-S",
    sample_id = c("safe_target", "pef_A_respondents_reweighted"),
    model_tier = c("D1", "A1"),
    exposures = c("R_A", "E0"),
    focal_terms = c("R_A", "E0"),
    role = c("response_model", "selection_sensitivity"),
    stringsAsFactors = FALSE
  )
  out <- dplyr::bind_rows(anchor, gli, reference, ipw)
  out$formula_text <- vapply(seq_len(nrow(out)), function(i) {
    id <- out$analysis_id[[i]]
    if (id == "v45_ipw_d1") {
      paste(deparse(v45_outcome_d1_formula(FALSE)), collapse = " ")
    } else if (id == "v45_ipw_a1") {
      paste(deparse(v45_outcome_formula("E0", "A1")), collapse = " ")
    } else {
      exposure <- strsplit(out$exposures[[i]], ";", fixed = TRUE)[[1L]]
      exposure <- exposure[nzchar(exposure)]
      paste(
        deparse(v45_outcome_formula(exposure, out$model_tier[[i]])),
        collapse = " "
      )
    }
  }, character(1))
  out
}

v45_outcome_d1_formula <- function(outcome_augmented = FALSE) {
  terms <- c(
    "age_centered", "age_centered_squared", "sex", "race_ethnicity",
    "cycle_label", "height_cm", "bmi_category", "smoking_status",
    "education_3", "pir_category", "lung_disease", "ever_asthma",
    "mobility_difficulty_routed", "adl_iadl_difficulty_routed",
    "phq9_category", "low_physical_activity"
  )
  if (isTRUE(outcome_augmented)) {
    terms <- c(terms, "death", "nelson_aalen")
  }
  stats::as.formula(paste("R_A ~", paste(terms, collapse = " + ")))
}

v45_prepare_d1 <- function(completed) {
  out <- completed
  out$R_A <- factor(as.character(out$R_A), levels = c("0", "1"))
  age <- as.numeric(out$RIDAGEYR)
  weight <- as.numeric(out$wtmec6yr)
  if (any(!is.finite(age)) || any(!is.finite(weight) | weight <= 0)) {
    stop("D1 preparation found invalid age or official weight.", call. = FALSE)
  }
  out$age_centered <- age - sum(age * weight) / sum(weight)
  out$age_centered_squared <- out$age_centered^2
  out$sex <- factor(
    as.numeric(as.character(out$RIAGENDR)),
    levels = c(1, 2), labels = c("Male", "Female")
  )
  out$race_ethnicity <- factor(
    as.character(out$race_ethnicity),
    levels = c(
      "Mexican American", "Other Hispanic", "Non-Hispanic White",
      "Non-Hispanic Black", "Other/Multi-Racial"
    )
  )
  out$cycle_label <- factor(
    as.character(out$cycle_label), levels = c("E", "F", "G")
  )
  out$bmi_category <- cut(
    as.numeric(out$bmi),
    breaks = c(-Inf, 18.5, 25, 30, Inf), right = FALSE,
    labels = c("<18.5", "18.5-<25", "25-<30", ">=30")
  )
  out$smoking_status <- factor(
    as.character(out$smoking_status),
    levels = c("never", "former", "current")
  )
  education <- as.character(out$education)
  education_3 <- ifelse(
    education %in% c("<9th grade", "9-11th grade"), "<HS",
    ifelse(
      education == "High school/GED", "HS/GED",
      ifelse(
        education %in% c("Some college/AA", "College graduate+"),
        ">HS", NA_character_
      )
    )
  )
  out$education_3 <- factor(
    education_3, levels = c("<HS", "HS/GED", ">HS")
  )
  out$pir_category <- cut(
    as.numeric(out$income_poverty_ratio),
    breaks = c(-Inf, 1, 2, 4, Inf), right = FALSE,
    labels = c("<1", "1-<2", "2-<4", ">=4")
  )
  out$lung_disease <- factor(
    as.numeric(as.character(
      out$self_reported_emphysema_or_bronchitis
    )),
    levels = c(0, 1)
  )
  out$ever_asthma <- factor(
    as.numeric(as.character(out$ever_asthma)), levels = c(0, 1)
  )
  out$mobility_difficulty_routed <- factor(
    as.numeric(as.character(out$mobility_difficulty_routed)),
    levels = c(0, 1)
  )
  out$adl_iadl_difficulty_routed <- factor(
    as.numeric(as.character(out$adl_iadl_difficulty_routed)),
    levels = c(0, 1)
  )
  out$phq9_category <- cut(
    as.numeric(out$phq9_score),
    breaks = c(-Inf, 5, 10, Inf), right = FALSE,
    labels = c("0-4", "5-9", ">=10")
  )
  out$low_physical_activity <- factor(
    as.numeric(as.character(out$low_physical_activity)),
    levels = c(0, 1)
  )
  required <- unique(all.vars(v45_outcome_d1_formula(TRUE)))
  incomplete <- vapply(out[required], function(x) anyNA(x), logical(1))
  if (any(incomplete)) {
    stop(
      "Prepared D1 data retain missing fields: ",
      paste(names(incomplete)[incomplete], collapse = ", "),
      call. = FALSE
    )
  }
  out
}

v45_attach_a1_passive_no_exposure <- function(completed, knots, v43) {
  out <- completed
  out$RIAGENDR <- factor(
    round(as.numeric(as.character(out$RIAGENDR))), levels = c(1, 2)
  )
  out$cycle_label <- factor(
    as.character(out$cycle_label), levels = c("E", "F", "G")
  )
  out$race_ethnicity <- factor(
    as.character(out$race_ethnicity),
    levels = c(
      "Mexican American", "Other Hispanic", "Non-Hispanic White",
      "Non-Hispanic Black", "Other/Multi-Racial"
    )
  )
  out$smoking_status <- factor(
    as.character(out$smoking_status),
    levels = c("never", "former", "current")
  )
  out$education <- factor(
    as.character(out$education),
    levels = c(
      "<9th grade", "9-11th grade", "High school/GED",
      "Some college/AA", "College graduate+"
    )
  )
  out <- cbind(
    out,
    v43$fixed_ns(
      as.numeric(out$RIDAGEYR),
      v43$get_knot_row(knots, "RIDAGEYR"), "age"
    ),
    v43$fixed_ns(
      as.numeric(out$height_cm),
      v43$get_knot_row(knots, "height_cm"), "height"
    ),
    v43$fixed_ns(
      as.numeric(out$bmi),
      v43$get_knot_row(knots, "bmi"), "bmi"
    )
  )
  required <- unique(c(
    all.vars(v45_outcome_formula("E0", "A1")),
    "SEQN", "wtmec6yr", "cycle_label"
  ))
  required <- setdiff(required, c("E0", "followup_years", "death"))
  incomplete <- vapply(out[required], function(x) anyNA(x), logical(1))
  if (any(incomplete)) {
    stop(
      "A1 passive preparation retains missing fields: ",
      paste(names(incomplete)[incomplete], collapse = ", "),
      call. = FALSE
    )
  }
  out
}

v45_prepare_mib_completed <- function(completed, ledger, v43) {
  v43$attach_passive_variables(completed, ledger$spline_knots)
}

v45_prepare_mig_completed <- function(completed, ledger, v43) {
  base <- v43$attach_passive_variables(completed, ledger$spline_knots)
  gli <- v45_compute_gli(base)
  duplicate <- intersect(names(base), names(gli))
  if (length(duplicate)) {
    stop(
      "Passive GLI fields duplicate completed fields: ",
      paste(duplicate, collapse = ", "),
      call. = FALSE
    )
  }
  cbind(base, gli)
}

v45_prepare_mis_completed <- function(completed, ledger, v43) {
  d1 <- v45_prepare_d1(completed)
  a1 <- v45_attach_a1_passive_no_exposure(d1, ledger$spline_knots, v43)
  master <- ledger$person_master
  exposure <- master[
    master$primary_domain %in% TRUE,
    c("SEQN", "E0", "E0b"),
    drop = FALSE
  ]
  exposure$SEQN <- as.numeric(as.character(exposure$SEQN))
  a1$SEQN <- as.numeric(as.character(a1$SEQN))
  if (anyNA(exposure$SEQN) || anyDuplicated(exposure$SEQN)) {
    stop("Frozen respondent exposure lookup is not one row per ID.",
         call. = FALSE)
  }
  out <- dplyr::left_join(a1, exposure, by = "SEQN")
  respondent <- as.character(out$R_A) == "1"
  if (
    sum(respondent) != 6719L ||
    anyNA(out$E0[respondent]) ||
    anyNA(out$E0b[respondent]) ||
    any(!is.na(out$E0[!respondent])) ||
    any(!is.na(out$E0b[!respondent]))
  ) {
    stop("MI-S respondent-only E0/E0b join violated its frozen contract.",
         call. = FALSE)
  }
  out
}

v45_stage2_text_sha256 <- function(lines) {
  digest::digest(
    enc2utf8(paste(lines, collapse = "\n")),
    algo = "sha256", serialize = FALSE
  )
}

v45_stage2_integer_sha256 <- function(x) {
  v45_stage2_text_sha256(c(
    paste0("integer_length=", length(x)),
    paste(sprintf("%d", as.integer(x)), collapse = "\u241f")
  ))
}

v45_outcome_design_data <- function(ledger, rw_contract = NULL) {
  allowed <- c(
    "SEQN", "design_psu", "design_strata", "SDMVPSU",
    "cycle_label", "wtmec6yr"
  )
  missing <- setdiff(allowed, names(ledger$full_mec_design_backbone))
  if (length(missing)) {
    stop(
      "Full MEC backbone lacks fields: ", paste(missing, collapse = ", "),
      call. = FALSE
    )
  }
  out <- ledger$full_mec_design_backbone[allowed]
  out$SEQN <- as.integer(as.numeric(out$SEQN))
  out <- out[order(out$SEQN, method = "radix"), , drop = FALSE]
  rownames(out) <- NULL
  out$design_psu <- factor(
    as.character(out$design_psu),
    levels = sort(unique(as.character(out$design_psu)), method = "radix")
  )
  out$design_strata <- factor(
    as.character(out$design_strata),
    levels = sort(unique(as.character(out$design_strata)), method = "radix")
  )
  out$cycle_label <- factor(
    as.character(out$cycle_label), levels = c("E", "F", "G")
  )
  if (
    nrow(out) != 29353L ||
    nlevels(out$design_strata) != 45L ||
    nlevels(out$design_psu) != 94L ||
    anyNA(out$SEQN) || anyDuplicated(out$SEQN) ||
    any(!is.finite(out$wtmec6yr) | out$wtmec6yr <= 0)
  ) {
    stop("Full MEC design anchors failed.", call. = FALSE)
  }
  if (!is.null(rw_contract)) {
    observed <- v45_stage2_integer_sha256(out$SEQN)
    if (!identical(observed, rw_contract$design$seqn_order_sha256) ||
        !isTRUE(all.equal(
          as.numeric(out$wtmec6yr),
          as.numeric(rw_contract$full_design_pweights),
          tolerance = 1e-14, check.attributes = FALSE
        ))) {
      stop("Full MEC design order or official weights drifted from Stage 2.",
           call. = FALSE)
    }
  }
  out
}

v45_merge_completed_design <- function(
    design_data, completed, member_ids = NULL) {
  completed$SEQN <- as.integer(as.numeric(as.character(completed$SEQN)))
  if (anyNA(completed$SEQN) || anyDuplicated(completed$SEQN)) {
    stop("Completed data are not one row per SEQN.", call. = FALSE)
  }
  if (is.null(member_ids)) member_ids <- completed$SEQN
  member_ids <- as.integer(as.numeric(member_ids))
  drop_fields <- c(
    "design_psu", "design_strata", "SDMVPSU", "cycle_label", "wtmec6yr"
  )
  model_fields <- setdiff(names(completed), drop_fields)
  merged <- dplyr::left_join(
    design_data, completed[model_fields], by = "SEQN"
  )
  if (nrow(merged) != nrow(design_data) ||
      !identical(merged$SEQN, design_data$SEQN)) {
    stop("Completed-data merge changed full MEC rows or order.",
         call. = FALSE)
  }
  merged$analysis_domain <- merged$SEQN %in% member_ids
  if (sum(merged$analysis_domain) != length(unique(member_ids))) {
    stop("One or more requested domain IDs are absent from the MEC backbone.",
         call. = FALSE)
  }
  merged
}

v45_make_taylor_design <- function(merged) {
  survey::svydesign(
    ids = ~design_psu,
    strata = ~design_strata,
    weights = ~wtmec6yr,
    data = merged,
    nest = TRUE
  )
}

v45_make_rw_design <- function(
    merged, rw_contract, module_id, replicates = 500L) {
  replicates <- as.integer(replicates)
  if (!module_id %in% names(rw_contract$modules) ||
      !replicates %in% c(250L, 500L)) {
    stop("Unknown Rao-Wu module or replicate count.", call. = FALSE)
  }
  if (
    nrow(merged) != 29353L ||
    !identical(
      v45_stage2_integer_sha256(merged$SEQN),
      rw_contract$design$seqn_order_sha256
    )
  ) {
    stop("Rao-Wu design requires the exact ordered full MEC backbone.",
         call. = FALSE)
  }
  module <- rw_contract$modules[[module_id]]
  matrix <- module$matrix[, seq_len(replicates), drop = FALSE]
  index <- as.integer(rw_contract$full_design_cluster_index)
  if (
    !identical(dim(matrix), c(94L, replicates)) ||
    length(index) != nrow(merged) ||
    any(index < 1L | index > 94L)
  ) {
    stop("Rao-Wu compressed multiplier contract is invalid.",
         call. = FALSE)
  }
  repweights <- list(weights = matrix, index = index)
  class(repweights) <- "repweights_compressed"
  design <- list(
    repweights = repweights,
    pweights = as.numeric(rw_contract$full_design_pweights),
    type = "subbootstrap",
    rho = 0,
    scale = if (replicates == 500L) 1 / 499 else 1 / 249,
    rscales = rep(1, replicates),
    call = match.call(),
    combined.weights = FALSE,
    selfrep = NULL,
    mse = TRUE,
    variables = merged,
    degf = 49L
  )
  class(design) <- "svyrep.design"
  design
}

v45_capture_model <- function(expr) {
  warnings <- character()
  value <- withCallingHandlers(
    tryCatch(
      expr,
      error = function(e) structure(
        list(error = conditionMessage(e)), class = "v45_model_error"
      )
    ),
    warning = function(w) {
      warnings <<- c(warnings, conditionMessage(w))
      invokeRestart("muffleWarning")
    }
  )
  list(value = value, warnings = unique(warnings))
}

v45_validate_cox_compact <- function(fit, warnings, model_id) {
  beta <- stats::coef(fit)
  variance <- stats::vcov(fit)
  warning_values <- unique(trimws(as.character(warnings)))
  warning_values <- warning_values[nzchar(warning_values)]
  hard_warning <- any(grepl(
    "did not converge|failed to converge|infinite coefficient|singular",
    warning_values, ignore.case = TRUE
  ))
  fail <- if (is.null(fit$fail)) "" else paste(fit$fail, collapse = "; ")
  valid <- length(beta) > 0L &&
    all(is.finite(beta)) &&
    is.matrix(variance) &&
    identical(dim(variance), c(length(beta), length(beta))) &&
    all(is.finite(variance)) &&
    all(diag(variance) > 0) &&
    qr(variance)$rank == length(beta) &&
    !hard_warning &&
    !nzchar(trimws(fail))
  if (!valid) {
    stop(
      model_id, " failed convergence/finite-covariance validation.",
      call. = FALSE
    )
  }
  list(
    coefficients = beta,
    variance = variance,
    warnings = paste(warning_values, collapse = "; ")
  )
}

v45_fit_taylor_cox <- function(
    completed, design_data, formula, model_id, member_ids = NULL) {
  if (is.null(member_ids)) {
    member_ids <- as.integer(as.numeric(as.character(completed$SEQN)))
  }
  merged <- v45_merge_completed_design(
    design_data, completed, member_ids = member_ids
  )
  domain <- merged[merged$analysis_domain, , drop = FALSE]
  matrix <- stats::model.matrix(
    stats::delete.response(stats::terms(formula)), data = domain
  )
  if (qr(matrix)$rank != ncol(matrix)) {
    stop(model_id, " has a rank-deficient design matrix.", call. = FALSE)
  }
  full_design <- v45_make_taylor_design(merged)
  v45_fit_taylor_cox_prebuilt(
    merged = merged,
    full_design = full_design,
    domain_index = merged$analysis_domain,
    formula = formula,
    model_id = model_id
  )
}

v45_fit_taylor_cox_prebuilt <- function(
    merged, full_design, domain_index, formula, model_id) {
  domain_index <- as.logical(domain_index)
  if (
    length(domain_index) != nrow(merged) ||
    anyNA(domain_index) ||
    sum(domain_index) < 100L
  ) {
    stop(model_id, " received an invalid survey domain.", call. = FALSE)
  }
  domain <- merged[domain_index, , drop = FALSE]
  matrix <- stats::model.matrix(
    stats::delete.response(stats::terms(formula)), data = domain
  )
  if (qr(matrix)$rank != ncol(matrix)) {
    stop(model_id, " has a rank-deficient design matrix.", call. = FALSE)
  }
  domain_design <- full_design[domain_index, ]
  captured <- v45_capture_model(
    survey::svycoxph(formula, design = domain_design)
  )
  if (inherits(captured$value, "v45_model_error")) {
    stop(model_id, " failed: ", captured$value$error, call. = FALSE)
  }
  checked <- v45_validate_cox_compact(
    captured$value, captured$warnings, model_id
  )
  list(
    coefficients = checked$coefficients,
    variance = checked$variance,
    diagnostics = data.frame(
      model_id = model_id,
      n = nrow(domain),
      events = sum(as.integer(domain$death) == 1L),
      person_years = sum(as.numeric(domain$followup_years)),
      design_strata = length(unique(domain$design_strata)),
      design_psu = length(unique(domain$design_psu)),
      design_df = survey::degf(domain_design),
      matrix_columns = ncol(matrix),
      matrix_rank = qr(matrix)$rank,
      warnings = checked$warnings,
      stringsAsFactors = FALSE
    )
  )
}

v45_pool_scalar_qu <- function(
    estimates, within_variances, complete_data_df = 49) {
  estimates <- as.numeric(estimates)
  within_variances <- as.numeric(within_variances)
  if (
    length(estimates) < 2L ||
    length(estimates) != length(within_variances) ||
    any(!is.finite(estimates)) ||
    any(!is.finite(within_variances) | within_variances <= 0)
  ) {
    stop("Rubin pooling received invalid estimates or variances.",
         call. = FALSE)
  }
  pooled <- mice::pool.scalar(
    estimates, within_variances,
    n = as.numeric(complete_data_df) + 1,
    k = 1, rule = "rubin1987"
  )
  critical <- if (is.finite(pooled$df)) {
    stats::qt(0.975, df = pooled$df)
  } else {
    stats::qnorm(0.975)
  }
  se <- sqrt(pooled$t)
  statistic <- pooled$qbar / se
  p_value <- if (is.finite(pooled$df)) {
    2 * stats::pt(abs(statistic), df = pooled$df, lower.tail = FALSE)
  } else {
    2 * stats::pnorm(abs(statistic), lower.tail = FALSE)
  }
  data.frame(
    m = pooled$m,
    estimate = pooled$qbar,
    standard_error = se,
    ci_low = pooled$qbar - critical * se,
    ci_high = pooled$qbar + critical * se,
    p_value = p_value,
    within_variance = pooled$ubar,
    between_variance = pooled$b,
    total_variance = pooled$t,
    df = pooled$df,
    complete_data_design_df = complete_data_df,
    fraction_missing_information = pooled$fmi,
    relative_efficiency = 1 / (1 + pooled$fmi / pooled$m),
    monte_carlo_error = sqrt(pooled$b / pooled$m),
    monte_carlo_error_fraction = sqrt(pooled$b / pooled$m) / se,
    stringsAsFactors = FALSE
  )
}

v45_weighted_cox_coefficients <- function(
    data, weights, formula, terms, model_id) {
  weights <- as.numeric(weights)
  required <- unique(c(all.vars(formula), terms))
  usable <- is.finite(weights) & weights > 0 &
    stats::complete.cases(data[required])
  if (sum(usable) < 100L ||
      sum(as.integer(data$death[usable]) == 1L) < 20L) {
    stop(model_id, " has insufficient positive-weight support.",
         call. = FALSE)
  }
  local <- data[usable, , drop = FALSE]
  local_weight <- weights[usable]
  local_weight <- local_weight / mean(local_weight)
  local$.v45_analysis_weight <- local_weight
  matrix <- stats::model.matrix(
    stats::delete.response(stats::terms(formula)), data = local
  )
  if (qr(matrix)$rank != ncol(matrix)) {
    stop(model_id, " has a rank-deficient positive-weight matrix.",
         call. = FALSE)
  }
  captured <- v45_capture_model(
    survival::coxph(
      formula, data = local, weights = .v45_analysis_weight,
      ties = "efron", robust = FALSE, singular.ok = FALSE,
      model = FALSE, x = FALSE, y = FALSE
    )
  )
  if (inherits(captured$value, "v45_model_error")) {
    stop(model_id, " failed: ", captured$value$error, call. = FALSE)
  }
  checked <- v45_validate_cox_compact(
    captured$value, captured$warnings, model_id
  )
  missing <- setdiff(terms, names(checked$coefficients))
  if (length(missing)) {
    stop(
      model_id, " lacks requested coefficients: ",
      paste(missing, collapse = ", "), call. = FALSE
    )
  }
  checked$coefficients[terms]
}

v45_replicate_variance <- function(
    replicate_estimates, point_estimate, replicates) {
  replicates <- as.integer(replicates)
  values <- as.numeric(replicate_estimates)
  valid <- is.finite(values)
  valid_fraction <- mean(valid)
  if (sum(valid) < 2L) {
    return(list(
      variance = NA_real_, valid_fraction = valid_fraction,
      valid_n = sum(valid)
    ))
  }
  variance <- survey::svrVar(
    values,
    scale = if (replicates == 500L) 1 / 499 else 1 / 249,
    rscales = rep(1, replicates),
    na.action = "na.omit",
    mse = TRUE,
    coef = as.numeric(point_estimate)
  )
  list(
    variance = as.numeric(variance),
    valid_fraction = valid_fraction,
    valid_n = sum(valid)
  )
}

v45_kish_ess <- function(weights) {
  weights <- as.numeric(weights)
  weights <- weights[is.finite(weights) & weights > 0]
  if (!length(weights)) return(NA_real_)
  sum(weights)^2 / sum(weights^2)
}

v45_weighted_mean <- function(x, weights) {
  sum(as.numeric(x) * weights) / sum(weights)
}

v45_weighted_variance <- function(x, weights) {
  center <- v45_weighted_mean(x, weights)
  sum(weights * (as.numeric(x) - center)^2) / sum(weights)
}

v45_ipw_factors <- function(probability, respondent, base_weight) {
  availability <- 1 / probability[respondent]
  caps <- c(
    uncapped = Inf,
    cap_p99 = as.numeric(stats::quantile(
      availability, 0.99, names = FALSE, type = 7
    )),
    cap_p975 = as.numeric(stats::quantile(
      availability, 0.975, names = FALSE, type = 7
    ))
  )
  target_total <- sum(base_weight)
  respondent_weight <- base_weight[respondent]
  factors <- lapply(caps, function(cap) {
    raw <- pmin(availability, cap)
    raw * target_total / sum(respondent_weight * raw)
  })
  list(availability = availability, caps = caps, factors = factors)
}

v45_ipw_theta <- function(
    target_data, base_weight, outcome_augmented = FALSE,
    variants = c("original", "uncapped", "cap_p99", "cap_p975"),
    model_id = "v45_ipw") {
  allowed_variants <- c("original", "uncapped", "cap_p99", "cap_p975")
  if (!length(variants) || any(!variants %in% allowed_variants) ||
      anyDuplicated(variants)) {
    stop(model_id, " requested an invalid IPW variant set.", call. = FALSE)
  }
  base_weight <- as.numeric(base_weight)
  positive <- is.finite(base_weight) & base_weight > 0
  if (sum(positive) < 1000L) {
    stop(model_id, " has insufficient positive target weight support.",
         call. = FALSE)
  }
  response_formula <- v45_outcome_d1_formula(outcome_augmented)
  response_weight <- base_weight[positive]
  response_weight <- response_weight / mean(response_weight)
  response_data <- target_data[positive, , drop = FALSE]
  response_data$.v45_response_weight <- response_weight
  response_capture <- v45_capture_model(
    stats::glm(
      response_formula, data = response_data,
      weights = .v45_response_weight, family = quasibinomial()
    )
  )
  if (inherits(response_capture$value, "v45_model_error")) {
    stop(
      model_id, " response model failed: ",
      response_capture$value$error, call. = FALSE
    )
  }
  response_beta <- stats::coef(response_capture$value)
  if (any(!is.finite(response_beta))) {
    stop(model_id, " response model has non-finite coefficients.",
         call. = FALSE)
  }
  probability <- as.numeric(stats::predict(
    response_capture$value, newdata = target_data, type = "response"
  ))
  if (any(!is.finite(probability) |
          probability <= 0 | probability >= 1)) {
    stop(model_id, " predicted response probability is outside (0,1).",
         call. = FALSE)
  }
  registered_respondent <- as.character(target_data$R_A) == "1"
  if (sum(registered_respondent) != 6719L) {
    stop(model_id, " respondent anchor drifted.", call. = FALSE)
  }
  respondent <- registered_respondent & positive
  factor_contract <- v45_ipw_factors(
    probability, respondent, base_weight
  )
  outcome_formula <- v45_outcome_formula("E0", "A1")
  theta <- setNames(numeric(length(variants)), variants)
  if ("original" %in% variants) {
    theta[["original"]] <- unname(v45_weighted_cox_coefficients(
      target_data[respondent, , drop = FALSE],
      base_weight[respondent], outcome_formula, "E0",
      paste0(model_id, "_original")
    )[[1L]])
  }
  weighted_variants <- setdiff(variants, "original")
  for (variant in weighted_variants) {
    theta[[variant]] <- v45_weighted_cox_coefficients(
      target_data[respondent, , drop = FALSE],
      base_weight[respondent] *
        factor_contract$factors[[variant]],
      outcome_formula, "E0",
      paste0(model_id, "_", variant)
    )[[1L]]
  }
  attr(theta, "response_warnings") <- paste(
    response_capture$warnings, collapse = "; "
  )
  theta
}

v45_ipw_balance_diagnostics <- function(
    target_data, base_weight, outcome_augmented = FALSE) {
  response_formula <- v45_outcome_d1_formula(outcome_augmented)
  response_data <- target_data
  response_data$.v45_response_weight <-
    base_weight / mean(base_weight)
  fit <- stats::glm(
    response_formula, data = response_data,
    weights = .v45_response_weight,
    family = quasibinomial()
  )
  probability <- as.numeric(stats::predict(
    fit, newdata = target_data, type = "response"
  ))
  respondent <- as.character(target_data$R_A) == "1"
  factor_contract <- v45_ipw_factors(
    probability, respondent, base_weight
  )
  matrix <- stats::model.matrix(
    stats::delete.response(stats::terms(v45_outcome_d1_formula(FALSE))),
    data = target_data
  )
  matrix <- matrix[, colnames(matrix) != "(Intercept)", drop = FALSE]
  target_mean <- apply(
    matrix, 2L, v45_weighted_mean, weights = base_weight
  )
  target_sd <- sqrt(apply(
    matrix, 2L, v45_weighted_variance, weights = base_weight
  ))
  target_sd[!is.finite(target_sd) | target_sd <= 0] <- NA_real_
  respondent_base <- base_weight[respondent]
  variants <- c(
    list(original = rep(1, sum(respondent))),
    factor_contract$factors
  )
  rows <- lapply(names(variants), function(variant) {
    weight <- respondent_base * variants[[variant]]
    mean_respondent <- apply(
      matrix[respondent, , drop = FALSE],
      2L, v45_weighted_mean, weights = weight
    )
    smd <- (mean_respondent - target_mean) / target_sd
    data.frame(
      variant = variant,
      kish_ess = v45_kish_ess(weight),
      ess_ratio = v45_kish_ess(weight) /
        v45_kish_ess(respondent_base),
      maximum_absolute_smd = max(abs(smd), na.rm = TRUE),
      stringsAsFactors = FALSE
    )
  })
  list(
    probability = probability,
    availability = factor_contract$availability,
    caps = factor_contract$caps,
    variants = dplyr::bind_rows(rows),
    response_matrix_columns = ncol(matrix),
    response_matrix_rank = qr(cbind(1, matrix))$rank
  )
}

v45_gate_state_three_level <- function(
    value, go_test, stop_test) {
  if (isTRUE(stop_test(value))) return("STOP")
  if (isTRUE(go_test(value))) return("GO")
  "CAUTION"
}

v45_outcome_static_self_test <- function() {
  registry <- v45_outcome_model_registry()
  expected_ids <- c(
    "v45_anchor_nhanes_a0", "v45_anchor_nhanes_a1",
    "v45_anchor_nhanes_a2",
    names(v45_outcome_g_exposures()),
    "v45_gli_ref_2022", "v45_gli_ref_2012",
    "v45_ipw_d1", "v45_ipw_a1"
  )
  primary_d1 <- v45_outcome_d1_formula(FALSE)
  augmented_d1 <- v45_outcome_d1_formula(TRUE)
  checks <- c(
    registry_ids = identical(registry$analysis_id, expected_ids),
    registry_unique = !anyDuplicated(registry$analysis_id),
    registry_no_empty_formula = all(nzchar(registry$formula_text)),
    anchor_count = sum(registry$module == "anchor") == 3L,
    g_count = sum(registry$module == "GLI_same_sample") == 11L,
    reference_count =
      sum(registry$module == "GLI_reference_range") == 2L,
    ipw_count = sum(registry$module == "observation_IPW") == 2L,
    primary_d1_no_outcome =
      !any(c("death", "nelson_aalen") %in% all.vars(primary_d1)),
    augmented_d1_exact_outcomes =
      setequal(
        intersect(
          all.vars(augmented_d1), c("death", "nelson_aalen")
        ),
        c("death", "nelson_aalen")
      ),
    g6a_exact =
      identical(
        v45_outcome_g_exposures()$v45_g6a,
        c("E0", "L_FEV1", "L_RATIO")
      )
  )
  data.frame(
    check = names(checks),
    status = ifelse(checks, "PASS", "FAIL"),
    stringsAsFactors = FALSE
  )
}
