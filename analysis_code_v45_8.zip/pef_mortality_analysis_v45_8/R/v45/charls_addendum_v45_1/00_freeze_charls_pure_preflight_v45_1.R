# Freeze the additive CHARLS v45.1 pure-function/no-outcome structural gate.

options(stringsAsFactors = FALSE)

script_path <- sub(
  "^--file=", "",
  grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)[[1L]]
)
root <- normalizePath(
  file.path(dirname(script_path), "..", "..", ".."),
  mustWork = TRUE
)
source(file.path(
  root, "R", "v45", "charls_addendum_v45_1",
  "charls_structural_utilities_v45_1.R"
))
v45_charls_activate_project_library(root)
if (!all(vapply(
  c("digest", "yaml", "survey"),
  requireNamespace, quietly = TRUE, FUN.VALUE = logical(1)
))) {
  stop("The frozen digest, yaml, and survey packages are required.", call. = FALSE)
}
source(file.path(
  root, "R", "v45", "charls_addendum_v45_1",
  "charls_pure_functions_v45_1.R"
))

work_dir <- file.path(root, "work_v45", "charls_addendum_v45_1")
result_dir <- file.path(root, "results", "v45", "charls_addendum_v45_1")
spec_path <- file.path(work_dir, "charls_pure_preflight_spec_v45_1.yml")
spec <- yaml::read_yaml(spec_path)

output_paths <- c(
  code_manifest = file.path(
    work_dir, "charls_pure_preflight_code_manifest_v45_1.tsv"
  ),
  function_manifest = file.path(
    work_dir, "charls_pure_function_manifest_v45_1.tsv"
  ),
  freeze_roots = file.path(
    work_dir, "charls_pure_preflight_freeze_roots_v45_1.tsv"
  ),
  validation = file.path(
    result_dir, "charls_pure_preflight_freeze_validation_v45_1.tsv"
  ),
  addendum_gate = file.path(
    work_dir, "charls_addendum_gate_state_v45_1.yml"
  )
)

assert_exact_runtime <- function() {
  if (!identical(as.character(getRversion()), spec$runtime$R_version)) {
    stop("R version differs from the CHARLS preflight contract.", call. = FALSE)
  }
  if (!identical(
    as.character(utils::packageVersion("survey")),
    spec$runtime$survey_version
  )) {
    stop("survey version differs from the CHARLS preflight contract.", call. = FALSE)
  }
}

authority_paths <- vapply(
  spec$authority[c(
    "flow_measurement", "mortality_library",
    "anthropometric_v44_1_1"
  )],
  function(x) file.path(root, x$path),
  character(1)
)
authority_expected <- vapply(
  spec$authority[c(
    "flow_measurement", "mortality_library",
    "anthropometric_v44_1_1"
  )],
  `[[`, character(1), "sha256"
)

build_function_manifest <- function() {
  rows <- lapply(seq_len(nrow(v45_charls_pure_provenance)), function(i) {
    p <- v45_charls_pure_provenance[i, , drop = FALSE]
    authority_path <- authority_paths[[p$authority_id]]
    authority_fun <- v45_charls_extract_top_function(
      authority_path, p$function_name
    )
    migrated_fun <- v45_charls_pure_library$authority_migrated[[
      p$function_name
    ]]
    authority_hash <- v45_charls_function_sha256(authority_fun)
    migrated_hash <- v45_charls_function_sha256(migrated_fun)
    data.frame(
      function_name = p$function_name,
      function_role = "authority_migrated",
      authority_id = p$authority_id,
      authority_path_alias = sub(
        paste0("^", root, "/"), "", authority_path
      ),
      authority_file_sha256 = v45_charls_sha256_file(authority_path),
      authority_start_line = p$authority_start_line,
      authority_function_sha256 = authority_hash,
      migrated_function_sha256 = migrated_hash,
      exact_formals = identical(
        formals(authority_fun), formals(migrated_fun)
      ),
      exact_body = identical(body(authority_fun), body(migrated_fun)),
      status = if (
        identical(formals(authority_fun), formals(migrated_fun)) &&
          identical(body(authority_fun), body(migrated_fun)) &&
          identical(authority_hash, migrated_hash)
      ) "PASS" else "FAIL",
      stringsAsFactors = FALSE
    )
  })
  migrated <- do.call(rbind, rows)
  helpers <- do.call(rbind, lapply(
    names(v45_charls_pure_library$structural_helpers),
    function(name) {
      data.frame(
        function_name = name,
        function_role = "new_structural_helper",
        authority_id = "v45_1_structural_contract",
        authority_path_alias =
          "R/v45/charls_addendum_v45_1/charls_pure_functions_v45_1.R",
        authority_file_sha256 = v45_charls_sha256_file(file.path(
          root, "R", "v45", "charls_addendum_v45_1",
          "charls_pure_functions_v45_1.R"
        )),
        authority_start_line = NA_integer_,
        authority_function_sha256 = NA_character_,
        migrated_function_sha256 = v45_charls_function_sha256(
          v45_charls_pure_library$structural_helpers[[name]]
        ),
        exact_formals = NA,
        exact_body = NA,
        status = "PASS",
        stringsAsFactors = FALSE
      )
    }
  ))
  rbind(migrated, helpers)
}

build_code_manifest <- function() {
  paths <- c(
    "work_v45/charls_addendum_v45_1/charls_addendum_spec_v45_1.yml",
    "work_v45/charls_addendum_v45_1/analysis_registry_addendum_v45_1.tsv",
    "work_v45/charls_addendum_v45_1/estimand_registry_addendum_v45_1.tsv",
    "work_v45/charls_addendum_v45_1/seed_addendum_v45_1.tsv",
    "work_v45/charls_addendum_v45_1/input_addendum_manifest_v45_1.tsv",
    "results/v45/charls_addendum_v45_1/charls_addendum_validation_v45_1.tsv",
    "work_v45/charls_addendum_v45_1/charls_pure_preflight_spec_v45_1.yml",
    "work_v45/charls_addendum_v45_1/charls_pure_preflight_decision_log_v45_1.md",
    "work_v45/charls_addendum_v45_1/charls_pure_preflight_amendment_log_v45_1.md",
    "R/v45/charls_addendum_v45_1/charls_pure_functions_v45_1.R",
    "R/v45/charls_addendum_v45_1/charls_structural_utilities_v45_1.R",
    "R/v45/charls_addendum_v45_1/00_freeze_charls_pure_preflight_v45_1.R",
    "R/v45/charls_addendum_v45_1/01_run_charls_structural_preflight_v45_1.R",
    "R/v45/charls_addendum_v45_1/02_validate_charls_structural_preflight_v45_1.R"
  )
  do.call(rbind, lapply(paths, function(path) {
    full <- file.path(root, path)
    data.frame(
      asset_id = paste0("CHARLS_V45_1::", path),
      path_alias = path,
      exists = file.exists(full) && !dir.exists(full),
      bytes = if (file.exists(full)) as.numeric(file.info(full)$size) else NA_real_,
      sha256 = v45_charls_sha256_file(full),
      immutable = TRUE,
      authorized_purpose =
        "pure-function and synthetic no-outcome structural preflight",
      stringsAsFactors = FALSE
    )
  }))
}

build_objects <- function() {
  assert_exact_runtime()
  if (any(!file.exists(authority_paths)) ||
      !identical(
        unname(vapply(authority_paths, v45_charls_sha256_file, character(1))),
        unname(authority_expected)
      )) {
    stop("One or more CHARLS authority scripts drifted.", call. = FALSE)
  }
  scaffold_validation_path <- file.path(
    result_dir, "charls_addendum_validation_v45_1.tsv"
  )
  if (!file.exists(scaffold_validation_path)) {
    stop("The additive scaffold validation is absent.", call. = FALSE)
  }
  scaffold_validation <- utils::read.delim(
    scaffold_validation_path,
    stringsAsFactors = FALSE, check.names = FALSE
  )
  if (!nrow(scaffold_validation) ||
      any(scaffold_validation$status != "PASS") ||
      !identical(
        tail(scaffold_validation$check_id, 1L),
        "overall_scaffold_validation"
      )) {
    stop("The additive scaffold did not validate cleanly.", call. = FALSE)
  }
  input_manifest <- utils::read.delim(
    file.path(work_dir, "input_addendum_manifest_v45_1.tsv"),
    stringsAsFactors = FALSE, check.names = FALSE
  )
  if (!nrow(input_manifest) ||
      any(input_manifest$validation_status != "PASS") ||
      any(!input_manifest$exists) ||
      any(input_manifest$expected_sha256 !=
            input_manifest$observed_sha256)) {
    stop("The additive input manifest is not current.", call. = FALSE)
  }
  code <- build_code_manifest()
  functions <- build_function_manifest()
  if (any(!code$exists) ||
      any(!grepl("^[0-9a-f]{64}$", code$sha256)) ||
      any(functions$status != "PASS")) {
    stop("The CHARLS pure-preflight code/function closure is incomplete.",
         call. = FALSE)
  }
  parent_roots <- c(
    stage0_input_root =
      "f4fa0eb3ed43c4998d5a949b0a1bead89d9de2b3b6a600448fac2e9c97e168f1",
    stage0_code_root =
      "392ff735f2052067c587bac46d468a140d5c2b63e733972f25d40e336e5c09ac",
    stage0_seed_ledger =
      "ae9b6360333174d384c55791623646363b072d421b9f81a9a7dc690b2dd20af5",
    stage2_survey_function_root =
      "095eef4715f14d19602c0d64535c41e4d1b0380d369ff694ab8964f69c62ef36"
  )
  roots <- data.frame(
    root_id = c(
      "charls_v45_1_code_root",
      "charls_v45_1_function_root",
      names(parent_roots)
    ),
    sha256 = c(
      v45_charls_manifest_root(
        code, "asset_id",
        c("asset_id", "path_alias", "bytes", "sha256", "immutable")
      ),
      v45_charls_manifest_root(
        functions, "function_name",
        c(
          "function_name", "function_role", "authority_id",
          "authority_file_sha256", "migrated_function_sha256", "status"
        )
      ),
      unname(parent_roots)
    ),
    stringsAsFactors = FALSE
  )
  list(code = code, functions = functions, roots = roots)
}

same_table <- function(a, b, key, fields) {
  a <- a[order(a[[key]], method = "radix"), fields, drop = FALSE]
  b <- b[order(b[[key]], method = "radix"), fields, drop = FALSE]
  normalize <- function(x) {
    lapply(x, function(z) {
      z <- as.character(z)
      z[is.na(z) | !nzchar(z)] <- NA_character_
      z
    })
  }
  identical(normalize(a), normalize(b))
}

objects <- build_objects()
mode <- if ("--verify" %in% commandArgs(trailingOnly = TRUE)) {
  "verify"
} else {
  "freeze"
}

if (identical(mode, "verify")) {
  required <- output_paths[c(
    "code_manifest", "function_manifest", "freeze_roots", "validation"
  )]
  if (any(!file.exists(required))) {
    stop("CHARLS pure-preflight freeze outputs are absent.", call. = FALSE)
  }
  recorded_code <- utils::read.delim(
    output_paths[["code_manifest"]],
    stringsAsFactors = FALSE, check.names = FALSE
  )
  recorded_functions <- utils::read.delim(
    output_paths[["function_manifest"]],
    stringsAsFactors = FALSE, check.names = FALSE
  )
  recorded_roots <- utils::read.delim(
    output_paths[["freeze_roots"]],
    stringsAsFactors = FALSE, check.names = FALSE
  )
  validation <- utils::read.delim(
    output_paths[["validation"]],
    stringsAsFactors = FALSE, check.names = FALSE
  )
  ok <- c(
    code = same_table(
      recorded_code, objects$code, "asset_id",
      c(
        "asset_id", "path_alias", "exists", "bytes", "sha256",
        "immutable", "authorized_purpose"
      )
    ),
    functions = same_table(
      recorded_functions, objects$functions, "function_name",
      names(objects$functions)
    ),
    roots = same_table(
      recorded_roots, objects$roots, "root_id",
      c("root_id", "sha256")
    ),
    validation = nrow(validation) == 6L &&
      all(validation$status == "PASS")
  )
  if (!all(ok)) {
    stop(
      "The CHARLS pure-preflight freeze drifted: ",
      paste(names(ok)[!ok], collapse = ", "), call. = FALSE
    )
  }
  message("CHARLS v45.1 pure/no-outcome freeze verifies exactly.")
} else {
  if (any(file.exists(output_paths))) {
    stop(
      "One or more CHARLS pure-preflight freeze outputs already exist; ",
      "use --verify.", call. = FALSE
    )
  }
  freeze_id <- paste0(
    "charls_v45_1_pure_", format(Sys.time(), "%Y%m%dT%H%M%S"),
    "_pid", Sys.getpid()
  )
  frozen_at <- format(Sys.time(), "%Y-%m-%dT%H:%M:%SZ", tz = "UTC")
  validation <- data.frame(
    check = c(
      "additive_scaffold_current",
      "authority_files_exact",
      "authority_functions_mechanically_identical",
      "exact_runtime_available",
      "no_row_level_or_outcome_execution_authorized",
      "main_gate_and_registries_not_modified"
    ),
    status = rep("PASS", 6L),
    detail = c(
      "all prior additive scaffold checks and input hashes PASS",
      "three content-addressed authority scripts match",
      paste0(
        sum(objects$functions$function_role == "authority_migrated"),
        " migrated functions match formals and body"
      ),
      paste0(
        "R=", getRversion(), "; survey=",
        utils::packageVersion("survey")
      ),
      "synthetic PSU-only structural tests are the sole authorized execution",
      "this stage writes only its isolated addendum gate"
    ),
    freeze_id = freeze_id,
    frozen_at_utc = frozen_at,
    stringsAsFactors = FALSE
  )
  for (name in names(objects)) {
    objects[[name]]$freeze_id <- freeze_id
    objects[[name]]$frozen_at_utc <- frozen_at
  }
  v45_charls_atomic_write_tsv(
    objects$code, output_paths[["code_manifest"]]
  )
  v45_charls_atomic_write_tsv(
    objects$functions, output_paths[["function_manifest"]]
  )
  v45_charls_atomic_write_tsv(
    objects$roots, output_paths[["freeze_roots"]]
  )
  v45_charls_atomic_write_tsv(
    validation, output_paths[["validation"]]
  )
  gate <- list(
    gate_id = "charls_addendum_v45_1",
    updated_at_utc = frozen_at,
    pure_function_freeze = list(status = "PASS"),
    structural_preflight = list(status = "NOT_RUN"),
    independent_validation = list(status = "NOT_RUN"),
    actual_design_key_binding = list(status = "NOT_RUN"),
    outcome_execution_allowed = FALSE,
    new_coefficient_inspection_allowed = FALSE,
    next_authorized_step =
      "run_synthetic_CHARLS_no_outcome_structural_preflight"
  )
  v45_charls_atomic_write_yaml(
    gate, output_paths[["addendum_gate"]]
  )
  message("CHARLS v45.1 pure/no-outcome freeze completed.")
}
