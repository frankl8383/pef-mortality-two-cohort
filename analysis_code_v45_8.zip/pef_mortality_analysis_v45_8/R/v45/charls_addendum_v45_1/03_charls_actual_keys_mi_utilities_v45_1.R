# Restricted utilities for the CHARLS v45.1 actual-design/MI-object gate.
# Sourcing this file defines functions only.

v45_charls_actual_paths <- function(root) {
  list(
    ledger = file.path(
      root, "derived_sensitive/v43/charls_stage3_analysis_ledger_v43.rds"
    ),
    donor = file.path(
      root, "derived_sensitive/charls/charls_core_harmonized_provisional.rds"
    ),
    spec = file.path(
      root,
      "work_v45/charls_addendum_v45_1/charls_actual_keys_mi_spec_v45_1.yml"
    ),
    v43 = file.path(
      root,
      paste0(
        "output/code_archive/PEF_mortality_v44_2_code_candidate/",
        "R/v43/04_charls_stage3_primary_mortality.R"
      )
    ),
    v44 = file.path(
      root,
      paste0(
        "output/code_archive/PEF_mortality_v44_2_code_candidate/",
        "R/v44/05_charls_anthropometric_qc_resolution_v44_1_1.R"
      )
    ),
    v44_spec = file.path(
      root,
      paste0(
        "output/code_archive/PEF_mortality_v44_2_code_candidate/",
        "work_v44/charls_anthropometric_qc_resolution_spec_v44_1_1.yml"
      )
    )
  )
}

v45_charls_actual_extract_function <- function(path, name, environment) {
  expressions <- parse(path, keep.source = FALSE)
  matches <- list()
  for (expression in expressions) {
    if (!is.call(expression) || length(expression) != 3L ||
        !identical(as.character(expression[[1L]]), "<-") ||
        !is.symbol(expression[[2L]]) ||
        !identical(as.character(expression[[2L]]), name) ||
        !is.call(expression[[3L]]) ||
        !identical(as.character(expression[[3L]][[1L]]), "function")) {
      next
    }
    matches[[length(matches) + 1L]] <- expression[[3L]]
  }
  if (length(matches) != 1L) {
    stop(
      "Expected exactly one authority function named ", name,
      "; observed ", length(matches), ".", call. = FALSE
    )
  }
  assign(name, eval(matches[[1L]], envir = environment), envir = environment)
  invisible(get(name, envir = environment, inherits = FALSE))
}

v45_charls_actual_load_authority <- function(root) {
  paths <- v45_charls_actual_paths(root)
  environment <- new.env(parent = globalenv())
  v43_names <- c(
    "derive_smoking",
    "numeric_code",
    "apply_charls_smoking_parent_rule",
    "mice.impute.charls_smoke_now_skip_logreg_v43",
    "register_charls_smoking_imputer",
    "make_mi_input",
    "freeze_mi_specification",
    "record_category_trace_iteration",
    "completed_binary_mice_variable",
    "record_smoking_coherence_iteration",
    "mice_smoking_coherence_trace",
    "run_mi",
    "run_mi_checked"
  )
  v44_names <- c(
    "v44_constrained_weight_pmm_core",
    "v44_constrained_height_pmm_core",
    "mice.impute.v44_who_constrained_weight_pmm",
    "mice.impute.v44_who_constrained_height_pmm",
    "variant_catalog_v44",
    "clean_wave_v44",
    "make_mi_input_v44",
    "freeze_mi_spec_v44"
  )
  for (name in v43_names) {
    v45_charls_actual_extract_function(paths$v43, name, environment)
  }
  for (name in v44_names) {
    v45_charls_actual_extract_function(paths$v44, name, environment)
  }
  attr(environment, "function_names") <- c(v43_names, v44_names)
  attr(environment, "authority_paths") <- c(v43 = paths$v43, v44 = paths$v44)
  environment
}

v45_charls_actual_register_v44_imputers <- function(authority) {
  names <- c(
    "mice.impute.v44_who_constrained_weight_pmm",
    "mice.impute.v44_who_constrained_height_pmm"
  )
  prior <- lapply(names, function(name) {
    if (exists(name, envir = .GlobalEnv, inherits = FALSE)) {
      list(existed = TRUE, value = get(name, envir = .GlobalEnv, inherits = FALSE))
    } else {
      list(existed = FALSE, value = NULL)
    }
  })
  names(prior) <- names
  for (name in names) {
    assign(name, get(name, envir = authority, inherits = FALSE), envir = .GlobalEnv)
  }
  function() {
    for (name in names) {
      if (isTRUE(prior[[name]]$existed)) {
        assign(name, prior[[name]]$value, envir = .GlobalEnv)
      } else if (exists(name, envir = .GlobalEnv, inherits = FALSE)) {
        rm(list = name, envir = .GlobalEnv)
      }
    }
    invisible(TRUE)
  }
}

v45_charls_actual_validate_source_files <- function(root, spec) {
  paths <- v45_charls_actual_paths(root)
  expected <- list(
    ledger = spec$restricted_sources$stage3_ledger,
    donor = spec$restricted_sources$w1_weight_donor
  )
  observed <- lapply(names(expected), function(name) {
    path <- paths[[name]]
    definition <- expected[[name]]
    data.frame(
      source_id = name,
      exists = file.exists(path) && !dir.exists(path) && !nzchar(Sys.readlink(path)),
      bytes = if (file.exists(path)) as.numeric(file.info(path)$size) else NA_real_,
      expected_bytes = as.numeric(definition$expected_bytes),
      sha256 = if (file.exists(path)) v45_charls_sha256_file(path) else NA_character_,
      expected_sha256 = as.character(definition$expected_sha256),
      stringsAsFactors = FALSE
    )
  })
  observed <- do.call(rbind, observed)
  observed$status <- ifelse(
    observed$exists &
      observed$bytes == observed$expected_bytes &
      observed$sha256 == observed$expected_sha256,
    "PASS", "FAIL"
  )
  if (any(observed$status != "PASS")) {
    stop("One or more restricted CHARLS sources drifted.", call. = FALSE)
  }
  observed
}

v45_charls_actual_read_sources <- function(root, spec) {
  source_validation <- v45_charls_actual_validate_source_files(root, spec)
  paths <- v45_charls_actual_paths(root)
  ledger <- readRDS(paths$ledger)
  donor_source <- readRDS(paths$donor)
  if (!is.list(ledger) ||
      !all(c("person_master", "person_period_skeleton") %in% names(ledger))) {
    stop("The CHARLS Stage3 ledger schema is invalid.", call. = FALSE)
  }
  master <- as.data.frame(ledger$person_master, stringsAsFactors = FALSE)
  period <- as.data.frame(
    ledger$person_period_skeleton, stringsAsFactors = FALSE
  )
  donor_required <- c("participant_id", "weight_kg_w1")
  if (!all(donor_required %in% names(donor_source))) {
    stop("The authorized W1 weight donor lacks its two allowed fields.", call. = FALSE)
  }
  donor <- as.data.frame(
    donor_source[donor_required], stringsAsFactors = FALSE
  )
  rm(donor_source)
  invisible(gc(verbose = FALSE))
  if (anyDuplicated(master$participant_id) ||
      anyDuplicated(donor$participant_id) ||
      anyNA(master$participant_id) ||
      anyNA(master$community_id)) {
    stop("CHARLS source IDs are missing or duplicated.", call. = FALSE)
  }
  match_index <- match(master$participant_id, donor$participant_id)
  if (anyNA(match_index)) {
    stop("The authorized W1 weight join is incomplete.", call. = FALSE)
  }
  weight <- suppressWarnings(as.numeric(donor$weight_kg_w1[match_index]))
  observed_weight <- is.finite(weight)
  if (!any(observed_weight) ||
      any(weight[observed_weight] < -1e6 | weight[observed_weight] > 1e6)) {
    stop("The authorized W1 weight donor is structurally invalid.", call. = FALSE)
  }
  list(
    master = master,
    period = period,
    weight_kg_w1 = weight,
    source_validation = source_validation
  )
}

v45_charls_actual_denominators <- function(source) {
  master <- source$master
  period <- source$period
  valid_trial <- function(x) is.finite(x) & x >= 30 & x <= 890
  complete_three <- valid_trial(master$pef_w1_trial1) &
    valid_trial(master$pef_w1_trial2) &
    valid_trial(master$pef_w1_trial3)
  adjacent_row <- period$end_wave - period$start_wave == 1L
  adjacent_ids <- unique(period$participant_id[adjacent_row])
  post_w2 <- period$start_wave >= 2L
  post_w2_ids <- unique(period$participant_id[post_w2])
  w2_initial <- master$known_alive_w2 == 1L &
    master$participant_id %in% post_w2_ids
  r_w2 <- is.finite(master$pef_w2_rowmax) &
    master$pef_w2_rowmax >= 30 &
    master$pef_w2_rowmax <= 890
  response_by_psu <- tapply(
    r_w2[w2_initial],
    as.character(master$community_id[w2_initial]),
    sum
  )
  supported_keys <- names(response_by_psu)[
    is.finite(response_by_psu) & response_by_psu > 0
  ]
  zero_response_keys <- names(response_by_psu)[response_by_psu == 0]
  w2_supported <- w2_initial &
    as.character(master$community_id) %in% supported_keys
  post_period <- period[post_w2, , drop = FALSE]
  split_period <- split(
    seq_len(nrow(post_period)), as.character(post_period$participant_id)
  )
  post_event <- integer(nrow(master))
  post_last_wave <- integer(nrow(master))
  post_span <- numeric(nrow(master))
  for (participant in names(split_period)) {
    index <- split_period[[participant]]
    row <- match(participant, master$participant_id)
    post_event[[row]] <- as.integer(any(post_period$period_event[index] == 1L))
    post_last_wave[[row]] <- max(post_period$end_wave[index])
    post_span[[row]] <- sum(post_period$nominal_years[index])
  }
  list(
    complete_three = complete_three,
    adjacent_row = adjacent_row,
    adjacent_ids = adjacent_ids,
    w2_initial = w2_initial,
    r_w2 = r_w2,
    response_by_psu = response_by_psu,
    supported_keys = sort(enc2utf8(supported_keys), method = "radix"),
    zero_response_keys = sort(enc2utf8(zero_response_keys), method = "radix"),
    w2_supported = w2_supported,
    post_event = post_event,
    post_last_wave = post_last_wave,
    post_span = post_span
  )
}

v45_charls_actual_assert_anchors <- function(source, denominator, spec) {
  master <- source$master
  period <- source$period
  trial_period <- period[
    period$participant_id %in%
      master$participant_id[denominator$complete_three],
    ,
    drop = FALSE
  ]
  adjacent <- period[denominator$adjacent_row, , drop = FALSE]
  w2_initial <- denominator$w2_initial
  w2_supported <- denominator$w2_supported
  checks <- data.frame(
    check_id = character(),
    observed = character(),
    expected = character(),
    status = character(),
    stringsAsFactors = FALSE
  )
  add <- function(id, observed, expected, pass) {
    checks <<- rbind(
      checks,
      data.frame(
        check_id = id,
        observed = as.character(observed),
        expected = as.character(expected),
        status = if (isTRUE(pass)) "PASS" else "FAIL",
        stringsAsFactors = FALSE
      )
    )
  }
  trial <- spec$denominators$trial
  add("trial_participants", sum(denominator$complete_three), trial$participants,
      sum(denominator$complete_three) == as.integer(trial$participants))
  add("trial_deaths", sum(master$event_any[denominator$complete_three]),
      trial$deaths,
      sum(master$event_any[denominator$complete_three]) ==
        as.integer(trial$deaths))
  add("trial_period_rows", nrow(trial_period), trial$person_period_rows,
      nrow(trial_period) == as.integer(trial$person_period_rows))
  add(
    "trial_psu",
    length(unique(master$community_id[denominator$complete_three])),
    trial$psu,
    length(unique(master$community_id[denominator$complete_three])) ==
      as.integer(trial$psu)
  )
  adjacent_spec <- spec$denominators$adjacent
  add("adjacent_participants", length(denominator$adjacent_ids),
      adjacent_spec$participants,
      length(denominator$adjacent_ids) == as.integer(adjacent_spec$participants))
  add("adjacent_deaths", sum(adjacent$period_event),
      adjacent_spec$deaths,
      sum(adjacent$period_event) == as.integer(adjacent_spec$deaths))
  add("adjacent_rows", nrow(adjacent), adjacent_spec$person_period_rows,
      nrow(adjacent) == as.integer(adjacent_spec$person_period_rows))
  add("adjacent_psu", length(unique(adjacent$community_id)),
      adjacent_spec$adjacent_only_psu,
      length(unique(adjacent$community_id)) ==
        as.integer(adjacent_spec$adjacent_only_psu))
  initial <- spec$denominators$w2_initial
  add("w2_initial_participants", sum(w2_initial), initial$participants,
      sum(w2_initial) == as.integer(initial$participants))
  add("w2_initial_psu",
      length(unique(master$community_id[w2_initial])), initial$psu,
      length(unique(master$community_id[w2_initial])) ==
        as.integer(initial$psu))
  add("w2_response_observed", sum(denominator$r_w2[w2_initial]),
      initial$response_observed,
      sum(denominator$r_w2[w2_initial]) ==
        as.integer(initial$response_observed))
  add("w2_zero_response_psu", length(denominator$zero_response_keys),
      initial$zero_response_psu,
      length(denominator$zero_response_keys) ==
        as.integer(initial$zero_response_psu))
  add(
    "w2_zero_response_participants",
    sum(
      w2_initial &
        as.character(master$community_id) %in% denominator$zero_response_keys
    ),
    initial$participants_in_zero_response_psu,
    sum(
      w2_initial &
        as.character(master$community_id) %in% denominator$zero_response_keys
    ) == as.integer(initial$participants_in_zero_response_psu)
  )
  supported <- spec$denominators$w2_D2_supported
  add("w2_supported_participants", sum(w2_supported), supported$participants,
      sum(w2_supported) == as.integer(supported$participants))
  add("w2_supported_psu",
      length(unique(master$community_id[w2_supported])), supported$psu,
      length(unique(master$community_id[w2_supported])) ==
        as.integer(supported$psu))
  add("w2_supported_response", sum(denominator$r_w2[w2_supported]),
      supported$response_observed,
      sum(denominator$r_w2[w2_supported]) ==
        as.integer(supported$response_observed))
  add("w2_supported_nonresponse",
      sum(!denominator$r_w2[w2_supported]), supported$response_unobserved,
      sum(!denominator$r_w2[w2_supported]) ==
        as.integer(supported$response_unobserved))
  if (any(checks$status != "PASS")) {
    stop("One or more CHARLS denominator anchors drifted.", call. = FALSE)
  }
  checks
}

v45_charls_actual_sorted_keys <- function(x) {
  sort(unique(enc2utf8(as.character(x))), method = "radix")
}

v45_charls_actual_key_map <- function(keys, module_id) {
  keys <- v45_charls_actual_sorted_keys(keys)
  data.frame(
    module_id = module_id,
    stratum_key = "CHARLS_SINGLE_STRATUM",
    psu_ordinal = seq_along(keys),
    community_id = keys,
    stringsAsFactors = FALSE
  )
}

v45_charls_actual_generate_subbootstrap <- function(
    key_map, seed, matrix_id) {
  if (!identical(key_map$psu_ordinal, seq_len(nrow(key_map))) ||
      anyDuplicated(key_map$community_id) ||
      length(unique(key_map$stratum_key)) != 1L ||
      nrow(key_map) < 2L) {
    stop("The actual CHARLS key map is invalid.", call. = FALSE)
  }
  skeleton <- data.frame(
    psu_key = factor(
      key_map$community_id, levels = key_map$community_id
    ),
    structural_weight = 1,
    stringsAsFactors = FALSE
  )
  design <- survey::svydesign(
    ids = ~psu_key,
    weights = ~structural_weight,
    data = skeleton,
    nest = TRUE
  )
  RNGkind(
    kind = "Mersenne-Twister",
    normal.kind = "Inversion",
    sample.kind = "Rejection"
  )
  set.seed(as.integer(seed))
  warnings <- character()
  replicate_design <- withCallingHandlers(
    survey::as.svrepdesign(
      design,
      type = "subbootstrap",
      replicates = 500L,
      mse = TRUE,
      compress = TRUE
    ),
    warning = function(warning) {
      warnings <<- c(warnings, conditionMessage(warning))
      invokeRestart("muffleWarning")
    }
  )
  if (length(warnings)) {
    stop(
      matrix_id, " generated warnings: ",
      paste(unique(warnings), collapse = " | "), call. = FALSE
    )
  }
  if (!inherits(replicate_design$repweights, "repweights_compressed")) {
    stop(matrix_id, " did not retain compressed replicate weights.", call. = FALSE)
  }
  matrix <- unclass(replicate_design$repweights$weights)
  rownames(matrix) <- key_map$community_id
  colnames(matrix) <- sprintf("R%03d", seq_len(ncol(matrix)))
  list(
    matrix_id = matrix_id,
    seed = as.integer(seed),
    key_map = key_map,
    matrix = matrix,
    index = as.integer(replicate_design$repweights$index),
    pweights = as.numeric(replicate_design$pweights),
    scale = as.numeric(replicate_design$scale),
    rscales = as.numeric(replicate_design$rscales),
    mse = isTRUE(replicate_design$mse),
    combined_weights = isTRUE(replicate_design$combined.weights),
    degf = as.integer(replicate_design$degf),
    warnings = unique(warnings)
  )
}

v45_charls_actual_matrix_audit <- function(module) {
  matrix <- module$matrix
  value_matrix <- matrix
  dimnames(value_matrix) <- NULL
  prefix <- matrix[, seq_len(250L), drop = FALSE]
  prefix_value <- prefix
  dimnames(prefix_value) <- NULL
  data.frame(
    matrix_id = module$matrix_id,
    seed = module$seed,
    psu = nrow(matrix),
    replicates = ncol(matrix),
    design_df = module$degf,
    stratum_n = length(unique(module$key_map$stratum_key)),
    key_sha256 = v45_canonical_object_sha256(module$key_map$community_id),
    matrix_sha256 = v45_canonical_array_sha256(matrix),
    value_sha256 = v45_canonical_array_sha256(value_matrix),
    prefix_value_sha256 = v45_canonical_array_sha256(prefix_value),
    finite_nonnegative = all(is.finite(matrix) & matrix >= 0),
    maximum_balance_error = max(abs(colSums(matrix) - nrow(matrix))),
    each_replicate_omits_psu =
      all(apply(matrix, 2L, function(column) any(column == 0))),
    index_exact = identical(module$index, seq_len(nrow(matrix))),
    pweights_exact = length(module$pweights) == nrow(matrix) &&
      all(module$pweights == 1),
    scale_exact = identical(module$scale, 1 / 499),
    prefix_scale = 1 / 249,
    rscales_exact = length(module$rscales) == 500L &&
      all(module$rscales == 1),
    mse = module$mse,
    combined_weights = module$combined_weights,
    warning_n = length(module$warnings),
    status = if (
      ncol(matrix) == 500L &&
        all(is.finite(matrix) & matrix >= 0) &&
        max(abs(colSums(matrix) - nrow(matrix))) <= 1e-10 &&
        all(apply(matrix, 2L, function(column) any(column == 0))) &&
        identical(module$index, seq_len(nrow(matrix))) &&
        length(module$pweights) == nrow(matrix) &&
        all(module$pweights == 1) &&
        identical(module$scale, 1 / 499) &&
        length(module$rscales) == 500L &&
        all(module$rscales == 1) &&
        module$mse && !module$combined_weights &&
        !length(module$warnings)
    ) "PASS" else "FAIL",
    stringsAsFactors = FALSE
  )
}

v45_charls_actual_build_clean_master <- function(source, authority, v44_spec) {
  variant <- authority$variant_catalog_v44(v44_spec)[[
    "who_block_no_later_aux"
  ]]
  if (!identical(variant$seed, 440401L) ||
      !identical(variant$h, c(1, 2.7)) ||
      !identical(variant$w, c(20, 350)) ||
      !identical(variant$b, c(11, 75)) ||
      !isTRUE(variant$block) || isTRUE(variant$later)) {
    stop("The inherited MI-C0 WHO variant drifted.", call. = FALSE)
  }
  raw_master <- source$master
  raw_master$height_m_w1_raw <- suppressWarnings(
    as.numeric(raw_master$height_m_w1)
  )
  raw_master$weight_kg_w1_raw <- source$weight_kg_w1
  cleaned <- authority$clean_wave_v44(
    raw_master$height_m_w1_raw,
    raw_master$weight_kg_w1_raw,
    variant
  )
  clean_master <- raw_master
  clean_master$height_m_w1 <- cleaned$height
  clean_master$weight_kg_w1 <- cleaned$weight
  clean_master$bmi_w1 <- cleaned$bmi
  list(master = clean_master, variant = variant, cleaning = cleaned)
}

v45_charls_actual_build_mi_c0 <- function(source, authority, v44_spec) {
  prepared <- v45_charls_actual_build_clean_master(
    source, authority, v44_spec
  )
  mi_data <- authority$make_mi_input_v44(
    prepared$master, prepared$variant
  )
  mi_spec <- authority$freeze_mi_spec_v44(
    mi_data, prepared$variant, v44_spec
  )
  if (!identical(mi_spec$seed, 440401L) ||
      !identical(mi_spec$method[["height_m_w1"]],
                 "v44_who_constrained_height_pmm") ||
      !identical(mi_spec$method[["weight_kg_w1"]],
                 "v44_who_constrained_weight_pmm") ||
      !identical(mi_spec$method[["bmi_w1"]], "")) {
    stop("MI-C0 method or seed semantics drifted.", call. = FALSE)
  }
  list(
    object_id = "MI-C0",
    mi_data = mi_data,
    mi_spec = mi_spec,
    clean_master = prepared$master,
    variant = prepared$variant,
    passive = c(
      bmi_w1 = "weight_kg_w1 / height_m_w1^2",
      height_basis = "rebuild_after_completed_height"
    )
  )
}

v45_charls_actual_post_w2_summary <- function(source, denominator) {
  period <- source$period[source$period$start_wave >= 2L, , drop = FALSE]
  supported_ids <- source$master$participant_id[denominator$w2_supported]
  period <- period[period$participant_id %in% supported_ids, , drop = FALSE]
  split_index <- split(seq_len(nrow(period)), as.character(period$participant_id))
  out <- data.frame(
    participant_id = supported_ids,
    event_after_w2 = integer(length(supported_ids)),
    last_observed_post_w2_wave = integer(length(supported_ids)),
    observed_post_w2_span = numeric(length(supported_ids)),
    stringsAsFactors = FALSE
  )
  for (i in seq_len(nrow(out))) {
    index <- split_index[[out$participant_id[[i]]]]
    if (is.null(index) || !length(index)) {
      stop("A W2-supported participant lacks a post-W2 transition.", call. = FALSE)
    }
    out$event_after_w2[[i]] <- as.integer(any(period$period_event[index] == 1L))
    out$last_observed_post_w2_wave[[i]] <- max(period$end_wave[index])
    out$observed_post_w2_span[[i]] <- sum(period$nominal_years[index])
  }
  out
}

v45_charls_actual_build_mi_c2 <- function(
    source, denominator, authority, v44_spec) {
  prepared <- v45_charls_actual_build_clean_master(
    source, authority, v44_spec
  )
  master <- prepared$master[denominator$w2_supported, , drop = FALSE]
  post <- v45_charls_actual_post_w2_summary(source, denominator)
  index <- match(master$participant_id, post$participant_id)
  if (anyNA(index)) {
    stop("The MI-C2 post-W2 auxiliary join is incomplete.", call. = FALSE)
  }
  master$event_any <- post$event_after_w2[index]
  master$last_known_followup_wave <-
    post$last_observed_post_w2_wave[index]
  master$total_observed_followup_span <-
    post$observed_post_w2_span[index]
  variant <- prepared$variant
  variant$seed <- 450503L
  mi_data <- authority$make_mi_input_v44(master, variant)
  mi_data$last_known_followup_wave <- droplevels(
    mi_data$last_known_followup_wave
  )
  mi_data$R_W2 <- factor(
    as.integer(denominator$r_w2[denominator$w2_supported]),
    levels = 0:1
  )
  mi_spec <- authority$freeze_mi_spec_v44(mi_data, variant, v44_spec)
  mi_spec$seed <- 450503L
  mi_spec$method[["R_W2"]] <- ""
  mi_spec$predictor_matrix["R_W2", ] <- 0
  mi_spec$w2_fixed_auxiliaries <- c(
    "R_W2", "event_any", "last_known_followup_wave", "E0",
    "log_survey_weight"
  )
  mi_spec$w2_pef_columns_forbidden <- TRUE
  mi_spec$passive_age_w2_rule <- "age_w1 + 2"
  forbidden_w2_pef_columns <- grep(
    "pef_w2|E0_W2|M12|D12",
    names(mi_data), ignore.case = TRUE, value = TRUE
  )
  pef_targets <- names(mi_spec$method)[
    nzchar(mi_spec$method) &
      grepl("(^|_)pef|E0_W2|M12|D12", names(mi_spec$method), ignore.case = TRUE)
  ]
  if (length(forbidden_w2_pef_columns) || length(pef_targets) ||
      anyNA(mi_data$R_W2) ||
      !identical(mi_spec$seed, 450503L) ||
      nzchar(mi_spec$method[["R_W2"]]) ||
      !identical(mi_spec$method[["height_m_w1"]],
                 "v44_who_constrained_height_pmm") ||
      !identical(mi_spec$method[["weight_kg_w1"]],
                 "v44_who_constrained_weight_pmm") ||
      !identical(mi_spec$method[["bmi_w1"]], "")) {
    stop("MI-C2 fixed-response/no-PEF contract drifted.", call. = FALSE)
  }
  list(
    object_id = "MI-C2",
    mi_data = mi_data,
    mi_spec = mi_spec,
    clean_master = master,
    variant = variant,
    passive = c(
      bmi_w1 = "weight_kg_w1 / height_m_w1^2",
      age_w2_model = "age_w1 + 2",
      height_basis = "rebuild_after_completed_height"
    )
  )
}

v45_charls_actual_object_contract <- function(object) {
  where <- is.na(object$mi_data)
  storage.mode(where) <- "logical"
  method <- object$mi_spec$method
  predictor <- object$mi_spec$predictor_matrix
  visit <- object$mi_spec$visit_sequence
  active <- names(method)[nzchar(method)]
  data_contract <- v45_canonical_data_frame_contract(object$mi_data)
  data.frame(
    object_id = object$object_id,
    n = nrow(object$mi_data),
    columns = ncol(object$mi_data),
    seed = as.integer(object$mi_spec$seed),
    production_initial_m = as.integer(object$mi_spec$initial_m),
    production_maximum_m = as.integer(object$mi_spec$maximum_m),
    production_checkpoints = paste(
      object$mi_spec$convergence_iteration_checkpoints, collapse = "|"
    ),
    active_target_n = length(active),
    active_targets = paste(active, collapse = "|"),
    input_sha256 = data_contract$sha256,
    method_sha256 = v45_canonical_object_sha256(method),
    predictor_sha256 = v45_canonical_array_sha256(predictor),
    where_sha256 = v45_canonical_array_sha256(where),
    visit_sha256 = v45_canonical_object_sha256(visit),
    missingness_sha256 = v45_canonical_object_sha256(
      vapply(object$mi_data, function(x) sum(is.na(x)), integer(1))
    ),
    passive_sha256 = v45_canonical_object_sha256(object$passive),
    pef_imputation_target_n = sum(
      nzchar(method) &
        grepl("(^|_)pef|E0_W2|M12|D12", names(method), ignore.case = TRUE)
    ),
    status = "PASS",
    stringsAsFactors = FALSE
  )
}

v45_charls_actual_equal_observed <- function(original, completed) {
  if (!identical(names(original), names(completed)) ||
      nrow(original) != nrow(completed)) {
    return(FALSE)
  }
  all(vapply(names(original), function(name) {
    observed <- !is.na(original[[name]])
    if (!any(observed)) return(TRUE)
    left <- original[[name]][observed]
    right <- completed[[name]][observed]
    if (is.factor(left)) {
      identical(as.character(left), as.character(right)) &&
        identical(levels(original[[name]]), levels(completed[[name]]))
    } else if (is.numeric(left)) {
      identical(as.numeric(left), as.numeric(right))
    } else {
      identical(left, right)
    }
  }, logical(1)))
}

v45_charls_actual_complete_and_validate <- function(
    imp, object, run_label) {
  rows <- vector("list", imp$m)
  completion_hashes <- character(imp$m)
  for (chain in seq_len(imp$m)) {
    completed <- mice::complete(imp, action = chain)
    if (!v45_charls_actual_equal_observed(object$mi_data, completed)) {
      stop(
        object$object_id, " changed an observed value in ", run_label,
        "/chain", chain, ".", call. = FALSE
      )
    }
    height <- suppressWarnings(as.numeric(completed$height_m_w1))
    weight <- suppressWarnings(as.numeric(completed$weight_kg_w1))
    bmi <- weight / height^2
    ever <- suppressWarnings(as.numeric(as.character(completed$smoke_ever_w1)))
    now <- suppressWarnings(as.numeric(as.character(completed$smoke_now_w1)))
    parent_bad <- !is.finite(height) | height < 1 | height > 2.7 |
      !is.finite(weight) | weight < 20 | weight > 350
    bmi_bad <- !is.finite(bmi) | bmi < 11 | bmi > 75
    smoking_bad <- !is.finite(ever) | !is.finite(now) |
      !ever %in% 0:1 | !now %in% 0:1 | (ever == 0 & now == 1)
    if (any(parent_bad) || any(bmi_bad) || any(smoking_bad)) {
      stop(
        object$object_id, " completion gate failed in ", run_label,
        "/chain", chain, ".", call. = FALSE
      )
    }
    completed$bmi_w1 <- bmi
    age_identity_error <- NA_real_
    if (identical(object$object_id, "MI-C2")) {
      completed$age_w2_model <-
        suppressWarnings(as.numeric(completed$age_w1)) + 2
      age_identity_error <- max(abs(
        completed$age_w2_model -
          (suppressWarnings(as.numeric(completed$age_w1)) + 2)
      ))
    }
    bmi_identity_error <- max(abs(completed$bmi_w1 - weight / height^2))
    completion_hashes[[chain]] <-
      v45_canonical_data_frame_contract(completed)$sha256
    rows[[chain]] <- data.frame(
      object_id = object$object_id,
      run_label = run_label,
      chain = chain,
      n = nrow(completed),
      height_min = min(height),
      height_max = max(height),
      weight_min = min(weight),
      weight_max = max(weight),
      bmi_min = min(bmi),
      bmi_max = max(bmi),
      bmi_identity_max_error = bmi_identity_error,
      age_w2_identity_max_error = age_identity_error,
      observed_value_change_n = 0L,
      smoking_conflict_n = 0L,
      completion_sha256 = completion_hashes[[chain]],
      stringsAsFactors = FALSE
    )
    rm(completed)
  }
  list(
    summary = do.call(rbind, rows),
    completion_hashes = completion_hashes
  )
}

v45_charls_actual_run_dry_once <- function(object, authority, run_label) {
  restore <- v45_charls_actual_register_v44_imputers(authority)
  on.exit(restore(), add = TRUE)
  warnings <- character()
  imp <- withCallingHandlers(
    authority$run_mi_checked(
      object$mi_data,
      object$mi_spec,
      m = 2L,
      maxit = 2L
    ),
    warning = function(warning) {
      warnings <<- c(warnings, conditionMessage(warning))
      invokeRestart("muffleWarning")
    }
  )
  if (length(warnings)) {
    stop(
      object$object_id, " dry run emitted warnings: ",
      paste(unique(warnings), collapse = " | "), call. = FALSE
    )
  }
  logged_events <- if (is.null(imp$loggedEvents)) 0L else nrow(imp$loggedEvents)
  if (logged_events != 0L) {
    stop(object$object_id, " dry run retained logged MICE events.", call. = FALSE)
  }
  completion <- v45_charls_actual_complete_and_validate(
    imp, object, run_label
  )
  result <- list(
    object_id = object$object_id,
    run_label = run_label,
    m = imp$m,
    maxit = imp$iteration,
    warning_n = length(warnings),
    logged_event_n = logged_events,
    imputation_payload_sha256 =
      v45_canonical_imputation_payload_sha256(imp),
    completion_hashes = completion$completion_hashes,
    completion_summary = completion$summary
  )
  rm(imp)
  invisible(gc(verbose = FALSE))
  result
}

v45_charls_actual_run_dry_pair <- function(object, authority) {
  first <- v45_charls_actual_run_dry_once(object, authority, "A")
  second <- v45_charls_actual_run_dry_once(object, authority, "B")
  deterministic <- identical(
    first$imputation_payload_sha256,
    second$imputation_payload_sha256
  ) && identical(first$completion_hashes, second$completion_hashes)
  if (!deterministic) {
    stop(object$object_id, " dry pair is not deterministic.", call. = FALSE)
  }
  list(
    audit = data.frame(
      object_id = object$object_id,
      m = first$m,
      maxit = first$maxit,
      run_A_payload_sha256 = first$imputation_payload_sha256,
      run_B_payload_sha256 = second$imputation_payload_sha256,
      run_A_completion_sha256 = paste(first$completion_hashes, collapse = "|"),
      run_B_completion_sha256 = paste(second$completion_hashes, collapse = "|"),
      warnings = first$warning_n + second$warning_n,
      logged_events = first$logged_event_n + second$logged_event_n,
      deterministic = deterministic,
      status = if (
        deterministic &&
          first$warning_n + second$warning_n == 0L &&
          first$logged_event_n + second$logged_event_n == 0L
      ) "PASS" else "FAIL",
      stringsAsFactors = FALSE
    ),
    completion = rbind(first$completion_summary, second$completion_summary)
  )
}

v45_charls_actual_function_manifest <- function(root, authority) {
  paths <- v45_charls_actual_paths(root)
  names <- attr(authority, "function_names")
  authority_source <- c(
    rep("v43", 13L),
    rep("v44", length(names) - 13L)
  )
  data.frame(
    function_name = names,
    authority = authority_source,
    authority_file_sha256 = vapply(
      authority_source,
      function(source) v45_charls_sha256_file(paths[[source]]),
      character(1)
    ),
    function_sha256 = vapply(
      names,
      function(name) {
        v45_charls_function_sha256(
          get(name, envir = authority, inherits = FALSE)
        )
      },
      character(1)
    ),
    status = "PASS",
    stringsAsFactors = FALSE
  )
}
