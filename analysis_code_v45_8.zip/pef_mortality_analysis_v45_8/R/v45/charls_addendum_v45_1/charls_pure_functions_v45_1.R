# Sourceable CHARLS v45.1 pure-function library.
#
# Functions in `authority_migrated` are mechanically copied from the frozen
# authority scripts. Those scripts are never sourced by this file. New
# structural helpers are isolated in `structural_helpers`.

v45_charls_pure_library <- local({
  weighted_mean_simple <- function(x, w) {
    ok <- is.finite(x) & is.finite(w) & w > 0
    if (!any(ok)) return(NA_real_)
    sum(x[ok] * w[ok]) / sum(w[ok])
  }

  weighted_var_simple <- function(x, w) {
    ok <- is.finite(x) & is.finite(w) & w > 0
    if (sum(ok) < 2L) return(NA_real_)
    mu <- weighted_mean_simple(x[ok], w[ok])
    sum(w[ok] * (x[ok] - mu)^2) / sum(w[ok])
  }

  weighted_cor_simple <- function(x, y, w) {
    ok <- is.finite(x) & is.finite(y) & is.finite(w) & w > 0
    if (sum(ok) < 3L) return(NA_real_)
    x <- x[ok]
    y <- y[ok]
    w <- w[ok]
    mx <- sum(w * x) / sum(w)
    my <- sum(w * y) / sum(w)
    vx <- sum(w * (x - mx)^2) / sum(w)
    vy <- sum(w * (y - my)^2) / sum(w)
    if (!is.finite(vx) || !is.finite(vy) || vx <= 0 || vy <= 0) return(NA_real_)
    sum(w * (x - mx) * (y - my)) / sum(w) / sqrt(vx * vy)
  }

  row_summary <- function(mat, fun) {
    apply(mat, 1, function(z) {
      z <- z[is.finite(z)]
      if (!length(z)) return(NA_real_)
      fun(z)
    })
  }

  top_two_difference <- function(mat) {
    apply(mat, 1, function(z) {
      z <- sort(z[is.finite(z)], decreasing = TRUE)
      if (length(z) < 2L) return(NA_real_)
      z[[1]] - z[[2]]
    })
  }

  variant_catalog_v44 <- function(spec) {
    variants <- spec$mi_variants
    out <- lapply(variants, function(v) {
      bounds <- if (identical(v$bounds, "who_operational")) {
        spec$anthropometric_rules$who_operational
      } else if (identical(v$bounds, "pcornet_sensitivity")) {
        spec$anthropometric_rules$pcornet_sensitivity
      } else {
        stop("Unknown anthropometric bound set: ", v$bounds, call. = FALSE)
      }
      list(
        id = as.character(v$id), role = as.character(v$role),
        bounds_id = as.character(v$bounds), invalidation = as.character(v$invalidation),
        later = isTRUE(v$later_wave_auxiliaries),
        tiers = unlist(v$fit_tiers, use.names = FALSE), seed = as.integer(v$seed),
        h = as.numeric(unlist(bounds$height_m)),
        w = as.numeric(unlist(bounds$weight_kg)),
        b = as.numeric(unlist(bounds$reconstructed_bmi_kg_m2)),
        block = grepl("block", as.character(v$id), fixed = TRUE)
      )
    })
    names(out) <- vapply(out, `[[`, character(1), "id")
    out
  }

  clean_wave_v44 <- function(height, weight, variant) {
    height <- suppressWarnings(as.numeric(height))
    weight <- suppressWarnings(as.numeric(weight))
    h_flag <- is.finite(height) & (height < variant$h[[1]] | height > variant$h[[2]])
    w_flag <- is.finite(weight) & (weight < variant$w[[1]] | weight > variant$w[[2]])
    raw_bmi <- ifelse(
      is.finite(height) & height > 0 & is.finite(weight),
      weight / height^2,
      NA_real_
    )
    b_flag <- is.finite(raw_bmi) & (raw_bmi < variant$b[[1]] | raw_bmi > variant$b[[2]])
    if (isTRUE(variant$block)) {
      any_flag <- h_flag | w_flag | b_flag
      height_clean <- ifelse(any_flag, NA_real_, height)
      weight_clean <- ifelse(any_flag, NA_real_, weight)
    } else {
      any_flag <- h_flag | w_flag | b_flag
      height_clean <- ifelse(h_flag, NA_real_, height)
      weight_clean <- ifelse(w_flag, NA_real_, weight)
    }
    bmi_clean <- ifelse(
      is.finite(height_clean) & height_clean > 0 & is.finite(weight_clean),
      weight_clean / height_clean^2,
      NA_real_
    )
    list(
      height = height_clean, weight = weight_clean, bmi = bmi_clean,
      h_flag = h_flag, w_flag = w_flag, b_flag = b_flag,
      any_flag = any_flag, raw_bmi = raw_bmi
    )
  }

  validate_covariance_matrix <- function(variance, coefficient_names, context) {
    variance <- as.matrix(variance)
    p <- length(coefficient_names)
    if (!identical(dim(variance), c(p, p))) {
      stop(context, " covariance dimension does not match the coefficient vector.", call. = FALSE)
    }
    if (is.null(rownames(variance)) || is.null(colnames(variance)) ||
        !identical(rownames(variance), coefficient_names) ||
        !identical(colnames(variance), coefficient_names)) {
      stop(context, " covariance names/order do not match the coefficient vector.", call. = FALSE)
    }
    if (any(!is.finite(variance))) {
      stop(context, " covariance matrix contains non-finite values.", call. = FALSE)
    }
    scale <- max(.Machine$double.xmin, max(abs(variance)))
    symmetry_error <- max(abs(variance - t(variance)))
    if (!is.finite(symmetry_error) ||
        symmetry_error > sqrt(.Machine$double.eps) * scale) {
      stop(context, " covariance matrix is not symmetric within numerical tolerance.", call. = FALSE)
    }
    symmetric_variance <- (variance + t(variance)) / 2
    eigenvalues <- eigen(symmetric_variance, symmetric = TRUE, only.values = TRUE)$values
    eigenvalue_scale <- max(abs(eigenvalues))
    positive_tolerance <- max(
      .Machine$double.xmin,
      .Machine$double.eps * max(1, p) * eigenvalue_scale
    )
    if (any(!is.finite(eigenvalues)) || min(eigenvalues) <= positive_tolerance) {
      stop(context, " covariance matrix is not numerically positive definite.", call. = FALSE)
    }
    list(
      matrix = symmetric_variance,
      symmetry_error = symmetry_error,
      minimum_eigenvalue = min(eigenvalues),
      condition_number = max(eigenvalues) / min(eigenvalues)
    )
  }

  authority_migrated <- list(
    weighted_mean_simple = weighted_mean_simple,
    weighted_var_simple = weighted_var_simple,
    weighted_cor_simple = weighted_cor_simple,
    row_summary = row_summary,
    top_two_difference = top_two_difference,
    variant_catalog_v44 = variant_catalog_v44,
    clean_wave_v44 = clean_wave_v44,
    validate_covariance_matrix = validate_covariance_matrix
  )

  kish_ess <- function(weight) {
    keep <- is.finite(weight) & weight > 0
    weight <- as.numeric(weight[keep])
    if (!length(weight)) return(NA_real_)
    sum(weight)^2 / sum(weight^2)
  }

  same_respondent_ess_ratio <- function(base_weight, availability_factor, r2) {
    if (!identical(length(base_weight), length(availability_factor)) ||
        !identical(length(base_weight), length(r2))) {
      stop("ESS inputs must have identical lengths.", call. = FALSE)
    }
    r2 <- as.integer(r2)
    keep <- r2 == 1L & is.finite(base_weight) & base_weight > 0 &
      is.finite(availability_factor) & availability_factor > 0
    if (!any(keep)) {
      stop("The ESS contract has no valid R2 respondents.", call. = FALSE)
    }
    base_ess <- kish_ess(base_weight[keep])
    composite_ess <- kish_ess(
      base_weight[keep] * availability_factor[keep]
    )
    ratio <- composite_ess / base_ess
    if (!all(is.finite(c(base_ess, composite_ess, ratio))) ||
        base_ess <= 0 || composite_ess <= 0 || ratio <= 0) {
      stop("The same-respondent ESS contract is non-finite.", call. = FALSE)
    }
    list(
      base_ess_same_r2 = base_ess,
      composite_ess_same_r2 = composite_ess,
      ratio = ratio,
      respondent_n = sum(keep)
    )
  }

  paired_replicate_covariance <- function(
      replicate_estimates, point_estimate, scale, rscales) {
    replicate_estimates <- as.matrix(replicate_estimates)
    point_estimate <- as.numeric(point_estimate)
    if (ncol(replicate_estimates) != 2L ||
        length(point_estimate) != 2L ||
        nrow(replicate_estimates) != length(rscales) ||
        any(!is.finite(replicate_estimates)) ||
        any(!is.finite(point_estimate)) ||
        !is.finite(scale) || scale <= 0 ||
        any(!is.finite(rscales) | rscales <= 0)) {
      stop("Invalid paired replicate-covariance contract.", call. = FALSE)
    }
    centered <- sweep(
      replicate_estimates, 2L, point_estimate, FUN = "-"
    )
    covariance <- scale * crossprod(
      centered * sqrt(as.numeric(rscales)),
      centered * sqrt(as.numeric(rscales))
    )
    dimnames(covariance) <- list(
      c("all", "adjacent"), c("all", "adjacent")
    )
    delta_replicates <-
      replicate_estimates[, "adjacent"] - replicate_estimates[, "all"]
    delta_point <- point_estimate[[2]] - point_estimate[[1]]
    delta_variance_direct <- scale * sum(
      rscales * (delta_replicates - delta_point)^2
    )
    contrast <- c(all = -1, adjacent = 1)
    delta_variance_quadratic <- as.numeric(
      t(contrast) %*% covariance %*% contrast
    )
    list(
      covariance = covariance,
      delta_point = delta_point,
      delta_replicates = delta_replicates,
      delta_variance_direct = delta_variance_direct,
      delta_variance_quadratic = delta_variance_quadratic
    )
  }

  structural_helpers <- list(
    kish_ess = kish_ess,
    same_respondent_ess_ratio = same_respondent_ess_ratio,
    paired_replicate_covariance = paired_replicate_covariance
  )

  list(
    authority_migrated = authority_migrated,
    structural_helpers = structural_helpers
  )
})

v45_charls_pure_provenance <- data.frame(
  function_name = names(v45_charls_pure_library$authority_migrated),
  authority_id = c(
    rep("flow_measurement", 5L),
    rep("anthropometric_v44_1_1", 2L),
    "mortality_library"
  ),
  authority_start_line = c(50L, 56L, 63L, 98L, 106L, 651L, 676L, 2748L),
  migration_rule = "identical formals plus deparsed body",
  stringsAsFactors = FALSE
)
