#!/usr/bin/env Rscript

options(stringsAsFactors = FALSE, warn = 1)

script_path <- sub(
  "^--file=", "",
  grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)[[1]]
)
root <- normalizePath(
  file.path(dirname(script_path), "..", "..", ".."),
  mustWork = TRUE
)
source(file.path(
  root,
  "R/v45/charls_addendum_v45_1/charls_structural_utilities_v45_1.R"
))
v45_charls_activate_project_library(root)
required_packages <- c("yaml", "digest", "mice", "survey", "dplyr")
if (!all(vapply(
  required_packages, requireNamespace, quietly = TRUE, FUN.VALUE = logical(1)
))) {
  stop("Required independent CHARLS validator packages are unavailable.", call. = FALSE)
}
source(file.path(root, "R/v45/production_mi_hashes_v45.R"))

work_dir <- file.path(root, "work_v45/charls_addendum_v45_1")
result_dir <- file.path(root, "results/v45/charls_addendum_v45_1")
restricted_path <- file.path(
  root,
  paste0(
    "derived_sensitive/v45/charls_addendum_v45_1/",
    "charls_actual_keys_mi_contract_v45_1.rds"
  )
)
qa_dir <- file.path(root, "output/qa/v45/charls_addendum_v45_1")
spec <- yaml::read_yaml(file.path(
  work_dir, "charls_actual_keys_mi_spec_v45_1.yml"
))

sha256 <- function(path) v45_charls_sha256_file(path)
add_check <- function(checks, id, pass, observed, expected) {
  rbind(
    checks,
    data.frame(
      check_id = id,
      status = if (isTRUE(pass)) "PASS" else "FAIL",
      observed = as.character(observed),
      expected = as.character(expected),
      stringsAsFactors = FALSE
    )
  )
}

checks <- data.frame(
  check_id = character(), status = character(),
  observed = character(), expected = character(),
  stringsAsFactors = FALSE
)

# Independently rehash the complete frozen code closure.
code_manifest <- utils::read.delim(
  file.path(work_dir, "charls_actual_keys_mi_code_manifest_v45_1.tsv"),
  stringsAsFactors = FALSE, check.names = FALSE
)
code_current <- identical(
  names(code_manifest),
  c("asset_id", "path_alias", "bytes", "sha256", "status")
) && all(vapply(seq_len(nrow(code_manifest)), function(index) {
  path <- file.path(root, code_manifest$path_alias[[index]])
  file.exists(path) && !dir.exists(path) && !nzchar(Sys.readlink(path)) &&
    as.numeric(file.info(path)$size) ==
      as.numeric(code_manifest$bytes[[index]]) &&
    identical(sha256(path), as.character(code_manifest$sha256[[index]]))
}, logical(1)))
checks <- add_check(
  checks, "frozen_code_closure_rehashed", code_current,
  paste0(sum(vapply(seq_len(nrow(code_manifest)), function(index) {
    path <- file.path(root, code_manifest$path_alias[[index]])
    file.exists(path) &&
      identical(sha256(path), as.character(code_manifest$sha256[[index]]))
  }, logical(1))), "/", nrow(code_manifest)),
  "all frozen code assets exact"
)
if (!code_current) stop("The frozen CHARLS validator closure drifted.", call. = FALSE)

output_manifest <- utils::read.delim(
  file.path(result_dir, "charls_actual_keys_mi_output_manifest_v45_1.tsv"),
  stringsAsFactors = FALSE, check.names = FALSE
)
output_current <- all(output_manifest$validation_status == "PASS") &&
  all(vapply(seq_len(nrow(output_manifest)), function(index) {
    path <- file.path(root, output_manifest$path_alias[[index]])
    file.exists(path) && !dir.exists(path) &&
      as.numeric(file.info(path)$size) ==
        as.numeric(output_manifest$bytes[[index]]) &&
      identical(sha256(path), as.character(output_manifest$sha256[[index]]))
  }, logical(1)))
checks <- add_check(
  checks, "runner_output_manifest_rehashed", output_current,
  paste0(nrow(output_manifest), "/", nrow(output_manifest)),
  "all runner outputs exact before independent reconstruction"
)
if (!output_current) stop("The runner output bundle drifted.", call. = FALSE)

# Open only the two Stage0-authorized restricted sources.
ledger_path <- file.path(
  root, "derived_sensitive/v43/charls_stage3_analysis_ledger_v43.rds"
)
donor_path <- file.path(
  root, "derived_sensitive/charls/charls_core_harmonized_provisional.rds"
)
source_exact <- as.numeric(file.info(ledger_path)$size) ==
    as.numeric(spec$restricted_sources$stage3_ledger$expected_bytes) &&
  identical(
    sha256(ledger_path),
    as.character(spec$restricted_sources$stage3_ledger$expected_sha256)
  ) &&
  as.numeric(file.info(donor_path)$size) ==
    as.numeric(spec$restricted_sources$w1_weight_donor$expected_bytes) &&
  identical(
    sha256(donor_path),
    as.character(spec$restricted_sources$w1_weight_donor$expected_sha256)
  )
if (!source_exact) stop("A restricted CHARLS source drifted.", call. = FALSE)
ledger <- readRDS(ledger_path)
donor_source <- readRDS(donor_path)
master <- as.data.frame(ledger$person_master, stringsAsFactors = FALSE)
period <- as.data.frame(
  ledger$person_period_skeleton, stringsAsFactors = FALSE
)
donor <- as.data.frame(
  donor_source[c("participant_id", "weight_kg_w1")],
  stringsAsFactors = FALSE
)
rm(donor_source)
donor_index <- match(master$participant_id, donor$participant_id)
id_join_ok <- !anyDuplicated(master$participant_id) &&
  !anyDuplicated(donor$participant_id) && !anyNA(donor_index)
if (!id_join_ok) stop("The independent source-key join failed.", call. = FALSE)
weight_kg_w1 <- suppressWarnings(
  as.numeric(donor$weight_kg_w1[donor_index])
)
checks <- add_check(
  checks, "restricted_sources_and_two_field_join", source_exact && id_join_ok,
  paste0("master=", nrow(master), "; donor_fields=2; unmatched=", sum(is.na(donor_index))),
  "exact source hashes; unique complete two-field join"
)

# Independent denominator reconstruction.
valid <- function(x) is.finite(x) & x >= 30 & x <= 890
complete_three <- valid(master$pef_w1_trial1) &
  valid(master$pef_w1_trial2) &
  valid(master$pef_w1_trial3)
adjacent_row <- period$end_wave - period$start_wave == 1L
adjacent_ids <- unique(period$participant_id[adjacent_row])
post_w2_rows <- period$start_wave >= 2L
post_w2_ids <- unique(period$participant_id[post_w2_rows])
w2_initial <- master$known_alive_w2 == 1L &
  master$participant_id %in% post_w2_ids
r_w2 <- valid(master$pef_w2_rowmax)
response_by_psu <- tapply(
  r_w2[w2_initial], as.character(master$community_id[w2_initial]), sum
)
zero_keys <- names(response_by_psu)[response_by_psu == 0]
supported_keys <- names(response_by_psu)[response_by_psu > 0]
w2_supported <- w2_initial &
  as.character(master$community_id) %in% supported_keys
trial_period <- period[
  period$participant_id %in% master$participant_id[complete_three],
  ,
  drop = FALSE
]
denominator_values <- c(
  trial_n = sum(complete_three),
  trial_death = sum(master$event_any[complete_three]),
  trial_rows = nrow(trial_period),
  trial_psu = length(unique(master$community_id[complete_three])),
  adjacent_n = length(adjacent_ids),
  adjacent_death = sum(period$period_event[adjacent_row]),
  adjacent_rows = sum(adjacent_row),
  adjacent_psu = length(unique(period$community_id[adjacent_row])),
  w2_initial_n = sum(w2_initial),
  w2_initial_psu = length(unique(master$community_id[w2_initial])),
  w2_response = sum(r_w2[w2_initial]),
  w2_zero_psu = length(zero_keys),
  w2_zero_people = sum(
    w2_initial & as.character(master$community_id) %in% zero_keys
  ),
  w2_supported_n = sum(w2_supported),
  w2_supported_psu = length(unique(master$community_id[w2_supported])),
  w2_supported_response = sum(r_w2[w2_supported]),
  w2_supported_nonresponse = sum(!r_w2[w2_supported])
)
expected_denominator_values <- c(
  12512, 1722, 45358, 433,
  12427, 1539, 44778, 432,
  11981, 432, 8308, 12, 112,
  11869, 420, 8308, 3561
)
denominator_ok <- identical(
  unname(as.numeric(denominator_values)),
  as.numeric(expected_denominator_values)
)
checks <- add_check(
  checks, "independent_denominator_reconstruction", denominator_ok,
  paste(denominator_values, collapse = "|"),
  paste(expected_denominator_values, collapse = "|")
)
if (!denominator_ok) stop("Independent denominator anchors failed.", call. = FALSE)

contract <- readRDS(restricted_path)
forbidden_object_names <- c(
  "completed_data", "completed_datasets", "mids",
  "coefficient_vector", "coefficient_vectors",
  "propensity_scores", "individual_propensity",
  "availability_weights", "individual_availability_weights"
)
storage_ok <- !any(tolower(names(contract)) %in% forbidden_object_names) &&
  identical(contract$completed_data_persisted, FALSE) &&
  identical(contract$mids_persisted, FALSE) &&
  identical(contract$response_model_fit_count, 0L) &&
  identical(contract$outcome_model_fit_count, 0L) &&
  identical(contract$pef_model_fit_count, 0L) &&
  identical(contract$coefficient_export_count, 0L)
checks <- add_check(
  checks, "restricted_contract_excludes_forbidden_objects", storage_ok,
  "completed/mids/models/coefficients absent; all fit/export counts 0",
  "no persisted completed data, mids, fitted model, propensity or coefficient"
)

sort_keys <- function(x) {
  sort(unique(enc2utf8(as.character(x))), method = "radix")
}
independent_key_maps <- list(
  trial = data.frame(
    module_id = "RW-CHARLS-TRIAL-ACTUAL",
    stratum_key = "CHARLS_SINGLE_STRATUM",
    psu_ordinal = seq_along(sort_keys(master$community_id[complete_three])),
    community_id = sort_keys(master$community_id[complete_three]),
    stringsAsFactors = FALSE
  ),
  adjacent = data.frame(
    module_id = "RW-CHARLS-ADJACENT-ACTUAL",
    stratum_key = "CHARLS_SINGLE_STRATUM",
    psu_ordinal = seq_along(sort_keys(master$community_id)),
    community_id = sort_keys(master$community_id),
    stringsAsFactors = FALSE
  ),
  w2 = data.frame(
    module_id = "RW-CHARLS-W2-IPW-ACTUAL",
    stratum_key = "CHARLS_SINGLE_STRATUM",
    psu_ordinal = seq_along(sort_keys(master$community_id[w2_supported])),
    community_id = sort_keys(master$community_id[w2_supported]),
    stringsAsFactors = FALSE
  )
)
key_ok <- identical(independent_key_maps, contract$key_maps)
checks <- add_check(
  checks, "actual_key_maps_reconstructed", key_ok,
  "433|433|420 actual PSU keys; one structural stratum",
  "exact restricted key maps"
)

independent_participant_map <- data.frame(
  participant_id = as.character(master$participant_id),
  community_id = as.character(master$community_id),
  base_weight = as.numeric(master$weight_biomarker_w1),
  trial_complete_three = complete_three,
  adjacent_participant = master$participant_id %in% adjacent_ids,
  w2_initial = w2_initial,
  D2_support = w2_supported,
  R_W2 = r_w2,
  stringsAsFactors = FALSE
)
independent_period_map <- data.frame(
  participant_id = as.character(period$participant_id),
  community_id = as.character(period$community_id),
  start_wave = as.integer(period$start_wave),
  end_wave = as.integer(period$end_wave),
  nominal_years = as.numeric(period$nominal_years),
  adjacent_transition = adjacent_row,
  stringsAsFactors = FALSE
)
mapping_ok <- identical(
  independent_participant_map, contract$participant_denominator_map
) && identical(
  independent_period_map, contract$outcome_free_period_key_map
)
checks <- add_check(
  checks, "participant_and_period_mapping_reconstructed", mapping_ok,
  paste0(nrow(independent_participant_map), "|", nrow(independent_period_map)),
  "exact ID/weight/denominator and outcome-free time maps"
)

independent_matrix <- function(key_map, seed) {
  skeleton <- data.frame(
    key = factor(key_map$community_id, levels = key_map$community_id),
    weight = 1,
    stringsAsFactors = FALSE
  )
  design <- survey::svydesign(
    ids = ~key, weights = ~weight, data = skeleton, nest = TRUE
  )
  RNGkind("Mersenne-Twister", "Inversion", "Rejection")
  set.seed(as.integer(seed))
  warnings <- character()
  replicate_design <- withCallingHandlers(
    survey::as.svrepdesign(
      design, type = "subbootstrap", replicates = 500L,
      mse = TRUE, compress = TRUE
    ),
    warning = function(warning) {
      warnings <<- c(warnings, conditionMessage(warning))
      invokeRestart("muffleWarning")
    }
  )
  if (length(warnings)) stop("Independent Rao–Wu generation warned.", call. = FALSE)
  value <- unclass(replicate_design$repweights$weights)
  rownames(value) <- key_map$community_id
  colnames(value) <- sprintf("R%03d", seq_len(ncol(value)))
  list(
    matrix = value,
    index = as.integer(replicate_design$repweights$index),
    scale = as.numeric(replicate_design$scale),
    rscales = as.numeric(replicate_design$rscales),
    degf = as.integer(replicate_design$degf),
    mse = isTRUE(replicate_design$mse),
    combined = isTRUE(replicate_design$combined.weights)
  )
}
independent_modules <- list(
  trial = independent_matrix(independent_key_maps$trial, 450501L),
  adjacent = independent_matrix(independent_key_maps$adjacent, 450502L),
  w2 = independent_matrix(independent_key_maps$w2, 450504L)
)
synthetic <- readRDS(file.path(
  work_dir, "charls_structural_replicate_contract_v45_1.rds"
))
matrix_ok <- all(vapply(names(independent_modules), function(name) {
  current <- independent_modules[[name]]
  stored <- contract$modules[[name]]
  identical(current$matrix, stored$matrix) &&
    identical(current$index, stored$index) &&
    identical(current$scale, 1 / 499) &&
    identical(current$rscales, rep(1, 500L)) &&
    identical(current$degf, nrow(current$matrix) - 1L) &&
    current$mse && !current$combined &&
    all(is.finite(current$matrix) & current$matrix >= 0) &&
    max(abs(colSums(current$matrix) - nrow(current$matrix))) <= 1e-10 &&
    all(apply(current$matrix, 2L, function(column) any(column == 0))) &&
    identical(
      unname(current$matrix), unname(synthetic$modules[[name]]$matrix)
    ) &&
    identical(
      unname(current$matrix[, seq_len(250L), drop = FALSE]),
      unname(
        synthetic$modules[[name]]$matrix[, seq_len(250L), drop = FALSE]
      )
    )
}, logical(1)))
checks <- add_check(
  checks, "independent_actual_Rao_Wu_reconstruction", matrix_ok,
  "3 exact actual matrices; 500/250 exact; df 432|432|419",
  "stored and frozen-synthetic values match direct survey generation"
)

# Independently parse, but never source, the authority scripts.
extract_function <- function(path, name, environment) {
  expressions <- parse(path, keep.source = FALSE)
  matches <- list()
  for (expression in expressions) {
    if (is.call(expression) && length(expression) == 3L &&
        identical(as.character(expression[[1L]]), "<-") &&
        is.symbol(expression[[2L]]) &&
        identical(as.character(expression[[2L]]), name) &&
        is.call(expression[[3L]]) &&
        identical(as.character(expression[[3L]][[1L]]), "function")) {
      matches[[length(matches) + 1L]] <- expression[[3L]]
    }
  }
  if (length(matches) != 1L) stop("Authority function parse failed.", call. = FALSE)
  assign(name, eval(matches[[1L]], envir = environment), envir = environment)
}
v43_path <- file.path(
  root,
  paste0(
    "output/code_archive/PEF_mortality_v44_2_code_candidate/",
    "R/v43/04_charls_stage3_primary_mortality.R"
  )
)
v44_path <- file.path(
  root,
  paste0(
    "output/code_archive/PEF_mortality_v44_2_code_candidate/",
    "R/v44/05_charls_anthropometric_qc_resolution_v44_1_1.R"
  )
)
authority <- new.env(parent = globalenv())
v43_names <- c(
  "derive_smoking", "numeric_code", "apply_charls_smoking_parent_rule",
  "mice.impute.charls_smoke_now_skip_logreg_v43",
  "register_charls_smoking_imputer", "make_mi_input",
  "freeze_mi_specification", "record_category_trace_iteration",
  "completed_binary_mice_variable", "record_smoking_coherence_iteration",
  "mice_smoking_coherence_trace", "run_mi", "run_mi_checked"
)
v44_names <- c(
  "v44_constrained_weight_pmm_core", "v44_constrained_height_pmm_core",
  "mice.impute.v44_who_constrained_weight_pmm",
  "mice.impute.v44_who_constrained_height_pmm",
  "variant_catalog_v44", "clean_wave_v44",
  "make_mi_input_v44", "freeze_mi_spec_v44"
)
for (name in v43_names) extract_function(v43_path, name, authority)
for (name in v44_names) extract_function(v44_path, name, authority)
v44_spec <- yaml::read_yaml(file.path(
  root,
  paste0(
    "output/code_archive/PEF_mortality_v44_2_code_candidate/",
    "work_v44/charls_anthropometric_qc_resolution_spec_v44_1_1.yml"
  )
))
variant <- authority$variant_catalog_v44(v44_spec)[[
  "who_block_no_later_aux"
]]
clean <- authority$clean_wave_v44(
  suppressWarnings(as.numeric(master$height_m_w1)),
  weight_kg_w1,
  variant
)
clean_master <- master
clean_master$height_m_w1 <- clean$height
clean_master$weight_kg_w1 <- clean$weight
clean_master$bmi_w1 <- clean$bmi
c0_data <- authority$make_mi_input_v44(clean_master, variant)
c0_spec <- authority$freeze_mi_spec_v44(c0_data, variant, v44_spec)

post_period <- period[
  period$start_wave >= 2L &
    period$participant_id %in% master$participant_id[w2_supported],
  ,
  drop = FALSE
]
split_index <- split(seq_len(nrow(post_period)), post_period$participant_id)
supported_master <- clean_master[w2_supported, , drop = FALSE]
post_event <- integer(nrow(supported_master))
post_last <- integer(nrow(supported_master))
post_span <- numeric(nrow(supported_master))
for (index in seq_len(nrow(supported_master))) {
  rows <- split_index[[supported_master$participant_id[[index]]]]
  post_event[[index]] <- as.integer(any(post_period$period_event[rows] == 1L))
  post_last[[index]] <- max(post_period$end_wave[rows])
  post_span[[index]] <- sum(post_period$nominal_years[rows])
}
supported_master$event_any <- post_event
supported_master$last_known_followup_wave <- post_last
supported_master$total_observed_followup_span <- post_span
c2_variant <- variant
c2_variant$seed <- 450503L
c2_data <- authority$make_mi_input_v44(
  supported_master, c2_variant
)
c2_data$last_known_followup_wave <- droplevels(
  c2_data$last_known_followup_wave
)
c2_data$R_W2 <- factor(as.integer(r_w2[w2_supported]), levels = 0:1)
c2_spec <- authority$freeze_mi_spec_v44(c2_data, c2_variant, v44_spec)
c2_spec$seed <- 450503L
c2_spec$method[["R_W2"]] <- ""
c2_spec$predictor_matrix["R_W2", ] <- 0
c2_spec$w2_fixed_auxiliaries <- c(
  "R_W2", "event_any", "last_known_followup_wave", "E0",
  "log_survey_weight"
)
c2_spec$w2_pef_columns_forbidden <- TRUE
c2_spec$passive_age_w2_rule <- "age_w1 + 2"

make_contract <- function(id, data, mi_spec, passive) {
  data.frame(
    object_id = id, n = nrow(data), columns = ncol(data),
    seed = as.integer(mi_spec$seed),
    production_initial_m = as.integer(mi_spec$initial_m),
    production_maximum_m = as.integer(mi_spec$maximum_m),
    production_checkpoints =
      paste(mi_spec$convergence_iteration_checkpoints, collapse = "|"),
    active_target_n = sum(nzchar(mi_spec$method)),
    active_targets =
      paste(names(mi_spec$method)[nzchar(mi_spec$method)], collapse = "|"),
    input_sha256 = v45_canonical_data_frame_contract(data)$sha256,
    method_sha256 = v45_canonical_object_sha256(mi_spec$method),
    predictor_sha256 =
      v45_canonical_array_sha256(mi_spec$predictor_matrix),
    where_sha256 = v45_canonical_array_sha256(is.na(data)),
    visit_sha256 =
      v45_canonical_object_sha256(mi_spec$visit_sequence),
    missingness_sha256 = v45_canonical_object_sha256(
      vapply(data, function(value) sum(is.na(value)), integer(1))
    ),
    passive_sha256 = v45_canonical_object_sha256(passive),
    pef_imputation_target_n = sum(
      nzchar(mi_spec$method) &
        grepl(
          "(^|_)pef|E0_W2|M12|D12",
          names(mi_spec$method), ignore.case = TRUE
        )
    ),
    status = "PASS",
    stringsAsFactors = FALSE
  )
}
c0_passive <- c(
  bmi_w1 = "weight_kg_w1 / height_m_w1^2",
  height_basis = "rebuild_after_completed_height"
)
c2_passive <- c(
  bmi_w1 = "weight_kg_w1 / height_m_w1^2",
  age_w2_model = "age_w1 + 2",
  height_basis = "rebuild_after_completed_height"
)
independent_object_contracts <- rbind(
  make_contract("MI-C0", c0_data, c0_spec, c0_passive),
  make_contract("MI-C2", c2_data, c2_spec, c2_passive)
)
runner_object_contracts <- utils::read.delim(
  file.path(result_dir, "charls_mi_object_contracts_v45_1.tsv"),
  stringsAsFactors = FALSE, check.names = FALSE
)
object_ok <- identical(
  independent_object_contracts, runner_object_contracts
) && identical(c0_spec$method, contract$MI_definitions$MI_C0$method) &&
  identical(
    c0_spec$predictor_matrix,
    contract$MI_definitions$MI_C0$predictor_matrix
  ) &&
  identical(c2_spec$method, contract$MI_definitions$MI_C2$method) &&
  identical(
    c2_spec$predictor_matrix,
    contract$MI_definitions$MI_C2$predictor_matrix
  ) &&
  !any(grepl("pef_w2|E0_W2|M12|D12", names(c2_data), ignore.case = TRUE))
checks <- add_check(
  checks, "independent_MI_C0_MI_C2_object_reconstruction", object_ok,
  paste(independent_object_contracts$input_sha256, collapse = "|"),
  "exact input/method/predictor/where/visit/missingness/passive hashes"
)

register_v44 <- function() {
  names <- c(
    "mice.impute.v44_who_constrained_weight_pmm",
    "mice.impute.v44_who_constrained_height_pmm"
  )
  existed <- vapply(
    names, exists, logical(1), envir = .GlobalEnv, inherits = FALSE
  )
  previous <- lapply(names, function(name) {
    if (exists(name, envir = .GlobalEnv, inherits = FALSE)) {
      get(name, envir = .GlobalEnv, inherits = FALSE)
    } else NULL
  })
  for (name in names) {
    assign(name, authority[[name]], envir = .GlobalEnv)
  }
  function() {
    for (index in seq_along(names)) {
      if (existed[[index]]) {
        assign(names[[index]], previous[[index]], envir = .GlobalEnv)
      } else if (exists(names[[index]], envir = .GlobalEnv, inherits = FALSE)) {
        rm(list = names[[index]], envir = .GlobalEnv)
      }
    }
  }
}
equal_observed <- function(original, completed) {
  all(vapply(names(original), function(name) {
    observed <- !is.na(original[[name]])
    if (!any(observed)) return(TRUE)
    if (is.factor(original[[name]])) {
      identical(
        as.character(original[[name]][observed]),
        as.character(completed[[name]][observed])
      ) && identical(levels(original[[name]]), levels(completed[[name]]))
    } else if (is.numeric(original[[name]])) {
      identical(
        as.numeric(original[[name]][observed]),
        as.numeric(completed[[name]][observed])
      )
    } else {
      identical(
        original[[name]][observed], completed[[name]][observed]
      )
    }
  }, logical(1)))
}
dry_once <- function(id, data, mi_spec) {
  restore <- register_v44()
  on.exit(restore(), add = TRUE)
  warnings <- character()
  imp <- withCallingHandlers(
    authority$run_mi_checked(data, mi_spec, m = 2L, maxit = 2L),
    warning = function(warning) {
      warnings <<- c(warnings, conditionMessage(warning))
      invokeRestart("muffleWarning")
    }
  )
  logged <- if (is.null(imp$loggedEvents)) 0L else nrow(imp$loggedEvents)
  hashes <- character(imp$m)
  passive_ok <- TRUE
  for (chain in seq_len(imp$m)) {
    completed <- mice::complete(imp, chain)
    passive_ok <- passive_ok && equal_observed(data, completed)
    height <- suppressWarnings(as.numeric(completed$height_m_w1))
    weight <- suppressWarnings(as.numeric(completed$weight_kg_w1))
    bmi <- weight / height^2
    ever <- suppressWarnings(as.numeric(as.character(completed$smoke_ever_w1)))
    now <- suppressWarnings(as.numeric(as.character(completed$smoke_now_w1)))
    passive_ok <- passive_ok &&
      all(is.finite(height) & height >= 1 & height <= 2.7) &&
      all(is.finite(weight) & weight >= 20 & weight <= 350) &&
      all(is.finite(bmi) & bmi >= 11 & bmi <= 75) &&
      !any(ever == 0 & now == 1)
    completed$bmi_w1 <- bmi
    if (identical(id, "MI-C2")) {
      completed$age_w2_model <-
        suppressWarnings(as.numeric(completed$age_w1)) + 2
      passive_ok <- passive_ok && max(abs(
        completed$age_w2_model -
          (suppressWarnings(as.numeric(completed$age_w1)) + 2)
      )) <= 1e-12
    }
    hashes[[chain]] <-
      v45_canonical_data_frame_contract(completed)$sha256
    rm(completed)
  }
  list(
    payload = v45_canonical_imputation_payload_sha256(imp),
    completed = hashes,
    warning_n = length(unique(warnings)),
    logged_n = logged,
    passive_ok = passive_ok
  )
}
independent_dry <- lapply(
  list(
    `MI-C0` = list(data = c0_data, spec = c0_spec),
    `MI-C2` = list(data = c2_data, spec = c2_spec)
  ),
  function(object) {
    first <- dry_once(
      if (identical(object$data, c0_data)) "MI-C0" else "MI-C2",
      object$data, object$spec
    )
    second <- dry_once(
      if (identical(object$data, c0_data)) "MI-C0" else "MI-C2",
      object$data, object$spec
    )
    list(first = first, second = second)
  }
)
runner_dry <- utils::read.delim(
  file.path(result_dir, "charls_mi_dry_pair_validation_v45_1.tsv"),
  stringsAsFactors = FALSE, check.names = FALSE
)
dry_ok <- all(vapply(names(independent_dry), function(id) {
  current <- independent_dry[[id]]
  row <- runner_dry[runner_dry$object_id == id, , drop = FALSE]
  nrow(row) == 1L &&
    identical(current$first$payload, current$second$payload) &&
    identical(current$first$completed, current$second$completed) &&
    identical(current$first$payload, as.character(row$run_A_payload_sha256)) &&
    identical(
      paste(current$first$completed, collapse = "|"),
      as.character(row$run_A_completion_sha256)
    ) &&
    current$first$warning_n + current$second$warning_n == 0L &&
    current$first$logged_n + current$second$logged_n == 0L &&
    current$first$passive_ok && current$second$passive_ok
}, logical(1)))
checks <- add_check(
  checks, "independent_MI_dry_pair_reexecution", dry_ok,
  paste(vapply(
    independent_dry, function(value) value$first$payload, character(1)
  ), collapse = "|"),
  "both objects bitwise deterministic; runner hashes exact; zero warnings/events"
)

suspicious <- list.files(
  file.path(root, "derived_sensitive/v45/charls_addendum_v45_1"),
  recursive = TRUE, full.names = FALSE
)
suspicious <- suspicious[
  grepl("(^|/)(complete|completed|mids|imp_|propensity|coefficient)",
        suspicious, ignore.case = TRUE)
]
file_boundary_ok <- !length(suspicious)
checks <- add_check(
  checks, "no_suspicious_persisted_artifacts", file_boundary_ok,
  if (length(suspicious)) paste(suspicious, collapse = "|") else "none",
  "no completed data, mids, imputation payload, propensity or coefficient file"
)

all_pass <- all(checks$status == "PASS") &&
  storage_ok && key_ok && mapping_ok && matrix_ok &&
  object_ok && dry_ok && file_boundary_ok
if (!all_pass) {
  print(checks[checks$status != "PASS", ], row.names = FALSE)
  stop("Independent CHARLS actual-key/MI validation failed.", call. = FALSE)
}

validation_path <- file.path(
  result_dir, "charls_actual_keys_mi_independent_validation_v45_1.tsv"
)
qa_path <- file.path(
  qa_dir, "CHARLS_ACTUAL_KEYS_MI_INDEPENDENT_QA_v45_1.md"
)
qa_lines <- c(
  "# CHARLS v45.1 independent actual-key/MI validation",
  "",
  paste0("Validated: ", format(Sys.time(), tz = "UTC", usetz = TRUE)),
  "",
  "## Decision",
  "",
  "PASS. Actual trial, shared adjacent, and W2 community keys were reconstructed directly from the two content-addressed restricted sources. All three 500-column Rao–Wu matrices and their literal 250-column prefixes matched both the restricted contract and the earlier synthetic value matrices exactly.",
  "",
  "MI-C0 and MI-C2 input, method, predictor, where, visit, missingness and passive-variable hashes were independently reconstructed. Both m=2/maxit=2 dry pairs were re-executed from scratch and exactly matched the runner, with zero warnings, zero logged events, no observed-value changes, exact passive BMI, and exact MI-C2 Wave-2 age.",
  "",
  "No response, PEF, or mortality model was fit; no coefficient, completed dataset, mids object, individual propensity, or availability weight was persisted. CHARLS production MI may now be separately frozen. Outcome execution and coefficient inspection remain disabled.",
  "",
  paste(capture.output(print(checks, row.names = FALSE)), collapse = "\n")
)
v45_charls_atomic_write_tsv(checks, validation_path)
v45_charls_atomic_write_lines(qa_lines, qa_path)
independent_manifest <- data.frame(
  asset_id = c("independent_validation", "independent_QA"),
  path_alias = c(
    "results/v45/charls_addendum_v45_1/charls_actual_keys_mi_independent_validation_v45_1.tsv",
    "output/qa/v45/charls_addendum_v45_1/CHARLS_ACTUAL_KEYS_MI_INDEPENDENT_QA_v45_1.md"
  ),
  bytes = c(
    as.numeric(file.info(validation_path)$size),
    as.numeric(file.info(qa_path)$size)
  ),
  sha256 = c(sha256(validation_path), sha256(qa_path)),
  validation_status = "PASS",
  stringsAsFactors = FALSE
)
v45_charls_atomic_write_tsv(
  independent_manifest,
  file.path(
    result_dir,
    "charls_actual_keys_mi_independent_output_manifest_v45_1.tsv"
  )
)

stage_gate_path <- file.path(
  work_dir, "charls_actual_keys_mi_gate_state_v45_1.yml"
)
stage_gate <- yaml::read_yaml(stage_gate_path)
stage_gate$updated_at_utc <- format(Sys.time(), tz = "UTC", usetz = TRUE)
stage_gate$actual_design_key_binding$status <- "PASS"
stage_gate$mi_c0_structural_preflight$status <- "PASS"
stage_gate$mi_c2_structural_preflight$status <- "PASS"
stage_gate$independent_validation$status <- "PASS"
stage_gate$charls_production_mi_allowed <- "yes"
stage_gate$outcome_execution_allowed <- "no"
stage_gate$new_coefficient_inspection_allowed <- "no"
stage_gate$next_authorized_step <- "freeze_CHARLS_production_MI_C0_MI_C2"
v45_charls_atomic_write_yaml(stage_gate, stage_gate_path)

parent_gate_path <- file.path(
  work_dir, "charls_addendum_gate_state_v45_1.yml"
)
parent_gate <- yaml::read_yaml(parent_gate_path)
parent_gate$updated_at_utc <- format(Sys.time(), tz = "UTC", usetz = TRUE)
parent_gate$actual_design_key_binding$status <- "PASS"
parent_gate$mi_c0_structural_preflight <- list(status = "PASS")
parent_gate$mi_c2_structural_preflight <- list(status = "PASS")
parent_gate$actual_keys_mi_independent_validation <- list(status = "PASS")
parent_gate$charls_production_mi_allowed <- "yes"
parent_gate$outcome_execution_allowed <- "no"
parent_gate$new_coefficient_inspection_allowed <- "no"
parent_gate$next_authorized_step <- "freeze_CHARLS_production_MI_C0_MI_C2"
v45_charls_atomic_write_yaml(parent_gate, parent_gate_path)

cat("CHARLS ACTUAL-KEY/MI INDEPENDENT VALIDATION PASS\n")
