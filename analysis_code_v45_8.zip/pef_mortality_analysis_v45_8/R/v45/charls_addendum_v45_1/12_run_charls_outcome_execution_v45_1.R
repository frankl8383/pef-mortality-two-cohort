#!/usr/bin/env Rscript

# Execute the frozen CHARLS v45.1 outcome addendum.
#
# Governance boundary
# -------------------
# This file defines functions without fitting a model.  Its main execution
# path first verifies the coefficient-blind outcome freeze, the independently
# validated MI-C0/MI-C2 pointers, and every bound input hash.  Coefficient-
# bearing objects are written only to derived_sensitive.  Public state files
# contain module status, path aliases, and hashes, never coefficients,
# directions, individual weights, completed data, or fitted model objects.
#
# Prefix/full boundary
# --------------------
# Every replicate module first executes literal columns R001:R250.  A full
# module is permitted to execute only R251:R500 and must concatenate the
# verified prefix object in literal order.  Failed columns are never replaced;
# variance and covariance after a common failure mask use 1/(B_valid - 1).

options(stringsAsFactors = FALSE, warn = 2)

v45c_runner_root <- function() {
  args <- commandArgs(trailingOnly = FALSE)
  file_arg <- grep("^--file=", args, value = TRUE)
  if (!length(file_arg)) {
    return(normalizePath(getwd(), mustWork = TRUE))
  }
  script <- sub("^--file=", "", file_arg[[1L]])
  normalizePath(
    file.path(dirname(script), "..", "..", ".."),
    mustWork = TRUE
  )
}

v45c_arg_value <- function(args, prefix, default = NULL) {
  hit <- grep(paste0("^", prefix, "="), args, value = TRUE)
  if (!length(hit)) return(default)
  sub(paste0("^", prefix, "="), "", tail(hit, 1L))
}

v45c_yes <- function(value) {
  isTRUE(value) ||
    (length(value) == 1L && !is.na(value) &&
       tolower(as.character(value)) %in% c("yes", "true", "1"))
}

v45c_no <- function(value) {
  identical(value, FALSE) ||
    (length(value) == 1L && !is.na(value) &&
       tolower(as.character(value)) %in% c("no", "false", "0"))
}

v45c_safe_alias <- function(root, alias, allowed_prefix, regular = TRUE) {
  if (length(alias) != 1L || is.na(alias) || !nzchar(alias) ||
      startsWith(alias, "/")) {
    stop("Unsafe path alias.", call. = FALSE)
  }
  pieces <- strsplit(alias, "/", fixed = TRUE)[[1L]]
  if (any(pieces %in% c("", ".", ".."))) {
    stop("Unsafe path alias component.", call. = FALSE)
  }
  path <- file.path(root, alias)
  if (regular && (!file.exists(path) || dir.exists(path) ||
                  nzchar(Sys.readlink(path)))) {
    stop("Bound regular file is absent or unsafe: ", alias, call. = FALSE)
  }
  if (!regular && !dir.exists(path)) {
    stop("Bound directory is absent: ", alias, call. = FALSE)
  }
  resolved <- normalizePath(path, mustWork = TRUE)
  allowed <- normalizePath(
    file.path(root, allowed_prefix), mustWork = TRUE
  )
  if (!identical(resolved, allowed) &&
      !startsWith(resolved, paste0(allowed, .Platform$file.sep))) {
    stop("Path alias escapes its permitted root: ", alias, call. = FALSE)
  }
  resolved
}

v45c_literal_replicate_names <- function(indices) {
  indices <- as.integer(indices)
  if (!length(indices) || anyNA(indices) ||
      any(indices < 1L | indices > 500L) || anyDuplicated(indices)) {
    stop("Invalid replicate indices.", call. = FALSE)
  }
  sprintf("R%03d", indices)
}

v45c_concat_prefix <- function(prefix, suffix) {
  if (!is.matrix(prefix) || !is.matrix(suffix) ||
      ncol(prefix) != ncol(suffix) ||
      !identical(colnames(prefix), colnames(suffix)) ||
      !identical(rownames(prefix), v45c_literal_replicate_names(1:250)) ||
      !identical(rownames(suffix), v45c_literal_replicate_names(251:500))) {
    stop("Literal prefix/suffix replicate identity failed.", call. = FALSE)
  }
  out <- rbind(prefix, suffix)
  if (!identical(rownames(out), v45c_literal_replicate_names(1:500))) {
    stop("Full replicate concatenation changed literal order.",
         call. = FALSE)
  }
  out
}

v45c_gate_three_level <- function(value, go, stop) {
  if (!is.numeric(value) || length(value) != 1L || !is.finite(value)) {
    return("STOP")
  }
  if (isTRUE(stop(value))) return("STOP")
  if (isTRUE(go(value))) return("GO")
  "CAUTION"
}

v45c_valid_fraction_gate <- function(value) {
  v45c_gate_three_level(
    value,
    go = function(x) x >= 0.95,
    stop = function(x) x < 0.90
  )
}

v45c_common_replicate_covariance <- function(
    point, replicates, valid = NULL) {
  point <- as.numeric(point)
  names(point) <- colnames(replicates)
  if (!is.matrix(replicates) || !length(point) ||
      ncol(replicates) != length(point) ||
      is.null(colnames(replicates)) ||
      any(!is.finite(point))) {
    stop("Invalid point/replicate covariance input.", call. = FALSE)
  }
  finite_rows <- apply(replicates, 1L, function(x) all(is.finite(x)))
  if (is.null(valid)) {
    valid <- finite_rows
  } else {
    valid <- as.logical(valid)
    if (length(valid) != nrow(replicates) || anyNA(valid)) {
      stop("Invalid explicit common failure mask.", call. = FALSE)
    }
    valid <- valid & finite_rows
  }
  valid_n <- sum(valid)
  valid_fraction <- valid_n / nrow(replicates)
  covariance <- matrix(
    NA_real_, nrow = length(point), ncol = length(point),
    dimnames = list(colnames(replicates), colnames(replicates))
  )
  if (valid_n >= 2L) {
    centered <- sweep(
      replicates[valid, , drop = FALSE], 2L, point, FUN = "-"
    )
    covariance <- crossprod(centered) / (valid_n - 1L)
    covariance <- (covariance + t(covariance)) / 2
  }
  list(
    covariance = covariance,
    valid = valid,
    valid_n = valid_n,
    valid_fraction = valid_fraction,
    gate = v45c_valid_fraction_gate(valid_fraction),
    denominator = if (valid_n >= 2L) valid_n - 1L else NA_integer_,
    nominal_n = nrow(replicates)
  )
}

v45c_w2_normalize_factor <- function(
    raw_factor, respondent, current_base_weight) {
  respondent <- as.logical(respondent)
  current_base_weight <- as.numeric(current_base_weight)
  raw_factor <- as.numeric(raw_factor)
  if (anyNA(respondent) ||
      length(respondent) != length(current_base_weight) ||
      length(raw_factor) != sum(respondent)) {
    stop(
      "Same-column W2 normalization interface is invalid.",
      call. = FALSE
    )
  }
  target_total <- sum(current_base_weight)
  respondent_total <- sum(current_base_weight[respondent])
  weighted_factor_total <- sum(
    current_base_weight[respondent] * raw_factor
  )
  if (any(!is.finite(current_base_weight) |
          current_base_weight < 0) ||
      !is.finite(target_total) || target_total <= 0 ||
      !is.finite(respondent_total) || respondent_total <= 0 ||
      any(!is.finite(raw_factor) | raw_factor <= 0) ||
      !is.finite(weighted_factor_total) ||
      weighted_factor_total <= 0) {
    v45c_numeric_failure(
      "Same-column W2 normalization lacks finite positive support.",
      "W2_NORMALIZATION_SUPPORT"
    )
  }
  multiplier <- target_total / weighted_factor_total
  out <- raw_factor * multiplier
  if (!is.finite(multiplier) || multiplier <= 0 ||
      any(!is.finite(out) | out <= 0)) {
    v45c_numeric_failure(
      "Same-column W2 normalization multiplier is invalid.",
      "W2_NORMALIZATION_NUMERIC"
    )
  }
  if (!isTRUE(all.equal(
    sum(current_base_weight[respondent] * out),
    target_total,
    tolerance = 1e-12, check.attributes = FALSE
  ))) {
    v45c_numeric_failure(
      "W2 availability factor failed same-column normalization.",
      "W2_NORMALIZATION_IDENTITY"
    )
  }
  out
}

v45c_static_self_test <- function() {
  prefix <- matrix(
    seq_len(250L * 2L), ncol = 2L,
    dimnames = list(v45c_literal_replicate_names(1:250), c("a", "b"))
  )
  suffix <- matrix(
    seq_len(250L * 2L), ncol = 2L,
    dimnames = list(v45c_literal_replicate_names(251:500), c("a", "b"))
  )
  joined <- v45c_concat_prefix(prefix, suffix)
  point <- c(a = 1, b = 2)
  reps <- rbind(
    c(a = 2, b = 2),
    c(a = 1, b = 4),
    c(a = 0, b = 0),
    c(a = NA, b = 2)
  )
  cov <- v45c_common_replicate_covariance(point, reps)
  centered <- sweep(reps[1:3, , drop = FALSE], 2L, point, "-")
  expected_cov <- crossprod(centered) / 2
  synthetic_prefix_group <- v45c_make_group(
    "SYNTHETIC_PREFIX_FULL", point, prefix, 10,
    rep("", nrow(prefix)), compute_covariance = FALSE
  )
  synthetic_full_group <- v45c_extend_group(
    synthetic_prefix_group, suffix, rep("", nrow(suffix))
  )
  respondent <- c(TRUE, FALSE, TRUE, FALSE)
  base <- c(2, 0, 5, 7)
  normalized <- v45c_w2_normalize_factor(
    c(2, 4), respondent, base
  )
  w2_normalization_failure <- tryCatch(
    v45c_w2_normalize_factor(
      c(Inf, 4), respondent, base
    ),
    v45c_numeric_failure = function(error) error
  )
  cesd_boundary <- cut(
    c(0, 9, 10, 19, 20, 30),
    breaks = c(0, 10, 20, Inf),
    right = FALSE, include.lowest = TRUE,
    labels = c("0-9", "10-19", "20-30")
  )
  current_pointer_example <- data.frame(
    run_id = "charls_v45_1_outcome_m50_20260725T010203_pid123",
    state_path_alias = "results/v45/x/module_state.tsv",
    state_sha256 = paste(rep("a", 64), collapse = ""),
    freeze_contract_sha256 = paste(rep("b", 64), collapse = ""),
    coefficient_visibility = "RESTRICTED",
    independent_validation_status = "NOT_RUN",
    stringsAsFactors = FALSE
  )
  current_pointer_valid <- tryCatch({
    v45c_validate_existing_current_pointer(
      current_pointer_example,
      current_pointer_example$run_id[[1L]],
      current_pointer_example$state_path_alias[[1L]],
      current_pointer_example$state_sha256[[1L]],
      current_pointer_example$freeze_contract_sha256[[1L]]
    )
    TRUE
  }, error = function(error) FALSE)
  current_pointer_bad_hash_blocked <- inherits(tryCatch(
    v45c_validate_existing_current_pointer(
      current_pointer_example,
      current_pointer_example$run_id[[1L]],
      current_pointer_example$state_path_alias[[1L]],
      paste(rep("c", 64), collapse = ""),
      current_pointer_example$freeze_contract_sha256[[1L]]
    ),
    error = function(error) error
  ), "error")
  completed_stop_blocked <- inherits(tryCatch(
    v45c_assert_completed_module_gate(
      "trial-prefix", list(prefix_gate = "STOP")
    ),
    error = function(error) error
  ), "error")
  completed_nonestimable_full_blocked <- inherits(tryCatch(
    v45c_assert_completed_module_gate(
      "trial-full",
      list(
        full_gate = "GO",
        pooling_status = "NOT_ESTIMABLE_WITH_REASON"
      )
    ),
    error = function(error) error
  ), "error")
  paired_row <- data.frame(
    analysis_id = "v45_c_trial_mean_minus_max",
    row_type = "paired_contrast",
    formula_id = "F_TRIAL_L100_A1",
    focal_terms = "beta_mean;beta_max",
    contrast_id = "beta_mean_minus_beta_max",
    stringsAsFactors = FALSE
  )
  paired_contract <- list(contrast_contract = list(
    trial_component_exposures = list(
      beta_mean_minus_beta_max = c("L100_mean", "L100_max")
    )
  ))
  paired_components <- v45c_formula_components_from_registry_row(
    paired_row, paired_contract
  )
  adjacent_row <- data.frame(
    analysis_id = "v45_c_adjacent_delta",
    row_type = "paired_contrast",
    formula_id = "F_ADJACENT_E0_A1",
    focal_terms = "beta_adjacent;beta_all",
    contrast_id = "beta_adjacent_minus_beta_all",
    stringsAsFactors = FALSE
  )
  adjacent_components <- v45c_formula_components_from_registry_row(
    adjacent_row, paired_contract
  )
  interrupted_state <- v45c_state_template()
  interrupted_state$status[
    interrupted_state$module == "trial-prefix"
  ] <- "RUNNING"
  interrupted_state_valid <- tryCatch({
    v45c_validate_interrupted_state(
      interrupted_state,
      "charls_v45_1_outcome_m50_20260725T010203_pid123",
      paste0(
        "results/v45/charls_addendum_v45_1/outcome_execution/",
        "charls_v45_1_outcome_m50_20260725T010203_pid123/",
        "module_state.tsv"
      )
    )
    TRUE
  }, error = function(error) FALSE)
  noninterrupted_state_blocked <- inherits(tryCatch(
    v45c_validate_interrupted_state(
      v45c_state_template(),
      "charls_v45_1_outcome_m50_20260725T010203_pid123",
      paste0(
        "results/v45/charls_addendum_v45_1/outcome_execution/",
        "charls_v45_1_outcome_m50_20260725T010203_pid123/",
        "module_state.tsv"
      )
    ),
    error = function(error) error
  ), "error")
  stale_owner <- data.frame(
    run_id = "charls_v45_1_outcome_m50_20260725T010203_pid123",
    pid = 123L,
    acquired_at_utc = "2026-07-25T01:02:03Z",
    stringsAsFactors = FALSE
  )
  stale_owner_valid <- tryCatch({
    identical(
      v45c_validate_stale_lock_owner(
        stale_owner, stale_owner$run_id[[1L]]
      ),
      123L
    )
  }, error = function(error) FALSE)
  stale_owner_mismatch_blocked <- inherits(tryCatch(
    v45c_validate_stale_lock_owner(
      stale_owner,
      "charls_v45_1_outcome_m50_20260725T010203_pid124"
    ),
    error = function(error) error
  ), "error")
  scalar_pool_failure <- tryCatch(
    v45c_pool_scalar(
      c(1, 2), c(0, 0), 10,
      "synthetic_scalar"
    ),
    v45c_numeric_failure = function(error) error
  )
  covariance_pool_failure <- tryCatch(
    v45c_require_spd_matrix(
      matrix(c(1, 1, 1, 1), 2L),
      "synthetic_covariance"
    ),
    v45c_numeric_failure = function(error) error
  )
  scalar_pool_success <- v45c_pool_scalar(
    c(1, 1.1, 0.9), c(0.2, 0.21, 0.19), 10,
    "synthetic_scalar_success"
  )
  multivariate_pool_success <- v45c_pool_multivariate(
    matrix(
      c(0.10, 0.20, 0.15, 0.25, 0.12, 0.18),
      nrow = 3L, byrow = TRUE
    ),
    rep(list(diag(c(0.10, 0.12))), 3L),
    "synthetic_multivariate_success"
  )
  quiet_log <- function(text) invisible(NULL)
  registered_parallel_failure <- tryCatch(
    v45c_parallel_map(
      1:3,
      function(index) {
        if (index == 2L) {
          v45c_numeric_failure(
            "Synthetic registered point-support failure.",
            "SYNTHETIC_POINT_SUPPORT"
          )
        }
        index
      },
      workers = 1L,
      label = "synthetic registered point",
      append_log = quiet_log
    ),
    v45c_registered_stage_stop = function(error) error
  )
  unknown_parallel_failure <- tryCatch(
    v45c_parallel_map(
      1:3,
      function(index) {
        if (index == 2L) {
          stop(
            "Synthetic unknown implementation error.",
            call. = FALSE
          )
        }
        index
      },
      workers = 1L,
      label = "synthetic unknown implementation",
      append_log = quiet_log
    ),
    error = function(error) error
  )
  mixed_parallel_failure <- tryCatch(
    v45c_parallel_map(
      1:3,
      function(index) {
        if (index == 1L) {
          v45c_numeric_failure(
            "Synthetic registered failure in mixed batch.",
            "SYNTHETIC_POINT_SUPPORT"
          )
        }
        if (index == 2L) {
          stop(
            "Synthetic unknown failure in mixed batch.",
            call. = FALSE
          )
        }
        index
      },
      workers = 1L,
      label = "synthetic mixed implementation",
      append_log = quiet_log
    ),
    error = function(error) error
  )
  synthetic_point_failure_object <- v45c_point_failure_object(
    module = "trial-prefix",
    object_id = "MI-C0",
    is_prefix = TRUE,
    is_full = FALSE,
    replicate_indices = seq_len(250L),
    prefix_sha256 = NA_character_,
    failure = registered_parallel_failure
  )
  w2_point_diagnostic_stop <- tryCatch(
    v45c_require_w2_point_diagnostic(
      data.frame(
        overall_status = "STOP",
        stringsAsFactors = FALSE
      ),
      1L
    ),
    v45c_registered_stage_stop = function(error) error
  )
  synthetic_w2_diagnostic <- v45c_w2_diagnostics(
    probability = rep(0.5, 100L),
    respondent = rep(c(TRUE, FALSE), 50L),
    current_base_weight = rep(1, 100L),
    balance_matrix = cbind(
      constant_column = rep(1, 100L),
      varying_column = rep(c(0, 1), 50L)
    )
  )$compact
  synthetic_named_balance <- v45c_named_balance_matrix(list(
    matrix = unname(cbind(
      `(Intercept)` = rep(1, 4),
      balance_a = c(0, 1, 0, 1),
      balance_b = c(1, 1, 0, 0)
    )),
    matrix_names = c("(Intercept)", "balance_a", "balance_b")
  ))
  synthetic_anchor_pass_results <- lapply(
    seq_len(50L), function(index) {
      list(
        imputation = as.integer(index),
        v44_beta = 0.354509670529553,
        v45_beta = 0.354509670529553
      )
    }
  )
  synthetic_anchor_fail_results <- lapply(
    seq_len(50L), function(index) {
      list(
        imputation = as.integer(index),
        v44_beta = 0.354509670529553,
        v45_beta = 0.354509670529553 +
          if (index == 1L) 2e-8 else 0
      )
    }
  )
  synthetic_anchor_pass <- v45c_anchor_object(
    synthetic_anchor_pass_results
  )
  synthetic_anchor_fail <- v45c_anchor_object(
    synthetic_anchor_fail_results
  )
  synthetic_anchor_numeric_fail <- v45c_anchor_failure_object(
    registered_parallel_failure
  )
  synthetic_passive_bmi <- v45c_rebuild_passive_bmi(
    height_m_w1 = c(1.5, 2),
    weight_kg_w1 = c(45, 100),
    bmi_placeholder = c(0, 0),
    object_id = "SYNTHETIC"
  )
  synthetic_completed_bmi <- v45c_rebuild_completed_bmi(
    data.frame(
      height_m_w1 = c(1.5, 2),
      weight_kg_w1 = c(45, 100),
      bmi_w1 = c(0, 0),
      retained = c("a", "b"),
      stringsAsFactors = FALSE
    ),
    object_id = "SYNTHETIC V44 ANCHOR"
  )
  nonzero_bmi_placeholder_blocked <- inherits(tryCatch(
    v45c_rebuild_passive_bmi(
      height_m_w1 = c(1.5, 2),
      weight_kg_w1 = c(45, 100),
      bmi_placeholder = c(0, 1),
      object_id = "SYNTHETIC"
    ),
    error = function(error) error
  ), "error")
  point_failure_resume_blocked <- inherits(tryCatch(
    v45c_assert_completed_module_gate(
      "trial-prefix", synthetic_point_failure_object
    ),
    error = function(error) error
  ), "error")
  anchor_failure_resume_blocked <- inherits(tryCatch(
    v45c_assert_completed_module_gate(
      "anchor-point",
      list(anchor = synthetic_anchor_fail)
    ),
    error = function(error) error
  ), "error")
  canonical_module_alias <- v45c_run_alias(
    "charls_v45_1_outcome_m50_20260725T010203_pid123",
    "anchor-point"
  )
  checks <- c(
    module_contract = identical(
      v45c_allowed_modules(),
      c(
        "anchor-point",
        "trial-prefix", "trial-full",
        "inconsistency-prefix", "inconsistency-full",
        "adjacent-prefix", "adjacent-full",
        "timehet-prefix", "timehet-full",
        "W2-prefix", "W2-full", "all"
      )
    ),
    prefix_names = identical(
      rownames(prefix), sprintf("R%03d", 1:250)
    ),
    suffix_names = identical(
      rownames(suffix), sprintf("R%03d", 251:500)
    ),
    literal_full = identical(
      rownames(joined), sprintf("R%03d", 1:500)
    ),
    common_mask = identical(cov$valid, c(TRUE, TRUE, TRUE, FALSE)),
    valid_denominator = identical(cov$denominator, 2L),
    covariance = isTRUE(all.equal(
      cov$covariance, expected_cov,
      tolerance = 1e-15, check.attributes = FALSE
    )),
    named_dfcom_survives_prefix_full =
      identical(
        names(synthetic_full_group$dfcom_by_column),
        names(point)
      ) &&
      identical(
        as.numeric(synthetic_full_group$dfcom_by_column),
        rep(10, length(point))
      ) &&
      identical(
        rownames(synthetic_full_group$replicates),
        sprintf("R%03d", 1:500)
      ),
    prefix_stop_boundary =
      identical(v45c_valid_fraction_gate(0.899999), "STOP"),
    prefix_caution_boundary =
      identical(v45c_valid_fraction_gate(0.90), "CAUTION"),
    prefix_go_boundary =
      identical(v45c_valid_fraction_gate(0.95), "GO"),
    same_column_normalization = isTRUE(all.equal(
      sum(base[respondent] * normalized), sum(base),
      tolerance = 1e-12, check.attributes = FALSE
    )),
    same_column_normalization_failure_registered =
      inherits(
        w2_normalization_failure, "v45c_numeric_failure"
      ) &&
      identical(
        w2_normalization_failure$failure_class,
        "W2_NORMALIZATION_SUPPORT"
      ),
    cesd_boundary_contract = identical(
      as.character(cesd_boundary),
      c("0-9", "0-9", "10-19", "10-19", "20-30", "20-30")
    ),
    existing_current_pointer_identity = current_pointer_valid,
    existing_current_pointer_hash_fail_closed =
      current_pointer_bad_hash_blocked,
    completed_STOP_module_fail_closed = completed_stop_blocked,
    completed_nonestimable_full_fail_closed =
      completed_nonestimable_full_blocked,
    paired_component_exposure_order = identical(
      paired_components$exposures,
      c("L100_mean", "L100_max")
    ),
    paired_component_formula_count =
      identical(length(paired_components$formula_text), 2L),
    adjacent_single_real_formula =
      identical(length(adjacent_components$formula_text), 1L) &&
      grepl("\\bE0\\b", adjacent_components$formula_text) &&
      !grepl("\\bbeta_", adjacent_components$formula_text),
    synthetic_beta_formula_forbidden =
      !any(grepl("\\bbeta_", paired_components$formula_text)),
    interrupted_state_recovery_contract = interrupted_state_valid,
    noninterrupted_supersession_blocked =
      noninterrupted_state_blocked,
    stale_lock_owner_binding = stale_owner_valid,
    stale_lock_owner_mismatch_blocked =
      stale_owner_mismatch_blocked,
    full_STOP_skips_pooling = identical(
      v45c_pooling_action(TRUE, "STOP"),
      "NOT_PERFORMED_FULL_GATE_STOP"
    ),
    full_GO_authorizes_pooling = identical(
      v45c_pooling_action(TRUE, "GO"),
      "POOL"
    ),
    scalar_pool_nonestimability_classified =
      inherits(scalar_pool_failure, "v45c_numeric_failure") &&
      identical(
        scalar_pool_failure$failure_class,
        "POOL_SCALAR_NOT_ESTIMABLE"
      ),
    covariance_pool_nonestimability_classified =
      inherits(covariance_pool_failure, "v45c_numeric_failure") &&
      identical(
        covariance_pool_failure$failure_class,
        "POOL_COVARIANCE_NOT_ESTIMABLE"
      ),
    scalar_pool_success_finite =
      nrow(scalar_pool_success) == 1L &&
      all(is.finite(unlist(
        scalar_pool_success, use.names = FALSE
      ))),
    multivariate_pool_success_finite =
      is.finite(multivariate_pool_success$statistic) &&
      is.finite(multivariate_pool_success$p_value) &&
      multivariate_pool_success$p_value >= 0 &&
      multivariate_pool_success$p_value <= 1,
    registered_point_failure_classified =
      inherits(
        registered_parallel_failure,
        "v45c_registered_stage_stop"
      ) &&
      identical(
        registered_parallel_failure$failure_class,
        "SYNTHETIC_POINT_SUPPORT"
      ) &&
      identical(
        registered_parallel_failure$failure_summary,
        data.frame(
          failure_class = "SYNTHETIC_POINT_SUPPORT",
          affected_imputations = "2",
          affected_imputation_count = 1L,
          stringsAsFactors = FALSE
        )
      ),
    unknown_implementation_not_registered =
      inherits(unknown_parallel_failure, "error") &&
      !inherits(
        unknown_parallel_failure,
        "v45c_registered_stage_stop"
      ),
    mixed_unknown_failure_dominates =
      inherits(mixed_parallel_failure, "error") &&
      !inherits(
        mixed_parallel_failure,
        "v45c_registered_stage_stop"
      ),
    minimal_point_failure_contract =
      identical(
        synthetic_point_failure_object$pooling_status,
        "POINT_NOT_ESTIMABLE_WITH_REASON"
      ) &&
      identical(
        synthetic_point_failure_object$prefix_gate, "STOP"
      ) &&
      is.na(
        synthetic_point_failure_object$
          minimum_valid_replicate_fraction
      ) &&
      !length(synthetic_point_failure_object$results) &&
      !synthetic_point_failure_object$
        partial_imputation_results_retained,
    point_failure_resume_blocked =
      point_failure_resume_blocked,
    W2_point_diagnostic_STOP_registered =
      inherits(
        w2_point_diagnostic_stop,
        "v45c_registered_stage_stop"
      ) &&
      identical(
        w2_point_diagnostic_stop$failure_class,
        "W2_POINT_DIAGNOSTIC_STOP"
      ),
    W2_constant_balance_column_named =
      identical(
        synthetic_w2_diagnostic$
          structurally_constant_balance_columns,
        1L
      ) &&
      identical(
        synthetic_w2_diagnostic$
          structurally_constant_balance_column_names,
        "constant_column"
      ),
    W2_cached_balance_names_restored =
      identical(dim(synthetic_named_balance), c(4L, 2L)) &&
      identical(
        colnames(synthetic_named_balance),
        c("balance_a", "balance_b")
      ),
    anchor_PASS_contract =
      identical(synthetic_anchor_pass$gate, "PASS"),
    anchor_identity_FAIL_is_restricted_record =
      identical(synthetic_anchor_fail$gate, "FAIL") &&
      identical(
        synthetic_anchor_fail$failure_class,
        "ANCHOR_IDENTITY_MISMATCH"
      ) &&
      !nrow(synthetic_anchor_fail$failure_summary) &&
      !synthetic_anchor_fail$
        partial_imputation_results_retained &&
      synthetic_anchor_fail$
        coefficient_or_direction_in_failure_record,
    anchor_numeric_FAIL_is_minimal_record =
      identical(synthetic_anchor_numeric_fail$gate, "FAIL") &&
      !synthetic_anchor_numeric_fail$
        partial_imputation_results_retained &&
      !synthetic_anchor_numeric_fail$
        coefficient_or_direction_in_failure_record,
    zero_placeholder_passive_BMI_rebuilt =
      identical(synthetic_passive_bmi$height, c(1.5, 2)) &&
      identical(synthetic_passive_bmi$weight, c(45, 100)) &&
      identical(synthetic_passive_bmi$bmi, c(20, 25)),
    inherited_v44_anchor_receives_rebuilt_BMI =
      identical(synthetic_completed_bmi$bmi_w1, c(20, 25)) &&
      identical(synthetic_completed_bmi$retained, c("a", "b")),
    nonzero_BMI_placeholder_fail_closed =
      nonzero_bmi_placeholder_blocked,
    anchor_failure_resume_blocked =
      anchor_failure_resume_blocked,
    canonical_module_alias_has_no_empty_component =
      identical(
        canonical_module_alias,
        paste0(
          "derived_sensitive/v45/charls_addendum_v45_1/",
          "outcome_execution/m50/",
          "charls_v45_1_outcome_m50_20260725T010203_pid123/",
          "anchor_point_restricted.rds"
        )
      ) &&
      !grepl("//", canonical_module_alias, fixed = TRUE),
    run_pid_binding = identical(
      v45c_run_pid(
        "charls_v45_1_outcome_m50_20260725T010203_pid123"
      ),
      123L
    )
  )
  data.frame(
    check = names(checks),
    status = ifelse(checks, "PASS", "FAIL"),
    stringsAsFactors = FALSE
  )
}

v45c_allowed_modules <- function() {
  c(
    "anchor-point",
    "trial-prefix", "trial-full",
    "inconsistency-prefix", "inconsistency-full",
    "adjacent-prefix", "adjacent-full",
    "timehet-prefix", "timehet-full",
    "W2-prefix", "W2-full", "all"
  )
}

v45c_required_runtime_versions <- function() {
  c(
    digest = "0.6.37", dplyr = "1.1.4", mice = "3.19.0",
    survey = "4.5", yaml = "2.3.10"
  )
}

v45c_validate_runtime <- function(root) {
  structural_path <- file.path(
    root,
    "R/v45/charls_addendum_v45_1/charls_structural_utilities_v45_1.R"
  )
  source(structural_path, local = globalenv())
  v45_charls_activate_project_library(root)
  required_packages <- v45c_required_runtime_versions()
  missing <- names(required_packages)[!vapply(
    names(required_packages), requireNamespace,
    logical(1), quietly = TRUE
  )]
  observed <- setNames(vapply(
    names(required_packages), function(package) {
      if (!requireNamespace(package, quietly = TRUE)) {
        return(NA_character_)
      }
      as.character(utils::packageVersion(package))
    }, character(1)
  ), names(required_packages))
  runtime_authority <- if (
    "yaml" %in% names(required_packages) &&
      requireNamespace("yaml", quietly = TRUE)
  ) {
    yaml::read_yaml(file.path(
      root,
      paste0(
        "work_v45/charls_addendum_v45_1/",
        "charls_outcome_execution_spec_v45_1.yml"
      )
    ))$runtime
  } else {
    NULL
  }
  authority_versions <- if (
    is.list(runtime_authority$exact_package_versions)
  ) {
    setNames(
      as.character(unlist(
        runtime_authority$exact_package_versions,
        use.names = FALSE
      )),
      names(runtime_authority$exact_package_versions)
    )
  } else {
    character()
  }
  if (length(missing) ||
      !identical(as.character(getRversion()), "4.5.1") ||
      !identical(observed, required_packages) ||
      !identical(
        as.character(runtime_authority$R_version), "4.5.1"
      ) ||
      !identical(authority_versions, required_packages)) {
    stop(
      "Frozen CHARLS outcome runtime is incomplete or drifted; ",
      "required survey authority is version 4.5.",
      call. = FALSE
    )
  }
  invisible(observed)
}

v45c_sha256_file <- function(path) {
  if (!file.exists(path) || dir.exists(path) || nzchar(Sys.readlink(path))) {
    return(NA_character_)
  }
  digest::digest(path, algo = "sha256", file = TRUE)
}

v45c_atomic_write_lines <- function(lines, path) {
  dir.create(dirname(path), recursive = TRUE, showWarnings = FALSE)
  tmp <- tempfile(paste0(".", basename(path), "."), tmpdir = dirname(path))
  on.exit(if (file.exists(tmp)) unlink(tmp, force = TRUE), add = TRUE)
  writeLines(lines, tmp, useBytes = TRUE)
  if (!file.rename(tmp, path)) {
    stop("Atomic text promotion failed.", call. = FALSE)
  }
  invisible(path)
}

v45c_atomic_write_tsv <- function(data, path) {
  dir.create(dirname(path), recursive = TRUE, showWarnings = FALSE)
  tmp <- tempfile(paste0(".", basename(path), "."), tmpdir = dirname(path))
  on.exit(if (file.exists(tmp)) unlink(tmp, force = TRUE), add = TRUE)
  utils::write.table(
    data, tmp, sep = "\t", row.names = FALSE, quote = FALSE, na = ""
  )
  if (!file.rename(tmp, path)) {
    stop("Atomic TSV promotion failed.", call. = FALSE)
  }
  invisible(path)
}

v45c_atomic_save_rds <- function(value, path) {
  dir.create(dirname(path), recursive = TRUE, showWarnings = FALSE)
  tmp <- tempfile(paste0(".", basename(path), "."), tmpdir = dirname(path))
  on.exit(if (file.exists(tmp)) unlink(tmp, force = TRUE), add = TRUE)
  saveRDS(value, tmp, version = 3, compress = "xz")
  if (!file.rename(tmp, path)) {
    stop("Atomic restricted-RDS promotion failed.", call. = FALSE)
  }
  invisible(path)
}

v45c_read_tsv <- function(path) {
  utils::read.delim(
    path, stringsAsFactors = FALSE, check.names = FALSE,
    na.strings = c("", "NA")
  )
}

v45c_numeric_failure <- function(message, failure_class) {
  condition <- structure(
    list(message = as.character(message), call = NULL,
         failure_class = as.character(failure_class)),
    class = c("v45c_numeric_failure", "error", "condition")
  )
  stop(condition)
}

v45c_registered_stage_stop <- function(
    message, failure_class, failure_summary = NULL) {
  message <- as.character(message)
  failure_class <- as.character(failure_class)
  if (length(message) != 1L || is.na(message) || !nzchar(message) ||
      length(failure_class) != 1L || is.na(failure_class) ||
      !nzchar(failure_class)) {
    stop(
      "Registered stage-stop condition is malformed.",
      call. = FALSE
    )
  }
  if (!is.null(failure_summary) &&
      (!is.data.frame(failure_summary) ||
       !identical(
         names(failure_summary),
         c(
           "failure_class", "affected_imputations",
           "affected_imputation_count"
         )
       ))) {
    stop(
      "Registered stage-stop failure summary is malformed.",
      call. = FALSE
    )
  }
  condition <- structure(
    list(
      message = message,
      call = NULL,
      failure_class = failure_class,
      failure_summary = failure_summary
    ),
    class = c(
      "v45c_registered_stage_stop", "error", "condition"
    )
  )
  stop(condition)
}

v45c_registered_failure_summary <- function(
    indices, failure_classes) {
  indices <- as.integer(indices)
  failure_classes <- as.character(failure_classes)
  if (!length(indices) || length(indices) != length(failure_classes) ||
      anyNA(indices) || any(indices < 1L) ||
      anyNA(failure_classes) || any(!nzchar(failure_classes))) {
    stop(
      "Registered point-stage failure inputs are malformed.",
      call. = FALSE
    )
  }
  classes <- unique(failure_classes)
  do.call(rbind, lapply(classes, function(failure_class) {
    affected <- indices[failure_classes == failure_class]
    data.frame(
      failure_class = failure_class,
      affected_imputations = paste(affected, collapse = "|"),
      affected_imputation_count = as.integer(length(affected)),
      stringsAsFactors = FALSE
    )
  }))
}

v45c_point_failure_object <- function(
    module, object_id, is_prefix, is_full, replicate_indices,
    prefix_sha256, failure) {
  if (!inherits(failure, "v45c_registered_stage_stop") ||
      !xor(is_prefix, is_full) ||
      !is.data.frame(failure$failure_summary) ||
      nrow(failure$failure_summary) < 1L) {
    stop(
      "Minimal point-failure object received an invalid condition.",
      call. = FALSE
    )
  }
  list(
    module = module,
    mi_object = object_id,
    requested_m = 50L,
    replicate_indices = if (is_prefix) {
      seq_len(250L)
    } else {
      seq_len(500L)
    },
    requested_replicate_indices = as.integer(replicate_indices),
    executed_in_this_transaction = integer(),
    prefix_sha256 = if (is_full) {
      as.character(prefix_sha256)
    } else {
      NA_character_
    },
    literal_prefix_identity = NA,
    results = list(),
    sample_anchors = data.frame(),
    minimum_valid_replicate_fraction = NA_real_,
    prefix_gate = if (is_prefix) "STOP" else NA_character_,
    full_gate = if (is_full) "STOP" else NA_character_,
    coefficient_blind_prefix_gate = is_prefix,
    prefix_pooling_or_release_performed = FALSE,
    no_replacement_replicates = TRUE,
    variance_rule = "1/(B_valid-1)",
    common_failure_masks_preserved = TRUE,
    pooling_status = "POINT_NOT_ESTIMABLE_WITH_REASON",
    point_failure_class = failure$failure_class,
    point_failure_reason = conditionMessage(failure),
    point_failure_summary = failure$failure_summary,
    valid_fraction_assessed = FALSE,
    partial_imputation_results_retained = FALSE,
    coefficient_or_direction_in_failure_record = FALSE
  )
}

v45c_anchor_failure_object <- function(failure) {
  if (!inherits(failure, "v45c_registered_stage_stop") ||
      !is.data.frame(failure$failure_summary) ||
      nrow(failure$failure_summary) < 1L) {
    stop(
      "Minimal anchor-failure object received an invalid condition.",
      call. = FALSE
    )
  }
  list(
    gate = "FAIL",
    tolerance = 1e-8,
    failure_class = failure$failure_class,
    failure_reason = conditionMessage(failure),
    failure_summary = failure$failure_summary,
    per_imputation = data.frame(),
    computed_v44_Qbar = NA_real_,
    computed_v45_Qbar = NA_real_,
    maximum_absolute_difference = NA_real_,
    comparison_role = "point_estimate_only_sidecar_gate",
    Rao_Wu_SE_identity_required = FALSE,
    partial_imputation_results_retained = FALSE,
    coefficient_or_direction_in_failure_record = FALSE
  )
}

v45c_capture_fit <- function(expr, model_id) {
  warnings <- character()
  value <- withCallingHandlers(
    tryCatch(
      expr,
      error = function(error) {
        message <- conditionMessage(error)
        expected_numeric <- grepl(
          paste(
            "NA/NaN/Inf|cannot find valid starting|cannot correct step",
            "no observations informative|singular|algorithm did not converge",
            "fitted probabilities numerically",
            sep = "|"
          ),
          message, ignore.case = TRUE
        )
        if (!expected_numeric) stop(error)
        v45c_numeric_failure(
          paste0(model_id, " numerical fit error."),
          paste0("FIT_ERROR:", class(error)[[1L]])
        )
      }
    ),
    warning = function(warning) {
      warnings <<- c(warnings, conditionMessage(warning))
      invokeRestart("muffleWarning")
    }
  )
  if (length(warnings)) {
    v45c_numeric_failure(
      paste0(model_id, " emitted a warning."),
      "MODEL_WARNING"
    )
  }
  value
}

v45c_validate_covariance <- function(value, names_expected, model_id) {
  value <- as.matrix(value)
  p <- length(names_expected)
  if (!identical(dim(value), c(p, p)) ||
      is.null(rownames(value)) || is.null(colnames(value)) ||
      !identical(rownames(value), names_expected) ||
      !identical(colnames(value), names_expected) ||
      any(!is.finite(value))) {
    v45c_numeric_failure(
      paste0(model_id, " covariance is invalid."),
      "COVARIANCE_INVALID"
    )
  }
  scale <- max(.Machine$double.xmin, max(abs(value)))
  if (max(abs(value - t(value))) >
      sqrt(.Machine$double.eps) * scale) {
    v45c_numeric_failure(
      paste0(model_id, " covariance is asymmetric."),
      "COVARIANCE_ASYMMETRIC"
    )
  }
  value <- (value + t(value)) / 2
  eigenvalues <- eigen(
    value, symmetric = TRUE, only.values = TRUE
  )$values
  tolerance <- max(
    .Machine$double.xmin,
    .Machine$double.eps * max(1, p) * max(abs(eigenvalues))
  )
  if (any(!is.finite(eigenvalues)) || min(eigenvalues) <= tolerance) {
    v45c_numeric_failure(
      paste0(model_id, " covariance is not positive definite."),
      "COVARIANCE_NOT_POSITIVE_DEFINITE"
    )
  }
  value
}

v45c_fit_cloglog <- function(
    data, weights, formula, focal_terms, model_id,
    point_survey = FALSE) {
  weights <- as.numeric(weights)
  focal_terms <- as.character(focal_terms)
  if (nrow(data) < 100L || length(weights) != nrow(data) ||
      any(!is.finite(weights) | weights < 0) ||
      sum(weights > 0) < 100L) {
    v45c_numeric_failure(
      paste0(model_id, " has invalid positive-weight support."),
      "WEIGHT_SUPPORT"
    )
  }
  frame <- tryCatch(
    stats::model.frame(formula, data = data, na.action = stats::na.fail),
    error = function(error) {
      stop(
        model_id,
        " would silently delete or cannot encode one or more rows.",
        call. = FALSE
      )
    }
  )
  if (nrow(frame) != nrow(data)) {
    stop(model_id, " model frame changed row cardinality.", call. = FALSE)
  }
  matrix <- stats::model.matrix(
    stats::delete.response(stats::terms(formula)), data = frame
  )
  positive <- weights > 0
  if (nrow(matrix) != nrow(data) ||
      qr(matrix[positive, , drop = FALSE])$rank != ncol(matrix)) {
    v45c_numeric_failure(
      paste0(model_id, " model matrix is rank deficient."),
      "RANK_DEFICIENT"
    )
  }
  local <- data
  local$.v45c_weight <- weights /
    mean(weights[weights > 0])
  if (point_survey) {
    design <- survey::svydesign(
      ids = ~community_id + participant_id,
      weights = ~.v45c_weight,
      data = local, nest = TRUE
    )
    fit <- v45c_capture_fit(
      survey::svyglm(
        formula, design = design,
        family = stats::quasibinomial(link = "cloglog")
      ),
      model_id
    )
    design_df <- as.numeric(survey::degf(design))
  } else {
    fit <- v45c_capture_fit(
      stats::glm(
        formula, data = local, weights = .v45c_weight,
        family = stats::quasibinomial(link = "cloglog"),
        model = FALSE, x = FALSE, y = FALSE
      ),
      model_id
    )
    design_df <- length(unique(as.character(local$community_id))) - 1L
  }
  if (!isTRUE(fit$converged) ||
      length(fit$boundary) != 1L || is.na(fit$boundary) ||
      isTRUE(fit$boundary)) {
    v45c_numeric_failure(
      paste0(model_id, " failed convergence/boundary validation."),
      "CONVERGENCE_OR_BOUNDARY"
    )
  }
  coefficients <- stats::coef(fit)
  if (!length(coefficients) || is.null(names(coefficients)) ||
      anyNA(names(coefficients)) || any(!nzchar(names(coefficients))) ||
      anyDuplicated(names(coefficients)) ||
      any(!is.finite(coefficients))) {
    v45c_numeric_failure(
      paste0(model_id, " produced invalid coefficients."),
      "COEFFICIENT_INVALID"
    )
  }
  missing_terms <- setdiff(focal_terms, names(coefficients))
  if (length(missing_terms)) {
    v45c_numeric_failure(
      paste0(model_id, " lacks focal terms."),
      "FOCAL_TERM_ABSENT"
    )
  }
  invisible(v45c_validate_covariance(
    stats::vcov(fit), names(coefficients), model_id
  ))
  fitted <- stats::fitted(fit)
  if (length(fitted) != nrow(data) ||
      any(!is.finite(fitted) | fitted <= 0 | fitted >= 1)) {
    v45c_numeric_failure(
      paste0(model_id, " fitted probabilities are outside (0,1)."),
      "FITTED_PROBABILITY_INVALID"
    )
  }
  result <- list(
    coefficients = unname(coefficients[focal_terms]),
    coefficient_names = focal_terms,
    diagnostics = data.frame(
      model_id = model_id,
      participants = length(unique(as.character(data$participant_id))),
      events = sum(as.integer(data$period_event) == 1L),
      period_rows = nrow(data),
      psu = length(unique(as.character(data$community_id))),
      design_df = as.numeric(design_df),
      matrix_columns = ncol(matrix),
      matrix_rank = qr(matrix[positive, , drop = FALSE])$rank,
      converged = TRUE,
      boundary = FALSE,
      warnings = "",
      stringsAsFactors = FALSE
    )
  )
  names(result$coefficients) <- focal_terms
  rm(fit)
  result
}

# Build a model frame and design matrix once per imputation/sample/formula.
# Replicate columns change weights, not rows or factor encodings.  W2 response
# centering is the sole exception and is updated in-place in the one registered
# grip column before each cached fit.
v45c_build_glm_cache <- function(
    data, formula, focal_terms, cache_id, family = c("cloglog", "logit")) {
  family <- match.arg(family)
  frame <- tryCatch(
    stats::model.frame(formula, data = data, na.action = stats::na.fail),
    error = function(error) {
      stop(cache_id, " cannot build an omission-free model frame.",
           call. = FALSE)
    }
  )
  if (nrow(frame) != nrow(data)) {
    stop(cache_id, " model frame changed row cardinality.", call. = FALSE)
  }
  terms_object <- stats::terms(formula)
  matrix <- stats::model.matrix(
    stats::delete.response(terms_object), data = frame
  )
  response <- stats::model.response(frame)
  offset <- stats::model.offset(frame)
  if (is.null(offset)) offset <- rep(0, nrow(frame))
  if (!is.numeric(response) && !is.logical(response)) {
    response <- as.numeric(response) - 1L
  }
  response <- as.numeric(response)
  focal_index <- match(focal_terms, colnames(matrix))
  if (anyNA(focal_index) || anyDuplicated(focal_index) ||
      any(!is.finite(response)) || any(!is.finite(offset)) ||
      any(!is.finite(matrix))) {
    stop(cache_id, " has invalid response, offset, matrix, or focal terms.",
         call. = FALSE)
  }
  list(
    cache_id = cache_id,
    family = family,
    formula_text = paste(deparse(formula), collapse = " "),
    response = response,
    offset = as.numeric(offset),
    matrix = unname(matrix),
    matrix_names = colnames(matrix),
    focal_terms = as.character(focal_terms),
    focal_index = as.integer(focal_index),
    participant_id = as.character(data$participant_id),
    community_id = as.character(data$community_id),
    period_event = if ("period_event" %in% names(data)) {
      as.integer(data$period_event)
    } else {
      rep(NA_integer_, nrow(data))
    }
  )
}

v45c_cached_matrix_column <- function(cache, name, value) {
  index <- match(name, cache$matrix_names)
  if (is.na(index) || length(value) != nrow(cache$matrix) ||
      any(!is.finite(value))) {
    stop(cache$cache_id, " dynamic matrix-column update is invalid.",
         call. = FALSE)
  }
  cache$matrix[, index] <- as.numeric(value)
  cache
}

v45c_fit_cached_glm <- function(
    cache, weights, model_id, return_fitted = FALSE) {
  weights <- as.numeric(weights)
  if (length(weights) != nrow(cache$matrix) ||
      any(!is.finite(weights) | weights < 0)) {
    v45c_numeric_failure(
      paste0(model_id, " has invalid replicate weights."),
      "WEIGHT_SUPPORT"
    )
  }
  positive <- weights > 0
  if (sum(positive) < 100L ||
      length(unique(cache$response[positive])) < 2L ||
      qr(cache$matrix[positive, , drop = FALSE])$rank !=
        ncol(cache$matrix)) {
    v45c_numeric_failure(
      paste0(model_id, " has insufficient full-rank outcome support."),
      "RANK_OR_OUTCOME_SUPPORT"
    )
  }
  family <- if (identical(cache$family, "logit")) {
    stats::quasibinomial(link = "logit")
  } else {
    stats::quasibinomial(link = "cloglog")
  }
  # For W2 response replicates this is the prespecified arithmetic mean over
  # the entire D2 column, including zero-multiplier communities.  For outcome
  # fits it is an innocuous common scale factor.
  scaled_weight <- weights / mean(weights)
  fit <- v45c_capture_fit(
    stats::glm.fit(
      x = cache$matrix,
      y = cache$response,
      weights = scaled_weight,
      offset = cache$offset,
      family = family,
      intercept = FALSE
    ),
    model_id
  )
  if (!isTRUE(fit$converged) ||
      length(fit$boundary) != 1L || is.na(fit$boundary) ||
      isTRUE(fit$boundary) ||
      fit$rank != ncol(cache$matrix) ||
      any(!is.finite(fit$coefficients))) {
    v45c_numeric_failure(
      paste0(model_id, " failed cached convergence/rank validation."),
      "CONVERGENCE_RANK_OR_BOUNDARY"
    )
  }
  # A full-rank weighted QR with finite, nonzero diagonal and finite positive
  # quasi-dispersion is equivalent to a finite SPD coefficient covariance.
  r_matrix <- tryCatch(
    qr.R(fit$qr),
    error = function(error) matrix(NA_real_, 0L, 0L)
  )
  residual_df <- sum(positive) - fit$rank
  pearson <- if (residual_df > 0L) {
    sum(
      scaled_weight[positive] *
        (cache$response[positive] - fit$fitted.values[positive])^2 /
        family$variance(fit$fitted.values[positive]),
      na.rm = FALSE
    ) / residual_df
  } else {
    NA_real_
  }
  if (!identical(dim(r_matrix), c(ncol(cache$matrix),
                                  ncol(cache$matrix))) ||
      any(!is.finite(r_matrix)) ||
      any(abs(diag(r_matrix)) <=
          sqrt(.Machine$double.eps) * max(1, max(abs(r_matrix)))) ||
      !is.finite(pearson) || pearson <= 0) {
    v45c_numeric_failure(
      paste0(model_id, " failed covariance gate."),
      "COVARIANCE_INVALID"
    )
  }
  fitted <- as.numeric(fit$fitted.values)
  if (length(fitted) != nrow(cache$matrix) ||
      any(!is.finite(fitted) | fitted <= 0 | fitted >= 1)) {
    v45c_numeric_failure(
      paste0(model_id, " fitted probabilities are outside (0,1)."),
      "FITTED_PROBABILITY_INVALID"
    )
  }
  value <- unname(fit$coefficients[cache$focal_index])
  names(value) <- cache$focal_terms
  out <- list(coefficients = value)
  if (return_fitted) out$fitted <- fitted
  rm(fit)
  out
}

v45c_try_replicate_fit <- function(expr, width, names_out) {
  failure_class <- ""
  value <- tryCatch(
    expr,
    v45c_numeric_failure = function(error) {
      failure_class <<- error$failure_class
      setNames(rep(NA_real_, width), names_out)
    }
  )
  if (!is.numeric(value) || length(value) != width ||
      !identical(names(value), names_out)) {
    stop("Replicate subfit returned an invalid interface.", call. = FALSE)
  }
  list(
    value = value,
    valid = all(is.finite(value)),
    failure_class = failure_class
  )
}

v45c_pool_scalar <- function(
    q, u, dfcom, label = "registered_scalar") {
  q <- as.numeric(q)
  u <- as.numeric(u)
  dfcom <- as.numeric(dfcom)
  if (length(q) < 2L || length(q) != length(u) ||
      any(!is.finite(q)) || any(!is.finite(u) | u <= 0) ||
      length(dfcom) != 1L || !is.finite(dfcom) || dfcom <= 0) {
    v45c_numeric_failure(
      paste0(label, " has non-estimable scalar Rubin input."),
      "POOL_SCALAR_NOT_ESTIMABLE"
    )
  }
  pooled <- tryCatch(
    mice::pool.scalar(
      Q = q, U = u, n = dfcom + 1, k = 1, rule = "rubin1987"
    ),
    error = function(error) {
      v45c_numeric_failure(
        paste0(label, " failed scalar Rubin pooling."),
        "POOL_SCALAR_NOT_ESTIMABLE"
      )
    }
  )
  pooled_required <- c(
    m = pooled$m, qbar = pooled$qbar, ubar = pooled$ubar,
    b = pooled$b, t = pooled$t, df = pooled$df,
    fmi = pooled$fmi
  )
  if (length(pooled_required) != 7L ||
      any(!is.finite(pooled_required)) ||
      pooled_required[["m"]] != length(q) ||
      pooled_required[["ubar"]] <= 0 ||
      pooled_required[["b"]] < 0 ||
      pooled_required[["t"]] <= 0 ||
      pooled_required[["df"]] <= 0 ||
      pooled_required[["fmi"]] < 0 ||
      pooled_required[["fmi"]] > 1) {
    v45c_numeric_failure(
      paste0(label, " produced invalid scalar Rubin output."),
      "POOL_SCALAR_NOT_ESTIMABLE"
    )
  }
  se <- sqrt(pooled$t)
  critical <- if (is.finite(pooled$df)) {
    stats::qt(0.975, df = pooled$df)
  } else {
    stats::qnorm(0.975)
  }
  statistic <- pooled$qbar / se
  p_value <- if (is.finite(pooled$df)) {
    2 * stats::pt(abs(statistic), df = pooled$df, lower.tail = FALSE)
  } else {
    2 * stats::pnorm(abs(statistic), lower.tail = FALSE)
  }
  mce <- sqrt(pooled$b / pooled$m)
  out <- data.frame(
    m = as.integer(pooled$m),
    estimate = pooled$qbar,
    standard_error = se,
    ci_low = pooled$qbar - critical * se,
    ci_high = pooled$qbar + critical * se,
    p_value = p_value,
    within_variance = pooled$ubar,
    between_variance = pooled$b,
    total_variance = pooled$t,
    df = pooled$df,
    dfcom = dfcom,
    FMI = pooled$fmi,
    MCE = mce,
    MCE_fraction = mce / se,
    stringsAsFactors = FALSE
  )
  numeric_output <- unlist(
    out, use.names = FALSE
  )
  if (any(!is.finite(numeric_output)) ||
      out$p_value < 0 || out$p_value > 1 ||
      out$standard_error <= 0 ||
      out$total_variance <= 0 ||
      out$MCE < 0 || out$MCE_fraction < 0) {
    v45c_numeric_failure(
      paste0(label, " produced non-finite scalar inference."),
      "POOL_SCALAR_NOT_ESTIMABLE"
    )
  }
  out
}

v45c_require_spd_matrix <- function(value, label) {
  value <- as.matrix(value)
  if (nrow(value) < 1L || nrow(value) != ncol(value) ||
      any(!is.finite(value))) {
    v45c_numeric_failure(
      paste0(label, " is not a finite square covariance."),
      "POOL_COVARIANCE_NOT_ESTIMABLE"
    )
  }
  scale <- max(.Machine$double.xmin, max(abs(value)))
  if (max(abs(value - t(value))) >
      sqrt(.Machine$double.eps) * scale) {
    v45c_numeric_failure(
      paste0(label, " covariance is asymmetric."),
      "POOL_COVARIANCE_NOT_ESTIMABLE"
    )
  }
  value <- (value + t(value)) / 2
  eigenvalues <- eigen(
    value, symmetric = TRUE, only.values = TRUE
  )$values
  tolerance <- max(
    .Machine$double.xmin,
    .Machine$double.eps * nrow(value) * max(abs(eigenvalues))
  )
  if (any(!is.finite(eigenvalues)) ||
      min(eigenvalues) <= tolerance) {
    v45c_numeric_failure(
      paste0(label, " covariance is not positive definite."),
      "POOL_COVARIANCE_NOT_ESTIMABLE"
    )
  }
  value
}

v45c_pool_multivariate <- function(q, u, test_id) {
  q <- as.matrix(q)
  if (nrow(q) < 2L || ncol(q) < 1L ||
      any(!is.finite(q)) || length(u) != nrow(q)) {
    stop(test_id, " has invalid multivariate Rubin input.", call. = FALSE)
  }
  p <- ncol(q)
  if (any(!vapply(u, function(value) {
    is.matrix(value) && identical(dim(value), c(p, p)) &&
      all(is.finite(value))
  }, logical(1)))) {
    stop(test_id, " has invalid within-imputation covariance.",
      call. = FALSE)
  }
  u <- lapply(seq_along(u), function(index) {
    v45c_require_spd_matrix(
      u[[index]],
      paste0(test_id, "/within_imputation_", index)
    )
  })
  qbar <- colMeans(q)
  ubar <- Reduce("+", u) / length(u)
  between <- stats::cov(q)
  total <- ubar + (1 + 1 / nrow(q)) * between
  total <- v45c_require_spd_matrix(
    total, paste0(test_id, "/total")
  )
  inverse <- tryCatch(
    solve(total),
    error = function(error) {
      v45c_numeric_failure(
        paste0(test_id, " total covariance is singular."),
        "POOL_COVARIANCE_NOT_ESTIMABLE"
      )
    }
  )
  statistic <- as.numeric(crossprod(qbar, inverse %*% qbar))
  p_value <- stats::pchisq(
    statistic, df = p, lower.tail = FALSE
  )
  if (length(statistic) != 1L || !is.finite(statistic) ||
      statistic < 0 || length(p_value) != 1L ||
      !is.finite(p_value) || p_value < 0 || p_value > 1) {
    v45c_numeric_failure(
      paste0(test_id, " produced invalid multivariate inference."),
      "POOL_COVARIANCE_NOT_ESTIMABLE"
    )
  }
  list(
    test_id = test_id,
    dimension = p,
    statistic = statistic,
    p_value = p_value,
    qbar = qbar,
    within_covariance = ubar,
    between_covariance = between,
    total_covariance = total
  )
}

v45c_parallel_map <- function(indices, fun, workers, label, append_log) {
  append_log(paste0(
    label, " started for ", length(indices),
    " imputations with ", workers, " worker(s)."
  ))
  wrapper <- function(index) {
    tryCatch(
      list(
        ok = TRUE, value = fun(index),
        registered_stop = FALSE,
        failure_class = "", error_class = ""
      ),
      v45c_registered_stage_stop = function(error) list(
        ok = FALSE, value = NULL,
        registered_stop = TRUE,
        failure_class = error$failure_class,
        error_class = paste(class(error), collapse = "|")
      ),
      v45c_numeric_failure = function(error) list(
        ok = FALSE, value = NULL,
        registered_stop = TRUE,
        failure_class = error$failure_class,
        error_class = paste(class(error), collapse = "|")
      ),
      error = function(error) list(
        ok = FALSE, value = NULL,
        registered_stop = FALSE,
        failure_class = "",
        error_class = paste(class(error), collapse = "|")
      )
    )
  }
  result <- if (workers == 1L) {
    lapply(indices, wrapper)
  } else {
    parallel::mclapply(
      indices, wrapper, mc.cores = workers,
      mc.preschedule = FALSE, mc.set.seed = FALSE
    )
  }
  failed <- !vapply(result, `[[`, logical(1), "ok")
  if (any(failed)) {
    registered <- vapply(
      result, `[[`, logical(1), "registered_stop"
    )
    unknown <- failed & !registered
    if (any(unknown)) {
      stop(
        label, " failed for imputation(s): ",
        paste(indices[unknown], collapse = ","),
        "; unknown implementation failure classes: ",
        paste(unique(vapply(
          result[unknown], `[[`, character(1), "error_class"
        )), collapse = ","),
        call. = FALSE
      )
    }
    failure_classes <- vapply(
      result[failed], `[[`, character(1), "failure_class"
    )
    failure_summary <- v45c_registered_failure_summary(
      indices[failed], failure_classes
    )
    aggregate_class <- if (nrow(failure_summary) == 1L) {
      failure_summary$failure_class[[1L]]
    } else {
      "MULTIPLE_REGISTERED_POINT_FAILURE_CLASSES"
    }
    append_log(paste0(
      label, " stopped by a registered point-stage failure in ",
      sum(failed), " imputation(s)."
    ))
    v45c_registered_stage_stop(
      paste0(
        "Registered point-stage numerical, support, or diagnostic ",
        "failure affected ", sum(failed), " imputation(s)."
      ),
      aggregate_class,
      failure_summary
    )
  }
  append_log(paste0(label, " finished for all imputations."))
  lapply(result, `[[`, "value")
}

v45c_numeric_code <- function(value) {
  suppressWarnings(as.numeric(as.character(value)))
}

v45c_rebuild_passive_bmi <- function(
    height_m_w1, weight_kg_w1, bmi_placeholder, object_id) {
  height <- v45c_numeric_code(height_m_w1)
  weight <- v45c_numeric_code(weight_kg_w1)
  placeholder <- v45c_numeric_code(bmi_placeholder)
  if (!length(height) ||
      length(weight) != length(height) ||
      length(placeholder) != length(height)) {
    stop(object_id, " passive BMI inputs have incompatible lengths.",
         call. = FALSE)
  }
  if (any(!is.finite(height) | height < 1 | height > 2.7) ||
      any(!is.finite(weight) | weight < 20 | weight > 350)) {
    stop(object_id, " passive BMI parents failed frozen bounds.",
         call. = FALSE)
  }
  if (any(!is.finite(placeholder) | placeholder != 0)) {
    stop(object_id, " frozen BMI placeholder is not exactly zero.",
         call. = FALSE)
  }
  bmi <- weight / height^2
  identity_error <- max(abs(bmi - weight / height^2))
  if (any(!is.finite(bmi) | bmi < 11 | bmi > 75) ||
      !is.finite(identity_error) || identity_error > 1e-12) {
    stop(object_id, " rebuilt passive BMI failed frozen identity/bounds.",
         call. = FALSE)
  }
  list(height = height, weight = weight, bmi = bmi)
}

v45c_rebuild_completed_bmi <- function(completed, object_id) {
  completed <- as.data.frame(completed, stringsAsFactors = FALSE)
  required <- c("height_m_w1", "weight_kg_w1", "bmi_w1")
  if (!all(required %in% names(completed))) {
    stop(object_id, " completed data lack passive BMI fields.",
         call. = FALSE)
  }
  passive <- v45c_rebuild_passive_bmi(
    completed$height_m_w1,
    completed$weight_kg_w1,
    completed$bmi_w1,
    object_id
  )
  completed$height_m_w1 <- passive$height
  completed$weight_kg_w1 <- passive$weight
  completed$bmi_w1 <- passive$bmi
  if (max(abs(
        completed$bmi_w1 -
          completed$weight_kg_w1 / completed$height_m_w1^2
      )) > 1e-12) {
    stop(object_id, " completed passive BMI assignment drifted.",
         call. = FALSE)
  }
  completed
}

v45c_explicit_match <- function(keys, reference, label) {
  keys <- as.character(keys)
  reference <- as.character(reference)
  if (anyNA(keys) || anyNA(reference) || any(!nzchar(keys)) ||
      any(!nzchar(reference)) || anyDuplicated(keys) ||
      anyDuplicated(reference)) {
    stop(label, " keys are missing or duplicated.", call. = FALSE)
  }
  index <- match(keys, reference)
  if (anyNA(index) || anyDuplicated(index)) {
    stop(label, " exact character match failed.", call. = FALSE)
  }
  index
}

v45c_add_fixed_fields <- function(completed, master, fields, label) {
  index <- v45c_explicit_match(
    completed$participant_id, master$participant_id,
    paste0(label, " participant join")
  )
  for (field in fields) {
    if (!field %in% names(master)) {
      stop(label, " fixed ledger field is absent: ", field,
           call. = FALSE)
    }
    value <- master[[field]][index]
    if (field %in% names(completed)) {
      left <- completed[[field]]
      equal <- if (is.numeric(left) || is.numeric(value)) {
        isTRUE(all.equal(
          v45c_numeric_code(left), v45c_numeric_code(value),
          tolerance = 0, check.attributes = FALSE
        ))
      } else {
        identical(as.character(left), as.character(value))
      }
      if (!equal) {
        stop(label, " fixed field drifted: ", field, call. = FALSE)
      }
    } else {
      completed[[field]] <- value
    }
  }
  completed
}

v45c_valid_pef <- function(value) {
  is.finite(value) & value >= 30 & value <= 890
}

v45c_top_two_difference <- function(trials) {
  apply(trials, 1L, function(value) {
    value <- value[v45c_valid_pef(value)]
    if (length(value) < 2L) return(0)
    value <- sort(value, decreasing = TRUE)
    value[[1L]] - value[[2L]]
  })
}

v45c_pef_summary <- function(trials, type) {
  type <- match.arg(type, c("max", "mean", "median"))
  apply(trials, 1L, function(value) {
    value <- value[v45c_valid_pef(value)]
    if (!length(value)) return(NA_real_)
    switch(
      type,
      max = max(value),
      mean = mean(value),
      median = stats::median(value)
    )
  })
}

v45c_prepare_person <- function(
    completed, ledger, actual, v43, object_id) {
  object_id <- match.arg(object_id, c("MI-C0", "MI-C2"))
  completed <- as.data.frame(completed, stringsAsFactors = FALSE)
  completed$participant_id <- as.character(completed$participant_id)
  completed$community_id <- as.character(completed$community_id)
  if (anyNA(completed$participant_id) ||
      anyDuplicated(completed$participant_id) ||
      anyNA(completed$community_id)) {
    stop(object_id, " completion has invalid IDs.", call. = FALSE)
  }
  denominator <- actual$participant_denominator_map
  expected_ids <- if (identical(object_id, "MI-C0")) {
    as.character(denominator$participant_id)
  } else {
    as.character(denominator$participant_id[
      denominator$D2_support %in% TRUE
    ])
  }
  index <- v45c_explicit_match(
    completed$participant_id, expected_ids,
    paste0(object_id, " completed-to-frozen denominator")
  )
  if (length(index) != length(expected_ids) ||
      !setequal(index, seq_along(expected_ids))) {
    stop(object_id, " completion does not contain its exact denominator.",
         call. = FALSE)
  }
  frozen_denominator <- denominator[
    match(completed$participant_id, denominator$participant_id),
    , drop = FALSE
  ]
  if (!identical(
    as.character(completed$community_id),
    as.character(frozen_denominator$community_id)
  )) {
    stop(object_id, " completion community IDs drifted.", call. = FALSE)
  }
  master <- ledger$person_master
  fixed_fields <- c(
    "pef_w1_trial1", "pef_w1_trial2", "pef_w1_trial3",
    "pef_w1_valid_n", "pef_w1_completion_yes",
    "pef_w1_standing", "pef_w1_full_effort",
    "pef_w1_strict_protocol",
    "pef_w1_boundary_floor", "pef_w1_boundary_ceiling"
  )
  if (identical(object_id, "MI-C2")) {
    fixed_fields <- c(
      fixed_fields,
      "pef_w2_trial1", "pef_w2_trial2", "pef_w2_trial3",
      "pef_w2_valid_n", "pef_w2_completion_yes",
      "pef_w2_standing", "pef_w2_full_effort",
      "pef_w2_strict_protocol",
      "pef_w2_boundary_floor", "pef_w2_boundary_ceiling"
    )
  }
  completed <- v45c_add_fixed_fields(
    completed, master, fixed_fields, object_id
  )
  completed <- v45c_rebuild_completed_bmi(completed, object_id)

  smoke_ever <- v45c_numeric_code(completed$smoke_ever_w1)
  smoke_now <- v45c_numeric_code(completed$smoke_now_w1)
  if (anyNA(smoke_ever) || anyNA(smoke_now) ||
      any(!smoke_ever %in% 0:1) || any(!smoke_now %in% 0:1) ||
      any(smoke_ever == 0 & smoke_now == 1)) {
    stop(object_id, " smoking parent-child identity failed.",
         call. = FALSE)
  }
  smoking <- ifelse(
    smoke_ever == 0, "never",
    ifelse(smoke_now == 1, "current", "former")
  )
  completed$smoking_status_3 <- factor(
    smoking, levels = c("never", "former", "current")
  )
  sex <- v45c_numeric_code(completed$sex_code)
  education <- v45c_numeric_code(completed$raeducl)
  rural <- v45c_numeric_code(completed$h1rural)
  if (any(!sex %in% c(1, 2)) ||
      any(!education %in% c(1, 2, 3)) ||
      any(!rural %in% c(0, 1))) {
    stop(object_id, " frozen factor-level contract failed.",
         call. = FALSE)
  }
  completed$sex_code <- factor(sex, levels = c(1, 2))
  completed$raeducl <- factor(education, levels = c(1, 2, 3))
  completed$h1rural <- factor(rural, levels = c(0, 1))
  completed$hh1cperc <- v45c_numeric_code(completed$hh1cperc)
  if (any(!is.finite(completed$hh1cperc) | completed$hh1cperc < 0)) {
    stop(object_id, " household consumption is invalid.", call. = FALSE)
  }
  completed$log_hh1cperc <- log1p(completed$hh1cperc)
  diseases <- c(
    "r1hibpe", "r1diabe", "r1cancre",
    "r1hearte", "r1stroke", "r1kidneye"
  )
  disease_matrix <- do.call(cbind, lapply(
    completed[diseases], v45c_numeric_code
  ))
  if (anyNA(disease_matrix) || any(!disease_matrix %in% 0:1)) {
    stop(object_id, " disease-parent encoding is invalid.",
         call. = FALSE)
  }
  completed$nonpulmonary_comorbidity_count <- rowSums(disease_matrix)
  completed$frailty_proxy_count_w1 <-
    v45c_numeric_code(completed$frailty_proxy_count_w1)
  completed$lung_w1 <- v45c_numeric_code(completed$lung_w1)
  completed$asthma_w1 <- v45c_numeric_code(completed$asthma_w1)
  completed$age_w1 <- v45c_numeric_code(completed$age_w1)
  completed$E0 <- v45c_numeric_code(completed$E0)
  completed$E0b <- v45c_numeric_code(completed$E0b)
  completed$weight_biomarker_w1 <-
    v45c_numeric_code(completed$weight_biomarker_w1)
  if (any(!is.finite(completed$weight_biomarker_w1) |
          completed$weight_biomarker_w1 <= 0)) {
    stop(object_id, " base survey weight is invalid.", call. = FALSE)
  }

  completed <- cbind(
    completed,
    v43$fixed_ns(
      completed$age_w1,
      v43$get_knot_row(ledger$spline_knots, "age_w1"), "age"
    ),
    v43$fixed_ns(
      completed$height_m_w1,
      v43$get_knot_row(ledger$spline_knots, "height_m_w1"), "height"
    ),
    v43$fixed_ns(
      completed$bmi_w1,
      v43$get_knot_row(ledger$spline_knots, "bmi_w1"), "bmi"
    ),
    v43$restricted_cubic_basis(
      completed$E0,
      v43$get_knot_row(ledger$spline_knots, "E0"), "E0"
    )
  )
  completed$age_w2 <- completed$age_w1 + 2
  w2_knots <- data.frame(
    weighted_q05 = 48, weighted_q35 = 56,
    weighted_q65 = 64, weighted_q95 = 80
  )
  completed <- cbind(
    completed,
    v43$fixed_ns(completed$age_w2, w2_knots, "ageW2")
  )

  trial_w1 <- as.matrix(completed[c(
    "pef_w1_trial1", "pef_w1_trial2", "pef_w1_trial3"
  )])
  storage.mode(trial_w1) <- "double"
  completed$PEF_max <- v45c_pef_summary(trial_w1, "max")
  completed$PEF_mean <- v45c_pef_summary(trial_w1, "mean")
  completed$PEF_median <- v45c_pef_summary(trial_w1, "median")
  mu <- ifelse(
    sex == 1, 352.0554437442698, 250.41587378062366
  )
  sigma <- ifelse(
    sex == 1, 139.663376333644, 99.89645172261167
  )
  completed$L100_max <- (mu - completed$PEF_max) / 100
  completed$L100_mean <- (mu - completed$PEF_mean) / 100
  completed$L100_median <- (mu - completed$PEF_median) / 100
  completed$C100_median <- completed$L100_median
  completed$pef_w1_top2_log40 <-
    log1p(v45c_top_two_difference(trial_w1) / 40)
  completed$pef_w1_boundary_any <- as.logical(
    completed$pef_w1_boundary_floor |
      completed$pef_w1_boundary_ceiling
  )
  completed$pef_w1_valid_n <-
    as.integer(v45c_numeric_code(completed$pef_w1_valid_n))
  completed$pef_w1_standing <- as.logical(completed$pef_w1_standing)
  completed$pef_w1_full_effort <-
    as.logical(completed$pef_w1_full_effort)

  if (identical(object_id, "MI-C2")) {
    trial_w2 <- as.matrix(completed[c(
      "pef_w2_trial1", "pef_w2_trial2", "pef_w2_trial3"
    )])
    storage.mode(trial_w2) <- "double"
    w2_max <- v45c_pef_summary(trial_w2, "max")
    w2_mean <- v45c_pef_summary(trial_w2, "mean")
    w2_median <- v45c_pef_summary(trial_w2, "median")
    completed$E0_W1 <- (mu - completed$PEF_max) / sigma
    completed$E0_W2 <- (mu - w2_max) / sigma
    completed$M12 <- (completed$E0_W1 + completed$E0_W2) / 2
    completed$D12 <- completed$E0_W2 - completed$E0_W1
    completed$M12_max <- completed$M12
    completed$M12_mean <- (
      (mu - completed$PEF_mean) / sigma +
        (mu - w2_mean) / sigma
    ) / 2
    completed$M12_median <- (
      (mu - completed$PEF_median) / sigma +
        (mu - w2_median) / sigma
    ) / 2
    completed$pef_w2_valid_n <-
      as.integer(v45c_numeric_code(completed$pef_w2_valid_n))
    completed$R_W2 <- as.integer(v45c_numeric_code(completed$R_W2))
    if (!identical(
      completed$R_W2,
      as.integer(frozen_denominator$R_W2)
    )) {
      stop("MI-C2 R_W2 drifted from the frozen fixed field.",
           call. = FALSE)
    }
    cesd <- v45c_numeric_code(completed$cesd10_w1)
    if (any(!is.finite(cesd) | cesd < 0 | cesd > 30)) {
      stop("MI-C2 CES-D source is outside the frozen range.",
           call. = FALSE)
    }
    completed$cesd_category <- cut(
      cesd, breaks = c(0, 10, 20, Inf),
      right = FALSE, include.lowest = TRUE,
      labels = c("0-9", "10-19", "20-30")
    )
    completed$log_survey_weight <-
      log(completed$weight_biomarker_w1)
  }
  completed
}

v45c_build_period <- function(
    person, ledger, actual, member,
    adjacent = FALSE, w2_landmark = FALSE) {
  member <- as.logical(member)
  if (length(member) != nrow(person) || anyNA(member)) {
    stop("Invalid person-period domain mask.", call. = FALSE)
  }
  skeleton <- as.data.frame(
    ledger$person_period_skeleton, stringsAsFactors = FALSE
  )
  skeleton$participant_id <- as.character(skeleton$participant_id)
  skeleton$community_id <- as.character(skeleton$community_id)
  key_map <- actual$outcome_free_period_key_map
  key <- paste(
    skeleton$participant_id, skeleton$start_wave, skeleton$end_wave,
    sep = "\u241f"
  )
  frozen_key <- paste(
    key_map$participant_id, key_map$start_wave, key_map$end_wave,
    sep = "\u241f"
  )
  if (anyDuplicated(key) || anyDuplicated(frozen_key) ||
      !identical(key, frozen_key) ||
      !identical(
        as.character(skeleton$community_id),
        as.character(key_map$community_id)
      )) {
    stop("Person-period skeleton drifted from the frozen period key map.",
         call. = FALSE)
  }
  keep_ids <- person$participant_id[member]
  keep <- skeleton$participant_id %in% keep_ids
  if (adjacent) keep <- keep & key_map$adjacent_transition %in% TRUE
  if (w2_landmark) {
    keep <- keep &
      skeleton$start_wave >= 2L &
      skeleton$end_wave %in% c(3L, 4L, 5L)
  }
  skeleton <- skeleton[keep, , drop = FALSE]
  index <- match(skeleton$participant_id, person$participant_id)
  if (anyNA(index) || nrow(skeleton) < 1L) {
    stop("Person-period explicit join failed.", call. = FALSE)
  }
  person_fields <- setdiff(
    names(person),
    c("participant_id", "community_id", "weight_biomarker_w1")
  )
  out <- cbind(
    skeleton,
    person[index, person_fields, drop = FALSE]
  )
  if (!identical(
    as.character(out$community_id),
    as.character(person$community_id[index])
  ) || !isTRUE(all.equal(
    as.numeric(out$weight_biomarker_w1),
    as.numeric(person$weight_biomarker_w1[index]),
    tolerance = 0, check.attributes = FALSE
  ))) {
    stop("Person-period fixed community/weight join drifted.",
         call. = FALSE)
  }
  out$end_wave <- factor(
    as.integer(out$end_wave),
    levels = if (w2_landmark) c(3, 4, 5) else c(2, 3, 4, 5)
  )
  out
}

v45c_replicate_multiplier <- function(
    community_id, module, replicate_index) {
  replicate_name <- v45c_literal_replicate_names(replicate_index)
  key_map <- module$key_map
  if (is.null(rownames(module$matrix)) ||
      !identical(
        as.character(rownames(module$matrix)),
        as.character(key_map$community_id)
      ) ||
      !identical(
        as.integer(key_map$psu_ordinal),
        seq_len(nrow(key_map))
      )) {
    stop("Actual Rao-Wu matrix/key-map order drifted.", call. = FALSE)
  }
  index <- match(
    as.character(community_id),
    as.character(key_map$community_id)
  )
  if (anyNA(index) ||
      anyDuplicated(as.character(key_map$community_id)) ||
      !replicate_name %in% colnames(module$matrix)) {
    stop("Actual Rao-Wu community binding failed.", call. = FALSE)
  }
  as.numeric(module$matrix[index, replicate_name])
}

v45c_a1_terms <- function(age_prefix = "age") {
  c(
    paste0(age_prefix, "_ns1"),
    paste0(age_prefix, "_ns2"),
    paste0(age_prefix, "_ns3"),
    "factor(sex_code)",
    "height_ns1", "height_ns2", "height_ns3",
    "factor(smoking_status_3)",
    "bmi_ns1", "bmi_ns2", "bmi_ns3",
    "factor(raeducl)", "factor(h1rural)", "log_hh1cperc",
    "factor(end_wave)", "offset(log(nominal_years))"
  )
}

v45c_formula <- function(formula_id, exposure = NULL) {
  rhs <- switch(
    formula_id,
    F_TRIAL_L100_A1 = c(exposure, v45c_a1_terms("age")),
    F_INCONSISTENCY_LINEAR_A1 = c(
      "C100_median", "I_z", v45c_a1_terms("age")
    ),
    F_INCONSISTENCY_SPLINE_A1 = c(
      "C100_median", "I_z_linear",
      "I_z_nonlinear1", "I_z_nonlinear2",
      v45c_a1_terms("age")
    ),
    F_ADJACENT_E0_A1 = c("E0", v45c_a1_terms("age")),
    F_W2_SINGLE_A1 = c(exposure, v45c_a1_terms("ageW2")),
    F_W2_M12_D12_A1 = c(
      "M12", "D12", v45c_a1_terms("ageW2")
    ),
    F_TIME_HETEROGENEITY_A1 = c(
      "E0", "E0:factor(end_wave)", v45c_a1_terms("age")
    ),
    stop("Unknown outcome formula ID: ", formula_id, call. = FALSE)
  )
  if (!length(rhs) || anyNA(rhs) || any(!nzchar(rhs)) ||
      anyDuplicated(rhs)) {
    stop(formula_id, " formula has invalid or duplicate terms.",
         call. = FALSE)
  }
  stats::as.formula(paste(
    "period_event ~", paste(rhs, collapse = " + ")
  ))
}

v45c_response_formula <- function() {
  stats::as.formula(paste(
    "R_W2 ~ ageW2_ns1 + ageW2_ns2 + ageW2_ns3 +",
    "factor(sex_code) +",
    "height_ns1 + height_ns2 + height_ns3 +",
    "bmi_ns1 + bmi_ns2 + bmi_ns3 +",
    "factor(smoking_status_3) +",
    "factor(raeducl) + factor(h1rural) + log_hh1cperc +",
    "E0_linear + E0_nonlinear1 + E0_nonlinear2 +",
    "factor(pef_w1_valid_n, levels=c(3,2,1)) +",
    "pef_w1_standing + pef_w1_full_effort +",
    "pef_w1_boundary_any + pef_w1_top2_log40 +",
    "lung_w1 + asthma_w1 +",
    "nonpulmonary_comorbidity_count + frailty_proxy_count_w1 +",
    "grip_c_5kg + adl6_score_w1 + factor(cesd_category) +",
    "log_survey_weight"
  ))
}

v45c_assert_anchor <- function(
    data, expected_n, expected_events = NULL,
    expected_rows = NULL, expected_psu = NULL, label) {
  n <- length(unique(as.character(data$participant_id)))
  events <- if ("period_event" %in% names(data)) {
    sum(as.integer(data$period_event) == 1L)
  } else {
    NA_integer_
  }
  rows <- nrow(data)
  psu <- length(unique(as.character(data$community_id)))
  pass <- identical(as.integer(n), as.integer(expected_n)) &&
    (is.null(expected_events) ||
       identical(as.integer(events), as.integer(expected_events))) &&
    (is.null(expected_rows) ||
       identical(as.integer(rows), as.integer(expected_rows))) &&
    (is.null(expected_psu) ||
       identical(as.integer(psu), as.integer(expected_psu)))
  if (!pass) {
    stop(label, " denominator/event/period/PSU anchor failed.",
         call. = FALSE)
  }
  invisible(TRUE)
}

v45c_failure_summary <- function(values) {
  values <- as.character(values)
  values <- values[!is.na(values) & nzchar(values)]
  if (!length(values)) {
    return(data.frame(
      failure_class = character(), count = integer(),
      stringsAsFactors = FALSE
    ))
  }
  table_value <- sort(table(values), decreasing = TRUE)
  data.frame(
    failure_class = names(table_value),
    count = as.integer(table_value),
    stringsAsFactors = FALSE
  )
}

v45c_make_group <- function(
    group_id, point, replicates, dfcom,
    failure_class = rep("", nrow(replicates)),
    compute_covariance = TRUE) {
  point <- as.numeric(point)
  names(point) <- colnames(replicates)
  if (!is.matrix(replicates) || !length(point) ||
      ncol(replicates) != length(point) ||
      !identical(names(point), colnames(replicates)) ||
      any(!is.finite(point)) ||
      length(failure_class) != nrow(replicates)) {
    stop(group_id, " group interface is invalid.", call. = FALSE)
  }
  dfcom_names <- names(dfcom)
  dfcom <- as.numeric(dfcom)
  if (length(dfcom) == 1L) {
    dfcom <- rep(dfcom, length(point))
    names(dfcom) <- names(point)
  } else if (!is.null(dfcom_names)) {
    names(dfcom) <- dfcom_names
  }
  if (length(dfcom) != length(point) ||
      is.null(names(dfcom)) ||
      !identical(names(dfcom), names(point)) ||
      any(!is.finite(dfcom) | dfcom <= 0)) {
    stop(group_id, " per-estimand dfcom contract is invalid.",
         call. = FALSE)
  }
  finite <- apply(replicates, 1L, function(value) {
    all(is.finite(value))
  })
  if (isTRUE(compute_covariance)) {
    covariance <- v45c_common_replicate_covariance(
      point, replicates, finite
    )
  } else {
    covariance <- list(
      covariance = matrix(
        NA_real_, length(point), length(point),
        dimnames = list(names(point), names(point))
      ),
      valid = finite,
      valid_n = sum(finite),
      valid_fraction = mean(finite),
      gate = v45c_valid_fraction_gate(mean(finite)),
      denominator = NA_integer_,
      nominal_n = nrow(replicates)
    )
  }
  list(
    group_id = group_id,
    point = point,
    replicates = replicates,
    common_valid_mask = covariance$valid,
    within_covariance = covariance$covariance,
    valid_replicate_n = covariance$valid_n,
    valid_replicate_fraction = covariance$valid_fraction,
    valid_fraction_gate = covariance$gate,
    variance_denominator = covariance$denominator,
    nominal_replicates = covariance$nominal_n,
    dfcom = min(dfcom),
    dfcom_by_column = dfcom,
    failure_class_by_replicate = as.character(failure_class),
    failure_summary = v45c_failure_summary(failure_class),
    scale_rule = "1/(B_valid-1)",
    common_failure_mask = TRUE,
    covariance_computed = isTRUE(compute_covariance),
    coefficient_blind_prefix_eligible =
      !isTRUE(compute_covariance)
  )
}

v45c_extend_group <- function(prefix, suffix_replicates, failure_class) {
  if (!is.list(prefix) || is.null(prefix$point) ||
      is.null(prefix$replicates) ||
      !identical(
        rownames(prefix$replicates),
        v45c_literal_replicate_names(1:250)
      )) {
    stop("Prefix group is invalid.", call. = FALSE)
  }
  all_replicates <- v45c_concat_prefix(
    prefix$replicates, suffix_replicates
  )
  prefix_failures <- prefix$failure_class_by_replicate
  if (length(prefix_failures) != 250L) {
    stop("Prefix failure registry is incomplete.", call. = FALSE)
  }
  v45c_make_group(
    prefix$group_id, prefix$point, all_replicates,
    prefix$dfcom_by_column,
    c(prefix_failures, failure_class),
    compute_covariance = TRUE
  )
}

v45c_module_gate <- function(results) {
  fractions <- unlist(lapply(results, function(result) {
    vapply(
      result$groups, `[[`, numeric(1),
      "valid_replicate_fraction"
    )
  }), use.names = FALSE)
  if (!length(fractions) || any(!is.finite(fractions))) {
    return(list(
      minimum_valid_fraction = NA_real_, gate = "STOP"
    ))
  }
  list(
    minimum_valid_fraction = min(fractions),
    gate = v45c_valid_fraction_gate(min(fractions))
  )
}

v45c_pooling_action <- function(is_full, gate) {
  if (!isTRUE(is_full)) return("NOT_APPLICABLE_PREFIX")
  if (length(gate) != 1L || is.na(gate) ||
      !gate %in% c("GO", "CAUTION", "STOP")) {
    stop("Invalid full-module gate for pooling.", call. = FALSE)
  }
  if (gate == "STOP") {
    "NOT_PERFORMED_FULL_GATE_STOP"
  } else {
    "POOL"
  }
}

v45c_pool_full_module <- function(
    results, scalar_map, joint_definitions = list()) {
  if (length(results) != 50L ||
      !identical(
        vapply(results, `[[`, integer(1), "imputation"),
        seq_len(50L)
      )) {
    stop("Full module does not contain all 50 imputations.",
         call. = FALSE)
  }
  required_map <- c(
    "group_id", "column", "analysis_id", "term", "MCE_trigger"
  )
  if (!is.data.frame(scalar_map) ||
      !all(required_map %in% names(scalar_map)) ||
      anyDuplicated(paste(scalar_map$group_id, scalar_map$column)) ||
      anyDuplicated(paste(scalar_map$analysis_id, scalar_map$term))) {
    stop("Scalar map is invalid.", call. = FALSE)
  }
  per_rows <- lapply(seq_len(nrow(scalar_map)), function(map_index) {
    map <- scalar_map[map_index, , drop = FALSE]
    rows <- lapply(results, function(result) {
      group <- result$groups[[map$group_id[[1L]]]]
      column_index <- match(map$column[[1L]], names(group$point))
      if (is.null(group) || is.na(column_index)) {
        stop("Scalar map references an absent group column.",
             call. = FALSE)
      }
      data.frame(
        analysis_id = map$analysis_id[[1L]],
        term = map$term[[1L]],
        group_id = map$group_id[[1L]],
        imputation = result$imputation,
        estimate = group$point[[column_index]],
        within_variance =
          group$within_covariance[column_index, column_index],
        dfcom = group$dfcom_by_column[[map$column[[1L]]]],
        valid_replicate_n = group$valid_replicate_n,
        valid_replicate_fraction =
          group$valid_replicate_fraction,
        MCE_trigger = as.logical(map$MCE_trigger[[1L]]),
        stringsAsFactors = FALSE
      )
    })
    do.call(rbind, rows)
  })
  per_scalar <- do.call(rbind, per_rows)
  rownames(per_scalar) <- NULL
  keys <- unique(per_scalar[c(
    "analysis_id", "term", "group_id", "MCE_trigger"
  )])
  pooled_rows <- lapply(seq_len(nrow(keys)), function(key_index) {
    key <- keys[key_index, , drop = FALSE]
    use <- per_scalar$analysis_id == key$analysis_id[[1L]] &
      per_scalar$term == key$term[[1L]] &
      per_scalar$group_id == key$group_id[[1L]]
    data <- per_scalar[use, , drop = FALSE]
    data <- data[order(data$imputation), , drop = FALSE]
    if (!identical(data$imputation, seq_len(50L))) {
      stop("Scalar pooling key lacks exact m=50.", call. = FALSE)
    }
    pooled <- v45c_pool_scalar(
      data$estimate, data$within_variance,
      min(data$dfcom),
      paste0(
        key$analysis_id[[1L]], "/", key$term[[1L]]
      )
    )
    cbind(key, pooled)
  })
  pooled_scalar <- do.call(rbind, pooled_rows)
  rownames(pooled_scalar) <- NULL

  joint_results <- lapply(joint_definitions, function(definition) {
    group_id <- definition$group_id
    columns <- definition$columns
    q <- do.call(rbind, lapply(results, function(result) {
      group <- result$groups[[group_id]]
      if (is.null(group) || !all(columns %in% names(group$point))) {
        stop(definition$test_id, " joint columns are absent.",
             call. = FALSE)
      }
      unname(group$point[columns])
    }))
    colnames(q) <- columns
    u <- lapply(results, function(result) {
      group <- result$groups[[group_id]]
      group$within_covariance[
        columns, columns, drop = FALSE
      ]
    })
    v45c_pool_multivariate(q, u, definition$test_id)
  })
  names(joint_results) <- vapply(
    joint_definitions, `[[`, character(1), "test_id"
  )
  trigger <- pooled_scalar$MCE_trigger %in% TRUE &
    pooled_scalar$MCE_fraction >= 0.10
  list(
    per_imputation = per_scalar,
    pooled_scalar = pooled_scalar,
    joint_results = joint_results,
    m100_trigger_metadata = list(
      policy = "WHOLE_MI_OBJECT_NO_SELECTIVE_MODEL_UPGRADE",
      evaluated_scalar_n = sum(pooled_scalar$MCE_trigger %in% TRUE),
      trigger_scalar_n = sum(trigger),
      trigger = any(trigger),
      threshold = 0.10,
      independent_validation_required_before_action = TRUE,
      automatic_m100_execution = FALSE
    )
  )
}

v45c_trial_scalar_map <- function() {
  data.frame(
    group_id = "TRIAL_ALL_THREE",
    column = c(
      "trial_max", "trial_mean", "trial_median",
      "trial_mean_minus_max", "trial_median_minus_max",
      "trial_median_minus_mean"
    ),
    analysis_id = c(
      "v45_c_trial_max_a1", "v45_c_trial_mean_a1",
      "v45_c_trial_median_a1", "v45_c_trial_mean_minus_max",
      "v45_c_trial_median_minus_max",
      "v45_c_trial_median_minus_mean"
    ),
    term = c(
      "L100_max", "L100_mean", "L100_median",
      "beta_mean_minus_beta_max",
      "beta_median_minus_beta_max",
      "beta_median_minus_beta_mean"
    ),
    MCE_trigger = TRUE,
    stringsAsFactors = FALSE
  )
}

v45c_trial_one_imputation <- function(
    mids, imputation, replicate_indices, context,
    prefix_result = NULL) {
  completed <- mice::complete(mids, action = imputation)
  person <- v45c_prepare_person(
    completed, context$ledger, context$actual, context$v43, "MI-C0"
  )
  trial <- as.matrix(person[c(
    "pef_w1_trial1", "pef_w1_trial2", "pef_w1_trial3"
  )])
  storage.mode(trial) <- "double"
  member <- apply(trial, 1L, function(value) {
    all(is.finite(value) & value >= 30 & value <= 890)
  })
  period <- v45c_build_period(
    person, context$ledger, context$actual, member
  )
  v45c_assert_anchor(
    period, 12512L, 1722L, 45358L, 433L,
    paste0("trial imp", imputation)
  )
  exposures <- c("L100_max", "L100_mean", "L100_median")
  formulas <- lapply(
    exposures, function(exposure) {
      v45c_formula("F_TRIAL_L100_A1", exposure)
    }
  )
  caches <- lapply(seq_along(exposures), function(index) {
    v45c_build_glm_cache(
      period, formulas[[index]], exposures[[index]],
      paste0("trial_", exposures[[index]], "_imp", imputation)
    )
  })
  if (is.null(prefix_result)) {
    point_fit <- lapply(seq_along(exposures), function(index) {
      v45c_fit_cloglog(
        period, period$weight_biomarker_w1,
        formulas[[index]], exposures[[index]],
        paste0("trial_point_", exposures[[index]], "_imp", imputation),
        point_survey = TRUE
      )
    })
    base_point <- setNames(
      vapply(point_fit, function(fit) fit$coefficients[[1L]], numeric(1)),
      c("trial_max", "trial_mean", "trial_median")
    )
    point <- c(
      base_point,
      trial_mean_minus_max =
        base_point[["trial_mean"]] - base_point[["trial_max"]],
      trial_median_minus_max =
        base_point[["trial_median"]] - base_point[["trial_max"]],
      trial_median_minus_mean =
        base_point[["trial_median"]] - base_point[["trial_mean"]]
    )
  } else {
    point <- prefix_result$groups$TRIAL_ALL_THREE$point
  }
  replicate_names <- v45c_literal_replicate_names(replicate_indices)
  replicates <- matrix(
    NA_real_, nrow = length(replicate_indices), ncol = length(point),
    dimnames = list(replicate_names, names(point))
  )
  failures <- character(length(replicate_indices))
  for (row in seq_along(replicate_indices)) {
    replicate_index <- replicate_indices[[row]]
    weight <- period$weight_biomarker_w1 *
      v45c_replicate_multiplier(
        period$community_id, context$actual$modules$trial,
        replicate_index
      )
    attempt <- v45c_try_replicate_fit({
      base <- setNames(vapply(
        seq_along(caches), function(index) {
          v45c_fit_cached_glm(
            caches[[index]], weight,
            paste0(
              "trial_", exposures[[index]], "_imp", imputation,
              "_", replicate_names[[row]]
            )
          )$coefficients[[1L]]
        }, numeric(1)
      ), c("trial_max", "trial_mean", "trial_median"))
      c(
        base,
        trial_mean_minus_max =
          base[["trial_mean"]] - base[["trial_max"]],
        trial_median_minus_max =
          base[["trial_median"]] - base[["trial_max"]],
        trial_median_minus_mean =
          base[["trial_median"]] - base[["trial_mean"]]
      )
    }, length(point), names(point))
    replicates[row, ] <- attempt$value
    failures[[row]] <- attempt$failure_class
  }
  if (is.null(prefix_result)) {
    group <- v45c_make_group(
      "TRIAL_ALL_THREE", point, replicates, 432, failures,
      compute_covariance = FALSE
    )
  } else {
    group <- v45c_extend_group(
      prefix_result$groups$TRIAL_ALL_THREE,
      replicates, failures
    )
  }
  rm(completed, person, period, caches)
  list(
    imputation = as.integer(imputation),
    groups = list(TRIAL_ALL_THREE = group),
    sample_anchors = data.frame(
      sample_id = "charls_w1_complete_three",
      imputation = as.integer(imputation),
      n = 12512L, events_or_responses = 1722L,
      period_rows = 45358L, psu = 433L, dfcom = 432L,
      stringsAsFactors = FALSE
    )
  )
}

v45c_inconsistency_scalar_map <- function() {
  data.frame(
    group_id = c(
      "INCONSISTENCY_LINEAR", "INCONSISTENCY_LINEAR",
      "INCONSISTENCY_BOUNDARY", "INCONSISTENCY_BOUNDARY"
    ),
    column = c(
      "linear_C100_median", "linear_I_z",
      "boundary_C100_median", "boundary_I_z"
    ),
    analysis_id = c(
      "v45_c_inconsistency_a1", "v45_c_inconsistency_a1",
      "v45_c_inconsistency_boundary_a1",
      "v45_c_inconsistency_boundary_a1"
    ),
    term = c("C100_median", "I_z", "C100_median", "I_z"),
    MCE_trigger = TRUE,
    stringsAsFactors = FALSE
  )
}

v45c_inconsistency_joint_definitions <- function() {
  list(
    list(
      test_id = "v45_c_inconsistency_spline_a1_overall",
      group_id = "INCONSISTENCY_SPLINE",
      columns = c(
        "spline_I_z_linear",
        "spline_I_z_nonlinear1",
        "spline_I_z_nonlinear2"
      )
    ),
    list(
      test_id = "v45_c_inconsistency_spline_joint_nonlinear",
      group_id = "INCONSISTENCY_SPLINE",
      columns = c(
        "spline_I_z_nonlinear1",
        "spline_I_z_nonlinear2"
      )
    )
  )
}

v45c_inconsistency_one_imputation <- function(
    mids, imputation, replicate_indices, context,
    prefix_result = NULL) {
  completed <- mice::complete(mids, action = imputation)
  person <- v45c_prepare_person(
    completed, context$ledger, context$actual, context$v43, "MI-C0"
  )
  trial <- as.matrix(person[c(
    "pef_w1_trial1", "pef_w1_trial2", "pef_w1_trial3"
  )])
  storage.mode(trial) <- "double"
  member <- apply(trial, 1L, function(value) {
    all(is.finite(value) & value >= 30 & value <= 890)
  })
  no_boundary <- member & !apply(trial, 1L, function(value) {
    any(value == 30 | value == 890)
  })
  top_difference <- apply(trial, 1L, function(value) {
    if (!all(is.finite(value) & value >= 30 & value <= 890)) {
      return(NA_real_)
    }
    value <- sort(value, decreasing = TRUE)
    value[[1L]] - value[[2L]]
  })
  person$I_raw <- log1p(top_difference)
  person$I_z <- (
    person$I_raw - 2.6645548501904162
  ) / 1.4405336275941463
  i_knots <- data.frame(
    weighted_q05 = -1.8496998606277060,
    weighted_q35 = -0.1851116643749560,
    weighted_q65 = 0.5341300887087024,
    weighted_q95 = 1.2816810527429137
  )
  i_basis <- context$v43$restricted_cubic_basis(
    person$I_z, i_knots, "I_z"
  )
  person <- cbind(person, i_basis)
  period <- v45c_build_period(
    person, context$ledger, context$actual, member
  )
  boundary_period <- v45c_build_period(
    person, context$ledger, context$actual, no_boundary
  )
  v45c_assert_anchor(
    period, 12512L, 1722L, 45358L, 433L,
    paste0("inconsistency imp", imputation)
  )
  v45c_assert_anchor(
    boundary_period, 12235L, 1632L, 44456L, 432L,
    paste0("inconsistency boundary imp", imputation)
  )
  formulas <- list(
    linear = v45c_formula("F_INCONSISTENCY_LINEAR_A1"),
    spline = v45c_formula("F_INCONSISTENCY_SPLINE_A1"),
    boundary = v45c_formula("F_INCONSISTENCY_LINEAR_A1")
  )
  focal <- list(
    linear = c("C100_median", "I_z"),
    spline = c(
      "C100_median", "I_z_linear",
      "I_z_nonlinear1", "I_z_nonlinear2"
    ),
    boundary = c("C100_median", "I_z")
  )
  caches <- list(
    linear = v45c_build_glm_cache(
      period, formulas$linear, focal$linear,
      paste0("inconsistency_linear_imp", imputation)
    ),
    spline = v45c_build_glm_cache(
      period, formulas$spline, focal$spline,
      paste0("inconsistency_spline_imp", imputation)
    ),
    boundary = v45c_build_glm_cache(
      boundary_period, formulas$boundary, focal$boundary,
      paste0("inconsistency_boundary_imp", imputation)
    )
  )
  semantic_names <- list(
    linear = c("linear_C100_median", "linear_I_z"),
    spline = c(
      "spline_C100_median", "spline_I_z_linear",
      "spline_I_z_nonlinear1", "spline_I_z_nonlinear2"
    ),
    boundary = c("boundary_C100_median", "boundary_I_z")
  )
  if (is.null(prefix_result)) {
    point_linear <- v45c_fit_cloglog(
      period, period$weight_biomarker_w1,
      formulas$linear, focal$linear,
      paste0("inconsistency_linear_point_imp", imputation),
      point_survey = TRUE
    )$coefficients
    point_spline <- v45c_fit_cloglog(
      period, period$weight_biomarker_w1,
      formulas$spline, focal$spline,
      paste0("inconsistency_spline_point_imp", imputation),
      point_survey = TRUE
    )$coefficients
    point_boundary <- v45c_fit_cloglog(
      boundary_period, boundary_period$weight_biomarker_w1,
      formulas$boundary, focal$boundary,
      paste0("inconsistency_boundary_point_imp", imputation),
      point_survey = TRUE
    )$coefficients
    names(point_linear) <- semantic_names$linear
    names(point_spline) <- semantic_names$spline
    names(point_boundary) <- semantic_names$boundary
    point <- list(
      linear = point_linear,
      spline = point_spline,
      boundary = point_boundary
    )
  } else {
    point <- list(
      linear =
        prefix_result$groups$INCONSISTENCY_LINEAR$point,
      spline =
        prefix_result$groups$INCONSISTENCY_SPLINE$point,
      boundary =
        prefix_result$groups$INCONSISTENCY_BOUNDARY$point
    )
  }
  replicate_names <- v45c_literal_replicate_names(replicate_indices)
  replicate_matrices <- lapply(point, function(value) {
    matrix(
      NA_real_, nrow = length(replicate_indices),
      ncol = length(value),
      dimnames = list(replicate_names, names(value))
    )
  })
  failures <- lapply(point, function(value) {
    character(length(replicate_indices))
  })
  for (row in seq_along(replicate_indices)) {
    replicate_index <- replicate_indices[[row]]
    weight <- period$weight_biomarker_w1 *
      v45c_replicate_multiplier(
        period$community_id, context$actual$modules$trial,
        replicate_index
      )
    boundary_weight <- boundary_period$weight_biomarker_w1 *
      v45c_replicate_multiplier(
        boundary_period$community_id,
        context$actual$modules$trial, replicate_index
      )
    for (fit_id in c("linear", "spline", "boundary")) {
      local_weight <- if (fit_id == "boundary") {
        boundary_weight
      } else {
        weight
      }
      attempt <- v45c_try_replicate_fit({
        value <- v45c_fit_cached_glm(
          caches[[fit_id]], local_weight,
          paste0(
            "inconsistency_", fit_id, "_imp", imputation,
            "_", replicate_names[[row]]
          )
        )$coefficients
        names(value) <- semantic_names[[fit_id]]
        value
      }, length(point[[fit_id]]), names(point[[fit_id]]))
      replicate_matrices[[fit_id]][row, ] <- attempt$value
      failures[[fit_id]][[row]] <- attempt$failure_class
    }
  }
  if (is.null(prefix_result)) {
    groups <- list(
      INCONSISTENCY_LINEAR = v45c_make_group(
        "INCONSISTENCY_LINEAR", point$linear,
        replicate_matrices$linear, 432, failures$linear,
        compute_covariance = FALSE
      ),
      INCONSISTENCY_SPLINE = v45c_make_group(
        "INCONSISTENCY_SPLINE", point$spline,
        replicate_matrices$spline, 432, failures$spline,
        compute_covariance = FALSE
      ),
      INCONSISTENCY_BOUNDARY = v45c_make_group(
        "INCONSISTENCY_BOUNDARY", point$boundary,
        replicate_matrices$boundary, 431, failures$boundary,
        compute_covariance = FALSE
      )
    )
  } else {
    groups <- list(
      INCONSISTENCY_LINEAR = v45c_extend_group(
        prefix_result$groups$INCONSISTENCY_LINEAR,
        replicate_matrices$linear, failures$linear
      ),
      INCONSISTENCY_SPLINE = v45c_extend_group(
        prefix_result$groups$INCONSISTENCY_SPLINE,
        replicate_matrices$spline, failures$spline
      ),
      INCONSISTENCY_BOUNDARY = v45c_extend_group(
        prefix_result$groups$INCONSISTENCY_BOUNDARY,
        replicate_matrices$boundary, failures$boundary
      )
    )
  }
  rm(completed, person, period, boundary_period, caches)
  list(
    imputation = as.integer(imputation), groups = groups,
    sample_anchors = data.frame(
      sample_id = c(
        "charls_w1_complete_three",
        "charls_w1_complete_three_no_trial_boundary"
      ),
      imputation = as.integer(imputation),
      n = c(12512L, 12235L),
      events_or_responses = c(1722L, 1632L),
      period_rows = c(45358L, 44456L),
      psu = c(433L, 432L), dfcom = c(432L, 431L),
      stringsAsFactors = FALSE
    )
  )
}

v45c_adjacent_scalar_map <- function() {
  data.frame(
    group_id = "ADJACENT_PAIRED",
    column = c("adjacent_all", "adjacent_only", "adjacent_delta"),
    analysis_id = c(
      "v45_c_adjacent_all_a1",
      "v45_c_adjacent_only_a1",
      "v45_c_adjacent_delta"
    ),
    term = c("E0", "E0", "beta_adjacent_minus_beta_all"),
    MCE_trigger = TRUE,
    stringsAsFactors = FALSE
  )
}

v45c_adjacent_one_imputation <- function(
    mids, imputation, replicate_indices, context,
    prefix_result = NULL) {
  completed <- mice::complete(mids, action = imputation)
  person <- v45c_prepare_person(
    completed, context$ledger, context$actual, context$v43, "MI-C0"
  )
  all_member <- rep(TRUE, nrow(person))
  all_period <- v45c_build_period(
    person, context$ledger, context$actual, all_member
  )
  adjacent_period <- v45c_build_period(
    person, context$ledger, context$actual, all_member,
    adjacent = TRUE
  )
  v45c_assert_anchor(
    all_period, 12555L, 1735L, 45503L, 433L,
    paste0("adjacent all imp", imputation)
  )
  v45c_assert_anchor(
    adjacent_period, 12427L, 1539L, 44778L, 432L,
    paste0("adjacent only imp", imputation)
  )
  formula <- v45c_formula("F_ADJACENT_E0_A1")
  caches <- list(
    all = v45c_build_glm_cache(
      all_period, formula, "E0",
      paste0("adjacent_all_imp", imputation)
    ),
    adjacent = v45c_build_glm_cache(
      adjacent_period, formula, "E0",
      paste0("adjacent_only_imp", imputation)
    )
  )
  if (is.null(prefix_result)) {
    beta_all <- v45c_fit_cloglog(
      all_period, all_period$weight_biomarker_w1,
      formula, "E0",
      paste0("adjacent_all_point_imp", imputation),
      point_survey = TRUE
    )$coefficients[[1L]]
    beta_adjacent <- v45c_fit_cloglog(
      adjacent_period, adjacent_period$weight_biomarker_w1,
      formula, "E0",
      paste0("adjacent_only_point_imp", imputation),
      point_survey = TRUE
    )$coefficients[[1L]]
    point <- c(
      adjacent_all = beta_all,
      adjacent_only = beta_adjacent,
      adjacent_delta = beta_adjacent - beta_all
    )
  } else {
    point <- prefix_result$groups$ADJACENT_PAIRED$point
  }
  replicate_names <- v45c_literal_replicate_names(replicate_indices)
  replicates <- matrix(
    NA_real_, nrow = length(replicate_indices),
    ncol = length(point),
    dimnames = list(replicate_names, names(point))
  )
  failures <- character(length(replicate_indices))
  for (row in seq_along(replicate_indices)) {
    replicate_index <- replicate_indices[[row]]
    all_weight <- all_period$weight_biomarker_w1 *
      v45c_replicate_multiplier(
        all_period$community_id,
        context$actual$modules$adjacent, replicate_index
      )
    adjacent_weight <- adjacent_period$weight_biomarker_w1 *
      v45c_replicate_multiplier(
        adjacent_period$community_id,
        context$actual$modules$adjacent, replicate_index
      )
    attempt <- v45c_try_replicate_fit({
      beta_all <- v45c_fit_cached_glm(
        caches$all, all_weight,
        paste0(
          "adjacent_all_imp", imputation, "_",
          replicate_names[[row]]
        )
      )$coefficients[[1L]]
      beta_adjacent <- v45c_fit_cached_glm(
        caches$adjacent, adjacent_weight,
        paste0(
          "adjacent_only_imp", imputation, "_",
          replicate_names[[row]]
        )
      )$coefficients[[1L]]
      c(
        adjacent_all = beta_all,
        adjacent_only = beta_adjacent,
        adjacent_delta = beta_adjacent - beta_all
      )
    }, length(point), names(point))
    replicates[row, ] <- attempt$value
    failures[[row]] <- attempt$failure_class
  }
  group <- if (is.null(prefix_result)) {
    v45c_make_group(
      "ADJACENT_PAIRED", point, replicates,
      c(
        adjacent_all = 432,
        adjacent_only = 431,
        adjacent_delta = 431
      ),
      failures,
      compute_covariance = FALSE
    )
  } else {
    v45c_extend_group(
      prefix_result$groups$ADJACENT_PAIRED,
      replicates, failures
    )
  }
  rm(completed, person, all_period, adjacent_period, caches)
  list(
    imputation = as.integer(imputation),
    groups = list(ADJACENT_PAIRED = group),
    sample_anchors = data.frame(
      sample_id = c(
        "charls_primary_all_windows",
        "charls_primary_adjacent_windows"
      ),
      imputation = as.integer(imputation),
      n = c(12555L, 12427L),
      events_or_responses = c(1735L, 1539L),
      period_rows = c(45503L, 44778L),
      psu = c(433L, 432L), dfcom = c(432L, 431L),
      stringsAsFactors = FALSE
    )
  )
}

v45c_timehet_scalar_map <- function() {
  data.frame(
    group_id = "TIME_HETEROGENEITY",
    column = c(
      "E0_at_end_wave_2", "E0_at_end_wave_3",
      "E0_at_end_wave_4", "E0_at_end_wave_5"
    ),
    analysis_id = "v45_c_time_heterogeneity_joint",
    term = c(
      "E0_at_end_wave_2", "E0_at_end_wave_3",
      "E0_at_end_wave_4", "E0_at_end_wave_5"
    ),
    MCE_trigger = TRUE,
    stringsAsFactors = FALSE
  )
}

v45c_timehet_joint_definitions <- function() {
  list(list(
    test_id = "v45_c_time_heterogeneity_joint",
    group_id = "TIME_HETEROGENEITY",
    columns = c(
      "E0_by_end_wave_3",
      "E0_by_end_wave_4",
      "E0_by_end_wave_5"
    )
  ))
}

v45c_timehet_expand <- function(coefficients) {
  required <- c(
    "E0", "E0:factor(end_wave)3",
    "E0:factor(end_wave)4", "E0:factor(end_wave)5"
  )
  if (!identical(names(coefficients), required)) {
    stop("Time-heterogeneity coefficient order drifted.",
         call. = FALSE)
  }
  base <- coefficients[[1L]]
  c(
    E0_by_end_wave_3 = coefficients[[2L]],
    E0_by_end_wave_4 = coefficients[[3L]],
    E0_by_end_wave_5 = coefficients[[4L]],
    E0_at_end_wave_2 = base,
    E0_at_end_wave_3 = base + coefficients[[2L]],
    E0_at_end_wave_4 = base + coefficients[[3L]],
    E0_at_end_wave_5 = base + coefficients[[4L]]
  )
}

v45c_timehet_one_imputation <- function(
    mids, imputation, replicate_indices, context,
    prefix_result = NULL) {
  completed <- mice::complete(mids, action = imputation)
  person <- v45c_prepare_person(
    completed, context$ledger, context$actual, context$v43, "MI-C0"
  )
  period <- v45c_build_period(
    person, context$ledger, context$actual, rep(TRUE, nrow(person))
  )
  v45c_assert_anchor(
    period, 12555L, 1735L, 45503L, 433L,
    paste0("time heterogeneity imp", imputation)
  )
  formula <- v45c_formula("F_TIME_HETEROGENEITY_A1")
  focal <- c(
    "E0", "E0:factor(end_wave)3",
    "E0:factor(end_wave)4", "E0:factor(end_wave)5"
  )
  cache <- v45c_build_glm_cache(
    period, formula, focal,
    paste0("timehet_imp", imputation)
  )
  if (is.null(prefix_result)) {
    point_raw <- v45c_fit_cloglog(
      period, period$weight_biomarker_w1,
      formula, focal,
      paste0("timehet_point_imp", imputation),
      point_survey = TRUE
    )$coefficients
    point <- v45c_timehet_expand(point_raw)
  } else {
    point <- prefix_result$groups$TIME_HETEROGENEITY$point
  }
  replicate_names <- v45c_literal_replicate_names(replicate_indices)
  replicates <- matrix(
    NA_real_, nrow = length(replicate_indices),
    ncol = length(point),
    dimnames = list(replicate_names, names(point))
  )
  failures <- character(length(replicate_indices))
  for (row in seq_along(replicate_indices)) {
    replicate_index <- replicate_indices[[row]]
    weight <- period$weight_biomarker_w1 *
      v45c_replicate_multiplier(
        period$community_id,
        context$actual$modules$adjacent, replicate_index
      )
    attempt <- v45c_try_replicate_fit({
      raw <- v45c_fit_cached_glm(
        cache, weight,
        paste0(
          "timehet_imp", imputation, "_",
          replicate_names[[row]]
        )
      )$coefficients
      v45c_timehet_expand(raw)
    }, length(point), names(point))
    replicates[row, ] <- attempt$value
    failures[[row]] <- attempt$failure_class
  }
  group <- if (is.null(prefix_result)) {
    v45c_make_group(
      "TIME_HETEROGENEITY", point, replicates, 432, failures,
      compute_covariance = FALSE
    )
  } else {
    v45c_extend_group(
      prefix_result$groups$TIME_HETEROGENEITY,
      replicates, failures
    )
  }
  rm(completed, person, period, cache)
  list(
    imputation = as.integer(imputation),
    groups = list(TIME_HETEROGENEITY = group),
    sample_anchors = data.frame(
      sample_id = "charls_primary_all_windows",
      imputation = as.integer(imputation),
      n = 12555L, events_or_responses = 1735L,
      period_rows = 45503L, psu = 433L, dfcom = 432L,
      stringsAsFactors = FALSE
    )
  )
}

v45c_anchor_one_imputation <- function(mids, imputation, context) {
  completed <- mice::complete(mids, action = imputation)
  v44_completed <- v45c_rebuild_completed_bmi(
    completed, "MI-C0 inherited v44 anchor"
  )
  v44_person <- context$v43$attach_passive_variables(
    v44_completed, context$ledger$spline_knots
  )
  v44_formula <- context$v43$model_formulas("E0", FALSE)$A1
  v44_fit <- context$v43$fit_one_survey_model(
    v44_person, context$ledger$person_period_skeleton,
    v44_formula,
    paste0("v44_anchor_imp", imputation)
  )
  v44_beta <- unname(v44_fit$coefficients[["E0"]])

  v45_person <- v45c_prepare_person(
    completed, context$ledger, context$actual, context$v43, "MI-C0"
  )
  v45_period <- v45c_build_period(
    v45_person, context$ledger, context$actual,
    rep(TRUE, nrow(v45_person))
  )
  v45c_assert_anchor(
    v45_period, 12555L, 1735L, 45503L, 433L,
    paste0("legacy anchor imp", imputation)
  )
  v45_beta <- v45c_fit_cloglog(
    v45_period, v45_period$weight_biomarker_w1,
    v45c_formula("F_ADJACENT_E0_A1"), "E0",
    paste0("v45_anchor_imp", imputation),
    point_survey = TRUE
  )$coefficients[[1L]]
  rm(
    completed, v44_completed, v44_person, v44_fit,
    v45_person, v45_period
  )
  list(
    imputation = as.integer(imputation),
    v44_beta = v44_beta,
    v45_beta = v45_beta,
    absolute_difference = abs(v44_beta - v45_beta)
  )
}

v45c_anchor_object <- function(results) {
  if (length(results) != 50L ||
      !identical(
        vapply(results, `[[`, integer(1), "imputation"),
        seq_len(50L)
      )) {
    stop("Legacy anchor lacks exact m=50.", call. = FALSE)
  }
  v44 <- vapply(results, `[[`, numeric(1), "v44_beta")
  v45 <- vapply(results, `[[`, numeric(1), "v45_beta")
  public_qbar <- 0.354509670529553
  tolerance <- 1e-8
  finite <- all(is.finite(v44)) && all(is.finite(v45))
  pass <- finite &&
    all(abs(v44 - v45) <= tolerance) &&
    abs(mean(v44) - mean(v45)) <= tolerance &&
    abs(mean(v44) - public_qbar) <= tolerance &&
    abs(mean(v45) - public_qbar) <= tolerance
  list(
    gate = if (pass) "PASS" else "FAIL",
    tolerance = tolerance,
    public_v44_Qbar = public_qbar,
    failure_class = if (pass) {
      ""
    } else if (!finite) {
      "ANCHOR_VALUE_INVALID"
    } else {
      "ANCHOR_IDENTITY_MISMATCH"
    },
    failure_reason = if (pass) {
      ""
    } else if (!finite) {
      "The restricted v44/v45 anchor contained a non-finite value."
    } else {
      paste0(
        "The restricted v44/v45 per-imputation or pooled-Qbar ",
        "identity tolerance was not met."
      )
    },
    failure_summary = data.frame(
      failure_class = character(),
      affected_imputations = character(),
      affected_imputation_count = integer(),
      stringsAsFactors = FALSE
    ),
    per_imputation = data.frame(
      imputation = seq_len(50L),
      v44_beta = v44,
      v45_beta = v45,
      absolute_difference = abs(v44 - v45),
      stringsAsFactors = FALSE
    ),
    computed_v44_Qbar = mean(v44),
    computed_v45_Qbar = mean(v45),
    maximum_absolute_difference = max(abs(v44 - v45)),
    comparison_role = "point_estimate_only_sidecar_gate",
    Rao_Wu_SE_identity_required = FALSE,
    partial_imputation_results_retained = FALSE,
    coefficient_or_direction_in_failure_record = !pass
  )
}

v45c_weighted_mean <- function(value, weight) {
  value <- as.numeric(value)
  weight <- as.numeric(weight)
  usable <- is.finite(value) & is.finite(weight) & weight > 0
  if (!any(usable)) return(NA_real_)
  sum(value[usable] * weight[usable]) / sum(weight[usable])
}

v45c_weighted_population_variance <- function(value, weight) {
  center <- v45c_weighted_mean(value, weight)
  usable <- is.finite(value) & is.finite(weight) & weight > 0
  if (!is.finite(center) || !any(usable)) return(NA_real_)
  sum(weight[usable] * (value[usable] - center)^2) /
    sum(weight[usable])
}

v45c_kish_ess <- function(weight) {
  weight <- as.numeric(weight)
  weight <- weight[is.finite(weight) & weight > 0]
  if (!length(weight)) return(NA_real_)
  sum(weight)^2 / sum(weight^2)
}

v45c_w2_response_cache <- function(person, base_weight, cache_id) {
  grip <- v45c_numeric_code(person$grip_kg_w1)
  center <- v45c_weighted_mean(grip, base_weight)
  if (!is.finite(center)) {
    v45c_numeric_failure(
      paste0(cache_id, " grip center is invalid."),
      "GRIP_CENTER_INVALID"
    )
  }
  person$grip_c_5kg <- (grip - center) / 5
  cache <- v45c_build_glm_cache(
    person, v45c_response_formula(), "ageW2_ns1",
    cache_id, family = "logit"
  )
  list(cache = cache, grip = grip, initial_center = center)
}

v45c_update_response_grip <- function(
    response_cache, grip, current_base_weight) {
  center <- v45c_weighted_mean(grip, current_base_weight)
  if (!is.finite(center)) {
    v45c_numeric_failure(
      "W2 replicate grip center is invalid.",
      "GRIP_CENTER_INVALID"
    )
  }
  v45c_cached_matrix_column(
    response_cache, "grip_c_5kg", (grip - center) / 5
  )
}

v45c_w2_diagnostics <- function(
    probability, respondent, current_base_weight, balance_matrix) {
  probability <- as.numeric(probability)
  respondent <- as.logical(respondent)
  current_base_weight <- as.numeric(current_base_weight)
  balance_matrix <- as.matrix(balance_matrix)
  if (is.null(colnames(balance_matrix)) ||
      length(colnames(balance_matrix)) != ncol(balance_matrix) ||
      anyNA(colnames(balance_matrix)) ||
      any(!nzchar(colnames(balance_matrix))) ||
      anyDuplicated(colnames(balance_matrix))) {
    stop(
      "W2 balance-matrix column-name interface is invalid.",
      call. = FALSE
    )
  }
  if (length(probability) != length(respondent) ||
      length(probability) != length(current_base_weight) ||
      nrow(balance_matrix) != length(probability) ||
      anyNA(respondent) ||
      any(!is.finite(probability) |
          probability <= 0 | probability >= 1) ||
      any(!is.finite(current_base_weight) |
          current_base_weight < 0) ||
      sum(current_base_weight > 0) < 100L ||
      any(!is.finite(balance_matrix))) {
    v45c_numeric_failure(
      "W2 response diagnostics received invalid input.",
      "W2_DIAGNOSTIC_INPUT"
    )
  }
  availability <- 1 / probability[respondent]
  cap_p99 <- as.numeric(stats::quantile(
    availability, 0.99, names = FALSE, type = 7
  ))
  cap_p97_5 <- as.numeric(stats::quantile(
    availability, 0.975, names = FALSE, type = 7
  ))
  raw <- list(
    uncapped = availability,
    p99 = pmin(availability, cap_p99),
    p97_5 = pmin(availability, cap_p97_5)
  )
  factor <- lapply(raw, function(value) {
    v45c_w2_normalize_factor(
      value, respondent, current_base_weight
    )
  })
  original_respondent_weight <- current_base_weight[respondent]
  composite <- original_respondent_weight * factor$uncapped
  ess_ratio <- v45c_kish_ess(composite) /
    v45c_kish_ess(original_respondent_weight)

  target_mean <- apply(
    balance_matrix, 2L, v45c_weighted_mean,
    weight = current_base_weight
  )
  target_variance <- apply(
    balance_matrix, 2L, v45c_weighted_population_variance,
    weight = current_base_weight
  )
  target_sd <- sqrt(target_variance)
  structurally_constant <- vapply(seq_len(ncol(balance_matrix)), function(j) {
    value <- balance_matrix[current_base_weight > 0, j]
    length(unique(value)) == 1L
  }, logical(1))
  invalid_sd <- !is.finite(target_sd) | target_sd <= 0
  if (any(invalid_sd & !structurally_constant)) {
    v45c_numeric_failure(
      "W2 balance target has non-structural zero/nonfinite SD.",
      "BALANCE_TARGET_SD_INVALID"
    )
  }
  use <- !invalid_sd
  respondent_mean <- apply(
    balance_matrix[respondent, use, drop = FALSE],
    2L, v45c_weighted_mean, weight = composite
  )
  smd <- (
    respondent_mean - target_mean[use]
  ) / target_sd[use]
  maximum_absolute_smd <- if (length(smd)) {
    max(abs(smd))
  } else {
    0
  }
  metrics <- c(
    response_probability_p01 = as.numeric(stats::quantile(
      probability, 0.01, names = FALSE, type = 7
    )),
    availability_factor_p99 = as.numeric(stats::quantile(
      availability, 0.99, names = FALSE, type = 7
    )),
    ESS_ratio = ess_ratio,
    maximum_absolute_SMD = maximum_absolute_smd
  )
  statuses <- c(
    response_probability_p01 = v45c_gate_three_level(
      metrics[["response_probability_p01"]],
      go = function(x) x >= 0.05,
      stop = function(x) x <= 0.01
    ),
    availability_factor_p99 = v45c_gate_three_level(
      metrics[["availability_factor_p99"]],
      go = function(x) x <= 10,
      stop = function(x) x > 20
    ),
    ESS_ratio = v45c_gate_three_level(
      metrics[["ESS_ratio"]],
      go = function(x) x >= 0.50,
      stop = function(x) x < 0.30
    ),
    maximum_absolute_SMD = v45c_gate_three_level(
      metrics[["maximum_absolute_SMD"]],
      go = function(x) x <= 0.10,
      stop = function(x) x > 0.20
    )
  )
  overall <- if (any(statuses == "STOP")) {
    "STOP"
  } else if (any(statuses == "CAUTION")) {
    "CAUTION"
  } else {
    "GO"
  }
  list(
    factors = factor,
    compact = data.frame(
      response_probability_p01 =
        metrics[["response_probability_p01"]],
      availability_factor_p99 =
        metrics[["availability_factor_p99"]],
      ESS_ratio = metrics[["ESS_ratio"]],
      maximum_absolute_SMD =
        metrics[["maximum_absolute_SMD"]],
      cap_p99 = cap_p99,
      cap_p97_5 = cap_p97_5,
      structurally_constant_balance_columns =
        sum(structurally_constant),
      structurally_constant_balance_column_names =
        paste(
          colnames(balance_matrix)[structurally_constant],
          collapse = "|"
        ),
      response_probability_status =
        statuses[["response_probability_p01"]],
      availability_factor_status =
        statuses[["availability_factor_p99"]],
      ESS_status = statuses[["ESS_ratio"]],
      maximum_absolute_SMD_status =
        statuses[["maximum_absolute_SMD"]],
      overall_status = overall,
      stringsAsFactors = FALSE
    )
  )
}

v45c_w2_response_once <- function(
    response_cache, grip, current_base_weight, respondent,
    model_id) {
  cache <- v45c_update_response_grip(
    response_cache, grip, current_base_weight
  )
  fit <- v45c_fit_cached_glm(
    cache, current_base_weight, model_id,
    return_fitted = TRUE
  )
  balance <- v45c_named_balance_matrix(cache)
  diagnostic <- v45c_w2_diagnostics(
    fit$fitted, respondent, current_base_weight, balance
  )
  list(
    factors = diagnostic$factors,
    diagnostic = diagnostic$compact
  )
}

v45c_named_balance_matrix <- function(cache) {
  if (!is.list(cache) || !is.matrix(cache$matrix) ||
      !is.character(cache$matrix_names) ||
      length(cache$matrix_names) != ncol(cache$matrix) ||
      anyNA(cache$matrix_names) ||
      any(!nzchar(cache$matrix_names)) ||
      anyDuplicated(cache$matrix_names)) {
    stop("W2 cached balance-matrix interface is invalid.",
         call. = FALSE)
  }
  use <- cache$matrix_names != "(Intercept)"
  if (!any(use)) {
    stop("W2 cached balance matrix has no non-intercept columns.",
         call. = FALSE)
  }
  balance <- cache$matrix[, use, drop = FALSE]
  colnames(balance) <- cache$matrix_names[use]
  balance
}

v45c_w2_scalar_map <- function() {
  data.frame(
    group_id = c(
      "W2_ORIGINAL_E0_W1", "W2_ORIGINAL_E0_W2",
      rep("W2_M12_ALL_VARIANTS", 4),
      rep("W2_ORIGINAL_M12_D12", 2),
      "W2_C3_ORIGINAL_MAX", "W2_C3_ORIGINAL_MEAN",
      "W2_C3_ORIGINAL_MEDIAN",
      "W2_UNCAPPED_E0_W1", "W2_UNCAPPED_E0_W2",
      rep("W2_UNCAPPED_M12_D12", 2)
    ),
    column = c(
      "w2_w1_original", "w2_w2_original",
      "w2_m12_original", "w2_m12_uncapped",
      "w2_m12_p99", "w2_m12_p97_5",
      "w2_m12_d12_original_M12",
      "w2_m12_d12_original_D12",
      "w2_m12_max_c3_original",
      "w2_m12_mean_c3_original",
      "w2_m12_median_c3_original",
      "w2_w1_uncapped", "w2_w2_uncapped",
      "w2_m12_d12_uncapped_M12",
      "w2_m12_d12_uncapped_D12"
    ),
    analysis_id = c(
      "v45_c_w2_w1_original", "v45_c_w2_w2_original",
      "v45_c_w2_m12_original", "v45_c_w2_m12_uncapped",
      "v45_c_w2_m12_p99", "v45_c_w2_m12_p97_5",
      "v45_c_w2_m12_d12_original",
      "v45_c_w2_m12_d12_original",
      "v45_c_w2_m12_max_c3_original",
      "v45_c_w2_m12_mean_c3_original",
      "v45_c_w2_m12_median_c3_original",
      "v45_c_w2_w1_uncapped", "v45_c_w2_w2_uncapped",
      "v45_c_w2_m12_d12_uncapped",
      "v45_c_w2_m12_d12_uncapped"
    ),
    term = c(
      "E0_W1", "E0_W2",
      "M12", "M12", "M12", "M12",
      "M12", "D12",
      "M12_max", "M12_mean", "M12_median",
      "E0_W1", "E0_W2", "M12", "D12"
    ),
    MCE_trigger = TRUE,
    stringsAsFactors = FALSE
  )
}

v45c_w2_cache_specs <- function() {
  list(
    original_w1 = list(
      formula = v45c_formula("F_W2_SINGLE_A1", "E0_W1"),
      focal = "E0_W1", sample = "r2"
    ),
    original_w2 = list(
      formula = v45c_formula("F_W2_SINGLE_A1", "E0_W2"),
      focal = "E0_W2", sample = "r2"
    ),
    m12 = list(
      formula = v45c_formula("F_W2_SINGLE_A1", "M12"),
      focal = "M12", sample = "r2"
    ),
    m12_d12 = list(
      formula = v45c_formula("F_W2_M12_D12_A1"),
      focal = c("M12", "D12"), sample = "r2"
    ),
    c3_max = list(
      formula = v45c_formula("F_W2_SINGLE_A1", "M12_max"),
      focal = "M12_max", sample = "c3"
    ),
    c3_mean = list(
      formula = v45c_formula("F_W2_SINGLE_A1", "M12_mean"),
      focal = "M12_mean", sample = "c3"
    ),
    c3_median = list(
      formula = v45c_formula(
        "F_W2_SINGLE_A1", "M12_median"
      ),
      focal = "M12_median", sample = "c3"
    )
  )
}

v45c_w2_build_caches <- function(r2_period, c3_period, imputation) {
  specs <- v45c_w2_cache_specs()
  lapply(names(specs), function(name) {
    spec <- specs[[name]]
    data <- if (spec$sample == "c3") c3_period else r2_period
    v45c_build_glm_cache(
      data, spec$formula, spec$focal,
      paste0("W2_", name, "_imp", imputation)
    )
  }) |>
    setNames(names(specs))
}

v45c_w2_fit_cached <- function(cache, weight, model_id) {
  v45c_fit_cached_glm(cache, weight, model_id)$coefficients
}

v45c_w2_point_groups <- function(
    r2_period, c3_period, caches, weights, imputation) {
  point_value <- function(cache_name, weight, names_out) {
    fit <- v45c_fit_cloglog(
      if (startsWith(cache_name, "c3_")) c3_period else r2_period,
      weight,
      v45c_w2_cache_specs()[[cache_name]]$formula,
      v45c_w2_cache_specs()[[cache_name]]$focal,
      paste0("W2_", cache_name, "_point_imp", imputation),
      point_survey = TRUE
    )$coefficients
    names(fit) <- names_out
    fit
  }
  list(
    W2_RESPONSE_SHARED = c(response_gate_placeholder = 0),
    W2_ORIGINAL_E0_W1 = point_value(
      "original_w1", weights$original_r2, "w2_w1_original"
    ),
    W2_ORIGINAL_E0_W2 = point_value(
      "original_w2", weights$original_r2, "w2_w2_original"
    ),
    W2_M12_ALL_VARIANTS = c(
      point_value(
        "m12", weights$original_r2, "w2_m12_original"
      ),
      point_value(
        "m12", weights$uncapped_r2, "w2_m12_uncapped"
      ),
      point_value(
        "m12", weights$p99_r2, "w2_m12_p99"
      ),
      point_value(
        "m12", weights$p97_5_r2, "w2_m12_p97_5"
      )
    ),
    W2_ORIGINAL_M12_D12 = point_value(
      "m12_d12", weights$original_r2,
      c("w2_m12_d12_original_M12",
        "w2_m12_d12_original_D12")
    ),
    W2_C3_ORIGINAL_MAX = point_value(
      "c3_max", weights$original_c3,
      "w2_m12_max_c3_original"
    ),
    W2_C3_ORIGINAL_MEAN = point_value(
      "c3_mean", weights$original_c3,
      "w2_m12_mean_c3_original"
    ),
    W2_C3_ORIGINAL_MEDIAN = point_value(
      "c3_median", weights$original_c3,
      "w2_m12_median_c3_original"
    ),
    W2_UNCAPPED_E0_W1 = point_value(
      "original_w1", weights$uncapped_r2, "w2_w1_uncapped"
    ),
    W2_UNCAPPED_E0_W2 = point_value(
      "original_w2", weights$uncapped_r2, "w2_w2_uncapped"
    ),
    W2_UNCAPPED_M12_D12 = point_value(
      "m12_d12", weights$uncapped_r2,
      c("w2_m12_d12_uncapped_M12",
        "w2_m12_d12_uncapped_D12")
    )
  )
}

v45c_w2_period_weights <- function(
    period, person, current_base_weight, factor = NULL) {
  index <- match(period$participant_id, person$participant_id)
  if (anyNA(index)) {
    stop("W2 period weight participant match failed.", call. = FALSE)
  }
  weight <- current_base_weight[index]
  if (!is.null(factor)) {
    if (length(factor) != nrow(person) || anyNA(factor)) {
      stop("W2 period availability factor is invalid.", call. = FALSE)
    }
    weight <- weight * factor[index]
  }
  as.numeric(weight)
}

v45c_require_w2_point_diagnostic <- function(
    diagnostic, imputation) {
  imputation <- as.integer(imputation)
  if (!is.data.frame(diagnostic) || nrow(diagnostic) != 1L ||
      !"overall_status" %in% names(diagnostic) ||
      length(imputation) != 1L || is.na(imputation) ||
      imputation < 1L ||
      length(diagnostic$overall_status) != 1L ||
      is.na(diagnostic$overall_status[[1L]]) ||
      !diagnostic$overall_status[[1L]] %in%
        c("GO", "CAUTION", "STOP")) {
    stop(
      "W2 point diagnostic returned an invalid interface.",
      call. = FALSE
    )
  }
  if (identical(
    as.character(diagnostic$overall_status[[1L]]), "STOP"
  )) {
    v45c_registered_stage_stop(
      paste0(
        "Registered uncapped W2 point diagnostic STOP at ",
        "imputation ", imputation, "."
      ),
      "W2_POINT_DIAGNOSTIC_STOP"
    )
  }
  invisible(TRUE)
}

v45c_w2_one_imputation <- function(
    mids, imputation, replicate_indices, context,
    prefix_result = NULL) {
  completed <- mice::complete(mids, action = imputation)
  person <- v45c_prepare_person(
    completed, context$ledger, context$actual, context$v43, "MI-C2"
  )
  respondent <- person$R_W2 == 1L
  if (
    nrow(person) != 11869L ||
    sum(respondent) != 8308L ||
    length(unique(person$community_id)) != 420L
  ) {
    stop("W2 D2 structural anchors failed.", call. = FALSE)
  }
  r2_member <- respondent
  c3_member <- respondent &
    person$pef_w1_valid_n == 3L &
    person$pef_w2_valid_n == 3L
  r2_period <- v45c_build_period(
    person, context$ledger, context$actual, r2_member,
    w2_landmark = TRUE
  )
  c3_period <- v45c_build_period(
    person, context$ledger, context$actual, c3_member,
    w2_landmark = TRUE
  )
  v45c_assert_anchor(
    r2_period, 8308L, 912L, 23154L, 420L,
    paste0("W2 R2 imp", imputation)
  )
  v45c_assert_anchor(
    c3_period, 8245L, 899L, 22984L, 420L,
    paste0("W2 complete-three imp", imputation)
  )
  base_weight <- person$weight_biomarker_w1
  response_setup <- v45c_w2_response_cache(
    person, base_weight,
    paste0("W2_response_imp", imputation)
  )
  caches <- v45c_w2_build_caches(
    r2_period, c3_period, imputation
  )
  if (is.null(prefix_result)) {
    response_point <- v45c_w2_response_once(
      response_setup$cache, response_setup$grip,
      base_weight, respondent,
      paste0("W2_response_point_imp", imputation)
    )
    v45c_require_w2_point_diagnostic(
      response_point$diagnostic, imputation
    )
    factor_person <- lapply(response_point$factors, function(value) {
      out <- rep(1, nrow(person))
      out[respondent] <- value
      out
    })
    point_weight <- list(
      original_r2 = v45c_w2_period_weights(
        r2_period, person, base_weight
      ),
      original_c3 = v45c_w2_period_weights(
        c3_period, person, base_weight
      ),
      uncapped_r2 = v45c_w2_period_weights(
        r2_period, person, base_weight, factor_person$uncapped
      ),
      p99_r2 = v45c_w2_period_weights(
        r2_period, person, base_weight, factor_person$p99
      ),
      p97_5_r2 = v45c_w2_period_weights(
        r2_period, person, base_weight, factor_person$p97_5
      )
    )
    point <- v45c_w2_point_groups(
      r2_period, c3_period, caches, point_weight, imputation
    )
    point_diagnostic <- response_point$diagnostic
    point_diagnostic$imputation <- as.integer(imputation)
  } else {
    point <- lapply(prefix_result$groups, `[[`, "point")
    point_diagnostic <- prefix_result$response_point_diagnostic
  }
  group_ids <- names(point)
  replicate_names <- v45c_literal_replicate_names(replicate_indices)
  replicate_matrices <- lapply(point, function(value) {
    matrix(
      NA_real_, nrow = length(replicate_indices),
      ncol = length(value),
      dimnames = list(replicate_names, names(value))
    )
  })
  failures <- lapply(point, function(value) {
    character(length(replicate_indices))
  })
  response_diagnostics <- vector(
    "list", length(replicate_indices)
  )

  write_attempt <- function(group_id, row, expression) {
    attempt <- v45c_try_replicate_fit(
      expression,
      length(point[[group_id]]), names(point[[group_id]])
    )
    replicate_matrices[[group_id]][row, ] <<- attempt$value
    failures[[group_id]][[row]] <<- attempt$failure_class
    invisible(attempt$valid)
  }

  for (row in seq_along(replicate_indices)) {
    replicate_index <- replicate_indices[[row]]
    replicate_name <- replicate_names[[row]]
    multiplier <- v45c_replicate_multiplier(
      person$community_id, context$actual$modules$w2,
      replicate_index
    )
    current_base <- base_weight * multiplier
    response_failure <- ""
    response_value <- tryCatch(
      v45c_w2_response_once(
        response_setup$cache, response_setup$grip,
        current_base, respondent,
        paste0(
          "W2_response_imp", imputation, "_", replicate_name
        )
      ),
      v45c_numeric_failure = function(error) {
        response_failure <<- paste0(
          "RESPONSE_", error$failure_class
        )
        NULL
      }
    )
    response_valid <- !is.null(response_value) &&
      !identical(
        response_value$diagnostic$overall_status[[1L]], "STOP"
      )
    if (!is.null(response_value) && !response_valid) {
      response_failure <- "RESPONSE_UNCAPPED_DIAGNOSTIC_STOP"
    }
    if (response_valid) {
      replicate_matrices$W2_RESPONSE_SHARED[
        row, "response_gate_placeholder"
      ] <- 0
      response_diagnostic <- response_value$diagnostic
      response_diagnostic$replicate <- replicate_name
      response_diagnostic$response_fit_valid <- TRUE
      response_diagnostic$response_failure_class <- ""
    } else {
      failures$W2_RESPONSE_SHARED[[row]] <- response_failure
      response_diagnostic <- data.frame(
        response_probability_p01 = NA_real_,
        availability_factor_p99 = NA_real_,
        ESS_ratio = NA_real_,
        maximum_absolute_SMD = NA_real_,
        cap_p99 = NA_real_,
        cap_p97_5 = NA_real_,
        structurally_constant_balance_columns = NA_integer_,
        structurally_constant_balance_column_names = NA_character_,
        response_probability_status = "STOP",
        availability_factor_status = "STOP",
        ESS_status = "STOP",
        maximum_absolute_SMD_status = "STOP",
        overall_status = "STOP",
        replicate = replicate_name,
        response_fit_valid = FALSE,
        response_failure_class = response_failure,
        stringsAsFactors = FALSE
      )
    }
    response_diagnostics[[row]] <- response_diagnostic

    original_r2 <- v45c_w2_period_weights(
      r2_period, person, current_base
    )
    original_c3 <- v45c_w2_period_weights(
      c3_period, person, current_base
    )
    write_attempt("W2_ORIGINAL_E0_W1", row, {
      value <- v45c_w2_fit_cached(
        caches$original_w1, original_r2,
        paste0("W2_original_w1_imp", imputation, "_", replicate_name)
      )
      setNames(value, "w2_w1_original")
    })
    write_attempt("W2_ORIGINAL_E0_W2", row, {
      value <- v45c_w2_fit_cached(
        caches$original_w2, original_r2,
        paste0("W2_original_w2_imp", imputation, "_", replicate_name)
      )
      setNames(value, "w2_w2_original")
    })
    write_attempt("W2_ORIGINAL_M12_D12", row, {
      value <- v45c_w2_fit_cached(
        caches$m12_d12, original_r2,
        paste0(
          "W2_original_m12_d12_imp", imputation, "_", replicate_name
        )
      )
      setNames(
        value,
        c("w2_m12_d12_original_M12",
          "w2_m12_d12_original_D12")
      )
    })
    write_attempt("W2_C3_ORIGINAL_MAX", row, {
      value <- v45c_w2_fit_cached(
        caches$c3_max, original_c3,
        paste0("W2_c3_max_imp", imputation, "_", replicate_name)
      )
      setNames(value, "w2_m12_max_c3_original")
    })
    write_attempt("W2_C3_ORIGINAL_MEAN", row, {
      value <- v45c_w2_fit_cached(
        caches$c3_mean, original_c3,
        paste0("W2_c3_mean_imp", imputation, "_", replicate_name)
      )
      setNames(value, "w2_m12_mean_c3_original")
    })
    write_attempt("W2_C3_ORIGINAL_MEDIAN", row, {
      value <- v45c_w2_fit_cached(
        caches$c3_median, original_c3,
        paste0("W2_c3_median_imp", imputation, "_", replicate_name)
      )
      setNames(value, "w2_m12_median_c3_original")
    })

    if (!response_valid) {
      for (group_id in c(
        "W2_M12_ALL_VARIANTS",
        "W2_UNCAPPED_E0_W1", "W2_UNCAPPED_E0_W2",
        "W2_UNCAPPED_M12_D12"
      )) {
        failures[[group_id]][[row]] <- response_failure
      }
      next
    }
    factor_person <- lapply(response_value$factors, function(value) {
      out <- rep(1, nrow(person))
      out[respondent] <- value
      out
    })
    uncapped_r2 <- v45c_w2_period_weights(
      r2_period, person, current_base, factor_person$uncapped
    )
    p99_r2 <- v45c_w2_period_weights(
      r2_period, person, current_base, factor_person$p99
    )
    p97_5_r2 <- v45c_w2_period_weights(
      r2_period, person, current_base, factor_person$p97_5
    )
    write_attempt("W2_UNCAPPED_E0_W1", row, {
      value <- v45c_w2_fit_cached(
        caches$original_w1, uncapped_r2,
        paste0("W2_uncapped_w1_imp", imputation, "_", replicate_name)
      )
      setNames(value, "w2_w1_uncapped")
    })
    write_attempt("W2_UNCAPPED_E0_W2", row, {
      value <- v45c_w2_fit_cached(
        caches$original_w2, uncapped_r2,
        paste0("W2_uncapped_w2_imp", imputation, "_", replicate_name)
      )
      setNames(value, "w2_w2_uncapped")
    })
    write_attempt("W2_UNCAPPED_M12_D12", row, {
      value <- v45c_w2_fit_cached(
        caches$m12_d12, uncapped_r2,
        paste0(
          "W2_uncapped_m12_d12_imp", imputation, "_", replicate_name
        )
      )
      setNames(
        value,
        c("w2_m12_d12_uncapped_M12",
          "w2_m12_d12_uncapped_D12")
      )
    })
    write_attempt("W2_M12_ALL_VARIANTS", row, {
      c(
        w2_m12_original = v45c_w2_fit_cached(
          caches$m12, original_r2,
          paste0(
            "W2_m12_original_imp", imputation, "_", replicate_name
          )
        )[[1L]],
        w2_m12_uncapped = v45c_w2_fit_cached(
          caches$m12, uncapped_r2,
          paste0(
            "W2_m12_uncapped_imp", imputation, "_", replicate_name
          )
        )[[1L]],
        w2_m12_p99 = v45c_w2_fit_cached(
          caches$m12, p99_r2,
          paste0(
            "W2_m12_p99_imp", imputation, "_", replicate_name
          )
        )[[1L]],
        w2_m12_p97_5 = v45c_w2_fit_cached(
          caches$m12, p97_5_r2,
          paste0(
            "W2_m12_p97_5_imp", imputation, "_", replicate_name
          )
        )[[1L]]
      )
    })
  }

  if (is.null(prefix_result)) {
    groups <- setNames(lapply(group_ids, function(group_id) {
      v45c_make_group(
        group_id, point[[group_id]],
        replicate_matrices[[group_id]], 419,
        failures[[group_id]],
        compute_covariance = FALSE
      )
    }), group_ids)
    all_response_diagnostics <- do.call(
      rbind, response_diagnostics
    )
  } else {
    groups <- setNames(lapply(group_ids, function(group_id) {
      v45c_extend_group(
        prefix_result$groups[[group_id]],
        replicate_matrices[[group_id]],
        failures[[group_id]]
      )
    }), group_ids)
    all_response_diagnostics <- rbind(
      prefix_result$response_replicate_diagnostics,
      do.call(rbind, response_diagnostics)
    )
    if (!identical(
      all_response_diagnostics$replicate,
      v45c_literal_replicate_names(1:500)
    )) {
      stop("W2 full diagnostics changed literal replicate order.",
           call. = FALSE)
    }
  }
  rm(
    completed, person, r2_period, c3_period,
    response_setup, caches
  )
  list(
    imputation = as.integer(imputation),
    groups = groups,
    sample_anchors = data.frame(
      sample_id = c(
        "charls_w2_D2_supported",
        "charls_w2_landmark_R2",
        "charls_w1_w2_complete_three_R2"
      ),
      imputation = as.integer(imputation),
      n = c(11869L, 8308L, 8245L),
      events_or_responses = c(8308L, 912L, 899L),
      period_rows = c(NA_integer_, 23154L, 22984L),
      psu = c(420L, 420L, 420L),
      dfcom = c(419L, 419L, 419L),
      stringsAsFactors = FALSE
    ),
    response_point_diagnostic = point_diagnostic,
    response_replicate_diagnostics = all_response_diagnostics,
    response_coefficients_persisted = FALSE,
    individual_probability_or_factor_persisted = FALSE
  )
}

v45c_formula_component_serialization <- function(formula_texts) {
  formula_texts <- as.character(formula_texts)
  if (!length(formula_texts) || anyNA(formula_texts) ||
      any(!nzchar(formula_texts))) {
    stop("Canonical formula-component serialization input is invalid.",
         call. = FALSE)
  }
  paste0(
    sprintf(
      "%d:%s",
      nchar(formula_texts, type = "bytes"),
      formula_texts
    ),
    collapse = "||"
  )
}

v45c_formula_components_from_registry_row <- function(row, contract) {
  formula_id <- as.character(row$formula_id[[1L]])
  row_type <- as.character(row$row_type[[1L]])
  contrast_id <- as.character(row$contrast_id[[1L]])
  focal <- strsplit(
    as.character(row$focal_terms[[1L]]), ";", fixed = TRUE
  )[[1L]]
  if (formula_id == "F_W2_RESPONSE_LOGIT") {
    formulas <- list(v45c_response_formula())
    exposures <- character()
  } else if (identical(row_type, "paired_contrast") &&
             identical(formula_id, "F_TRIAL_L100_A1")) {
    component_map <-
      contract$contrast_contract$trial_component_exposures
    if (is.null(component_map) ||
        !contrast_id %in% names(component_map)) {
      stop(
        "Paired contrast lacks a frozen component-formula mapping: ",
        as.character(row$analysis_id[[1L]]), call. = FALSE
      )
    }
    exposures <- as.character(component_map[[contrast_id]])
    expected_focal <- sub("^L100_", "beta_", exposures)
    if (!identical(formula_id, "F_TRIAL_L100_A1") ||
        length(exposures) != 2L || anyDuplicated(exposures) ||
        any(!exposures %in%
              c("L100_max", "L100_mean", "L100_median")) ||
        any(grepl("^beta_", exposures)) ||
        !identical(focal, expected_focal)) {
      stop(
        "Frozen paired-contrast component mapping drifted: ",
        as.character(row$analysis_id[[1L]]), call. = FALSE
      )
    }
    formulas <- lapply(
      exposures,
      function(exposure) v45c_formula(formula_id, exposure)
    )
  } else {
    exposures <- if (formula_id %in%
                     c("F_TRIAL_L100_A1", "F_W2_SINGLE_A1")) {
      focal[[1L]]
    } else {
      character()
    }
    formulas <- if (length(exposures)) {
      list(v45c_formula(formula_id, exposures[[1L]]))
    } else {
      list(v45c_formula(formula_id))
    }
  }
  texts <- vapply(formulas, function(formula) {
    paste(deparse(formula, width.cutoff = 500L), collapse = " ")
  }, character(1))
  if (identical(formula_id, "F_TRIAL_L100_A1") &&
      any(grepl("\\bbeta_", texts))) {
    stop(
      "A synthetic beta term entered a trial component formula: ",
      as.character(row$analysis_id[[1L]]), call. = FALSE
    )
  }
  list(
    exposures = exposures,
    formulas = formulas,
    formula_text = texts,
    serialization = v45c_formula_component_serialization(texts)
  )
}

v45c_validate_formula_implementation <- function(contract) {
  registry <- contract$model_registry
  hashes <- contract$formula_hashes
  if (!is.data.frame(registry) || nrow(registry) != 28L ||
      !is.data.frame(hashes) || nrow(hashes) != 28L ||
      anyDuplicated(registry$analysis_id) ||
      anyDuplicated(hashes$analysis_id) ||
      !setequal(registry$analysis_id, hashes$analysis_id)) {
    stop("Frozen formula/model registry schema failed.", call. = FALSE)
  }
  paired_rows <- registry[
    registry$row_type == "paired_contrast" &
      registry$formula_id == "F_TRIAL_L100_A1",
    , drop = FALSE
  ]
  component_map <-
    contract$contrast_contract$trial_component_exposures
  component_map_valid <- is.list(component_map) &&
    length(component_map) == 3L &&
    !is.null(names(component_map)) &&
    !anyDuplicated(names(component_map)) &&
    all(vapply(component_map, function(value) {
      is.character(value) && length(value) == 2L &&
        !anyNA(value) && !anyDuplicated(value) &&
        all(value %in%
              c("L100_max", "L100_mean", "L100_median"))
    }, logical(1)))
  if (!component_map_valid ||
      !identical(
        sort(names(component_map), method = "radix"),
        sort(paired_rows$contrast_id, method = "radix")
      )) {
    stop(
      "Frozen paired-contrast component mappings do not fully and only ",
      "cover the registered trial contrasts.", call. = FALSE
    )
  }
  required_hash_columns <- c(
    "analysis_id", "formula_id", "component_count",
    "component_exposures", "component_formula_serialization",
    "component_formula_ast_sha256"
  )
  if (!identical(names(hashes), required_hash_columns)) {
    stop("Frozen formula-component hash schema drifted.", call. = FALSE)
  }
  for (index in seq_len(nrow(registry))) {
    row <- registry[index, , drop = FALSE]
    frozen_row <- hashes[
      hashes$analysis_id == row$analysis_id[[1L]], , drop = FALSE
    ]
    implemented <- v45c_formula_components_from_registry_row(
      row, contract
    )
    exposure_text <- if (length(implemented$exposures)) {
      paste(implemented$exposures, collapse = ";")
    } else {
      "NONE"
    }
    hash <- v45_charls_text_sha256(c(
      "formula_component_set_v1",
      implemented$serialization
    ))
    pass <-
      identical(
        as.integer(frozen_row$component_count[[1L]]),
        length(implemented$formula_text)
      ) &&
      identical(
        as.character(frozen_row$component_exposures[[1L]]),
        exposure_text
      ) &&
      identical(
        as.character(
          frozen_row$component_formula_serialization[[1L]]
        ),
        implemented$serialization
      ) &&
      identical(
        as.character(frozen_row$component_formula_ast_sha256[[1L]]),
        hash
      )
    if (!pass) {
      stop(
        "Runner component-formula implementation drifted for ",
        row$analysis_id[[1L]], call. = FALSE
      )
    }
  }
  invisible(TRUE)
}

v45c_verify_contract <- function(root, contract_path, gate_path) {
  contract <- readRDS(contract_path)
  gate <- yaml::read_yaml(gate_path)
  if (!identical(
        contract$contract_version,
        "v45_1_charls_outcome_execution"
      ) ||
      is.null(contract$governance) ||
      any(unlist(contract$governance) != 0L) ||
      !isTRUE(
        contract$release_gate$restricted_outcome_execution_allowed
      ) ||
      !identical(
        contract$release_gate$new_coefficient_inspection_allowed,
        FALSE
      ) ||
      !identical(as.character(gate$freeze$status), "PASS") ||
      !identical(
        as.character(gate$freeze$contract_sha256),
        v45c_sha256_file(contract_path)
      ) ||
      !v45c_yes(gate$restricted_outcome_execution_allowed) ||
      !v45c_no(gate$new_coefficient_inspection_allowed) ||
      !v45c_no(gate$response_or_outcome_result_release_allowed)) {
    stop("Frozen CHARLS outcome execution gate/contract is invalid.",
         call. = FALSE)
  }
  if (!is.data.frame(contract$mi_bindings) ||
      nrow(contract$mi_bindings) != 2L ||
      !setequal(contract$mi_bindings$object_id, c("MI-C0", "MI-C2")) ||
      any(contract$mi_bindings$requested_m != 50L) ||
      any(contract$mi_bindings$status !=
          "INDEPENDENT_VALIDATION_PASS") ||
      !is.data.frame(contract$model_registry) ||
      nrow(contract$model_registry) != 28L ||
      !is.data.frame(contract$threshold_registry) ||
      nrow(contract$threshold_registry) != 12L ||
      !is.data.frame(contract$anchor_registry) ||
      nrow(contract$anchor_registry) != 75L ||
      !is.data.frame(contract$crosswalk) ||
      nrow(contract$crosswalk) != 18L) {
    stop("Frozen CHARLS outcome bindings/registries are incomplete.",
         call. = FALSE)
  }
  v45c_validate_formula_implementation(contract)
  contract
}

v45c_load_mids <- function(root, contract, object_id) {
  binding <- contract$mi_bindings[
    contract$mi_bindings$object_id == object_id, , drop = FALSE
  ]
  if (nrow(binding) != 1L) {
    stop(object_id, " lacks one frozen MI binding.", call. = FALSE)
  }
  current_path <- v45c_safe_alias(
    root, binding$current_pointer_path_alias[[1L]],
    "results/v45/charls_addendum_v45_1/production_mi"
  )
  validated_path <- v45c_safe_alias(
    root, binding$validated_pointer_path_alias[[1L]],
    "results/v45/charls_addendum_v45_1/production_mi"
  )
  if (!identical(
        v45c_sha256_file(current_path),
        binding$current_pointer_sha256[[1L]]
      ) ||
      !identical(
        v45c_sha256_file(validated_path),
        binding$validated_pointer_sha256[[1L]]
      )) {
    stop(object_id, " validated/current pointer hash drifted.",
         call. = FALSE)
  }
  current <- v45c_read_tsv(current_path)
  validated <- v45c_read_tsv(validated_path)
  if (nrow(current) != 1L || nrow(validated) != 1L ||
      current$object_id[[1L]] != object_id ||
      validated$object_id[[1L]] != object_id ||
      current$run_id[[1L]] != binding$run_id[[1L]] ||
      validated$run_id[[1L]] != binding$run_id[[1L]] ||
      validated$status[[1L]] != "INDEPENDENT_VALIDATION_PASS" ||
      validated$current_pointer_sha256[[1L]] !=
        binding$current_pointer_sha256[[1L]] ||
      current$mids_path_alias[[1L]] !=
        binding$mids_path_alias[[1L]] ||
      current$mids_sha256[[1L]] != binding$mids_sha256[[1L]]) {
    stop(object_id, " current/validated pointer content drifted.",
         call. = FALSE)
  }
  mids_path <- v45c_safe_alias(
    root, binding$mids_path_alias[[1L]],
    "derived_sensitive/v45/charls_addendum_v45_1"
  )
  if (!identical(
        v45c_sha256_file(mids_path),
        binding$mids_sha256[[1L]]
      )) {
    stop(object_id, " mids hash drifted.", call. = FALSE)
  }
  value <- readRDS(mids_path)
  if (!inherits(value, "mids") || value$m != 50L) {
    stop(object_id, " bound object is not exact m=50 mids.",
         call. = FALSE)
  }
  value
}

v45c_load_context <- function(root, contract) {
  ledger_path <- file.path(
    root, "derived_sensitive/v43/charls_stage3_analysis_ledger_v43.rds"
  )
  actual_path <- file.path(
    root,
    paste0(
      "derived_sensitive/v45/charls_addendum_v45_1/",
      "charls_actual_keys_mi_contract_v45_1.rds"
    )
  )
  v43_path <- file.path(
    root, "R/v43/04_charls_stage3_primary_mortality.R"
  )
  expected <- c(
    ledger =
      "500e923e8793d1925823c73ff1039591dd9a23f84d57a31a80a33f4f49e0ea0b",
    actual =
      "2e80186cacd93d8f9c29aac1dc02168d545e4f43a4cded86542565bb7a01937c",
    v43 =
      "bc759aab44691deb5a920a4017c7b51bfe7c5694959b27ae9aa95462fba5908d"
  )
  observed <- c(
    ledger = v45c_sha256_file(ledger_path),
    actual = v45c_sha256_file(actual_path),
    v43 = v45c_sha256_file(v43_path)
  )
  if (!identical(observed, expected) ||
      !identical(
        contract$actual_design_contract_sha256,
        expected[["actual"]]
      )) {
    stop("Immutable CHARLS ledger/design/function authority drifted.",
         call. = FALSE)
  }
  ledger <- readRDS(ledger_path)
  actual <- readRDS(actual_path)
  if (!identical(
        actual$actual_design_key_role,
        "production_bound_actual_CHARLS_community_keys"
      ) ||
      !identical(
        vapply(
          actual$modules, `[[`, character(1), "matrix_id"
        ),
        c(
          trial = "RW-CHARLS-TRIAL-ACTUAL",
          adjacent = "RW-CHARLS-ADJACENT-ACTUAL",
          w2 = "RW-CHARLS-W2-IPW-ACTUAL"
        )
      ) ||
      any(vapply(
        actual$modules,
        function(module) !identical(dim(module$matrix),
                                    c(nrow(module$key_map), 500L)),
        logical(1)
      ))) {
    stop("Actual CHARLS Rao-Wu object failed runtime validation.",
         call. = FALSE)
  }
  v43 <- new.env(parent = globalenv())
  sys.source(v43_path, envir = v43)
  required_v43 <- c(
    "fixed_ns", "get_knot_row", "restricted_cubic_basis",
    "attach_passive_variables", "model_formulas",
    "fit_one_survey_model"
  )
  if (!all(vapply(
        required_v43, exists, logical(1),
        envir = v43, inherits = FALSE
      ))) {
    stop("Exact v43 function authority is incomplete.", call. = FALSE)
  }
  list(ledger = ledger, actual = actual, v43 = v43)
}

v45c_module_rows <- function() {
  c(
    "anchor-point",
    "trial-prefix", "trial-full",
    "inconsistency-prefix", "inconsistency-full",
    "adjacent-prefix", "adjacent-full",
    "timehet-prefix", "timehet-full",
    "W2-prefix", "W2-full"
  )
}

v45c_state_template <- function() {
  data.frame(
    module = v45c_module_rows(),
    status = "NOT_RUN",
    output_path_alias = NA_character_,
    output_sha256 = NA_character_,
    completed_at = NA_character_,
    coefficient_visibility = "RESTRICTED",
    independent_validation_status = "NOT_RUN",
    stringsAsFactors = FALSE
  )
}

v45c_validate_existing_current_pointer <- function(
    pointer, run_id, state_path_alias, state_sha256,
    freeze_contract_sha256) {
  required <- c(
    "run_id", "state_path_alias", "state_sha256",
    "freeze_contract_sha256", "coefficient_visibility",
    "independent_validation_status"
  )
  if (!is.data.frame(pointer) || nrow(pointer) != 1L ||
      !identical(names(pointer), required) ||
      !identical(as.character(pointer$run_id[[1L]]),
                 as.character(run_id)) ||
      !identical(
        as.character(pointer$state_path_alias[[1L]]),
        as.character(state_path_alias)
      ) ||
      !identical(
        as.character(pointer$state_sha256[[1L]]),
        as.character(state_sha256)
      ) ||
      !identical(
        as.character(pointer$freeze_contract_sha256[[1L]]),
        as.character(freeze_contract_sha256)
      ) ||
      !grepl("^[0-9a-f]{64}$",
             as.character(pointer$state_sha256[[1L]])) ||
      !grepl("^[0-9a-f]{64}$",
             as.character(pointer$freeze_contract_sha256[[1L]])) ||
      pointer$coefficient_visibility[[1L]] != "RESTRICTED" ||
      pointer$independent_validation_status[[1L]] != "NOT_RUN") {
    stop(
      "Existing restricted current pointer does not exactly bind ",
      "the computed state path and current state SHA-256.",
      call. = FALSE
    )
  }
  invisible(TRUE)
}

v45c_run_pid <- function(run_id) {
  run_id <- as.character(run_id)
  value <- sub("^.*_pid", "", run_id)
  pid <- suppressWarnings(as.integer(value))
  if (length(run_id) != 1L || is.na(run_id) || !nzchar(run_id) ||
      !grepl("_pid[0-9]+$", run_id) ||
      length(pid) != 1L || is.na(pid) || pid < 1L) {
    stop("Outcome run ID has no valid bound PID.", call. = FALSE)
  }
  pid
}

v45c_validate_interrupted_state <- function(
    state, old_run_id, state_path_alias) {
  template <- v45c_state_template()
  expected_alias <- file.path(
    "results/v45/charls_addendum_v45_1/outcome_execution",
    old_run_id, "module_state.tsv"
  )
  if (!is.data.frame(state) ||
      !identical(names(state), names(template)) ||
      !identical(state$module, template$module) ||
      any(!state$status %in%
            c("NOT_RUN", "RUNNING", "RESTRICTED_COMPLETE")) ||
      !any(state$status == "RUNNING") ||
      !identical(as.character(state_path_alias), expected_alias) ||
      any(state$coefficient_visibility != "RESTRICTED") ||
      any(state$independent_validation_status != "NOT_RUN")) {
    stop(
      "Supersession requires an exact old state with at least one ",
      "interrupted RUNNING module.", call. = FALSE
    )
  }
  invisible(TRUE)
}

v45c_validate_stale_lock_owner <- function(owner, old_run_id) {
  required <- c("run_id", "pid", "acquired_at_utc")
  schema_valid <- is.data.frame(owner) && nrow(owner) == 1L &&
    identical(names(owner), required)
  owner_pid <- if (schema_valid) {
    suppressWarnings(as.integer(owner$pid[[1L]]))
  } else {
    NA_integer_
  }
  if (!schema_valid ||
      !identical(names(owner), required) ||
      !identical(as.character(owner$run_id[[1L]]),
                 as.character(old_run_id)) ||
      length(owner_pid) != 1L || is.na(owner_pid) ||
      owner_pid < 1L ||
      is.na(owner$acquired_at_utc[[1L]]) ||
      !nzchar(as.character(owner$acquired_at_utc[[1L]]))) {
    stop(
      "Stale execution-lock owner does not exactly bind the ",
      "interrupted old run.", call. = FALSE
    )
  }
  owner_pid
}

v45c_assert_completed_module_gate <- function(module, object) {
  if (identical(module, "anchor-point")) {
    pass <- is.list(object$anchor) &&
      identical(object$anchor$gate, "PASS")
  } else if (endsWith(module, "-prefix")) {
    pass <- length(object$prefix_gate) == 1L &&
      !is.na(object$prefix_gate) &&
      object$prefix_gate %in% c("GO", "CAUTION") &&
      identical(
        object$pooling_status, "NOT_APPLICABLE_PREFIX"
      )
  } else if (endsWith(module, "-full")) {
    pass <- length(object$full_gate) == 1L &&
      !is.na(object$full_gate) &&
      object$full_gate %in% c("GO", "CAUTION") &&
      identical(object$pooling_status, "COMPLETE")
  } else {
    pass <- FALSE
  }
  if (!isTRUE(pass)) {
    stop(
      module,
      " is complete but its frozen anchor/prefix/full gate is STOP ",
      "or missing; resume is fail-closed.",
      call. = FALSE
    )
  }
  invisible(TRUE)
}

v45c_run_alias <- function(run_id, module) {
  file.path(
    "derived_sensitive/v45/charls_addendum_v45_1",
    "outcome_execution/m50", run_id,
    paste0(gsub("-", "_", module, fixed = TRUE), "_restricted.rds")
  )
}

v45c_main <- function() {
  args <- commandArgs(trailingOnly = TRUE)
  if ("--self-test" %in% args) {
    runtime <- v45c_validate_runtime(v45c_runner_root())
    report <- v45c_static_self_test()
    report <- rbind(
      report,
      data.frame(
        check = "frozen_runtime_authority",
        status = if (identical(
          runtime, v45c_required_runtime_versions()
        )) "PASS" else "FAIL",
        stringsAsFactors = FALSE
      )
    )
    if (any(report$status != "PASS")) {
      stop("CHARLS outcome runner self-test failed.", call. = FALSE)
    }
    cat("CHARLS V45.1 OUTCOME RUNNER SELF-TEST PASS\n")
    cat("response_or_outcome_models_fitted=0\n")
    cat("coefficient_inspection=0\n")
    cat("outputs_written=0\n")
    return(invisible(report))
  }

  root <- v45c_runner_root()
  v45c_validate_runtime(root)
  source(file.path(
    root,
    "R/v45/charls_addendum_v45_1/charls_outcome_utilities_v45_1.R"
  ))
  options(
    survey.lonely.psu = "adjust",
    survey.adjust.domain.lonely = TRUE,
    survey.replicates.mse = TRUE,
    survey.multicore = FALSE
  )

  module_requested <- v45c_arg_value(args, "--module", "all")
  if (!module_requested %in% v45c_allowed_modules()) {
    stop(
      "Unknown --module. Expected: ",
      paste(v45c_allowed_modules(), collapse = ", "),
      call. = FALSE
    )
  }
  workers <- suppressWarnings(as.integer(
    v45c_arg_value(args, "--workers", "4")
  ))
  if (!is.finite(workers) || workers < 1L || workers > 8L) {
    stop("--workers must be an integer from 1 to 8.", call. = FALSE)
  }
  detected <- parallel::detectCores()
  if (!is.finite(detected)) detected <- 1L
  workers <- min(workers, max(1L, as.integer(detected) - 1L))
  supersede_value <- v45c_arg_value(
    args, "--supersede-interrupted", "no"
  )
  if (!v45c_yes(supersede_value) && !v45c_no(supersede_value)) {
    stop(
      "--supersede-interrupted must be exactly yes or no.",
      call. = FALSE
    )
  }
  supersede_interrupted <- v45c_yes(supersede_value)

  freeze_script <- file.path(
    root,
    "R/v45/charls_addendum_v45_1/",
    "11_freeze_charls_outcome_execution_v45_1.R"
  )
  verify_output <- system2(
    file.path(R.home("bin"), "Rscript"),
    c("--vanilla", freeze_script, "--verify"),
    stdout = TRUE, stderr = TRUE
  )
  verify_status <- attr(verify_output, "status")
  if ((!is.null(verify_status) && verify_status != 0L) ||
      !any(grepl(
        "CHARLS V45.1 OUTCOME FREEZE VERIFY PASS",
        verify_output, fixed = TRUE
      ))) {
    stop(
      "CHARLS outcome freeze verification failed: ",
      paste(verify_output, collapse = " | "), call. = FALSE
    )
  }
  contract_path <- file.path(
    root,
    paste0(
      "derived_sensitive/v45/charls_addendum_v45_1/",
      "charls_outcome_execution_contract_v45_1.rds"
    )
  )
  gate_path <- file.path(
    root,
    paste0(
      "work_v45/charls_addendum_v45_1/",
      "charls_outcome_execution_gate_state_v45_1.yml"
    )
  )
  contract <- v45c_verify_contract(root, contract_path, gate_path)
  contract_sha <- v45c_sha256_file(contract_path)

  public_root <- file.path(
    root,
    "results/v45/charls_addendum_v45_1/outcome_execution"
  )
  restricted_root <- file.path(
    root,
    "derived_sensitive/v45/charls_addendum_v45_1/outcome_execution/m50"
  )
  log_root <- file.path(
    root, "logs/v45/charls_addendum_v45_1/outcome_execution"
  )
  dir.create(public_root, recursive = TRUE, showWarnings = FALSE)
  dir.create(restricted_root, recursive = TRUE, showWarnings = FALSE)
  dir.create(log_root, recursive = TRUE, showWarnings = FALSE)
  current_path <- file.path(
    public_root, "charls_outcome_restricted_current.tsv"
  )

  run_id_arg <- v45c_arg_value(args, "--run-id", NULL)
  run_pattern <-
    "^charls_v45_1_outcome_m50_[0-9]{8}T[0-9]{6}_pid[0-9]+$"
  if (!is.null(run_id_arg) && !grepl(run_pattern, run_id_arg)) {
    stop("Unsafe or invalid --run-id.", call. = FALSE)
  }
  if (supersede_interrupted && is.null(run_id_arg)) {
    stop(
      "--supersede-interrupted=yes requires an explicit all-new --run-id.",
      call. = FALSE
    )
  }
  supersession <- NULL
  if (supersede_interrupted) {
    if (!file.exists(current_path)) {
      stop(
        "No restricted current pointer exists to supersede.",
        call. = FALSE
      )
    }
    old_pointer <- v45c_read_tsv(current_path)
    required_current <- c(
      "run_id", "state_path_alias", "state_sha256",
      "freeze_contract_sha256", "coefficient_visibility",
      "independent_validation_status"
    )
    if (nrow(old_pointer) != 1L ||
        !identical(names(old_pointer), required_current)) {
      stop(
        "The old restricted current pointer schema is invalid.",
        call. = FALSE
      )
    }
    old_run_id <- as.character(old_pointer$run_id[[1L]])
    if (!grepl(run_pattern, old_run_id) ||
        identical(old_run_id, run_id_arg)) {
      stop(
        "Supersession requires a distinct valid old and all-new run ID.",
        call. = FALSE
      )
    }
    old_state_alias <- as.character(
      old_pointer$state_path_alias[[1L]]
    )
    old_state_path <- v45c_safe_alias(
      root, old_state_alias,
      "results/v45/charls_addendum_v45_1/outcome_execution"
    )
    v45c_validate_existing_current_pointer(
      pointer = old_pointer,
      run_id = old_run_id,
      state_path_alias = old_state_alias,
      state_sha256 = v45c_sha256_file(old_state_path),
      freeze_contract_sha256 = contract_sha
    )
    old_state <- v45c_read_tsv(old_state_path)
    v45c_validate_interrupted_state(
      old_state, old_run_id, old_state_alias
    )
    supersession <- list(
      old_run_id = old_run_id,
      old_pid = v45c_run_pid(old_run_id),
      old_pid_source = "RUN_ID_SUFFIX_FALLBACK",
      old_pointer_sha256 = v45c_sha256_file(current_path),
      old_state_path_alias = old_state_alias,
      old_state_sha256 = v45c_sha256_file(old_state_path),
      old_running_modules = paste(
        old_state$module[old_state$status == "RUNNING"],
        collapse = "|"
      )
    )
    run_id <- run_id_arg
  } else if (!is.null(run_id_arg)) {
    run_id <- run_id_arg
  } else if (file.exists(current_path)) {
    current <- v45c_read_tsv(current_path)
    required_current <- c(
      "run_id", "state_path_alias", "state_sha256",
      "freeze_contract_sha256", "coefficient_visibility",
      "independent_validation_status"
    )
    if (nrow(current) != 1L ||
        !identical(names(current), required_current) ||
        !grepl(run_pattern, current$run_id[[1L]]) ||
        current$coefficient_visibility[[1L]] != "RESTRICTED" ||
        current$independent_validation_status[[1L]] != "NOT_RUN" ||
        current$freeze_contract_sha256[[1L]] != contract_sha) {
      stop("Current restricted-run pointer is invalid.", call. = FALSE)
    }
    run_id <- current$run_id[[1L]]
  } else {
    run_id <- paste0(
      "charls_v45_1_outcome_m50_",
      format(Sys.time(), "%Y%m%dT%H%M%S"),
      "_pid", Sys.getpid()
    )
  }

  run_dir <- file.path(restricted_root, run_id)
  state_dir <- file.path(public_root, run_id)
  state_path <- file.path(state_dir, "module_state.tsv")
  log_path <- file.path(log_root, paste0(run_id, ".log"))
  if (supersede_interrupted &&
      (file.exists(run_dir) || file.exists(state_dir) ||
       file.exists(log_path))) {
    stop(
      "The explicit supersession run ID is not all-new; refusing overwrite.",
      call. = FALSE
    )
  }
  lock_parent <- file.path(
    root,
    "derived_sensitive/v45/charls_addendum_v45_1/outcome_execution"
  )
  dir.create(lock_parent, recursive = TRUE, showWarnings = FALSE)
  lock <- file.path(lock_parent, ".charls_outcome_execution.lock")
  stale_lock_status <- "ABSENT_AFTER_INTERRUPTED_EXIT"
  stale_lock_archive_alias <- NA_character_
  stale_lock_owner_sha256 <- NA_character_
  if (supersede_interrupted && dir.exists(lock)) {
    if (nzchar(Sys.readlink(lock))) {
      stop("Execution lock is an unsafe symlink.", call. = FALSE)
    }
    old_owner_path <- file.path(lock, "owner.tsv")
    if (!file.exists(old_owner_path) || dir.exists(old_owner_path) ||
        nzchar(Sys.readlink(old_owner_path))) {
      stop("Stale execution lock lacks a safe owner record.",
           call. = FALSE)
    }
    old_owner <- v45c_read_tsv(old_owner_path)
    owner_pid <- v45c_validate_stale_lock_owner(
      old_owner, supersession$old_run_id
    )
    if (isTRUE(tools::pskill(owner_pid, 0L))) {
      stop(
        "The stale-lock owner PID is still alive; supersession denied.",
        call. = FALSE
      )
    }
    supersession$old_pid <- owner_pid
    supersession$old_pid_source <- "STALE_LOCK_OWNER"
    stale_lock_owner_sha256 <- v45c_sha256_file(old_owner_path)
    stale_archive <- file.path(
      lock_parent,
      paste0(
        ".charls_outcome_execution.stale_",
        supersession$old_run_id, "_",
        format(Sys.time(), "%Y%m%dT%H%M%S")
      )
    )
    if (file.exists(stale_archive) ||
        !file.rename(lock, stale_archive)) {
      stop(
        "Atomic stale execution-lock archival failed.",
        call. = FALSE
      )
    }
    stale_lock_status <- "ARCHIVED_DEAD_OWNER"
    stale_lock_archive_alias <- substring(
      stale_archive, nchar(root) + 2L
    )
  } else if (supersede_interrupted &&
             isTRUE(tools::pskill(supersession$old_pid, 0L))) {
    stop(
      "No stale lock remains, but the old run-ID PID is still alive; ",
      "supersession denied.", call. = FALSE
    )
  }
  if (!dir.create(lock, showWarnings = FALSE)) {
    stop("Another CHARLS outcome runner holds the execution lock.",
         call. = FALSE)
  }
  lock_preowner_cleanup <- TRUE
  on.exit({
    if (isTRUE(lock_preowner_cleanup) && dir.exists(lock)) {
      unlink(lock, recursive = TRUE, force = TRUE)
    }
  }, add = TRUE)
  lock_owner <- file.path(lock, "owner.tsv")
  v45c_atomic_write_tsv(data.frame(
    run_id = run_id, pid = Sys.getpid(),
    acquired_at_utc =
      format(Sys.time(), "%Y-%m-%dT%H:%M:%SZ", tz = "UTC"),
    stringsAsFactors = FALSE
  ), lock_owner)
  lock_owner_sha <- v45c_sha256_file(lock_owner)
  on.exit({
    if (dir.exists(lock) &&
        identical(v45c_sha256_file(lock_owner), lock_owner_sha)) {
      unlink(lock, recursive = TRUE, force = TRUE)
    }
  }, add = TRUE)
  lock_preowner_cleanup <- FALSE
  dir.create(run_dir, recursive = TRUE, showWarnings = FALSE)
  dir.create(state_dir, recursive = TRUE, showWarnings = FALSE)
  if (!dir.exists(run_dir) || !dir.exists(state_dir)) {
    stop("New outcome run directories could not be created.",
         call. = FALSE)
  }

  log_lines <- if (file.exists(log_path)) {
    readLines(log_path, warn = FALSE)
  } else {
    c(
      paste0("run_id: ", run_id),
      "coefficient_visibility: restricted",
      "row_level_public_output: forbidden",
      "completed_dataset_persistence: forbidden",
      paste0("workers: ", workers),
      paste0("freeze_contract_sha256: ", contract_sha)
    )
  }
  append_log <- function(text) {
    line <- paste0(
      format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z"), " ", text
    )
    log_lines <<- c(log_lines, line)
    v45c_atomic_write_lines(log_lines, log_path)
    message(text)
  }
  state <- if (file.exists(state_path)) {
    v45c_read_tsv(state_path)
  } else {
    v45c_state_template()
  }
  template <- v45c_state_template()
  if (!identical(names(state), names(template)) ||
      !identical(state$module, template$module) ||
      any(!state$status %in%
          c("NOT_RUN", "RUNNING", "RESTRICTED_COMPLETE"))) {
    stop("Restricted module state schema drifted.", call. = FALSE)
  }
  if (any(state$status == "RUNNING")) {
    stop(
      "An interrupted RUNNING module requires audit and a new run ID.",
      call. = FALSE
    )
  }
  state_path_alias <- substring(state_path, nchar(root) + 2L)
  if (file.exists(current_path) && !supersede_interrupted) {
    existing_current <- v45c_read_tsv(current_path)
    v45c_validate_existing_current_pointer(
      pointer = existing_current,
      run_id = run_id,
      state_path_alias = state_path_alias,
      state_sha256 = v45c_sha256_file(state_path),
      freeze_contract_sha256 = contract_sha
    )
  }
  supersession_audit_path <- NA_character_
  supersession_audit_sha256 <- NA_character_
  if (supersede_interrupted) {
    audit_dir <- file.path(public_root, "supersession_audit")
    dir.create(audit_dir, recursive = TRUE, showWarnings = FALSE)
    supersession_audit_path <- file.path(
      audit_dir, paste0(run_id, "_supersession.tsv")
    )
    if (file.exists(supersession_audit_path)) {
      stop(
        "Supersession aggregate audit sidecar already exists.",
        call. = FALSE
      )
    }
    v45c_atomic_write_tsv(data.frame(
      supersession_id = paste0(
        "supersede_", supersession$old_run_id, "_to_", run_id
      ),
      old_run_id = supersession$old_run_id,
      old_execution_pid = supersession$old_pid,
      old_execution_pid_source = supersession$old_pid_source,
      old_pointer_sha256 = supersession$old_pointer_sha256,
      old_state_path_alias = supersession$old_state_path_alias,
      old_state_sha256 = supersession$old_state_sha256,
      old_running_modules = supersession$old_running_modules,
      new_run_id = run_id,
      new_state_path_alias = state_path_alias,
      freeze_contract_sha256 = contract_sha,
      stale_lock_status = stale_lock_status,
      stale_lock_archive_path_alias = stale_lock_archive_alias,
      stale_lock_owner_sha256 = stale_lock_owner_sha256,
      old_restricted_outputs_modified = "no",
      row_level_or_coefficient_content = "none",
      superseded_at_utc = format(
        Sys.time(), "%Y-%m-%dT%H:%M:%SZ", tz = "UTC"
      ),
      stringsAsFactors = FALSE
    ), supersession_audit_path)
    supersession_audit_sha256 <-
      v45c_sha256_file(supersession_audit_path)
  }

  write_state <- function() {
    v45c_atomic_write_tsv(state, state_path)
    pointer <- data.frame(
      run_id = run_id,
      state_path_alias = state_path_alias,
      state_sha256 = v45c_sha256_file(state_path),
      freeze_contract_sha256 = contract_sha,
      coefficient_visibility = "RESTRICTED",
      independent_validation_status = "NOT_RUN",
      stringsAsFactors = FALSE
    )
    v45c_atomic_write_tsv(pointer, current_path)
    invisible(TRUE)
  }
  write_state()
  if (supersede_interrupted) {
    append_log(paste0(
      "Superseded interrupted run ", supersession$old_run_id,
      "; aggregate audit SHA-256=", supersession_audit_sha256,
      "; stale lock status=", stale_lock_status,
      "; old restricted outputs modified=no."
    ))
  }

  module_path <- function(module) {
    file.path(root, v45c_run_alias(run_id, module))
  }
  begin_module <- function(module) {
    row <- match(module, state$module)
    if (is.na(row) || state$status[[row]] != "NOT_RUN") {
      stop(module, " was already attempted.", call. = FALSE)
    }
    state$status[[row]] <<- "RUNNING"
    write_state()
    append_log(paste0(module, " transaction started."))
  }
  publish_module <- function(module, object) {
    row <- match(module, state$module)
    if (is.na(row) || state$status[[row]] != "RUNNING") {
      stop(module, " is not in RUNNING state.", call. = FALSE)
    }
    path <- module_path(module)
    if (file.exists(path)) {
      stop("Refusing to overwrite restricted module output.",
           call. = FALSE)
    }
    object$schema_version <- paste0(
      "v45_1_charls_", gsub("-", "_", module, fixed = TRUE),
      "_restricted"
    )
    object$run_id <- run_id
    object$created_at_utc <- format(
      Sys.time(), "%Y-%m-%dT%H:%M:%SZ", tz = "UTC"
    )
    object$freeze_contract_sha256 <- contract_sha
    object$coefficient_visibility <- "RESTRICTED"
    object$completed_dataset_saved <- FALSE
    object$model_object_saved <- FALSE
    object$row_level_data_saved <- FALSE
    object$individual_probability_or_weight_saved <- FALSE
    object$independent_validation_status <- "NOT_RUN"
    v45c_atomic_save_rds(object, path)
    state$status[[row]] <<- "RESTRICTED_COMPLETE"
    state$output_path_alias[[row]] <<-
      v45c_run_alias(run_id, module)
    state$output_sha256[[row]] <<- v45c_sha256_file(path)
    state$completed_at[[row]] <<- format(
      Sys.time(), "%Y-%m-%dT%H:%M:%S%z"
    )
    write_state()
    append_log(paste0(
      module, " completed; restricted SHA-256=",
      state$output_sha256[[row]]
    ))
    invisible(path)
  }
  read_module <- function(module) {
    row <- match(module, state$module)
    if (is.na(row) ||
        state$status[[row]] != "RESTRICTED_COMPLETE" ||
        is.na(state$output_path_alias[[row]]) ||
        is.na(state$output_sha256[[row]])) {
      stop(module, " prerequisite is not complete.", call. = FALSE)
    }
    path <- v45c_safe_alias(
      root, state$output_path_alias[[row]],
      "derived_sensitive/v45/charls_addendum_v45_1/outcome_execution/m50"
    )
    if (!identical(
          v45c_sha256_file(path), state$output_sha256[[row]]
        )) {
      stop(module, " restricted output hash drifted.", call. = FALSE)
    }
    value <- readRDS(path)
    if (!identical(value$freeze_contract_sha256, contract_sha) ||
        value$coefficient_visibility != "RESTRICTED" ||
        value$independent_validation_status != "NOT_RUN") {
      stop(module, " restricted object metadata drifted.",
           call. = FALSE)
    }
    v45c_assert_completed_module_gate(module, value)
    value
  }
  require_anchor <- function() {
    if (state$status[state$module == "anchor-point"] !=
        "RESTRICTED_COMPLETE") {
      stop(
        "The exact v44/v45 anchor-point gate must PASS first.",
        call. = FALSE
      )
    }
    invisible(read_module("anchor-point"))
  }

  context <- NULL
  get_context <- function() {
    if (is.null(context)) {
      context <<- v45c_load_context(root, contract)
    }
    context
  }

  run_anchor <- function() {
    begin_module("anchor-point")
    mids <- v45c_load_mids(root, contract, "MI-C0")
    context_value <- get_context()
    registered_failure <- NULL
    results <- tryCatch(
      v45c_parallel_map(
        seq_len(50L),
        function(index) {
          v45c_anchor_one_imputation(
            mids, index, context_value
          )
        },
        workers, "MI-C0 exact v44/v45 point anchor", append_log
      ),
      v45c_registered_stage_stop = function(error) {
        registered_failure <<- error
        NULL
      }
    )
    if (!is.null(registered_failure)) {
      object <- list(
        module = "anchor-point",
        mi_object = "MI-C0",
        requested_m = 50L,
        anchor = v45c_anchor_failure_object(
          registered_failure
        ),
        sample_anchors = data.frame(),
        no_Rao_Wu_SE_identity_claim = TRUE
      )
      publish_module("anchor-point", object)
      stop(
        "The restricted v44/v45 anchor is not estimable; ",
        "a minimal FAIL sidecar was retained and release is blocked.",
        call. = FALSE
      )
    }
    anchor <- v45c_anchor_object(results)
    object <- list(
      module = "anchor-point",
      mi_object = "MI-C0",
      requested_m = 50L,
      anchor = anchor,
      sample_anchors = data.frame(
        sample_id = "charls_primary_all_windows",
        imputation = seq_len(50L),
        n = 12555L, events_or_responses = 1735L,
        period_rows = 45503L, psu = 433L, dfcom = 432L,
        stringsAsFactors = FALSE
      ),
      no_Rao_Wu_SE_identity_claim = TRUE
    )
    publish_module("anchor-point", object)
    if (!identical(anchor$gate, "PASS")) {
      stop(
        "The restricted v44/v45 anchor identity gate is FAIL; ",
        "the restricted FAIL sidecar was retained and release is blocked.",
        call. = FALSE
      )
    }
  }

  run_replicate <- function(
      module, object_id, one_fun, scalar_map,
      joint_definitions = list()) {
    require_anchor()
    is_prefix <- endsWith(module, "-prefix")
    is_full <- endsWith(module, "-full")
    if (!xor(is_prefix, is_full)) {
      stop("Replicate module suffix is invalid.", call. = FALSE)
    }
    prefix_module <- sub("-full$", "-prefix", module)
    prefix <- NULL
    if (is_full) {
      prefix <- read_module(prefix_module)
      if (!identical(prefix$replicate_indices, seq_len(250L)) ||
          !prefix$prefix_gate %in% c("GO", "CAUTION")) {
        stop(prefix_module, " did not authorize columns 251-500.",
             call. = FALSE)
      }
    }
    begin_module(module)
    mids <- v45c_load_mids(root, contract, object_id)
    context_value <- get_context()
    replicate_indices <- if (is_prefix) seq_len(250L) else 251:500
    registered_failure <- NULL
    results <- tryCatch(
      v45c_parallel_map(
        seq_len(50L),
        function(index) {
          one_fun(
            mids, index, replicate_indices, context_value,
            if (is.null(prefix)) NULL else prefix$results[[index]]
          )
        },
        workers,
        paste0(object_id, " ", module, " literal replicate columns"),
        append_log
      ),
      v45c_registered_stage_stop = function(error) {
        registered_failure <<- error
        NULL
      }
    )
    if (!is.null(registered_failure)) {
      object <- v45c_point_failure_object(
        module = module,
        object_id = object_id,
        is_prefix = is_prefix,
        is_full = is_full,
        replicate_indices = replicate_indices,
        prefix_sha256 = if (is_full) {
          state$output_sha256[state$module == prefix_module]
        } else {
          NA_character_
        },
        failure = registered_failure
      )
      publish_module(module, object)
      stop(
        module,
        " point fit is numerically/support non-estimable or reached a ",
        "registered W2 diagnostic STOP; the minimal restricted reason ",
        "was retained and downstream release is blocked.",
        call. = FALSE
      )
    }
    gate <- v45c_module_gate(results)
    object <- list(
      module = module,
      mi_object = object_id,
      requested_m = 50L,
      replicate_indices = if (is_prefix) {
        seq_len(250L)
      } else {
        seq_len(500L)
      },
      executed_in_this_transaction = replicate_indices,
      prefix_sha256 = if (is_full) {
        state$output_sha256[state$module == prefix_module]
      } else {
        NA_character_
      },
      literal_prefix_identity = if (is_full) TRUE else NA,
      results = results,
      sample_anchors = do.call(
        rbind, lapply(results, `[[`, "sample_anchors")
      ),
      minimum_valid_replicate_fraction =
        gate$minimum_valid_fraction,
      prefix_gate = if (is_prefix) gate$gate else NA_character_,
      full_gate = if (is_full) gate$gate else NA_character_,
      coefficient_blind_prefix_gate = is_prefix,
      prefix_pooling_or_release_performed = FALSE,
      no_replacement_replicates = TRUE,
      variance_rule = "1/(B_valid-1)",
      common_failure_masks_preserved = TRUE
    )
    if (is_full) {
      action <- v45c_pooling_action(TRUE, gate$gate)
      if (identical(action, "NOT_PERFORMED_FULL_GATE_STOP")) {
        object$pooling_status <- action
        object$pooling_failure_class <-
          "VALID_REPLICATE_FRACTION_STOP"
        object$pooling_failure_reason <- paste0(
          "minimum_valid_replicate_fraction=",
          format(
            gate$minimum_valid_fraction,
            digits = 17, scientific = FALSE
          )
        )
      } else {
        pooling_failure_class <- ""
        pooling_failure_reason <- ""
        pooled <- tryCatch(
          v45c_pool_full_module(
            results, scalar_map, joint_definitions
          ),
          v45c_numeric_failure = function(error) {
            pooling_failure_class <<- error$failure_class
            pooling_failure_reason <<- conditionMessage(error)
            NULL
          }
        )
        if (is.null(pooled)) {
          object$pooling_status <- "NOT_ESTIMABLE_WITH_REASON"
          object$pooling_failure_class <- pooling_failure_class
          object$pooling_failure_reason <- pooling_failure_reason
        } else {
          object$pooling_status <- "COMPLETE"
          object$pooling_failure_class <- ""
          object$pooling_failure_reason <- ""
          object$per_imputation <- pooled$per_imputation
          object$pooled_scalar <- pooled$pooled_scalar
          object$joint_results <- pooled$joint_results
          pooled$m100_trigger_metadata$affected_MI_object <- object_id
          pooled$m100_trigger_metadata$affected_scope <-
            if (object_id == "MI-C0") {
              "ALL_MI_C0_MODULES"
            } else {
              "RESPONSE_IPW_AND_ALL_W2_OUTCOMES"
            }
          object$m100_trigger_metadata <-
            pooled$m100_trigger_metadata
        }
      }
    } else {
      object$pooling_status <- "NOT_APPLICABLE_PREFIX"
      object$pooling_failure_class <- ""
      object$pooling_failure_reason <- ""
    }
    if (startsWith(module, "W2-")) {
      object$response_point_diagnostics <- do.call(
        rbind,
        lapply(results, `[[`, "response_point_diagnostic")
      )
      object$response_replicate_diagnostics <- do.call(
        rbind,
        lapply(results, `[[`, "response_replicate_diagnostics")
      )
      expected_rows <- 50L * if (is_prefix) 250L else 500L
      if (nrow(object$response_point_diagnostics) != 50L ||
          nrow(object$response_replicate_diagnostics) !=
            expected_rows) {
        stop("W2 compact diagnostic cardinality failed.",
             call. = FALSE)
      }
      object$response_coefficients_saved <- FALSE
      object$individual_probability_or_IPW_saved <- FALSE
      object$capped_results_can_rescue_uncapped <- FALSE
    }
    publish_module(module, object)
    if (gate$gate == "STOP") {
      stop(
        module,
        " valid-replicate-fraction gate is STOP; downstream release blocked.",
        call. = FALSE
      )
    }
    if (is_full &&
        !identical(object$pooling_status, "COMPLETE")) {
      stop(
        module,
        " pooling is numerically/support non-estimable; restricted ",
        "reason retained and downstream release blocked.",
        call. = FALSE
      )
    }
  }

  runners <- list(
    `anchor-point` = run_anchor,
    `trial-prefix` = function() run_replicate(
      "trial-prefix", "MI-C0", v45c_trial_one_imputation,
      v45c_trial_scalar_map()
    ),
    `trial-full` = function() run_replicate(
      "trial-full", "MI-C0", v45c_trial_one_imputation,
      v45c_trial_scalar_map()
    ),
    `inconsistency-prefix` = function() run_replicate(
      "inconsistency-prefix", "MI-C0",
      v45c_inconsistency_one_imputation,
      v45c_inconsistency_scalar_map(),
      v45c_inconsistency_joint_definitions()
    ),
    `inconsistency-full` = function() run_replicate(
      "inconsistency-full", "MI-C0",
      v45c_inconsistency_one_imputation,
      v45c_inconsistency_scalar_map(),
      v45c_inconsistency_joint_definitions()
    ),
    `adjacent-prefix` = function() run_replicate(
      "adjacent-prefix", "MI-C0", v45c_adjacent_one_imputation,
      v45c_adjacent_scalar_map()
    ),
    `adjacent-full` = function() run_replicate(
      "adjacent-full", "MI-C0", v45c_adjacent_one_imputation,
      v45c_adjacent_scalar_map()
    ),
    `timehet-prefix` = function() run_replicate(
      "timehet-prefix", "MI-C0", v45c_timehet_one_imputation,
      v45c_timehet_scalar_map(),
      v45c_timehet_joint_definitions()
    ),
    `timehet-full` = function() run_replicate(
      "timehet-full", "MI-C0", v45c_timehet_one_imputation,
      v45c_timehet_scalar_map(),
      v45c_timehet_joint_definitions()
    ),
    `W2-prefix` = function() run_replicate(
      "W2-prefix", "MI-C2", v45c_w2_one_imputation,
      v45c_w2_scalar_map()
    ),
    `W2-full` = function() run_replicate(
      "W2-full", "MI-C2", v45c_w2_one_imputation,
      v45c_w2_scalar_map()
    )
  )
  execution_order <- v45c_module_rows()
  requested <- if (module_requested == "all") {
    execution_order
  } else {
    module_requested
  }
  append_log(paste0("Requested module: ", module_requested))
  for (module in requested) {
    if (module_requested == "all" &&
        state$status[state$module == module] ==
          "RESTRICTED_COMPLETE") {
      append_log(paste0(module, " already complete; verified and skipped."))
      invisible(read_module(module))
      next
    }
    runners[[module]]()
  }
  append_log("Requested restricted execution completed.")
  cat("V45_CHARLS_OUTCOME_RESTRICTED_EXECUTION_COMPLETE\n")
  cat("run_id=", run_id, "\n", sep = "")
  cat("coefficient_visibility=RESTRICTED\n")
  cat("independent_validation_status=NOT_RUN\n")
  invisible(TRUE)
}

v45c_library_only <- identical(
  Sys.getenv("V45_CHARLS_OUTCOME_LIBRARY_ONLY", unset = "no"),
  "yes"
) || "--library-only" %in% commandArgs(trailingOnly = TRUE)

if (sys.nframe() == 0L && !v45c_library_only) {
  v45c_main()
}
