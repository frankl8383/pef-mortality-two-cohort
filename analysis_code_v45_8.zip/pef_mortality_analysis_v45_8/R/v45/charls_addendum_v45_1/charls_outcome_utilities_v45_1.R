# CHARLS v45.1 outcome-stage pure utilities.
#
# This file defines functions only. It never reads project data, fits a model
# while being sourced, creates random numbers, or writes an artifact unless an
# atomic-write function is explicitly called by an authorized execution script.
#
# Provenance:
# - weighted mean/variance, Kish ESS, type-7 IPW caps, scalar Rubin pooling,
#   and IPW SMD mechanics adapt the validated v45 NHANES utilities in
#   R/v45/11_nhanes_outcome_utilities_v45.R;
# - trial summaries and the restricted-cubic basis reproduce the frozen v43
#   CHARLS authority in R/v43/04_charls_stage3_primary_mortality.R
#   (authority SHA-256
#   bc759aab44691deb5a920a4017c7b51bfe7c5694959b27ae9aa95462fba5908d);
# - direct paired-replicate covariance follows
#   charls_pure_functions_v45_1.R, tightened here to one explicit common-valid
#   mask and the post-deletion factor 1/(B_valid-1).
#
# Individual probabilities, availability factors, row replicate multipliers,
# and composite weights are wrapped as restricted in-memory objects. All atomic
# writers below fail closed if such an object is supplied.

options(stringsAsFactors = FALSE)

v45_charls_outcome_require_namespace <- function(package) {
  if (!requireNamespace(package, quietly = TRUE)) {
    stop("Required package is unavailable: ", package, call. = FALSE)
  }
  invisible(TRUE)
}

v45_charls_outcome_sha256_file <- function(path) {
  v45_charls_outcome_require_namespace("digest")
  if (length(path) != 1L || is.na(path) || !nzchar(path) ||
      !file.exists(path) || dir.exists(path) || nzchar(Sys.readlink(path))) {
    stop("SHA-256 requires one regular non-symlink file.", call. = FALSE)
  }
  digest::digest(path, algo = "sha256", file = TRUE)
}

v45_charls_outcome_sha256_text <- function(lines) {
  v45_charls_outcome_require_namespace("digest")
  digest::digest(
    enc2utf8(paste(as.character(lines), collapse = "\n")),
    algo = "sha256", serialize = FALSE
  )
}

v45_charls_outcome_sha256_object <- function(object) {
  v45_charls_outcome_require_namespace("digest")
  digest::digest(object, algo = "sha256", serialize = TRUE)
}

v45_charls_outcome_restricted <- function(payload, role, aggregate = NULL) {
  if (length(role) != 1L || is.na(role) || !nzchar(role)) {
    stop("A restricted object requires one nonempty role.", call. = FALSE)
  }
  structure(
    list(
      role = as.character(role),
      payload = payload,
      aggregate = aggregate,
      persistence_allowed = FALSE
    ),
    class = "v45_charls_outcome_restricted"
  )
}

print.v45_charls_outcome_restricted <- function(x, ...) {
  cat(
    "<v45_charls_outcome_restricted role=", x$role,
    "; persistence_allowed=FALSE>\n", sep = ""
  )
  invisible(x)
}

as.data.frame.v45_charls_outcome_restricted <- function(
    x, row.names = NULL, optional = FALSE, ...) {
  stop(
    "Restricted individual probability/weight objects may not be coerced ",
    "for persistence.", call. = FALSE
  )
}

v45_charls_outcome_restricted_payload <- function(x, expected_role = NULL) {
  if (!inherits(x, "v45_charls_outcome_restricted") ||
      !identical(x$persistence_allowed, FALSE)) {
    stop("Expected a restricted in-memory CHARLS object.", call. = FALSE)
  }
  if (!is.null(expected_role) &&
      !grepl(expected_role, x$role, fixed = TRUE)) {
    stop("Restricted object role does not match the requested use.",
         call. = FALSE)
  }
  x$payload
}

v45_charls_outcome_contains_restricted <- function(x) {
  if (inherits(x, "v45_charls_outcome_restricted")) return(TRUE)
  if (!is.list(x)) return(FALSE)
  any(vapply(x, v45_charls_outcome_contains_restricted, logical(1)))
}

v45_charls_outcome_assert_persistable <- function(x, role = "artifact") {
  if (v45_charls_outcome_contains_restricted(x)) {
    stop(
      role, " contains individual probabilities, factors, multipliers, or ",
      "weights and is forbidden from persistence.", call. = FALSE
    )
  }
  invisible(TRUE)
}

v45_charls_outcome_atomic_target <- function(path) {
  if (length(path) != 1L || is.na(path) || !nzchar(path)) {
    stop("Atomic output path must be one nonempty string.", call. = FALSE)
  }
  directory <- dirname(path)
  if (!dir.exists(directory)) {
    dir.create(directory, recursive = TRUE, showWarnings = FALSE)
  }
  if (!dir.exists(directory) || nzchar(Sys.readlink(directory))) {
    stop("Atomic output directory is absent or a symlink.", call. = FALSE)
  }
  tempfile(paste0(".", basename(path), "."), tmpdir = directory)
}

v45_charls_outcome_atomic_promote <- function(temporary, path) {
  if (!file.exists(temporary) || dir.exists(temporary)) {
    stop("Atomic temporary file was not created.", call. = FALSE)
  }
  if (file.exists(path) && !file.remove(path)) {
    stop("Could not replace an existing atomic target.", call. = FALSE)
  }
  if (!file.rename(temporary, path)) {
    stop("Atomic promotion failed.", call. = FALSE)
  }
  invisible(normalizePath(path, mustWork = TRUE))
}

v45_charls_outcome_atomic_write_lines <- function(lines, path) {
  v45_charls_outcome_assert_persistable(lines, "text artifact")
  temporary <- v45_charls_outcome_atomic_target(path)
  on.exit(if (file.exists(temporary)) unlink(temporary), add = TRUE)
  writeLines(enc2utf8(as.character(lines)), temporary, useBytes = TRUE)
  v45_charls_outcome_atomic_promote(temporary, path)
}

v45_charls_outcome_atomic_write_tsv <- function(data, path) {
  v45_charls_outcome_assert_persistable(data, "TSV artifact")
  if (!is.data.frame(data)) stop("TSV artifact must be a data frame.",
                                 call. = FALSE)
  temporary <- v45_charls_outcome_atomic_target(path)
  on.exit(if (file.exists(temporary)) unlink(temporary), add = TRUE)
  utils::write.table(
    data, temporary, sep = "\t", row.names = FALSE, col.names = TRUE,
    quote = TRUE, na = ""
  )
  v45_charls_outcome_atomic_promote(temporary, path)
}

v45_charls_outcome_atomic_save_rds <- function(object, path) {
  v45_charls_outcome_assert_persistable(object, "RDS artifact")
  temporary <- v45_charls_outcome_atomic_target(path)
  on.exit(if (file.exists(temporary)) unlink(temporary), add = TRUE)
  saveRDS(object, temporary, version = 3)
  v45_charls_outcome_atomic_promote(temporary, path)
}

v45_charls_outcome_weighted_mean <- function(x, weight) {
  x <- as.numeric(x)
  weight <- as.numeric(weight)
  if (length(x) != length(weight)) {
    stop("Weighted-mean inputs have different lengths.", call. = FALSE)
  }
  keep <- is.finite(x) & is.finite(weight) & weight > 0
  if (!any(keep)) return(NA_real_)
  sum(x[keep] * weight[keep]) / sum(weight[keep])
}

v45_charls_outcome_weighted_variance <- function(x, weight) {
  x <- as.numeric(x)
  weight <- as.numeric(weight)
  if (length(x) != length(weight)) {
    stop("Weighted-variance inputs have different lengths.", call. = FALSE)
  }
  keep <- is.finite(x) & is.finite(weight) & weight > 0
  if (sum(keep) < 2L) return(NA_real_)
  center <- v45_charls_outcome_weighted_mean(x[keep], weight[keep])
  sum(weight[keep] * (x[keep] - center)^2) / sum(weight[keep])
}

v45_charls_outcome_quantile_type7 <- function(x, probability) {
  x <- as.numeric(x)
  probability <- as.numeric(probability)
  x <- x[is.finite(x)]
  if (!length(x) || !length(probability) ||
      any(!is.finite(probability) | probability < 0 | probability > 1)) {
    stop("Type-7 quantile received invalid values or probabilities.",
         call. = FALSE)
  }
  as.numeric(stats::quantile(
    x, probs = probability, names = FALSE, type = 7
  ))
}

v45_charls_outcome_weighted_cdf_quantile <- function(
    x, weight, probability) {
  x <- as.numeric(x)
  weight <- as.numeric(weight)
  probability <- as.numeric(probability)
  if (length(x) != length(weight) || !length(probability) ||
      any(!is.finite(probability) | probability < 0 | probability > 1)) {
    stop("Weighted-CDF quantile received an invalid contract.",
         call. = FALSE)
  }
  keep <- is.finite(x) & is.finite(weight) & weight > 0
  x <- x[keep]
  weight <- weight[keep]
  if (!length(x)) return(rep(NA_real_, length(probability)))
  order_index <- order(x, method = "radix")
  x <- x[order_index]
  cumulative <- cumsum(weight[order_index]) / sum(weight)
  vapply(
    probability,
    function(p) x[[which(cumulative >= p)[[1L]]]],
    numeric(1)
  )
}

v45_charls_outcome_kish_ess <- function(weight) {
  weight <- as.numeric(weight)
  weight <- weight[is.finite(weight) & weight > 0]
  if (!length(weight)) return(NA_real_)
  sum(weight)^2 / sum(weight^2)
}

v45_charls_outcome_passive_bmi <- function(
    height_m, weight_kg, tolerance = 1e-12) {
  height_m <- as.numeric(height_m)
  weight_kg <- as.numeric(weight_kg)
  if (length(height_m) != length(weight_kg) ||
      !length(height_m) ||
      any(!is.finite(height_m) | height_m <= 0) ||
      any(!is.finite(weight_kg) | weight_kg <= 0)) {
    stop("Passive BMI requires finite positive height and weight.",
         call. = FALSE)
  }
  bmi <- weight_kg / height_m^2
  error <- max(abs(bmi - weight_kg / height_m^2))
  if (!is.finite(error) || error > tolerance) {
    stop("Passive BMI identity failed.", call. = FALSE)
  }
  bmi
}

v45_charls_outcome_factor_levels <- function() {
  list(
    sex_code = c("1", "2"),
    smoking_status_3 = c("never", "former", "current"),
    raeducl = c("1", "2", "3"),
    h1rural = c("0", "1"),
    end_wave_full = c("2", "3", "4", "5"),
    end_wave_W2_landmark = c("3", "4", "5"),
    binary_disease = c("0", "1"),
    pef_w1_valid_n = c("3", "2", "1"),
    logical_trial_quality = c("false", "true"),
    cesd_category = c("0-9", "10-19", "20-30")
  )
}

v45_charls_outcome_fixed_factor <- function(x, factor_id) {
  catalog <- v45_charls_outcome_factor_levels()
  if (!factor_id %in% names(catalog)) {
    stop("Unknown fixed CHARLS factor: ", factor_id, call. = FALSE)
  }
  if (identical(factor_id, "logical_trial_quality")) {
    if (!is.logical(x)) {
      stop("Logical trial-quality fields must remain logical.",
           call. = FALSE)
    }
    value <- ifelse(is.na(x), NA_character_, ifelse(x, "true", "false"))
  } else {
    value <- as.character(x)
    value[is.na(x)] <- NA_character_
  }
  invalid <- !is.na(value) & !value %in% catalog[[factor_id]]
  if (any(invalid)) {
    stop(
      factor_id, " contains values outside its frozen levels: ",
      paste(unique(value[invalid]), collapse = "|"), call. = FALSE
    )
  }
  factor(value, levels = catalog[[factor_id]])
}

v45_charls_outcome_cesd_category <- function(cesd10) {
  cesd10 <- as.numeric(cesd10)
  invalid <- !is.na(cesd10) &
    (!is.finite(cesd10) | cesd10 < 0 | cesd10 > 30)
  if (any(invalid)) {
    stop("CESD-10 must lie in the frozen closed 0-to-30 range.",
         call. = FALSE)
  }
  factor(
    cut(
      cesd10, breaks = c(0, 10, 20, Inf),
      right = FALSE, labels = c("0-9", "10-19", "20-30")
    ),
    levels = c("0-9", "10-19", "20-30")
  )
}

v45_charls_outcome_rebuild_fixed_fields <- function(
    data, end_wave_scope = c("none", "full", "W2_landmark")) {
  end_wave_scope <- match.arg(end_wave_scope)
  if (!is.data.frame(data)) stop("Passive reconstruction requires data.",
                                 call. = FALSE)
  required <- c("height_m_w1", "weight_kg_w1")
  absent <- setdiff(required, names(data))
  if (length(absent)) {
    stop("Passive reconstruction lacks: ", paste(absent, collapse = ", "),
         call. = FALSE)
  }
  out <- data
  out$bmi_w1 <- v45_charls_outcome_passive_bmi(
    out$height_m_w1, out$weight_kg_w1
  )
  direct <- intersect(
    c("sex_code", "raeducl", "h1rural", "pef_w1_valid_n"),
    names(out)
  )
  for (name in direct) {
    out[[name]] <- v45_charls_outcome_fixed_factor(out[[name]], name)
  }
  logical_fields <- intersect(
    c(
      "pef_w1_standing", "pef_w1_full_effort",
      "pef_w1_boundary_any"
    ),
    names(out)
  )
  for (name in logical_fields) {
    out[[name]] <- v45_charls_outcome_fixed_factor(
      out[[name]], "logical_trial_quality"
    )
  }
  if (all(c("smoke_ever_w1", "smoke_now_w1") %in% names(out))) {
    ever <- as.numeric(as.character(out$smoke_ever_w1))
    now <- as.numeric(as.character(out$smoke_now_w1))
    invalid <- !is.finite(ever) | !is.finite(now) |
      !ever %in% 0:1 | !now %in% 0:1 | (ever == 0 & now == 1)
    if (any(invalid)) {
      stop("Smoking parent-child coherence failed.", call. = FALSE)
    }
    smoking <- ifelse(
      ever == 0, "never", ifelse(now == 1, "current", "former")
    )
    out$smoking_status_3 <- v45_charls_outcome_fixed_factor(
      smoking, "smoking_status_3"
    )
  } else if ("smoking_status_3" %in% names(out)) {
    out$smoking_status_3 <- v45_charls_outcome_fixed_factor(
      out$smoking_status_3, "smoking_status_3"
    )
  }
  disease <- c(
    "r1hibpe", "r1diabe", "r1cancre",
    "r1hearte", "r1stroke", "r1kidneye"
  )
  if (all(disease %in% names(out))) {
    matrix <- do.call(cbind, lapply(out[disease], function(x) {
      as.numeric(as.character(x))
    }))
    if (any(!is.finite(matrix) | !matrix %in% 0:1)) {
      stop("Nonpulmonary disease parents must be complete binary fields.",
           call. = FALSE)
    }
    out$nonpulmonary_comorbidity_count <- rowSums(matrix)
  }
  if ("age_w1" %in% names(out)) {
    age <- as.numeric(out$age_w1)
    if (any(!is.finite(age))) stop("Completed W1 age is non-finite.",
                                   call. = FALSE)
    out$age_w2_model <- age + 2
  }
  if ("cesd10_w1" %in% names(out)) {
    out$cesd_category <- v45_charls_outcome_cesd_category(out$cesd10_w1)
  }
  if ("end_wave" %in% names(out) && end_wave_scope != "none") {
    id <- if (end_wave_scope == "full") {
      "end_wave_full"
    } else {
      "end_wave_W2_landmark"
    }
    out$end_wave <- v45_charls_outcome_fixed_factor(out$end_wave, id)
  }
  out
}

v45_charls_outcome_trial_summaries <- function(
    trials, lower = 30, upper = 890, strict = TRUE) {
  trials <- as.matrix(trials)
  if (ncol(trials) != 3L || !nrow(trials)) {
    stop("Trial summaries require a nonempty three-column matrix.",
         call. = FALSE)
  }
  converted <- apply(trials, 2L, function(x) suppressWarnings(as.numeric(x)))
  converted <- matrix(converted, nrow = nrow(trials), ncol = 3L)
  nonnumeric <- !is.na(trials) & is.na(converted)
  out_of_range <- is.finite(converted) &
    (converted < lower | converted > upper)
  if (isTRUE(strict) && (any(nonnumeric) || any(out_of_range) ||
                         any(!is.na(converted) & !is.finite(converted)))) {
    stop("Trial matrix contains nonnumeric, nonfinite, or out-of-range values.",
         call. = FALSE)
  }
  valid <- is.finite(converted) & converted >= lower & converted <= upper
  clean <- converted
  clean[!valid] <- NA_real_
  valid_n <- rowSums(valid)
  row_function <- function(fun) {
    apply(clean, 1L, function(x) {
      x <- x[is.finite(x)]
      if (!length(x)) NA_real_ else fun(x)
    })
  }
  top_two <- apply(clean, 1L, function(x) {
    x <- sort(x[is.finite(x)], decreasing = TRUE)
    if (length(x) < 2L) NA_real_ else x[[1L]] - x[[2L]]
  })
  data.frame(
    PEF_max = row_function(max),
    PEF_mean = row_function(mean),
    PEF_median = row_function(stats::median),
    valid_n = valid_n,
    complete_three = valid_n == 3L,
    boundary_any = rowSums(valid & (clean == lower | clean == upper)) > 0L,
    top_two_difference = top_two,
    I_raw = log1p(top_two),
    stringsAsFactors = FALSE
  )
}

v45_charls_outcome_frozen_inconsistency_anchors <- function() {
  c(
    I_raw_weighted_mean = 2.6645548501904162,
    I_raw_weighted_population_SD = 1.4405336275941463,
    I_z_weighted_q05 = -1.8496998606277060,
    I_z_weighted_q35 = -0.1851116643749560,
    I_z_weighted_q65 = 0.5341300887087024,
    I_z_weighted_q95 = 1.2816810527429137
  )
}

v45_charls_outcome_inconsistency_scale <- function(
    I_raw, weight, complete_three) {
  if (length(I_raw) != length(weight) ||
      length(I_raw) != length(complete_three) ||
      anyNA(complete_three)) {
    stop("Inconsistency-scale inputs violate the common sample contract.",
         call. = FALSE)
  }
  keep <- as.logical(complete_three) & is.finite(I_raw) &
    is.finite(weight) & weight > 0
  center <- v45_charls_outcome_weighted_mean(I_raw[keep], weight[keep])
  variance <- v45_charls_outcome_weighted_variance(
    I_raw[keep], weight[keep]
  )
  scale <- sqrt(variance)
  if (!is.finite(center) || !is.finite(scale) || scale <= 0) {
    stop("Inconsistency scale is non-finite or degenerate.", call. = FALSE)
  }
  list(
    mean = center, variance = variance, sd = scale,
    n = sum(keep), weight_sum = sum(weight[keep])
  )
}

v45_charls_outcome_inconsistency_z <- function(I_raw, center, scale) {
  if (length(center) != 1L || length(scale) != 1L ||
      !is.finite(center) || !is.finite(scale) || scale <= 0) {
    stop("I_z requires one finite center and positive scale.",
         call. = FALSE)
  }
  (as.numeric(I_raw) - center) / scale
}

v45_charls_outcome_restricted_cubic_basis <- function(
    x, knots, prefix = "I_z") {
  x <- as.numeric(x)
  knots <- as.numeric(knots)
  if (length(knots) != 4L || any(!is.finite(knots)) ||
      any(diff(knots) <= 0)) {
    stop("Restricted-cubic basis requires four increasing finite knots.",
         call. = FALSE)
  }
  tp3 <- function(z) pmax(z, 0)^3
  nonlinear <- lapply(1:2, function(j) {
    (
      tp3(x - knots[j]) -
        tp3(x - knots[3]) *
          (knots[4] - knots[j]) / (knots[4] - knots[3]) +
        tp3(x - knots[4]) *
          (knots[3] - knots[j]) / (knots[4] - knots[3])
    ) / (knots[4] - knots[1])^2
  })
  out <- data.frame(x, nonlinear[[1L]], nonlinear[[2L]])
  names(out) <- paste0(
    prefix, c("_linear", "_nonlinear1", "_nonlinear2")
  )
  out
}

v45_charls_outcome_e0 <- function(
    pef, sex_code,
    male_mu = 352.0554437442698, male_sigma = 139.663376333644,
    female_mu = 250.41587378062366,
    female_sigma = 99.89645172261167) {
  pef <- as.numeric(pef)
  sex <- as.character(sex_code)
  invalid <- !is.na(pef) & !is.finite(pef)
  if (length(pef) != length(sex) || any(invalid) ||
      any(!is.na(sex) & !sex %in% c("1", "2"))) {
    stop("E0 inputs violate the frozen sex-scale contract.", call. = FALSE)
  }
  mu <- ifelse(sex == "1", male_mu, female_mu)
  sigma <- ifelse(sex == "1", male_sigma, female_sigma)
  (mu - pef) / sigma
}

v45_charls_outcome_longitudinal_identities <- function(E0_W1, E0_W2) {
  E0_W1 <- as.numeric(E0_W1)
  E0_W2 <- as.numeric(E0_W2)
  if (length(E0_W1) != length(E0_W2)) {
    stop("Longitudinal E0 vectors have different lengths.", call. = FALSE)
  }
  M12 <- (E0_W1 + E0_W2) / 2
  D12 <- E0_W2 - E0_W1
  if (any(abs(2 * M12 - E0_W1 - E0_W2) > 1e-12, na.rm = TRUE) ||
      any(abs(D12 - (E0_W2 - E0_W1)) > 1e-12, na.rm = TRUE)) {
    stop("M12/D12 algebraic identities failed.", call. = FALSE)
  }
  data.frame(E0_W1 = E0_W1, E0_W2 = E0_W2, M12 = M12, D12 = D12)
}

v45_charls_outcome_exact_match_join <- function(
    left, right, key = "participant_id", right_fields = NULL,
    require_same_key_set = TRUE, context = "restricted join") {
  if (!is.data.frame(left) || !is.data.frame(right) ||
      !key %in% names(left) || !key %in% names(right) ||
      !is.character(left[[key]]) || !is.character(right[[key]])) {
    stop(context, " requires data frames and exact character keys.",
         call. = FALSE)
  }
  if (anyNA(left[[key]]) || anyNA(right[[key]]) ||
      any(!nzchar(left[[key]])) || any(!nzchar(right[[key]])) ||
      anyDuplicated(left[[key]]) || anyDuplicated(right[[key]])) {
    stop(context, " keys are missing, empty, or duplicated.", call. = FALSE)
  }
  if (isTRUE(require_same_key_set) &&
      !setequal(left[[key]], right[[key]])) {
    stop(context, " one-to-one key sets differ.", call. = FALSE)
  }
  index <- match(left[[key]], right[[key]])
  if (anyNA(index) || !identical(right[[key]][index], left[[key]])) {
    stop(context, " explicit match failed.", call. = FALSE)
  }
  if (is.null(right_fields)) right_fields <- setdiff(names(right), key)
  if (any(!right_fields %in% names(right)) ||
      length(intersect(right_fields, names(left)))) {
    stop(context, " requested absent or duplicate right-side fields.",
         call. = FALSE)
  }
  out <- cbind(left, right[index, right_fields, drop = FALSE])
  rownames(out) <- rownames(left)
  if (nrow(out) != nrow(left) ||
      !identical(out[[key]], left[[key]])) {
    stop(context, " changed row order or cardinality.", call. = FALSE)
  }
  out
}

v45_charls_outcome_bind_actual_keys <- function(
    row_keys, key_map, multiplier_matrix, replicate_columns = NULL,
    key_column = "community_id", ordinal_column = "psu_ordinal") {
  if (!is.character(row_keys) || anyNA(row_keys) || any(!nzchar(row_keys)) ||
      !is.data.frame(key_map) ||
      !all(c(key_column, ordinal_column) %in% names(key_map)) ||
      !is.character(key_map[[key_column]]) ||
      anyNA(key_map[[key_column]]) ||
      anyDuplicated(key_map[[key_column]]) ||
      !identical(
        as.integer(key_map[[ordinal_column]]), seq_len(nrow(key_map))
      )) {
    stop("Actual-key binder received an invalid character-key map.",
         call. = FALSE)
  }
  multiplier_matrix <- as.matrix(multiplier_matrix)
  if (nrow(multiplier_matrix) != nrow(key_map) ||
      is.null(rownames(multiplier_matrix)) ||
      !identical(rownames(multiplier_matrix), key_map[[key_column]]) ||
      is.null(colnames(multiplier_matrix)) ||
      any(!is.finite(multiplier_matrix) | multiplier_matrix < 0)) {
    stop("Actual Rao-Wu matrix is not aligned to the frozen key map.",
         call. = FALSE)
  }
  if (is.null(replicate_columns)) {
    replicate_columns <- colnames(multiplier_matrix)
  }
  if (any(!replicate_columns %in% colnames(multiplier_matrix)) ||
      anyDuplicated(replicate_columns)) {
    stop("Requested Rao-Wu replicate columns are invalid.", call. = FALSE)
  }
  index <- match(row_keys, key_map[[key_column]])
  if (anyNA(index) ||
      !identical(key_map[[key_column]][index], row_keys)) {
    stop("One or more row keys are absent from the actual matrix.",
         call. = FALSE)
  }
  v45_charls_outcome_restricted(
    list(
      key_index = index,
      replicate_ids = replicate_columns,
      multipliers = multiplier_matrix[
        index, replicate_columns, drop = FALSE
      ]
    ),
    role = "individual_actual_key_replicate_multipliers",
    aggregate = data.frame(
      row_n = length(row_keys),
      unique_psu = length(unique(row_keys)),
      replicate_n = length(replicate_columns)
    )
  )
}

v45_charls_outcome_registered_formula <- function(
    registered_text, formula_id, exposure = NULL) {
  if (length(registered_text) != 1L || is.na(registered_text) ||
      !nzchar(registered_text) || length(formula_id) != 1L ||
      is.na(formula_id) || !nzchar(formula_id)) {
    stop("Formula registration requires nonempty text and ID.",
         call. = FALSE)
  }
  has_placeholder <- grepl("{EXPOSURE}", registered_text, fixed = TRUE)
  if (has_placeholder) {
    if (length(exposure) != 1L || is.na(exposure) ||
        !grepl("^[A-Za-z][A-Za-z0-9_.]*$", exposure)) {
      stop(formula_id, " requires one safe registered exposure.",
           call. = FALSE)
    }
    registered_text <- gsub(
      "{EXPOSURE}", exposure, registered_text, fixed = TRUE
    )
  } else if (!is.null(exposure)) {
    stop(formula_id, " does not permit an exposure substitution.",
         call. = FALSE)
  }
  formula_environment <- new.env(parent = baseenv())
  formula_environment$offset <- stats::offset
  formula <- stats::as.formula(
    registered_text, env = formula_environment
  )
  terms <- stats::terms(formula)
  labels <- attr(terms, "term.labels")
  if (anyDuplicated(labels) || length(all.vars(formula[[2L]])) != 1L) {
    stop(formula_id, " has duplicate terms or an invalid outcome.",
         call. = FALSE)
  }
  outcome <- all.vars(formula[[2L]])[[1L]]
  if (!outcome %in% c("period_event", "R_W2")) {
    stop(formula_id, " has an unauthorized outcome.", call. = FALSE)
  }
  text <- paste(deparse(formula), collapse = " ")
  if (outcome == "period_event") {
    if (!"factor(end_wave)" %in% labels ||
        length(attr(terms, "offset")) != 1L ||
        !grepl(
          "offset\\s*\\(\\s*log\\s*\\(\\s*nominal_years\\s*\\)\\s*\\)",
          text
        ) ||
        grepl("\\bwindow_id\\b", text)) {
      stop(formula_id, " violates the frozen person-period AST.",
           call. = FALSE)
    }
  } else {
    forbidden <- c(
      "pef_w2_trial1", "pef_w2_trial2", "mortality_outcome",
      "period_event", "nelson_aalen"
    )
    if (any(forbidden %in% all.vars(formula))) {
      stop(formula_id, " contains a forbidden response predictor.",
           call. = FALSE)
    }
  }
  formula
}

v45_charls_outcome_compile_glm_frame <- function(
    formula, data, model_id = "CHARLS_glm") {
  if (!inherits(formula, "formula") || !is.data.frame(data)) {
    stop(model_id, " requires a formula and data frame.", call. = FALSE)
  }
  frame <- stats::model.frame(
    formula, data = data, na.action = stats::na.fail,
    drop.unused.levels = FALSE
  )
  terms <- stats::terms(frame)
  x <- stats::model.matrix(terms, frame)
  y <- stats::model.response(frame)
  offset <- stats::model.offset(frame)
  if (is.null(offset)) offset <- rep(0, nrow(x))
  y <- as.numeric(y)
  if (!nrow(x) || nrow(x) != nrow(data) || length(y) != nrow(x) ||
      length(offset) != nrow(x) || any(!is.finite(x)) ||
      any(!is.finite(y)) || any(!y %in% 0:1) ||
      any(!is.finite(offset)) || qr(x)$rank != ncol(x) ||
      is.null(colnames(x)) || anyDuplicated(colnames(x))) {
    stop(model_id, " compiled matrix failed row/rank/finiteness gates.",
         call. = FALSE)
  }
  structure(
    list(
      x = x, y = y, offset = as.numeric(offset),
      coefficient_names = colnames(x),
      n = nrow(x), p = ncol(x), rank = qr(x)$rank
    ),
    class = "v45_charls_outcome_compiled_glm"
  )
}

v45_charls_outcome_glm_fit_compact <- function(
    compiled, weight, link = c("cloglog", "logit"),
    focal_terms = character(), model_id = "CHARLS_glm",
    return_probability = FALSE, maxit = 25L) {
  link <- match.arg(link)
  if (!inherits(compiled, "v45_charls_outcome_compiled_glm")) {
    stop(model_id, " requires a compiled GLM frame.", call. = FALSE)
  }
  weight <- as.numeric(weight)
  if (length(weight) != compiled$n ||
      any(!is.finite(weight) | weight < 0) ||
      sum(weight > 0) <= compiled$p ||
      !all(focal_terms %in% compiled$coefficient_names)) {
    stop(model_id, " has invalid weights, support, or focal terms.",
         call. = FALSE)
  }
  positive_mean <- mean(weight[weight > 0])
  weight <- weight / positive_mean
  warnings <- character()
  fit <- withCallingHandlers(
    tryCatch(
      stats::glm.fit(
        x = compiled$x, y = compiled$y, weights = weight,
        offset = compiled$offset,
        family = stats::quasibinomial(link = link),
        control = stats::glm.control(maxit = as.integer(maxit))
      ),
      error = function(e) structure(
        list(error = conditionMessage(e)),
        class = "v45_charls_outcome_glm_error"
      )
    ),
    warning = function(w) {
      warnings <<- c(warnings, conditionMessage(w))
      invokeRestart("muffleWarning")
    }
  )
  if (inherits(fit, "v45_charls_outcome_glm_error")) {
    stop(model_id, " failed: ", fit$error, call. = FALSE)
  }
  coefficients <- setNames(
    as.numeric(fit$coefficients), compiled$coefficient_names
  )
  probability <- as.numeric(fit$fitted.values)
  R <- tryCatch(
    qr.R(fit$qr)[seq_len(compiled$p), seq_len(compiled$p), drop = FALSE],
    error = function(e) matrix(NA_real_, compiled$p, compiled$p)
  )
  R_scale <- if (all(is.finite(R))) max(1, max(abs(R))) else NA_real_
  R_diagonal_pass <- all(is.finite(R)) &&
    all(abs(diag(R)) >
          .Machine$double.eps * compiled$p * R_scale)
  pearson <- (compiled$y - probability) /
    sqrt(fit$family$variance(probability))
  dispersion <- if (is.finite(fit$df.residual) && fit$df.residual > 0) {
    sum(weight * pearson^2) / fit$df.residual
  } else {
    NA_real_
  }
  covariance <- matrix(
    NA_real_, compiled$p, compiled$p,
    dimnames = list(
      compiled$coefficient_names, compiled$coefficient_names
    )
  )
  if (R_diagonal_pass && is.finite(dispersion) && dispersion > 0) {
    covariance_pivot <- chol2inv(R) * dispersion
    pivot <- fit$qr$pivot[seq_len(compiled$p)]
    covariance[pivot, pivot] <- covariance_pivot
  }
  covariance_pass <- tryCatch({
    covariance <- v45_charls_outcome_validate_covariance(
      covariance, compiled$coefficient_names,
      paste0(model_id, "/weighted_quasi_covariance"),
      positive_definite = TRUE
    )
    TRUE
  }, error = function(e) FALSE)
  valid <- isTRUE(fit$converged) && !isTRUE(fit$boundary) &&
    identical(as.integer(fit$rank), as.integer(compiled$p)) &&
    all(is.finite(coefficients)) && !length(warnings) &&
    R_diagonal_pass && is.finite(dispersion) && dispersion > 0 &&
    covariance_pass &&
    length(probability) == compiled$n &&
    all(is.finite(probability) & probability > 0 & probability < 1)
  if (!valid) {
    stop(model_id, " failed convergence/boundary/rank/open-probability gates.",
         call. = FALSE)
  }
  result <- list(
    coefficients = coefficients,
    covariance = covariance,
    diagnostics = data.frame(
      model_id = model_id,
      n = compiled$n,
      positive_weight_n = sum(weight > 0),
      events_positive_weight = sum(compiled$y[weight > 0] == 1),
      matrix_columns = compiled$p,
      matrix_rank = fit$rank,
      converged = isTRUE(fit$converged),
      boundary = isTRUE(fit$boundary),
      iterations = fit$iter,
      quasi_dispersion = dispersion,
      weighted_R_minimum_absolute_diagonal =
        if (all(is.finite(R))) min(abs(diag(R))) else NA_real_,
      covariance_minimum_eigenvalue =
        if (covariance_pass) min(eigen(
          covariance, symmetric = TRUE, only.values = TRUE
        )$values) else NA_real_,
      fitted_probability_min = min(probability),
      fitted_probability_max = max(probability),
      warnings = paste(unique(warnings), collapse = "; "),
      stringsAsFactors = FALSE
    )
  )
  if (isTRUE(return_probability)) {
    result$probability <- v45_charls_outcome_restricted(
      probability,
      role = paste0("individual_fitted_probability::", model_id),
      aggregate = data.frame(
        n = length(probability), minimum = min(probability),
        maximum = max(probability)
      )
    )
  }
  result
}

v45_charls_outcome_common_valid_mask <- function(
    component_success, replicate_ids = NULL) {
  if (is.list(component_success) && !is.data.frame(component_success)) {
    component_success <- do.call(cbind, component_success)
  }
  component_success <- as.matrix(component_success)
  if (!is.logical(component_success) || !nrow(component_success) ||
      !ncol(component_success) || anyNA(component_success)) {
    stop("Common-valid mask requires a complete logical matrix.",
         call. = FALSE)
  }
  if (is.null(replicate_ids)) replicate_ids <- rownames(component_success)
  if (is.null(replicate_ids) ||
      length(replicate_ids) != nrow(component_success) ||
      anyNA(replicate_ids) || any(!nzchar(replicate_ids)) ||
      anyDuplicated(replicate_ids)) {
    stop("Common-valid mask requires unique replicate IDs.",
         call. = FALSE)
  }
  setNames(rowSums(component_success) == ncol(component_success), replicate_ids)
}

v45_charls_outcome_replicate_covariance <- function(
    replicate_estimates, point_estimate, common_valid_mask) {
  replicate_estimates <- as.matrix(replicate_estimates)
  point_estimate <- as.numeric(point_estimate)
  if (!nrow(replicate_estimates) || !ncol(replicate_estimates) ||
      length(point_estimate) != ncol(replicate_estimates) ||
      is.null(colnames(replicate_estimates)) ||
      is.null(rownames(replicate_estimates)) ||
      is.null(names(common_valid_mask)) ||
      !identical(rownames(replicate_estimates), names(common_valid_mask)) ||
      length(common_valid_mask) != nrow(replicate_estimates) ||
      !is.logical(common_valid_mask) || anyNA(common_valid_mask) ||
      any(!is.finite(point_estimate)) ||
      sum(common_valid_mask) < 2L) {
    stop("Replicate covariance received an invalid common-mask contract.",
         call. = FALSE)
  }
  names(point_estimate) <- colnames(replicate_estimates)
  retained <- replicate_estimates[common_valid_mask, , drop = FALSE]
  if (any(!is.finite(retained))) {
    stop("A common-valid replicate contains a non-finite estimate.",
         call. = FALSE)
  }
  centered <- sweep(retained, 2L, point_estimate, FUN = "-")
  valid_n <- nrow(retained)
  covariance <- crossprod(centered) / (valid_n - 1)
  dimnames(covariance) <- list(
    colnames(replicate_estimates), colnames(replicate_estimates)
  )
  list(
    covariance = covariance,
    valid_n = valid_n,
    nominal_n = nrow(replicate_estimates),
    valid_fraction = valid_n / nrow(replicate_estimates),
    denominator = valid_n - 1L,
    variance_rule = "sum_centered_crossproduct/(B_valid-1)"
  )
}

v45_charls_outcome_replicate_variance <- function(
    replicate_estimates, point_estimate, common_valid_mask) {
  matrix <- matrix(
    as.numeric(replicate_estimates), ncol = 1L,
    dimnames = list(names(common_valid_mask), "theta")
  )
  result <- v45_charls_outcome_replicate_covariance(
    matrix, setNames(as.numeric(point_estimate), "theta"),
    common_valid_mask
  )
  list(
    variance = unname(result$covariance[[1L]]),
    valid_n = result$valid_n,
    nominal_n = result$nominal_n,
    valid_fraction = result$valid_fraction,
    denominator = result$denominator,
    variance_rule = result$variance_rule
  )
}

v45_charls_outcome_direct_paired_contrast <- function(
    replicate_estimates, point_estimate, contrast, common_valid_mask,
    contrast_id = "paired_contrast", tolerance = 1e-12) {
  replicate_estimates <- as.matrix(replicate_estimates)
  contrast_names <- names(contrast)
  contrast <- as.numeric(contrast)
  names(contrast) <- contrast_names
  if (is.null(names(point_estimate)) ||
      !identical(colnames(replicate_estimates), names(point_estimate)) ||
      is.null(names(contrast)) ||
      !identical(names(contrast), names(point_estimate)) ||
      all(contrast == 0) || any(!is.finite(contrast))) {
    stop(contrast_id, " has an invalid named contrast contract.",
         call. = FALSE)
  }
  covariance <- v45_charls_outcome_replicate_covariance(
    replicate_estimates, point_estimate, common_valid_mask
  )
  retained <- replicate_estimates[common_valid_mask, , drop = FALSE]
  point <- sum(point_estimate * contrast)
  replicate_contrast <- as.numeric(retained %*% contrast)
  direct <- sum((replicate_contrast - point)^2) /
    (length(replicate_contrast) - 1L)
  quadratic <- as.numeric(
    t(contrast) %*% covariance$covariance %*% contrast
  )
  scale <- max(1, abs(direct), abs(quadratic))
  if (!is.finite(direct) || !is.finite(quadratic) ||
      abs(direct - quadratic) > tolerance * scale) {
    stop(contrast_id, " direct and covariance variances disagree.",
         call. = FALSE)
  }
  data.frame(
    contrast_id = contrast_id,
    estimate = point,
    within_variance = direct,
    quadratic_variance = quadratic,
    valid_n = covariance$valid_n,
    nominal_n = covariance$nominal_n,
    valid_fraction = covariance$valid_fraction,
    stringsAsFactors = FALSE
  )
}

v45_charls_outcome_validate_covariance <- function(
    covariance, terms, context = "covariance",
    positive_definite = TRUE) {
  covariance <- as.matrix(covariance)
  if (!identical(dim(covariance), c(length(terms), length(terms))) ||
      is.null(rownames(covariance)) || is.null(colnames(covariance)) ||
      !identical(rownames(covariance), terms) ||
      !identical(colnames(covariance), terms) ||
      any(!is.finite(covariance))) {
    stop(context, " has invalid dimensions, names, or values.",
         call. = FALSE)
  }
  scale <- max(.Machine$double.xmin, max(abs(covariance)))
  if (max(abs(covariance - t(covariance))) >
      sqrt(.Machine$double.eps) * scale) {
    stop(context, " is not symmetric.", call. = FALSE)
  }
  covariance <- (covariance + t(covariance)) / 2
  eigenvalues <- eigen(
    covariance, symmetric = TRUE, only.values = TRUE
  )$values
  tolerance <- .Machine$double.eps *
    max(1, length(terms), max(abs(eigenvalues)))
  if (isTRUE(positive_definite) && min(eigenvalues) <= tolerance) {
    stop(context, " is not numerically positive definite.",
         call. = FALSE)
  }
  covariance
}

v45_charls_outcome_mce <- function(
    estimates, total_variance = NULL) {
  estimates <- as.numeric(estimates)
  if (length(estimates) < 2L || any(!is.finite(estimates))) {
    stop("MCE requires at least two finite imputation estimates.",
         call. = FALSE)
  }
  between <- stats::var(estimates)
  mce <- sqrt(between / length(estimates))
  fraction <- if (is.null(total_variance)) {
    NA_real_
  } else {
    if (length(total_variance) != 1L ||
        !is.finite(total_variance) || total_variance <= 0) {
      stop("MCE fraction requires positive total variance.",
           call. = FALSE)
    }
    mce / sqrt(total_variance)
  }
  c(
    between_variance = between,
    monte_carlo_error = mce,
    monte_carlo_error_fraction = fraction
  )
}

v45_charls_outcome_pool_scalar <- function(
    Q, U, dfcom, scalar_id = "scalar") {
  v45_charls_outcome_require_namespace("mice")
  Q <- as.numeric(Q)
  U <- as.numeric(U)
  if (length(Q) < 2L || length(Q) != length(U) ||
      any(!is.finite(Q)) || any(!is.finite(U) | U <= 0) ||
      length(dfcom) != 1L || !is.finite(dfcom) || dfcom <= 0) {
    stop(scalar_id, " received invalid Rubin inputs.", call. = FALSE)
  }
  pooled <- mice::pool.scalar(
    Q = Q, U = U, n = as.numeric(dfcom) + 1,
    k = 1, rule = "rubin1987"
  )
  se <- sqrt(pooled$t)
  critical <- if (is.finite(pooled$df)) {
    stats::qt(0.975, pooled$df)
  } else {
    stats::qnorm(0.975)
  }
  statistic <- pooled$qbar / se
  p <- if (is.finite(pooled$df)) {
    2 * stats::pt(abs(statistic), pooled$df, lower.tail = FALSE)
  } else {
    2 * stats::pnorm(abs(statistic), lower.tail = FALSE)
  }
  mce <- v45_charls_outcome_mce(Q, pooled$t)
  data.frame(
    scalar_id = scalar_id,
    m = pooled$m,
    estimate = pooled$qbar,
    standard_error = se,
    ci_low = pooled$qbar - critical * se,
    ci_high = pooled$qbar + critical * se,
    p_value = p,
    within_variance = pooled$ubar,
    between_variance = pooled$b,
    total_variance = pooled$t,
    df = pooled$df,
    dfcom = dfcom,
    fraction_missing_information = pooled$fmi,
    monte_carlo_error = unname(mce[["monte_carlo_error"]]),
    monte_carlo_error_fraction =
      unname(mce[["monte_carlo_error_fraction"]]),
    stringsAsFactors = FALSE
  )
}

v45_charls_outcome_pool_linear_combination <- function(
    Q_matrix, U_list, contrast, dfcom, contrast_id) {
  Q_matrix <- as.matrix(Q_matrix)
  if (is.null(colnames(Q_matrix)) || is.null(names(contrast)) ||
      !identical(colnames(Q_matrix), names(contrast)) ||
      length(U_list) != nrow(Q_matrix)) {
    stop(contrast_id, " has invalid linear-combination inputs.",
         call. = FALSE)
  }
  contrast <- as.numeric(contrast)
  names(contrast) <- colnames(Q_matrix)
  Q <- as.numeric(Q_matrix %*% contrast)
  U <- vapply(seq_along(U_list), function(i) {
    covariance <- v45_charls_outcome_validate_covariance(
      U_list[[i]], colnames(Q_matrix),
      paste0(contrast_id, "/U", i), positive_definite = TRUE
    )
    as.numeric(t(contrast) %*% covariance %*% contrast)
  }, numeric(1))
  result <- v45_charls_outcome_pool_scalar(
    Q, U, dfcom, scalar_id = contrast_id
  )
  result$exp_estimate <- exp(result$estimate)
  result$exp_ci_low <- exp(result$ci_low)
  result$exp_ci_high <- exp(result$ci_high)
  result
}

v45_charls_outcome_pool_multivariate_wald <- function(
    Q_matrix, U_list, test_id) {
  Q_matrix <- as.matrix(Q_matrix)
  terms <- colnames(Q_matrix)
  if (nrow(Q_matrix) < 2L || ncol(Q_matrix) < 2L ||
      is.null(terms) || anyDuplicated(terms) ||
      any(!is.finite(Q_matrix)) ||
      length(U_list) != nrow(Q_matrix)) {
    stop(test_id, " has invalid multivariate Rubin inputs.",
         call. = FALSE)
  }
  U <- lapply(seq_along(U_list), function(i) {
    v45_charls_outcome_validate_covariance(
      U_list[[i]], terms, paste0(test_id, "/U", i),
      positive_definite = TRUE
    )
  })
  Qbar <- colMeans(Q_matrix)
  Ubar <- Reduce(`+`, U) / length(U)
  B <- as.matrix(stats::cov(Q_matrix))
  dimnames(B) <- list(terms, terms)
  total <- Ubar + (1 + 1 / nrow(Q_matrix)) * B
  dimnames(total) <- list(terms, terms)
  total <- v45_charls_outcome_validate_covariance(
    total, terms, paste0(test_id, "/total"), positive_definite = TRUE
  )
  statistic <- as.numeric(crossprod(Qbar, solve(total, Qbar)))
  if (!is.finite(statistic) || statistic < -1e-10) {
    stop(test_id, " produced an invalid Wald statistic.",
         call. = FALSE)
  }
  statistic <- max(0, statistic)
  list(
    test = data.frame(
      test_id = test_id,
      terms = paste(terms, collapse = ";"),
      m = nrow(Q_matrix),
      df = ncol(Q_matrix),
      statistic = statistic,
      p_value = stats::pchisq(
        statistic, ncol(Q_matrix), lower.tail = FALSE
      ),
      stringsAsFactors = FALSE
    ),
    Qbar = Qbar,
    Ubar = Ubar,
    B = B,
    total = total,
    per_term_mce = sqrt(diag(B) / nrow(Q_matrix))
  )
}

v45_charls_outcome_validate_probability <- function(probability) {
  probability <- as.numeric(probability)
  if (!length(probability) ||
      any(!is.finite(probability) |
            probability <= 0 | probability >= 1)) {
    stop("Response probability must be finite and strictly inside (0,1).",
         call. = FALSE)
  }
  invisible(TRUE)
}

v45_charls_outcome_ipw_factor_contract <- function(
    probability, respondent, same_column_base_weight,
    column_id = "POINT") {
  probability <- as.numeric(probability)
  respondent <- as.logical(respondent)
  base <- as.numeric(same_column_base_weight)
  v45_charls_outcome_validate_probability(probability)
  if (length(probability) != length(respondent) ||
      length(probability) != length(base) || anyNA(respondent) ||
      any(!is.finite(base) | base < 0) || sum(base) <= 0 ||
      !any(respondent & base > 0)) {
    stop(column_id, " violates the same-column IPW contract.",
         call. = FALSE)
  }
  availability <- 1 / probability[respondent]
  caps <- c(
    uncapped = Inf,
    p99 = v45_charls_outcome_quantile_type7(availability, 0.99),
    p97_5 = v45_charls_outcome_quantile_type7(availability, 0.975)
  )
  raw <- cbind(
    original = 1,
    uncapped = availability,
    p99 = pmin(availability, caps[["p99"]]),
    p97_5 = pmin(availability, caps[["p97_5"]])
  )
  target_total <- sum(base)
  factors <- raw
  normalization <- c(original = 1, uncapped = NA, p99 = NA, p97_5 = NA)
  for (variant in c("uncapped", "p99", "p97_5")) {
    denominator <- sum(base[respondent] * raw[, variant])
    if (!is.finite(denominator) || denominator <= 0) {
      stop(column_id, "/", variant, " normalization failed.",
           call. = FALSE)
    }
    normalization[[variant]] <- target_total / denominator
    factors[, variant] <- raw[, variant] * normalization[[variant]]
  }
  summary <- data.frame(
    column_id = column_id,
    variant = colnames(factors),
    cap = c(NA_real_, Inf, caps[["p99"]], caps[["p97_5"]]),
    normalization = as.numeric(normalization),
    target_total = target_total,
    normalized_respondent_total = vapply(
      colnames(factors),
      function(variant) sum(base[respondent] * factors[, variant]),
      numeric(1)
    ),
    stringsAsFactors = FALSE
  )
  v45_charls_outcome_restricted(
    list(
      respondent = respondent,
      probability = probability,
      availability = availability,
      factors = factors,
      base_weight = base
    ),
    role = paste0("individual_ipw_factors::", column_id),
    aggregate = summary
  )
}

v45_charls_outcome_ipw_ess_aggregates <- function(factor_contract) {
  payload <- v45_charls_outcome_restricted_payload(
    factor_contract, "individual_ipw_factors"
  )
  respondent <- payload$respondent
  base <- payload$base_weight[respondent]
  base_ess <- v45_charls_outcome_kish_ess(base)
  rows <- lapply(colnames(payload$factors), function(variant) {
    composite <- base * payload$factors[, variant]
    ess <- v45_charls_outcome_kish_ess(composite)
    data.frame(
      variant = variant,
      same_respondent_base_ess = base_ess,
      composite_ess = ess,
      ess_ratio = ess / base_ess,
      stringsAsFactors = FALSE
    )
  })
  do.call(rbind, rows)
}

v45_charls_outcome_ipw_smd_aggregates <- function(
    factor_contract, balance_matrix,
    structurally_constant_columns = character()) {
  payload <- v45_charls_outcome_restricted_payload(
    factor_contract, "individual_ipw_factors"
  )
  balance_matrix <- as.matrix(balance_matrix)
  if (nrow(balance_matrix) != length(payload$respondent) ||
      is.null(colnames(balance_matrix)) ||
      "(Intercept)" %in% colnames(balance_matrix) ||
      any(!is.finite(balance_matrix)) ||
      any(!structurally_constant_columns %in% colnames(balance_matrix))) {
    stop("IPW balance matrix violates its frozen column contract.",
         call. = FALSE)
  }
  target_mean <- apply(
    balance_matrix, 2L, v45_charls_outcome_weighted_mean,
    weight = payload$base_weight
  )
  target_sd <- sqrt(apply(
    balance_matrix, 2L, v45_charls_outcome_weighted_variance,
    weight = payload$base_weight
  ))
  invalid_sd <- !is.finite(target_sd) | target_sd <= 0
  unauthorized <- names(target_sd)[invalid_sd &
    !names(target_sd) %in% structurally_constant_columns]
  if (length(unauthorized)) {
    stop(
      "Nonconstant balance columns have zero/nonfinite target SD: ",
      paste(unauthorized, collapse = "|"), call. = FALSE
    )
  }
  respondent <- payload$respondent
  per_column <- list()
  summary <- list()
  for (variant in colnames(payload$factors)) {
    weight <- payload$base_weight[respondent] *
      payload$factors[, variant]
    respondent_mean <- apply(
      balance_matrix[respondent, , drop = FALSE],
      2L, v45_charls_outcome_weighted_mean, weight = weight
    )
    smd <- (respondent_mean - target_mean) / target_sd
    smd[invalid_sd] <- NA_real_
    per_column[[variant]] <- data.frame(
      variant = variant,
      variable = colnames(balance_matrix),
      target_mean = target_mean,
      target_sd = target_sd,
      respondent_mean = respondent_mean,
      smd = smd,
      structurally_constant_excluded = invalid_sd,
      stringsAsFactors = FALSE
    )
    finite <- abs(smd[is.finite(smd)])
    summary[[variant]] <- data.frame(
      variant = variant,
      maximum_absolute_smd =
        if (length(finite)) max(finite) else NA_real_,
      structurally_constant_excluded_n = sum(invalid_sd),
      stringsAsFactors = FALSE
    )
  }
  list(
    summary = do.call(rbind, summary),
    per_column = do.call(rbind, per_column)
  )
}

v45_charls_outcome_metric_gate <- function(metric, value) {
  if (length(value) != 1L || !is.finite(value)) return("STOP")
  switch(
    metric,
    response_probability_p01 =
      if (value <= 0.01) "STOP" else if (value >= 0.05) "GO" else "CAUTION",
    availability_factor_p99 =
      if (value > 20) "STOP" else if (value <= 10) "GO" else "CAUTION",
    ESS_ratio =
      if (value < 0.30) "STOP" else if (value >= 0.50) "GO" else "CAUTION",
    maximum_absolute_SMD =
      if (value > 0.20) "STOP" else if (value <= 0.10) "GO" else "CAUTION",
    valid_replicate_fraction =
      if (value < 0.90) "STOP" else if (value >= 0.95) "GO" else "CAUTION",
    stop("Unknown frozen diagnostic metric: ", metric, call. = FALSE)
  )
}

v45_charls_outcome_ipw_diagnostics <- function(
    factor_contract, balance_matrix,
    structurally_constant_columns = character(),
    unit = c("point", "replicate")) {
  unit <- match.arg(unit)
  payload <- v45_charls_outcome_restricted_payload(
    factor_contract, "individual_ipw_factors"
  )
  ess <- v45_charls_outcome_ipw_ess_aggregates(factor_contract)
  smd <- v45_charls_outcome_ipw_smd_aggregates(
    factor_contract, balance_matrix, structurally_constant_columns
  )
  uncapped_ess <- ess$ess_ratio[ess$variant == "uncapped"]
  uncapped_smd <- smd$summary$maximum_absolute_smd[
    smd$summary$variant == "uncapped"
  ]
  metrics <- c(
    response_probability_p01 =
      v45_charls_outcome_quantile_type7(payload$probability, 0.01),
    availability_factor_p99 =
      v45_charls_outcome_quantile_type7(payload$availability, 0.99),
    ESS_ratio = uncapped_ess,
    maximum_absolute_SMD = uncapped_smd
  )
  status <- vapply(
    names(metrics),
    function(metric) v45_charls_outcome_metric_gate(
      metric, metrics[[metric]]
    ),
    character(1)
  )
  overall <- if (any(status == "STOP")) {
    "STOP"
  } else if (any(status == "CAUTION")) {
    "CAUTION"
  } else {
    "GO"
  }
  action <- if (unit == "point" && overall == "STOP") {
    "STOP_ENTIRE_W2_STAGE"
  } else if (unit == "replicate" && overall == "STOP") {
    "INVALIDATE_CANDIDATE_COLUMN"
  } else {
    "RETAIN"
  }
  list(
    gate = data.frame(
      unit = unit, metric = names(metrics), value = as.numeric(metrics),
      status = unname(status), stringsAsFactors = FALSE
    ),
    overall_status = overall,
    action = action,
    ess = ess,
    smd = smd
  )
}

v45_charls_outcome_expect_error <- function(expression) {
  inherits(try(force(expression), silent = TRUE), "try-error")
}

v45_charls_outcome_synthetic_self_test <- function() {
  checks <- c()
  record <- function(name, value) {
    checks[[name]] <<- isTRUE(value)
  }

  record(
    "passive_bmi",
    identical(
      v45_charls_outcome_passive_bmi(c(1.5, 2), c(45, 100)),
      c(20, 25)
    )
  )
  rebuilt <- v45_charls_outcome_rebuild_fixed_fields(data.frame(
    height_m_w1 = c(1.5, 2), weight_kg_w1 = c(45, 100),
    sex_code = c(1, 2), raeducl = c(1, 3), h1rural = c(0, 1),
    smoke_ever_w1 = c(0, 1), smoke_now_w1 = c(0, 1),
    r1hibpe = 0:1, r1diabe = c(0, 0), r1cancre = c(0, 0),
    r1hearte = c(0, 0), r1stroke = c(0, 0), r1kidneye = c(0, 0),
    age_w1 = c(50, 60), cesd10_w1 = c(9, 20)
  ))
  record(
    "fixed_factor_reconstruction",
    identical(levels(rebuilt$sex_code), c("1", "2")) &&
      identical(as.character(rebuilt$smoking_status_3),
                c("never", "current")) &&
      identical(rebuilt$nonpulmonary_comorbidity_count, c(0, 1)) &&
      identical(rebuilt$age_w2_model, c(52, 62))
  )
  record(
    "cesd_closed_interval_boundaries",
    identical(
      as.character(v45_charls_outcome_cesd_category(
        c(0, 9, 10, 19, 20, 30)
      )),
      c("0-9", "0-9", "10-19", "10-19", "20-30", "20-30")
    )
  )
  record(
    "weighted_math",
    abs(v45_charls_outcome_weighted_mean(c(1, 3), c(1, 3)) - 2.5) <
      1e-15 &&
      abs(v45_charls_outcome_weighted_variance(
        c(1, 3), c(1, 3)
      ) - 0.75) < 1e-15 &&
      v45_charls_outcome_kish_ess(c(1, 1, 1, 1)) == 4 &&
      v45_charls_outcome_quantile_type7(1:5, 0.5) == 3
  )
  trial <- v45_charls_outcome_trial_summaries(rbind(
    c(300, 280, 290), c(30, 30, 890)
  ))
  record(
    "trial_summaries",
    identical(trial$PEF_max, c(300, 890)) &&
      max(abs(trial$PEF_mean - c(290, 950 / 3))) < 1e-12 &&
      identical(trial$PEF_median, c(290, 30)) &&
      abs(trial$I_raw[[1L]] - log1p(10)) < 1e-15
  )
  anchors <- v45_charls_outcome_frozen_inconsistency_anchors()
  record(
    "six_frozen_Iz_anchors",
    length(anchors) == 6L &&
      identical(
        names(anchors),
        c(
          "I_raw_weighted_mean", "I_raw_weighted_population_SD",
          "I_z_weighted_q05", "I_z_weighted_q35",
          "I_z_weighted_q65", "I_z_weighted_q95"
        )
      ) &&
      all(is.finite(anchors)) &&
      anchors[["I_raw_weighted_population_SD"]] > 0 &&
      all(diff(anchors[3:6]) > 0)
  )
  basis <- v45_charls_outcome_restricted_cubic_basis(
    c(-2, 0, 2), anchors[3:6], "I_z"
  )
  record(
    "v43_exact_RCS_shape",
    identical(
      names(basis),
      c("I_z_linear", "I_z_nonlinear1", "I_z_nonlinear2")
    ) && identical(basis$I_z_linear, c(-2, 0, 2))
  )
  e0 <- v45_charls_outcome_e0(c(352.0554437442698, 250.41587378062366),
                              c(1, 2))
  longitudinal <- v45_charls_outcome_longitudinal_identities(
    c(0, 1), c(2, 3)
  )
  record(
    "E0_M12_D12_identities",
    max(abs(e0)) < 1e-15 &&
      identical(longitudinal$M12, c(1, 2)) &&
      identical(longitudinal$D12, c(2, 2))
  )
  left <- data.frame(participant_id = c("p2", "p1"), x = 1:2)
  right <- data.frame(participant_id = c("p1", "p2"), y = c(10, 20))
  joined <- v45_charls_outcome_exact_match_join(left, right)
  record(
    "exact_character_join",
    identical(joined$participant_id, left$participant_id) &&
      identical(joined$y, c(20, 10))
  )
  key_map <- data.frame(
    community_id = c("c1", "c2"), psu_ordinal = 1:2
  )
  multipliers <- matrix(
    c(0, 2, 2, 0), nrow = 2,
    dimnames = list(c("c1", "c2"), c("R001", "R002"))
  )
  binding <- v45_charls_outcome_bind_actual_keys(
    c("c2", "c1", "c2"), key_map, multipliers
  )
  record(
    "actual_key_explicit_match",
    inherits(binding, "v45_charls_outcome_restricted") &&
      identical(
        v45_charls_outcome_restricted_payload(binding)$key_index,
        c(2L, 1L, 2L)
      ) &&
      v45_charls_outcome_expect_error(
        v45_charls_outcome_assert_persistable(binding)
      )
  )
  replicate <- rbind(
    R001 = c(a = 1.1, b = 2.2),
    R002 = c(a = 0.9, b = 1.8),
    R003 = c(a = NA, b = 2.0),
    R004 = c(a = 1.2, b = 2.4)
  )
  mask <- v45_charls_outcome_common_valid_mask(
    cbind(
      fit_a = is.finite(replicate[, "a"]),
      fit_b = is.finite(replicate[, "b"])
    ),
    rownames(replicate)
  )
  covariance <- v45_charls_outcome_replicate_covariance(
    replicate, c(a = 1, b = 2), mask
  )
  paired <- v45_charls_outcome_direct_paired_contrast(
    replicate, c(a = 1, b = 2), c(a = -1, b = 1), mask,
    "b_minus_a"
  )
  record(
    "common_mask_Bvalid_minus_1",
    covariance$valid_n == 3L && covariance$denominator == 2L &&
      max(abs(covariance$covariance -
                matrix(c(.03, .06, .06, .12), 2L,
                       dimnames = list(c("a", "b"), c("a", "b"))))) <
        1e-14 &&
      abs(paired$within_variance - 0.03) < 1e-14
  )
  formula <- v45_charls_outcome_registered_formula(
    paste(
      "period_event ~ x + factor(end_wave) +",
      "offset(log(nominal_years))"
    ),
    "SYNTHETIC_OUTCOME"
  )
  synthetic <- data.frame(
    period_event = rep(c(0, 1, 0, 0, 1), 8),
    x = rep(c(-2, -1, 0, 1, 2), 8) + rep(0:7, each = 5) / 20,
    end_wave = factor(rep(c(2, 3, 4, 5), each = 10),
                      levels = c(2, 3, 4, 5)),
    nominal_years = rep(c(2, 2, 3, 2), each = 10)
  )
  compiled <- v45_charls_outcome_compile_glm_frame(
    formula, synthetic, "SYNTHETIC_OUTCOME"
  )
  compact <- v45_charls_outcome_glm_fit_compact(
    compiled, rep(1, nrow(synthetic)), "cloglog",
    focal_terms = "x", model_id = "SYNTHETIC_OUTCOME"
  )
  response_compiled <- v45_charls_outcome_compile_glm_frame(
    R_W2 ~ x, transform(synthetic, R_W2 = period_event),
    "SYNTHETIC_RESPONSE"
  )
  response_fit <- v45_charls_outcome_glm_fit_compact(
    response_compiled, rep(1, nrow(synthetic)), "logit",
    focal_terms = "x", model_id = "SYNTHETIC_RESPONSE",
    return_probability = TRUE
  )
  record(
    "cached_compact_glm_fit",
    all(is.finite(compact$coefficients)) &&
      inherits(
        response_fit$probability, "v45_charls_outcome_restricted"
      )
  )
  Q <- rbind(
    c(a = 0.1, b = 0.2),
    c(a = 0.2, b = 0.1),
    c(a = 0.15, b = 0.25),
    c(a = 0.05, b = 0.15)
  )
  U <- replicate(
    nrow(Q),
    matrix(
      c(0.04, 0.005, 0.005, 0.03), 2,
      dimnames = list(c("a", "b"), c("a", "b"))
    ),
    simplify = FALSE
  )
  scalar <- v45_charls_outcome_pool_scalar(
    Q[, "a"], rep(0.04, nrow(Q)), 432, "a"
  )
  linear <- v45_charls_outcome_pool_linear_combination(
    Q, U, c(a = 1, b = 1), 432, "a_plus_b"
  )
  joint <- v45_charls_outcome_pool_multivariate_wald(Q, U, "a_b")
  record(
    "Rubin_scalar_linear_joint",
    all(is.finite(scalar$estimate)) &&
      all(is.finite(linear$estimate)) &&
      all(is.finite(joint$test$statistic)) &&
      joint$test$df == 2L
  )
  probability <- v45_charls_outcome_restricted_payload(
    response_fit$probability
  )
  respondent <- transform(synthetic, R_W2 = period_event)$R_W2 == 1
  factor_contract <- v45_charls_outcome_ipw_factor_contract(
    probability, respondent, rep(1, length(probability)), "SYNTHETIC"
  )
  balance <- cbind(
    x = synthetic$x,
    wave3 = as.numeric(synthetic$end_wave == 3),
    wave4 = as.numeric(synthetic$end_wave == 4),
    wave5 = as.numeric(synthetic$end_wave == 5)
  )
  diagnostics <- v45_charls_outcome_ipw_diagnostics(
    factor_contract, balance, unit = "replicate"
  )
  record(
    "W2_factor_ESS_SMD_gate",
    identical(
      factor_contract$aggregate$variant,
      c("original", "uncapped", "p99", "p97_5")
    ) &&
      nrow(diagnostics$ess) == 4L &&
      nrow(diagnostics$gate) == 4L &&
      diagnostics$action %in%
        c("RETAIN", "INVALIDATE_CANDIDATE_COLUMN")
  )

  data.frame(
    check = names(checks),
    status = ifelse(unlist(checks), "PASS", "FAIL"),
    stringsAsFactors = FALSE
  )
}
