#!/usr/bin/env Rscript

options(stringsAsFactors = FALSE, warn = 1)

script_path <- sub(
  "^--file=", "",
  grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)[[1]]
)
root <- normalizePath(
  file.path(dirname(script_path), "..", "..", ".."),
  mustWork = TRUE
)
source(file.path(
  root,
  "R/v45/charls_addendum_v45_1/charls_structural_utilities_v45_1.R"
))
v45_charls_activate_project_library(root)
required_packages <- c("yaml", "digest", "mice", "survey", "dplyr")
if (!all(vapply(
  required_packages, requireNamespace, quietly = TRUE, FUN.VALUE = logical(1)
))) {
  stop("Required CHARLS actual-key/MI freeze packages are unavailable.", call. = FALSE)
}
source(file.path(root, "R/v45/production_mi_hashes_v45.R"))
source(file.path(
  root,
  "R/v45/charls_addendum_v45_1/03_charls_actual_keys_mi_utilities_v45_1.R"
))

work_dir <- file.path(root, "work_v45/charls_addendum_v45_1")
result_dir <- file.path(root, "results/v45/charls_addendum_v45_1")
spec_path <- file.path(work_dir, "charls_actual_keys_mi_spec_v45_1.yml")
code_manifest_path <- file.path(
  work_dir, "charls_actual_keys_mi_code_manifest_v45_1.tsv"
)
function_manifest_path <- file.path(
  work_dir, "charls_actual_keys_mi_function_manifest_v45_1.tsv"
)
roots_path <- file.path(
  work_dir, "charls_actual_keys_mi_freeze_roots_v45_1.tsv"
)
freeze_validation_path <- file.path(
  result_dir, "charls_actual_keys_mi_freeze_validation_v45_1.tsv"
)
gate_path <- file.path(
  work_dir, "charls_actual_keys_mi_gate_state_v45_1.yml"
)

sha256 <- function(path) v45_charls_sha256_file(path)
is_no <- function(value) {
  identical(value, FALSE) ||
    identical(tolower(as.character(value)), "no") ||
    identical(tolower(as.character(value)), "false")
}

validate_parent <- function() {
  gate <- yaml::read_yaml(file.path(
    work_dir, "charls_addendum_gate_state_v45_1.yml"
  ))
  required <- list(
    pure_function_freeze = "PASS",
    structural_preflight = "PASS",
    independent_validation = "PASS"
  )
  gate_ok <- all(vapply(names(required), function(name) {
    identical(as.character(gate[[name]]$status), required[[name]])
  }, logical(1))) &&
    identical(as.character(gate$actual_design_key_binding$status), "NOT_RUN") &&
    is_no(gate$outcome_execution_allowed) &&
    is_no(gate$new_coefficient_inspection_allowed)
  roots <- utils::read.delim(
    file.path(work_dir, "charls_pure_preflight_freeze_roots_v45_1.tsv"),
    stringsAsFactors = FALSE, check.names = FALSE
  )
  expected <- c(
    charls_v45_1_code_root =
      "e18b0a82e835272e74b1b63a9ee3024c49062a85ac5e0e7cdd03f64ab9f79f29",
    charls_v45_1_function_root =
      "466530949e8f3c7f2caf152133cef51ea5108e76b6a96a63f9cd66b23882c687"
  )
  root_ok <- all(vapply(names(expected), function(name) {
    row <- roots[roots$root_id == name, , drop = FALSE]
    nrow(row) == 1L && identical(as.character(row$sha256), expected[[name]])
  }, logical(1)))
  manifest_path <- file.path(
    result_dir, "charls_structural_output_manifest_v45_1.tsv"
  )
  manifest <- utils::read.delim(
    manifest_path, stringsAsFactors = FALSE, check.names = FALSE
  )
  manifest_ok <- identical(
    names(manifest),
    c("asset_id", "path_alias", "bytes", "sha256", "validation_status")
  ) && nrow(manifest) == 12L &&
    all(manifest$validation_status == "PASS") &&
    all(vapply(seq_len(nrow(manifest)), function(index) {
      path <- file.path(root, manifest$path_alias[[index]])
      file.exists(path) && !dir.exists(path) && !nzchar(Sys.readlink(path)) &&
        isTRUE(as.numeric(file.info(path)$size) ==
                 as.numeric(manifest$bytes[[index]])) &&
        identical(sha256(path), as.character(manifest$sha256[[index]]))
    }, logical(1)))
  list(
    pass = gate_ok && root_ok && manifest_ok,
    gate_ok = gate_ok,
    root_ok = root_ok,
    manifest_ok = manifest_ok
  )
}

code_paths <- c(
  "work_v45/charls_addendum_v45_1/charls_actual_keys_mi_spec_v45_1.yml",
  "work_v45/charls_addendum_v45_1/charls_actual_keys_mi_decision_log_v45_1.md",
  "R/v45/charls_addendum_v45_1/charls_pure_functions_v45_1.R",
  "R/v45/charls_addendum_v45_1/charls_structural_utilities_v45_1.R",
  "R/v45/charls_addendum_v45_1/03_charls_actual_keys_mi_utilities_v45_1.R",
  "R/v45/charls_addendum_v45_1/04_freeze_charls_actual_keys_mi_v45_1.R",
  "R/v45/charls_addendum_v45_1/05_run_charls_actual_keys_mi_preflight_v45_1.R",
  "R/v45/charls_addendum_v45_1/06_validate_charls_actual_keys_mi_preflight_v45_1.R",
  "R/v45/production_mi_hashes_v45.R",
  paste0(
    "output/code_archive/PEF_mortality_v44_2_code_candidate/",
    "R/v43/04_charls_stage3_primary_mortality.R"
  ),
  paste0(
    "output/code_archive/PEF_mortality_v44_2_code_candidate/",
    "R/v44/05_charls_anthropometric_qc_resolution_v44_1_1.R"
  ),
  paste0(
    "output/code_archive/PEF_mortality_v44_2_code_candidate/",
    "work_v44/charls_anthropometric_qc_resolution_spec_v44_1_1.yml"
  ),
  "work_v45/charls_addendum_v45_1/charls_pure_preflight_freeze_roots_v45_1.tsv",
  "results/v45/charls_addendum_v45_1/charls_structural_output_manifest_v45_1.tsv"
)

verify_manifest <- function() {
  if (!all(file.exists(c(
    code_manifest_path, function_manifest_path, roots_path,
    freeze_validation_path, gate_path
  )))) {
    stop("The CHARLS actual-key/MI freeze bundle is incomplete.", call. = FALSE)
  }
  code <- utils::read.delim(
    code_manifest_path, stringsAsFactors = FALSE, check.names = FALSE
  )
  if (!identical(
    names(code), c("asset_id", "path_alias", "bytes", "sha256", "status")
  ) || !identical(as.character(code$path_alias), code_paths) ||
      any(code$status != "PASS")) {
    stop("The CHARLS actual-key/MI code manifest schema drifted.", call. = FALSE)
  }
  current <- vapply(seq_len(nrow(code)), function(index) {
    path <- file.path(root, code$path_alias[[index]])
    file.exists(path) && !dir.exists(path) && !nzchar(Sys.readlink(path)) &&
      isTRUE(as.numeric(file.info(path)$size) ==
               as.numeric(code$bytes[[index]])) &&
      identical(sha256(path), as.character(code$sha256[[index]]))
  }, logical(1))
  if (!all(current)) {
    stop("A frozen CHARLS actual-key/MI code asset drifted.", call. = FALSE)
  }
  parent <- validate_parent()
  if (!isTRUE(parent$pass)) {
    stop("The parent CHARLS structural gate drifted.", call. = FALSE)
  }
  spec <- yaml::read_yaml(spec_path)
  source_validation <- v45_charls_actual_validate_source_files(root, spec)
  roots <- utils::read.delim(
    roots_path, stringsAsFactors = FALSE, check.names = FALSE
  )
  expected_code_root <- v45_charls_manifest_root(
    code, "asset_id", c("asset_id", "bytes", "sha256")
  )
  functions <- utils::read.delim(
    function_manifest_path, stringsAsFactors = FALSE, check.names = FALSE
  )
  expected_function_root <- v45_charls_manifest_root(
    functions, "function_name",
    c("function_name", "authority", "authority_file_sha256", "function_sha256")
  )
  source_root <- v45_charls_manifest_root(
    source_validation, "source_id",
    c("source_id", "bytes", "sha256", "expected_bytes", "expected_sha256")
  )
  expected <- c(
    actual_keys_mi_code_root = expected_code_root,
    actual_keys_mi_function_root = expected_function_root,
    restricted_source_root = source_root,
    parent_pure_code_root =
      "e18b0a82e835272e74b1b63a9ee3024c49062a85ac5e0e7cdd03f64ab9f79f29",
    parent_pure_function_root =
      "466530949e8f3c7f2caf152133cef51ea5108e76b6a96a63f9cd66b23882c687"
  )
  roots_ok <- all(vapply(names(expected), function(name) {
    row <- roots[roots$root_id == name, , drop = FALSE]
    nrow(row) == 1L && identical(as.character(row$sha256), expected[[name]])
  }, logical(1)))
  if (!roots_ok) {
    stop("The CHARLS actual-key/MI freeze roots drifted.", call. = FALSE)
  }
  gate <- yaml::read_yaml(gate_path)
  permitted_structural_status <- c("FROZEN_NOT_RUN", "PASS_PENDING_INDEPENDENT")
  gate_ok <- identical(as.character(gate$freeze$status), "PASS") &&
    as.character(gate$actual_design_key_binding$status) %in%
      permitted_structural_status &&
    as.character(gate$mi_c0_structural_preflight$status) %in%
      permitted_structural_status &&
    as.character(gate$mi_c2_structural_preflight$status) %in%
      permitted_structural_status &&
    identical(as.character(gate$independent_validation$status), "NOT_RUN") &&
    is_no(gate$charls_production_mi_allowed) &&
    is_no(gate$outcome_execution_allowed) &&
    is_no(gate$new_coefficient_inspection_allowed)
  if (!gate_ok) {
    stop("The frozen CHARLS actual-key/MI gate semantics drifted.", call. = FALSE)
  }
  cat("CHARLS ACTUAL-KEY/MI FREEZE VERIFY PASS\n")
  invisible(TRUE)
}

verify_mode <- "--verify" %in% commandArgs(trailingOnly = TRUE)
if (verify_mode) {
  verify_manifest()
  quit(save = "no", status = 0L, runLast = FALSE)
}

missing_code <- code_paths[!file.exists(file.path(root, code_paths))]
if (length(missing_code)) {
  stop(
    "Cannot freeze before all actual-key/MI scripts exist: ",
    paste(missing_code, collapse = ", "), call. = FALSE
  )
}
parent <- validate_parent()
if (!isTRUE(parent$pass)) {
  stop("The parent CHARLS structural gate is not current.", call. = FALSE)
}
spec <- yaml::read_yaml(spec_path)
source_validation <- v45_charls_actual_validate_source_files(root, spec)
authority <- v45_charls_actual_load_authority(root)

freeze_id <- paste0(
  "charls_v45_1_actual_keys_mi_",
  format(Sys.time(), "%Y%m%dT%H%M%S", tz = "UTC"),
  "_pid", Sys.getpid()
)
frozen_at <- format(Sys.time(), tz = "UTC", usetz = TRUE)
code <- data.frame(
  asset_id = paste0("CHARLS_ACTUAL_MI::", code_paths),
  path_alias = code_paths,
  bytes = vapply(
    file.path(root, code_paths),
    function(path) as.numeric(file.info(path)$size),
    numeric(1)
  ),
  sha256 = vapply(file.path(root, code_paths), sha256, character(1)),
  status = "PASS",
  stringsAsFactors = FALSE
)
functions <- v45_charls_actual_function_manifest(root, authority)
utility_names <- ls(
  envir = .GlobalEnv,
  pattern = "^v45_charls_actual_",
  all.names = TRUE
)
utility_rows <- data.frame(
  function_name = utility_names,
  authority = "v45_1_actual_keys_mi",
  authority_file_sha256 = sha256(file.path(
    root,
    "R/v45/charls_addendum_v45_1/03_charls_actual_keys_mi_utilities_v45_1.R"
  )),
  function_sha256 = vapply(
    utility_names,
    function(name) v45_charls_function_sha256(get(name, envir = .GlobalEnv)),
    character(1)
  ),
  status = "PASS",
  stringsAsFactors = FALSE
)
functions <- rbind(functions, utility_rows)
if (anyDuplicated(functions$function_name) || any(functions$status != "PASS")) {
  stop("The actual-key/MI function manifest is invalid.", call. = FALSE)
}
code_root <- v45_charls_manifest_root(
  code, "asset_id", c("asset_id", "bytes", "sha256")
)
function_root <- v45_charls_manifest_root(
  functions, "function_name",
  c("function_name", "authority", "authority_file_sha256", "function_sha256")
)
source_root <- v45_charls_manifest_root(
  source_validation, "source_id",
  c("source_id", "bytes", "sha256", "expected_bytes", "expected_sha256")
)
roots <- data.frame(
  root_id = c(
    "actual_keys_mi_code_root", "actual_keys_mi_function_root",
    "restricted_source_root", "parent_pure_code_root",
    "parent_pure_function_root"
  ),
  sha256 = c(
    code_root, function_root, source_root,
    "e18b0a82e835272e74b1b63a9ee3024c49062a85ac5e0e7cdd03f64ab9f79f29",
    "466530949e8f3c7f2caf152133cef51ea5108e76b6a96a63f9cd66b23882c687"
  ),
  freeze_id = freeze_id,
  frozen_at_utc = frozen_at,
  stringsAsFactors = FALSE
)
freeze_validation <- data.frame(
  check_id = c(
    "parent_gate_current",
    "parent_pure_roots_exact",
    "parent_output_manifest_current",
    "restricted_source_files_exact",
    "code_assets_exist_and_hashable",
    "authority_functions_parsed_without_sourcing",
    "main_stage3_gate_not_bound"
  ),
  status = c(
    if (parent$gate_ok) "PASS" else "FAIL",
    if (parent$root_ok) "PASS" else "FAIL",
    if (parent$manifest_ok) "PASS" else "FAIL",
    if (all(source_validation$status == "PASS")) "PASS" else "FAIL",
    if (all(code$status == "PASS")) "PASS" else "FAIL",
    if (all(functions$status == "PASS")) "PASS" else "FAIL",
    "PASS"
  ),
  observed = c(
    "pure/structural/independent PASS; actual keys NOT_RUN; outcomes no",
    "two exact parent roots",
    "12/12 immutable parent outputs current",
    paste(source_validation$source_id, collapse = "|"),
    paste0(nrow(code), "/", nrow(code)),
    paste0(nrow(functions), " function definitions"),
    "mutable work_v45/gate_state_v45.yml excluded"
  ),
  expected = c(
    "parent no-outcome gate current",
    "exact frozen roots",
    "all parent outputs current",
    "two Stage0-authorized sources exact",
    "all code assets current",
    "parse definitions only; no authority top-level execution",
    "no concurrent NHANES gate hash dependency"
  ),
  freeze_id = freeze_id,
  stringsAsFactors = FALSE
)
if (any(freeze_validation$status != "PASS")) {
  stop("CHARLS actual-key/MI freeze validation failed.", call. = FALSE)
}
prior_stage_gate <- if (file.exists(gate_path)) {
  yaml::read_yaml(gate_path)
} else {
  NULL
}
preserve_runner_pending <- !is.null(prior_stage_gate) &&
  identical(
    as.character(prior_stage_gate$actual_design_key_binding$status),
    "PASS_PENDING_INDEPENDENT"
  ) &&
  identical(
    as.character(prior_stage_gate$mi_c0_structural_preflight$status),
    "PASS_PENDING_INDEPENDENT"
  ) &&
  identical(
    as.character(prior_stage_gate$mi_c2_structural_preflight$status),
    "PASS_PENDING_INDEPENDENT"
  ) &&
  identical(
    as.character(prior_stage_gate$independent_validation$status),
    "NOT_RUN"
  ) &&
  file.exists(file.path(
    result_dir, "charls_actual_keys_mi_output_manifest_v45_1.tsv"
  ))
gate <- list(
  gate_id = "charls_actual_keys_mi_v45_1",
  freeze_id = freeze_id,
  runner_freeze_id = if (preserve_runner_pending) {
    as.character(prior_stage_gate$freeze_id)
  } else {
    NULL
  },
  updated_at_utc = frozen_at,
  freeze = list(status = "PASS"),
  actual_design_key_binding = list(
    status = if (preserve_runner_pending) {
      "PASS_PENDING_INDEPENDENT"
    } else {
      "FROZEN_NOT_RUN"
    }
  ),
  mi_c0_structural_preflight = list(
    status = if (preserve_runner_pending) {
      "PASS_PENDING_INDEPENDENT"
    } else {
      "FROZEN_NOT_RUN"
    }
  ),
  mi_c2_structural_preflight = list(
    status = if (preserve_runner_pending) {
      "PASS_PENDING_INDEPENDENT"
    } else {
      "FROZEN_NOT_RUN"
    }
  ),
  independent_validation = list(status = "NOT_RUN"),
  charls_production_mi_allowed = "no",
  outcome_execution_allowed = "no",
  new_coefficient_inspection_allowed = "no",
  next_authorized_step = "run_actual_design_key_and_MI_C0_MI_C2_structural_preflight"
)
v45_charls_atomic_write_tsv(code, code_manifest_path)
v45_charls_atomic_write_tsv(functions, function_manifest_path)
v45_charls_atomic_write_tsv(roots, roots_path)
v45_charls_atomic_write_tsv(freeze_validation, freeze_validation_path)
v45_charls_atomic_write_yaml(gate, gate_path)
verify_manifest()
