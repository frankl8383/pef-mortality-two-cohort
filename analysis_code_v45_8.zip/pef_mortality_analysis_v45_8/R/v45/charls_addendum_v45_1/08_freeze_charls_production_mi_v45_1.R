#!/usr/bin/env Rscript

# Freeze the isolated CHARLS v45.1 production MI-C0/MI-C2 stage.
# This script reconstructs and hashes inputs but never runs MICE.

options(stringsAsFactors = FALSE, warn = 2)

script_path <- sub(
  "^--file=", "",
  grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)[[1L]]
)
root <- normalizePath(
  file.path(dirname(script_path), "..", "..", ".."),
  mustWork = TRUE
)
source(file.path(
  root,
  "R/v45/charls_addendum_v45_1/charls_structural_utilities_v45_1.R"
))
v45_charls_activate_project_library(root)
required_packages <- c("digest", "dplyr", "mice", "yaml")
missing_packages <- required_packages[!vapply(
  required_packages, requireNamespace, logical(1), quietly = TRUE
)]
if (length(missing_packages)) {
  stop(
    "CHARLS production-MI freeze packages are unavailable: ",
    paste(missing_packages, collapse = ", "), call. = FALSE
  )
}
source(file.path(root, "R/v45/production_mi_hashes_v45.R"))
source(file.path(
  root,
  "R/v45/charls_addendum_v45_1/03_charls_actual_keys_mi_utilities_v45_1.R"
))
source(file.path(
  root,
  "R/v45/charls_addendum_v45_1/07_charls_production_mi_utilities_v45_1.R"
))

paths <- v45_charls_prod_paths(root)
output <- c(
  code = file.path(
    paths$work, "charls_production_mi_code_manifest_v45_1.tsv"
  ),
  functions = file.path(
    paths$work, "charls_production_mi_function_manifest_v45_1.tsv"
  ),
  roots = file.path(
    paths$work, "charls_production_mi_freeze_roots_v45_1.tsv"
  ),
  input_contract = file.path(
    paths$restricted, "charls_production_mi_input_contract_v45_1.rds"
  ),
  input_summary = file.path(
    paths$result, "charls_production_mi_input_contracts_v45_1.tsv"
  ),
  validation = file.path(
    paths$result, "charls_production_mi_freeze_validation_v45_1.tsv"
  ),
  output_manifest = file.path(
    paths$result, "charls_production_mi_freeze_output_manifest_v45_1.tsv"
  )
)

function_sha <- function(fun) {
  v45_charls_text_sha256(c(
    deparse(formals(fun), width.cutoff = 500L),
    deparse(body(fun), width.cutoff = 500L)
  ))
}

same_table <- function(left, right, key) {
  if (!is.data.frame(left) || !is.data.frame(right) ||
      !identical(names(left), names(right)) ||
      anyDuplicated(left[[key]]) || anyDuplicated(right[[key]]) ||
      !setequal(left[[key]], right[[key]])) {
    return(FALSE)
  }
  left <- left[order(left[[key]], method = "radix"), , drop = FALSE]
  right <- right[order(right[[key]], method = "radix"), , drop = FALSE]
  rownames(left) <- NULL
  rownames(right) <- NULL
  normalize <- function(data) {
    lapply(data, function(value) {
      value <- as.character(value)
      value[is.na(value) | !nzchar(value)] <- NA_character_
      value
    })
  }
  identical(normalize(left), normalize(right))
}

build_code_manifest <- function() {
  relative <- c(
    "work_v45/charls_addendum_v45_1/charls_production_mi_spec_v45_1.yml",
    paste0(
      "work_v45/charls_addendum_v45_1/",
      "charls_production_mi_decision_log_v45_1.md"
    ),
    paste0(
      "work_v45/charls_addendum_v45_1/",
      "charls_production_mi_amendment_log_v45_1.md"
    ),
    paste0(
      "output/qa/v45/charls_addendum_v45_1/freeze_history/",
      "production_mi_predecessor_verify_attempt1/failure.txt"
    ),
    paste0(
      "output/qa/v45/charls_addendum_v45_1/freeze_history/",
      "production_mi_c0_where_exact_failure_20260725T114536Z/",
      "RECOVERY_AUDIT.md"
    ),
    paste0(
      "output/qa/v45/charls_addendum_v45_1/freeze_history/",
      "production_mi_c0_where_exact_failure_20260725T114536Z/",
      "STRUCTURAL_DIAGNOSTIC.tsv"
    ),
    paste0(
      "output/qa/v45/charls_addendum_v45_1/freeze_history/",
      "production_mi_c0_where_exact_failure_20260725T114536Z/",
      "ARCHIVE_INVENTORY.tsv"
    ),
    paste0(
      "work_v45/charls_addendum_v45_1/",
      "charls_actual_keys_mi_spec_v45_1.yml"
    ),
    paste0(
      "work_v45/charls_addendum_v45_1/",
      "charls_addendum_gate_state_v45_1.yml"
    ),
    paste0(
      "work_v45/charls_addendum_v45_1/",
      "charls_actual_keys_mi_gate_state_v45_1.yml"
    ),
    paste0(
      "work_v45/charls_addendum_v45_1/",
      "charls_actual_keys_mi_code_manifest_v45_1.tsv"
    ),
    paste0(
      "work_v45/charls_addendum_v45_1/",
      "charls_actual_keys_mi_function_manifest_v45_1.tsv"
    ),
    paste0(
      "work_v45/charls_addendum_v45_1/",
      "charls_actual_keys_mi_freeze_roots_v45_1.tsv"
    ),
    paste0(
      "results/v45/charls_addendum_v45_1/",
      "charls_actual_keys_mi_output_manifest_v45_1.tsv"
    ),
    paste0(
      "results/v45/charls_addendum_v45_1/",
      "charls_actual_keys_mi_independent_output_manifest_v45_1.tsv"
    ),
    paste0(
      "results/v45/charls_addendum_v45_1/",
      "charls_actual_keys_mi_independent_validation_v45_1.tsv"
    ),
    paste0(
      "derived_sensitive/v45/charls_addendum_v45_1/",
      "charls_actual_keys_mi_contract_v45_1.rds"
    ),
    "R/v45/charls_addendum_v45_1/charls_structural_utilities_v45_1.R",
    "R/v45/charls_addendum_v45_1/03_charls_actual_keys_mi_utilities_v45_1.R",
    "R/v45/charls_addendum_v45_1/07_charls_production_mi_utilities_v45_1.R",
    "R/v45/charls_addendum_v45_1/08_freeze_charls_production_mi_v45_1.R",
    "R/v45/charls_addendum_v45_1/09_run_charls_production_mi_v45_1.R",
    "R/v45/charls_addendum_v45_1/10_validate_charls_production_mi_v45_1.R",
    "R/v45/production_mi_hashes_v45.R",
    "R/v45/independent_mi_validation_helpers_v45.R",
    paste0(
      "output/code_archive/PEF_mortality_v44_2_code_candidate/",
      "R/v43/04_charls_stage3_primary_mortality.R"
    ),
    paste0(
      "output/code_archive/PEF_mortality_v44_2_code_candidate/",
      "R/v44/05_charls_anthropometric_qc_resolution_v44_1_1.R"
    ),
    paste0(
      "output/code_archive/PEF_mortality_v44_2_code_candidate/",
      "work_v44/charls_anthropometric_qc_resolution_spec_v44_1_1.yml"
    )
  )
  do.call(rbind, lapply(seq_along(relative), function(index) {
    alias <- relative[[index]]
    path <- file.path(root, alias)
    data.frame(
      asset_id = paste0("CHARLS_PRODUCTION_MI::", alias),
      path_alias = alias,
      bytes = if (v45_charls_prod_regular_file(path)) {
        as.numeric(file.info(path)$size)
      } else {
        NA_real_
      },
      sha256 = v45_charls_sha256_file(path),
      immutable = TRUE,
      authorized_purpose =
        "restricted CHARLS m50 MICE creation without model fitting",
      status = if (v45_charls_prod_regular_file(path)) "PASS" else "FAIL",
      stringsAsFactors = FALSE
    )
  }))
}

global_function_closure <- function(roots) {
  v45_charls_prod_transitive_functions(globalenv(), roots)
}

build_function_manifest <- function(authority) {
  authority_names <- sort(unique(c(
    attr(authority, "function_names"),
    attr(authority, "production_v43_closure")
  )), method = "radix")
  v44_names <- c(
    "v44_constrained_weight_pmm_core",
    "v44_constrained_height_pmm_core",
    "mice.impute.v44_who_constrained_weight_pmm",
    "mice.impute.v44_who_constrained_height_pmm",
    "variant_catalog_v44", "clean_wave_v44",
    "make_mi_input_v44", "freeze_mi_spec_v44"
  )
  authority_rows <- do.call(rbind, lapply(authority_names, function(name) {
    source_id <- if (name %in% v44_names) "v44" else "v43"
    source_path <- paths[[source_id]]
    data.frame(
      asset_id = paste0(source_id, "::", name),
      function_name = name,
      source = sub(
        paste0("^", root, "/?"), "",
        normalizePath(source_path, mustWork = TRUE)
      ),
      source_sha256 = v45_charls_sha256_file(source_path),
      function_sha256 = function_sha(
        get(name, envir = authority, inherits = FALSE)
      ),
      status = "PASS",
      stringsAsFactors = FALSE
    )
  }))
  global_names <- global_function_closure(c(
    "v45_charls_prod_build_input_contract",
    "v45_charls_prod_component_table",
    "v45_charls_prod_verify_predecessor",
    "v45_charls_prod_object_contract",
    "v45_charls_actual_register_v44_imputers",
    "v45_charls_atomic_write_tsv",
    "v45_charls_atomic_write_yaml",
    "v45_charls_atomic_write_lines",
    "v45_charls_atomic_save_rds"
  ))
  source_for <- function(name) {
    if (grepl("^v45_canonical_", name)) {
      "R/v45/production_mi_hashes_v45.R"
    } else if (grepl("^v45_charls_actual_", name)) {
      "R/v45/charls_addendum_v45_1/03_charls_actual_keys_mi_utilities_v45_1.R"
    } else if (grepl("^v45_charls_prod_", name)) {
      "R/v45/charls_addendum_v45_1/07_charls_production_mi_utilities_v45_1.R"
    } else {
      "R/v45/charls_addendum_v45_1/charls_structural_utilities_v45_1.R"
    }
  }
  global_rows <- do.call(rbind, lapply(global_names, function(name) {
    source_alias <- source_for(name)
    data.frame(
      asset_id = paste0("v45_1::", name),
      function_name = name,
      source = source_alias,
      source_sha256 = v45_charls_sha256_file(file.path(root, source_alias)),
      function_sha256 = function_sha(
        get(name, envir = globalenv(), inherits = FALSE)
      ),
      status = "PASS",
      stringsAsFactors = FALSE
    )
  }))
  output <- rbind(authority_rows, global_rows)
  if (anyDuplicated(output$asset_id) ||
      any(!grepl("^[0-9a-f]{64}$", output$source_sha256)) ||
      any(!grepl("^[0-9a-f]{64}$", output$function_sha256))) {
    stop("CHARLS production function manifest is incomplete.", call. = FALSE)
  }
  output
}

build_objects <- function() {
  expected_versions <- c(
    digest = "0.6.37", dplyr = "1.1.4",
    mice = "3.19.0", yaml = "2.3.10"
  )
  version_ok <- identical(as.character(getRversion()), "4.5.1") &&
    all(vapply(names(expected_versions), function(package) {
      identical(
        as.character(utils::packageVersion(package)),
        expected_versions[[package]]
      )
    }, logical(1))) &&
    identical(
      unname(RNGkind()),
      c("Mersenne-Twister", "Inversion", "Rejection")
    )
  if (!version_ok) {
    stop("CHARLS production-MI runtime or RNGkind drifted.", call. = FALSE)
  }
  predecessor <- v45_charls_prod_verify_predecessor(root)
  input <- v45_charls_prod_build_input_contract(root)
  code <- build_code_manifest()
  if (any(code$status != "PASS") ||
      any(!grepl("^[0-9a-f]{64}$", code$sha256))) {
    stop("CHARLS production-MI code closure is incomplete.", call. = FALSE)
  }
  functions <- build_function_manifest(input$authority)
  prior_roots <- v45_charls_prod_read_tsv_stable(file.path(
    paths$work, "charls_actual_keys_mi_freeze_roots_v45_1.tsv"
  ))
  root_value <- function(id) {
    row <- prior_roots[prior_roots$root_id == id, , drop = FALSE]
    if (nrow(row) != 1L ||
        !grepl("^[0-9a-f]{64}$", as.character(row$sha256))) {
      stop("Required predecessor root is absent: ", id, call. = FALSE)
    }
    as.character(row$sha256)
  }
  roots <- data.frame(
    root_id = c(
      "charls_production_mi_code_root",
      "charls_production_mi_function_root",
      "charls_production_mi_input_root",
      "charls_predecessor_validated_output_root",
      "charls_actual_keys_mi_code_root",
      "charls_actual_keys_mi_function_root",
      "charls_restricted_source_root"
    ),
    sha256 = c(
      v45_charls_manifest_root(
        code, "asset_id",
        c(
          "asset_id", "path_alias", "bytes", "sha256",
          "immutable", "authorized_purpose", "status"
        )
      ),
      v45_charls_manifest_root(
        functions, "asset_id",
        c(
          "asset_id", "function_name", "source",
          "source_sha256", "function_sha256", "status"
        )
      ),
      v45_canonical_object_sha256(input$contract),
      predecessor$root,
      root_value("actual_keys_mi_code_root"),
      root_value("actual_keys_mi_function_root"),
      root_value("restricted_source_root")
    ),
    stringsAsFactors = FALSE
  )
  if (any(!grepl("^[0-9a-f]{64}$", roots$sha256))) {
    stop("CHARLS production-MI roots are incomplete.", call. = FALSE)
  }
  list(
    code = code,
    functions = functions,
    roots = roots,
    input_contract = input$contract,
    input_summary = input$summary
  )
}

expected_output_manifest <- function(source_paths = output) {
  required_sources <- c(
    "code", "functions", "roots", "input_contract",
    "input_summary", "validation"
  )
  if (!all(required_sources %in% names(source_paths))) {
    stop("Freeze output-manifest source mapping is incomplete.",
         call. = FALSE)
  }
  aliases <- c(
    code = sub(paste0("^", root, "/?"), "", output[["code"]]),
    functions = sub(paste0("^", root, "/?"), "", output[["functions"]]),
    roots = sub(paste0("^", root, "/?"), "", output[["roots"]]),
    input_contract =
      sub(paste0("^", root, "/?"), "", output[["input_contract"]]),
    input_summary =
      sub(paste0("^", root, "/?"), "", output[["input_summary"]]),
    validation =
      sub(paste0("^", root, "/?"), "", output[["validation"]])
  )
  data.frame(
    asset_id = names(aliases),
    path_alias = unname(aliases),
    bytes = vapply(required_sources, function(asset_id) {
      as.numeric(file.info(source_paths[[asset_id]])$size)
    }, numeric(1)),
    sha256 = vapply(required_sources, function(asset_id) {
      v45_charls_sha256_file(source_paths[[asset_id]])
    }, character(1)),
    access = c(
      "aggregate", "aggregate", "aggregate",
      "restricted_no_completed_data", "aggregate", "aggregate"
    ),
    validation_status = "PASS",
    stringsAsFactors = FALSE
  )
}

verify_freeze <- function(objects) {
  if (any(!vapply(output, v45_charls_prod_regular_file, logical(1)))) {
    stop("CHARLS production-MI freeze bundle is incomplete.",
         call. = FALSE)
  }
  recorded_code <- v45_charls_prod_read_tsv_stable(output[["code"]])
  recorded_functions <- v45_charls_prod_read_tsv_stable(
    output[["functions"]]
  )
  recorded_roots <- v45_charls_prod_read_tsv_stable(output[["roots"]])
  recorded_contract <- v45_charls_prod_read_rds_stable(
    output[["input_contract"]]
  )
  recorded_summary <- v45_charls_prod_read_tsv_stable(
    output[["input_summary"]]
  )
  validation <- v45_charls_prod_read_tsv_stable(output[["validation"]])
  if (nrow(validation) != 7L || anyDuplicated(validation$check_id) ||
      any(validation$status != "PASS") ||
      length(unique(validation$freeze_id)) != 1L) {
    stop("CHARLS production-MI freeze validation drifted.", call. = FALSE)
  }
  expected_roots <- rbind(
    objects$roots,
    data.frame(
      root_id = "charls_production_mi_freeze_validation_file",
      sha256 = v45_charls_sha256_file(output[["validation"]]),
      stringsAsFactors = FALSE
    )
  )
  expected_manifest <- expected_output_manifest()
  recorded_manifest <- v45_charls_prod_read_tsv_stable(
    output[["output_manifest"]]
  )
  checks <- c(
    code = same_table(recorded_code, objects$code, "asset_id"),
    functions = same_table(
      recorded_functions, objects$functions, "asset_id"
    ),
    roots = same_table(recorded_roots, expected_roots, "root_id"),
    input_contract = identical(recorded_contract, objects$input_contract),
    input_summary = same_table(
      recorded_summary, objects$input_summary, "object_id"
    ),
    output_manifest = same_table(
      recorded_manifest, expected_manifest, "asset_id"
    )
  )
  if (!all(checks)) {
    stop(
      "CHARLS production-MI freeze no longer verifies: ",
      paste(names(checks)[!checks], collapse = ", "), call. = FALSE
    )
  }
  gate <- yaml::read_yaml(paths$gate)
  recorded_freeze_id <- unique(as.character(validation$freeze_id))
  if (!identical(as.character(gate$freeze$status), "PASS") ||
      !identical(as.character(gate$freeze_id), recorded_freeze_id) ||
      !identical(
        as.character(gate$freeze$validation_sha256),
        v45_charls_sha256_file(output[["validation"]])
      ) ||
      !identical(
        as.character(gate$freeze$roots_sha256),
        v45_charls_sha256_file(output[["roots"]])
      ) ||
      !identical(
        as.character(gate$freeze$output_manifest_sha256),
        v45_charls_sha256_file(output[["output_manifest"]])
      ) ||
      !identical(
        as.character(gate$freeze$validation_path_alias),
        sub(paste0("^", root, "/?"), "", output[["validation"]])
      ) ||
      !identical(
        as.character(gate$freeze$roots_path_alias),
        sub(paste0("^", root, "/?"), "", output[["roots"]])
      ) ||
      !identical(
        as.character(gate$freeze$output_manifest_path_alias),
        sub(paste0("^", root, "/?"), "", output[["output_manifest"]])
      ) ||
      !v45_charls_prod_is_yes(gate$charls_production_mi_authorized) ||
      !v45_charls_prod_is_no(gate$outcome_execution_allowed) ||
      !v45_charls_prod_is_no(gate$new_coefficient_inspection_allowed)) {
    stop("The isolated CHARLS production-MI gate drifted.", call. = FALSE)
  }
  invisible(TRUE)
}

mode <- if ("--self-test" %in% commandArgs(trailingOnly = TRUE)) {
  "self_test"
} else if ("--verify" %in% commandArgs(trailingOnly = TRUE)) {
  "verify"
} else {
  "freeze"
}

if (identical(mode, "self_test")) {
  objects <- build_objects()
  message(
    "CHARLS PRODUCTION-MI READ-ONLY SELF-TEST PASS; code_assets=",
    nrow(objects$code), "; functions=", nrow(objects$functions),
    "; objects=", paste(objects$input_summary$object_id, collapse = "|"),
    "; no freeze output was written."
  )
} else if (identical(mode, "verify")) {
  objects <- build_objects()
  verify_freeze(objects)
  message("CHARLS PRODUCTION-MI FREEZE VERIFY PASS")
} else {
  freeze_execution <- function() {
  freeze_lock <- file.path(
    paths$work, ".charls_production_mi_freeze.lock"
  )
  if (!dir.create(freeze_lock, showWarnings = FALSE)) {
    stop("Another CHARLS production-MI freezer holds the lock.",
         call. = FALSE)
  }
  freeze_lock_owner <- file.path(freeze_lock, "owner.tsv")
  v45_charls_atomic_write_tsv(
    data.frame(
      pid = Sys.getpid(),
      acquired_at_utc =
        format(Sys.time(), "%Y-%m-%dT%H:%M:%SZ", tz = "UTC"),
      stringsAsFactors = FALSE
    ),
    freeze_lock_owner
  )
  freeze_lock_owner_sha <- v45_charls_sha256_file(freeze_lock_owner)
  freeze_id <- paste0(
    "charls_v45_1_production_mi_freeze_",
    format(Sys.time(), "%Y%m%dT%H%M%S"), "_pid", Sys.getpid()
  )
  freeze_committed <- FALSE
  freeze_verified <- FALSE
  freeze_final_paths <- c(unname(output), paths$gate)
  freeze_staging_paths <- setNames(
    file.path(
      dirname(freeze_final_paths),
      paste0(
        ".", basename(freeze_final_paths), ".", freeze_id, ".staging"
      )
    ),
    freeze_final_paths
  )
  freeze_expected_hashes <- setNames(
    rep(NA_character_, length(freeze_final_paths)),
    freeze_final_paths
  )
  freeze_transaction_record <- file.path(
    paths$work,
    paste0(".charls_production_mi_freeze_transaction_", freeze_id, ".yml")
  )
  on.exit({
    commit_complete <- freeze_verified &&
      all(vapply(freeze_final_paths, function(path) {
        file.exists(path) &&
          grepl("^[0-9a-f]{64}$", freeze_expected_hashes[[path]]) &&
          identical(
            v45_charls_sha256_file(path),
            freeze_expected_hashes[[path]]
          )
      }, logical(1)))
    if (commit_complete) freeze_committed <- TRUE
    if (!freeze_committed) {
      for (path in freeze_final_paths) {
        if (file.exists(path) &&
            grepl("^[0-9a-f]{64}$", freeze_expected_hashes[[path]]) &&
            identical(
              v45_charls_sha256_file(path),
              freeze_expected_hashes[[path]]
            )) {
          unlink(path, force = TRUE)
        }
      }
    }
    for (path in freeze_staging_paths) {
      if (file.exists(path)) unlink(path, force = TRUE)
    }
    rollback_complete <- all(!file.exists(freeze_final_paths))
    if (file.exists(freeze_transaction_record) &&
        (freeze_committed || rollback_complete)) {
      unlink(freeze_transaction_record, force = TRUE)
    }
    if (dir.exists(freeze_lock) &&
        identical(
          v45_charls_sha256_file(freeze_lock_owner),
          freeze_lock_owner_sha
        )) {
      unlink(freeze_lock, recursive = TRUE, force = TRUE)
    }
  }, add = TRUE)
  if (any(file.exists(output)) || file.exists(paths$gate)) {
    stop(
      "CHARLS production-MI freeze outputs already exist; use --verify.",
      call. = FALSE
    )
  }
  stale_freeze_transactions <- list.files(
    paths$work,
    pattern = "^\\.charls_production_mi_freeze_transaction_.*\\.yml$",
    all.files = TRUE, full.names = TRUE
  )
  if (length(stale_freeze_transactions)) {
    stop(
      "An interrupted production-MI freeze requires audit: ",
      paste(basename(stale_freeze_transactions), collapse = ", "),
      call. = FALSE
    )
  }
  objects <- build_objects()
  production_parent <- file.path(
    paths$restricted, "production_mi"
  )
  aggregate_parent <- file.path(
    paths$result, "production_mi"
  )
  existing_runs <- c(
    if (dir.exists(production_parent)) list.files(
      production_parent, recursive = TRUE, all.files = TRUE,
      no.. = TRUE
    ) else character(),
    if (dir.exists(aggregate_parent)) list.files(
      aggregate_parent, recursive = TRUE, all.files = TRUE,
      no.. = TRUE
    ) else character()
  )
  if (length(existing_runs)) {
    stop("Production run artifacts predate the formal freeze.", call. = FALSE)
  }
  frozen_at <- format(Sys.time(), "%Y-%m-%dT%H:%M:%SZ", tz = "UTC")
  validation <- data.frame(
    check_id = c(
      "actual_keys_MI_predecessor_current",
      "complete_code_and_function_closure",
      "canonical_MI_C0_MI_C2_inputs",
      "m50_seeds_checkpoints_and_Rhat_exact",
      "passive_BMI_C2_age_and_zero_PEF_contract",
      "restricted_storage_and_transaction_contract",
      "no_MICE_or_model_execution_during_freeze"
    ),
    status = "PASS",
    observed = c(
      "actual key, MI dry-pair, and independent gates rehashed",
      paste0(
        "code_assets=", nrow(objects$code),
        "; functions=", nrow(objects$functions)
      ),
      paste0(
        objects$input_summary$object_id, ":",
        objects$input_summary$denominator_n, collapse = "|"
      ),
      "MI-C0=440401; MI-C2=450503; m=50; checkpoints=20|40|80; Rhat<=1.05",
      "BMI passive; ageW2=ageW1+2; PEF targets=0",
      "restricted mids only; completed data/models/coefficients forbidden",
      "production MICE runs=0; model fits=0; coefficients=0"
    ),
    freeze_id = freeze_id,
    frozen_at_utc = frozen_at,
    stringsAsFactors = FALSE
  )
  stage_output <- setNames(
    unname(freeze_staging_paths[unname(output)]),
    names(output)
  )
  gate_staging <- unname(freeze_staging_paths[[paths$gate]])
  v45_charls_atomic_write_tsv(objects$code, stage_output[["code"]])
  v45_charls_atomic_write_tsv(
    objects$functions, stage_output[["functions"]]
  )
  v45_charls_atomic_save_rds(
    objects$input_contract, stage_output[["input_contract"]]
  )
  v45_charls_atomic_write_tsv(
    objects$input_summary, stage_output[["input_summary"]]
  )
  v45_charls_atomic_write_tsv(
    validation, stage_output[["validation"]]
  )
  objects$roots <- rbind(
    objects$roots,
    data.frame(
      root_id = "charls_production_mi_freeze_validation_file",
      sha256 = v45_charls_sha256_file(stage_output[["validation"]]),
      stringsAsFactors = FALSE
    )
  )
  v45_charls_atomic_write_tsv(objects$roots, stage_output[["roots"]])
  v45_charls_atomic_write_tsv(
    expected_output_manifest(source_paths = stage_output),
    stage_output[["output_manifest"]]
  )
  gate <- list(
    gate_id = "charls_production_mi_v45_1",
    freeze_id = freeze_id,
    updated_at_utc = frozen_at,
    freeze = list(
      status = "PASS",
      validation_path_alias =
        sub(paste0("^", root, "/?"), "", output[["validation"]]),
      validation_sha256 =
        v45_charls_sha256_file(stage_output[["validation"]]),
      roots_path_alias =
        sub(paste0("^", root, "/?"), "", output[["roots"]]),
      roots_sha256 =
        v45_charls_sha256_file(stage_output[["roots"]]),
      output_manifest_path_alias =
        sub(paste0("^", root, "/?"), "", output[["output_manifest"]]),
      output_manifest_sha256 =
        v45_charls_sha256_file(stage_output[["output_manifest"]])
    ),
    charls_production_mi_authorized = "yes",
    charls_production_mi_execution = list(
      status = "NOT_RUN", objects = list()
    ),
    charls_production_mi_independent_validation =
      list(status = "NOT_RUN"),
    outcome_execution_allowed = "no",
    new_coefficient_inspection_allowed = "no",
    main_v45_gate_modified = "no",
    next_authorized_step =
      "run_CHARLS_MI_C0_m50_then_MI_C2_m50_serially"
  )
  v45_charls_atomic_write_yaml(gate, gate_staging)
  for (path in freeze_final_paths) {
    staged <- freeze_staging_paths[[path]]
    hash <- v45_charls_sha256_file(staged)
    if (!v45_charls_prod_regular_file(staged) ||
        !grepl("^[0-9a-f]{64}$", hash)) {
      stop("A staged CHARLS freeze asset is invalid.", call. = FALSE)
    }
    freeze_expected_hashes[[path]] <- hash
  }
  transaction <- list(
    transaction_id = freeze_id,
    phase = "READY_TO_PROMOTE",
    destination_paths =
      sub(paste0("^", root, "/?"), "", freeze_final_paths),
    expected_sha256 = unname(freeze_expected_hashes),
    gate_published_last = "yes",
    recovery_rule =
      "verify hashes; complete or roll back only this freeze transaction"
  )
  v45_charls_atomic_write_yaml(transaction, freeze_transaction_record)
  for (index in seq_along(freeze_final_paths)) {
    destination <- freeze_final_paths[[index]]
    staged <- freeze_staging_paths[[destination]]
    if (!file.rename(staged, destination) ||
        !identical(
          v45_charls_sha256_file(destination),
          freeze_expected_hashes[[destination]]
        )) {
      stop("CHARLS freeze asset promotion failed.", call. = FALSE)
    }
    transaction$phase <- paste0(
      "PROMOTED_", index, "_OF_", length(freeze_final_paths)
    )
    v45_charls_atomic_write_yaml(transaction, freeze_transaction_record)
  }
  verify_freeze(objects = build_objects())
  freeze_verified <- TRUE
  freeze_committed <- TRUE
  if (file.exists(freeze_transaction_record)) {
    unlink(freeze_transaction_record, force = TRUE)
  }
  message(
    "CHARLS production MI-C0/MI-C2 m=50 authorization frozen; ",
    "no production MICE was run."
  )
  }
  freeze_execution()
}
