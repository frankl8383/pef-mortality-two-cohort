# Utilities for the CHARLS v45.1 no-outcome structural preflight.
# Sourcing this file defines functions only.

v45_charls_project_root <- function() {
  args <- commandArgs(trailingOnly = FALSE)
  file_arg <- grep("^--file=", args, value = TRUE)
  if (!length(file_arg)) return(normalizePath(getwd(), mustWork = TRUE))
  script <- sub("^--file=", "", file_arg[[1]])
  normalizePath(file.path(dirname(script), "..", "..", ".."), mustWork = TRUE)
}

v45_charls_activate_project_library <- function(root) {
  path <- file.path(
    root, "work_v43", "renv", "library", "macos", "R-4.5",
    "aarch64-apple-darwin20"
  )
  if (!dir.exists(path)) {
    stop("The frozen project R library is absent.", call. = FALSE)
  }
  .libPaths(unique(c(normalizePath(path, mustWork = TRUE), .libPaths())))
  invisible(path)
}

v45_charls_sha256_file <- function(path) {
  if (!file.exists(path) || dir.exists(path)) return(NA_character_)
  digest::digest(path, algo = "sha256", file = TRUE)
}

v45_charls_text_sha256 <- function(lines) {
  digest::digest(
    enc2utf8(paste(lines, collapse = "\n")),
    algo = "sha256",
    serialize = FALSE
  )
}

v45_charls_object_sha256 <- function(object) {
  digest::digest(
    object, algo = "sha256", serialize = TRUE, serializeVersion = 3L
  )
}

v45_charls_numeric_sha256 <- function(x) {
  raw_value <- writeBin(
    as.double(x), con = raw(), size = 8L, endian = "little"
  )
  v45_charls_text_sha256(c(
    paste0("float64_length=", length(x)),
    digest::digest(raw_value, algo = "sha256", serialize = FALSE)
  ))
}

v45_charls_matrix_sha256 <- function(x) {
  x <- as.matrix(x)
  v45_charls_text_sha256(c(
    paste0("dimensions=", paste(dim(x), collapse = "x")),
    paste0("rownames=", paste(rownames(x), collapse = "\u241f")),
    paste0("colnames=", paste(colnames(x), collapse = "\u241f")),
    paste0(
      "float64_values=",
      v45_charls_numeric_sha256(as.vector(x))
    )
  ))
}

v45_charls_function_sha256 <- function(fun) {
  v45_charls_text_sha256(c(
    deparse(formals(fun), width.cutoff = 500L),
    deparse(body(fun), width.cutoff = 500L)
  ))
}

v45_charls_extract_top_function <- function(path, function_name) {
  expressions <- parse(path, keep.source = FALSE)
  matches <- list()
  for (expr in expressions) {
    if (!is.call(expr) || length(expr) != 3L ||
        !identical(as.character(expr[[1L]]), "<-") ||
        !is.symbol(expr[[2L]]) ||
        !identical(as.character(expr[[2L]]), function_name) ||
        !is.call(expr[[3L]]) ||
        !identical(as.character(expr[[3L]][[1L]]), "function")) {
      next
    }
    matches[[length(matches) + 1L]] <- expr[[3L]]
  }
  if (length(matches) != 1L) {
    stop(
      "Expected one top-level function assignment for ", function_name,
      "; found ", length(matches), ".", call. = FALSE
    )
  }
  eval(matches[[1L]], envir = new.env(parent = baseenv()))
}

v45_charls_atomic_write_tsv <- function(x, path) {
  dir.create(dirname(path), recursive = TRUE, showWarnings = FALSE)
  tmp <- tempfile(paste0(".", basename(path), "."), tmpdir = dirname(path))
  on.exit(if (file.exists(tmp)) unlink(tmp, force = TRUE), add = TRUE)
  utils::write.table(
    x, tmp, sep = "\t", row.names = FALSE, quote = FALSE, na = ""
  )
  if (!file.rename(tmp, path)) {
    stop("Atomic TSV promotion failed: ", path, call. = FALSE)
  }
  invisible(path)
}

v45_charls_atomic_write_yaml <- function(x, path) {
  dir.create(dirname(path), recursive = TRUE, showWarnings = FALSE)
  tmp <- tempfile(paste0(".", basename(path), "."), tmpdir = dirname(path))
  on.exit(if (file.exists(tmp)) unlink(tmp, force = TRUE), add = TRUE)
  yaml::write_yaml(x, tmp)
  if (!file.rename(tmp, path)) {
    stop("Atomic YAML promotion failed: ", path, call. = FALSE)
  }
  invisible(path)
}

v45_charls_atomic_write_lines <- function(x, path) {
  dir.create(dirname(path), recursive = TRUE, showWarnings = FALSE)
  tmp <- tempfile(paste0(".", basename(path), "."), tmpdir = dirname(path))
  on.exit(if (file.exists(tmp)) unlink(tmp, force = TRUE), add = TRUE)
  writeLines(x, tmp, useBytes = TRUE)
  if (!file.rename(tmp, path)) {
    stop("Atomic text promotion failed: ", path, call. = FALSE)
  }
  invisible(path)
}

v45_charls_atomic_save_rds <- function(x, path) {
  dir.create(dirname(path), recursive = TRUE, showWarnings = FALSE)
  tmp <- tempfile(paste0(".", basename(path), "."), tmpdir = dirname(path))
  on.exit(if (file.exists(tmp)) unlink(tmp, force = TRUE), add = TRUE)
  saveRDS(x, tmp, version = 3L, compress = "xz")
  if (!file.rename(tmp, path)) {
    stop("Atomic RDS promotion failed: ", path, call. = FALSE)
  }
  invisible(path)
}

v45_charls_manifest_root <- function(data, key, fields) {
  data <- data[order(data[[key]], method = "radix"), fields, drop = FALSE]
  rows <- apply(data, 1L, function(x) paste(x, collapse = "\u241f"))
  v45_charls_text_sha256(rows)
}

v45_charls_synthetic_psu_design <- function(psu_n) {
  if (length(psu_n) != 1L || !is.finite(psu_n) ||
      psu_n < 2L || psu_n != as.integer(psu_n)) {
    stop("Synthetic PSU count must be an integer of at least two.", call. = FALSE)
  }
  data.frame(
    psu_position = seq_len(as.integer(psu_n)),
    psu_key = factor(
      sprintf("SYNTHETIC_PSU_%04d", seq_len(as.integer(psu_n)))
    ),
    structural_weight = 1,
    stringsAsFactors = FALSE
  )
}

v45_charls_generate_subbootstrap <- function(psu_n, seed, matrix_id) {
  skeleton <- v45_charls_synthetic_psu_design(psu_n)
  design <- survey::svydesign(
    ids = ~psu_key,
    weights = ~structural_weight,
    data = skeleton,
    nest = TRUE
  )
  RNGkind(
    kind = "Mersenne-Twister",
    normal.kind = "Inversion",
    sample.kind = "Rejection"
  )
  set.seed(as.integer(seed))
  warnings <- character()
  replicate_design <- withCallingHandlers(
    survey::as.svrepdesign(
      design,
      type = "subbootstrap",
      replicates = 500L,
      mse = TRUE,
      compress = TRUE
    ),
    warning = function(w) {
      warnings <<- c(warnings, conditionMessage(w))
      invokeRestart("muffleWarning")
    }
  )
  if (length(warnings)) {
    stop(
      matrix_id, " generated warnings: ",
      paste(unique(warnings), collapse = " | "), call. = FALSE
    )
  }
  if (!inherits(replicate_design$repweights, "repweights_compressed")) {
    stop(matrix_id, " did not produce compressed weights.", call. = FALSE)
  }
  matrix <- unclass(replicate_design$repweights$weights)
  rownames(matrix) <- as.character(skeleton$psu_key)
  colnames(matrix) <- sprintf("R%03d", seq_len(ncol(matrix)))
  list(
    matrix_id = matrix_id,
    seed = as.integer(seed),
    psu_n = as.integer(psu_n),
    skeleton = skeleton,
    matrix = matrix,
    index = as.integer(replicate_design$repweights$index),
    pweights = as.numeric(replicate_design$pweights),
    scale = as.numeric(replicate_design$scale),
    rscales = as.numeric(replicate_design$rscales),
    mse = isTRUE(replicate_design$mse),
    combined_weights = isTRUE(replicate_design$combined.weights),
    degf = as.integer(replicate_design$degf),
    warnings = unique(warnings)
  )
}

v45_charls_prefix_module <- function(module) {
  out <- module
  out$matrix <- module$matrix[, seq_len(250L), drop = FALSE]
  out$scale <- 1 / 249
  out$rscales <- rep(1, 250L)
  out
}

v45_charls_make_repdesign <- function(data, psu_column, weight_column, module) {
  psu <- as.character(data[[psu_column]])
  index <- match(psu, as.character(module$skeleton$psu_key))
  if (anyNA(index)) {
    stop("Synthetic interface contains a PSU outside its module.", call. = FALSE)
  }
  repweights <- list(weights = module$matrix, index = index)
  class(repweights) <- "repweights_compressed"
  out <- list(
    repweights = repweights,
    pweights = as.numeric(data[[weight_column]]),
    type = "subbootstrap",
    rho = 0,
    scale = module$scale,
    rscales = module$rscales,
    call = match.call(),
    combined.weights = FALSE,
    selfrep = NULL,
    mse = TRUE,
    variables = data,
    degf = module$degf
  )
  class(out) <- "svyrep.design"
  out
}

v45_charls_capture_interface <- function(expr) {
  warnings <- character()
  value <- tryCatch(
    withCallingHandlers(
      expr,
      warning = function(w) {
        warnings <<- c(warnings, conditionMessage(w))
        invokeRestart("muffleWarning")
      }
    ),
    error = function(e) e
  )
  list(value = value, warnings = unique(warnings))
}

v45_charls_module_audit <- function(module) {
  matrix <- module$matrix
  balance_difference <- max(abs(colSums(matrix) - module$psu_n))
  list(
    dimensions_ok = identical(dim(matrix), c(module$psu_n, 500L)),
    finite_nonnegative = all(is.finite(matrix) & matrix >= 0),
    balance_difference = balance_difference,
    zero_each_replicate = all(apply(matrix, 2L, function(x) any(x == 0))),
    index_ok = identical(module$index, seq_len(module$psu_n)),
    pweights_ok = length(module$pweights) == module$psu_n &&
      all(module$pweights == 1),
    scale_ok = identical(module$scale, 1 / 499),
    rscales_ok = length(module$rscales) == 500L &&
      all(module$rscales == 1),
    mse_ok = module$mse,
    combined_weights_ok = !module$combined_weights,
    degf_ok = module$degf == module$psu_n - 1L,
    warning_ok = !length(module$warnings)
  )
}

v45_charls_module_audit_pass <- function(audit) {
  isTRUE(audit$dimensions_ok) &&
    isTRUE(audit$finite_nonnegative) &&
    is.finite(audit$balance_difference) &&
    audit$balance_difference <= 1e-10 &&
    isTRUE(audit$zero_each_replicate) &&
    isTRUE(audit$index_ok) &&
    isTRUE(audit$pweights_ok) &&
    isTRUE(audit$scale_ok) &&
    isTRUE(audit$rscales_ok) &&
    isTRUE(audit$mse_ok) &&
    isTRUE(audit$combined_weights_ok) &&
    isTRUE(audit$degf_ok) &&
    isTRUE(audit$warning_ok)
}
