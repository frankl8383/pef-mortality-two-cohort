#!/usr/bin/env Rscript

# Freeze the CHARLS v45.1 outcome-execution contract.
# This script never completes a mids object, reads a new coefficient, or fits
# a response/outcome model.  The only derived values are coefficient-blind
# measurement summaries and immutable structural hashes.

options(stringsAsFactors = FALSE, warn = 2)

args_all <- commandArgs(trailingOnly = FALSE)
script_arg <- grep("^--file=", args_all, value = TRUE)
if (!length(script_arg)) stop("Cannot resolve script path.", call. = FALSE)
script_path <- sub("^--file=", "", script_arg[[1L]])
root <- normalizePath(
  file.path(dirname(script_path), "..", "..", ".."), mustWork = TRUE
)
source(file.path(
  root, "R/v45/charls_addendum_v45_1/charls_structural_utilities_v45_1.R"
))
v45_charls_activate_project_library(root)
for (pkg in c("digest", "dplyr", "yaml")) {
  if (!requireNamespace(pkg, quietly = TRUE)) {
    stop("Missing frozen package: ", pkg, call. = FALSE)
  }
}
source(file.path(root, "R/v45/production_mi_hashes_v45.R"))
outcome_utility_path <- file.path(
  root,
  "R/v45/charls_addendum_v45_1/charls_outcome_utilities_v45_1.R"
)
if (file.exists(outcome_utility_path)) source(outcome_utility_path)

stop_o <- function(...) stop(..., call. = FALSE)
is_yes <- function(x) {
  isTRUE(x) || (length(x) == 1L && !is.na(x) &&
    tolower(as.character(x)) %in% c("yes", "true", "1"))
}
is_no <- function(x) {
  identical(x, FALSE) || (length(x) == 1L && !is.na(x) &&
    tolower(as.character(x)) %in% c("no", "false", "0"))
}
regular_file <- function(path) {
  file.exists(path) && !dir.exists(path) && !nzchar(Sys.readlink(path))
}
sha256_file <- function(path) {
  if (!regular_file(path)) return(NA_character_)
  digest::digest(path, algo = "sha256", file = TRUE)
}
alias_of <- function(path) {
  sub(paste0("^", root, "/?"), "", normalizePath(path, mustWork = FALSE))
}
safe_alias <- function(alias, regular = TRUE) {
  if (length(alias) != 1L || is.na(alias) || !nzchar(alias) ||
      startsWith(alias, "/") ||
      any(strsplit(alias, "/", fixed = TRUE)[[1L]] %in% c("", ".", ".."))) {
    stop_o("Unsafe path alias: ", alias)
  }
  path <- file.path(root, alias)
  ok <- if (regular) regular_file(path) else dir.exists(path)
  if (!ok) stop_o("Required path is absent: ", alias)
  resolved <- normalizePath(path, mustWork = TRUE)
  if (!startsWith(resolved, paste0(root, .Platform$file.sep))) {
    stop_o("Path escapes project root: ", alias)
  }
  resolved
}
stable_tsv <- function(path, label = basename(path)) {
  if (!regular_file(path)) stop_o(label, " is absent.")
  before <- sha256_file(path)
  value <- utils::read.delim(
    path, stringsAsFactors = FALSE, check.names = FALSE,
    na.strings = character()
  )
  if (!identical(before, sha256_file(path))) stop_o(label, " changed.")
  list(value = value, sha256 = before)
}
stable_csv <- function(path, label = basename(path)) {
  if (!regular_file(path)) stop_o(label, " is absent.")
  before <- sha256_file(path)
  value <- utils::read.csv(
    path, stringsAsFactors = FALSE, check.names = FALSE
  )
  if (!identical(before, sha256_file(path))) stop_o(label, " changed.")
  list(value = value, sha256 = before)
}
stable_rds <- function(path, label = basename(path)) {
  if (!regular_file(path)) stop_o(label, " is absent.")
  before <- sha256_file(path)
  value <- readRDS(path)
  if (!identical(before, sha256_file(path))) stop_o(label, " changed.")
  list(value = value, sha256 = before)
}
stable_yaml <- function(path, label = basename(path)) {
  if (!regular_file(path)) stop_o(label, " is absent.")
  before <- sha256_file(path)
  value <- yaml::read_yaml(path)
  if (!identical(before, sha256_file(path))) stop_o(label, " changed.")
  list(value = value, sha256 = before)
}
same_table <- function(x, y, key) {
  if (!is.data.frame(x) || !is.data.frame(y) ||
      !identical(names(x), names(y)) ||
      anyDuplicated(x[[key]]) || anyDuplicated(y[[key]]) ||
      !setequal(as.character(x[[key]]), as.character(y[[key]]))) return(FALSE)
  normalize <- function(z) {
    z <- z[order(as.character(z[[key]]), method = "radix"), , drop = FALSE]
    rownames(z) <- NULL
    as.data.frame(lapply(z, function(v) {
      out <- as.character(v)
      out[is.na(out) | !nzchar(out)] <- "<MISSING>"
      out
    }), stringsAsFactors = FALSE, check.names = FALSE)
  }
  identical(normalize(x), normalize(y))
}
manifest_root <- function(x, key) {
  v45_charls_manifest_root(x, key, names(x))
}
function_sha <- function(fun) {
  v45_charls_text_sha256(c(
    deparse(formals(fun), width.cutoff = 500L),
    deparse(body(fun), width.cutoff = 500L)
  ))
}

work <- file.path(root, "work_v45/charls_addendum_v45_1")
result <- file.path(root, "results/v45/charls_addendum_v45_1")
restricted <- file.path(root, "derived_sensitive/v45/charls_addendum_v45_1")
qa <- file.path(root, "output/qa/v45/charls_addendum_v45_1")
paths <- list(
  spec = file.path(work, "charls_outcome_execution_spec_v45_1.yml"),
  model = file.path(work, "charls_outcome_model_registry_v45_1.tsv"),
  threshold = file.path(work, "charls_outcome_threshold_registry_v45_1.tsv"),
  anchor = file.path(work, "charls_outcome_anchor_registry_v45_1.tsv"),
  decision = file.path(work, "charls_outcome_decision_log_v45_1.md"),
  crosswalk = file.path(work, "charls_outcome_analysis_crosswalk_v45_1.tsv"),
  production_gate = file.path(
    work, "charls_production_mi_gate_state_v45_1.yml"
  ),
  main_gate = file.path(work, "charls_addendum_gate_state_v45_1.yml"),
  gate = file.path(work, "charls_outcome_execution_gate_state_v45_1.yml"),
  code = file.path(work, "charls_outcome_code_manifest_v45_1.tsv"),
  functions = file.path(
    work, "charls_outcome_function_manifest_v45_1.tsv"
  ),
  inputs = file.path(work, "charls_outcome_input_manifest_v45_1.tsv"),
  roots = file.path(work, "charls_outcome_freeze_roots_v45_1.tsv"),
  contract = file.path(
    restricted, "charls_outcome_execution_contract_v45_1.rds"
  ),
  scales = file.path(
    result, "charls_outcome_freeze_derived_scale_anchors_v45_1.tsv"
  ),
  trial_desc = file.path(
    result, "charls_trial_summary_descriptive_v45_1.tsv"
  ),
  validation = file.path(
    result, "charls_outcome_freeze_validation_v45_1.tsv"
  ),
  pointer = file.path(
    result, "charls_outcome_execution_current.tsv"
  ),
  output_manifest = file.path(
    result, "charls_outcome_freeze_output_manifest_v45_1.tsv"
  )
)

contract_aliases <- c(
  spec = "work_v45/charls_addendum_v45_1/charls_outcome_execution_spec_v45_1.yml",
  model = "work_v45/charls_addendum_v45_1/charls_outcome_model_registry_v45_1.tsv",
  threshold = "work_v45/charls_addendum_v45_1/charls_outcome_threshold_registry_v45_1.tsv",
  anchor = "work_v45/charls_addendum_v45_1/charls_outcome_anchor_registry_v45_1.tsv",
  decision = "work_v45/charls_addendum_v45_1/charls_outcome_decision_log_v45_1.md",
  crosswalk = "work_v45/charls_addendum_v45_1/charls_outcome_analysis_crosswalk_v45_1.tsv"
)
expected_contract_hashes <- c(
  spec = "8f97ea7e55f6af921e9cc739d109a6924dad070f418a00ab9464fca0f40a35c6",
  model = "7af5937ae0a1a2a8972e89df0d5c4d7dcf5e0262984e927bb1c704010272dede",
  threshold = "d8ad807adec1996ee4876a978bfaa90cb1a7e721cb4ac3e9da9121104a47924c",
  anchor = "638866007bc063b6a6c93f2f995ebf662d0feefebca363a1b7e30eb6c57e13c8",
  decision = "26f2fbc2bb6193f6f7fde17af4554f3621cb214d8fd8703e6890e253f6715689",
  crosswalk = "b64e868e5235ffe8e7af3def2409385921627ceb4a03b27595ad1ea35206cd7d"
)

build_authoring_manifest <- function() {
  out <- do.call(rbind, lapply(names(contract_aliases), function(id) {
    alias <- contract_aliases[[id]]
    path <- safe_alias(alias)
    data.frame(
      asset_id = id, path_alias = alias,
      bytes = as.numeric(file.info(path)$size),
      sha256 = sha256_file(path), status = "PASS",
      stringsAsFactors = FALSE
    )
  }))
  if (!identical(setNames(out$sha256, out$asset_id),
                 expected_contract_hashes)) {
    stop_o("One or more final authoring-contract hashes drifted.")
  }
  out
}

anchor_value <- function(anchor, id) {
  row <- anchor[anchor$anchor_id == id, , drop = FALSE]
  if (nrow(row) != 1L) stop_o("Missing anchor: ", id)
  as.character(row$value)
}

validate_registries <- function(authoring) {
  spec <- stable_yaml(paths$spec)$value
  model <- stable_tsv(paths$model)$value
  threshold <- stable_tsv(paths$threshold)$value
  anchor <- stable_tsv(paths$anchor)$value
  crosswalk <- stable_tsv(paths$crosswalk)$value
  inherited <- stable_tsv(file.path(
    work, "analysis_registry_addendum_v45_1.tsv"
  ))$value
  required_model_names <- c(
    "analysis_id", "module", "row_type", "role", "sample_id",
    "mi_object", "weight_variant", "exposure_id", "focal_terms",
    "adjustment_id", "formula_id", "contrast_id", "matrix_id",
    "replicate_columns", "replicate_scale", "failure_mask_group",
    "MCE_scope", "release_role", "expected_n",
    "expected_events_or_responses", "expected_period_rows", "expected_psu",
    "expected_dfcom", "anchor_binding_status", "status", "result_visibility"
  )
  signature <- c(
    "module", "row_type", "role", "sample_id", "mi_object",
    "weight_variant", "exposure_id", "adjustment_id",
    "formula_id", "contrast_id"
  )
  sig <- do.call(paste, c(model[signature], sep = "\r"))
  module_counts <- table(model$module)
  expected_modules <- c(
    CHARLS_trial_summary = 6L,
    CHARLS_within_session_inconsistency = 4L,
    CHARLS_adjacent_wave = 3L,
    CHARLS_W2_landmark = 14L,
    CHARLS_time_heterogeneity = 1L
  )
  expected_formula_ids <- c(
    "F_TRIAL_L100_A1", "F_INCONSISTENCY_LINEAR_A1",
    "F_INCONSISTENCY_SPLINE_A1", "F_ADJACENT_E0_A1",
    "F_W2_RESPONSE_LOGIT", "F_W2_SINGLE_A1",
    "F_W2_M12_D12_A1", "F_TIME_HETEROGENEITY_A1"
  )
  if (!identical(names(model), required_model_names) ||
      nrow(model) != 28L || anyDuplicated(model$analysis_id) ||
      anyDuplicated(sig) ||
      !identical(
        as.integer(module_counts[names(expected_modules)]),
        as.integer(expected_modules)
      ) ||
      !setequal(unique(model$formula_id), expected_formula_ids) ||
      any(!model$matrix_id %in% c(
        "RW-CHARLS-TRIAL-ACTUAL", "RW-CHARLS-ADJACENT-ACTUAL",
        "RW-CHARLS-W2-IPW-ACTUAL"
      )) ||
      any(model$replicate_columns != "R001-R500") ||
      any(model$replicate_scale !=
            "valid_columns_1_over_B_valid_minus_1") ||
      any(model$anchor_binding_status != "BOUND") ||
      any(model$status != "PRE_FREEZE_NOT_RUN") ||
      any(model$result_visibility != "BLOCKED")) {
    stop_o("The exact 28-row model registry/signature failed.")
  }
  if (nrow(threshold) != 12L ||
      anyDuplicated(threshold$threshold_id) ||
      any(threshold$binding_status != "BOUND") ||
      sum(as.logical(threshold$m100_trigger)) != 1L ||
      threshold$threshold_id[as.logical(threshold$m100_trigger)] !=
        "v45_c_thr_mce_m50") {
    stop_o("The exact 12-row threshold registry failed.")
  }
  if (nrow(anchor) != 75L || anyDuplicated(anchor$anchor_id) ||
      any(anchor$binding_status != "BOUND") ||
      any(grepl("PENDING_FREEZE_BINDING", unlist(anchor), fixed = TRUE))) {
    stop_o("The exact 75-row bound anchor registry failed.")
  }
  if (nrow(inherited) != 18L || anyDuplicated(inherited$analysis_id) ||
      nrow(crosswalk) != 18L ||
      anyDuplicated(crosswalk$inherited_analysis_id) ||
      !setequal(inherited$analysis_id, crosswalk$inherited_analysis_id) ||
      any(crosswalk$status != "BOUND") ||
      any(!as.logical(crosswalk$estimand_preserved))) {
    stop_o("The exact 18-row inherited-analysis crosswalk failed.")
  }
  target_ids <- unique(unlist(strsplit(
    crosswalk$execution_analysis_id, ";", fixed = TRUE
  )))
  if (!all(setdiff(target_ids, "v45_c_trial_desc") %in%
           model$analysis_id)) {
    stop_o("Crosswalk points outside the outcome registry.")
  }
  expected_public_aggregate_fields <- c(
    "analysis_id", "n", "events", "period_rows", "psu", "design_df",
    "beta", "standard_error", "HR", "confidence_interval", "P_value",
    "FMI", "MCE", "valid_replicate_fraction", "diagnostic_status"
  )
  if (!identical(as.character(spec$spec_version), "v45_1_charls_outcome") ||
      !identical(as.character(spec$status),
                 "DRAFT_PRE_FREEZE_NO_OUTCOME_EXECUTION") ||
      !isTRUE(spec$drafted_before_new_CHARLS_coefficients) ||
      !identical(as.integer(spec$registries$outcome_models$exact_rows), 28L) ||
      !identical(as.integer(spec$registries$inherited_crosswalk$exact_rows),
                 18L) ||
      !identical(
        as.character(
          spec$release$public_aggregate_allowed_after_validation
        ),
        expected_public_aggregate_fields
      )) {
    stop_o("Outcome specification governance header failed.")
  }
  list(
    spec = spec, model = model, threshold = threshold,
    anchor = anchor, crosswalk = crosswalk, inherited = inherited
  )
}

weighted_q_first <- function(x, w, p) {
  ok <- is.finite(x) & is.finite(w) & w > 0
  x <- x[ok]; w <- w[ok]
  if (!length(x)) stop_o("Weighted quantile has no support.")
  ord <- order(x, method = "radix")
  x <- x[ord]; w <- w[ord]
  x[which(cumsum(w) >= p * sum(w))[[1L]]]
}
weighted_mean <- function(x, w) sum(w * x) / sum(w)
weighted_pop_sd <- function(x, w) {
  mu <- weighted_mean(x, w)
  sqrt(sum(w * (x - mu)^2) / sum(w))
}

build_measurement_artifacts <- function(registries, freeze_id) {
  ledger_path <- safe_alias(
    "derived_sensitive/v43/charls_stage3_analysis_ledger_v43.rds"
  )
  ledger <- stable_rds(ledger_path, "stage3 ledger")
  master <- as.data.frame(ledger$value$person_master)
  trial_names <- paste0("pef_w1_trial", 1:3)
  if (!all(c("participant_id", "community_id", "weight_biomarker_w1",
             trial_names) %in% names(master))) {
    stop_o("Ledger lacks coefficient-blind trial fields.")
  }
  trial <- as.matrix(master[trial_names])
  complete_three <- apply(
    trial, 1L, function(x) all(is.finite(x) & x >= 30 & x <= 890)
  )
  trial <- trial[complete_three, , drop = FALSE]
  weight <- as.numeric(master$weight_biomarker_w1[complete_three])
  if (nrow(trial) != 12512L || any(!is.finite(weight) | weight <= 0)) {
    stop_o("Complete-three measurement denominator drifted.")
  }
  sorted <- t(apply(trial, 1L, sort, decreasing = TRUE))
  i_raw <- log1p(sorted[, 1L] - sorted[, 2L])
  mu <- weighted_mean(i_raw, weight)
  sigma <- weighted_pop_sd(i_raw, weight)
  i_z <- (i_raw - mu) / sigma
  probs <- c(0.05, 0.35, 0.65, 0.95)
  knots <- vapply(probs, function(p) weighted_q_first(i_z, weight, p),
                  numeric(1))
  expected <- c(
    2.6645548501904162, 1.4405336275941463,
    -1.8496998606277060, -0.1851116643749560,
    0.5341300887087024, 1.2816810527429137
  )
  observed <- c(mu, sigma, knots)
  if (any(abs(observed - expected) >
          1e-14 * pmax(1, abs(expected)))) {
    stop_o("Coefficient-blind I_raw/I_z anchors drifted.")
  }
  scale_ids <- c(
    "I_raw_weighted_mean", "I_raw_weighted_population_SD",
    "I_z_weighted_q05", "I_z_weighted_q35",
    "I_z_weighted_q65", "I_z_weighted_q95"
  )
  scales <- data.frame(
    scale_id = scale_ids,
    sample_id = "charls_w1_complete_three",
    variable = c("I_raw", "I_raw", rep("I_z", 4L)),
    metric = scale_ids,
    value = observed,
    weight = "weight_biomarker_w1",
    computation_rule = c(
      "sum(w*x)/sum(w)",
      "sqrt(sum(w*(x-weighted_mean)^2)/sum(w))",
      rep("first_sorted_value_with_cumulative_weight_at_least_probability",
          4L)
    ),
    source_sha256 = ledger$sha256,
    freeze_id = freeze_id, status = "PASS",
    stringsAsFactors = FALSE
  )
  derived <- cbind(
    trial,
    PEF_max = apply(trial, 1L, max),
    PEF_mean = rowMeans(trial),
    PEF_median = apply(trial, 1L, stats::median)
  )
  colnames(derived)[1:3] <- trial_names
  metrics <- c(
    "weighted_mean", "weighted_population_SD",
    "weighted_q25", "weighted_median", "weighted_q75"
  )
  trial_desc <- do.call(rbind, lapply(colnames(derived), function(variable) {
    x <- as.numeric(derived[, variable])
    values <- c(
      weighted_mean(x, weight), weighted_pop_sd(x, weight),
      weighted_q_first(x, weight, 0.25),
      weighted_q_first(x, weight, 0.50),
      weighted_q_first(x, weight, 0.75)
    )
    data.frame(
      analysis_id = "v45_c_trial_desc",
      sample_id = "charls_w1_complete_three",
      variable = variable, metric = metrics, value = values,
      unit = "L_per_min", weight = "weight_biomarker_w1",
      n = nrow(derived),
      computation_rule = c(
        "sum(w*x)/sum(w)",
        "sqrt(sum(w*(x-weighted_mean)^2)/sum(w))",
        rep("first_sorted_value_with_cumulative_weight_at_least_probability",
            3L)
      ),
      source_sha256 = ledger$sha256,
      freeze_id = freeze_id, status = "PASS",
      stringsAsFactors = FALSE
    )
  }))
  if (nrow(trial_desc) != 30L ||
      !identical(unique(trial_desc$n), 12512L)) {
    stop_o("Trial descriptive sidecar grid failed.")
  }
  knot_row <- data.frame(
    weighted_q05 = knots[[1L]], weighted_q35 = knots[[2L]],
    weighted_q65 = knots[[3L]], weighted_q95 = knots[[4L]]
  )
  authority_path <- safe_alias(
    "R/v43/04_charls_stage3_primary_mortality.R"
  )
  if (!identical(
        sha256_file(authority_path),
        "bc759aab44691deb5a920a4017c7b51bfe7c5694959b27ae9aa95462fba5908d"
      )) stop_o("v43 restricted-cubic-basis authority drifted.")
  rcs <- v45_charls_extract_top_function(
    authority_path, "restricted_cubic_basis"
  )
  basis <- rcs(i_z, knot_row, prefix = "I_z")
  if (!identical(names(basis),
                 c("I_z_linear", "I_z_nonlinear1", "I_z_nonlinear2")) ||
      nrow(basis) != 12512L || any(!is.finite(as.matrix(basis)))) {
    stop_o("Exact v43 I_z RCS basis reconstruction failed.")
  }
  list(
    scales = scales, trial_desc = trial_desc,
    basis_value_sha256 =
      v45_canonical_array_sha256(unname(as.matrix(basis))),
    basis_dimname_sha256 =
      v45_canonical_object_sha256(dimnames(as.matrix(basis))),
    complete_three = complete_three, ledger = ledger$value,
    ledger_sha256 = ledger$sha256
  )
}

validate_actual_contract <- function(registries, measurement) {
  actual_path <- safe_alias(
    "derived_sensitive/v45/charls_addendum_v45_1/charls_actual_keys_mi_contract_v45_1.rds"
  )
  actual <- stable_rds(actual_path, "actual-key contract")
  if (!identical(
        actual$sha256,
        "2e80186cacd93d8f9c29aac1dc02168d545e4f43a4cded86542565bb7a01937c"
      ) ||
      !identical(actual$value$actual_design_key_role,
                 "production_bound_actual_CHARLS_community_keys") ||
      !isTRUE(actual$value$one_structural_stratum)) {
    stop_o("Actual-key production contract failed.")
  }
  synthetic <- stable_rds(safe_alias(
    "work_v45/charls_addendum_v45_1/charls_structural_replicate_contract_v45_1.rds"
  ), "synthetic contract")
  if (!identical(
        synthetic$sha256,
        "2fd47f0717d006fe96dfbda51bd6008393bac53cd938b5d77e2d5f43fb4e745f"
      ) || !identical(synthetic$value$production_use_allowed, FALSE)) {
    stop_o("Synthetic contract is not production-forbidden.")
  }
  published <- stable_tsv(file.path(
    result, "charls_actual_rao_wu_matrix_contracts_v45_1.tsv"
  ))$value
  expected <- list(
    trial = c("RW-CHARLS-TRIAL-ACTUAL", "450501", "433"),
    adjacent = c("RW-CHARLS-ADJACENT-ACTUAL", "450502", "433"),
    w2 = c("RW-CHARLS-W2-IPW-ACTUAL", "450504", "420")
  )
  matrix_rows <- do.call(rbind, lapply(names(expected), function(name) {
    module <- actual$value$modules[[name]]
    rule <- expected[[name]]
    matrix <- module$matrix
    prefix <- matrix[, 1:250, drop = FALSE]
    prefix_value <- prefix; dimnames(prefix_value) <- NULL
    value <- matrix; dimnames(value) <- NULL
    row <- published[published$matrix_id == rule[[1L]], , drop = FALSE]
    checks <- c(
      identical(module$matrix_id, rule[[1L]]),
      identical(as.integer(module$seed), as.integer(rule[[2L]])),
      identical(dim(matrix), c(as.integer(rule[[3L]]), 500L)),
      identical(rownames(matrix), as.character(module$key_map$community_id)),
      identical(colnames(matrix), sprintf("R%03d", 1:500)),
      identical(module$key_map, actual$value$key_maps[[name]]),
      identical(module$scale, 1 / 499),
      identical(module$rscales, rep(1, 500L)),
      isTRUE(module$mse), !isTRUE(module$combined_weights),
      nrow(row) == 1L,
      identical(
        v45_canonical_object_sha256(module$key_map$community_id),
        as.character(row$key_sha256)
      ),
      identical(v45_canonical_array_sha256(matrix),
                as.character(row$matrix_sha256)),
      identical(v45_canonical_array_sha256(value),
                as.character(row$value_sha256)),
      identical(v45_canonical_array_sha256(prefix_value),
                as.character(row$prefix_value_sha256))
    )
    if (!all(checks)) stop_o("Actual matrix failed: ", name)
    data.frame(
      module = name, matrix_id = module$matrix_id,
      seed = module$seed, psu = nrow(matrix), replicates = ncol(matrix),
      key_sha256 = as.character(row$key_sha256),
      matrix_sha256 = as.character(row$matrix_sha256),
      value_sha256 = as.character(row$value_sha256),
      prefix_value_sha256 = as.character(row$prefix_value_sha256),
      stringsAsFactors = FALSE
    )
  }))
  master <- as.data.frame(measurement$ledger$person_master)
  pmap <- actual$value$participant_denominator_map
  if (!identical(as.character(master$participant_id),
                 as.character(pmap$participant_id))) {
    stop_o("Actual participant backbone order drifted.")
  }
  # Structural outcome/event anchors were independently validated upstream.
  # The freezer binds those aggregate anchors without opening mortality or
  # response fields. R2 membership for the immutable W2-PEF join is recovered
  # only from the fixed PEF measurement itself.
  structural <- rbind(
    boundary = c(
      participants = as.integer(anchor_value(
        registries$anchor, "v45_c_anchor_boundary_n"
      )),
      deaths = as.integer(anchor_value(
        registries$anchor, "v45_c_anchor_boundary_deaths"
      )),
      period_rows = as.integer(anchor_value(
        registries$anchor, "v45_c_anchor_boundary_rows"
      )),
      psu = as.integer(anchor_value(
        registries$anchor, "v45_c_anchor_boundary_psu"
      )),
      dfcom = as.integer(anchor_value(
        registries$anchor, "v45_c_anchor_boundary_df"
      ))
    ),
    w2_r2 = c(
      participants = as.integer(anchor_value(
        registries$anchor, "v45_c_anchor_w2_r2_n"
      )),
      deaths = as.integer(anchor_value(
        registries$anchor, "v45_c_anchor_w2_r2_deaths"
      )),
      period_rows = as.integer(anchor_value(
        registries$anchor, "v45_c_anchor_w2_r2_rows"
      )),
      psu = as.integer(anchor_value(
        registries$anchor, "v45_c_anchor_w2_r2_psu"
      )),
      dfcom = as.integer(anchor_value(
        registries$anchor, "v45_c_anchor_w2_r2_df"
      ))
    ),
    w2_c3 = c(
      participants = as.integer(anchor_value(
        registries$anchor, "v45_c_anchor_w2_c3_n"
      )),
      deaths = as.integer(anchor_value(
        registries$anchor, "v45_c_anchor_w2_c3_deaths"
      )),
      period_rows = as.integer(anchor_value(
        registries$anchor, "v45_c_anchor_w2_c3_rows"
      )),
      psu = as.integer(anchor_value(
        registries$anchor, "v45_c_anchor_w2_c3_psu"
      )),
      dfcom = as.integer(anchor_value(
        registries$anchor, "v45_c_anchor_w2_c3_df"
      ))
    )
  )
  expected_structural <- rbind(
    boundary = c(12235, 1632, 44456, 432, 431),
    w2_r2 = c(8308, 912, 23154, 420, 419),
    w2_c3 = c(8245, 899, 22984, 420, 419)
  )
  colnames(expected_structural) <- colnames(structural)
  if (!identical(
        as.numeric(structural), as.numeric(expected_structural)
      )) {
    stop_o("Coefficient-blind structural anchors failed.")
  }
  fixed_fields <- c(
    "participant_id", "pef_w2_trial1", "pef_w2_trial2",
    "pef_w2_trial3", "pef_w2_valid_n", "pef_w2_completion_yes",
    "pef_w2_standing", "pef_w2_full_effort", "pef_w2_strict_protocol",
    "pef_w2_boundary_floor", "pef_w2_boundary_ceiling"
  )
  r2_measurement <- pmap$D2_support & is.finite(master$pef_w2_rowmax)
  if (sum(r2_measurement) != 8308L) {
    stop_o("Immutable W2 PEF measurement join denominator drifted.")
  }
  backbone_fields <- c(
    "participant_id", "community_id", "base_weight",
    "trial_complete_three", "adjacent_participant",
    "w2_initial", "D2_support"
  )
  restricted_join_hashes <- c(
    W2_R2_fixed_fields =
      v45_canonical_data_frame_contract(
        master[r2_measurement, fixed_fields]
      )$sha256,
    outcome_free_period_key_map =
      v45_canonical_data_frame_contract(
        actual$value$outcome_free_period_key_map
      )$sha256,
    participant_backbone =
      v45_canonical_data_frame_contract(pmap[backbone_fields])$sha256
  )
  list(
    contract_sha256 = actual$sha256,
    matrix_bindings = matrix_rows,
    structural = structural,
    restricted_join_hashes = restricted_join_hashes
  )
}

formula_component_serialization <- function(formula_texts) {
  formula_texts <- as.character(formula_texts)
  if (!length(formula_texts) || anyNA(formula_texts) ||
      any(!nzchar(formula_texts))) {
    stop_o("Canonical formula-component serialization input is invalid.")
  }
  paste0(
    sprintf(
      "%d:%s",
      nchar(formula_texts, type = "bytes"),
      formula_texts
    ),
    collapse = "||"
  )
}

formula_components_for_row <- function(row, registries) {
  formula_id <- as.character(row$formula_id[[1L]])
  row_type <- as.character(row$row_type[[1L]])
  contrast_id <- as.character(row$contrast_id[[1L]])
  templates <- registries$spec$formula_registry$templates
  component_map <- registries$spec$formula_registry$
    paired_contrast_component_exposures
  text <- as.character(templates[[formula_id]])
  if (identical(formula_id, "F_W2_RESPONSE_LOGIT")) {
    text <- registries$spec$W2_response_model$formula
  }
  exposures <- NA_character_
  if (identical(row_type, "paired_contrast") &&
      identical(formula_id, "F_TRIAL_L100_A1")) {
    if (!contrast_id %in% names(component_map)) {
      stop_o(
        "Paired contrast lacks a prespecified component-formula mapping: ",
        as.character(row$analysis_id[[1L]])
      )
    }
    exposures <- as.character(component_map[[contrast_id]])
    expected_focal <- sub("^L100_", "beta_", exposures)
    observed_focal <- strsplit(
      as.character(row$focal_terms[[1L]]), ";", fixed = TRUE
    )[[1L]]
    if (length(exposures) != 2L || anyDuplicated(exposures) ||
        any(!exposures %in%
              c("L100_max", "L100_mean", "L100_median")) ||
        any(grepl("^beta_", exposures)) ||
        !identical(observed_focal, expected_focal)) {
      stop_o(
        "Paired-contrast component exposures/focal terms drifted: ",
        as.character(row$analysis_id[[1L]])
      )
    }
  } else if (grepl("{EXPOSURE}", text, fixed = TRUE)) {
    exposures <- strsplit(
      as.character(row$focal_terms[[1L]]), ";", fixed = TRUE
    )[[1L]][1L]
  }
  texts <- if (all(is.na(exposures))) {
    text
  } else {
    vapply(exposures, function(exposure) {
      gsub("{EXPOSURE}", exposure, text, fixed = TRUE)
    }, character(1))
  }
  formulas <- lapply(texts, stats::as.formula)
  canonical_text <- vapply(formulas, function(formula) {
    labels <- attr(stats::terms(formula), "term.labels")
    if (anyDuplicated(labels)) {
      stop_o(
        "Duplicated formula term: ",
        as.character(row$analysis_id[[1L]])
      )
    }
    paste(deparse(formula, width.cutoff = 500L), collapse = " ")
  }, character(1))
  if (identical(formula_id, "F_TRIAL_L100_A1") &&
      any(grepl("\\bbeta_", canonical_text))) {
    stop_o(
      "A synthetic beta term entered a trial component formula: ",
      as.character(row$analysis_id[[1L]])
    )
  }
  list(
    exposures = if (all(is.na(exposures))) character() else exposures,
    formula_text = canonical_text,
    serialization = formula_component_serialization(canonical_text)
  )
}

validate_drift_and_formulas <- function(registries, measurement) {
  drift <- stable_csv(safe_alias(
    "results/v43/charls_cross_wave_drift_v43.csv"
  ))
  row <- drift$value[
    drift$value$scope == "baseline_eligible_pairwise" &
      drift$value$wave_start == "W1" & drift$value$wave_end == "W2",
    , drop = FALSE
  ]
  if (!identical(
        drift$sha256,
        "b623e9f4e510b055481f426c6ca2fca807e55ef9fc8ca2c2ce88a42f07783093"
      ) || nrow(row) != 1L || as.integer(row$n) != 8283L ||
      abs(as.numeric(row$unexplained_shift_sd) -
            0.06847071614962984) > 1e-15 ||
      as.character(row$status) != "PASS") {
    stop_o("Exact v43 W1-W2 drift authority row failed.")
  }
  templates <- registries$spec$formula_registry$templates
  if (!setequal(names(templates), unique(registries$model$formula_id))) {
    stop_o("Formula registry does not cover all and only formula IDs.")
  }
  component_map <- registries$spec$formula_registry$
    paired_contrast_component_exposures
  trial_contrast_rows <- registries$model[
    registries$model$row_type == "paired_contrast" &
      registries$model$formula_id == "F_TRIAL_L100_A1",
    , drop = FALSE
  ]
  component_map_valid <- is.list(component_map) &&
    length(component_map) == 3L &&
    !is.null(names(component_map)) &&
    !anyDuplicated(names(component_map)) &&
    all(vapply(component_map, function(value) {
      is.character(value) && length(value) == 2L &&
        !anyNA(value) && !anyDuplicated(value) &&
        all(value %in%
              c("L100_max", "L100_mean", "L100_median"))
    }, logical(1)))
  if (!component_map_valid ||
      !identical(
        sort(names(component_map), method = "radix"),
        sort(trial_contrast_rows$contrast_id, method = "radix")
      )) {
    stop_o(
      "Paired-contrast component mappings do not fully and only cover ",
      "the registered trial contrasts."
    )
  }
  resolved <- do.call(rbind, lapply(seq_len(nrow(registries$model)), function(i) {
    row <- registries$model[i, , drop = FALSE]
    components <- formula_components_for_row(row, registries)
    data.frame(
      analysis_id = row$analysis_id, formula_id = row$formula_id,
      component_count = length(components$formula_text),
      component_exposures = if (length(components$exposures)) {
        paste(components$exposures, collapse = ";")
      } else {
        "NONE"
      },
      component_formula_serialization = components$serialization,
      component_formula_ast_sha256 = v45_charls_text_sha256(c(
        "formula_component_set_v1",
        components$serialization
      )),
      stringsAsFactors = FALSE
    )
  }))
  contrast_contract <- list(
    trial_order = c("beta_max", "beta_mean", "beta_median"),
    trial_component_exposures = component_map,
    trial_L = rbind(
      beta_mean_minus_beta_max = c(-1, 1, 0),
      beta_median_minus_beta_max = c(-1, 0, 1),
      beta_median_minus_beta_mean = c(0, -1, 1)
    ),
    adjacent_order = c("beta_all", "beta_adjacent"),
    adjacent_L = c(beta_adjacent_minus_beta_all = -1, 1),
    time_order = unlist(
      registries$spec$time_heterogeneity$
        coefficient_order_for_linear_combinations
    ),
    time_L = do.call(rbind, registries$spec$time_heterogeneity$contrast_vectors)
  )
  list(
    formula_hashes = resolved, contrast_contract = contrast_contract,
    drift_row_sha256 = v45_canonical_data_frame_contract(row)$sha256
  )
}

build_code_manifest <- function(require_outcome_utilities = FALSE) {
  aliases <- c(
    "R/v45/charls_addendum_v45_1/11_freeze_charls_outcome_execution_v45_1.R",
    "R/v45/charls_addendum_v45_1/charls_structural_utilities_v45_1.R",
    "R/v45/production_mi_hashes_v45.R",
    "R/v45/charls_addendum_v45_1/03_charls_actual_keys_mi_utilities_v45_1.R",
    "R/v45/charls_addendum_v45_1/08_freeze_charls_production_mi_v45_1.R",
    "R/v45/charls_addendum_v45_1/10_validate_charls_production_mi_v45_1.R",
    "R/v43/04_charls_stage3_primary_mortality.R"
  )
  execution_aliases <- c(
    "R/v45/charls_addendum_v45_1/12_run_charls_outcome_execution_v45_1.R",
    "R/v45/charls_addendum_v45_1/13_validate_charls_outcome_execution_v45_1.R"
  )
  execution_present <- vapply(
    execution_aliases,
    function(alias) regular_file(file.path(root, alias)),
    logical(1)
  )
  if (require_outcome_utilities && !all(execution_present)) {
    stop_o(
      "Outcome runner/validator code closure is incomplete: ",
      paste(basename(execution_aliases[!execution_present]), collapse = ", ")
    )
  }
  aliases <- c(aliases, execution_aliases[execution_present])
  utility_alias <-
    "R/v45/charls_addendum_v45_1/charls_outcome_utilities_v45_1.R"
  if (regular_file(file.path(root, utility_alias))) {
    aliases <- c(aliases, utility_alias)
  } else if (require_outcome_utilities) {
    stop_o("Outcome utility closure is not yet available.")
  }
  do.call(rbind, lapply(aliases, function(alias) {
    path <- safe_alias(alias)
    data.frame(
      asset_id = paste0("CHARLS_OUTCOME::", alias),
      path_alias = alias, bytes = as.numeric(file.info(path)$size),
      sha256 = sha256_file(path), immutable = TRUE,
      stringsAsFactors = FALSE
    )
  }))
}

build_function_manifest <- function() {
  top_level_function_names <- function(path) {
    expressions <- parse(file = path, keep.source = FALSE)
    names <- vapply(expressions, function(expression) {
      if (!is.call(expression) ||
          !identical(expression[[1L]], as.name("<-")) ||
          length(expression) != 3L ||
          !is.symbol(expression[[2L]]) ||
          !is.call(expression[[3L]]) ||
          !identical(expression[[3L]][[1L]], as.name("function"))) {
        return(NA_character_)
      }
      as.character(expression[[2L]])
    }, character(1))
    unique(names[!is.na(names) & nzchar(names)])
  }
  names_local <- unique(c(
    top_level_function_names(script_path),
    top_level_function_names(outcome_utility_path)
  ))
  imported <- c(
    "v45_charls_activate_project_library",
    "v45_charls_atomic_write_tsv", "v45_charls_atomic_write_yaml",
    "v45_charls_atomic_save_rds", "v45_charls_extract_top_function",
    "v45_charls_manifest_root", "v45_charls_text_sha256",
    "v45_canonical_object_sha256", "v45_canonical_array_sha256",
    "v45_canonical_data_frame_contract"
  )
  expected_names <- sort(unique(c(names_local, imported)), method = "radix")
  available_names <- sort(ls(globalenv()), method = "radix")
  missing_names <- setdiff(expected_names, available_names)
  nonfunctions <- expected_names[vapply(
    expected_names,
    function(name) {
      exists(name, envir = globalenv(), inherits = FALSE) &&
        !is.function(get(name, envir = globalenv(), inherits = FALSE))
    },
    logical(1)
  )]
  if (length(missing_names) || length(nonfunctions)) {
    stop_o(
      "Outcome function closure is incomplete; missing=",
      paste(missing_names, collapse = "|"),
      "; nonfunctions=", paste(nonfunctions, collapse = "|")
    )
  }
  manifest <- do.call(rbind, lapply(expected_names, function(name) {
    fun <- get(name, globalenv())
    data.frame(
      asset_id = paste0("function::", name), function_name = name,
      function_sha256 = function_sha(fun), status = "PASS",
      stringsAsFactors = FALSE
    )
  }))
  recorded_names <- sort(unique(manifest$function_name), method = "radix")
  if (anyDuplicated(manifest$asset_id) ||
      !identical(recorded_names, expected_names) ||
      length(setdiff(expected_names, recorded_names)) ||
      length(setdiff(recorded_names, expected_names))) {
    stop_o("Outcome function manifest has a nonzero closure difference.")
  }
  manifest
}

fixed_input_manifest <- function(registries) {
  immutable <- registries$spec$immutable_inputs
  entries <- immutable[vapply(immutable, function(x) {
    is.list(x) && !is.null(x$path)
  }, logical(1))]
  rows <- do.call(rbind, lapply(names(entries), function(id) {
    alias <- entries[[id]]$path
    path <- safe_alias(alias)
    observed <- sha256_file(path)
    if (!is.null(entries[[id]]$sha256) &&
        !identical(observed, as.character(entries[[id]]$sha256))) {
      stop_o("Immutable input drifted: ", id)
    }
    data.frame(
      asset_id = paste0("fixed::", id), object_id = "",
      path_alias = alias, bytes = as.numeric(file.info(path)$size),
      sha256 = observed,
      access = if (startsWith(alias, "derived_sensitive/")) {
        "restricted"
      } else "aggregate",
      status = "PASS", stringsAsFactors = FALSE
    )
  }))
  extra <- c(
    analysis_registry =
      "work_v45/charls_addendum_v45_1/analysis_registry_addendum_v45_1.tsv",
    actual_matrix_contracts =
      "results/v45/charls_addendum_v45_1/charls_actual_rao_wu_matrix_contracts_v45_1.tsv"
  )
  extra_rows <- do.call(rbind, lapply(names(extra), function(id) {
    path <- safe_alias(extra[[id]])
    data.frame(
      asset_id = paste0("fixed::", id), object_id = "",
      path_alias = extra[[id]], bytes = as.numeric(file.info(path)$size),
      sha256 = sha256_file(path), access = "aggregate", status = "PASS",
      stringsAsFactors = FALSE
    )
  }))
  rbind(rows, extra_rows)
}

rehash_manifest <- function(manifest, label) {
  if (anyDuplicated(manifest$asset_id) ||
      any(manifest$status %in% "FAIL")) stop_o(label, " schema failed.")
  ok <- vapply(seq_len(nrow(manifest)), function(i) {
    path <- safe_alias(as.character(manifest$path_alias[[i]]))
    identical(as.numeric(file.info(path)$size),
              as.numeric(manifest$bytes[[i]])) &&
      identical(sha256_file(path), as.character(manifest$sha256[[i]]))
  }, logical(1))
  if (!all(ok)) stop_o(label, " rehash failed.")
  invisible(TRUE)
}

load_validated_mi <- function() {
  gate_read <- stable_yaml(paths$production_gate, "production MI gate")
  gate <- gate_read$value
  if (!identical(
        as.character(gate$charls_production_mi_execution$status),
        "INDEPENDENT_VALIDATION_PASS"
      ) ||
      !identical(
        as.character(
          gate$charls_production_mi_independent_validation$status
        ), "PASS"
      ) ||
      !is_no(gate$outcome_execution_allowed) ||
      !is_no(gate$new_coefficient_inspection_allowed)) {
    stop_o("Production MI independent-validation gate is not PASS.")
  }
  independent_alias <- as.character(
    gate$charls_production_mi_independent_validation$output_manifest
  )
  independent <- stable_tsv(
    safe_alias(independent_alias), "MI independent output manifest"
  )
  if (!identical(
        independent$sha256,
        as.character(
          gate$charls_production_mi_independent_validation$
            output_manifest_sha256
        )
      )) stop_o("Independent output-manifest hash differs from gate.")
  independent_table <- independent$value
  if (anyDuplicated(independent_table$asset_id) ||
      any(independent_table$validation_status != "PASS")) {
    stop_o("Independent MI output manifest schema failed.")
  }
  ok <- vapply(seq_len(nrow(independent_table)), function(i) {
    path <- safe_alias(independent_table$path_alias[[i]])
    identical(as.numeric(file.info(path)$size),
              as.numeric(independent_table$bytes[[i]])) &&
      identical(sha256_file(path),
                as.character(independent_table$sha256[[i]]))
  }, logical(1))
  if (!all(ok)) stop_o("Independent MI output manifest rehash failed.")
  rows <- lapply(c("MI-C0", "MI-C2"), function(object_id) {
    token <- gsub("-", "_", object_id, fixed = TRUE)
    current_alias <- file.path(
      "results/v45/charls_addendum_v45_1/production_mi",
      paste0(token, "_m50_current.tsv")
    )
    validated_alias <- file.path(
      "results/v45/charls_addendum_v45_1/production_mi",
      paste0(token, "_m50_validated.tsv")
    )
    current <- stable_tsv(safe_alias(current_alias), paste0(object_id, " current"))
    validated <- stable_tsv(
      safe_alias(validated_alias), paste0(object_id, " validated")
    )
    ctab <- current$value; vtab <- validated$value
    gate_object <- gate$charls_production_mi_execution$objects[[object_id]]
    if (nrow(ctab) != 1L || nrow(vtab) != 1L ||
        as.character(ctab$object_id) != object_id ||
        as.character(vtab$object_id) != object_id ||
        as.integer(ctab$requested_m) != 50L ||
        as.integer(vtab$requested_m) != 50L ||
        as.character(vtab$status) != "INDEPENDENT_VALIDATION_PASS" ||
        !identical(as.character(vtab$current_pointer_sha256),
                   current$sha256) ||
        !identical(as.character(vtab$mids_sha256),
                   as.character(ctab$mids_sha256)) ||
        !identical(as.character(vtab$run_id),
                   as.character(ctab$run_id)) ||
        !identical(as.character(gate_object$validated_pointer_sha256),
                   validated$sha256)) {
      stop_o(object_id, " validated/current/gate pointer mismatch.")
    }
    mids_path <- safe_alias(as.character(ctab$mids_path_alias))
    run_manifest_path <- safe_alias(as.character(ctab$run_manifest_path_alias))
    run_output_path <- safe_alias(
      as.character(ctab$run_output_manifest_path_alias)
    )
    if (!identical(sha256_file(mids_path), as.character(ctab$mids_sha256)) ||
        !identical(
          sha256_file(run_output_path),
          as.character(ctab$run_output_manifest_sha256)
        )) stop_o(object_id, " mids/run-output hash failed.")
    run_output <- stable_tsv(run_output_path)$value
    if (anyDuplicated(run_output$asset_id) ||
        any(run_output$validation_status != "PASS")) {
      stop_o(object_id, " run-output schema failed.")
    }
    ok_run <- vapply(seq_len(nrow(run_output)), function(i) {
      path <- safe_alias(run_output$path_alias[[i]])
      identical(as.numeric(file.info(path)$size),
                as.numeric(run_output$bytes[[i]])) &&
        identical(sha256_file(path), as.character(run_output$sha256[[i]]))
    }, logical(1))
    if (!all(ok_run)) stop_o(object_id, " run-output rehash failed.")
    independent_pointer <- independent_table[
      independent_table$path_alias == validated_alias, , drop = FALSE
    ]
    if (nrow(independent_pointer) != 1L ||
        !identical(as.character(independent_pointer$sha256),
                   validated$sha256)) {
      stop_o(object_id, " independent manifest lacks validated pointer.")
    }
    data.frame(
      object_id = object_id, requested_m = 50L,
      run_id = as.character(ctab$run_id),
      validated_pointer_path_alias = validated_alias,
      validated_pointer_sha256 = validated$sha256,
      current_pointer_path_alias = current_alias,
      current_pointer_sha256 = current$sha256,
      mids_path_alias = as.character(ctab$mids_path_alias),
      mids_sha256 = as.character(ctab$mids_sha256),
      run_manifest_path_alias = as.character(ctab$run_manifest_path_alias),
      run_manifest_sha256 = sha256_file(run_manifest_path),
      run_output_manifest_path_alias =
        as.character(ctab$run_output_manifest_path_alias),
      run_output_manifest_sha256 = sha256_file(run_output_path),
      independent_validation_manifest_path_alias = independent_alias,
      independent_validation_manifest_sha256 = independent$sha256,
      status = "INDEPENDENT_VALIDATION_PASS",
      stringsAsFactors = FALSE
    )
  })
  list(
    rows = do.call(rbind, rows), gate_sha256 = gate_read$sha256,
    independent_manifest = independent_table
  )
}

build_components <- function(require_mi = FALSE, freeze_id = "SELF_TEST") {
  authoring <- build_authoring_manifest()
  registries <- validate_registries(authoring)
  measurement <- build_measurement_artifacts(registries, freeze_id)
  actual <- validate_actual_contract(registries, measurement)
  semantics <- validate_drift_and_formulas(registries, measurement)
  code <- build_code_manifest(require_outcome_utilities = require_mi)
  functions <- build_function_manifest()
  inputs <- fixed_input_manifest(registries)
  mi <- NULL
  if (require_mi) {
    mi <- load_validated_mi()
    mi_assets <- do.call(rbind, lapply(seq_len(nrow(mi$rows)), function(i) {
      row <- mi$rows[i, ]
      aliases <- c(
        validated_pointer = row$validated_pointer_path_alias,
        current_pointer = row$current_pointer_path_alias,
        mids = row$mids_path_alias,
        run_manifest = row$run_manifest_path_alias,
        run_output_manifest = row$run_output_manifest_path_alias
      )
      do.call(rbind, lapply(names(aliases), function(kind) {
        path <- safe_alias(aliases[[kind]])
        data.frame(
          asset_id = paste(row$object_id, kind, sep = "::"),
          object_id = row$object_id, path_alias = aliases[[kind]],
          bytes = as.numeric(file.info(path)$size),
          sha256 = sha256_file(path),
          access = if (kind == "mids") "restricted" else "aggregate",
          status = "PASS", stringsAsFactors = FALSE
        )
      }))
    }))
    inputs <- rbind(inputs, mi_assets)
  }
  roots <- data.frame(
    root_id = c(
      "charls_outcome_authoring_root", "charls_outcome_code_root",
      "charls_outcome_function_root", "charls_outcome_input_root",
      "charls_outcome_model_registry_root",
      "charls_outcome_threshold_registry_root",
      "charls_outcome_anchor_registry_root",
      "charls_outcome_crosswalk_root",
      "charls_outcome_formula_root", "charls_actual_matrix_binding_root",
      "charls_structural_anchor_root", "charls_restricted_join_root"
    ),
    sha256 = c(
      manifest_root(authoring, "asset_id"),
      manifest_root(code, "asset_id"),
      manifest_root(functions, "asset_id"),
      manifest_root(inputs, "asset_id"),
      v45_canonical_data_frame_contract(registries$model)$sha256,
      v45_canonical_data_frame_contract(registries$threshold)$sha256,
      v45_canonical_data_frame_contract(registries$anchor)$sha256,
      v45_canonical_data_frame_contract(registries$crosswalk)$sha256,
      v45_canonical_data_frame_contract(semantics$formula_hashes)$sha256,
      v45_canonical_data_frame_contract(actual$matrix_bindings)$sha256,
      v45_canonical_array_sha256(actual$structural),
      v45_canonical_object_sha256(actual$restricted_join_hashes)
    ),
    stringsAsFactors = FALSE
  )
  if (any(!grepl("^[0-9a-f]{64}$", roots$sha256))) {
    stop_o("One or more freeze roots are invalid.")
  }
  list(
    authoring = authoring, registries = registries,
    measurement = measurement, actual = actual, semantics = semantics,
    code = code, functions = functions, inputs = inputs, roots = roots,
    mi = mi
  )
}

make_contract <- function(components, freeze_id, frozen_at) {
  list(
    contract_version = "v45_1_charls_outcome_execution",
    freeze_id = freeze_id, created_at_utc = frozen_at,
    governance = list(
      coefficient_generation_count = 0L,
      coefficient_inspection_count = 0L,
      response_model_fit_count = 0L, outcome_model_fit_count = 0L,
      completed_dataset_persistence_count = 0L,
      row_level_public_export_count = 0L
    ),
    production_mi_gate_sha256 = components$mi$gate_sha256,
    main_addendum_gate_sha256 = sha256_file(paths$main_gate),
    specification_manifest = components$authoring,
    code_manifest = components$code,
    function_manifest = components$functions,
    input_manifest = components$inputs,
    roots = components$roots,
    mi_bindings = components$mi$rows,
    actual_design_contract_sha256 = components$actual$contract_sha256,
    actual_matrix_bindings = components$actual$matrix_bindings,
    structural_anchors = components$actual$structural,
    derived_scale_anchors = components$measurement$scales,
    I_z_RCS_basis_value_sha256 =
      components$measurement$basis_value_sha256,
    I_z_RCS_basis_dimname_sha256 =
      components$measurement$basis_dimname_sha256,
    formula_hashes = components$semantics$formula_hashes,
    contrast_contract = components$semantics$contrast_contract,
    restricted_join_hashes = components$actual$restricted_join_hashes,
    v43_W1_W2_drift_row_sha256 =
      components$semantics$drift_row_sha256,
    legacy_anchor_rule =
      components$registries$spec$legacy_anchor_reproduction,
    model_registry = components$registries$model,
    threshold_registry = components$registries$threshold,
    anchor_registry = components$registries$anchor,
    crosswalk = components$registries$crosswalk,
    release_gate = list(
      restricted_outcome_execution_allowed = TRUE,
      new_coefficient_inspection_allowed = FALSE
    )
  )
}

trial_desc_tsv_payload <- function(x) {
  required <- c(
    "analysis_id", "sample_id", "variable", "metric", "value", "unit",
    "weight", "n", "computation_rule", "source_sha256", "freeze_id",
    "status"
  )
  if (!is.data.frame(x) || !identical(names(x), required) ||
      nrow(x) != 30L || any(!is.finite(as.numeric(x$value)))) {
    stop_o("Trial descriptive TSV payload is invalid.")
  }
  out <- x[
    order(x$variable, x$metric, method = "radix"), , drop = FALSE
  ]
  rownames(out) <- NULL
  out$value <- sprintf("%.17g", as.numeric(out$value))
  if (anyNA(out$value) || any(!nzchar(out$value)) ||
      any(grepl("^(NA|NaN|Inf|-Inf)$", out$value))) {
    stop_o("Trial descriptive numeric text serialization failed.")
  }
  out
}

serialized_tsv_sha256 <- function(x) {
  temporary <- tempfile("charls_v45_1_serialized_", fileext = ".tsv")
  on.exit(
    if (file.exists(temporary)) unlink(temporary, force = TRUE),
    add = TRUE
  )
  v45_charls_atomic_write_tsv(x, temporary)
  sha256_file(temporary)
}

output_manifest_from <- function(stage) {
  aliases <- c(
    code = alias_of(paths$code), functions = alias_of(paths$functions),
    inputs = alias_of(paths$inputs), roots = alias_of(paths$roots),
    contract = alias_of(paths$contract), scales = alias_of(paths$scales),
    trial_desc = alias_of(paths$trial_desc),
    validation = alias_of(paths$validation),
    pointer = alias_of(paths$pointer)
  )
  do.call(rbind, lapply(names(aliases), function(id) {
    path <- stage[[id]]
    data.frame(
      asset_id = id, path_alias = aliases[[id]],
      bytes = as.numeric(file.info(path)$size),
      sha256 = sha256_file(path),
      access = if (id == "contract") "restricted" else "public_no_coefficient",
      validation_status = "PASS", stringsAsFactors = FALSE
    )
  }))
}

outcome_freeze_lock <- file.path(
  restricted, ".charls_outcome_execution_freeze.lock"
)
legacy_outcome_freeze_lock <- file.path(
  work, ".charls_outcome_execution_freeze.lock"
)

freeze_transaction_path_is_symlink <- function(path) {
  target <- Sys.readlink(path)
  length(target) == 1L && !is.na(target) && nzchar(target)
}

freeze_transaction_lock_marker_present <- function(path) {
  file.exists(path) || dir.exists(path) ||
    freeze_transaction_path_is_symlink(path)
}

assert_no_active_freeze_transaction <- function(
    primary_lock = outcome_freeze_lock,
    legacy_lock = legacy_outcome_freeze_lock) {
  if (freeze_transaction_lock_marker_present(primary_lock) ||
      freeze_transaction_lock_marker_present(legacy_lock)) {
    stop_o("Outcome freeze verification is blocked by an active transaction.")
  }
  invisible(TRUE)
}

verify_outputs <- function(components, allow_active_transaction = FALSE) {
  if (!isTRUE(allow_active_transaction)) {
    assert_no_active_freeze_transaction()
  }
  required <- unlist(paths[c(
    "code", "functions", "inputs", "roots", "contract", "scales",
    "trial_desc", "validation", "pointer", "output_manifest", "gate"
  )])
  if (any(!vapply(required, regular_file, logical(1)))) {
    stop_o("Outcome freeze output bundle is incomplete.")
  }
  contract <- stable_rds(paths$contract)$value
  code <- stable_tsv(paths$code)$value
  functions <- stable_tsv(paths$functions)$value
  inputs <- stable_tsv(paths$inputs)$value
  roots <- stable_tsv(paths$roots)$value
  scales <- stable_tsv(paths$scales)$value
  trial_desc <- stable_tsv(paths$trial_desc)$value
  validation <- stable_tsv(paths$validation)$value
  pointer <- stable_tsv(paths$pointer)$value
  manifest <- stable_tsv(paths$output_manifest)$value
  rehash_manifest(transform(
    manifest, status = validation_status
  )[, c("asset_id", "path_alias", "bytes", "sha256", "access", "status")],
  "outcome output manifest")
  trial_equal <- identical(
    sha256_file(paths$trial_desc),
    serialized_tsv_sha256(
      trial_desc_tsv_payload(components$measurement$trial_desc)
    )
  )
  if (!identical(contract$contract_version,
                 "v45_1_charls_outcome_execution") ||
      any(unlist(contract$governance) != 0L) ||
      !same_table(code, components$code, "asset_id") ||
      !same_table(functions, components$functions, "asset_id") ||
      !same_table(inputs, components$inputs, "asset_id") ||
      !same_table(roots, components$roots, "root_id") ||
      !same_table(scales, components$measurement$scales, "scale_id") ||
      !trial_equal) {
    stop_o("Recorded outcome contract/manifests no longer verify.")
  }
  if (nrow(trial_desc) != 30L ||
      nrow(validation) < 10L || any(validation$status != "PASS") ||
      nrow(pointer) != 1L ||
      !identical(as.character(pointer$contract_sha256),
                 sha256_file(paths$contract))) {
    stop_o("Public no-coefficient outputs failed read-back.")
  }
  gate <- stable_yaml(paths$gate)$value
  if (!identical(as.character(gate$freeze$status), "PASS") ||
      !identical(as.character(gate$freeze$contract_sha256),
                 sha256_file(paths$contract)) ||
      !identical(as.character(gate$freeze$output_manifest_sha256),
                 sha256_file(paths$output_manifest)) ||
      !is_yes(gate$restricted_outcome_execution_allowed) ||
      !is_no(gate$new_coefficient_inspection_allowed)) {
    stop_o("Outcome execution gate failed.")
  }
  if (!identical(contract$production_mi_gate_sha256,
                 sha256_file(paths$production_gate)) ||
      !identical(contract$main_addendum_gate_sha256,
                 sha256_file(paths$main_gate))) {
    stop_o("A predecessor/main gate changed after freeze.")
  }
  invisible(TRUE)
}

freeze_transaction_context <- function(
    project_root = root, lock_path = outcome_freeze_lock) {
  project_root <- normalizePath(project_root, mustWork = TRUE)
  lock_parent <- normalizePath(dirname(lock_path), mustWork = TRUE)
  if (!identical(lock_parent, project_root) &&
      !startsWith(
        lock_parent, paste0(project_root, .Platform$file.sep)
      )) {
    stop_o("Outcome freeze lock escapes its transaction root.")
  }
  list(
    root = project_root,
    lock = file.path(lock_parent, basename(lock_path))
  )
}

freeze_transaction_host <- function() {
  host <- unname(Sys.info()[["nodename"]])
  if (length(host) != 1L || is.na(host) || !nzchar(host)) {
    stop_o("Cannot resolve outcome freeze transaction host.")
  }
  host
}

freeze_transaction_alias <- function(path, context) {
  parent <- normalizePath(dirname(path), mustWork = TRUE)
  if (!identical(parent, context$root) &&
      !startsWith(parent, paste0(context$root, .Platform$file.sep))) {
    stop_o("Outcome freeze transaction path escapes its root.")
  }
  sub(
    paste0("^", context$root, "/?"), "",
    file.path(parent, basename(path))
  )
}

freeze_transaction_path <- function(path_alias, context) {
  if (length(path_alias) != 1L || is.na(path_alias) ||
      !nzchar(path_alias) || startsWith(path_alias, "/") ||
      any(strsplit(path_alias, "/", fixed = TRUE)[[1L]] %in%
          c("", ".", ".."))) {
    stop_o("Unsafe outcome freeze transaction path alias.")
  }
  candidate <- file.path(context$root, path_alias)
  parent <- normalizePath(dirname(candidate), mustWork = TRUE)
  if (!identical(parent, context$root) &&
      !startsWith(parent, paste0(context$root, .Platform$file.sep))) {
    stop_o("Outcome freeze transaction path alias escapes its root.")
  }
  file.path(parent, basename(candidate))
}

freeze_transaction_owner_columns <- function() {
  c(
    "transaction_id", "pid", "host", "acquired_at_utc",
    "owner_token"
  )
}

freeze_transaction_journal_columns <- function() {
  c(
    "journal_version", "transaction_id", "phase", "promotion_index",
    "owner_pid", "owner_host", "owner_sha256", "asset_id",
    "destination_path_alias", "stage_path_alias", "expected_sha256",
    "original_state", "original_sha256", "promotion_order",
    "promoted", "gate_published_last"
  )
}

validate_freeze_transaction_owner <- function(
    owner, expected_transaction_id = NULL) {
  required <- freeze_transaction_owner_columns()
  if (!is.data.frame(owner) || !identical(names(owner), required) ||
      nrow(owner) != 1L ||
      anyNA(owner[required]) ||
      any(!nzchar(vapply(owner[required], as.character, character(1)))) ||
      !grepl(
        "^[A-Za-z0-9_-]+$",
        as.character(owner$transaction_id[[1L]])
      ) ||
      !grepl("^[0-9]+$", as.character(owner$pid[[1L]])) ||
      (!is.null(expected_transaction_id) &&
       !identical(
         as.character(owner$transaction_id[[1L]]),
         as.character(expected_transaction_id)
       )) ||
      !grepl(
        "^[0-9a-f]{64}$", as.character(owner$owner_token[[1L]])
      )) {
    stop_o("Outcome freeze transaction owner binding is invalid.")
  }
  owner$pid <- as.integer(owner$pid)
  owner
}

freeze_transaction_owner_alive <- function(owner) {
  owner <- validate_freeze_transaction_owner(owner)
  if (!identical(
        as.character(owner$host[[1L]]), freeze_transaction_host()
      )) {
    stop_o("Cannot recover an outcome freeze transaction from another host.")
  }
  isTRUE(tools::pskill(as.integer(owner$pid[[1L]]), signal = 0L))
}

validate_freeze_transaction_journal <- function(
    journal, context, final, owner = NULL) {
  required <- freeze_transaction_journal_columns()
  if (!is.data.frame(journal) || !identical(names(journal), required) ||
      nrow(journal) != length(final)) {
    stop_o("Outcome freeze transaction journal schema differs.")
  }
  invariant <- c(
    unique_asset_id = !anyDuplicated(journal$asset_id),
    one_journal_version = length(unique(journal$journal_version)) == 1L,
    exact_journal_version = identical(
      unique(as.character(journal$journal_version)),
      "v45_1_outcome_freeze_transaction_1"
    ),
    one_transaction_id = length(unique(journal$transaction_id)) == 1L,
    one_phase = length(unique(journal$phase)) == 1L,
    one_promotion_index = length(unique(journal$promotion_index)) == 1L,
    one_owner_pid = length(unique(journal$owner_pid)) == 1L,
    one_owner_host = length(unique(journal$owner_host)) == 1L,
    one_owner_sha256 = length(unique(journal$owner_sha256)) == 1L,
    valid_owner_sha256 = all(grepl(
      "^[0-9a-f]{64}$", journal$owner_sha256
    )),
    no_missing = !anyNA(journal),
    expected_sha256 = all(grepl(
      "^[0-9a-f]{64}$", journal$expected_sha256
    )),
    original_absent = all(journal$original_state == "ABSENT"),
    original_sha_absent = all(journal$original_sha256 == "<ABSENT>"),
    promotion_order = identical(
      as.integer(journal$promotion_order), seq_along(final)
    ),
    promoted_values = all(journal$promoted %in% c("yes", "no")),
    gate_last_flag = all(journal$gate_published_last == "yes"),
    exact_asset_order = identical(
      as.character(journal$asset_id), names(final)
    ),
    exact_destination_aliases = identical(
      as.character(journal$destination_path_alias),
      unname(vapply(
        final, freeze_transaction_alias, character(1), context
      ))
    ),
    gate_is_last = identical(
      tail(as.character(journal$asset_id), 1L), "gate"
    )
  )
  if (any(!invariant)) {
    stop_o(
      "Outcome freeze transaction journal invariants differ: ",
      paste(names(invariant)[!invariant], collapse = "|")
    )
  }
  phases <- c(
    "STAGED", "PROMOTING", "VERIFYING", "VERIFY_FAILED", "VERIFIED"
  )
  if (!unique(journal$phase) %in% phases) {
    stop_o("Outcome freeze transaction phase is invalid.")
  }
  phase <- unique(as.character(journal$phase))
  promotion_index <- unique(as.integer(journal$promotion_index))
  promoted_index <- which(journal$promoted == "yes")
  phase_consistent <- if (identical(phase, "STAGED")) {
    identical(promotion_index, 0L) && !length(promoted_index)
  } else if (identical(phase, "PROMOTING")) {
    length(promotion_index) == 1L &&
      promotion_index >= 1L && promotion_index <= length(final) &&
      all(promoted_index <= promotion_index) &&
      all(seq_len(max(0L, promotion_index - 1L)) %in% promoted_index)
  } else {
    identical(promotion_index, as.integer(length(final))) &&
      identical(promoted_index, seq_along(final))
  }
  if (!isTRUE(phase_consistent)) {
    stop_o("Outcome freeze transaction phase/progress differs.")
  }
  destination_paths <- vapply(
    journal$destination_path_alias,
    freeze_transaction_path, character(1), context
  )
  stage_paths <- vapply(
    journal$stage_path_alias,
    freeze_transaction_path, character(1), context
  )
  if (!identical(unname(destination_paths), unname(final)) ||
      anyDuplicated(stage_paths) ||
      any(!startsWith(
        stage_paths,
        paste0(context$lock, .Platform$file.sep, "staging",
               .Platform$file.sep)
      )) ||
      any(destination_paths == stage_paths)) {
    stop_o("Outcome freeze transaction journal paths are unsafe.")
  }
  if (!is.null(owner)) {
    owner <- validate_freeze_transaction_owner(
      owner, unique(as.character(journal$transaction_id))
    )
    if (!identical(
          as.character(owner$pid[[1L]]),
          as.character(unique(journal$owner_pid))
        ) ||
        !identical(
          as.character(owner$host[[1L]]),
          as.character(unique(journal$owner_host))
        )) {
      stop_o("Outcome freeze transaction journal owner differs.")
    }
  }
  journal$promotion_index <- as.integer(journal$promotion_index)
  journal$promotion_order <- as.integer(journal$promotion_order)
  journal
}

freeze_transaction_journal_path <- function(context) {
  file.path(context$lock, "journal.tsv")
}

write_freeze_transaction_journal <- function(journal, context) {
  path <- freeze_transaction_journal_path(context)
  v45_charls_atomic_write_tsv(journal, path)
  stable_tsv(path, "outcome freeze transaction journal")$value
}

resolve_freeze_transaction_lock <- function(
    context, transaction_id, disposition) {
  if (!dir.exists(context$lock) ||
      freeze_transaction_path_is_symlink(context$lock)) {
    stop_o("Outcome freeze transaction lock is absent or unsafe.")
  }
  resolved <- paste0(
    context$lock, ".resolved.", transaction_id, ".", disposition,
    ".pid", Sys.getpid()
  )
  if (file.exists(resolved) || dir.exists(resolved) ||
      !file.rename(context$lock, resolved)) {
    stop_o("Outcome freeze transaction lock could not be resolved.")
  }
  unlink(resolved, recursive = TRUE, force = TRUE)
  if (file.exists(resolved) || dir.exists(resolved)) {
    stop_o("Resolved outcome freeze transaction residue remains.")
  }
  invisible(TRUE)
}

rollback_freeze_transaction <- function(context, final) {
  if (!freeze_transaction_lock_marker_present(context$lock)) {
    return(invisible(TRUE))
  }
  if (!dir.exists(context$lock) ||
      freeze_transaction_path_is_symlink(context$lock)) {
    stop_o("Outcome freeze rollback lock marker is unsafe.")
  }
  owner_path <- file.path(context$lock, "owner.tsv")
  if (!regular_file(owner_path)) {
    stop_o("Outcome freeze transaction owner is absent; retain evidence.")
  }
  owner_sha <- sha256_file(owner_path)
  owner <- validate_freeze_transaction_owner(
    stable_tsv(owner_path, "outcome freeze transaction owner")$value
  )
  journal_path <- freeze_transaction_journal_path(context)
  if (!regular_file(journal_path)) {
    if (any(file.exists(final))) {
      stop_o("Owner-only outcome freeze lock has live destinations.")
    }
    resolve_freeze_transaction_lock(
      context, as.character(owner$transaction_id[[1L]]), "ROLLED_BACK"
    )
    return(invisible(TRUE))
  }
  journal <- validate_freeze_transaction_journal(
    stable_tsv(journal_path, "outcome freeze transaction journal")$value,
    context, final, owner
  )
  if (!identical(
        unique(as.character(journal$owner_sha256)), owner_sha
      ) ||
      identical(unique(as.character(journal$phase)), "VERIFIED")) {
    stop_o("Outcome freeze rollback owner or phase is unsafe.")
  }
  destinations <- vapply(
    journal$destination_path_alias,
    freeze_transaction_path, character(1), context
  )
  stages <- vapply(
    journal$stage_path_alias,
    freeze_transaction_path, character(1), context
  )
  destination_present <- file.exists(destinations)
  stage_present <- file.exists(stages)
  destination_hash <- rep(NA_character_, length(destinations))
  stage_hash <- rep(NA_character_, length(stages))
  destination_hash[destination_present] <- vapply(
    destinations[destination_present], sha256_file, character(1)
  )
  stage_hash[stage_present] <- vapply(
    stages[stage_present], sha256_file, character(1)
  )
  if (any(destination_present &
          (!vapply(destinations, regular_file, logical(1)) |
           is.na(destination_hash) |
           destination_hash != journal$expected_sha256)) ||
      any(stage_present &
          (!vapply(stages, regular_file, logical(1)) |
           is.na(stage_hash) |
           stage_hash != journal$expected_sha256))) {
    stop_o("Outcome freeze rollback hash ambiguity; retain evidence.")
  }
  for (path in destinations[destination_present]) unlink(path, force = TRUE)
  for (path in stages[stage_present]) unlink(path, force = TRUE)
  if (any(file.exists(c(destinations, stages)))) {
    stop_o("Outcome freeze rollback did not remove transaction assets.")
  }
  resolve_freeze_transaction_lock(
    context, unique(as.character(journal$transaction_id)), "ROLLED_BACK"
  )
  invisible(TRUE)
}

finalize_freeze_transaction <- function(context, final) {
  if (!freeze_transaction_lock_marker_present(context$lock)) {
    return(invisible(TRUE))
  }
  if (!dir.exists(context$lock) ||
      freeze_transaction_path_is_symlink(context$lock)) {
    stop_o("Outcome freeze finalize lock marker is unsafe.")
  }
  owner_path <- file.path(context$lock, "owner.tsv")
  journal_path <- freeze_transaction_journal_path(context)
  if (!regular_file(owner_path) || !regular_file(journal_path)) {
    stop_o("Verified outcome freeze transaction evidence is incomplete.")
  }
  owner_sha <- sha256_file(owner_path)
  owner <- validate_freeze_transaction_owner(
    stable_tsv(owner_path, "outcome freeze transaction owner")$value
  )
  journal <- validate_freeze_transaction_journal(
    stable_tsv(journal_path, "outcome freeze transaction journal")$value,
    context, final, owner
  )
  destinations <- vapply(
    journal$destination_path_alias,
    freeze_transaction_path, character(1), context
  )
  if (!identical(unique(as.character(journal$phase)), "VERIFIED") ||
      !identical(unique(as.character(journal$owner_sha256)), owner_sha) ||
      any(!vapply(destinations, regular_file, logical(1))) ||
      any(vapply(destinations, sha256_file, character(1)) !=
          journal$expected_sha256)) {
    stop_o("Verified outcome freeze transaction cannot be finalized.")
  }
  resolve_freeze_transaction_lock(
    context, unique(as.character(journal$transaction_id)), "FINALIZED"
  )
  invisible(TRUE)
}

recover_provisional_freeze_locks <- function(context) {
  pattern <- paste0(
    "^", gsub("\\.", "\\\\.", basename(context$lock)),
    "\\..*\\.acquiring$"
  )
  candidates <- list.files(
    dirname(context$lock), pattern = pattern, all.files = TRUE,
    full.names = TRUE
  )
  for (candidate in candidates) {
    if (!dir.exists(candidate) ||
        freeze_transaction_path_is_symlink(candidate)) {
      stop_o("Provisional outcome freeze lock is unsafe.")
    }
    owner_path <- file.path(candidate, "owner.tsv")
    if (!regular_file(owner_path) ||
        regular_file(file.path(candidate, "journal.tsv"))) {
      stop_o("Provisional outcome freeze lock is ambiguous.")
    }
    owner <- validate_freeze_transaction_owner(
      stable_tsv(owner_path, "provisional outcome freeze owner")$value
    )
    if (freeze_transaction_owner_alive(owner)) {
      stop_o("Another outcome freezer is acquiring the lock.")
    }
    unlink(candidate, recursive = TRUE, force = TRUE)
    if (dir.exists(candidate) || file.exists(candidate)) {
      stop_o("Dead provisional outcome freeze lock remains.")
    }
  }
  invisible(TRUE)
}

recover_stale_freeze_transaction <- function(context, final) {
  recover_provisional_freeze_locks(context)
  if (!freeze_transaction_lock_marker_present(context$lock)) {
    return(invisible("NONE"))
  }
  if (!dir.exists(context$lock) ||
      freeze_transaction_path_is_symlink(context$lock)) {
    stop_o("Outcome freeze transaction lock marker is unsafe.")
  }
  owner_path <- file.path(context$lock, "owner.tsv")
  if (!regular_file(owner_path)) {
    stop_o("Outcome freeze transaction owner is missing; retain evidence.")
  }
  owner <- validate_freeze_transaction_owner(
    stable_tsv(owner_path, "outcome freeze transaction owner")$value
  )
  if (freeze_transaction_owner_alive(owner)) {
    stop_o("Another outcome freezer holds the lock.")
  }
  journal_path <- freeze_transaction_journal_path(context)
  if (!regular_file(journal_path)) {
    rollback_freeze_transaction(context, final)
    return(invisible("ROLLED_BACK_OWNER_ONLY"))
  }
  journal <- validate_freeze_transaction_journal(
    stable_tsv(journal_path, "outcome freeze transaction journal")$value,
    context, final, owner
  )
  if (identical(unique(as.character(journal$phase)), "VERIFIED")) {
    finalize_freeze_transaction(context, final)
    return(invisible("FINALIZED"))
  }
  rollback_freeze_transaction(context, final)
  invisible("ROLLED_BACK")
}

acquire_freeze_transaction <- function(context, final, transaction_id) {
  recover_stale_freeze_transaction(context, final)
  if (any(file.exists(final))) {
    stop_o("Outcome freeze outputs already exist; use --verify.")
  }
  provisional <- paste0(context$lock, ".", transaction_id, ".acquiring")
  if (!dir.create(provisional, showWarnings = FALSE)) {
    stop_o("Cannot create provisional outcome freeze lock.")
  }
  acquired <- FALSE
  returned <- FALSE
  on.exit(
    if (!returned) {
      if (!acquired && dir.exists(provisional)) {
        unlink(provisional, recursive = TRUE, force = TRUE)
      }
      if (acquired &&
          freeze_transaction_lock_marker_present(context$lock)) {
        if (!dir.exists(context$lock) ||
            freeze_transaction_path_is_symlink(context$lock)) {
          stop_o("Acquired outcome freeze lock marker became unsafe.")
        }
        owner_path <- file.path(context$lock, "owner.tsv")
        journal_path <- freeze_transaction_journal_path(context)
        if (regular_file(owner_path) && !regular_file(journal_path) &&
            !any(file.exists(final))) {
          owner_now <- validate_freeze_transaction_owner(
            stable_tsv(owner_path)$value, transaction_id
          )
          resolve_freeze_transaction_lock(
            context,
            as.character(owner_now$transaction_id[[1L]]),
            "ACQUISITION_ABORT"
          )
        }
      }
    },
    add = TRUE
  )
  acquired_at <- format(
    Sys.time(), "%Y-%m-%dT%H:%M:%SZ", tz = "UTC"
  )
  owner <- data.frame(
    transaction_id = transaction_id,
    pid = as.integer(Sys.getpid()),
    host = freeze_transaction_host(),
    acquired_at_utc = acquired_at,
    owner_token = digest::digest(
      paste(
        transaction_id, Sys.getpid(), freeze_transaction_host(),
        acquired_at, sep = "\u241f"
      ),
      algo = "sha256", serialize = FALSE
    ),
    stringsAsFactors = FALSE
  )
  owner_path <- file.path(provisional, "owner.tsv")
  v45_charls_atomic_write_tsv(owner, owner_path)
  validate_freeze_transaction_owner(
    stable_tsv(owner_path, "provisional outcome freeze owner")$value,
    transaction_id
  )
  if (!file.rename(provisional, context$lock)) {
    stop_o("Another outcome freezer won the transaction lock.")
  }
  acquired <- TRUE
  owner_path <- file.path(context$lock, "owner.tsv")
  owner_sha <- sha256_file(owner_path)
  staging_dir <- file.path(context$lock, "staging")
  if (!dir.create(staging_dir, showWarnings = FALSE)) {
    stop_o("Cannot create outcome freeze transaction staging directory.")
  }
  staging <- setNames(
    file.path(staging_dir, basename(final)), names(final)
  )
  out <- list(
    context = context, final = final, staging = staging,
    transaction_id = transaction_id, owner = owner,
    owner_sha256 = owner_sha
  )
  returned <- TRUE
  out
}

record_staged_freeze_transaction <- function(transaction) {
  final <- transaction$final
  staging <- transaction$staging
  if (any(file.exists(final)) ||
      any(!vapply(staging, regular_file, logical(1)))) {
    stop_o("Outcome freeze transaction staging is incomplete.")
  }
  expected <- vapply(staging, sha256_file, character(1))
  journal <- data.frame(
    journal_version = "v45_1_outcome_freeze_transaction_1",
    transaction_id = transaction$transaction_id,
    phase = "STAGED",
    promotion_index = 0L,
    owner_pid = as.integer(transaction$owner$pid[[1L]]),
    owner_host = as.character(transaction$owner$host[[1L]]),
    owner_sha256 = transaction$owner_sha256,
    asset_id = names(final),
    destination_path_alias = vapply(
      final, freeze_transaction_alias, character(1),
      transaction$context
    ),
    stage_path_alias = vapply(
      staging, freeze_transaction_alias, character(1),
      transaction$context
    ),
    expected_sha256 = expected,
    original_state = "ABSENT",
    original_sha256 = "<ABSENT>",
    promotion_order = seq_along(final),
    promoted = "no",
    gate_published_last = "yes",
    stringsAsFactors = FALSE
  )
  journal <- write_freeze_transaction_journal(
    journal, transaction$context
  )
  validate_freeze_transaction_journal(
    journal, transaction$context, final, transaction$owner
  )
}

update_freeze_transaction_journal <- function(
    journal, transaction, phase, promotion_index,
    promoted_index = integer()) {
  journal$phase <- phase
  journal$promotion_index <- as.integer(promotion_index)
  if (length(promoted_index)) {
    journal$promoted[as.integer(promoted_index)] <- "yes"
  }
  journal <- write_freeze_transaction_journal(
    journal, transaction$context
  )
  validate_freeze_transaction_journal(
    journal, transaction$context, transaction$final, transaction$owner
  )
}

promote_freeze_transaction <- function(
    transaction, journal, verify_fun,
    inject_fault_after_rename = NA_integer_) {
  for (i in seq_along(transaction$final)) {
    journal <- update_freeze_transaction_journal(
      journal, transaction, "PROMOTING", i
    )
    expected <- journal$expected_sha256[[i]]
    if (!file.rename(
          transaction$staging[[i]], transaction$final[[i]]
        )) {
      stop_o("Outcome freeze promotion failed.")
    }
    if (!is.na(inject_fault_after_rename) &&
        identical(as.integer(i), as.integer(inject_fault_after_rename))) {
      stop_o("Injected outcome freeze promotion fault.")
    }
    if (!identical(sha256_file(transaction$final[[i]]), expected)) {
      stop_o("Outcome freeze promoted asset hash differs.")
    }
    journal <- update_freeze_transaction_journal(
      journal, transaction, "PROMOTING", i, promoted_index = i
    )
  }
  journal <- update_freeze_transaction_journal(
    journal, transaction, "VERIFYING", length(transaction$final)
  )
  verification_error <- NULL
  tryCatch(
    verify_fun(),
    error = function(e) verification_error <<- e
  )
  if (!is.null(verification_error)) {
    journal <- update_freeze_transaction_journal(
      journal, transaction, "VERIFY_FAILED", length(transaction$final)
    )
    stop_o(conditionMessage(verification_error))
  }
  update_freeze_transaction_journal(
    journal, transaction, "VERIFIED", length(transaction$final)
  )
}

synthetic_freeze_transaction_case <- function(test_mode) {
  test_mode <- match.arg(
    test_mode,
    c(
      "promotion_fault", "verify_failure", "success",
      "dead_owner_verifying", "dead_owner_verified",
      "owner_tamper", "owner_missing"
    )
  )
  base <- tempfile(paste0("charls_v45_1_freeze_", test_mode, "_"))
  dir.create(base, recursive = TRUE, showWarnings = FALSE)
  base <- normalizePath(base, mustWork = TRUE)
  on.exit(
    if (dir.exists(base)) unlink(base, recursive = TRUE, force = TRUE),
    add = TRUE
  )
  for (directory in c("restricted", "public", "work")) {
    dir.create(file.path(base, directory), showWarnings = FALSE)
  }
  context <- freeze_transaction_context(
    base, file.path(base, "restricted", ".synthetic_freeze.lock")
  )
  final <- c(
    asset_a = file.path(base, "public", "asset_a.tsv"),
    asset_b = file.path(base, "work", "asset_b.tsv"),
    gate = file.path(base, "work", "gate.yml")
  )
  transaction_id <- paste0("synthetic_", test_mode, "_pid", Sys.getpid())
  transaction <- acquire_freeze_transaction(
    context, final, transaction_id
  )
  for (i in seq_along(transaction$staging)) {
    v45_charls_atomic_write_lines(
      paste0(names(transaction$staging)[[i]], "\t", i),
      transaction$staging[[i]]
    )
  }
  journal <- record_staged_freeze_transaction(transaction)
  run_current <- function(mode) {
    committed <- FALSE
    on.exit({
      if (freeze_transaction_lock_marker_present(context$lock)) {
        if (committed) {
          finalize_freeze_transaction(context, final)
        } else {
          rollback_freeze_transaction(context, final)
        }
      }
    }, add = TRUE)
    if (identical(mode, "promotion_fault")) {
      promote_freeze_transaction(
        transaction, journal, verify_fun = function() invisible(TRUE),
        inject_fault_after_rename = 1L
      )
    } else if (identical(mode, "verify_failure")) {
      promote_freeze_transaction(
        transaction, journal,
        verify_fun = function() stop_o("synthetic verify failure")
      )
    } else {
      final_journal <- promote_freeze_transaction(
        transaction, journal,
        verify_fun = function() {
          if (any(!vapply(final, regular_file, logical(1)))) {
            stop_o("synthetic final bundle is incomplete")
          }
          invisible(TRUE)
        }
      )
      if (!identical(unique(final_journal$phase), "VERIFIED")) {
        stop_o("Synthetic transaction did not verify.")
      }
      committed <- TRUE
      finalize_freeze_transaction(context, final)
    }
    invisible(TRUE)
  }
  if (test_mode %in% c("promotion_fault", "verify_failure", "success")) {
    value <- try(run_current(test_mode), silent = TRUE)
    expected_error <- !identical(test_mode, "success")
    return(
      identical(inherits(value, "try-error"), expected_error) &&
        !dir.exists(context$lock) &&
        if (expected_error) {
          !any(file.exists(final))
        } else {
          all(vapply(final, regular_file, logical(1)))
        }
    )
  }
  for (i in seq_along(final)) {
    if (!file.rename(transaction$staging[[i]], final[[i]]) ||
        !identical(sha256_file(final[[i]]),
                   journal$expected_sha256[[i]])) {
      stop_o("Synthetic stale transaction promotion failed.")
    }
  }
  journal$promoted <- "yes"
  journal$promotion_index <- length(final)
  journal$phase <- if (identical(test_mode, "dead_owner_verified")) {
    "VERIFIED"
  } else {
    "VERIFYING"
  }
  owner_path <- file.path(context$lock, "owner.tsv")
  owner <- stable_tsv(owner_path)$value
  if (identical(test_mode, "owner_missing")) {
    unlink(owner_path, force = TRUE)
    blocked <- inherits(
      try(recover_stale_freeze_transaction(context, final), silent = TRUE),
      "try-error"
    )
    return(blocked && dir.exists(context$lock))
  }
  owner$pid <- 999999L
  owner$owner_token <- digest::digest(
    paste0(transaction_id, "\u241fdead-owner"),
    algo = "sha256", serialize = FALSE
  )
  v45_charls_atomic_write_tsv(owner, owner_path)
  if (!identical(test_mode, "owner_tamper")) {
    journal$owner_pid <- 999999L
    journal$owner_sha256 <- sha256_file(owner_path)
  }
  v45_charls_atomic_write_tsv(
    journal, freeze_transaction_journal_path(context)
  )
  if (identical(test_mode, "owner_tamper")) {
    blocked <- inherits(
      try(recover_stale_freeze_transaction(context, final), silent = TRUE),
      "try-error"
    )
    return(blocked && dir.exists(context$lock) && all(file.exists(final)))
  }
  recovered <- recover_stale_freeze_transaction(context, final)
  if (identical(test_mode, "dead_owner_verified")) {
    identical(recovered, "FINALIZED") &&
      !dir.exists(context$lock) && all(file.exists(final))
  } else {
    identical(recovered, "ROLLED_BACK") &&
      !dir.exists(context$lock) && !any(file.exists(final))
  }
}

synthetic_active_transaction_guard <- function() {
  base <- tempfile("charls_v45_1_active_guard_")
  dir.create(base, recursive = TRUE, showWarnings = FALSE)
  base <- normalizePath(base, mustWork = TRUE)
  on.exit(unlink(base, recursive = TRUE, force = TRUE), add = TRUE)
  primary <- file.path(base, ".primary.lock")
  legacy <- file.path(base, ".legacy.lock")
  dir.create(primary, showWarnings = FALSE)
  directory_blocked <- inherits(
    try(
      assert_no_active_freeze_transaction(primary, legacy),
      silent = TRUE
    ),
    "try-error"
  )
  unlink(primary, recursive = TRUE, force = TRUE)
  file.create(primary)
  file_blocked <- inherits(
    try(
      assert_no_active_freeze_transaction(primary, legacy),
      silent = TRUE
    ),
    "try-error"
  )
  unlink(primary, force = TRUE)
  symlink_created <- file.symlink(
    file.path(base, "absent_target"), primary
  )
  symlink_blocked <- isTRUE(symlink_created) && inherits(
    try(
      assert_no_active_freeze_transaction(primary, legacy),
      silent = TRUE
    ),
    "try-error"
  )
  unlink(primary, force = TRUE)
  allowed <- isTRUE(assert_no_active_freeze_transaction(primary, legacy))
  directory_blocked && file_blocked && symlink_blocked && allowed
}

mode <- if ("--self-test" %in% commandArgs(trailingOnly = TRUE)) {
  "self_test"
} else if ("--verify" %in% commandArgs(trailingOnly = TRUE)) {
  "verify"
} else "freeze"

if (mode == "self_test") {
  components <- build_components(require_mi = FALSE, freeze_id = "SELF_TEST")
  trial_payload <- trial_desc_tsv_payload(
    components$measurement$trial_desc
  )
  mutated_trial_payload <- trial_payload
  mutated_trial_payload$value[[1L]] <- paste0(
    mutated_trial_payload$value[[1L]], "0"
  )
  serialization_ok <- is.character(trial_payload$value) &&
    nrow(trial_payload) == 30L &&
    identical(
      serialized_tsv_sha256(trial_payload),
      serialized_tsv_sha256(trial_payload)
    ) &&
    !identical(
      serialized_tsv_sha256(trial_payload),
      serialized_tsv_sha256(mutated_trial_payload)
    )
  transaction_cases <- c(
    "promotion_fault", "verify_failure", "success",
    "dead_owner_verifying", "dead_owner_verified",
    "owner_tamper", "owner_missing"
  )
  transaction_ok <- vapply(
    transaction_cases, synthetic_freeze_transaction_case, logical(1)
  )
  active_transaction_guard_ok <- synthetic_active_transaction_guard()
  formula_rows <- components$semantics$formula_hashes
  trial_contrast_ids <- components$registries$model$analysis_id[
    components$registries$model$row_type == "paired_contrast" &
      components$registries$model$formula_id == "F_TRIAL_L100_A1"
  ]
  trial_formula_rows <- formula_rows[
    formula_rows$analysis_id %in% trial_contrast_ids, , drop = FALSE
  ]
  adjacent_formula_row <- formula_rows[
    formula_rows$analysis_id == "v45_c_adjacent_delta", , drop = FALSE
  ]
  if (!serialization_ok || any(!transaction_ok) ||
      !active_transaction_guard_ok ||
      nrow(trial_formula_rows) != 3L ||
      any(trial_formula_rows$component_count != 2L) ||
      any(grepl(
        "\\bbeta_",
        trial_formula_rows$component_formula_serialization
      )) ||
      nrow(adjacent_formula_row) != 1L ||
      adjacent_formula_row$component_count[[1L]] != 1L ||
      grepl(
        "\\bbeta_",
        adjacent_formula_row$component_formula_serialization[[1L]]
      )) {
    stop_o(
      "Formula-component self-test failed for trial/adjacent contrasts."
    )
  }
  message(
    "CHARLS V45.1 OUTCOME FREEZER SELF-TEST PASS; models=28; thresholds=12; ",
    "anchors=75; crosswalk=18; scale_anchors=6; trial_desc_rows=30; ",
    "exact_trial_TSV_rehash=PASS; freeze_transaction_tests=8/8; ",
    "actual_matrices=3; trial_component_sets=3x2; ",
    "adjacent_component_sets=1x1; response/outcome fits=0; outputs_written=0."
  )
} else if (mode == "verify") {
  assert_no_active_freeze_transaction()
  components <- build_components(require_mi = TRUE, freeze_id = "VERIFY")
  # Freeze IDs are intentionally ignored when comparing recomputed sidecars.
  components$measurement$scales$freeze_id <-
    stable_tsv(paths$scales)$value$freeze_id
  components$measurement$trial_desc$freeze_id <-
    stable_tsv(paths$trial_desc)$value$freeze_id
  verify_outputs(components)
  message("CHARLS V45.1 OUTCOME FREEZE VERIFY PASS")
} else {
  run_outcome_freeze <- function() {
    final <- unlist(paths[c(
      "code", "functions", "inputs", "roots", "contract", "scales",
      "trial_desc", "validation", "pointer", "output_manifest", "gate"
    )])
    if (!identical(tail(names(final), 1L), "gate")) {
      stop_o("Outcome freeze gate is not last in promotion order.")
    }
    if (freeze_transaction_lock_marker_present(
          legacy_outcome_freeze_lock
        )) {
      stop_o("A legacy outcome freeze lock needs audit.")
    }
    freeze_id <- paste0(
      "charls_v45_1_outcome_freeze_",
      format(Sys.time(), "%Y%m%dT%H%M%S"), "_pid", Sys.getpid()
    )
    context <- freeze_transaction_context()
    transaction <- acquire_freeze_transaction(
      context, final, freeze_id
    )
    committed <- FALSE
    on.exit({
      if (dir.exists(context$lock)) {
        if (committed) {
          finalize_freeze_transaction(context, final)
        } else {
          rollback_freeze_transaction(context, final)
        }
      }
    }, add = TRUE)
    production_gate_before <- sha256_file(paths$production_gate)
    main_gate_before <- sha256_file(paths$main_gate)
    components <- build_components(require_mi = TRUE, freeze_id = freeze_id)
    frozen_at <- format(Sys.time(), "%Y-%m-%dT%H:%M:%SZ", tz = "UTC")
    contract <- make_contract(components, freeze_id, frozen_at)
    stage <- as.list(transaction$staging)
    v45_charls_atomic_write_tsv(components$code, stage$code)
    v45_charls_atomic_write_tsv(components$functions, stage$functions)
    v45_charls_atomic_write_tsv(components$inputs, stage$inputs)
    v45_charls_atomic_write_tsv(components$roots, stage$roots)
    v45_charls_atomic_save_rds(contract, stage$contract)
    v45_charls_atomic_write_tsv(
      components$measurement$scales, stage$scales
    )
    v45_charls_atomic_write_tsv(
      trial_desc_tsv_payload(components$measurement$trial_desc),
      stage$trial_desc
    )
    validation <- data.frame(
      check_id = c(
        "production_MI_independent_validation",
        "six_final_authoring_contract_hashes",
        "model_threshold_anchor_crosswalk_schema",
        "immutable_inputs_rehashed",
        "three_actual_Rao_Wu_matrices",
        "three_structural_denominator_anchors",
        "I_raw_I_z_six_scale_anchors",
        "exact_v43_RCS_basis_hash",
        "exact_v43_W1_W2_drift_row",
        "formula_sample_mask_and_L_contracts",
        "restricted_join_hashes",
        "trial_descriptive_6_by_5",
        "zero_model_fit_or_coefficient_generation",
        "old_gates_unchanged_before_commit"
      ),
      status = "PASS",
      observed = c(
        "MI-C0|MI-C2 m50 independently validated",
        "6/6 exact SHA-256",
        "28|12|75|18",
        paste0(nrow(components$inputs), " bound inputs"),
        "TRIAL|ADJACENT|W2 actual 500-column matrices",
        "12235/1632/44456;8308/912/23154;8245/899/22984",
        "6 coefficient-blind aggregates",
        components$measurement$basis_value_sha256,
        "baseline_eligible_pairwise W1-W2 N=8283 PASS",
        "28 canonical component sets; 3 ordered paired-trial mappings",
        "W2 fixed fields|period skeleton|participant backbone",
        "30 aggregate cells; exact 17g-text TSV SHA; no response fields",
        "0", "production and main gate hashes unchanged"
      ),
      freeze_id = freeze_id, frozen_at_utc = frozen_at,
      stringsAsFactors = FALSE
    )
    v45_charls_atomic_write_tsv(validation, stage$validation)
    pointer <- data.frame(
      freeze_id = freeze_id,
      contract_path_alias = alias_of(paths$contract),
      contract_sha256 = sha256_file(stage$contract),
      roots_path_alias = alias_of(paths$roots),
      roots_sha256 = sha256_file(stage$roots),
      status = "OUTCOME_EXECUTION_FROZEN",
      stringsAsFactors = FALSE
    )
    v45_charls_atomic_write_tsv(pointer, stage$pointer)
    out_manifest <- output_manifest_from(stage)
    v45_charls_atomic_write_tsv(out_manifest, stage$output_manifest)
    gate <- list(
      gate_id = "charls_outcome_execution_v45_1",
      freeze_id = freeze_id, updated_at_utc = frozen_at,
      freeze = list(
        status = "PASS",
        contract_path_alias = alias_of(paths$contract),
        contract_sha256 = sha256_file(stage$contract),
        roots_path_alias = alias_of(paths$roots),
        roots_sha256 = sha256_file(stage$roots),
        pointer_path_alias = alias_of(paths$pointer),
        pointer_sha256 = sha256_file(stage$pointer),
        output_manifest_path_alias = alias_of(paths$output_manifest),
        output_manifest_sha256 = sha256_file(stage$output_manifest)
      ),
      restricted_outcome_execution_allowed = "yes",
      new_coefficient_inspection_allowed = "no",
      response_or_outcome_result_release_allowed = "no",
      main_v45_gate_modified = "no",
      next_authorized_step =
        "run_restricted_v44_anchor_then_coefficient_blind_prefix"
    )
    v45_charls_atomic_write_yaml(gate, stage$gate)
    if (!identical(
          production_gate_before, sha256_file(paths$production_gate)
        ) ||
        !identical(main_gate_before, sha256_file(paths$main_gate)) ||
        !identical(
          setNames(
            build_authoring_manifest()$sha256,
            build_authoring_manifest()$asset_id
          ),
          expected_contract_hashes
        )) {
      stop_o("A predecessor gate or final authoring contract changed.")
    }
    journal <- record_staged_freeze_transaction(transaction)
    journal <- promote_freeze_transaction(
      transaction, journal,
      verify_fun = function() {
        verify_components <- build_components(
          require_mi = TRUE, freeze_id = freeze_id
        )
        verify_outputs(
          verify_components, allow_active_transaction = TRUE
        )
      }
    )
    if (!identical(unique(as.character(journal$phase)), "VERIFIED")) {
      stop_o("Outcome freeze transaction did not reach VERIFIED.")
    }
    committed <- TRUE
    finalize_freeze_transaction(context, final)
    if (dir.exists(context$lock)) {
      stop_o("Outcome freeze transaction lock remains after finalization.")
    }
    invisible(freeze_id)
  }
  run_outcome_freeze()
  message(
    "CHARLS V45.1 OUTCOME FREEZE PASS; restricted execution opened; ",
    "coefficient inspection and result release remain closed."
  )
}
