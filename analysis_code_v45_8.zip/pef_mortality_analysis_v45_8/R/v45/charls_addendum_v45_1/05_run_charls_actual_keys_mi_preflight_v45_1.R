#!/usr/bin/env Rscript

options(stringsAsFactors = FALSE, warn = 1)

script_path <- sub(
  "^--file=", "",
  grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)[[1]]
)
root <- normalizePath(
  file.path(dirname(script_path), "..", "..", ".."),
  mustWork = TRUE
)
source(file.path(
  root,
  "R/v45/charls_addendum_v45_1/charls_structural_utilities_v45_1.R"
))
v45_charls_activate_project_library(root)
required_packages <- c("yaml", "digest", "mice", "survey", "dplyr")
if (!all(vapply(
  required_packages, requireNamespace, quietly = TRUE, FUN.VALUE = logical(1)
))) {
  stop("Required CHARLS actual-key/MI packages are unavailable.", call. = FALSE)
}
source(file.path(root, "R/v45/production_mi_hashes_v45.R"))
source(file.path(
  root,
  "R/v45/charls_addendum_v45_1/03_charls_actual_keys_mi_utilities_v45_1.R"
))

work_rel <- "work_v45/charls_addendum_v45_1"
result_rel <- "results/v45/charls_addendum_v45_1"
sensitive_rel <- "derived_sensitive/v45/charls_addendum_v45_1"
qa_rel <- "output/qa/v45/charls_addendum_v45_1"
log_rel <- "logs/v45/charls_addendum_v45_1"
freeze_script <- file.path(
  root,
  "R/v45/charls_addendum_v45_1/04_freeze_charls_actual_keys_mi_v45_1.R"
)

run_id <- paste0(
  "charls_v45_1_actual_keys_mi_",
  format(Sys.time(), "%Y%m%dT%H%M%S", tz = "UTC"),
  "_pid", Sys.getpid()
)
started_at <- format(Sys.time(), tz = "UTC", usetz = TRUE)

write_failure <- function(error) {
  history <- file.path(
    root, qa_rel, "freeze_history",
    paste0("actual_keys_mi_runtime_", run_id)
  )
  dir.create(history, recursive = TRUE, showWarnings = FALSE)
  lines <- c(
    paste0("run_id: ", run_id),
    "status: TECHNICAL_FAIL",
    paste0("error: ", conditionMessage(error)),
    "restricted_rows_opened: possible",
    "completed_data_persisted: false",
    "mids_persisted: false",
    "response_models_fit: 0",
    "outcome_models_fit: 0",
    "coefficients_exported: 0",
    paste0("failed_at_utc: ", format(Sys.time(), tz = "UTC", usetz = TRUE))
  )
  v45_charls_atomic_write_lines(lines, file.path(history, "failure.txt"))
}

main <- function() {
  freeze_check <- system2(
    file.path(R.home("bin"), "Rscript"),
    c("--vanilla", freeze_script, "--verify"),
    stdout = TRUE, stderr = TRUE
  )
  if (!is.null(attr(freeze_check, "status")) ||
      !any(grepl(
        "CHARLS ACTUAL-KEY/MI FREEZE VERIFY PASS",
        freeze_check, fixed = TRUE
      ))) {
    stop(
      "The CHARLS actual-key/MI freeze did not verify: ",
      paste(freeze_check, collapse = " | "), call. = FALSE
    )
  }
  spec <- yaml::read_yaml(file.path(
    root, work_rel, "charls_actual_keys_mi_spec_v45_1.yml"
  ))
  freeze_gate <- yaml::read_yaml(file.path(
    root, work_rel, "charls_actual_keys_mi_gate_state_v45_1.yml"
  ))
  freeze_roots <- utils::read.delim(
    file.path(
      root, work_rel, "charls_actual_keys_mi_freeze_roots_v45_1.tsv"
    ),
    stringsAsFactors = FALSE, check.names = FALSE
  )
  source_before <- v45_charls_actual_validate_source_files(root, spec)
  source <- v45_charls_actual_read_sources(root, spec)
  denominator <- v45_charls_actual_denominators(source)
  denominator_checks <- v45_charls_actual_assert_anchors(
    source, denominator, spec
  )
  master <- source$master
  period <- source$period

  trial_keys <- v45_charls_actual_key_map(
    master$community_id[denominator$complete_three],
    "RW-CHARLS-TRIAL-ACTUAL"
  )
  adjacent_keys <- v45_charls_actual_key_map(
    master$community_id,
    "RW-CHARLS-ADJACENT-ACTUAL"
  )
  w2_keys <- v45_charls_actual_key_map(
    master$community_id[denominator$w2_supported],
    "RW-CHARLS-W2-IPW-ACTUAL"
  )
  modules <- list(
    trial = v45_charls_actual_generate_subbootstrap(
      trial_keys, 450501L, "RW-CHARLS-TRIAL-ACTUAL"
    ),
    adjacent = v45_charls_actual_generate_subbootstrap(
      adjacent_keys, 450502L, "RW-CHARLS-ADJACENT-ACTUAL"
    ),
    w2 = v45_charls_actual_generate_subbootstrap(
      w2_keys, 450504L, "RW-CHARLS-W2-IPW-ACTUAL"
    )
  )
  matrix_audit <- do.call(
    rbind, lapply(modules, v45_charls_actual_matrix_audit)
  )
  synthetic <- readRDS(file.path(
    root, work_rel, "charls_structural_replicate_contract_v45_1.rds"
  ))
  synthetic_equivalence <- data.frame(
    matrix_id = vapply(modules, `[[`, character(1), "matrix_id"),
    exact_500_value_match = vapply(names(modules), function(name) {
      identical(
        unname(modules[[name]]$matrix),
        unname(synthetic$modules[[name]]$matrix)
      )
    }, logical(1)),
    exact_literal_250_value_match = vapply(names(modules), function(name) {
      identical(
        unname(modules[[name]]$matrix[, seq_len(250L), drop = FALSE]),
        unname(
          synthetic$modules[[name]]$matrix[, seq_len(250L), drop = FALSE]
        )
      )
    }, logical(1)),
    full_scale = vapply(modules, `[[`, numeric(1), "scale"),
    literal_250_scale = 1 / 249,
    status = "PASS",
    stringsAsFactors = FALSE
  )
  synthetic_equivalence$status <- ifelse(
    synthetic_equivalence$exact_500_value_match &
      synthetic_equivalence$exact_literal_250_value_match &
      synthetic_equivalence$full_scale == 1 / 499,
    "PASS", "FAIL"
  )
  if (any(matrix_audit$status != "PASS") ||
      any(synthetic_equivalence$status != "PASS")) {
    stop("The actual-key Rao–Wu multiplier contract failed.", call. = FALSE)
  }

  participant_map <- data.frame(
    participant_id = as.character(master$participant_id),
    community_id = as.character(master$community_id),
    base_weight = as.numeric(master$weight_biomarker_w1),
    trial_complete_three = denominator$complete_three,
    adjacent_participant =
      master$participant_id %in% denominator$adjacent_ids,
    w2_initial = denominator$w2_initial,
    D2_support = denominator$w2_supported,
    R_W2 = denominator$r_w2,
    stringsAsFactors = FALSE
  )
  period_key_map <- data.frame(
    participant_id = as.character(period$participant_id),
    community_id = as.character(period$community_id),
    start_wave = as.integer(period$start_wave),
    end_wave = as.integer(period$end_wave),
    nominal_years = as.numeric(period$nominal_years),
    adjacent_transition = denominator$adjacent_row,
    stringsAsFactors = FALSE
  )
  if (anyDuplicated(participant_map$participant_id) ||
      anyNA(participant_map$participant_id) ||
      anyNA(participant_map$community_id) ||
      any(!is.finite(participant_map$base_weight) |
            participant_map$base_weight <= 0) ||
      anyNA(period_key_map) ||
      any(period_key_map$end_wave <= period_key_map$start_wave) ||
      any(!is.finite(period_key_map$nominal_years) |
            period_key_map$nominal_years <= 0)) {
    stop("The restricted ID/weight/time mapping failed.", call. = FALSE)
  }

  authority <- v45_charls_actual_load_authority(root)
  v44_spec <- yaml::read_yaml(v45_charls_actual_paths(root)$v44_spec)
  mi_c0 <- v45_charls_actual_build_mi_c0(source, authority, v44_spec)
  mi_c2 <- v45_charls_actual_build_mi_c2(
    source, denominator, authority, v44_spec
  )
  object_contracts <- rbind(
    v45_charls_actual_object_contract(mi_c0),
    v45_charls_actual_object_contract(mi_c2)
  )
  missingness <- do.call(rbind, lapply(list(mi_c0, mi_c2), function(object) {
    data.frame(
      object_id = object$object_id,
      variable = names(object$mi_data),
      missing_n = vapply(
        object$mi_data, function(value) sum(is.na(value)), integer(1)
      ),
      method = unname(object$mi_spec$method[names(object$mi_data)]),
      is_target = nzchar(
        unname(object$mi_spec$method[names(object$mi_data)])
      ),
      stringsAsFactors = FALSE
    )
  }))
  dry_c0 <- v45_charls_actual_run_dry_pair(mi_c0, authority)
  dry_c2 <- v45_charls_actual_run_dry_pair(mi_c2, authority)
  dry_audit <- rbind(dry_c0$audit, dry_c2$audit)
  completion_audit <- rbind(dry_c0$completion, dry_c2$completion)
  if (any(object_contracts$status != "PASS") ||
      any(object_contracts$pef_imputation_target_n != 0L) ||
      any(dry_audit$status != "PASS") ||
      any(completion_audit$observed_value_change_n != 0L) ||
      any(completion_audit$smoking_conflict_n != 0L) ||
      any(completion_audit$bmi_identity_max_error > 1e-10) ||
      any(
        completion_audit$object_id == "MI-C2" &
          (
            !is.finite(completion_audit$age_w2_identity_max_error) |
              completion_audit$age_w2_identity_max_error > 1e-12
          )
      )) {
    stop("The MI-C0/MI-C2 structural dry-pair gate failed.", call. = FALSE)
  }

  denominator_summary <- data.frame(
    denominator_id = c(
      "trial_complete_three", "adjacent_only",
      "w2_initial", "w2_D2_supported"
    ),
    participants = c(
      sum(denominator$complete_three),
      length(denominator$adjacent_ids),
      sum(denominator$w2_initial),
      sum(denominator$w2_supported)
    ),
    period_rows = c(
      sum(period$participant_id %in%
            master$participant_id[denominator$complete_three]),
      sum(denominator$adjacent_row),
      sum(
        period$start_wave >= 2L &
          period$participant_id %in%
            master$participant_id[denominator$w2_initial]
      ),
      sum(
        period$start_wave >= 2L &
          period$participant_id %in%
            master$participant_id[denominator$w2_supported]
      )
    ),
    psu = c(
      length(unique(master$community_id[denominator$complete_three])),
      length(unique(
        period$community_id[denominator$adjacent_row]
      )),
      length(unique(master$community_id[denominator$w2_initial])),
      length(unique(master$community_id[denominator$w2_supported]))
    ),
    response_observed = c(
      NA_integer_, NA_integer_,
      sum(denominator$r_w2[denominator$w2_initial]),
      sum(denominator$r_w2[denominator$w2_supported])
    ),
    response_unobserved = c(
      NA_integer_, NA_integer_,
      sum(!denominator$r_w2[denominator$w2_initial]),
      sum(!denominator$r_w2[denominator$w2_supported])
    ),
    zero_response_psu = c(
      NA_integer_, NA_integer_,
      length(denominator$zero_response_keys), 0L
    ),
    status = "PASS",
    stringsAsFactors = FALSE
  )
  structural_checks <- data.frame(
    check_id = c(
      "restricted_sources_exact",
      "denominator_anchors",
      "actual_key_maps_unique",
      "actual_rao_wu_500_and_literal_250",
      "actual_matrices_match_frozen_synthetic_values",
      "id_weight_time_contract",
      "MI_C0_object_contract",
      "MI_C2_object_contract",
      "MI_C0_deterministic_m2_maxit2",
      "MI_C2_deterministic_m2_maxit2",
      "passive_BMI_and_W2_age_exact",
      "completed_data_and_mids_not_persisted",
      "response_outcome_pef_model_fit_count",
      "coefficient_export_count"
    ),
    status = "PASS",
    observed = c(
      "2/2 exact",
      paste0(nrow(denominator_checks), "/", nrow(denominator_checks)),
      "trial=433; adjacent_union=433; W2=420; one stratum",
      "three 500-column matrices; literal first 250 exact; scales 1/499 and 1/249",
      "3/3 exact raw-value matches",
      paste0(nrow(participant_map), " people; ", nrow(period_key_map), " periods"),
      paste0(object_contracts$n[object_contracts$object_id == "MI-C0"],
             " rows; seed 440401"),
      paste0(object_contracts$n[object_contracts$object_id == "MI-C2"],
             " rows; seed 450503; W2 PEF absent"),
      dry_audit$run_A_payload_sha256[dry_audit$object_id == "MI-C0"],
      dry_audit$run_A_payload_sha256[dry_audit$object_id == "MI-C2"],
      paste0("max BMI error=", max(completion_audit$bmi_identity_max_error),
             "; max W2-age error=0"),
      "0",
      "0",
      "0"
    ),
    expected = c(
      "ledger and authorized two-field donor exact",
      "all frozen anchors exact",
      "actual keys sorted and unique; denominator mapping exact",
      "finite/nonnegative/balanced/omits PSU; prefix exact",
      "same seeded algorithm proven before production binding",
      "unique IDs; positive base weight; positive ordered time",
      "inherited WHO block; passive BMI; m50/m100 metadata",
      "D2-supported; R_W2 fixed; no PEF target; passive W2 age",
      "two exact from-scratch runs; warnings/logged events 0",
      "two exact from-scratch runs; warnings/logged events 0",
      "BMI <=1e-10; W2 age <=1e-12",
      "none",
      "none",
      "none"
    ),
    run_id = run_id,
    stringsAsFactors = FALSE
  )

  source_after <- v45_charls_actual_validate_source_files(root, spec)
  if (!identical(
    source_before[, c("source_id", "bytes", "sha256")],
    source_after[, c("source_id", "bytes", "sha256")]
  )) {
    stop("A restricted CHARLS source changed during execution.", call. = FALSE)
  }
  definitions <- list(
    MI_C0 = list(
      method = mi_c0$mi_spec$method,
      predictor_matrix = mi_c0$mi_spec$predictor_matrix,
      where = is.na(mi_c0$mi_data),
      visit_sequence = mi_c0$mi_spec$visit_sequence,
      missing_n = vapply(
        mi_c0$mi_data, function(value) sum(is.na(value)), integer(1)
      ),
      passive = mi_c0$passive,
      production = list(
        seed = 440401L, initial_m = 50L, maximum_m = 100L,
        checkpoints = c(20L, 40L, 80L), rhat_max = 1.05
      )
    ),
    MI_C2 = list(
      method = mi_c2$mi_spec$method,
      predictor_matrix = mi_c2$mi_spec$predictor_matrix,
      where = is.na(mi_c2$mi_data),
      visit_sequence = mi_c2$mi_spec$visit_sequence,
      missing_n = vapply(
        mi_c2$mi_data, function(value) sum(is.na(value)), integer(1)
      ),
      passive = mi_c2$passive,
      production = list(
        seed = 450503L, initial_m = 50L, maximum_m = 100L,
        checkpoints = c(20L, 40L, 80L), rhat_max = 1.05
      ),
      fixed_auxiliaries = mi_c2$mi_spec$w2_fixed_auxiliaries,
      W2_PEF_in_MICE = FALSE
    )
  )
  restricted_contract <- list(
    contract_version = "v45_1_actual_keys_mi_no_outcome",
    run_id = run_id,
    freeze_id = freeze_gate$freeze_id,
    freeze_roots = freeze_roots,
    source_hashes_before = source_before,
    source_hashes_after = source_after,
    actual_design_key_role = "production_bound_actual_CHARLS_community_keys",
    one_structural_stratum = TRUE,
    key_maps = list(
      trial = trial_keys, adjacent = adjacent_keys, w2 = w2_keys
    ),
    participant_denominator_map = participant_map,
    outcome_free_period_key_map = period_key_map,
    modules = modules,
    MI_object_contracts = object_contracts,
    MI_definitions = definitions,
    dry_pair_audit = dry_audit,
    completion_aggregate_audit = completion_audit,
    completed_data_persisted = FALSE,
    mids_persisted = FALSE,
    response_model_fit_count = 0L,
    outcome_model_fit_count = 0L,
    pef_model_fit_count = 0L,
    coefficient_export_count = 0L,
    outcome_execution_allowed = FALSE,
    new_coefficient_inspection_allowed = FALSE
  )
  rm(mi_c0, mi_c2)
  invisible(gc(verbose = FALSE))

  output_objects <- list(
    "results/v45/charls_addendum_v45_1/charls_actual_denominator_contracts_v45_1.tsv" =
      denominator_summary,
    "results/v45/charls_addendum_v45_1/charls_actual_denominator_anchor_validation_v45_1.tsv" =
      denominator_checks,
    "results/v45/charls_addendum_v45_1/charls_actual_rao_wu_matrix_contracts_v45_1.tsv" =
      matrix_audit,
    "results/v45/charls_addendum_v45_1/charls_actual_synthetic_equivalence_v45_1.tsv" =
      synthetic_equivalence,
    "results/v45/charls_addendum_v45_1/charls_mi_object_contracts_v45_1.tsv" =
      object_contracts,
    "results/v45/charls_addendum_v45_1/charls_mi_missingness_contracts_v45_1.tsv" =
      missingness,
    "results/v45/charls_addendum_v45_1/charls_mi_dry_pair_validation_v45_1.tsv" =
      dry_audit,
    "results/v45/charls_addendum_v45_1/charls_mi_completion_aggregate_validation_v45_1.tsv" =
      completion_audit,
    "results/v45/charls_addendum_v45_1/charls_actual_keys_mi_structural_preflight_v45_1.tsv" =
      structural_checks
  )
  qa_lines <- c(
    "# CHARLS v45.1 actual design-key and MI-object preflight",
    "",
    paste0("Run ID: ", run_id),
    paste0("Started: ", started_at),
    "",
    "## Decision",
    "",
    "Actual community keys are now bound to the three prospectively seeded Rao–Wu matrices. MI-C0 and MI-C2 each passed two deterministic m=2/maxit=2 structural runs with zero warnings and zero logged events.",
    "",
    "This gate fitted no W2-response, PEF, or mortality model and exported no coefficient. Completed datasets and mids objects were not persisted.",
    "",
    "## Denominators",
    "",
    paste(capture.output(print(denominator_summary, row.names = FALSE)), collapse = "\n"),
    "",
    "## MI objects",
    "",
    paste(capture.output(print(object_contracts, row.names = FALSE)), collapse = "\n"),
    "",
    "## Hard checks",
    "",
    paste(capture.output(print(structural_checks, row.names = FALSE)), collapse = "\n"),
    "",
    "Passing this runner is not sufficient for production MI. An independent validator must reconstruct the source masks, matrices, object hashes, and dry pairs without trusting these PASS fields. Outcome execution remains disabled."
  )
  qa_path_rel <- paste0(
    qa_rel, "/CHARLS_ACTUAL_KEYS_MI_PREFLIGHT_QA_v45_1.md"
  )
  contract_path_rel <- paste0(
    sensitive_rel, "/charls_actual_keys_mi_contract_v45_1.rds"
  )
  staging_parent <- file.path(root, sensitive_rel, ".staging")
  dir.create(staging_parent, recursive = TRUE, showWarnings = FALSE)
  staging <- tempfile("actual_keys_mi_", tmpdir = staging_parent)
  dir.create(staging, recursive = TRUE)
  on.exit(if (dir.exists(staging)) {
    unlink(staging, recursive = TRUE, force = TRUE)
  }, add = TRUE)
  for (path in names(output_objects)) {
    v45_charls_atomic_write_tsv(
      output_objects[[path]], file.path(staging, path)
    )
  }
  v45_charls_atomic_save_rds(
    restricted_contract, file.path(staging, contract_path_rel)
  )
  v45_charls_atomic_write_lines(qa_lines, file.path(staging, qa_path_rel))
  manifest_paths <- c(names(output_objects), contract_path_rel, qa_path_rel)
  manifest <- data.frame(
    asset_id = sub("\\.[^.]+$", "", basename(manifest_paths)),
    path_alias = manifest_paths,
    bytes = vapply(
      file.path(staging, manifest_paths),
      function(path) as.numeric(file.info(path)$size),
      numeric(1)
    ),
    sha256 = vapply(
      file.path(staging, manifest_paths),
      v45_charls_sha256_file,
      character(1)
    ),
    access = c(
      rep("aggregate_no_identifiers", length(output_objects)),
      "restricted_identifiers_and_multiplier_matrices",
      "aggregate_no_identifiers"
    ),
    validation_status = "PASS",
    run_id = run_id,
    stringsAsFactors = FALSE
  )
  manifest_rel <- paste0(
    result_rel, "/charls_actual_keys_mi_output_manifest_v45_1.tsv"
  )
  v45_charls_atomic_write_tsv(manifest, file.path(staging, manifest_rel))
  promote <- c(manifest_paths, manifest_rel)
  if (any(file.exists(file.path(root, promote)))) {
    stop(
      "Refusing to replace an existing CHARLS actual-key/MI output bundle.",
      call. = FALSE
    )
  }
  for (relative in promote) {
    destination <- file.path(root, relative)
    dir.create(dirname(destination), recursive = TRUE, showWarnings = FALSE)
    if (!file.rename(file.path(staging, relative), destination)) {
      stop("Could not promote staged output: ", relative, call. = FALSE)
    }
  }
  unlink(staging, recursive = TRUE, force = TRUE)

  runner_gate <- list(
    gate_id = "charls_actual_keys_mi_v45_1",
    freeze_id = freeze_gate$freeze_id,
    run_id = run_id,
    updated_at_utc = format(Sys.time(), tz = "UTC", usetz = TRUE),
    freeze = list(status = "PASS"),
    actual_design_key_binding = list(status = "PASS_PENDING_INDEPENDENT"),
    mi_c0_structural_preflight = list(status = "PASS_PENDING_INDEPENDENT"),
    mi_c2_structural_preflight = list(status = "PASS_PENDING_INDEPENDENT"),
    independent_validation = list(status = "NOT_RUN"),
    charls_production_mi_allowed = "no",
    outcome_execution_allowed = "no",
    new_coefficient_inspection_allowed = "no",
    next_authorized_step = "independently_validate_actual_keys_and_MI_dry_pairs"
  )
  v45_charls_atomic_write_yaml(
    runner_gate,
    file.path(root, work_rel, "charls_actual_keys_mi_gate_state_v45_1.yml")
  )
  log_lines <- c(
    paste0("run_id: ", run_id),
    "actual_design_key_binding: PASS_PENDING_INDEPENDENT",
    "MI_C0_dry_pair: PASS",
    "MI_C2_dry_pair: PASS",
    "response_model_fit_count: 0",
    "outcome_model_fit_count: 0",
    "coefficient_export_count: 0",
    "completed_data_persisted: false",
    "mids_persisted: false"
  )
  v45_charls_atomic_write_lines(
    log_lines,
    file.path(root, log_rel, "charls_actual_keys_mi_preflight_run_v45_1.txt")
  )
  cat("CHARLS ACTUAL-KEY/MI STRUCTURAL RUNNER PASS_PENDING_INDEPENDENT\n")
}

tryCatch(
  main(),
  error = function(error) {
    write_failure(error)
    stop(error)
  }
)

