# Independent validation of the CHARLS v45.1 synthetic structural preflight.
#
# This validator never opens the CHARLS row-level ledger and never fits an
# actual response or outcome model.

options(stringsAsFactors = FALSE)

script_path <- sub(
  "^--file=", "",
  grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)[[1L]]
)
root <- normalizePath(
  file.path(dirname(script_path), "..", "..", ".."),
  mustWork = TRUE
)
source(file.path(
  root, "R", "v45", "charls_addendum_v45_1",
  "charls_structural_utilities_v45_1.R"
))
v45_charls_activate_project_library(root)
if (!all(vapply(
  c("digest", "yaml", "survey"),
  requireNamespace, quietly = TRUE, FUN.VALUE = logical(1)
))) {
  stop("The frozen digest, yaml, and survey packages are required.", call. = FALSE)
}
source(file.path(
  root, "R", "v45", "charls_addendum_v45_1",
  "charls_pure_functions_v45_1.R"
))

work_dir <- file.path(root, "work_v45", "charls_addendum_v45_1")
result_dir <- file.path(root, "results", "v45", "charls_addendum_v45_1")
qa_dir <- file.path(root, "output", "qa", "v45")
spec <- yaml::read_yaml(file.path(
  work_dir, "charls_pure_preflight_spec_v45_1.yml"
))
gate_path <- file.path(work_dir, "charls_addendum_gate_state_v45_1.yml")
gate <- yaml::read_yaml(gate_path)

input_paths <- c(
  code_manifest = file.path(
    work_dir, "charls_pure_preflight_code_manifest_v45_1.tsv"
  ),
  function_manifest = file.path(
    work_dir, "charls_pure_function_manifest_v45_1.tsv"
  ),
  freeze_roots = file.path(
    work_dir, "charls_pure_preflight_freeze_roots_v45_1.tsv"
  ),
  freeze_validation = file.path(
    result_dir, "charls_pure_preflight_freeze_validation_v45_1.tsv"
  ),
  matrix_contracts = file.path(
    result_dir, "charls_rao_wu_matrix_contracts_v45_1.tsv"
  ),
  structural = file.path(
    result_dir, "charls_structural_preflight_v45_1.tsv"
  ),
  interfaces = file.path(
    result_dir, "charls_synthetic_interface_validation_v45_1.tsv"
  ),
  w2_contract = file.path(
    result_dir, "charls_w2_structural_contract_validation_v45_1.tsv"
  ),
  contract = file.path(
    work_dir, "charls_structural_replicate_contract_v45_1.rds"
  ),
  run_log = file.path(
    work_dir, "charls_structural_preflight_run_log_v45_1.txt"
  )
)
output_paths <- c(
  validation = file.path(
    result_dir, "charls_structural_independent_validation_v45_1.tsv"
  ),
  qa = file.path(
    qa_dir, "V45_CHARLS_PURE_STRUCTURAL_PREFLIGHT_QA.md"
  ),
  manifest = file.path(
    result_dir, "charls_structural_output_manifest_v45_1.tsv"
  )
)
if (any(!file.exists(input_paths))) {
  stop(
    "Independent CHARLS validation inputs are incomplete: ",
    paste(input_paths[!file.exists(input_paths)], collapse = "; "),
    call. = FALSE
  )
}
if (any(file.exists(output_paths))) {
  stop("Independent CHARLS validation outputs already exist.",
       call. = FALSE)
}
if (!identical(gate$pure_function_freeze$status, "PASS") ||
    !identical(gate$structural_preflight$status, "PASS") ||
    !identical(gate$independent_validation$status, "NOT_RUN") ||
    isTRUE(gate$outcome_execution_allowed) ||
    isTRUE(gate$new_coefficient_inspection_allowed)) {
  stop("The isolated CHARLS addendum gate is not validation-ready.",
       call. = FALSE)
}

verify <- system2(
  file.path(R.home("bin"), "Rscript"),
  c(
    "--vanilla",
    file.path(
      root, "R", "v45", "charls_addendum_v45_1",
      "00_freeze_charls_pure_preflight_v45_1.R"
    ),
    "--verify"
  ),
  stdout = TRUE, stderr = TRUE
)
verify_status <- attr(verify, "status")
freeze_verifies <- is.null(verify_status) || verify_status == 0L

code_manifest <- utils::read.delim(
  input_paths[["code_manifest"]],
  stringsAsFactors = FALSE, check.names = FALSE
)
function_manifest <- utils::read.delim(
  input_paths[["function_manifest"]],
  stringsAsFactors = FALSE, check.names = FALSE
)
freeze_roots <- utils::read.delim(
  input_paths[["freeze_roots"]],
  stringsAsFactors = FALSE, check.names = FALSE
)
freeze_validation <- utils::read.delim(
  input_paths[["freeze_validation"]],
  stringsAsFactors = FALSE, check.names = FALSE
)
matrix_contracts <- utils::read.delim(
  input_paths[["matrix_contracts"]],
  stringsAsFactors = FALSE, check.names = FALSE
)
structural <- utils::read.delim(
  input_paths[["structural"]],
  stringsAsFactors = FALSE, check.names = FALSE
)
interfaces <- utils::read.delim(
  input_paths[["interfaces"]],
  stringsAsFactors = FALSE, check.names = FALSE
)
w2_contract <- utils::read.delim(
  input_paths[["w2_contract"]],
  stringsAsFactors = FALSE, check.names = FALSE
)
contract <- readRDS(input_paths[["contract"]])
run_log <- readLines(input_paths[["run_log"]], warn = FALSE)

checks <- list()
add_check <- function(check, pass, detail) {
  checks[[length(checks) + 1L]] <<- data.frame(
    check = check,
    status = if (isTRUE(pass)) "PASS" else "FAIL",
    detail = paste(detail, collapse = "; "),
    stringsAsFactors = FALSE
  )
}

add_check(
  "freeze_and_predecessor_closure_verify",
  freeze_verifies &&
    nrow(code_manifest) == 14L &&
    all(code_manifest$exists) &&
    all(code_manifest$immutable) &&
    nrow(function_manifest) == 11L &&
    all(function_manifest$status == "PASS") &&
    nrow(freeze_roots) == 6L &&
    all(freeze_validation$status == "PASS"),
  paste0(
    "freeze_exit=",
    if (freeze_verifies) 0L else verify_status,
    "; code=", nrow(code_manifest),
    "; functions=", nrow(function_manifest),
    "; roots=", nrow(freeze_roots)
  )
)

authority_map <- c(
  flow_measurement =
    spec$authority$flow_measurement$path,
  mortality_library =
    spec$authority$mortality_library$path,
  anthropometric_v44_1_1 =
    spec$authority$anthropometric_v44_1_1$path
)
function_exact <- vapply(seq_len(nrow(
  v45_charls_pure_provenance
)), function(i) {
  p <- v45_charls_pure_provenance[i, , drop = FALSE]
  authority_fun <- v45_charls_extract_top_function(
    file.path(root, authority_map[[p$authority_id]]),
    p$function_name
  )
  migrated_fun <- v45_charls_pure_library$authority_migrated[[
    p$function_name
  ]]
  identical(formals(authority_fun), formals(migrated_fun)) &&
    identical(body(authority_fun), body(migrated_fun)) &&
    identical(
      v45_charls_function_sha256(authority_fun),
      v45_charls_function_sha256(migrated_fun)
    )
}, logical(1))
add_check(
  "independent_pure_function_identity",
  all(function_exact),
  paste(
    v45_charls_pure_provenance$function_name,
    function_exact,
    collapse = "|"
  )
)

independent_generate <- function(psu_n, seed, matrix_id) {
  skeleton <- data.frame(
    psu_position = seq_len(psu_n),
    psu_key = factor(sprintf(
      "SYNTHETIC_PSU_%04d", seq_len(psu_n)
    )),
    structural_weight = 1,
    stringsAsFactors = FALSE
  )
  design <- survey::svydesign(
    ids = ~psu_key,
    weights = ~structural_weight,
    data = skeleton,
    nest = TRUE
  )
  RNGkind("Mersenne-Twister", "Inversion", "Rejection")
  set.seed(as.integer(seed))
  warnings <- character()
  replicate_design <- withCallingHandlers(
    survey::as.svrepdesign(
      design, type = "subbootstrap", replicates = 500L,
      mse = TRUE, compress = TRUE
    ),
    warning = function(w) {
      warnings <<- c(warnings, conditionMessage(w))
      invokeRestart("muffleWarning")
    }
  )
  matrix <- unclass(replicate_design$repweights$weights)
  rownames(matrix) <- as.character(skeleton$psu_key)
  colnames(matrix) <- sprintf("R%03d", seq_len(ncol(matrix)))
  list(
    matrix_id = matrix_id,
    seed = as.integer(seed),
    psu_n = as.integer(psu_n),
    skeleton = skeleton,
    matrix = matrix,
    index = as.integer(replicate_design$repweights$index),
    pweights = as.numeric(replicate_design$pweights),
    scale = as.numeric(replicate_design$scale),
    rscales = as.numeric(replicate_design$rscales),
    mse = isTRUE(replicate_design$mse),
    combined_weights =
      isTRUE(replicate_design$combined.weights),
    degf = as.integer(replicate_design$degf),
    warnings = unique(warnings)
  )
}

module_specs <- list(
  trial = spec$modules$trial,
  adjacent = spec$modules$adjacent,
  w2 = spec$modules$w2
)
regenerated <- lapply(module_specs, function(x) {
  independent_generate(
    as.integer(x$psu), as.integer(x$seed), x$matrix_id
  )
})
matrix_identity <- vapply(names(regenerated), function(name) {
  observed <- contract$modules[[name]]
  expected <- regenerated[[name]]
  identical(observed$matrix, expected$matrix) &&
    identical(observed$index, expected$index) &&
    identical(observed$pweights, expected$pweights) &&
    identical(observed$scale, 1 / 499) &&
    identical(observed$rscales, rep(1, 500L)) &&
    identical(observed$degf, observed$psu_n - 1L) &&
    !length(expected$warnings) &&
    identical(
      observed$matrix[, seq_len(250L), drop = FALSE],
      expected$matrix[, seq_len(250L), drop = FALSE]
    )
}, logical(1))
add_check(
  "independent_matrix_regeneration_and_prefix",
  all(matrix_identity),
  paste(names(matrix_identity), matrix_identity, collapse = "|")
)

matrix_rows_ok <- vapply(seq_len(nrow(matrix_contracts)), function(i) {
  row <- matrix_contracts[i, , drop = FALSE]
  module <- contract$modules[[row$module]]
  prefix <- module$matrix[, seq_len(250L), drop = FALSE]
  identical(v45_charls_matrix_sha256(module$matrix), row$matrix_sha256) &&
    identical(v45_charls_matrix_sha256(prefix), row$prefix_matrix_sha256) &&
    identical(
      v45_charls_object_sha256(unname(module$matrix)),
      row$multiplier_value_sha256
    ) &&
    identical(
      v45_charls_object_sha256(unname(prefix)),
      row$prefix_multiplier_value_sha256
    ) &&
    nrow(module$matrix) == as.integer(row$psu) &&
    ncol(module$matrix) == 500L &&
    all(is.finite(module$matrix) & module$matrix >= 0) &&
    max(abs(colSums(module$matrix) - nrow(module$matrix))) <= 1e-10 &&
    all(apply(module$matrix, 2L, function(x) any(x == 0)))
}, logical(1))
add_check(
  "restricted_structural_contract_integrity",
  identical(
    contract$design_key_role,
    "synthetic_ordinal_only_not_production_mapping"
  ) &&
    identical(contract$production_use_allowed, FALSE) &&
    identical(contract$actual_row_level_data_opened, FALSE) &&
    identical(
      contract$actual_response_or_outcome_values_opened,
      FALSE
    ) &&
    nrow(matrix_contracts) == 3L &&
    all(matrix_rows_ok) &&
    all(matrix_contracts$status == "PASS"),
  paste0(
    "modules=", nrow(matrix_contracts),
    "; exact_rows=", sum(matrix_rows_ok),
    "; production_use=", contract$production_use_allowed
  )
)

independent_make_design <- function(data, module, columns = 500L) {
  index <- match(
    as.character(data$psu_key),
    as.character(module$skeleton$psu_key)
  )
  repweights <- list(
    weights = module$matrix[, seq_len(columns), drop = FALSE],
    index = index
  )
  class(repweights) <- "repweights_compressed"
  out <- list(
    repweights = repweights,
    pweights = as.numeric(data$structural_weight),
    type = "subbootstrap",
    rho = 0,
    scale = if (columns == 500L) 1 / 499 else 1 / 249,
    rscales = rep(1, columns),
    call = match.call(),
    combined.weights = FALSE,
    selfrep = NULL,
    mse = TRUE,
    variables = data,
    degf = module$degf
  )
  class(out) <- "svyrep.design"
  out
}

independent_with_replicates <- function(design, theta) {
  warnings <- character()
  value <- withCallingHandlers(
    survey::withReplicates(
      design, theta = theta, return.replicates = TRUE
    ),
    warning = function(w) {
      warnings <<- c(warnings, conditionMessage(w))
      invokeRestart("muffleWarning")
    }
  )
  if (length(warnings)) {
    stop("Independent synthetic interface warned.", call. = FALSE)
  }
  value
}

trial_data <- regenerated$trial$skeleton
position <- trial_data$psu_position
trial_matrix <- cbind(
  trial1 = 280 + 0.9 * position + 18 * sin(position / 17),
  trial2 = 291 + 0.82 * position + 15 * cos(position / 23),
  trial3 = 286 + 0.86 * position +
    13 * sin(position / 31 + 0.4)
)
trial_data$pef_max <- apply(trial_matrix, 1L, max)
trial_data$pef_mean <- apply(trial_matrix, 1L, mean)
trial_data$pef_median <- apply(trial_matrix, 1L, stats::median)
trial_data$inconsistency <- log1p(apply(
  trial_matrix, 1L,
  function(x) {
    x <- sort(x, decreasing = TRUE)
    x[[1L]] - x[[2L]]
  }
))
trial_theta <- function(weight, data) {
  c(
    max = sum(weight * data$pef_max) / sum(weight),
    mean = sum(weight * data$pef_mean) / sum(weight),
    median = sum(weight * data$pef_median) / sum(weight),
    inconsistency =
      sum(weight * data$inconsistency) / sum(weight)
  )
}
trial_full <- independent_with_replicates(
  independent_make_design(trial_data, regenerated$trial, 500L),
  trial_theta
)
trial_prefix <- independent_with_replicates(
  independent_make_design(trial_data, regenerated$trial, 250L),
  trial_theta
)

adjacent_data <- regenerated$adjacent$skeleton
position <- adjacent_data$psu_position
adjacent_data$structural_weight <-
  0.75 + (position %% 19L) / 20
adjacent_data$synthetic_measure <-
  sin(position / 29) + log1p(position) / 20
adjacent_data$adjacent_domain <-
  adjacent_data$psu_position != max(adjacent_data$psu_position)
adjacent_theta <- function(weight, data) {
  keep <- data$adjacent_domain
  c(
    all = sum(weight * data$synthetic_measure) / sum(weight),
    adjacent = sum(
      weight[keep] * data$synthetic_measure[keep]
    ) / sum(weight[keep])
  )
}
adjacent_full <- independent_with_replicates(
  independent_make_design(
    adjacent_data, regenerated$adjacent, 500L
  ),
  adjacent_theta
)
adjacent_prefix <- independent_with_replicates(
  independent_make_design(
    adjacent_data, regenerated$adjacent, 250L
  ),
  adjacent_theta
)
centered <- sweep(
  as.matrix(adjacent_full$replicates),
  2L, as.numeric(stats::coef(adjacent_full)), FUN = "-"
)
adjacent_covariance <- (1 / 499) * crossprod(centered)
contrast <- c(-1, 1)
adjacent_delta <- adjacent_full$replicates[, 2L] -
  adjacent_full$replicates[, 1L]
adjacent_delta_point <- stats::coef(adjacent_full)[[2L]] -
  stats::coef(adjacent_full)[[1L]]
adjacent_delta_variance <- (1 / 499) * sum(
  (adjacent_delta - adjacent_delta_point)^2
)
adjacent_quadratic <- as.numeric(
  t(contrast) %*% adjacent_covariance %*% contrast
)

w2_key <- regenerated$w2$skeleton
w2_data <- w2_key[rep(seq_len(nrow(w2_key)), each = 2L), , drop = FALSE]
w2_data$within_psu_row <- rep(1:2, times = nrow(w2_key))
w2_data$structural_weight <-
  0.8 + (w2_data$psu_position %% 17L) / 20 +
  w2_data$within_psu_row / 40
w2_data$D2_support <- TRUE
w2_data$R2_synthetic <- as.integer(
  w2_data$psu_position > 12L &
    (w2_data$within_psu_row == 1L |
       w2_data$psu_position %% 3L != 0L)
)
w2_data$availability_factor_synthetic <-
  1 + (w2_data$psu_position %% 23L) / 50 +
  w2_data$within_psu_row / 100
w2_data$synthetic_measure <-
  cos(w2_data$psu_position / 37) +
  w2_data$within_psu_row / 10
manual_ess <- function(weight) sum(weight)^2 / sum(weight^2)
r2 <- w2_data$R2_synthetic == 1L
w2_manual_ratio <- manual_ess(
  w2_data$structural_weight[r2] *
    w2_data$availability_factor_synthetic[r2]
) / manual_ess(w2_data$structural_weight[r2])
w2_theta <- function(weight, data) {
  keep <- data$R2_synthetic == 1L
  c(
    respondent_mean = sum(
      weight[keep] * data$synthetic_measure[keep]
    ) / sum(weight[keep]),
    ess_ratio = manual_ess(
      weight[keep] * data$availability_factor_synthetic[keep]
    ) / manual_ess(weight[keep])
  )
}
w2_full <- independent_with_replicates(
  independent_make_design(w2_data, regenerated$w2, 500L),
  w2_theta
)
w2_prefix <- independent_with_replicates(
  independent_make_design(w2_data, regenerated$w2, 250L),
  w2_theta
)
zero_response_psu <- sum(vapply(
  split(w2_data$R2_synthetic, as.character(w2_data$psu_key)),
  function(x) !any(x == 1L), logical(1)
))

independent_interface_hashes <- data.frame(
  interface_id = c(
    "trial_summary_same_sample",
    "adjacent_shared_covariance",
    "w2_D2_ESS_structure"
  ),
  full_replicate_value_sha256 = c(
    v45_charls_object_sha256(unname(trial_full$replicates)),
    v45_charls_object_sha256(unname(adjacent_full$replicates)),
    v45_charls_object_sha256(unname(w2_full$replicates))
  ),
  prefix_replicate_value_sha256 = c(
    v45_charls_object_sha256(unname(trial_prefix$replicates)),
    v45_charls_object_sha256(unname(adjacent_prefix$replicates)),
    v45_charls_object_sha256(unname(w2_prefix$replicates))
  ),
  prefix_exact = c(
    identical(
      unname(trial_prefix$replicates),
      unname(trial_full$replicates[seq_len(250L), , drop = FALSE])
    ),
    identical(
      unname(adjacent_prefix$replicates),
      unname(adjacent_full$replicates[
        seq_len(250L), , drop = FALSE
      ])
    ),
    identical(
      unname(w2_prefix$replicates),
      unname(w2_full$replicates[seq_len(250L), , drop = FALSE])
    )
  ),
  stringsAsFactors = FALSE
)
joined_interfaces <- merge(
  interfaces,
  independent_interface_hashes,
  by = "interface_id",
  suffixes = c("_recorded", "_independent"),
  sort = TRUE
)
interface_exact <-
  nrow(joined_interfaces) == 3L &&
  all(
    joined_interfaces$full_replicate_value_sha256_recorded ==
      joined_interfaces$full_replicate_value_sha256_independent
  ) &&
  all(
    joined_interfaces$prefix_replicate_value_sha256_recorded ==
      joined_interfaces$prefix_replicate_value_sha256_independent
  ) &&
  all(joined_interfaces$prefix_exact) &&
  all(interfaces$status == "PASS")
add_check(
  "independent_synthetic_interface_reproduction",
  interface_exact,
  paste0(
    "interfaces=", nrow(joined_interfaces),
    "; exact_full=",
    sum(
      joined_interfaces$full_replicate_value_sha256_recorded ==
        joined_interfaces$full_replicate_value_sha256_independent
    ),
    "; exact_prefix=",
    sum(
      joined_interfaces$prefix_replicate_value_sha256_recorded ==
        joined_interfaces$prefix_replicate_value_sha256_independent
    )
  )
)

add_check(
  "adjacent_shared_covariance_identity",
  isTRUE(all.equal(
    unname(adjacent_covariance),
    unname(stats::vcov(adjacent_full)),
    tolerance = 1e-12,
    check.attributes = FALSE
  )) &&
    isTRUE(all.equal(
      adjacent_delta_variance,
      adjacent_quadratic,
      tolerance = 1e-12
    )) &&
    isTRUE(all.equal(
      adjacent_delta_variance,
      contract$adjacent_structure$delta_variance_direct,
      tolerance = 1e-12
    )),
  paste0(
    "direct=", sprintf("%.17g", adjacent_delta_variance),
    "; quadratic=", sprintf("%.17g", adjacent_quadratic)
  )
)

helper_ess <- v45_charls_pure_library$structural_helpers$
  same_respondent_ess_ratio(
    w2_data$structural_weight,
    w2_data$availability_factor_synthetic,
    w2_data$R2_synthetic
  )
add_check(
  "w2_structural_contract_independent",
  all(w2_data$D2_support) &&
    length(unique(w2_data$psu_key)) == 420L &&
    zero_response_psu == 12L &&
    isTRUE(all.equal(
      w2_manual_ratio, helper_ess$ratio, tolerance = 1e-15
    )) &&
    isTRUE(all.equal(
      w2_manual_ratio,
      contract$w2_structural$same_r2_ess_ratio_synthetic,
      tolerance = 1e-15
    )) &&
    all(w2_contract$status == "PASS") &&
    identical(
      contract$w2_structural$actual_response_model_fit_count,
      0L
    ) &&
    identical(
      contract$w2_structural$actual_outcome_model_fit_count,
      0L
    ),
  paste0(
    "supported_PSU=", length(unique(w2_data$psu_key)),
    "; zero_response_PSU=", zero_response_psu,
    "; ESS_ratio=", sprintf("%.17g", w2_manual_ratio)
  )
)

source_files <- file.path(root, code_manifest$path_alias[
  grepl("^R/v45/charls_addendum_v45_1/.*\\.R$",
        code_manifest$path_alias)
])
parse_ok <- vapply(source_files, function(path) {
  !inherits(try(parse(path), silent = TRUE), "try-error")
}, logical(1))
audit_source_files <- source_files[
  basename(source_files) !=
    "02_validate_charls_structural_preflight_v45_1.R"
]
source_text <- paste(
  unlist(lapply(audit_source_files, readLines, warn = FALSE)),
  collapse = "\n"
)
forbidden_data_patterns <- c(
  "charls_stage3_analysis_ledger_v43\\.rds",
  "charls_core_harmonized_provisional\\.rds",
  "person_period_skeleton",
  "period_event",
  "event_any",
  "died_w5",
  "iwstat_w[1-5]"
)
forbidden_fit_patterns <- c(
  "svyglm\\s*\\(",
  "coxph\\s*\\(",
  "Surv\\s*\\(",
  "(^|[^A-Za-z0-9_.])glm\\s*\\("
)
forbidden_hits <- c(
  data = sum(vapply(
    forbidden_data_patterns, grepl, logical(1),
    x = source_text, perl = TRUE
  )),
  fit = sum(vapply(
    forbidden_fit_patterns, grepl, logical(1),
    x = source_text, perl = TRUE
  ))
)
add_check(
  "static_no_outcome_and_sourceability_audit",
  all(parse_ok) &&
    all(forbidden_hits == 0L) &&
    any(grepl(
      "actual_row_level_data_opened: false",
      run_log, fixed = TRUE
    )) &&
    any(grepl(
      "actual_response_model_fit_count: 0",
      run_log, fixed = TRUE
    )) &&
    any(grepl(
      "actual_outcome_model_fit_count: 0",
      run_log, fixed = TRUE
    )),
  paste0(
    "parse=", sum(parse_ok), "/", length(parse_ok),
    "; forbidden_data_hits=", forbidden_hits[["data"]],
    "; forbidden_fit_hits=", forbidden_hits[["fit"]]
  )
)

current_main_hashes <- vapply(c(
  analysis_registry = file.path(
    root, "work_v45", "v45_analysis_registry.tsv"
  ),
  estimand_registry = file.path(
    root, "work_v45", "v45_estimand_registry.tsv"
  ),
  seed_ledger = file.path(
    root, "work_v45", "v45_seed_ledger.tsv"
  ),
  main_gate = file.path(
    root, "work_v45", "gate_state_v45.yml"
  )
), v45_charls_sha256_file, character(1))
add_check(
  "main_registries_seed_and_gate_unchanged_by_stage",
  identical(
    contract$main_file_hashes_before,
    contract$main_file_hashes_after
  ) &&
    identical(
      unname(contract$main_file_hashes_after),
      unname(current_main_hashes)
    ),
  paste(
    names(current_main_hashes),
    substr(current_main_hashes, 1L, 12L),
    collapse = "|"
  )
)

required_structural <- c(
  "same_seed_bitwise_regeneration",
  "all_three_matrices_structurally_valid",
  "literal_first_250_prefix_contract",
  "module_seeds_and_matrices_distinct",
  "adjacent_shared_replicate_covariance_and_pair_difference",
  "w2_D2_support_zero_response_and_same_R2_ESS_structure",
  "all_synthetic_interfaces_pass",
  "main_stage0_registries_seed_and_gate_unchanged",
  "no_actual_CHARLS_rows_or_outcomes_opened"
)
add_check(
  "execution_checks_complete",
  !anyDuplicated(structural$check) &&
    setequal(structural$check, required_structural) &&
    all(structural$status == "PASS"),
  paste0(
    "checks=", nrow(structural),
    "; failures=", sum(structural$status != "PASS"),
    "; missing=",
    paste(setdiff(required_structural, structural$check),
          collapse = "|")
  )
)

validation <- do.call(rbind, checks)
if (any(validation$status != "PASS")) {
  stop(
    "Independent CHARLS structural validation failed: ",
    paste(
      validation$check[validation$status != "PASS"],
      collapse = ", "
    ),
    call. = FALSE
  )
}

v45_charls_atomic_write_tsv(
  validation, output_paths[["validation"]]
)
qa_lines <- c(
  "# CHARLS v45.1 pure-function and structural-preflight QA",
  "",
  "## Outcome",
  "",
  paste0(
    "Independent validation passed ", nrow(validation),
    " checks. The migrated pure functions match their content-addressed ",
    "authority definitions exactly, and the three synthetic Rao–Wu ",
    "n−1 matrices reproduce bitwise."
  ),
  "",
  "## Proven structural contracts",
  "",
  "- trial: 433 × 500, seed 450501;",
  "- adjacent: 433 × 500, seed 450502, with within-replicate paired difference and shared covariance;",
  "- W2: 420 × 500, seed 450504;",
  "- every 250-column object is the literal first-250 prefix with scale 1/249; the 500-column scale is 1/499;",
  "- W2 D2-support schema, 12 synthetic zero-response PSUs, and the same-R2 Kish-ESS ratio were independently reproduced.",
  "",
  "## Boundary",
  "",
  paste(
    "No restricted CHARLS row was opened and no actual response, death,",
    "follow-up, propensity, observation weight, response model, or outcome",
    "model was used. The matrix row keys are ordinal synthetic placeholders,",
    "so production use remains forbidden until actual PSU keys are separately",
    "frozen and validated."
  ),
  "",
  "The main Stage 0 registries, seed ledger, and gate were not modified.",
  "Outcome execution and new coefficient inspection remain blocked.",
  "",
  "## Next authorized step",
  "",
  paste(
    "Freeze the actual CHARLS design-key bindings and the MI-C0/MI-C2",
    "object specifications under a new no-outcome gate."
  )
)
v45_charls_atomic_write_lines(qa_lines, output_paths[["qa"]])

manifest_targets <- c(
  input_paths,
  validation = output_paths[["validation"]],
  qa = output_paths[["qa"]]
)
manifest <- data.frame(
  asset_id = names(manifest_targets),
  path_alias = sub(
    paste0("^", root, "/"), "", unname(manifest_targets)
  ),
  bytes = as.numeric(file.info(unname(manifest_targets))$size),
  sha256 = vapply(
    unname(manifest_targets), v45_charls_sha256_file, character(1)
  ),
  validation_status = "PASS",
  stringsAsFactors = FALSE
)
v45_charls_atomic_write_tsv(
  manifest, output_paths[["manifest"]]
)

gate$updated_at_utc <- format(
  Sys.time(), "%Y-%m-%dT%H:%M:%SZ", tz = "UTC"
)
gate$independent_validation <- list(status = "PASS")
gate$actual_design_key_binding <- list(status = "NOT_RUN")
gate$outcome_execution_allowed <- FALSE
gate$new_coefficient_inspection_allowed <- FALSE
gate$next_authorized_step <-
  "freeze_actual_CHARLS_design_keys_and_MI_C0_MI_C2_without_outcomes"
v45_charls_atomic_write_yaml(gate, gate_path)

message(
  "CHARLS v45.1 pure/no-outcome structural validation PASS. ",
  "Actual design binding and all outcomes remain blocked."
)
