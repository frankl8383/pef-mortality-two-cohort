#!/usr/bin/env Rscript

# Run one isolated CHARLS v45.1 production m=50 MICE object.
# No outcome/response/PEF model is fitted and no completed data are saved.

options(stringsAsFactors = FALSE, warn = 2)

script_path <- sub(
  "^--file=", "",
  grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)[[1L]]
)
root <- normalizePath(
  file.path(dirname(script_path), "..", "..", ".."),
  mustWork = TRUE
)
source(file.path(
  root,
  "R/v45/charls_addendum_v45_1/charls_structural_utilities_v45_1.R"
))
v45_charls_activate_project_library(root)
required_packages <- c("digest", "dplyr", "mice", "yaml")
missing_packages <- required_packages[!vapply(
  required_packages, requireNamespace, logical(1), quietly = TRUE
)]
if (length(missing_packages) ||
    !identical(as.character(getRversion()), "4.5.1") ||
    !identical(as.character(utils::packageVersion("mice")), "3.19.0")) {
  stop("CHARLS production-MI runtime is incomplete or drifted.",
       call. = FALSE)
}
source(file.path(root, "R/v45/production_mi_hashes_v45.R"))
source(file.path(
  root,
  "R/v45/charls_addendum_v45_1/03_charls_actual_keys_mi_utilities_v45_1.R"
))
source(file.path(
  root,
  "R/v45/charls_addendum_v45_1/07_charls_production_mi_utilities_v45_1.R"
))

argument <- function(name) {
  value <- grep(
    paste0("^--", name, "="),
    commandArgs(trailingOnly = TRUE), value = TRUE
  )
  if (length(value) != 1L) {
    stop("Exactly one --", name, "=... argument is required.",
         call. = FALSE)
  }
  sub(paste0("^--", name, "="), "", value[[1L]])
}

execute <- function() {
object_id <- toupper(argument("object"))
m_value <- argument("m")
if (!object_id %in% c("MI-C0", "MI-C2")) {
  stop("--object must be exactly MI-C0 or MI-C2.", call. = FALSE)
}
if (!identical(m_value, "50")) {
  stop(
    "This frozen CHARLS runner authorizes only --m=50; m=100 remains blocked.",
    call. = FALSE
  )
}
requested_m <- 50L
m_label <- "m50"
paths <- v45_charls_prod_paths(root)
freeze_script <- file.path(
  root,
  "R/v45/charls_addendum_v45_1/08_freeze_charls_production_mi_v45_1.R"
)

verify_freeze <- function() {
  output <- system2(
    file.path(R.home("bin"), "Rscript"),
    c("--vanilla", freeze_script, "--verify"),
    stdout = TRUE, stderr = TRUE
  )
  status <- attr(output, "status")
  if ((!is.null(status) && status != 0L) ||
      !any(grepl(
        "CHARLS PRODUCTION-MI FREEZE VERIFY PASS",
        output, fixed = TRUE
      ))) {
    stop(
      "CHARLS production-MI freeze no longer verifies: ",
      paste(output, collapse = " | "), call. = FALSE
    )
  }
  invisible(TRUE)
}

run_id <- paste0(
  "charls_v45_1_", gsub("-", "_", tolower(object_id)),
  "_m50_", format(Sys.time(), "%Y%m%dT%H%M%S"), "_pid", Sys.getpid()
)
restricted_parent <- file.path(
  paths$restricted, "production_mi", object_id, m_label
)
result_parent <- file.path(
  paths$result, "production_mi", object_id, m_label
)
restricted_staging <- file.path(
  restricted_parent, paste0(".staging_", run_id)
)
result_staging <- file.path(
  result_parent, paste0(".staging_", run_id)
)
restricted_final <- file.path(restricted_parent, run_id)
result_final <- file.path(result_parent, run_id)
pointer <- file.path(
  paths$result, "production_mi",
  paste0(gsub("-", "_", object_id), "_m50_current.tsv")
)
pointer_staging <- file.path(
  dirname(pointer), paste0(".", basename(pointer), ".", run_id, ".staging")
)
failure_dir <- file.path(paths$result, "production_mi", "failures")
lock_parent <- file.path(paths$restricted, "production_mi")
lock <- file.path(lock_parent, ".charls_production_mi_execution.lock")
lock_owner <- file.path(lock, "owner.tsv")
transaction_record <- file.path(
  lock_parent, paste0(".transaction_", run_id, ".yml")
)
gate_backup <- file.path(
  lock_parent, paste0(".gate_before_", run_id, ".yml")
)
gate_staging <- file.path(
  dirname(paths$gate),
  paste0(".", basename(paths$gate), ".", run_id, ".staging")
)

dir.create(lock_parent, recursive = TRUE, showWarnings = FALSE)
if (!dir.create(lock, showWarnings = FALSE)) {
  stop("Another CHARLS production-MI process holds the execution lock.",
       call. = FALSE)
}
lock_value <- data.frame(
  run_id = run_id, pid = Sys.getpid(), object_id = object_id,
  acquired_at_utc =
    format(Sys.time(), "%Y-%m-%dT%H:%M:%SZ", tz = "UTC"),
  stringsAsFactors = FALSE
)
v45_charls_atomic_write_tsv(lock_value, lock_owner)
lock_owner_sha <- v45_charls_sha256_file(lock_owner)

transaction_committed <- FALSE
failure_recorded <- FALSE
execution_started <- FALSE
checkpoint_for_failure <- NULL
error_for_failure <- NULL
pointer_written_sha <- NA_character_
success_gate_sha <- NA_character_
committed_mids_sha <- NA_character_
committed_run_output_sha <- NA_character_
gate_path <- paths$gate
gate_sha_start <- NA_character_
gate_start_object <- NULL

record_failure <- function(error, checkpoint = NULL) {
  dir.create(failure_dir, recursive = TRUE, showWarnings = FALSE)
  failure <- data.frame(
    run_id = run_id,
    object_id = object_id,
    requested_m = requested_m,
    status = "FAIL_NO_MIDS_SAVED",
    error_class = paste(class(error), collapse = "|"),
    error_message = paste(
      strsplit(conditionMessage(error), "[\r\n]+")[[1L]],
      collapse = " "
    ),
    checkpoint_rows = if (is.null(checkpoint)) 0L else nrow(checkpoint),
    failed_at_utc =
      format(Sys.time(), "%Y-%m-%dT%H:%M:%SZ", tz = "UTC"),
    stringsAsFactors = FALSE
  )
  v45_charls_atomic_write_tsv(
    failure, file.path(failure_dir, paste0(run_id, "_failure.tsv"))
  )
  if (!is.null(checkpoint) && nrow(checkpoint)) {
    v45_charls_atomic_write_tsv(
      checkpoint,
      file.path(failure_dir, paste0(run_id, "_checkpoint.tsv"))
    )
  }
  current_sha <- v45_charls_sha256_file(gate_path)
  if (!identical(current_sha, gate_sha_start)) {
    stop(
      "Cannot record failure because the isolated gate did not roll back.",
      call. = FALSE
    )
  }
  failed_gate <- yaml::read_yaml(gate_path)
  if (is.null(failed_gate$charls_production_mi_execution$objects)) {
    failed_gate$charls_production_mi_execution$objects <- list()
  }
  failed_gate$charls_production_mi_execution$objects[[object_id]] <- list(
    status = "FAIL_NO_MIDS_SAVED", run_id = run_id
  )
  failed_gate$charls_production_mi_execution$status <- "FAILED"
  failed_gate$outcome_execution_allowed <- "no"
  failed_gate$new_coefficient_inspection_allowed <- "no"
  failed_gate$next_authorized_step <- paste0(
    "review_CHARLS_production_MI_failure_", gsub("-", "_", object_id)
  )
  failed_gate$updated_at_utc <-
    format(Sys.time(), "%Y-%m-%dT%H:%M:%SZ", tz = "UTC")
  v45_charls_atomic_write_yaml(failed_gate, gate_path)
  failure_recorded <<- TRUE
  invisible(failure)
}

on.exit({
  if (execution_started && !transaction_committed && !failure_recorded) {
    fallback <- if (inherits(error_for_failure, "condition")) {
      error_for_failure
    } else {
      simpleError("Unhandled CHARLS production-MI failure.")
    }
    try(record_failure(fallback, checkpoint_for_failure), silent = TRUE)
  }
  if (dir.exists(restricted_staging)) {
    unlink(restricted_staging, recursive = TRUE, force = TRUE)
  }
  if (dir.exists(result_staging)) {
    unlink(result_staging, recursive = TRUE, force = TRUE)
  }
  if (!transaction_committed) {
    if (dir.exists(restricted_final)) {
      unlink(restricted_final, recursive = TRUE, force = TRUE)
    }
    if (dir.exists(result_final)) {
      unlink(result_final, recursive = TRUE, force = TRUE)
    }
    if (file.exists(pointer) &&
        grepl("^[0-9a-f]{64}$", pointer_written_sha) &&
        identical(v45_charls_sha256_file(pointer), pointer_written_sha)) {
      unlink(pointer, force = TRUE)
    }
  }
  if (file.exists(transaction_record)) {
    unlink(transaction_record, force = TRUE)
  }
  if (dir.exists(lock) &&
      identical(v45_charls_sha256_file(lock_owner), lock_owner_sha)) {
    unlink(lock, recursive = TRUE, force = TRUE)
  }
}, add = TRUE)

verify_freeze()
gate_sha_start <- v45_charls_sha256_file(gate_path)
gate <- yaml::read_yaml(gate_path)
execution_objects <- gate$charls_production_mi_execution$objects
state_ok <- if (object_id == "MI-C0") {
  identical(
    as.character(gate$charls_production_mi_execution$status), "NOT_RUN"
  ) && length(execution_objects) == 0L
} else {
  identical(
    as.character(gate$charls_production_mi_execution$status), "IN_PROGRESS"
  ) &&
    is.list(execution_objects) &&
    identical(names(execution_objects), "MI-C0") &&
    identical(
      as.character(execution_objects[["MI-C0"]]$status),
      "GENERATED_AWAITING_INDEPENDENT_VALIDATION"
    )
}
if (!identical(as.character(gate$freeze$status), "PASS") ||
    !v45_charls_prod_is_yes(gate$charls_production_mi_authorized) ||
    !identical(
      as.character(
        gate$charls_production_mi_independent_validation$status
      ),
      "NOT_RUN"
    ) ||
    !state_ok ||
    !v45_charls_prod_is_no(gate$outcome_execution_allowed) ||
    !v45_charls_prod_is_no(gate$new_coefficient_inspection_allowed)) {
  stop("The isolated CHARLS gate does not authorize this state transition.",
       call. = FALSE)
}
pointer_contract_ok <- function(id, gate_value, pointer_override = NULL) {
  expected_gate <-
    gate_value$charls_production_mi_execution$objects[[id]]
  token <- gsub("-", "_", id)
  current_path <- if (is.null(pointer_override)) {
    file.path(
      paths$result, "production_mi",
      paste0(token, "_m50_current.tsv")
    )
  } else {
    pointer_override
  }
  if (is.null(expected_gate) ||
      !v45_charls_prod_regular_file(current_path)) {
    return(FALSE)
  }
  current <- tryCatch(
    v45_charls_prod_read_tsv_stable(current_path),
    error = function(error) NULL
  )
  required <- c(
    "object_id", "requested_m", "run_id", "run_manifest_path_alias",
    "run_output_manifest_path_alias", "run_output_manifest_sha256",
    "mids_path_alias", "mids_sha256", "status"
  )
  if (is.null(current) || nrow(current) != 1L ||
      !identical(names(current), required) ||
      !identical(as.character(current$object_id), id) ||
      !identical(as.integer(current$requested_m), 50L) ||
      !identical(as.character(current$run_id),
                 as.character(expected_gate$run_id)) ||
      !identical(as.character(current$mids_sha256),
                 as.character(expected_gate$mids_sha256)) ||
      !identical(
        as.character(current$run_output_manifest_sha256),
        as.character(expected_gate$run_output_manifest_sha256)
      ) ||
      !identical(
        as.character(current$status),
        "GENERATED_AWAITING_INDEPENDENT_VALIDATION"
      )) {
    return(FALSE)
  }
  expected_result_alias <- file.path(
    "results/v45/charls_addendum_v45_1/production_mi",
    id, "m50", as.character(expected_gate$run_id)
  )
  expected_mids_alias <- file.path(
    "derived_sensitive/v45/charls_addendum_v45_1/production_mi",
    id, "m50", as.character(expected_gate$run_id),
    paste0(id, "_m50.mids.rds")
  )
  expected_result_dir <- file.path(root, expected_result_alias)
  expected_mids_path <- file.path(root, expected_mids_alias)
  expected_result_files <- c(
    "run_manifest.tsv", "component_hashes.tsv",
    "structural_checks.tsv", "checkpoint_diagnostics.tsv",
    "final_convergence.tsv", "released_chain_trace.tsv",
    "completion_chain_audit.tsv", "completion_summary.tsv",
    "run.log", "run_output_manifest.tsv"
  )
  result_files <- if (dir.exists(expected_result_dir)) {
    list.files(
      expected_result_dir, all.files = TRUE, no.. = TRUE,
      full.names = TRUE
    )
  } else {
    character()
  }
  mids_files <- if (dir.exists(dirname(expected_mids_path))) {
    list.files(
      dirname(expected_mids_path), all.files = TRUE, no.. = TRUE,
      full.names = TRUE
    )
  } else {
    character()
  }
  run_output <- tryCatch(
    v45_charls_prod_read_tsv_stable(file.path(
      expected_result_dir, "run_output_manifest.tsv"
    )),
    error = function(error) NULL
  )
  run_output_ok <- !is.null(run_output) &&
    nrow(run_output) == 10L &&
    !anyDuplicated(run_output$asset_id) &&
    setequal(
      run_output$asset_id,
      c(
        "mids", "run_manifest", "component_hashes",
        "structural_checks", "checkpoint_diagnostics",
        "final_convergence", "released_chain_trace",
        "completion_chain_audit", "completion_summary", "run_log"
      )
    ) &&
    all(vapply(seq_len(nrow(run_output)), function(index) {
      asset_id <- as.character(run_output$asset_id[[index]])
      asset_path <- file.path(
        root, as.character(run_output$path_alias[[index]])
      )
      expected_alias <- if (asset_id == "mids") {
        expected_mids_alias
      } else {
        file.path(
          expected_result_alias,
          switch(
            asset_id,
            run_manifest = "run_manifest.tsv",
            component_hashes = "component_hashes.tsv",
            structural_checks = "structural_checks.tsv",
            checkpoint_diagnostics = "checkpoint_diagnostics.tsv",
            final_convergence = "final_convergence.tsv",
            released_chain_trace = "released_chain_trace.tsv",
            completion_chain_audit = "completion_chain_audit.tsv",
            completion_summary = "completion_summary.tsv",
            run_log = "run.log"
          )
        )
      }
      identical(
        as.character(run_output$path_alias[[index]]),
        expected_alias
      ) &&
        v45_charls_prod_regular_file(asset_path) &&
        identical(
          as.numeric(file.info(asset_path)$size),
          as.numeric(run_output$bytes[[index]])
        ) &&
        identical(
          v45_charls_sha256_file(asset_path),
          as.character(run_output$sha256[[index]])
        )
    }, logical(1)))
  identical(
    as.character(current$run_manifest_path_alias),
    file.path(expected_result_alias, "run_manifest.tsv")
  ) &&
    identical(
      as.character(current$run_output_manifest_path_alias),
      file.path(expected_result_alias, "run_output_manifest.tsv")
    ) &&
    identical(as.character(current$mids_path_alias), expected_mids_alias) &&
    length(result_files) == length(expected_result_files) &&
    setequal(basename(result_files), expected_result_files) &&
    all(vapply(
      result_files, v45_charls_prod_regular_file, logical(1)
    )) &&
    length(mids_files) == 1L &&
    identical(mids_files, expected_mids_path) &&
    v45_charls_prod_regular_file(expected_mids_path) &&
    run_output_ok &&
    identical(
      v45_charls_sha256_file(file.path(
        root, as.character(current$run_output_manifest_path_alias)
      )),
      as.character(current$run_output_manifest_sha256)
    ) &&
    identical(
      v45_charls_sha256_file(expected_mids_path),
      as.character(current$mids_sha256)
    )
}
if (object_id == "MI-C2" &&
    !pointer_contract_ok("MI-C0", gate)) {
  stop(
    "MI-C2 requires a fully bound, current MI-C0 production object.",
    call. = FALSE
  )
}
stale_transactions <- list.files(
  lock_parent, pattern = "^\\.transaction_.*\\.yml$",
  all.files = TRUE, full.names = TRUE
)
if (length(stale_transactions)) {
  stop(
    "An interrupted CHARLS production transaction requires audit: ",
    paste(basename(stale_transactions), collapse = ", "), call. = FALSE
  )
}
existing_restricted <- if (dir.exists(restricted_parent)) {
  list.files(
    restricted_parent, all.files = TRUE, no.. = TRUE,
    full.names = TRUE
  )
} else {
  character()
}
existing_results <- if (dir.exists(result_parent)) {
  list.files(
    result_parent, all.files = TRUE, no.. = TRUE,
    full.names = TRUE
  )
} else {
  character()
}
if (file.exists(pointer) || length(existing_restricted) ||
    length(existing_results)) {
  stop("A current, staged, or orphaned CHARLS production object exists.",
       call. = FALSE)
}
dir.create(restricted_staging, recursive = TRUE, showWarnings = FALSE)
dir.create(result_staging, recursive = TRUE, showWarnings = FALSE)
execution_started <- TRUE

log_lines <- c(
  paste0("run_id: ", run_id),
  paste0("object_id: ", object_id),
  "requested_m: 50",
  paste0(
    "started_at_utc: ",
    format(Sys.time(), "%Y-%m-%dT%H:%M:%SZ", tz = "UTC")
  ),
  "outcome_model_fit_count: 0",
  "response_model_fit_count: 0",
  "pef_model_fit_count: 0",
  "coefficient_export_count: 0",
  "completed_dataset_persistence_count: 0"
)
append_log <- function(...) {
  line <- paste0(...)
  log_lines <<- c(
    log_lines, paste0(format(Sys.time(), "%H:%M:%S"), " ", line)
  )
  message(line)
}

main <- function() {
  input_contract <- v45_charls_prod_read_rds_stable(file.path(
    paths$restricted, "charls_production_mi_input_contract_v45_1.rds"
  ))
  if (!identical(input_contract$R_version, as.character(getRversion())) ||
      !identical(
        unname(input_contract$RNGkind),
        c("Mersenne-Twister", "Inversion", "Rejection")
      )) {
    stop("Frozen CHARLS production runtime contract is invalid.",
         call. = FALSE)
  }
  RNGkind(
    kind = "Mersenne-Twister",
    normal.kind = "Inversion",
    sample.kind = "Rejection"
  )
  if (!identical(
    RNGkind(), c("Mersenne-Twister", "Inversion", "Rejection")
  )) {
    stop("Could not establish the frozen CHARLS RNGkind.", call. = FALSE)
  }

  append_log("Reconstructing the frozen CHARLS object.")
  built <- v45_charls_prod_build_objects(root)
  object <- built$objects[[object_id]]
  authority <- built$authority
  expected <- input_contract$objects[[object_id]]
  if (is.null(expected)) {
    stop("Frozen CHARLS object contract is absent.", call. = FALSE)
  }
  current <- v45_charls_prod_object_contract(object)
  contract_fields <- c(
    "object_id", "denominator_n", "input_column_n", "column_names",
    "column_contract_sha256", "canonical_data_sha256",
    "missing_contract_sha256", "ordered_participant_id_sha256",
    "specification", "specification_sha256",
    "method_sha256", "predictor_sha256",
    "where_sha256", "where_values_equal_raw_missingness",
    "where_dimnames_equal_input", "visit_sha256", "missingness_sha256",
    "passive_sha256", "seed", "initial_m", "maximum_m",
    "convergence_checkpoints", "convergence_rhat_max",
    "active_targets", "active_target_n", "pef_imputation_target_n",
    "bmi_method", "bmi_predictor_row_zero",
    "bmi_predictor_column_zero", "bmi_placeholder_all_zero",
    "height_derived_terms_absent_from_mice",
    "passive_age_W2_absent_from_mice", "height_method", "weight_method",
    "R_W2_method", "R_W2_where_zero", "R_W2_predictor_row_zero",
    "R_W2_predicts_active", "fixed_W1_PEF_methods_zero",
    "fixed_W1_PEF_where_zero", "W2_PEF_column_n"
  )
  equal <- vapply(contract_fields, function(field) {
    identical(current[[field]], expected[[field]])
  }, logical(1))
  if (!all(equal) || !identical(current$initial_m, requested_m) ||
      current$pef_imputation_target_n != 0L) {
    stop(
      "Frozen CHARLS input contract mismatch: ",
      paste(contract_fields[!equal], collapse = ", "), call. = FALSE
    )
  }

  restore_v44 <- v45_charls_actual_register_v44_imputers(authority)
  on.exit(restore_v44(), add = TRUE)
  append_log(
    "Starting m=50 MICE at checkpoints 20 -> 40 -> 80; ",
    "no outcome model will be fitted."
  )
  started <- proc.time()[["elapsed"]]
  schedule <- tryCatch(
    withCallingHandlers(
      authority$run_mi_convergence_schedule(
        object$mi_data,
        object$mi_spec,
        m = requested_m,
        analysis_id = object_id,
        mi_run = m_label
      ),
      warning = function(warning) {
        stop(
          "Escaped production warning: ",
          conditionMessage(warning), call. = FALSE
        )
      }
    ),
    error = function(error) {
      checkpoint_for_failure <<- if (
        inherits(error, "stage3_mice_convergence_error") &&
          !is.null(error$checkpoint_diagnostics)
      ) {
        error$checkpoint_diagnostics
      } else {
        NULL
      }
      error_for_failure <<- error
      stop(error)
    }
  )
  elapsed <- proc.time()[["elapsed"]] - started
  imp <- schedule$imp
  final_convergence <- schedule$final_convergence
  checkpoint_diagnostics <- schedule$checkpoint_diagnostics
  selected_maxit <- as.integer(schedule$selected_maxit)
  checkpoint_for_failure <<- checkpoint_diagnostics

  required_convergence <- c("parameter", "hard_gate", "pass")
  hard_rows <- if (is.data.frame(final_convergence)) {
    final_convergence$hard_gate %in% TRUE
  } else {
    logical()
  }
  variation_rows <- if (is.data.frame(final_convergence)) {
    final_convergence$parameter == "final_between_imputation_variation"
  } else {
    logical()
  }
  raw_where <- is.na(object$mi_data)
  expected_where <- v45_charls_prod_expected_where(object$mi_data)
  logged_events <- if (is.null(imp$loggedEvents)) {
    0L
  } else {
    nrow(imp$loggedEvents)
  }
  structure_checks <- c(
    class_is_mids = inherits(imp, "mids"),
    m_exact = identical(as.integer(imp$m), requested_m),
    selected_checkpoint_exact =
      identical(as.integer(imp$iteration), selected_maxit),
    selected_checkpoint_allowed = selected_maxit %in% c(20L, 40L, 80L),
    logged_events_zero = logged_events == 0L,
    method_exact = identical(imp$method, object$mi_spec$method),
    predictor_exact = identical(
      imp$predictorMatrix, object$mi_spec$predictor_matrix
    ),
    where_exact = identical(imp$where, expected_where),
    where_values_equal_raw_missingness =
      identical(as.vector(imp$where), as.vector(raw_where)),
    where_dimnames_equal_input =
      identical(dimnames(imp$where), dimnames(object$mi_data)),
    where_hash_exact = identical(
      v45_canonical_array_sha256(imp$where),
      expected$where_sha256
    ),
    visit_exact = identical(
      as.character(imp$visitSequence),
      as.character(object$mi_spec$visit_sequence)
    ),
    input_exact = identical(
      v45_canonical_data_frame_contract(imp$data)$sha256,
      expected$canonical_data_sha256
    ),
    convergence_table_nonempty =
      is.data.frame(final_convergence) &&
        nrow(final_convergence) > 0L &&
        all(required_convergence %in% names(final_convergence)),
    hard_rows_present = any(hard_rows),
    all_hard_rows_pass = any(hard_rows) &&
      all(final_convergence$pass[hard_rows] %in% TRUE),
    variation_rows_present = any(variation_rows),
    all_variation_rows_pass = any(variation_rows) &&
      all(final_convergence$pass[variation_rows] %in% TRUE)
  )
  if (!all(structure_checks)) {
    stop(
      "Post-MICE structural gate failed: ",
      paste(names(structure_checks)[!structure_checks], collapse = ", "),
      call. = FALSE
    )
  }
  append_log(
    "MICE selected checkpoint ", selected_maxit,
    " after ", round(elapsed, 1), " seconds."
  )

  append_log("Transiently auditing all 50 completed datasets.")
  completion_rows <- vector("list", requested_m)
  observed_change_n <- 0L
  structure_change_n <- 0L
  smoking_conflict_n <- 0L
  R_W2_change_n <- 0L
  maximum_bmi_error <- 0
  maximum_age_W2_error <- if (object_id == "MI-C2") 0 else NA_real_
  bmi_placeholder_nonzero_n <- 0L
  bmi_rebuilt_row_n <- 0L
  age_W2_rebuilt_row_n <- if (object_id == "MI-C2") 0L else NA_integer_
  for (chain in seq_len(requested_m)) {
    completed <- mice::complete(imp, action = chain)
    for (field in names(object$mi_data)) {
      class_ok <- identical(
        class(completed[[field]]), class(object$mi_data[[field]])
      ) && (
        !is.factor(object$mi_data[[field]]) ||
          (
            identical(
              levels(completed[[field]]), levels(object$mi_data[[field]])
            ) &&
              identical(
                is.ordered(completed[[field]]),
                is.ordered(object$mi_data[[field]])
              )
          )
      )
      structure_change_n <- structure_change_n + as.integer(!class_ok)
      observed <- !is.na(object$mi_data[[field]])
      changed <- if (
        is.factor(object$mi_data[[field]]) ||
          is.character(object$mi_data[[field]])
      ) {
        as.character(completed[[field]][observed]) !=
          as.character(object$mi_data[[field]][observed])
      } else {
        completed[[field]][observed] != object$mi_data[[field]][observed]
      }
      observed_change_n <- observed_change_n + sum(is.na(changed) | changed)
    }
    height <- as.numeric(completed$height_m_w1)
    weight <- as.numeric(completed$weight_kg_w1)
    bmi_placeholder <- as.numeric(completed$bmi_w1)
    bmi_placeholder_nonzero <- sum(
      !is.finite(bmi_placeholder) | bmi_placeholder != 0
    )
    bmi_placeholder_nonzero_n <-
      bmi_placeholder_nonzero_n + bmi_placeholder_nonzero
    rebuilt_bmi <- weight / height^2
    completed$bmi_w1 <- rebuilt_bmi
    bmi_rebuilt <- sum(
      is.finite(completed$bmi_w1) &
        completed$bmi_w1 != bmi_placeholder
    )
    bmi_rebuilt_row_n <- bmi_rebuilt_row_n + bmi_rebuilt
    bmi_error <- max(abs(completed$bmi_w1 - weight / height^2))
    maximum_bmi_error <- max(maximum_bmi_error, bmi_error)
    ever <- as.numeric(as.character(
      completed$smoke_ever_w1
    ))
    now <- as.numeric(as.character(
      completed$smoke_now_w1
    ))
    smoking_bad <- is.na(ever) | is.na(now) |
      !ever %in% 0:1 | !now %in% 0:1 | (ever == 0 & now == 1)
    smoking_conflict_n <- smoking_conflict_n + sum(smoking_bad)
    parent_bad <- !is.finite(height) | height < 1 | height > 2.7 |
      !is.finite(weight) | weight < 20 | weight > 350
    bmi_bad <- !is.finite(completed$bmi_w1) |
      completed$bmi_w1 < 11 | completed$bmi_w1 > 75
    age_error <- NA_real_
    age_rebuilt <- NA_integer_
    if (object_id == "MI-C2") {
      completed$age_w2_model <- as.numeric(completed$age_w1) + 2
      age_rebuilt <- sum(is.finite(completed$age_w2_model))
      age_W2_rebuilt_row_n <- age_W2_rebuilt_row_n + age_rebuilt
      age_error <- max(abs(
        completed$age_w2_model -
          (as.numeric(completed$age_w1) + 2)
      ))
      maximum_age_W2_error <- max(maximum_age_W2_error, age_error)
      response_changed <- as.character(completed$R_W2) !=
        as.character(object$mi_data$R_W2)
      R_W2_change_n <- R_W2_change_n +
        sum(is.na(response_changed) | response_changed)
    }
    if (bmi_placeholder_nonzero != 0L ||
        bmi_rebuilt != nrow(completed) ||
        any(parent_bad) || any(bmi_bad) || any(smoking_bad) ||
        !is.finite(bmi_error) || bmi_error > 1e-12 ||
        (object_id == "MI-C2" &&
           (age_rebuilt != nrow(completed) ||
              !is.finite(age_error) || age_error > 1e-12))) {
      stop("Completed-data passive/range/coherence gate failed in chain ",
           chain, ".", call. = FALSE)
    }
    passive_completion_sha <-
      v45_canonical_data_frame_contract(completed)$sha256
    completion_rows[[chain]] <- data.frame(
      object_id = object_id,
      chain = chain,
      n = nrow(completed),
      height_min = min(height),
      height_max = max(height),
      weight_min = min(weight),
      weight_max = max(weight),
      bmi_placeholder_nonzero_n = bmi_placeholder_nonzero,
      bmi_rebuilt_row_n = bmi_rebuilt,
      bmi_min = min(completed$bmi_w1),
      bmi_max = max(completed$bmi_w1),
      bmi_identity_max_error = bmi_error,
      age_W2_rebuilt_row_n = age_rebuilt,
      age_W2_identity_max_error = age_error,
      passive_completion_sha256 = passive_completion_sha,
      stringsAsFactors = FALSE
    )
    rm(
      completed, height, weight, bmi_placeholder, rebuilt_bmi,
      passive_completion_sha
    )
    if (chain %% 5L == 0L) invisible(gc(verbose = FALSE))
  }
  if (observed_change_n != 0L || structure_change_n != 0L ||
      smoking_conflict_n != 0L || R_W2_change_n != 0L ||
      bmi_placeholder_nonzero_n != 0L ||
      bmi_rebuilt_row_n != requested_m * nrow(object$mi_data) ||
      maximum_bmi_error > 1e-12 ||
      (object_id == "MI-C2" &&
         (age_W2_rebuilt_row_n != requested_m * nrow(object$mi_data) ||
            maximum_age_W2_error > 1e-12))) {
    stop(
      "Completed-data aggregate gate failed: observed=", observed_change_n,
      "; structure=", structure_change_n,
      "; smoking=", smoking_conflict_n,
      "; R_W2=", R_W2_change_n, call. = FALSE
    )
  }
  completion_audit <- do.call(rbind, completion_rows)
  completion_summary <- data.frame(
    object_id = object_id,
    requested_m = requested_m,
    chains_checked = nrow(completion_audit),
    observed_value_change_n = observed_change_n,
    structure_change_n = structure_change_n,
    smoking_conflict_n = smoking_conflict_n,
    R_W2_change_n = R_W2_change_n,
    bmi_placeholder_nonzero_n = bmi_placeholder_nonzero_n,
    bmi_rebuilt_row_n = bmi_rebuilt_row_n,
    maximum_bmi_identity_error = maximum_bmi_error,
    age_W2_rebuilt_row_n = age_W2_rebuilt_row_n,
    maximum_age_W2_identity_error = maximum_age_W2_error,
    completed_dataset_persistence_count = 0L,
    status = "PASS",
    stringsAsFactors = FALSE
  )

  released_trace <- authority$mice_chain_trace(
    imp, final_convergence, object$mi_data, object$mi_spec
  )
  category_trace <- attr(imp, "category_trace", exact = TRUE)
  if (is.null(category_trace)) {
    category_trace <- data.frame(
      variable = character(), category_level = character(),
      iteration = integer(), chain = integer(), missing_n = integer(),
      value = numeric(), stringsAsFactors = FALSE
    )
  }
  components <- v45_charls_prod_component_table(list(
    canonical_source_input_data = expected$canonical_data_sha256,
    canonical_column_contract = expected$column_contract_sha256,
    canonical_frozen_specification =
      v45_canonical_object_sha256(object$mi_spec),
    canonical_ordered_participant_ids =
      expected$ordered_participant_id_sha256,
    canonical_imputation_payload =
      v45_canonical_imputation_payload_sha256(imp),
    canonical_chain_mean = v45_canonical_array_sha256(imp$chainMean),
    canonical_chain_variance = v45_canonical_array_sha256(imp$chainVar),
    canonical_categorical_trace =
      v45_canonical_data_frame_contract(category_trace)$sha256,
    canonical_final_convergence =
      v45_canonical_data_frame_contract(final_convergence)$sha256,
    canonical_checkpoint_diagnostics =
      v45_canonical_data_frame_contract(checkpoint_diagnostics)$sha256,
    canonical_released_trace =
      v45_canonical_data_frame_contract(released_trace)$sha256,
    mids_method = v45_canonical_named_character_sha256(imp$method),
    mids_predictor_matrix =
      v45_canonical_array_sha256(imp$predictorMatrix),
    mids_where = v45_canonical_array_sha256(imp$where),
    mids_visit_sequence = v45_canonical_object_sha256(
      as.character(imp$visitSequence)
    ),
    mids_last_seed_value =
      v45_canonical_array_sha256(as.integer(imp$lastSeedValue))
  ))

  attr(imp, "v45_1_charls_production_metadata") <- list(
    contract_version = "v45_1_charls_production_mi",
    run_id = run_id,
    object_id = object_id,
    requested_m = requested_m,
    selected_maxit = selected_maxit,
    generation_status = "GENERATED_AWAITING_INDEPENDENT_VALIDATION",
    outcome_model_fit_count = 0L,
    response_model_fit_count = 0L,
    pef_model_fit_count = 0L,
    coefficient_export_count = 0L,
    completed_dataset_persistence_count = 0L,
    component_hashes_before_file_save = components
  )
  mids_name <- paste0(object_id, "_m50.mids.rds")
  mids_staging <- file.path(restricted_staging, mids_name)
  v45_charls_atomic_save_rds(imp, mids_staging)
  mids_sha <- v45_charls_sha256_file(mids_staging)
  components <- rbind(
    components,
    data.frame(
      component = "final_mids_file",
      sha256 = mids_sha,
      hash_rule = "SHA-256 of restricted xz-compressed RDS bytes",
      stringsAsFactors = FALSE
    )
  )
  if (nrow(components) != 17L ||
      anyDuplicated(components$component) ||
      any(!grepl("^[0-9a-f]{64}$", components$sha256))) {
    stop("Final production component manifest is invalid.", call. = FALSE)
  }

  restricted_alias <- file.path(
    "derived_sensitive/v45/charls_addendum_v45_1/production_mi",
    object_id, m_label, run_id, mids_name
  )
  result_alias <- file.path(
    "results/v45/charls_addendum_v45_1/production_mi",
    object_id, m_label, run_id
  )
  run_manifest <- data.frame(
    run_id = run_id,
    object_id = object_id,
    requested_m = requested_m,
    selected_maxit = selected_maxit,
    elapsed_seconds = round(elapsed, 3),
    denominator_n = nrow(object$mi_data),
    input_column_n = ncol(object$mi_data),
    active_target_n = sum(nzchar(object$mi_spec$method)),
    hard_convergence_rows = sum(hard_rows),
    failed_hard_convergence_rows = sum(
      hard_rows & !(final_convergence$pass %in% TRUE)
    ),
    warning_count = 0L,
    logged_event_count = logged_events,
    outcome_model_fit_count = 0L,
    response_model_fit_count = 0L,
    pef_model_fit_count = 0L,
    coefficient_export_count = 0L,
    completed_dataset_persistence_count = 0L,
    mids_path_alias = restricted_alias,
    mids_bytes = as.numeric(file.info(mids_staging)$size),
    mids_sha256 = mids_sha,
    result_path_alias = result_alias,
    status = "GENERATED_AWAITING_INDEPENDENT_VALIDATION",
    completed_at_utc =
      format(Sys.time(), "%Y-%m-%dT%H:%M:%SZ", tz = "UTC"),
    stringsAsFactors = FALSE
  )
  structural <- data.frame(
    check_id = names(structure_checks),
    status = ifelse(structure_checks, "PASS", "FAIL"),
    run_id = run_id,
    stringsAsFactors = FALSE
  )
  v45_charls_atomic_write_tsv(
    run_manifest, file.path(result_staging, "run_manifest.tsv")
  )
  v45_charls_atomic_write_tsv(
    components, file.path(result_staging, "component_hashes.tsv")
  )
  v45_charls_atomic_write_tsv(
    structural, file.path(result_staging, "structural_checks.tsv")
  )
  v45_charls_atomic_write_tsv(
    checkpoint_diagnostics,
    file.path(result_staging, "checkpoint_diagnostics.tsv")
  )
  v45_charls_atomic_write_tsv(
    final_convergence,
    file.path(result_staging, "final_convergence.tsv")
  )
  v45_charls_atomic_write_tsv(
    released_trace, file.path(result_staging, "released_chain_trace.tsv")
  )
  v45_charls_atomic_write_tsv(
    completion_audit,
    file.path(result_staging, "completion_chain_audit.tsv")
  )
  v45_charls_atomic_write_tsv(
    completion_summary,
    file.path(result_staging, "completion_summary.tsv")
  )
  v45_charls_atomic_write_lines(
    c(
      log_lines,
      paste0(
        "completed_at_utc: ",
        format(Sys.time(), "%Y-%m-%dT%H:%M:%SZ", tz = "UTC")
      ),
      "status: GENERATED_AWAITING_INDEPENDENT_VALIDATION"
    ),
    file.path(result_staging, "run.log")
  )
  run_assets <- c(
    mids = mids_staging,
    run_manifest = file.path(result_staging, "run_manifest.tsv"),
    component_hashes = file.path(result_staging, "component_hashes.tsv"),
    structural_checks = file.path(result_staging, "structural_checks.tsv"),
    checkpoint_diagnostics =
      file.path(result_staging, "checkpoint_diagnostics.tsv"),
    final_convergence =
      file.path(result_staging, "final_convergence.tsv"),
    released_chain_trace =
      file.path(result_staging, "released_chain_trace.tsv"),
    completion_chain_audit =
      file.path(result_staging, "completion_chain_audit.tsv"),
    completion_summary =
      file.path(result_staging, "completion_summary.tsv"),
    run_log = file.path(result_staging, "run.log")
  )
  run_output_manifest <- data.frame(
    asset_id = names(run_assets),
    path_alias = c(
      restricted_alias,
      file.path(result_alias, basename(run_assets[-1L]))
    ),
    bytes = vapply(
      run_assets, function(path) as.numeric(file.info(path)$size), numeric(1)
    ),
    sha256 = vapply(
      run_assets, v45_charls_sha256_file, character(1)
    ),
    access = c("restricted_mids", rep("aggregate", 9L)),
    validation_status = "PASS",
    stringsAsFactors = FALSE
  )
  if (nrow(run_output_manifest) != 10L ||
      anyDuplicated(run_output_manifest$asset_id) ||
      any(!grepl("^[0-9a-f]{64}$", run_output_manifest$sha256))) {
    stop("CHARLS production run output manifest is invalid.", call. = FALSE)
  }
  v45_charls_atomic_write_tsv(
    run_output_manifest,
    file.path(result_staging, "run_output_manifest.tsv")
  )
  run_output_manifest_sha <- v45_charls_sha256_file(
    file.path(result_staging, "run_output_manifest.tsv")
  )
  restricted_staged_files <- list.files(
    restricted_staging, all.files = TRUE, no.. = TRUE,
    full.names = TRUE
  )
  result_staged_files <- list.files(
    result_staging, all.files = TRUE, no.. = TRUE,
    full.names = TRUE
  )
  expected_result_files <- c(
    "run_manifest.tsv", "component_hashes.tsv",
    "structural_checks.tsv", "checkpoint_diagnostics.tsv",
    "final_convergence.tsv", "released_chain_trace.tsv",
    "completion_chain_audit.tsv", "completion_summary.tsv",
    "run.log", "run_output_manifest.tsv"
  )
  if (length(restricted_staged_files) != 1L ||
      !identical(restricted_staged_files, mids_staging) ||
      !v45_charls_prod_regular_file(restricted_staged_files) ||
      length(result_staged_files) != length(expected_result_files) ||
      !setequal(basename(result_staged_files), expected_result_files) ||
      !all(vapply(
        result_staged_files,
        v45_charls_prod_regular_file,
        logical(1)
      ))) {
    stop("CHARLS production staging allowlist failed.", call. = FALSE)
  }

  append_log("Rechecking frozen inputs and isolated gate before commit.")
  verify_freeze()
  if (!identical(v45_charls_sha256_file(gate_path), gate_sha_start)) {
    stop("The isolated CHARLS gate changed during production execution.",
         call. = FALSE)
  }
  transaction_state <- list(
    transaction_id = run_id,
    object_id = object_id,
    requested_m = requested_m,
    phase = "READY_TO_PROMOTE",
    gate_sha256_before = gate_sha_start,
    mids_sha256 = mids_sha,
    run_output_manifest_sha256 = run_output_manifest_sha,
    restricted_final_path = sub(
      paste0("^", root, "/?"), "", restricted_final
    ),
    result_final_path = sub(
      paste0("^", root, "/?"), "", result_final
    ),
    pointer_path = sub(paste0("^", root, "/?"), "", pointer),
    pointer_sha256 = NA_character_,
    recovery_rule =
      "audit hashes and phase; complete or roll back only this transaction"
  )
  write_transaction_state <- function(phase, pointer_sha = NA_character_) {
    transaction_state$phase <<- phase
    transaction_state$pointer_sha256 <<- pointer_sha
    v45_charls_atomic_write_yaml(transaction_state, transaction_record)
  }
  write_transaction_state("READY_TO_PROMOTE")
  if (!file.rename(restricted_staging, restricted_final)) {
    stop("Could not publish the restricted CHARLS mids directory.",
         call. = FALSE)
  }
  write_transaction_state("RESTRICTED_PROMOTED")
  if (!file.rename(result_staging, result_final)) {
    stop("Could not publish the CHARLS aggregate run directory.",
         call. = FALSE)
  }
  write_transaction_state("RESULT_PROMOTED")
  current_pointer <- data.frame(
    object_id = object_id,
    requested_m = requested_m,
    run_id = run_id,
    run_manifest_path_alias =
      file.path(result_alias, "run_manifest.tsv"),
    run_output_manifest_path_alias =
      file.path(result_alias, "run_output_manifest.tsv"),
    run_output_manifest_sha256 = run_output_manifest_sha,
    mids_path_alias = restricted_alias,
    mids_sha256 = mids_sha,
    status = "GENERATED_AWAITING_INDEPENDENT_VALIDATION",
    stringsAsFactors = FALSE
  )
  v45_charls_atomic_write_tsv(current_pointer, pointer)
  pointer_written_sha <<- v45_charls_sha256_file(pointer)
  write_transaction_state("POINTER_PUBLISHED", pointer_written_sha)
  if (!identical(v45_charls_sha256_file(gate_path), gate_sha_start)) {
    stop("The isolated CHARLS gate changed before final publication.",
         call. = FALSE)
  }
  success_gate <- yaml::read_yaml(gate_path)
  if (is.null(success_gate$charls_production_mi_execution$objects)) {
    success_gate$charls_production_mi_execution$objects <- list()
  }
  success_gate$charls_production_mi_execution$objects[[object_id]] <- list(
    status = "GENERATED_AWAITING_INDEPENDENT_VALIDATION",
    m = requested_m,
    run_id = run_id,
    selected_maxit = selected_maxit,
    mids_sha256 = mids_sha,
    run_output_manifest_sha256 = run_output_manifest_sha
  )
  pointer_contract_ok <- function(id) {
    expected_gate <-
      success_gate$charls_production_mi_execution$objects[[id]]
    token <- gsub("-", "_", id)
    current_path <- file.path(
      paths$result, "production_mi",
      paste0(token, "_m50_current.tsv")
    )
    if (is.null(expected_gate) ||
        !v45_charls_prod_regular_file(current_path)) {
      return(FALSE)
    }
    current <- tryCatch(
      v45_charls_prod_read_tsv_stable(current_path),
      error = function(error) NULL
    )
    required <- c(
      "object_id", "requested_m", "run_id", "run_manifest_path_alias",
      "run_output_manifest_path_alias", "run_output_manifest_sha256",
      "mids_path_alias", "mids_sha256", "status"
    )
    if (is.null(current) || nrow(current) != 1L ||
        !identical(names(current), required) ||
        !identical(as.character(current$object_id), id) ||
        !identical(as.integer(current$requested_m), 50L) ||
        !identical(as.character(current$run_id),
                   as.character(expected_gate$run_id)) ||
        !identical(as.character(current$mids_sha256),
                   as.character(expected_gate$mids_sha256)) ||
        !identical(
          as.character(current$run_output_manifest_sha256),
          as.character(expected_gate$run_output_manifest_sha256)
        ) ||
        !identical(
          as.character(current$status),
          "GENERATED_AWAITING_INDEPENDENT_VALIDATION"
        )) {
      return(FALSE)
    }
    expected_result_alias <- file.path(
      "results/v45/charls_addendum_v45_1/production_mi",
      id, "m50", as.character(expected_gate$run_id)
    )
    expected_mids_alias <- file.path(
      "derived_sensitive/v45/charls_addendum_v45_1/production_mi",
      id, "m50", as.character(expected_gate$run_id),
      paste0(id, "_m50.mids.rds")
    )
    identical(
      as.character(current$run_manifest_path_alias),
      file.path(expected_result_alias, "run_manifest.tsv")
    ) &&
      identical(
        as.character(current$run_output_manifest_path_alias),
        file.path(expected_result_alias, "run_output_manifest.tsv")
      ) &&
      identical(as.character(current$mids_path_alias), expected_mids_alias) &&
      identical(
        v45_charls_sha256_file(file.path(
          root, as.character(current$run_output_manifest_path_alias)
        )),
        as.character(current$run_output_manifest_sha256)
      ) &&
      identical(
        v45_charls_sha256_file(file.path(
          root, as.character(current$mids_path_alias)
        )),
        as.character(current$mids_sha256)
      )
  }
  both <- setequal(
    names(success_gate$charls_production_mi_execution$objects),
    c("MI-C0", "MI-C2")
  ) && all(vapply(
    c("MI-C0", "MI-C2"), pointer_contract_ok, logical(1)
  ))
  success_gate$charls_production_mi_execution$status <- if (both) {
    "GENERATED_ALL_AWAITING_INDEPENDENT_VALIDATION"
  } else {
    "IN_PROGRESS"
  }
  success_gate$outcome_execution_allowed <- "no"
  success_gate$new_coefficient_inspection_allowed <- "no"
  success_gate$next_authorized_step <- if (both) {
    "independently_validate_CHARLS_MI_C0_MI_C2_m50"
  } else {
    "run_remaining_CHARLS_production_m50_object_serially"
  }
  success_gate$updated_at_utc <-
    format(Sys.time(), "%Y-%m-%dT%H:%M:%SZ", tz = "UTC")
  v45_charls_atomic_write_yaml(success_gate, gate_path)
  write_transaction_state("GATE_PUBLISHED", pointer_written_sha)
  transaction_committed <<- TRUE
  if (file.exists(transaction_record)) {
    unlink(transaction_record, force = TRUE)
  }
  message(
    object_id,
    " m50 generated and awaiting independent validation; no model was fitted."
  )
}

tryCatch(
  withCallingHandlers(
    main(),
    warning = function(warning) {
      stop(
        "CHARLS production warning promoted to fatal: ",
        conditionMessage(warning), call. = FALSE
      )
    }
  ),
  error = function(error) {
    error_for_failure <<- error
    if (!failure_recorded) {
      try(record_failure(error, checkpoint_for_failure), silent = TRUE)
    }
    stop(error)
  }
)
}

execute()
