# Utilities for the isolated CHARLS v45.1 production-MI stage.
# Sourcing this file defines functions only.

v45_charls_prod_paths <- function(root) {
  base <- file.path(root, "work_v45", "charls_addendum_v45_1")
  result <- file.path(root, "results", "v45", "charls_addendum_v45_1")
  restricted <- file.path(
    root, "derived_sensitive", "v45", "charls_addendum_v45_1"
  )
  list(
    work = base,
    result = result,
    restricted = restricted,
    spec = file.path(base, "charls_production_mi_spec_v45_1.yml"),
    gate = file.path(base, "charls_production_mi_gate_state_v45_1.yml"),
    predecessor_gate =
      file.path(base, "charls_actual_keys_mi_gate_state_v45_1.yml"),
    predecessor_contract = file.path(
      restricted, "charls_actual_keys_mi_contract_v45_1.rds"
    ),
    predecessor_output_manifest = file.path(
      result, "charls_actual_keys_mi_output_manifest_v45_1.tsv"
    ),
    predecessor_independent_manifest = file.path(
      result,
      "charls_actual_keys_mi_independent_output_manifest_v45_1.tsv"
    ),
    predecessor_independent_validation = file.path(
      result, "charls_actual_keys_mi_independent_validation_v45_1.tsv"
    ),
    v43 = file.path(
      root,
      paste0(
        "output/code_archive/PEF_mortality_v44_2_code_candidate/",
        "R/v43/04_charls_stage3_primary_mortality.R"
      )
    ),
    v44 = file.path(
      root,
      paste0(
        "output/code_archive/PEF_mortality_v44_2_code_candidate/",
        "R/v44/05_charls_anthropometric_qc_resolution_v44_1_1.R"
      )
    ),
    v44_spec = file.path(
      root,
      paste0(
        "output/code_archive/PEF_mortality_v44_2_code_candidate/",
        "work_v44/charls_anthropometric_qc_resolution_spec_v44_1_1.yml"
      )
    )
  )
}

v45_charls_prod_is_no <- function(value) {
  identical(value, FALSE) ||
    (length(value) == 1L && !is.na(value) &&
       tolower(as.character(value)) %in% c("no", "false"))
}

v45_charls_prod_is_yes <- function(value) {
  identical(value, TRUE) ||
    (length(value) == 1L && !is.na(value) &&
       tolower(as.character(value)) %in% c("yes", "true"))
}

v45_charls_prod_regular_file <- function(path) {
  file.exists(path) && !dir.exists(path) && !nzchar(Sys.readlink(path))
}

v45_charls_prod_read_tsv_stable <- function(path) {
  if (!v45_charls_prod_regular_file(path)) {
    stop("Required stable TSV is absent: ", path, call. = FALSE)
  }
  before <- v45_charls_sha256_file(path)
  out <- utils::read.delim(
    path, stringsAsFactors = FALSE, check.names = FALSE
  )
  after <- v45_charls_sha256_file(path)
  if (!identical(before, after)) {
    stop("TSV changed while being read: ", path, call. = FALSE)
  }
  out
}

v45_charls_prod_read_rds_stable <- function(path) {
  if (!v45_charls_prod_regular_file(path)) {
    stop("Required stable RDS is absent: ", path, call. = FALSE)
  }
  before <- v45_charls_sha256_file(path)
  out <- readRDS(path)
  after <- v45_charls_sha256_file(path)
  if (!identical(before, after)) {
    stop("RDS changed while being read: ", path, call. = FALSE)
  }
  out
}

v45_charls_prod_top_function_names <- function(path) {
  expressions <- parse(path, keep.source = FALSE)
  names <- vapply(expressions, function(expression) {
    if (is.call(expression) && length(expression) == 3L &&
        identical(as.character(expression[[1L]]), "<-") &&
        is.symbol(expression[[2L]]) && is.call(expression[[3L]]) &&
        identical(as.character(expression[[3L]][[1L]]), "function")) {
      as.character(expression[[2L]])
    } else {
      NA_character_
    }
  }, character(1))
  unique(names[!is.na(names)])
}

v45_charls_prod_transitive_functions <- function(environment, roots) {
  seen <- character()
  pending <- unique(as.character(roots))
  while (length(pending)) {
    name <- pending[[1L]]
    pending <- pending[-1L]
    if (name %in% seen) next
    if (!exists(name, envir = environment, inherits = FALSE) ||
        !is.function(get(name, envir = environment, inherits = FALSE))) {
      stop("Required function is absent from frozen authority: ", name,
           call. = FALSE)
    }
    seen <- c(seen, name)
    discovered <- codetools::findGlobals(
      get(name, envir = environment, inherits = FALSE),
      merge = FALSE
    )
    globals <- unique(c(discovered$functions, discovered$variables))
    local <- globals[vapply(globals, function(candidate) {
      exists(candidate, envir = environment, inherits = FALSE) &&
        is.function(get(candidate, envir = environment, inherits = FALSE))
    }, logical(1))]
    pending <- unique(c(pending, setdiff(local, seen)))
  }
  sort(seen, method = "radix")
}

v45_charls_prod_load_authority <- function(root) {
  paths <- v45_charls_prod_paths(root)
  all_v43 <- new.env(parent = globalenv())
  for (name in v45_charls_prod_top_function_names(paths$v43)) {
    v45_charls_actual_extract_function(paths$v43, name, all_v43)
  }
  roots <- c(
    "run_mi_convergence_schedule",
    "mice_chain_convergence",
    "mice_chain_trace",
    "format_mice_convergence_failures"
  )
  closure <- v45_charls_prod_transitive_functions(all_v43, roots)
  authority <- v45_charls_actual_load_authority(root)
  for (name in closure) {
    v45_charls_actual_extract_function(paths$v43, name, authority)
  }
  attr(authority, "production_v43_closure") <- closure
  attr(authority, "production_roots") <- roots
  authority
}

v45_charls_prod_verify_manifest_files <- function(root, manifest) {
  required <- c(
    "asset_id", "path_alias", "bytes", "sha256", "validation_status"
  )
  if (!all(required %in% names(manifest)) ||
      anyDuplicated(manifest$asset_id) ||
      any(manifest$validation_status != "PASS")) {
    return(FALSE)
  }
  all(vapply(seq_len(nrow(manifest)), function(index) {
    path <- file.path(root, manifest$path_alias[[index]])
    v45_charls_prod_regular_file(path) &&
      identical(
        as.numeric(file.info(path)$size),
        as.numeric(manifest$bytes[[index]])
      ) &&
      identical(
        v45_charls_sha256_file(path),
        as.character(manifest$sha256[[index]])
      )
  }, logical(1)))
}

v45_charls_prod_verify_predecessor <- function(root) {
  paths <- v45_charls_prod_paths(root)
  gate <- yaml::read_yaml(paths$predecessor_gate)
  gate_ok <-
    identical(as.character(gate$freeze$status), "PASS") &&
    identical(as.character(gate$actual_design_key_binding$status), "PASS") &&
    identical(as.character(gate$mi_c0_structural_preflight$status), "PASS") &&
    identical(as.character(gate$mi_c2_structural_preflight$status), "PASS") &&
    identical(as.character(gate$independent_validation$status), "PASS") &&
    v45_charls_prod_is_yes(gate$charls_production_mi_allowed) &&
    v45_charls_prod_is_no(gate$outcome_execution_allowed) &&
    v45_charls_prod_is_no(gate$new_coefficient_inspection_allowed)
  if (!gate_ok) {
    stop("The predecessor CHARLS production-MI authorization drifted.",
         call. = FALSE)
  }
  parent_gate <- yaml::read_yaml(file.path(
    paths$work, "charls_addendum_gate_state_v45_1.yml"
  ))
  parent_required <- c(
    "pure_function_freeze", "structural_preflight",
    "independent_validation", "actual_design_key_binding",
    "mi_c0_structural_preflight", "mi_c2_structural_preflight",
    "actual_keys_mi_independent_validation"
  )
  parent_ok <- all(vapply(parent_required, function(field) {
    identical(as.character(parent_gate[[field]]$status), "PASS")
  }, logical(1))) &&
    v45_charls_prod_is_yes(parent_gate$charls_production_mi_allowed) &&
    v45_charls_prod_is_no(parent_gate$outcome_execution_allowed) &&
    v45_charls_prod_is_no(parent_gate$new_coefficient_inspection_allowed)
  if (!parent_ok) {
    stop("The current CHARLS addendum parent gate drifted.", call. = FALSE)
  }
  code <- v45_charls_prod_read_tsv_stable(file.path(
    paths$work, "charls_actual_keys_mi_code_manifest_v45_1.tsv"
  ))
  functions <- v45_charls_prod_read_tsv_stable(file.path(
    paths$work, "charls_actual_keys_mi_function_manifest_v45_1.tsv"
  ))
  roots <- v45_charls_prod_read_tsv_stable(file.path(
    paths$work, "charls_actual_keys_mi_freeze_roots_v45_1.tsv"
  ))
  code_ok <- !anyDuplicated(code$asset_id) && all(code$status == "PASS") &&
    all(vapply(seq_len(nrow(code)), function(index) {
      path <- file.path(root, code$path_alias[[index]])
      v45_charls_prod_regular_file(path) &&
        identical(
          as.numeric(file.info(path)$size),
          as.numeric(code$bytes[[index]])
        ) &&
        identical(
          v45_charls_sha256_file(path), as.character(code$sha256[[index]])
        )
    }, logical(1)))
  function_ok <- !anyDuplicated(functions$function_name) &&
    all(functions$status == "PASS") &&
    all(grepl("^[0-9a-f]{64}$", functions$authority_file_sha256)) &&
    all(grepl("^[0-9a-f]{64}$", functions$function_sha256))
  root_value <- function(id) {
    row <- roots[roots$root_id == id, , drop = FALSE]
    if (nrow(row) != 1L) return(NA_character_)
    as.character(row$sha256)
  }
  actual_spec <- yaml::read_yaml(v45_charls_actual_paths(root)$spec)
  source_validation <- v45_charls_actual_validate_source_files(
    root, actual_spec
  )
  roots_ok <- identical(
    root_value("actual_keys_mi_code_root"),
    v45_charls_manifest_root(
      code, "asset_id", c("asset_id", "bytes", "sha256")
    )
  ) && identical(
    root_value("actual_keys_mi_function_root"),
    v45_charls_manifest_root(
      functions, "function_name",
      c(
        "function_name", "authority",
        "authority_file_sha256", "function_sha256"
      )
    )
  ) && identical(
    root_value("restricted_source_root"),
    v45_charls_manifest_root(
      source_validation, "source_id",
      c(
        "source_id", "bytes", "sha256",
        "expected_bytes", "expected_sha256"
      )
    )
  )
  if (!code_ok || !function_ok || !roots_ok) {
    stop(
      "The predecessor CHARLS code/function/source roots drifted.",
      call. = FALSE
    )
  }
  runner <- v45_charls_prod_read_tsv_stable(
    paths$predecessor_output_manifest
  )
  independent <- v45_charls_prod_read_tsv_stable(
    paths$predecessor_independent_manifest
  )
  validation <- v45_charls_prod_read_tsv_stable(
    paths$predecessor_independent_validation
  )
  if (!v45_charls_prod_verify_manifest_files(root, runner) ||
      !v45_charls_prod_verify_manifest_files(root, independent) ||
      nrow(validation) != 11L || anyDuplicated(validation$check_id) ||
      any(validation$status != "PASS")) {
    stop("The predecessor CHARLS validated-output bundle drifted.",
         call. = FALSE)
  }
  manifest_rows <- rbind(
    data.frame(
      bundle = "runner", asset_id = runner$asset_id,
      path_alias = runner$path_alias, bytes = runner$bytes,
      sha256 = runner$sha256, stringsAsFactors = FALSE
    ),
    data.frame(
      bundle = "independent", asset_id = independent$asset_id,
      path_alias = independent$path_alias, bytes = independent$bytes,
      sha256 = independent$sha256, stringsAsFactors = FALSE
    )
  )
  list(
    gate = gate,
    parent_gate = parent_gate,
    root = v45_charls_manifest_root(
      manifest_rows, "asset_id",
      c("bundle", "asset_id", "path_alias", "bytes", "sha256")
    ),
    runner_manifest = runner,
    independent_manifest = independent,
    validation = validation
  )
}

v45_charls_prod_build_objects <- function(root) {
  spec <- yaml::read_yaml(v45_charls_prod_paths(root)$spec)
  actual_spec <- yaml::read_yaml(v45_charls_actual_paths(root)$spec)
  source <- v45_charls_actual_read_sources(root, actual_spec)
  denominator <- v45_charls_actual_denominators(source)
  v45_charls_actual_assert_anchors(source, denominator, actual_spec)
  authority <- v45_charls_prod_load_authority(root)
  v44_spec <- yaml::read_yaml(v45_charls_prod_paths(root)$v44_spec)
  objects <- list(
    `MI-C0` = v45_charls_actual_build_mi_c0(
      source, authority, v44_spec
    ),
    `MI-C2` = v45_charls_actual_build_mi_c2(
      source, denominator, authority, v44_spec
    )
  )
  rm(source, denominator)
  invisible(gc(verbose = FALSE))
  list(spec = spec, actual_spec = actual_spec, authority = authority,
       objects = objects)
}

v45_charls_prod_expected_where <- function(data) {
  if (!is.data.frame(data)) {
    stop("The MICE where contract requires a data frame.", call. = FALSE)
  }
  raw_where <- is.na(data)
  where <- matrix(
    as.logical(as.matrix(raw_where)),
    nrow = nrow(data),
    ncol = ncol(data),
    dimnames = dimnames(data)
  )
  if (anyNA(where) ||
      !identical(dim(where), dim(data)) ||
      !identical(dimnames(where), dimnames(data)) ||
      !identical(as.vector(where), as.vector(raw_where))) {
    stop("The deterministic MICE where contract is invalid.",
         call. = FALSE)
  }
  where
}

v45_charls_prod_object_contract <- function(object) {
  data_contract <- v45_canonical_data_frame_contract(object$mi_data)
  column_contract_sha <- v45_canonical_data_frame_contract(
    data_contract$columns
  )$sha256
  missing <- vapply(
    object$mi_data, function(value) sum(is.na(value)), integer(1)
  )
  missing_contract <- data.frame(
    column_index = seq_along(missing),
    column_name = names(missing),
    missing_n = unname(missing),
    stringsAsFactors = FALSE
  )
  raw_where <- is.na(object$mi_data)
  where <- v45_charls_prod_expected_where(object$mi_data)
  active <- names(object$mi_spec$method)[nzchar(object$mi_spec$method)]
  pef_targets <- active[grepl(
    "(^|_)pef|E0_W2|M12|D12", active, ignore.case = TRUE
  )]
  list(
    object_id = object$object_id,
    denominator_n = nrow(object$mi_data),
    input_column_n = ncol(object$mi_data),
    column_names = names(object$mi_data),
    column_contract = data_contract$columns,
    column_contract_sha256 = column_contract_sha,
    canonical_data_sha256 = data_contract$sha256,
    missing_contract = missing_contract,
    missing_contract_sha256 =
      v45_canonical_data_frame_contract(missing_contract)$sha256,
    ordered_participant_id_sha256 = v45_canonical_object_sha256(
      as.character(object$mi_data$participant_id)
    ),
    specification = object$mi_spec,
    specification_sha256 =
      v45_canonical_object_sha256(object$mi_spec),
    method_sha256 =
      v45_canonical_object_sha256(object$mi_spec$method),
    predictor_sha256 =
      v45_canonical_array_sha256(object$mi_spec$predictor_matrix),
    where_sha256 = v45_canonical_array_sha256(where),
    where_values_equal_raw_missingness =
      identical(as.vector(where), as.vector(raw_where)),
    where_dimnames_equal_input =
      identical(dimnames(where), dimnames(object$mi_data)),
    visit_sha256 =
      v45_canonical_object_sha256(object$mi_spec$visit_sequence),
    missingness_sha256 =
      v45_canonical_object_sha256(missing),
    passive_sha256 = v45_canonical_object_sha256(object$passive),
    seed = as.integer(object$mi_spec$seed),
    initial_m = as.integer(object$mi_spec$initial_m),
    maximum_m = as.integer(object$mi_spec$maximum_m),
    convergence_checkpoints =
      as.integer(object$mi_spec$convergence_iteration_checkpoints),
    convergence_rhat_max =
      as.numeric(object$mi_spec$convergence_rhat_max),
    active_targets = active,
    active_target_n = length(active),
    pef_imputation_targets = pef_targets,
    pef_imputation_target_n = length(pef_targets),
    bmi_method = unname(object$mi_spec$method[["bmi_w1"]]),
    bmi_predictor_row_zero =
      all(object$mi_spec$predictor_matrix["bmi_w1", ] == 0),
    bmi_predictor_column_zero =
      all(object$mi_spec$predictor_matrix[, "bmi_w1"] == 0),
    bmi_placeholder_all_zero = all(
      is.finite(object$mi_data$bmi_w1) & object$mi_data$bmi_w1 == 0
    ),
    height_derived_terms_absent_from_mice = !any(grepl(
      "^height_(ns|spline|basis)|height_m_w1_(ns|spline|basis)",
      names(object$mi_data), ignore.case = TRUE
    )),
    passive_age_W2_absent_from_mice = !any(
      c("age_w2", "age_W2", "age_w2_model") %in% names(object$mi_data)
    ),
    height_method =
      unname(object$mi_spec$method[["height_m_w1"]]),
    weight_method =
      unname(object$mi_spec$method[["weight_kg_w1"]]),
    R_W2_method = if ("R_W2" %in% names(object$mi_spec$method)) {
      unname(object$mi_spec$method[["R_W2"]])
    } else {
      NA_character_
    },
    R_W2_where_zero = if ("R_W2" %in% colnames(where)) {
      all(!where[, "R_W2"])
    } else {
      NA
    },
    R_W2_predictor_row_zero = if (
      "R_W2" %in% rownames(object$mi_spec$predictor_matrix)
    ) {
      all(object$mi_spec$predictor_matrix["R_W2", ] == 0)
    } else {
      NA
    },
    R_W2_predicts_active = if (
      "R_W2" %in% colnames(object$mi_spec$predictor_matrix)
    ) {
      all(object$mi_spec$predictor_matrix[active, "R_W2"] == 1)
    } else {
      NA
    },
    fixed_W1_PEF_methods_zero = all(
      object$mi_spec$method[
        intersect(c("E0", "E0b", "pef_w1_rowmax"),
                  names(object$mi_spec$method))
      ] == ""
    ),
    fixed_W1_PEF_where_zero = all(
      !where[, intersect(
        c("E0", "E0b", "pef_w1_rowmax"), colnames(where)
      ), drop = FALSE]
    ),
    W2_PEF_column_n = sum(grepl(
      "pef_w2|E0_W2|M12|D12",
      names(object$mi_data), ignore.case = TRUE
    ))
  )
}

v45_charls_prod_build_input_contract <- function(root) {
  built <- v45_charls_prod_build_objects(root)
  registered <- built$spec$objects
  actual_contract <- v45_charls_prod_read_rds_stable(
    v45_charls_prod_paths(root)$predecessor_contract
  )
  contracts <- lapply(built$objects, v45_charls_prod_object_contract)
  summary <- do.call(rbind, lapply(names(contracts), function(object_id) {
    current <- contracts[[object_id]]
    expected <- registered[[object_id]]
    prior <- actual_contract$MI_object_contracts[
      actual_contract$MI_object_contracts$object_id == object_id,
      ,
      drop = FALSE
    ]
    checks <- c(
      prior_unique = nrow(prior) == 1L,
      prior_status = nrow(prior) == 1L &&
        identical(as.character(prior$status), "PASS"),
      prior_denominator_columns_seed = nrow(prior) == 1L &&
        identical(current$denominator_n, as.integer(prior$n)) &&
        identical(current$input_column_n, as.integer(prior$columns)) &&
        identical(current$seed, as.integer(prior$seed)),
      prior_production_schedule = nrow(prior) == 1L &&
        identical(current$initial_m,
                  as.integer(prior$production_initial_m)) &&
        identical(current$maximum_m,
                  as.integer(prior$production_maximum_m)) &&
        identical(
          paste(current$convergence_checkpoints, collapse = "|"),
          as.character(prior$production_checkpoints)
        ),
      active_target_list = nrow(prior) == 1L &&
        identical(
          paste(current$active_targets, collapse = "|"),
          as.character(prior$active_targets)
        ),
      prior_active_target_n = nrow(prior) == 1L &&
        identical(current$active_target_n,
                  as.integer(prior$active_target_n)),
      prior_hashes = nrow(prior) == 1L &&
        identical(current$canonical_data_sha256,
                  as.character(prior$input_sha256)) &&
        identical(current$method_sha256,
                  as.character(prior$method_sha256)) &&
        identical(current$predictor_sha256,
                  as.character(prior$predictor_sha256)) &&
        identical(current$visit_sha256,
                  as.character(prior$visit_sha256)) &&
        identical(current$missingness_sha256,
                  as.character(prior$missingness_sha256)) &&
        identical(current$passive_sha256,
                  as.character(prior$passive_sha256)),
      predecessor_legacy_where_hash = nrow(prior) == 1L &&
        identical(
          as.character(prior$where_sha256),
          as.character(expected$predecessor_where_sha256)
        ),
      prior_zero_pef = nrow(prior) == 1L &&
        identical(current$pef_imputation_target_n,
                  as.integer(prior$pef_imputation_target_n)),
      denominator = identical(
        current$denominator_n, as.integer(expected$denominator_n)
      ),
      columns = identical(
        current$input_column_n, as.integer(expected$columns)
      ),
      active_targets = identical(
        current$active_target_n, as.integer(expected$active_target_n)
      ),
      seed = identical(current$seed, as.integer(expected$seed)),
      data_hash = identical(
        current$canonical_data_sha256,
        as.character(expected$canonical_data_sha256)
      ),
      method_hash = identical(
        current$method_sha256, as.character(expected$method_sha256)
      ),
      predictor_hash = identical(
        current$predictor_sha256, as.character(expected$predictor_sha256)
      ),
      where_hash = identical(
        current$where_sha256, as.character(expected$where_sha256)
      ),
      where_semantics =
        current$where_values_equal_raw_missingness &&
        current$where_dimnames_equal_input,
      visit_hash = identical(
        current$visit_sha256, as.character(expected$visit_sha256)
      ),
      missingness_hash = identical(
        current$missingness_sha256,
        as.character(expected$missingness_sha256)
      ),
      passive_hash = identical(
        current$passive_sha256, as.character(expected$passive_sha256)
      ),
      m50 = identical(current$initial_m, 50L),
      m100_upgrade_ceiling = identical(current$maximum_m, 100L),
      checkpoints = identical(
        current$convergence_checkpoints, c(20L, 40L, 80L)
      ),
      rhat = identical(current$convergence_rhat_max, 1.05),
      height_method = identical(
        current$height_method, "v44_who_constrained_height_pmm"
      ),
      weight_method = identical(
        current$weight_method, "v44_who_constrained_weight_pmm"
      ),
      passive_bmi = identical(current$bmi_method, "") &&
        current$bmi_predictor_row_zero &&
        current$bmi_predictor_column_zero &&
        current$bmi_placeholder_all_zero &&
        current$height_derived_terms_absent_from_mice,
      zero_pef_targets = current$pef_imputation_target_n == 0L,
      fixed_w1_pef = current$fixed_W1_PEF_methods_zero &&
        current$fixed_W1_PEF_where_zero,
      c2_rules = object_id != "MI-C2" ||
        (
          identical(current$R_W2_method, "") &&
            current$W2_PEF_column_n == 0L &&
            isTRUE(current$R_W2_where_zero) &&
            isTRUE(current$R_W2_predictor_row_zero) &&
            isTRUE(current$R_W2_predicts_active) &&
            current$passive_age_W2_absent_from_mice
        )
    )
    if (!all(checks)) {
      stop(
        object_id, " production input contract failed: ",
        paste(names(checks)[!checks], collapse = ", "), call. = FALSE
      )
    }
    data.frame(
      object_id = object_id,
      denominator_n = current$denominator_n,
      input_column_n = current$input_column_n,
      active_target_n = current$active_target_n,
      imputed_cell_n_per_chain = sum(
        current$missing_contract$missing_n[
          current$missing_contract$column_name %in% current$active_targets
        ]
      ),
      seed = current$seed,
      canonical_data_sha256 = current$canonical_data_sha256,
      column_contract_sha256 = current$column_contract_sha256,
      missing_contract_sha256 = current$missing_contract_sha256,
      ordered_participant_id_sha256 =
        current$ordered_participant_id_sha256,
      specification_sha256 = current$specification_sha256,
      method_sha256 = current$method_sha256,
      predictor_sha256 = current$predictor_sha256,
      where_sha256 = current$where_sha256,
      visit_sha256 = current$visit_sha256,
      passive_sha256 = current$passive_sha256,
      pef_imputation_target_n = current$pef_imputation_target_n,
      status = "PASS",
      stringsAsFactors = FALSE
    )
  }))
  rownames(summary) <- NULL
  list(
    contract = list(
      contract_version = "v45_1_charls_production_mi",
      hash_rule = "canonical_UTF8_type_explicit_v1",
      where_rule =
        "raw_missingness_values_with_dimnames_exactly_equal_to_input",
      R_version = as.character(getRversion()),
      package_versions = c(
        digest = as.character(utils::packageVersion("digest")),
        dplyr = as.character(utils::packageVersion("dplyr")),
        mice = as.character(utils::packageVersion("mice")),
        yaml = as.character(utils::packageVersion("yaml"))
      ),
      RNGkind = c(
        kind = "Mersenne-Twister",
        normal_kind = "Inversion",
        sample_kind = "Rejection"
      ),
      predecessor_contract_sha256 =
        v45_charls_sha256_file(
          v45_charls_prod_paths(root)$predecessor_contract
        ),
      objects = contracts,
      outcome_model_fit_count = 0L,
      response_model_fit_count = 0L,
      pef_model_fit_count = 0L,
      coefficient_export_count = 0L,
      completed_data_persisted = FALSE
    ),
    summary = summary,
    authority = built$authority
  )
}

v45_charls_prod_component_table <- function(components) {
  required <- c(
    "canonical_source_input_data",
    "canonical_column_contract",
    "canonical_frozen_specification",
    "canonical_ordered_participant_ids",
    "canonical_imputation_payload",
    "canonical_chain_mean",
    "canonical_chain_variance",
    "canonical_categorical_trace",
    "canonical_final_convergence",
    "canonical_checkpoint_diagnostics",
    "canonical_released_trace",
    "mids_method",
    "mids_predictor_matrix",
    "mids_where",
    "mids_visit_sequence",
    "mids_last_seed_value"
  )
  if (!is.list(components) || is.null(names(components)) ||
      anyDuplicated(names(components)) ||
      !setequal(names(components), required) ||
      length(components) != length(required)) {
    stop("Production component-hash set is incomplete or duplicated.",
         call. = FALSE)
  }
  hashes <- unlist(components[required], use.names = FALSE)
  if (length(hashes) != length(required) ||
      any(!grepl("^[0-9a-f]{64}$", hashes))) {
    stop("Production component hashes are invalid.", call. = FALSE)
  }
  data.frame(
    component = required,
    sha256 = hashes,
    hash_rule = c(
      "canonical_data_frame_v1",
      rep("canonical_type_explicit_v1", length(required) - 1L)
    ),
    stringsAsFactors = FALSE
  )
}
