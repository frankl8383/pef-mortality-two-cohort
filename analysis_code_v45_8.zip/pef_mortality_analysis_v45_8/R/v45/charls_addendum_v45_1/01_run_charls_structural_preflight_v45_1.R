# Execute the CHARLS v45.1 synthetic, no-outcome structural preflight.

options(stringsAsFactors = FALSE)

script_path <- sub(
  "^--file=", "",
  grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)[[1L]]
)
root <- normalizePath(
  file.path(dirname(script_path), "..", "..", ".."),
  mustWork = TRUE
)
source(file.path(
  root, "R", "v45", "charls_addendum_v45_1",
  "charls_structural_utilities_v45_1.R"
))
v45_charls_activate_project_library(root)
if (!all(vapply(
  c("digest", "yaml", "survey"),
  requireNamespace, quietly = TRUE, FUN.VALUE = logical(1)
))) {
  stop("The frozen digest, yaml, and survey packages are required.", call. = FALSE)
}
source(file.path(
  root, "R", "v45", "charls_addendum_v45_1",
  "charls_pure_functions_v45_1.R"
))

verify <- system2(
  file.path(R.home("bin"), "Rscript"),
  c(
    "--vanilla",
    file.path(
      root, "R", "v45", "charls_addendum_v45_1",
      "00_freeze_charls_pure_preflight_v45_1.R"
    ),
    "--verify"
  ),
  stdout = TRUE, stderr = TRUE
)
verify_status <- attr(verify, "status")
if (!is.null(verify_status) && verify_status != 0L) {
  stop(
    "The CHARLS pure-preflight freeze failed verification: ",
    paste(verify, collapse = " | "), call. = FALSE
  )
}

work_dir <- file.path(root, "work_v45", "charls_addendum_v45_1")
result_dir <- file.path(root, "results", "v45", "charls_addendum_v45_1")
spec <- yaml::read_yaml(file.path(
  work_dir, "charls_pure_preflight_spec_v45_1.yml"
))
gate_path <- file.path(work_dir, "charls_addendum_gate_state_v45_1.yml")
gate <- yaml::read_yaml(gate_path)
if (!identical(gate$pure_function_freeze$status, "PASS") ||
    !identical(gate$structural_preflight$status, "NOT_RUN") ||
    isTRUE(gate$outcome_execution_allowed) ||
    isTRUE(gate$new_coefficient_inspection_allowed)) {
  stop("The isolated CHARLS addendum gate is not ready.", call. = FALSE)
}

result_paths <- c(
  matrix_contracts = file.path(
    result_dir, "charls_rao_wu_matrix_contracts_v45_1.tsv"
  ),
  structural = file.path(
    result_dir, "charls_structural_preflight_v45_1.tsv"
  ),
  interfaces = file.path(
    result_dir, "charls_synthetic_interface_validation_v45_1.tsv"
  ),
  w2_contract = file.path(
    result_dir, "charls_w2_structural_contract_validation_v45_1.tsv"
  ),
  contract = file.path(
    work_dir, "charls_structural_replicate_contract_v45_1.rds"
  ),
  run_log = file.path(
    work_dir, "charls_structural_preflight_run_log_v45_1.txt"
  )
)
if (any(file.exists(result_paths))) {
  stop("Structural preflight outputs already exist; refusing overwrite.",
       call. = FALSE)
}

main_paths <- c(
  analysis_registry = file.path(root, "work_v45", "v45_analysis_registry.tsv"),
  estimand_registry = file.path(root, "work_v45", "v45_estimand_registry.tsv"),
  seed_ledger = file.path(root, "work_v45", "v45_seed_ledger.tsv"),
  main_gate = file.path(root, "work_v45", "gate_state_v45.yml")
)
main_hash_before <- vapply(
  main_paths, v45_charls_sha256_file, character(1)
)

run_id <- paste0(
  "charls_v45_1_structural_",
  format(Sys.time(), "%Y%m%dT%H%M%S"), "_pid", Sys.getpid()
)
checks <- list()
add_check <- function(check, pass, observed, expected) {
  checks[[length(checks) + 1L]] <<- data.frame(
    check = check,
    status = if (isTRUE(pass)) "PASS" else "FAIL",
    observed = paste(observed, collapse = "; "),
    expected = paste(expected, collapse = "; "),
    run_id = run_id,
    stringsAsFactors = FALSE
  )
  if (!isTRUE(pass)) {
    stop(check, " failed.", call. = FALSE)
  }
}

module_specs <- list(
  trial = spec$modules$trial,
  adjacent = spec$modules$adjacent,
  w2 = spec$modules$w2
)
modules <- lapply(module_specs, function(x) {
  v45_charls_generate_subbootstrap(
    as.integer(x$psu), as.integer(x$seed), x$matrix_id
  )
})
modules_again <- lapply(module_specs, function(x) {
  v45_charls_generate_subbootstrap(
    as.integer(x$psu), as.integer(x$seed), x$matrix_id
  )
})
add_check(
  "same_seed_bitwise_regeneration",
  all(vapply(names(modules), function(name) {
    identical(modules[[name]]$matrix, modules_again[[name]]$matrix)
  }, logical(1))),
  paste(
    names(modules),
    vapply(modules, function(x) {
      substr(v45_charls_matrix_sha256(x$matrix), 1L, 16L)
    }, character(1)),
    collapse = "|"
  ),
  "all three matrices regenerate bitwise-identically"
)
rm(modules_again)

module_audits <- lapply(modules, v45_charls_module_audit)
add_check(
  "all_three_matrices_structurally_valid",
  all(vapply(
    module_audits, v45_charls_module_audit_pass, logical(1)
  )),
  paste(
    names(module_audits),
    vapply(module_audits, function(x) {
      paste0(
        "balance=", signif(x$balance_difference, 6),
        ",pass=", v45_charls_module_audit_pass(x)
      )
    }, character(1)),
    collapse = "|"
  ),
  "433x500, 433x500, 420x500; finite nonnegative; balanced; zero support; scale=1/499; rscales=1; MSE"
)

prefixes <- lapply(modules, v45_charls_prefix_module)
add_check(
  "literal_first_250_prefix_contract",
  all(vapply(names(modules), function(name) {
    identical(
      prefixes[[name]]$matrix,
      modules[[name]]$matrix[, seq_len(250L), drop = FALSE]
    ) &&
      identical(prefixes[[name]]$scale, 1 / 249) &&
      length(prefixes[[name]]$rscales) == 250L &&
      all(prefixes[[name]]$rscales == 1)
  }, logical(1))),
  "all literal prefixes match",
  "first 250 columns; scale=1/249; 250 unit rscales"
)
add_check(
  "module_seeds_and_matrices_distinct",
  length(unique(vapply(modules, `[[`, integer(1), "seed"))) == 3L &&
    length(unique(vapply(
      modules,
      function(x) v45_charls_matrix_sha256(x$matrix),
      character(1)
    ))) == 3L,
  paste(vapply(modules, `[[`, integer(1), "seed"), collapse = "|"),
  "three distinct frozen seeds and value hashes"
)

capture_with_replicates <- function(design, theta) {
  capture <- v45_charls_capture_interface(
    survey::withReplicates(
      design, theta = theta, return.replicates = TRUE
    )
  )
  if (inherits(capture$value, "error") || length(capture$warnings)) {
    detail <- if (inherits(capture$value, "error")) {
      conditionMessage(capture$value)
    } else {
      paste(capture$warnings, collapse = " | ")
    }
    stop("Synthetic interface failed: ", detail, call. = FALSE)
  }
  capture$value
}

trial_data <- modules$trial$skeleton
position <- trial_data$psu_position
trial_matrix <- cbind(
  trial1 = 280 + 0.9 * position + 18 * sin(position / 17),
  trial2 = 291 + 0.82 * position + 15 * cos(position / 23),
  trial3 = 286 + 0.86 * position + 13 * sin(position / 31 + 0.4)
)
trial_data$pef_max <- v45_charls_pure_library$authority_migrated$row_summary(
  trial_matrix, max
)
trial_data$pef_mean <- v45_charls_pure_library$authority_migrated$row_summary(
  trial_matrix, mean
)
trial_data$pef_median <- v45_charls_pure_library$authority_migrated$row_summary(
  trial_matrix, stats::median
)
trial_data$inconsistency <- log1p(
  v45_charls_pure_library$authority_migrated$top_two_difference(
    trial_matrix
  )
)
trial_theta <- function(weight, data) {
  c(
    max = sum(weight * data$pef_max) / sum(weight),
    mean = sum(weight * data$pef_mean) / sum(weight),
    median = sum(weight * data$pef_median) / sum(weight),
    inconsistency =
      sum(weight * data$inconsistency) / sum(weight)
  )
}
trial_full <- capture_with_replicates(
  v45_charls_make_repdesign(
    trial_data, "psu_key", "structural_weight", modules$trial
  ),
  trial_theta
)
trial_prefix <- capture_with_replicates(
  v45_charls_make_repdesign(
    trial_data, "psu_key", "structural_weight", prefixes$trial
  ),
  trial_theta
)
trial_prefix_match <- identical(
  unname(trial_prefix$replicates),
  unname(trial_full$replicates[seq_len(250L), , drop = FALSE])
)

adjacent_data <- modules$adjacent$skeleton
position <- adjacent_data$psu_position
adjacent_data$structural_weight <-
  0.75 + (position %% 19L) / 20
adjacent_data$synthetic_measure <-
  sin(position / 29) + log1p(position) / 20
adjacent_data$adjacent_domain <-
  adjacent_data$psu_position != max(adjacent_data$psu_position)
adjacent_theta <- function(weight, data) {
  keep <- data$adjacent_domain
  c(
    all = sum(weight * data$synthetic_measure) / sum(weight),
    adjacent = sum(
      weight[keep] * data$synthetic_measure[keep]
    ) / sum(weight[keep])
  )
}
adjacent_full <- capture_with_replicates(
  v45_charls_make_repdesign(
    adjacent_data, "psu_key", "structural_weight",
    modules$adjacent
  ),
  adjacent_theta
)
adjacent_prefix <- capture_with_replicates(
  v45_charls_make_repdesign(
    adjacent_data, "psu_key", "structural_weight",
    prefixes$adjacent
  ),
  adjacent_theta
)
adjacent_pair <- v45_charls_pure_library$structural_helpers$
  paired_replicate_covariance(
    adjacent_full$replicates,
    stats::coef(adjacent_full),
    modules$adjacent$scale,
    modules$adjacent$rscales
  )
adjacent_covariance_match <- isTRUE(all.equal(
  adjacent_pair$covariance,
  stats::vcov(adjacent_full),
  tolerance = 1e-12,
  check.attributes = FALSE
))
adjacent_delta_match <- isTRUE(all.equal(
  adjacent_pair$delta_variance_direct,
  adjacent_pair$delta_variance_quadratic,
  tolerance = 1e-12,
  check.attributes = FALSE
))
adjacent_prefix_match <- identical(
  unname(adjacent_prefix$replicates),
  unname(adjacent_full$replicates[
    seq_len(250L), , drop = FALSE
  ])
)
add_check(
  "adjacent_shared_replicate_covariance_and_pair_difference",
  adjacent_covariance_match &&
    adjacent_delta_match &&
    adjacent_prefix_match &&
    nrow(adjacent_full$replicates) == 500L &&
    all(is.finite(adjacent_full$replicates)),
  paste0(
    "covariance_match=", adjacent_covariance_match,
    "; delta_variance_match=", adjacent_delta_match,
    "; prefix_match=", adjacent_prefix_match
  ),
  "same replicate columns; paired difference within replicate; shared covariance identity"
)

w2_key <- modules$w2$skeleton
w2_data <- w2_key[rep(seq_len(nrow(w2_key)), each = 2L), , drop = FALSE]
w2_data$within_psu_row <- rep(1:2, times = nrow(w2_key))
w2_data$structural_weight <-
  0.8 + (w2_data$psu_position %% 17L) / 20 +
  w2_data$within_psu_row / 40
w2_data$D2_support <- TRUE
w2_data$R2_synthetic <- as.integer(
  w2_data$psu_position > 12L &
    (w2_data$within_psu_row == 1L |
       w2_data$psu_position %% 3L != 0L)
)
w2_data$availability_factor_synthetic <-
  1 + (w2_data$psu_position %% 23L) / 50 +
  w2_data$within_psu_row / 100
w2_data$synthetic_measure <-
  cos(w2_data$psu_position / 37) +
  w2_data$within_psu_row / 10
zero_response_psu <- sum(vapply(
  split(w2_data$R2_synthetic, as.character(w2_data$psu_key)),
  function(x) sum(x == 1L) == 0L,
  logical(1)
))
w2_ess <- v45_charls_pure_library$structural_helpers$
  same_respondent_ess_ratio(
    w2_data$structural_weight,
    w2_data$availability_factor_synthetic,
    w2_data$R2_synthetic
  )
w2_theta <- function(weight, data) {
  keep <- data$R2_synthetic == 1L
  ess <- v45_charls_pure_library$structural_helpers$
    same_respondent_ess_ratio(
      weight,
      data$availability_factor_synthetic,
      data$R2_synthetic
    )
  c(
    respondent_mean = sum(
      weight[keep] * data$synthetic_measure[keep]
    ) / sum(weight[keep]),
    ess_ratio = ess$ratio
  )
}
w2_full <- capture_with_replicates(
  v45_charls_make_repdesign(
    w2_data, "psu_key", "structural_weight", modules$w2
  ),
  w2_theta
)
w2_prefix <- capture_with_replicates(
  v45_charls_make_repdesign(
    w2_data, "psu_key", "structural_weight", prefixes$w2
  ),
  w2_theta
)
w2_prefix_match <- identical(
  unname(w2_prefix$replicates),
  unname(w2_full$replicates[seq_len(250L), , drop = FALSE])
)
add_check(
  "w2_D2_support_zero_response_and_same_R2_ESS_structure",
  all(w2_data$D2_support) &&
    length(unique(w2_data$psu_key)) ==
      as.integer(spec$w2_structural_contract$expected_supported_psu) &&
    zero_response_psu ==
      as.integer(spec$w2_structural_contract$expected_zero_response_psu) &&
    is.finite(w2_ess$ratio) &&
    w2_ess$ratio >=
      as.numeric(spec$w2_structural_contract$preferred_ratio_at_least) &&
    w2_prefix_match &&
    nrow(w2_full$replicates) == 500L &&
    all(is.finite(w2_full$replicates)),
  paste0(
    "supported_PSU=", length(unique(w2_data$psu_key)),
    "; zero_response_PSU=", zero_response_psu,
    "; synthetic_ESS_ratio=", signif(w2_ess$ratio, 8),
    "; prefix_match=", w2_prefix_match
  ),
  "D2_support contract; 12 synthetic zero-response PSUs; exact same-R2 ESS formula; finite full/prefix interfaces"
)

interfaces <- data.frame(
  interface_id = c(
    "trial_summary_same_sample",
    "adjacent_shared_covariance",
    "w2_D2_ESS_structure"
  ),
  module_id = c(
    modules$trial$matrix_id,
    modules$adjacent$matrix_id,
    modules$w2$matrix_id
  ),
  full_replicates = c(
    nrow(trial_full$replicates),
    nrow(adjacent_full$replicates),
    nrow(w2_full$replicates)
  ),
  prefix_replicates = c(
    nrow(trial_prefix$replicates),
    nrow(adjacent_prefix$replicates),
    nrow(w2_prefix$replicates)
  ),
  full_finite = c(
    all(is.finite(trial_full$replicates)),
    all(is.finite(adjacent_full$replicates)),
    all(is.finite(w2_full$replicates))
  ),
  prefix_finite = c(
    all(is.finite(trial_prefix$replicates)),
    all(is.finite(adjacent_prefix$replicates)),
    all(is.finite(w2_prefix$replicates))
  ),
  prefix_bitwise_match = c(
    trial_prefix_match, adjacent_prefix_match, w2_prefix_match
  ),
  full_replicate_value_sha256 = c(
    v45_charls_object_sha256(unname(trial_full$replicates)),
    v45_charls_object_sha256(unname(adjacent_full$replicates)),
    v45_charls_object_sha256(unname(w2_full$replicates))
  ),
  prefix_replicate_value_sha256 = c(
    v45_charls_object_sha256(unname(trial_prefix$replicates)),
    v45_charls_object_sha256(unname(adjacent_prefix$replicates)),
    v45_charls_object_sha256(unname(w2_prefix$replicates))
  ),
  status = ifelse(
    c(
      trial_prefix_match,
      adjacent_prefix_match && adjacent_covariance_match &&
        adjacent_delta_match,
      w2_prefix_match
    ),
    "PASS", "FAIL"
  ),
  stringsAsFactors = FALSE
)
add_check(
  "all_synthetic_interfaces_pass",
  all(interfaces$status == "PASS") &&
    all(interfaces$full_replicates == 500L) &&
    all(interfaces$prefix_replicates == 250L) &&
    all(interfaces$full_finite) &&
    all(interfaces$prefix_finite),
  paste(interfaces$interface_id, interfaces$status, collapse = "|"),
  "three no-outcome interfaces pass 500 and literal first-250 contracts"
)

w2_validation <- data.frame(
  check = c(
    "D2_support_schema",
    "supported_PSU_anchor",
    "zero_response_PSU_anchor",
    "same_R2_ESS_denominator",
    "same_R2_ESS_formula",
    "actual_response_fit_count",
    "actual_outcome_fit_count"
  ),
  observed = c(
    "logical all TRUE in synthetic contract",
    as.character(length(unique(w2_data$psu_key))),
    as.character(zero_response_psu),
    paste0("respondent_n=", w2_ess$respondent_n),
    sprintf("%.17g", w2_ess$ratio),
    "0", "0"
  ),
  expected = c(
    "D2_support required before any later response fit",
    as.character(spec$w2_structural_contract$expected_supported_psu),
    as.character(spec$w2_structural_contract$expected_zero_response_psu),
    "base and composite Kish ESS use identical R2 rows",
    "ESS(base*availability among R2)/ESS(base among same R2)",
    "0", "0"
  ),
  status = "PASS",
  run_id = run_id,
  stringsAsFactors = FALSE
)

main_hash_after <- vapply(
  main_paths, v45_charls_sha256_file, character(1)
)
add_check(
  "main_stage0_registries_seed_and_gate_unchanged",
  identical(main_hash_before, main_hash_after),
  paste(names(main_hash_after), substr(main_hash_after, 1L, 12L),
        collapse = "|"),
  "all four hashes identical before and after structural execution"
)
add_check(
  "no_actual_CHARLS_rows_or_outcomes_opened",
  TRUE,
  "row_level_load_count=0; actual_response_fit_count=0; actual_outcome_fit_count=0; coefficient_release_count=0",
  "all counts zero"
)

module_contracts <- do.call(rbind, lapply(names(modules), function(name) {
  module <- modules[[name]]
  prefix <- prefixes[[name]]
  audit <- module_audits[[name]]
  data.frame(
    module = name,
    matrix_id = module$matrix_id,
    seed = module$seed,
    psu = module$psu_n,
    replicates = ncol(module$matrix),
    design_df = module$degf,
    scale = sprintf("%.17g", module$scale),
    prefix_replicates = ncol(prefix$matrix),
    prefix_scale = sprintf("%.17g", prefix$scale),
    matrix_sha256 = v45_charls_matrix_sha256(module$matrix),
    prefix_matrix_sha256 = v45_charls_matrix_sha256(prefix$matrix),
    multiplier_value_sha256 = v45_charls_object_sha256(
      unname(module$matrix)
    ),
    prefix_multiplier_value_sha256 = v45_charls_object_sha256(
      unname(prefix$matrix)
    ),
    maximum_balance_difference = audit$balance_difference,
    status = if (v45_charls_module_audit_pass(audit)) "PASS" else "FAIL",
    run_id = run_id,
    stringsAsFactors = FALSE
  )
}))

contract <- list(
  contract_version = "v45_1_charls_pure_stage1",
  design_key_role = "synthetic_ordinal_only_not_production_mapping",
  production_use_allowed = FALSE,
  actual_row_level_data_opened = FALSE,
  actual_response_or_outcome_values_opened = FALSE,
  main_file_hashes_before = main_hash_before,
  main_file_hashes_after = main_hash_after,
  modules = modules,
  interface_hashes = interfaces[, c(
    "interface_id", "module_id",
    "full_replicate_value_sha256",
    "prefix_replicate_value_sha256"
  )],
  w2_structural = list(
    supported_psu = length(unique(w2_data$psu_key)),
    zero_response_psu = zero_response_psu,
    same_r2_ess_ratio_synthetic = w2_ess$ratio,
    fatal_ratio_below =
      as.numeric(spec$w2_structural_contract$fatal_ratio_below),
    preferred_ratio_at_least =
      as.numeric(spec$w2_structural_contract$preferred_ratio_at_least),
    actual_response_model_fit_count = 0L,
    actual_outcome_model_fit_count = 0L
  ),
  adjacent_structure = list(
    same_matrix_and_replicate_column = TRUE,
    covariance = adjacent_pair$covariance,
    delta_variance_direct = adjacent_pair$delta_variance_direct,
    delta_variance_quadratic = adjacent_pair$delta_variance_quadratic
  )
)

structural <- do.call(rbind, checks)
if (any(structural$status != "PASS") ||
    any(module_contracts$status != "PASS") ||
    any(interfaces$status != "PASS") ||
    any(w2_validation$status != "PASS")) {
  stop("One or more structural outputs failed before publication.",
       call. = FALSE)
}

v45_charls_atomic_save_rds(contract, result_paths[["contract"]])
v45_charls_atomic_write_tsv(
  module_contracts, result_paths[["matrix_contracts"]]
)
v45_charls_atomic_write_tsv(
  structural, result_paths[["structural"]]
)
v45_charls_atomic_write_tsv(
  interfaces, result_paths[["interfaces"]]
)
v45_charls_atomic_write_tsv(
  w2_validation, result_paths[["w2_contract"]]
)
v45_charls_atomic_write_lines(c(
  paste0("run_id: ", run_id),
  "actual_row_level_data_opened: false",
  "actual_response_values_opened: false",
  "actual_death_or_followup_values_opened: false",
  "actual_response_model_fit_count: 0",
  "actual_outcome_model_fit_count: 0",
  "new_coefficient_release_count: 0",
  "matrix_design_key_role: synthetic_ordinal_only_not_production_mapping",
  "production_use_allowed: false",
  paste0("checks_passed: ", nrow(structural)),
  paste0("interfaces_passed: ", nrow(interfaces))
), result_paths[["run_log"]])

gate$updated_at_utc <- format(
  Sys.time(), "%Y-%m-%dT%H:%M:%SZ", tz = "UTC"
)
gate$structural_preflight <- list(status = "PASS")
gate$independent_validation <- list(status = "NOT_RUN")
gate$actual_design_key_binding <- list(status = "NOT_RUN")
gate$outcome_execution_allowed <- FALSE
gate$new_coefficient_inspection_allowed <- FALSE
gate$next_authorized_step <-
  "independently_validate_CHARLS_synthetic_structural_preflight"
v45_charls_atomic_write_yaml(gate, gate_path)

message(
  "CHARLS v45.1 synthetic structural preflight PASS; outcome execution ",
  "remains blocked."
)
