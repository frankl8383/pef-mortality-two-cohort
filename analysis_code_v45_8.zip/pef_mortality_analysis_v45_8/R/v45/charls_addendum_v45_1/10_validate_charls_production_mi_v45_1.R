#!/usr/bin/env Rscript

# Independent, read-only validation of CHARLS v45.1 production MI-C0/MI-C2.
# This script consumes no random numbers, generates no imputations, fits no
# model, and creates no coefficient.

options(stringsAsFactors = FALSE, warn = 2)

rng_state_at_start <- list(
  exists = exists(".Random.seed", envir = .GlobalEnv, inherits = FALSE),
  value = if (exists(".Random.seed", envir = .GlobalEnv, inherits = FALSE)) {
    get(".Random.seed", envir = .GlobalEnv, inherits = FALSE)
  } else {
    NULL
  },
  kind = RNGkind()
)

script_path <- sub(
  "^--file=", "",
  grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)[[1L]]
)
root <- normalizePath(
  file.path(dirname(script_path), "..", "..", ".."),
  mustWork = TRUE
)
frozen_library <- file.path(
  root, "work_v43", "renv", "library", "macos", "R-4.5",
  "aarch64-apple-darwin20"
)
if (!dir.exists(frozen_library)) {
  stop("The frozen CHARLS R library is absent.", call. = FALSE)
}
.libPaths(unique(c(normalizePath(frozen_library, mustWork = TRUE), .libPaths())))
expected_package_versions <- c(
  digest = "0.6.37", dplyr = "1.1.4",
  mice = "3.19.0", yaml = "2.3.10"
)
for (package in names(expected_package_versions)) {
  if (!requireNamespace(package, quietly = TRUE)) {
    stop("Independent CHARLS validation requires package: ", package,
         call. = FALSE)
  }
}
if (!identical(as.character(getRversion()), "4.5.1") ||
    !all(vapply(names(expected_package_versions), function(package) {
      identical(
        as.character(utils::packageVersion(package)),
        expected_package_versions[[package]]
      )
    }, logical(1)))) {
  stop("Independent CHARLS validation runtime drifted.", call. = FALSE)
}
source(file.path(
  root, "R/v45/independent_mi_validation_helpers_v45.R"
))

stop_iv <- function(...) stop(..., call. = FALSE)

sha256_file <- function(path) {
  if (!file.exists(path) || dir.exists(path) || nzchar(Sys.readlink(path))) {
    return(NA_character_)
  }
  digest::digest(path, algo = "sha256", file = TRUE)
}

regular_file <- function(path) {
  file.exists(path) && !dir.exists(path) && !nzchar(Sys.readlink(path))
}

read_tsv_stable <- function(path, label = basename(path)) {
  if (!regular_file(path)) stop_iv(label, " is absent.")
  before <- sha256_file(path)
  data <- utils::read.delim(
    path, stringsAsFactors = FALSE, check.names = FALSE
  )
  after <- sha256_file(path)
  if (!identical(before, after)) stop_iv(label, " changed while read.")
  list(data = data, sha256 = before)
}

read_rds_stable <- function(path, label = basename(path)) {
  if (!regular_file(path)) stop_iv(label, " is absent.")
  before <- sha256_file(path)
  data <- readRDS(path)
  after <- sha256_file(path)
  if (!identical(before, after)) stop_iv(label, " changed while read.")
  list(data = data, sha256 = before)
}

is_no <- function(value) {
  identical(value, FALSE) ||
    (length(value) == 1L && !is.na(value) &&
       tolower(as.character(value)) %in% c("no", "false"))
}

rng_state_unchanged <- function() {
  current_exists <-
    exists(".Random.seed", envir = .GlobalEnv, inherits = FALSE)
  current_value <- if (current_exists) {
    get(".Random.seed", envir = .GlobalEnv, inherits = FALSE)
  } else {
    NULL
  }
  identical(current_exists, rng_state_at_start$exists) &&
    identical(current_value, rng_state_at_start$value) &&
    identical(RNGkind(), rng_state_at_start$kind)
}

manifest_root <- function(data, key, fields) {
  data <- data[order(data[[key]], method = "radix"), fields, drop = FALSE]
  rows <- apply(data, 1L, function(value) {
    paste(value, collapse = "\u241f")
  })
  iv_canonical_text_sha256(rows)
}

safe_alias <- function(alias, allowed_prefix, regular = TRUE) {
  if (length(alias) != 1L || is.na(alias) || !nzchar(alias) ||
      startsWith(alias, "/") ||
      any(strsplit(alias, "/", fixed = TRUE)[[1L]] %in% c("", ".", ".."))) {
    stop_iv("Unsafe path alias: ", alias)
  }
  path <- file.path(root, alias)
  if (regular && !regular_file(path)) stop_iv("File is absent: ", alias)
  if (!regular && !dir.exists(path)) stop_iv("Directory is absent: ", alias)
  resolved <- normalizePath(path, mustWork = TRUE)
  allowed <- normalizePath(file.path(root, allowed_prefix), mustWork = TRUE)
  if (!identical(resolved, allowed) &&
      !startsWith(resolved, paste0(allowed, .Platform$file.sep))) {
    stop_iv("Path escapes its allowed prefix: ", alias)
  }
  resolved
}

atomic_write_tsv <- function(data, path) {
  dir.create(dirname(path), recursive = TRUE, showWarnings = FALSE)
  tmp <- tempfile(paste0(".", basename(path), "."), tmpdir = dirname(path))
  on.exit(if (file.exists(tmp)) unlink(tmp, force = TRUE), add = TRUE)
  utils::write.table(
    data, tmp, sep = "\t", row.names = FALSE, quote = FALSE, na = ""
  )
  if (!file.rename(tmp, path)) stop_iv("Atomic TSV promotion failed.")
  invisible(path)
}

atomic_write_lines <- function(lines, path) {
  dir.create(dirname(path), recursive = TRUE, showWarnings = FALSE)
  tmp <- tempfile(paste0(".", basename(path), "."), tmpdir = dirname(path))
  on.exit(if (file.exists(tmp)) unlink(tmp, force = TRUE), add = TRUE)
  writeLines(lines, tmp, useBytes = TRUE)
  if (!file.rename(tmp, path)) stop_iv("Atomic text promotion failed.")
  invisible(path)
}

atomic_write_yaml <- function(value, path) {
  dir.create(dirname(path), recursive = TRUE, showWarnings = FALSE)
  tmp <- tempfile(paste0(".", basename(path), "."), tmpdir = dirname(path))
  on.exit(if (file.exists(tmp)) unlink(tmp, force = TRUE), add = TRUE)
  yaml::write_yaml(value, tmp)
  if (!file.rename(tmp, path)) stop_iv("Atomic YAML promotion failed.")
  invisible(path)
}

function_hash_from_file <- function(path, function_name) {
  expressions <- parse(path, keep.source = FALSE)
  matches <- Filter(function(expression) {
    is.call(expression) && length(expression) == 3L &&
      identical(as.character(expression[[1L]]), "<-") &&
      is.symbol(expression[[2L]]) &&
      identical(as.character(expression[[2L]]), function_name) &&
      is.call(expression[[3L]]) &&
      identical(as.character(expression[[3L]][[1L]]), "function")
  }, as.list(expressions))
  if (length(matches) != 1L) {
    stop_iv(
      "Expected one frozen function ", function_name,
      "; observed ", length(matches), "."
    )
  }
  function_value <- eval(matches[[1L]][[3L]], envir = new.env(parent = baseenv()))
  iv_canonical_text_sha256(c(
    deparse(formals(function_value), width.cutoff = 500L),
    deparse(body(function_value), width.cutoff = 500L)
  ))
}

execute <- function() {
work <- file.path(root, "work_v45", "charls_addendum_v45_1")
result <- file.path(root, "results", "v45", "charls_addendum_v45_1")
restricted <- file.path(
  root, "derived_sensitive", "v45", "charls_addendum_v45_1"
)
gate_path <- file.path(work, "charls_production_mi_gate_state_v45_1.yml")
gate_sha_start <- sha256_file(gate_path)
gate <- yaml::read_yaml(gate_path)
if (!identical(as.character(gate$freeze$status), "PASS") ||
    !as.character(gate$charls_production_mi_execution$status) %in%
      c("GENERATED_ALL_AWAITING_INDEPENDENT_VALIDATION",
        "INDEPENDENT_VALIDATION_PASS") ||
    !is_no(gate$outcome_execution_allowed) ||
    !is_no(gate$new_coefficient_inspection_allowed)) {
  stop_iv("The isolated CHARLS gate is not ready for independent validation.")
}
gate_objects <- gate$charls_production_mi_execution$objects
if (!is.list(gate_objects) ||
    !setequal(names(gate_objects), c("MI-C0", "MI-C2")) ||
    length(gate_objects) != 2L) {
  stop_iv("The isolated CHARLS gate does not bind exactly two objects.")
}
validation_lock_parent <- file.path(restricted, "production_mi")
dir.create(validation_lock_parent, recursive = TRUE, showWarnings = FALSE)
validation_lock <- file.path(
  validation_lock_parent, ".charls_production_mi_validation.lock"
)
if (!dir.create(validation_lock, showWarnings = FALSE)) {
  stop_iv("Another CHARLS production-MI validator holds the lock.")
}
validation_id <- paste0(
  "charls_v45_1_production_mi_independent_",
  format(Sys.time(), "%Y%m%dT%H%M%S"), "_pid", Sys.getpid()
)
validation_lock_owner <- file.path(validation_lock, "owner.tsv")
atomic_write_tsv(
  data.frame(
    validation_id = validation_id, pid = Sys.getpid(),
    acquired_at_utc =
      format(Sys.time(), "%Y-%m-%dT%H:%M:%SZ", tz = "UTC"),
    stringsAsFactors = FALSE
  ),
  validation_lock_owner
)
validation_lock_owner_sha <- sha256_file(validation_lock_owner)
on.exit(
  if (dir.exists(validation_lock) &&
      identical(
        sha256_file(validation_lock_owner),
        validation_lock_owner_sha
      )) {
    unlink(validation_lock, recursive = TRUE, force = TRUE)
  },
  add = TRUE
)
stale_transactions <- list.files(
  validation_lock_parent,
  pattern = "^\\.(transaction|validation_transaction)_.*\\.yml$",
  all.files = TRUE, full.names = TRUE
)
if (length(stale_transactions)) {
  stop_iv(
    "An interrupted CHARLS transaction requires audit: ",
    paste(basename(stale_transactions), collapse = ", ")
  )
}

freeze_output <- read_tsv_stable(file.path(
  result, "charls_production_mi_freeze_output_manifest_v45_1.tsv"
), "freeze output manifest")$data
if (nrow(freeze_output) != 6L ||
    anyDuplicated(freeze_output$asset_id) ||
    any(freeze_output$validation_status != "PASS") ||
    !all(vapply(seq_len(nrow(freeze_output)), function(index) {
      path <- safe_alias(
        freeze_output$path_alias[[index]],
        if (freeze_output$asset_id[[index]] == "input_contract") {
          "derived_sensitive/v45/charls_addendum_v45_1"
        } else if (freeze_output$asset_id[[index]] %in%
                   c("code", "functions", "roots")) {
          "work_v45/charls_addendum_v45_1"
        } else {
          "results/v45/charls_addendum_v45_1"
        }
      )
      identical(
        as.numeric(file.info(path)$size),
        as.numeric(freeze_output$bytes[[index]])
      ) &&
        identical(sha256_file(path), freeze_output$sha256[[index]])
    }, logical(1)))) {
  stop_iv("The production freeze output manifest failed rehashing.")
}

code <- read_tsv_stable(file.path(
  work, "charls_production_mi_code_manifest_v45_1.tsv"
), "production code manifest")$data
if (anyDuplicated(code$asset_id) || any(code$status != "PASS") ||
    !all(vapply(seq_len(nrow(code)), function(index) {
      path <- safe_alias(code$path_alias[[index]], "")
      identical(
        as.numeric(file.info(path)$size),
        as.numeric(code$bytes[[index]])
      ) && identical(sha256_file(path), code$sha256[[index]])
    }, logical(1)))) {
  stop_iv("The frozen production code closure drifted.")
}

functions <- read_tsv_stable(file.path(
  work, "charls_production_mi_function_manifest_v45_1.tsv"
), "production function manifest")$data
function_ok <- !anyDuplicated(functions$asset_id) &&
  all(functions$status == "PASS") &&
  all(vapply(seq_len(nrow(functions)), function(index) {
    path <- safe_alias(functions$source[[index]], "")
    identical(
      sha256_file(path), as.character(functions$source_sha256[[index]])
    ) &&
      identical(
        function_hash_from_file(path, functions$function_name[[index]]),
        as.character(functions$function_sha256[[index]])
      )
  }, logical(1)))
if (!function_ok) stop_iv("The frozen production function closure drifted.")

input <- read_rds_stable(file.path(
  restricted, "charls_production_mi_input_contract_v45_1.rds"
), "production input contract")
input_contract <- input$data
if (!identical(input_contract$contract_version,
               "v45_1_charls_production_mi") ||
    !identical(input_contract$R_version, "4.5.1") ||
    !identical(
      names(input_contract$package_versions),
      names(expected_package_versions)
    ) ||
    !identical(
      unname(input_contract$package_versions),
      unname(expected_package_versions)
    ) ||
    !identical(as.integer(input_contract$outcome_model_fit_count), 0L) ||
    !identical(as.integer(input_contract$response_model_fit_count), 0L) ||
    !identical(as.integer(input_contract$pef_model_fit_count), 0L) ||
    !identical(as.integer(input_contract$coefficient_export_count), 0L) ||
    !identical(input_contract$completed_data_persisted, FALSE)) {
  stop_iv("The frozen production input governance contract is invalid.")
}

roots <- read_tsv_stable(file.path(
  work, "charls_production_mi_freeze_roots_v45_1.tsv"
), "production roots")$data
root_value <- function(id) {
  row <- roots[roots$root_id == id, , drop = FALSE]
  if (nrow(row) != 1L) stop_iv("Missing production root: ", id)
  as.character(row$sha256)
}
pre_runner <- read_tsv_stable(file.path(
  result, "charls_actual_keys_mi_output_manifest_v45_1.tsv"
), "predecessor runner manifest")$data
pre_independent <- read_tsv_stable(file.path(
  result, "charls_actual_keys_mi_independent_output_manifest_v45_1.tsv"
), "predecessor independent manifest")$data
predecessor_assets_ok <- all(vapply(
  seq_len(nrow(pre_runner)), function(index) {
    path <- safe_alias(
      pre_runner$path_alias[[index]],
      if (grepl("^derived_sensitive/", pre_runner$path_alias[[index]])) {
        "derived_sensitive/v45/charls_addendum_v45_1"
      } else if (grepl("^output/qa/", pre_runner$path_alias[[index]])) {
        "output/qa/v45/charls_addendum_v45_1"
      } else {
        "results/v45/charls_addendum_v45_1"
      }
    )
    identical(
      as.numeric(file.info(path)$size),
      as.numeric(pre_runner$bytes[[index]])
    ) && identical(sha256_file(path), pre_runner$sha256[[index]])
  }, logical(1)
)) && all(vapply(seq_len(nrow(pre_independent)), function(index) {
  path <- safe_alias(
    pre_independent$path_alias[[index]],
    if (grepl("^output/qa/", pre_independent$path_alias[[index]])) {
      "output/qa/v45/charls_addendum_v45_1"
    } else {
      "results/v45/charls_addendum_v45_1"
    }
  )
  identical(
    as.numeric(file.info(path)$size),
    as.numeric(pre_independent$bytes[[index]])
  ) && identical(sha256_file(path), pre_independent$sha256[[index]])
}, logical(1)))
if (!predecessor_assets_ok) {
  stop_iv("A predecessor validated output drifted.")
}
pre_rows <- rbind(
  data.frame(
    bundle = "runner", asset_id = pre_runner$asset_id,
    path_alias = pre_runner$path_alias, bytes = pre_runner$bytes,
    sha256 = pre_runner$sha256, stringsAsFactors = FALSE
  ),
  data.frame(
    bundle = "independent", asset_id = pre_independent$asset_id,
    path_alias = pre_independent$path_alias, bytes = pre_independent$bytes,
    sha256 = pre_independent$sha256, stringsAsFactors = FALSE
  )
)
root_checks <- c(
  code = identical(
    root_value("charls_production_mi_code_root"),
    manifest_root(
      code, "asset_id",
      c(
        "asset_id", "path_alias", "bytes", "sha256",
        "immutable", "authorized_purpose", "status"
      )
    )
  ),
  functions = identical(
    root_value("charls_production_mi_function_root"),
    manifest_root(
      functions, "asset_id",
      c(
        "asset_id", "function_name", "source",
        "source_sha256", "function_sha256", "status"
      )
    )
  ),
  input = identical(
    root_value("charls_production_mi_input_root"),
    iv_canonical_object_sha256(input_contract)
  ),
  predecessor = identical(
    root_value("charls_predecessor_validated_output_root"),
    manifest_root(
      pre_rows, "asset_id",
      c("bundle", "asset_id", "path_alias", "bytes", "sha256")
    )
  ),
  validation_file = identical(
    root_value("charls_production_mi_freeze_validation_file"),
    sha256_file(file.path(
      result, "charls_production_mi_freeze_validation_v45_1.tsv"
    ))
  )
)
actual_roots <- read_tsv_stable(file.path(
  work, "charls_actual_keys_mi_freeze_roots_v45_1.tsv"
), "actual-key roots")$data
for (id in c(
  "actual_keys_mi_code_root",
  "actual_keys_mi_function_root",
  "restricted_source_root"
)) {
  prior <- actual_roots[actual_roots$root_id == id, , drop = FALSE]
  root_checks[[paste0("prior_", id)]] <-
    nrow(prior) == 1L &&
      identical(root_value(paste0("charls_", id)),
                as.character(prior$sha256))
}
if (!all(root_checks)) {
  stop_iv(
    "Independent production-root validation failed: ",
    paste(names(root_checks)[!root_checks], collapse = ", ")
  )
}

standard_mids_names <- c(
  "data", "imp", "m", "where", "blocks", "call", "nmis", "method",
  "predictorMatrix", "visitSequence", "formulas", "calltype", "post",
  "blots", "ignore", "seed", "iteration", "lastSeedValue", "chainMean",
  "chainVar", "loggedEvents", "version", "date"
)
required_components <- c(
  "canonical_source_input_data", "canonical_column_contract",
  "canonical_frozen_specification", "canonical_ordered_participant_ids",
  "canonical_imputation_payload", "canonical_chain_mean",
  "canonical_chain_variance", "canonical_categorical_trace",
  "canonical_final_convergence", "canonical_checkpoint_diagnostics",
  "canonical_released_trace", "mids_method", "mids_predictor_matrix",
  "mids_where", "mids_visit_sequence", "mids_last_seed_value",
  "final_mids_file"
)

load_object <- function(object_id) {
  token <- gsub("-", "_", object_id)
  pointer_path <- file.path(
    result, "production_mi", paste0(token, "_m50_current.tsv")
  )
  pointer <- read_tsv_stable(pointer_path, paste0(object_id, " pointer"))
  p <- pointer$data
  required_pointer <- c(
    "object_id", "requested_m", "run_id", "run_manifest_path_alias",
    "run_output_manifest_path_alias", "run_output_manifest_sha256",
    "mids_path_alias", "mids_sha256", "status"
  )
  if (!identical(names(p), required_pointer) || nrow(p) != 1L ||
      !identical(as.character(p$object_id), object_id) ||
      !identical(as.integer(p$requested_m), 50L) ||
      !as.character(p$status) %in%
        c("GENERATED_AWAITING_INDEPENDENT_VALIDATION",
          "INDEPENDENT_VALIDATION_PASS") ||
      !grepl("^[0-9a-f]{64}$", p$mids_sha256) ||
      !grepl("^[0-9a-f]{64}$", p$run_output_manifest_sha256)) {
    stop_iv(object_id, " pointer is malformed.")
  }
  run_id <- as.character(p$run_id)
  gate_object <- gate_objects[[object_id]]
  required_gate_object <- c(
    "status", "m", "run_id", "selected_maxit", "mids_sha256",
    "run_output_manifest_sha256"
  )
  if (!is.list(gate_object) ||
      !identical(names(gate_object), required_gate_object) ||
      !as.character(gate_object$status) %in%
        c("GENERATED_AWAITING_INDEPENDENT_VALIDATION",
          "INDEPENDENT_VALIDATION_PASS") ||
      !identical(as.integer(gate_object$m), 50L) ||
      !identical(as.character(gate_object$run_id), run_id) ||
      !identical(as.character(gate_object$mids_sha256),
                 as.character(p$mids_sha256)) ||
      !identical(
        as.character(gate_object$run_output_manifest_sha256),
        as.character(p$run_output_manifest_sha256)
      )) {
    stop_iv(object_id, " gate object differs from the current pointer.")
  }
  result_alias <- file.path(
    "results/v45/charls_addendum_v45_1/production_mi",
    object_id, "m50", run_id
  )
  mids_alias <- file.path(
    "derived_sensitive/v45/charls_addendum_v45_1/production_mi",
    object_id, "m50", run_id, paste0(object_id, "_m50.mids.rds")
  )
  if (!identical(p$run_manifest_path_alias,
                 file.path(result_alias, "run_manifest.tsv")) ||
      !identical(p$run_output_manifest_path_alias,
                 file.path(result_alias, "run_output_manifest.tsv")) ||
      !identical(p$mids_path_alias, mids_alias)) {
    stop_iv(object_id, " pointer aliases differ from the frozen layout.")
  }
  result_dir <- safe_alias(
    result_alias,
    file.path(
      "results/v45/charls_addendum_v45_1/production_mi",
      object_id, "m50"
    ),
    regular = FALSE
  )
  mids_path <- safe_alias(
    mids_alias,
    file.path(
      "derived_sensitive/v45/charls_addendum_v45_1/production_mi",
      object_id, "m50"
    )
  )
  restricted_children <- list.files(
    dirname(dirname(mids_path)), all.files = TRUE, no.. = TRUE,
    full.names = FALSE
  )
  result_children <- list.files(
    dirname(result_dir), all.files = TRUE, no.. = TRUE,
    full.names = FALSE
  )
  if (!identical(restricted_children, run_id) ||
      !identical(result_children, run_id)) {
    stop_iv(object_id, " orphaned or extra m50 run directories exist.")
  }
  restricted_run_files <- list.files(
    dirname(mids_path), all.files = TRUE, no.. = TRUE,
    full.names = TRUE
  )
  expected_result_files <- c(
    "run_manifest.tsv", "component_hashes.tsv",
    "structural_checks.tsv", "checkpoint_diagnostics.tsv",
    "final_convergence.tsv", "released_chain_trace.tsv",
    "completion_chain_audit.tsv", "completion_summary.tsv",
    "run.log", "run_output_manifest.tsv"
  )
  result_run_files <- list.files(
    result_dir, all.files = TRUE, no.. = TRUE, full.names = TRUE
  )
  if (length(restricted_run_files) != 1L ||
      !identical(basename(restricted_run_files), basename(mids_path)) ||
      !regular_file(restricted_run_files) ||
      length(result_run_files) != length(expected_result_files) ||
      !setequal(basename(result_run_files), expected_result_files) ||
      !all(vapply(result_run_files, regular_file, logical(1)))) {
    stop_iv(object_id, " production run directory allowlist failed.")
  }
  run_output_path <- file.path(result_dir, "run_output_manifest.tsv")
  if (!identical(sha256_file(run_output_path),
                 as.character(p$run_output_manifest_sha256))) {
    stop_iv(object_id, " run-output manifest hash differs from pointer.")
  }
  run_output <- read_tsv_stable(
    run_output_path, paste0(object_id, " run-output manifest")
  )$data
  expected_run_aliases <- c(
    mids = mids_alias,
    run_manifest = file.path(result_alias, "run_manifest.tsv"),
    component_hashes = file.path(result_alias, "component_hashes.tsv"),
    structural_checks = file.path(result_alias, "structural_checks.tsv"),
    checkpoint_diagnostics =
      file.path(result_alias, "checkpoint_diagnostics.tsv"),
    final_convergence = file.path(result_alias, "final_convergence.tsv"),
    released_chain_trace =
      file.path(result_alias, "released_chain_trace.tsv"),
    completion_chain_audit =
      file.path(result_alias, "completion_chain_audit.tsv"),
    completion_summary =
      file.path(result_alias, "completion_summary.tsv"),
    run_log = file.path(result_alias, "run.log")
  )
  expected_access <- c(
    mids = "restricted_mids",
    setNames(rep("aggregate", 9L), names(expected_run_aliases)[-1L])
  )
  if (nrow(run_output) != 10L ||
      anyDuplicated(run_output$asset_id) ||
      any(run_output$validation_status != "PASS") ||
      !setequal(run_output$asset_id, names(expected_run_aliases)) ||
      !all(vapply(seq_len(nrow(run_output)), function(index) {
        asset_id <- as.character(run_output$asset_id[[index]])
        identical(
          as.character(run_output$path_alias[[index]]),
          unname(expected_run_aliases[[asset_id]])
        ) &&
          identical(
            as.character(run_output$access[[index]]),
            unname(expected_access[[asset_id]])
          )
      }, logical(1))) ||
      !all(vapply(seq_len(nrow(run_output)), function(index) {
        alias <- as.character(run_output$path_alias[[index]])
        path <- safe_alias(
          alias,
          if (run_output$asset_id[[index]] == "mids") {
            file.path(
              "derived_sensitive/v45/charls_addendum_v45_1/production_mi",
              object_id, "m50"
            )
          } else {
            file.path(
              "results/v45/charls_addendum_v45_1/production_mi",
              object_id, "m50"
            )
          }
        )
        identical(
          as.numeric(file.info(path)$size),
          as.numeric(run_output$bytes[[index]])
        ) && identical(sha256_file(path), run_output$sha256[[index]])
      }, logical(1)))) {
    stop_iv(object_id, " run-output manifest failed independent rehashing.")
  }
  mids_output_row <- run_output[
    run_output$asset_id == "mids", , drop = FALSE
  ]
  if (nrow(mids_output_row) != 1L ||
      !identical(as.character(mids_output_row$sha256),
                 as.character(p$mids_sha256))) {
    stop_iv(object_id, " manifest mids row differs from the pointer.")
  }
  run_manifest <- read_tsv_stable(
    file.path(result_dir, "run_manifest.tsv"),
    paste0(object_id, " run manifest")
  )$data
  component <- read_tsv_stable(
    file.path(result_dir, "component_hashes.tsv"),
    paste0(object_id, " component manifest")
  )$data
  completion_audit <- read_tsv_stable(
    file.path(result_dir, "completion_chain_audit.tsv"),
    paste0(object_id, " completion-chain audit")
  )$data
  completion_summary <- read_tsv_stable(
    file.path(result_dir, "completion_summary.tsv"),
    paste0(object_id, " completion summary")
  )$data
  if (nrow(run_manifest) != 1L ||
      !identical(as.character(run_manifest$object_id), object_id) ||
      !identical(as.integer(run_manifest$requested_m), 50L) ||
      !identical(as.character(run_manifest$run_id), run_id) ||
      !identical(
        as.integer(run_manifest$selected_maxit),
        as.integer(gate_object$selected_maxit)
      ) ||
      !identical(as.character(run_manifest$mids_path_alias), mids_alias) ||
      !identical(as.character(run_manifest$result_path_alias), result_alias) ||
      !identical(as.integer(run_manifest$warning_count), 0L) ||
      !identical(as.integer(run_manifest$logged_event_count), 0L) ||
      any(as.integer(run_manifest[c(
        "outcome_model_fit_count", "response_model_fit_count",
        "pef_model_fit_count", "coefficient_export_count",
        "completed_dataset_persistence_count"
      )]) != 0L) ||
      !identical(
        as.character(run_manifest$status),
        "GENERATED_AWAITING_INDEPENDENT_VALIDATION"
      ) ||
      nrow(component) != 17L ||
      anyDuplicated(component$component) ||
      !setequal(component$component, required_components) ||
      any(!grepl("^[0-9a-f]{64}$", component$sha256)) ||
      nrow(completion_audit) != 50L ||
      !identical(as.integer(completion_audit$chain), seq_len(50L)) ||
      any(completion_audit$object_id != object_id) ||
      any(!grepl(
        "^[0-9a-f]{64}$",
        as.character(completion_audit$passive_completion_sha256)
      )) ||
      nrow(completion_summary) != 1L ||
      !identical(as.character(completion_summary$object_id), object_id) ||
      !identical(as.integer(completion_summary$requested_m), 50L) ||
      !identical(as.integer(completion_summary$chains_checked), 50L) ||
      !identical(as.character(completion_summary$status), "PASS")) {
    stop_iv(object_id, " run or component manifest is invalid.")
  }
  mids <- read_rds_stable(mids_path, paste0(object_id, " restricted mids"))
  final_hash <- component$sha256[
    match("final_mids_file", component$component)
  ]
  if (!identical(mids$sha256, as.character(p$mids_sha256)) ||
      !identical(mids$sha256, as.character(run_manifest$mids_sha256)) ||
      !identical(mids$sha256, final_hash)) {
    stop_iv(object_id, " restricted mids hash differs across contracts.")
  }
  list(
    object_id = object_id, run_id = run_id,
    pointer_path = pointer_path, pointer_sha = pointer$sha256,
    pointer = p, result_dir = result_dir, mids_path = mids_path,
    mids = mids$data, run_manifest = run_manifest,
    component = component, completion_audit = completion_audit,
    completion_summary = completion_summary
  )
}

independent_diagnostic <- function(values, missing_n, role, threshold) {
  audit <- iv_rhat_audit(values)
  structural_na <- identical(role, "scale") && missing_n == 1L
  constant_acceptable <- identical(role, "scale") &&
    isTRUE(audit$raw_trace_constant)
  hard_gate <- !structural_na && !constant_acceptable
  pass <- if (structural_na || constant_acceptable) {
    TRUE
  } else {
    audit$finite &&
      nrow(values) >= 6L && ncol(values) >= 2L &&
      !isTRUE(audit$raw_trace_constant) &&
      is.finite(audit$rank_normalized_split_rhat) &&
      is.finite(audit$rhat) && audit$rhat <= threshold
  }
  diagnostic_status <- if (structural_na) {
    "NOT_APPLICABLE_SINGLE_MISSING_SD"
  } else if (constant_acceptable) {
    "NA_CONSTANT_SCALE"
  } else if (!pass) {
    "FAIL"
  } else if (!isTRUE(audit$folded_identifiable)) {
    "PASS_BULK_ONLY_FOLDED_DEGENERATE"
  } else {
    "PASS"
  }
  cbind(
    audit,
    data.frame(
      hard_gate = hard_gate, pass = pass,
      diagnostic_status = diagnostic_status,
      stringsAsFactors = FALSE
    )
  )
}

validate_object <- function(files) {
  object_id <- files$object_id
  imp <- files$mids
  contract <- input_contract$objects[[object_id]]
  if (is.null(contract)) stop_iv(object_id, " input contract is absent.")
  if (!inherits(imp, "mids") ||
      !identical(names(imp), standard_mids_names) ||
      !identical(as.integer(imp$m), 50L) ||
      !identical(names(imp$imp), names(imp$data))) {
    stop_iv(object_id, " mids top-level schema is invalid.")
  }
  raw_where <- is.na(imp$data)
  expected_where <- matrix(
    as.logical(as.matrix(raw_where)),
    nrow = nrow(imp$data),
    ncol = ncol(imp$data),
    dimnames = dimnames(imp$data)
  )
  data_hash <- iv_canonical_data_frame_contract(imp$data)$sha256
  method_hash <- iv_canonical_object_sha256(imp$method)
  predictor_hash <- iv_canonical_array_sha256(imp$predictorMatrix)
  where_hash <- iv_canonical_array_sha256(imp$where)
  visit_hash <- iv_canonical_object_sha256(imp$visitSequence)
  schema_checks <- c(
    input_hash = identical(data_hash, contract$canonical_data_sha256),
    specification_hash = identical(
      iv_canonical_object_sha256(contract$specification),
      contract$specification_sha256
    ),
    method_hash = identical(method_hash, contract$method_sha256) &&
      identical(imp$method, contract$specification$method),
    predictor_hash = identical(predictor_hash, contract$predictor_sha256) &&
      identical(
        imp$predictorMatrix,
        contract$specification$predictor_matrix
      ),
    where_exact = identical(imp$where, expected_where) &&
      identical(where_hash, contract$where_sha256),
    where_values_equal_raw_missingness =
      identical(as.vector(imp$where), as.vector(raw_where)),
    where_dimnames_equal_input =
      identical(dimnames(imp$where), dimnames(imp$data)),
    visit_hash = identical(visit_hash, contract$visit_sha256) &&
      identical(
        as.character(imp$visitSequence),
        as.character(contract$specification$visit_sequence)
      ),
    seed = identical(as.integer(imp$seed), as.integer(contract$seed)),
    nmis = identical(
      as.integer(imp$nmis),
      as.integer(vapply(imp$data, function(x) sum(is.na(x)), integer(1)))
    ),
    iteration = as.integer(imp$iteration) %in% c(20L, 40L, 80L),
    logged_events = is.null(imp$loggedEvents) ||
      (is.data.frame(imp$loggedEvents) && nrow(imp$loggedEvents) == 0L),
    zero_pef_targets = !any(
      nzchar(imp$method) &
        grepl("(^|_)pef|E0_W2|M12|D12",
              names(imp$method), ignore.case = TRUE)
    ),
    bmi_fixed = identical(unname(imp$method[["bmi_w1"]]), "") &&
      all(imp$predictorMatrix["bmi_w1", ] == 0) &&
      all(imp$predictorMatrix[, "bmi_w1"] == 0) &&
      all(is.finite(imp$data$bmi_w1) & imp$data$bmi_w1 == 0),
    height_derived_terms_absent = !any(grepl(
      "^height_(ns|spline|basis)|height_m_w1_(ns|spline|basis)",
      names(imp$data), ignore.case = TRUE
    )),
    no_passive_age_column = !any(
      c("age_w2", "age_W2", "age_w2_model") %in% names(imp$data)
    )
  )
  if (object_id == "MI-C2") {
    active <- names(imp$method)[nzchar(imp$method)]
    schema_checks <- c(
      schema_checks,
      c2_response_fixed =
        "R_W2" %in% names(imp$data) &&
          identical(unname(imp$method[["R_W2"]]), "") &&
          all(!imp$where[, "R_W2"]) &&
          all(imp$predictorMatrix["R_W2", ] == 0) &&
          all(imp$predictorMatrix[active, "R_W2"] == 1),
      c2_w2_pef_absent = !any(grepl(
        "pef_w2|E0_W2|M12|D12",
        c(
          names(imp$data), names(imp$method),
          rownames(imp$predictorMatrix), colnames(imp$predictorMatrix),
          colnames(imp$where), as.character(imp$visitSequence)
        ),
        ignore.case = TRUE
      ))
    )
  }
  if (!all(schema_checks)) {
    stop_iv(
      object_id, " independent mids/input contract failed: ",
      paste(names(schema_checks)[!schema_checks], collapse = ", ")
    )
  }

  expected_chains <- as.character(seq_len(50L))
  mapping <- do.call(rbind, lapply(names(imp$data), function(variable) {
    expected_rows <- which(expected_where[, variable])
    # mice 3.19.0 indexes each imp payload with the corresponding input-data
    # row labels (row.names(data)[wy]), not with numeric row positions when
    # the input has non-default row names.
    expected_row_labels <- rownames(imp$data)[expected_rows]
    payload <- imp$imp[[variable]]
    active <- nzchar(imp$method[[variable]])
    pass <- if (is.null(payload)) {
      !active
    } else if (active) {
      is.data.frame(payload) &&
        length(expected_row_labels) == length(expected_rows) &&
        !anyNA(expected_row_labels) &&
        !anyDuplicated(expected_row_labels) &&
        identical(rownames(payload), expected_row_labels) &&
        identical(names(payload), expected_chains) &&
        nrow(payload) == length(expected_rows) &&
        ncol(payload) == 50L && !anyNA(payload)
    } else {
      is.data.frame(payload) &&
        length(expected_row_labels) == length(expected_rows) &&
        !anyNA(expected_row_labels) &&
        !anyDuplicated(expected_row_labels) &&
        identical(rownames(payload), expected_row_labels) &&
        identical(names(payload), expected_chains) &&
        nrow(payload) == length(expected_rows) &&
        ncol(payload) == 50L && all(is.na(payload))
    }
    data.frame(
      object_id = object_id, variable = variable,
      active = active, expected_rows = length(expected_rows),
      status = if (pass) "PASS" else "FAIL",
      stringsAsFactors = FALSE
    )
  }))
  if (any(mapping$status != "PASS")) {
    stop_iv(
      object_id, " mids$imp row/chain mapping failed: ",
      paste(mapping$variable[mapping$status != "PASS"], collapse = ", ")
    )
  }

  metadata <- attr(imp, "v45_1_charls_production_metadata", exact = TRUE)
  expected_metadata <- c(
    "contract_version", "run_id", "object_id", "requested_m",
    "selected_maxit", "generation_status", "outcome_model_fit_count",
    "response_model_fit_count", "pef_model_fit_count",
    "coefficient_export_count", "completed_dataset_persistence_count",
    "component_hashes_before_file_save"
  )
  zero_fields <- c(
    "outcome_model_fit_count", "response_model_fit_count",
    "pef_model_fit_count", "coefficient_export_count",
    "completed_dataset_persistence_count"
  )
  if (!is.list(metadata) || !identical(names(metadata), expected_metadata) ||
      !identical(metadata$contract_version,
                 "v45_1_charls_production_mi") ||
      !identical(metadata$run_id, files$run_id) ||
      !identical(metadata$object_id, object_id) ||
      !identical(as.integer(metadata$requested_m), 50L) ||
      !identical(
        as.integer(metadata$selected_maxit), as.integer(imp$iteration)
      ) ||
      !identical(
        metadata$generation_status,
        "GENERATED_AWAITING_INDEPENDENT_VALIDATION"
      ) ||
      !all(vapply(zero_fields, function(field) {
        identical(as.integer(metadata[[field]]), 0L)
      }, logical(1)))) {
    stop_iv(object_id, " embedded production metadata is invalid.")
  }

  recorded_components <- setNames(
    as.character(files$component$sha256), files$component$component
  )
  category_trace <- attr(imp, "category_trace", exact = TRUE)
  if (is.null(category_trace)) {
    category_trace <- iv_empty_category_trace()
  }
  independent_components <- c(
    canonical_source_input_data =
      iv_canonical_data_frame_contract(imp$data)$sha256,
    canonical_column_contract = iv_canonical_data_frame_contract(
      iv_canonical_data_frame_contract(imp$data)$columns
    )$sha256,
    canonical_frozen_specification =
      iv_canonical_object_sha256(contract$specification),
    canonical_ordered_participant_ids =
      iv_canonical_object_sha256(as.character(imp$data$participant_id)),
    canonical_imputation_payload =
      iv_canonical_imputation_payload_sha256(imp),
    canonical_chain_mean = iv_canonical_array_sha256(imp$chainMean),
    canonical_chain_variance = iv_canonical_array_sha256(imp$chainVar),
    canonical_categorical_trace =
      iv_canonical_data_frame_contract(category_trace)$sha256,
    mids_method = iv_canonical_named_character_sha256(imp$method),
    mids_predictor_matrix =
      iv_canonical_array_sha256(imp$predictorMatrix),
    mids_where = iv_canonical_array_sha256(imp$where),
    mids_visit_sequence =
      iv_canonical_object_sha256(as.character(imp$visitSequence)),
    mids_last_seed_value =
      iv_canonical_array_sha256(as.integer(imp$lastSeedValue)),
    final_mids_file = sha256_file(files$mids_path)
  )
  if (!identical(
    unname(recorded_components[names(independent_components)]),
    unname(independent_components)
  )) {
    stop_iv(object_id, " independent component rehash failed.")
  }
  embedded <- metadata$component_hashes_before_file_save
  if (!is.data.frame(embedded) ||
      !setequal(
        embedded$component,
        setdiff(required_components, "final_mids_file")
      )) {
    stop_iv(object_id, " embedded component manifest is invalid.")
  }
  embedded_hash <- setNames(embedded$sha256, embedded$component)
  diagnostic_components <- c(
    "canonical_final_convergence",
    "canonical_checkpoint_diagnostics",
    "canonical_released_trace"
  )
  if (!identical(
    unname(embedded_hash[diagnostic_components]),
    unname(recorded_components[diagnostic_components])
  )) {
    stop_iv(object_id, " diagnostic component binding failed.")
  }

  smoking <- attr(imp, "smoking_coherence_trace", exact = TRUE)
  required_smoking <- c(
    "iteration", "chains_checked",
    "unresolved_n_across_completed_chains",
    "parent_zero_child_one_n_across_completed_chains", "rule"
  )
  if (!is.data.frame(smoking) ||
      !all(required_smoking %in% names(smoking)) ||
      nrow(smoking) != as.integer(imp$iteration) ||
      !identical(
        as.integer(smoking$iteration), seq_len(as.integer(imp$iteration))
      ) ||
      any(as.integer(smoking$chains_checked) != 50L) ||
      any(as.integer(
        smoking$unresolved_n_across_completed_chains
      ) != 0L) ||
      any(as.integer(
        smoking$parent_zero_child_one_n_across_completed_chains
      ) != 0L)) {
    stop_iv(object_id, " smoking coherence trace failed.")
  }
  if (length(contract$active_targets[
        contract$active_targets %in%
          c("raeducl")
      ]) ||
      nrow(category_trace) != 0L) {
    stop_iv(object_id, " unexpected unordered-category trace exists.")
  }

  checkpoint <- read_tsv_stable(
    file.path(files$result_dir, "checkpoint_diagnostics.tsv"),
    paste0(object_id, " checkpoint diagnostics")
  )$data
  final <- read_tsv_stable(
    file.path(files$result_dir, "final_convergence.tsv"),
    paste0(object_id, " final convergence")
  )$data
  selected <- as.integer(imp$iteration)
  checkpoint_values <- sort(unique(as.integer(
    checkpoint$checkpoint_iteration
  )))
  frozen_checkpoints <- as.integer(contract$convergence_checkpoints)
  expected_checkpoint_values <-
    frozen_checkpoints[frozen_checkpoints <= selected]
  if (!identical(frozen_checkpoints, c(20L, 40L, 80L)) ||
      !identical(checkpoint_values, expected_checkpoint_values) ||
      !identical(tail(checkpoint_values, 1L), selected)) {
    stop_iv(object_id, " checkpoint history is invalid.")
  }
  if (any(checkpoint$analysis_id != object_id) ||
      any(checkpoint$mi_run != "m50") ||
      any(final$analysis_id != object_id) ||
      any(final$mi_run != "m50") ||
      any(!final$selected_checkpoint %in% TRUE) ||
      any(as.integer(final$checkpoint_iteration) != selected)) {
    stop_iv(object_id, " convergence identity/checkpoint metadata drifted.")
  }
  active <- names(imp$method)[nzchar(imp$method)]
  missing_n <- vapply(
    imp$data[active], function(value) sum(is.na(value)), integer(1)
  )
  active <- active[missing_n > 0L]
  missing_n <- missing_n[active]
  threshold <- as.numeric(contract$convergence_rhat_max)
  expected_diagnostic_key <- as.vector(outer(
    active,
    c(
      "chain_mean", "chain_sd",
      "final_between_imputation_variation"
    ),
    paste, sep = "\r"
  ))
  checkpoint_independent_pass <- setNames(
    rep(TRUE, length(checkpoint_values)),
    as.character(checkpoint_values)
  )
  same_numeric <- function(observed, expected) {
    observed <- as.numeric(observed)
    expected <- as.numeric(expected)
    if (length(observed) != 1L || length(expected) != 1L) return(FALSE)
    if (is.na(expected)) return(is.na(observed))
    if (is.infinite(expected)) {
      return(is.infinite(observed) && sign(observed) == sign(expected))
    }
    is.finite(observed) &&
      abs(observed - expected) <= 1e-12 * max(1, abs(expected))
  }
  for (checkpoint_iteration in checkpoint_values) {
    recorded <- checkpoint[
      as.integer(checkpoint$checkpoint_iteration) == checkpoint_iteration,
      ,
      drop = FALSE
    ]
    checkpoint_order <- match(checkpoint_iteration, frozen_checkpoints)
    recorded_key <- paste(recorded$variable, recorded$parameter, sep = "\r")
    if (nrow(recorded) != length(expected_diagnostic_key) ||
        anyDuplicated(recorded_key) ||
        !setequal(recorded_key, expected_diagnostic_key) ||
        any(as.integer(recorded$checkpoint_order) != checkpoint_order) ||
        any(as.integer(recorded$checkpoint_iteration) !=
              checkpoint_iteration) ||
        any(as.integer(recorded$iterations) != checkpoint_iteration) ||
        any(as.integer(recorded$chains) != 50L) ||
        any(as.logical(recorded$selected_checkpoint) !=
              (checkpoint_iteration == selected))) {
      stop_iv(
        object_id, " checkpoint diagnostic grid is incomplete at ",
        checkpoint_iteration, "."
      )
    }
    for (variable in active) {
      mean_values <- imp$chainMean[
        variable, seq_len(checkpoint_iteration), , drop = TRUE
      ]
      variance_values <- imp$chainVar[
        variable, seq_len(checkpoint_iteration), , drop = TRUE
      ]
      if (is.null(dim(mean_values))) {
        mean_values <- matrix(mean_values, ncol = 50L)
      }
      if (is.null(dim(variance_values))) {
        variance_values <- matrix(variance_values, ncol = 50L)
      }
      independent_mean <- independent_diagnostic(
        mean_values, missing_n[[variable]], "location", threshold
      )
      independent_sd <- independent_diagnostic(
        sqrt(variance_values), missing_n[[variable]], "scale", threshold
      )
      for (parameter in c("chain_mean", "chain_sd")) {
        current <- recorded[
          recorded$variable == variable &
            recorded$parameter == parameter,
          ,
          drop = FALSE
        ]
        expected_diag <- if (parameter == "chain_mean") {
          independent_mean
        } else {
          independent_sd
        }
        checkpoint_independent_pass[[
          as.character(checkpoint_iteration)
        ]] <- checkpoint_independent_pass[[
          as.character(checkpoint_iteration)
        ]] && (
          !isTRUE(expected_diag$hard_gate) ||
            isTRUE(expected_diag$pass)
        )
        if (nrow(current) != 1L ||
            !identical(
              as.logical(current$hard_gate),
              as.logical(expected_diag$hard_gate)
            ) ||
            !identical(
              as.logical(current$pass), as.logical(expected_diag$pass)
            ) ||
            !identical(
              as.character(current$diagnostic_status),
              as.character(expected_diag$diagnostic_status)
            ) ||
            !identical(
              as.logical(current$raw_trace_constant),
              as.logical(expected_diag$raw_trace_constant)
            ) ||
            !identical(
              as.logical(current$folded_identifiable),
              as.logical(expected_diag$folded_identifiable)
            ) ||
            !same_numeric(
              current$rank_normalized_split_rhat,
              expected_diag$rank_normalized_split_rhat
            ) ||
            !same_numeric(
              current$folded_split_rhat,
              expected_diag$folded_split_rhat
            ) ||
            !same_numeric(current$rhat, expected_diag$rhat)) {
          stop_iv(
            object_id, " independent R-hat mismatch at ",
            checkpoint_iteration, "/", variable, "/", parameter, "."
          )
        }
      }
    }
  }
  earlier <- checkpoint_values[checkpoint_values < selected]
  if ((length(earlier) &&
       any(checkpoint_independent_pass[as.character(earlier)])) ||
      !isTRUE(checkpoint_independent_pass[[as.character(selected)]])) {
    stop_iv(object_id, " the selected checkpoint is not the first pass.")
  }
  selected_checkpoint <- checkpoint[
    as.integer(checkpoint$checkpoint_iteration) == selected,
    , drop = FALSE
  ]
  order_diagnostic <- function(data) {
    data <- data[
      order(data$variable, data$parameter, data$category_level,
            na.last = TRUE, method = "radix"),
      ,
      drop = FALSE
    ]
    rownames(data) <- NULL
    data
  }
  if (!identical(
        iv_canonical_data_frame_contract(
          order_diagnostic(selected_checkpoint)
        )$sha256,
        iv_canonical_data_frame_contract(order_diagnostic(final))$sha256
      )) {
    stop_iv(object_id, " final convergence differs from selected checkpoint.")
  }
  final_hard <- final$hard_gate %in% TRUE
  variation <- final$parameter == "final_between_imputation_variation"
  if (!any(final_hard) || !all(final$pass[final_hard] %in% TRUE) ||
      sum(variation) != length(active)) {
    stop_iv(object_id, " final convergence hard gates are incomplete.")
  }
  for (variable in active) {
    payload <- imp$imp[[variable]]
    varying <- is.data.frame(payload) && !anyNA(payload) &&
      sum(apply(payload, 1L, function(value) {
        length(unique(as.character(value))) > 1L
      })) > 0L
    row <- final[
      final$variable == variable &
        final$parameter == "final_between_imputation_variation",
      ,
      drop = FALSE
    ]
    if (nrow(row) != 1L || !varying || !isTRUE(as.logical(row$pass))) {
      stop_iv(object_id, " final between-imputation variation failed.")
    }
  }

  released <- read_tsv_stable(
    file.path(files$result_dir, "released_chain_trace.tsv"),
    paste0(object_id, " released trace")
  )$data
  eligible <- final[
    final$hard_gate %in% TRUE & final$pass %in% TRUE &
      final$missing_n >=
        as.integer(contract$specification$trace_release_missing_n_min) &
      final$parameter %in% c("chain_mean", "chain_sd"),
    c("variable", "parameter", "missing_n"),
    drop = FALSE
  ]
  if (nrow(eligible)) {
    for (index in seq_len(nrow(eligible))) {
      row <- eligible[index, , drop = FALSE]
      current <- released[
        released$variable == row$variable &
          released$parameter == row$parameter,
        ,
        drop = FALSE
      ]
      key <- paste(current$iteration, current$chain, sep = "\r")
      grid <- expand.grid(
        iteration = seq_len(selected), chain = seq_len(50L),
        KEEP.OUT.ATTRS = FALSE, stringsAsFactors = FALSE
      )
      grid_key <- paste(grid$iteration, grid$chain, sep = "\r")
      if (nrow(current) != nrow(grid) || anyDuplicated(key) ||
          !setequal(key, grid_key) ||
          any(current$cohort != "CHARLS") ||
          any(current$trace_release_status !=
                "RELEASED_HARD_GATE_AGGREGATE")) {
        stop_iv(object_id, " released trace grid is invalid.")
      }
      current <- current[match(grid_key, key), , drop = FALSE]
      expected_values <- as.vector(if (row$parameter == "chain_mean") {
        imp$chainMean[row$variable, , , drop = TRUE]
      } else {
        sqrt(imp$chainVar[row$variable, , , drop = TRUE])
      })
      tolerance <- 1e-12 * pmax(1, abs(expected_values))
      if (anyNA(current$value) || anyNA(expected_values) ||
          any(abs(current$value - expected_values) > tolerance)) {
        stop_iv(object_id, " released trace values differ from mids.")
      }
    }
  }

  observed_change_n <- 0L
  structure_change_n <- 0L
  smoking_conflict_n <- 0L
  R_W2_change_n <- 0L
  max_bmi_error <- 0
  max_age_error <- if (object_id == "MI-C2") 0 else NA_real_
  bmi_placeholder_nonzero_n <- 0L
  bmi_rebuilt_row_n <- 0L
  age_W2_rebuilt_row_n <- if (object_id == "MI-C2") 0L else NA_integer_
  chain_audit <- vector("list", 50L)
  for (chain in seq_len(50L)) {
    completed <- mice::complete(imp, action = chain)
    for (field in names(imp$data)) {
      class_ok <- identical(class(completed[[field]]), class(imp$data[[field]])) &&
        (
          !is.factor(imp$data[[field]]) ||
            (
              identical(levels(completed[[field]]), levels(imp$data[[field]])) &&
                identical(
                  is.ordered(completed[[field]]),
                  is.ordered(imp$data[[field]])
                )
            )
        )
      structure_change_n <- structure_change_n + as.integer(!class_ok)
      observed <- !is.na(imp$data[[field]])
      changed <- if (
        is.factor(imp$data[[field]]) || is.character(imp$data[[field]])
      ) {
        as.character(completed[[field]][observed]) !=
          as.character(imp$data[[field]][observed])
      } else {
        completed[[field]][observed] != imp$data[[field]][observed]
      }
      observed_change_n <- observed_change_n + sum(is.na(changed) | changed)
    }
    height <- as.numeric(completed$height_m_w1)
    weight <- as.numeric(completed$weight_kg_w1)
    bmi_placeholder <- as.numeric(completed$bmi_w1)
    bmi_placeholder_nonzero <- sum(
      !is.finite(bmi_placeholder) | bmi_placeholder != 0
    )
    bmi_placeholder_nonzero_n <-
      bmi_placeholder_nonzero_n + bmi_placeholder_nonzero
    rebuilt_bmi <- weight / height^2
    completed$bmi_w1 <- rebuilt_bmi
    bmi_rebuilt <- sum(
      is.finite(completed$bmi_w1) &
        completed$bmi_w1 != bmi_placeholder
    )
    bmi_rebuilt_row_n <- bmi_rebuilt_row_n + bmi_rebuilt
    bmi_error <- max(abs(completed$bmi_w1 - weight / height^2))
    max_bmi_error <- max(max_bmi_error, bmi_error)
    ever <- as.numeric(as.character(
      completed$smoke_ever_w1
    ))
    now <- as.numeric(as.character(
      completed$smoke_now_w1
    ))
    smoking_bad <- is.na(ever) | is.na(now) |
      !ever %in% 0:1 | !now %in% 0:1 | (ever == 0 & now == 1)
    smoking_conflict_n <- smoking_conflict_n + sum(smoking_bad)
    parent_bad <- !is.finite(height) | height < 1 | height > 2.7 |
      !is.finite(weight) | weight < 20 | weight > 350
    bmi_bad <- !is.finite(completed$bmi_w1) |
      completed$bmi_w1 < 11 | completed$bmi_w1 > 75
    age_error <- NA_real_
    age_rebuilt <- NA_integer_
    if (object_id == "MI-C2") {
      completed$age_w2_model <- as.numeric(completed$age_w1) + 2
      age_rebuilt <- sum(is.finite(completed$age_w2_model))
      age_W2_rebuilt_row_n <- age_W2_rebuilt_row_n + age_rebuilt
      age_error <- max(abs(
        completed$age_w2_model -
          (as.numeric(completed$age_w1) + 2)
      ))
      max_age_error <- max(max_age_error, age_error)
      changed <- as.character(completed$R_W2) != as.character(imp$data$R_W2)
      R_W2_change_n <- R_W2_change_n + sum(is.na(changed) | changed)
    }
    if (bmi_placeholder_nonzero != 0L ||
        bmi_rebuilt != nrow(completed) ||
        any(parent_bad) || any(bmi_bad) || any(smoking_bad) ||
        bmi_error > 1e-12 ||
        (object_id == "MI-C2" &&
           (age_rebuilt != nrow(completed) || age_error > 1e-12))) {
      stop_iv(object_id, " completion failed in chain ", chain, ".")
    }
    passive_completion_sha <-
      iv_canonical_data_frame_contract(completed)$sha256
    chain_audit[[chain]] <- data.frame(
      object_id = object_id, chain = chain, n = nrow(completed),
      height_min = min(height), height_max = max(height),
      weight_min = min(weight), weight_max = max(weight),
      bmi_placeholder_nonzero_n = bmi_placeholder_nonzero,
      bmi_rebuilt_row_n = bmi_rebuilt,
      bmi_min = min(completed$bmi_w1),
      bmi_max = max(completed$bmi_w1),
      bmi_identity_max_error = bmi_error,
      age_W2_rebuilt_row_n = age_rebuilt,
      age_W2_identity_max_error = age_error,
      passive_completion_sha256 = passive_completion_sha,
      stringsAsFactors = FALSE
    )
    rm(completed)
    if (chain %% 5L == 0L) invisible(gc(verbose = FALSE))
  }
  if (observed_change_n != 0L || structure_change_n != 0L ||
      smoking_conflict_n != 0L || R_W2_change_n != 0L ||
      bmi_placeholder_nonzero_n != 0L ||
      bmi_rebuilt_row_n != 50L * nrow(imp$data) ||
      max_bmi_error > 1e-12 ||
      (object_id == "MI-C2" &&
         (age_W2_rebuilt_row_n != 50L * nrow(imp$data) ||
            max_age_error > 1e-12))) {
    stop_iv(object_id, " completion aggregate validation failed.")
  }
  chain_audit <- do.call(rbind, chain_audit)
  recorded_audit <- files$completion_audit
  if (!identical(
        as.integer(recorded_audit$chain), as.integer(chain_audit$chain)
      ) ||
      !identical(
        as.character(recorded_audit$passive_completion_sha256),
        as.character(chain_audit$passive_completion_sha256)
      ) ||
      any(as.integer(recorded_audit$bmi_placeholder_nonzero_n) != 0L) ||
      any(as.integer(recorded_audit$bmi_rebuilt_row_n) !=
            as.integer(recorded_audit$n)) ||
      !identical(
        as.integer(files$completion_summary$bmi_rebuilt_row_n),
        as.integer(bmi_rebuilt_row_n)
      ) ||
      !identical(
        as.integer(files$completion_summary$bmi_placeholder_nonzero_n),
        0L
      ) ||
      (object_id == "MI-C2" &&
         (
           any(as.integer(recorded_audit$age_W2_rebuilt_row_n) !=
                 as.integer(recorded_audit$n)) ||
             !identical(
               as.integer(
                 files$completion_summary$age_W2_rebuilt_row_n
               ),
               as.integer(age_W2_rebuilt_row_n)
             )
         ))) {
    stop_iv(
      object_id,
      " independently reconstructed passive completions differ from runner."
    )
  }

  suspicious <- list.files(
    dirname(dirname(files$mids_path)),
    recursive = TRUE, full.names = TRUE, all.files = TRUE, no.. = TRUE
  )
  suspicious <- suspicious[
    grepl(
      "completed_data|coefficient|propensity|availability_weight|model_fit|survey_design",
      basename(suspicious), ignore.case = TRUE
    )
  ]
  suspicious <- suspicious[
    !grepl(
      "^completion_(chain_audit|summary)\\.tsv$",
      basename(suspicious)
    )
  ]
  if (length(suspicious)) {
    stop_iv(object_id, " suspicious persisted production artifacts exist.")
  }

  list(
    mapping = mapping,
    chain_audit = chain_audit,
    summary = data.frame(
      object_id = object_id,
      run_id = files$run_id,
      m = as.integer(imp$m),
      selected_maxit = as.integer(imp$iteration),
      denominator_n = nrow(imp$data),
      active_target_n = length(active),
      checkpoints_independently_recomputed =
        paste(checkpoint_values, collapse = "|"),
      observed_value_change_n = observed_change_n,
      structure_change_n = structure_change_n,
      smoking_conflict_n = smoking_conflict_n,
      R_W2_change_n = R_W2_change_n,
      bmi_placeholder_nonzero_n = bmi_placeholder_nonzero_n,
      bmi_rebuilt_row_n = bmi_rebuilt_row_n,
      maximum_bmi_identity_error = max_bmi_error,
      age_W2_rebuilt_row_n = age_W2_rebuilt_row_n,
      maximum_age_W2_identity_error = max_age_error,
      warnings = 0L,
      logged_events = 0L,
      outcome_model_fit_count = 0L,
      response_model_fit_count = 0L,
      pef_model_fit_count = 0L,
      coefficient_export_count = 0L,
      completed_dataset_persistence_count = 0L,
      status = "PASS",
      stringsAsFactors = FALSE
    )
  )
}

files <- lapply(c("MI-C0", "MI-C2"), load_object)
names(files) <- c("MI-C0", "MI-C2")
validations <- lapply(files, validate_object)
summary <- do.call(rbind, lapply(validations, `[[`, "summary"))
mapping <- do.call(rbind, lapply(validations, `[[`, "mapping"))
if (any(summary$status != "PASS") || any(mapping$status != "PASS")) {
  stop_iv("One or more CHARLS production objects failed independent validation.")
}
if (!rng_state_unchanged()) {
  stop_iv("Independent CHARLS validation changed the R random state.")
}

validation <- data.frame(
  check_id = c(
    "freeze_code_function_input_roots_rehashed",
    "both_restricted_mids_and_run_manifests_rehashed",
    "independent_mids_schema_and_payload_mapping",
    "independent_all_checkpoint_Rhat_and_final_variation",
    "independent_smoking_and_observed_value_preservation",
    "independent_passive_BMI_all_50",
    "independent_MI_C2_age_R_W2_and_zero_PEF",
    "no_completed_data_models_or_coefficients_persisted",
    "outcome_and_coefficient_gates_remain_closed",
    "R_random_state_unchanged"
  ),
  status = "PASS",
  observed = c(
    paste0("code=", nrow(code), "; functions=", nrow(functions)),
    paste(summary$object_id, summary$run_id, sep = ":", collapse = "|"),
    paste0("mapping_rows=", nrow(mapping), "; all exact"),
    paste(
      summary$object_id,
      summary$checkpoints_independently_recomputed,
      sep = ":", collapse = "|"
    ),
    "0 observed changes; 0 structural changes; 0 smoking conflicts",
    paste(
      summary$object_id,
      sprintf("%.17g", summary$maximum_bmi_identity_error),
      sep = ":", collapse = "|"
    ),
    paste0(
      "age_error=",
      sprintf(
        "%.17g",
        summary$maximum_age_W2_identity_error[
          summary$object_id == "MI-C2"
        ]
      ),
      "; R_W2_changes=0; PEF_targets=0"
    ),
    "completed/model/coefficient persistence count=0",
    "outcome=no; coefficient inspection=no",
    "Random.seed existence/value and RNGkind unchanged"
  ),
  validation_id = validation_id,
  validated_at_utc =
    format(Sys.time(), "%Y-%m-%dT%H:%M:%SZ", tz = "UTC"),
  stringsAsFactors = FALSE
)

validation_path <- file.path(
  result, "charls_production_mi_independent_validation_v45_1.tsv"
)
qa_path <- file.path(
  root, "output/qa/v45/charls_addendum_v45_1",
  "CHARLS_PRODUCTION_MI_INDEPENDENT_QA_v45_1.md"
)
validated_pointer_paths <- setNames(file.path(
  result, "production_mi",
  paste0(c("MI_C0", "MI_C2"), "_m50_validated.tsv")
), c("MI-C0", "MI-C2"))
output_manifest_path <- file.path(
  result, "charls_production_mi_independent_output_manifest_v45_1.tsv"
)
final_paths <- c(
  validation_path, qa_path, validated_pointer_paths, output_manifest_path
)
validation_transaction_record <- file.path(
  validation_lock_parent,
  paste0(".validation_transaction_", validation_id, ".yml")
)
if (any(file.exists(final_paths))) {
  stop_iv("Independent CHARLS validation outputs already exist.")
}

staging <- file.path(
  result, "production_mi", paste0(".validation_staging_", validation_id)
)
dir.create(staging, recursive = TRUE, showWarnings = FALSE)
committed <- FALSE
owned_hashes <- setNames(rep(NA_character_, length(final_paths)), final_paths)
on.exit({
  if (dir.exists(staging)) unlink(staging, recursive = TRUE, force = TRUE)
  if (!committed) {
    for (path in final_paths) {
      if (file.exists(path) &&
          grepl("^[0-9a-f]{64}$", owned_hashes[[path]]) &&
          identical(sha256_file(path), owned_hashes[[path]])) {
        unlink(path, force = TRUE)
      }
    }
  }
  if (file.exists(validation_transaction_record)) {
    unlink(validation_transaction_record, force = TRUE)
  }
}, add = TRUE)

staged_validation <- file.path(staging, basename(validation_path))
staged_qa <- file.path(staging, basename(qa_path))
atomic_write_tsv(validation, staged_validation)
qa_lines <- c(
  "# CHARLS v45.1 independent production-MI validation",
  "",
  paste0("Validation ID: ", validation_id),
  "",
  "## Decision",
  "",
  paste(
    "PASS. MI-C0 and MI-C2 restricted m=50 objects independently passed",
    "schema, payload mapping, all available checkpoint R-hat, final",
    "between-imputation variation, smoking coherence, observed-value",
    "preservation, passive BMI, and MI-C2 age/response/no-PEF gates."
  ),
  "",
  paste(
    "No random numbers were consumed, no imputation was generated, no",
    "completed dataset was saved, and no outcome, response, or PEF model",
    "or coefficient was created or inspected."
  ),
  "",
  "Outcome execution and coefficient inspection remain disabled.",
  "",
  "## Object summary",
  "",
  paste(capture.output(print(summary, row.names = FALSE)), collapse = "\n")
)
atomic_write_lines(qa_lines, staged_qa)
staged_pointers <- character()
for (object_id in names(files)) {
  value <- data.frame(
    object_id = object_id,
    requested_m = 50L,
    run_id = files[[object_id]]$run_id,
    mids_path_alias = files[[object_id]]$pointer$mids_path_alias,
    mids_sha256 = files[[object_id]]$pointer$mids_sha256,
    current_pointer_sha256 = files[[object_id]]$pointer_sha,
    validation_id = validation_id,
    status = "INDEPENDENT_VALIDATION_PASS",
    stringsAsFactors = FALSE
  )
  staged <- file.path(
    staging, basename(validated_pointer_paths[[object_id]])
  )
  atomic_write_tsv(value, staged)
  staged_pointers[[object_id]] <- staged
}
manifest_assets <- c(
  independent_validation = staged_validation,
  independent_QA = staged_qa,
  MI_C0_validated_pointer = staged_pointers[["MI-C0"]],
  MI_C2_validated_pointer = staged_pointers[["MI-C2"]]
)
manifest <- data.frame(
  asset_id = names(manifest_assets),
  path_alias = c(
    sub(paste0("^", root, "/?"), "", validation_path),
    sub(paste0("^", root, "/?"), "", qa_path),
    sub(
      paste0("^", root, "/?"), "",
      validated_pointer_paths[["MI-C0"]]
    ),
    sub(
      paste0("^", root, "/?"), "",
      validated_pointer_paths[["MI-C2"]]
    )
  ),
  bytes = vapply(
    manifest_assets, function(path) as.numeric(file.info(path)$size),
    numeric(1)
  ),
  sha256 = vapply(manifest_assets, sha256_file, character(1)),
  validation_status = "PASS",
  stringsAsFactors = FALSE
)
staged_manifest <- file.path(staging, basename(output_manifest_path))
atomic_write_tsv(manifest, staged_manifest)

if (!rng_state_unchanged() ||
    !identical(sha256_file(gate_path), gate_sha_start) ||
    !all(vapply(names(files), function(object_id) {
      identical(
        sha256_file(files[[object_id]]$pointer_path),
        files[[object_id]]$pointer_sha
      ) &&
        identical(
          sha256_file(files[[object_id]]$mids_path),
          files[[object_id]]$pointer$mids_sha256
        )
    }, logical(1)))) {
  stop_iv("Gate, pointer, or mids changed during independent validation.")
}
dir.create(dirname(qa_path), recursive = TRUE, showWarnings = FALSE)
promotion <- c(
  staged_validation, staged_qa,
  staged_pointers[["MI-C0"]], staged_pointers[["MI-C2"]],
  staged_manifest
)
destinations <- c(
  validation_path, qa_path,
  validated_pointer_paths[["MI-C0"]],
  validated_pointer_paths[["MI-C2"]],
  output_manifest_path
)
transaction_state <- list(
  transaction_id = validation_id,
  phase = "READY_TO_PROMOTE",
  gate_sha256_before = gate_sha_start,
  destination_paths = sub(paste0("^", root, "/?"), "", destinations),
  destination_sha256 = vapply(promotion, sha256_file, character(1)),
  recovery_rule =
    "audit hashes and phase; complete or roll back only this validation"
)
write_validation_transaction <- function(phase) {
  transaction_state$phase <<- phase
  atomic_write_yaml(transaction_state, validation_transaction_record)
}
write_validation_transaction("READY_TO_PROMOTE")
for (index in seq_along(promotion)) {
  expected_sha <- sha256_file(promotion[[index]])
  if (!file.rename(promotion[[index]], destinations[[index]])) {
    stop_iv("Independent validation output promotion failed.")
  }
  if (!identical(sha256_file(destinations[[index]]), expected_sha)) {
    stop_iv("Independent validation output changed during promotion.")
  }
  owned_hashes[[destinations[[index]]]] <- expected_sha
  write_validation_transaction(paste0(
    "PROMOTED_", index, "_OF_", length(promotion)
  ))
}
write_validation_transaction("OUTPUTS_PROMOTED_AWAITING_GATE")
if (!identical(sha256_file(gate_path), gate_sha_start)) {
  stop_iv("The isolated CHARLS gate changed before final validation commit.")
}
gate_final <- yaml::read_yaml(gate_path)
for (object_id in names(files)) {
  gate_final$charls_production_mi_execution$objects[[object_id]]$status <-
    "INDEPENDENT_VALIDATION_PASS"
  gate_final$charls_production_mi_execution$objects[[object_id]]$
    validated_pointer <- sub(
      paste0("^", root, "/?"), "",
      validated_pointer_paths[[object_id]]
    )
  gate_final$charls_production_mi_execution$objects[[object_id]]$
    validated_pointer_sha256 <-
      sha256_file(validated_pointer_paths[[object_id]])
}
gate_final$charls_production_mi_execution$status <-
  "INDEPENDENT_VALIDATION_PASS"
gate_final$charls_production_mi_independent_validation <- list(
  status = "PASS",
  validation_id = validation_id,
  output_manifest = sub(
    paste0("^", root, "/?"), "", output_manifest_path
  ),
  output_manifest_sha256 = sha256_file(output_manifest_path)
)
gate_final$outcome_execution_allowed <- "no"
gate_final$new_coefficient_inspection_allowed <- "no"
gate_final$next_authorized_step <- "freeze_CHARLS_outcome_execution"
gate_final$updated_at_utc <-
  format(Sys.time(), "%Y-%m-%dT%H:%M:%SZ", tz = "UTC")
atomic_write_yaml(gate_final, gate_path)
committed <- TRUE
if (file.exists(validation_transaction_record)) {
  unlink(validation_transaction_record, force = TRUE)
}
if (dir.exists(staging)) unlink(staging, recursive = TRUE, force = TRUE)
message(
  "CHARLS MI-C0/MI-C2 m50 independent validation PASS; ",
  "outcome execution remains blocked."
)
}

execute()
