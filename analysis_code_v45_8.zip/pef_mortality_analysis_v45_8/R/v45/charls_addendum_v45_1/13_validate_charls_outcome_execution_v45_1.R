#!/usr/bin/env Rscript

# Independently validate and, only after every frozen gate passes, release
# aggregate CHARLS v45.1 outcome results.
#
# This program deliberately does not trust pooled values written by the
# execution program.  It treats the restricted point/replicate coefficient
# arrays as validation inputs, independently reconstructs common masks,
# 1/(B_valid - 1) within-imputation covariance matrices, scalar and
# multivariate Rubin results, the literal prefix/full identity, and every
# object-wide m=50 Monte Carlo-error decision.
#
# Completed imputations are opened transiently only to repeat the frozen
# coefficient-blind sample anchors and the exact v44/v45 point-anchor gate.
# No completed data, fitted object, participant/community identifier,
# individual probability, availability factor, person weight, or replicate
# multiplier is persisted or released.

options(stringsAsFactors = FALSE, warn = 2)

v45cv_stop <- function(...) stop(..., call. = FALSE)

v45cv_root <- function() {
  args <- commandArgs(trailingOnly = FALSE)
  file_arg <- grep("^--file=", args, value = TRUE)
  if (!length(file_arg)) {
    return(normalizePath(getwd(), mustWork = TRUE))
  }
  script <- sub("^--file=", "", file_arg[[1L]])
  normalizePath(
    file.path(dirname(script), "..", "..", ".."),
    mustWork = TRUE
  )
}

root <- v45cv_root()
source(file.path(
  root,
  "R/v45/charls_addendum_v45_1/charls_structural_utilities_v45_1.R"
))
v45_charls_activate_project_library(root)
source(file.path(
  root,
  "R/v45/charls_addendum_v45_1/charls_outcome_utilities_v45_1.R"
))

required_packages <- c(
  digest = "0.6.37", dplyr = "1.1.4", mice = "3.19.0",
  survey = "4.5", yaml = "2.3.10"
)
missing_packages <- names(required_packages)[!vapply(
  names(required_packages), requireNamespace,
  logical(1), quietly = TRUE
)]
if (length(missing_packages) ||
    !identical(as.character(getRversion()), "4.5.1") ||
    any(!vapply(names(required_packages), function(package) {
      identical(
        as.character(utils::packageVersion(package)),
        required_packages[[package]]
      )
    }, logical(1)))) {
  v45cv_stop(
    "Frozen CHARLS validator runtime is incomplete or drifted; ",
    "R=4.5.1 and exact digest/dplyr/mice/survey/yaml versions required."
  )
}

args <- commandArgs(trailingOnly = TRUE)
mode <- if ("--self-test" %in% args) {
  "self_test"
} else if ("--verify" %in% args) {
  "verify"
} else {
  "validate"
}

v45cv_arg_value <- function(prefix, default = NULL) {
  hit <- grep(paste0("^", prefix, "="), args, value = TRUE)
  if (!length(hit)) return(default)
  sub(paste0("^", prefix, "="), "", tail(hit, 1L))
}

workers <- suppressWarnings(as.integer(
  v45cv_arg_value("--workers", Sys.getenv(
    "V45_CHARLS_OUTCOME_VALIDATION_WORKERS", "4"
  ))
))
if (is.na(workers) || workers < 1L || workers > 8L) {
  v45cv_stop("--workers must be an integer from 1 to 8.")
}
detected_cores <- parallel::detectCores()
if (!is.finite(detected_cores)) detected_cores <- 1L
workers <- min(workers, max(1L, as.integer(detected_cores) - 1L))

v45cv_yes <- function(value) {
  isTRUE(value) ||
    (length(value) == 1L && !is.na(value) &&
       tolower(as.character(value)) %in% c("yes", "true", "1"))
}

v45cv_no <- function(value) {
  identical(value, FALSE) ||
    (length(value) == 1L && !is.na(value) &&
       tolower(as.character(value)) %in% c("no", "false", "0"))
}

v45cv_validate_failure_summary <- function(
    summary, allow_empty, label) {
  expected <- c(
    "failure_class", "affected_imputations",
    "affected_imputation_count"
  )
  if (!is.data.frame(summary) ||
      !identical(names(summary), expected) ||
      anyNA(summary) ||
      (!isTRUE(allow_empty) && nrow(summary) < 1L) ||
      anyDuplicated(summary$failure_class)) {
    v45cv_stop(label, " failure-summary schema differs.")
  }
  if (!nrow(summary)) return(invisible(TRUE))
  seen <- integer()
  for (index in seq_len(nrow(summary))) {
    failure_class <- as.character(summary$failure_class[[index]])
    affected <- suppressWarnings(as.integer(strsplit(
      as.character(summary$affected_imputations[[index]]),
      "|", fixed = TRUE
    )[[1L]]))
    count <- suppressWarnings(as.integer(
      summary$affected_imputation_count[[index]]
    ))
    if (!nzchar(failure_class) || !length(affected) ||
        anyNA(affected) || any(!affected %in% seq_len(50L)) ||
        anyDuplicated(affected) ||
        length(count) != 1L || is.na(count) ||
        count != length(affected) ||
        any(affected %in% seen)) {
      v45cv_stop(label, " failure-summary contents differ.")
    }
    seen <- c(seen, affected)
  }
  invisible(TRUE)
}

v45cv_validate_point_failure_record <- function(module, value) {
  is_prefix <- endsWith(module, "-prefix")
  is_full <- endsWith(module, "-full")
  failure_fields <- c(
    "mi_object", "requested_m", "replicate_indices",
    "requested_replicate_indices", "executed_in_this_transaction",
    "prefix_sha256", "literal_prefix_identity", "results",
    "sample_anchors", "minimum_valid_replicate_fraction",
    "prefix_gate", "full_gate", "coefficient_blind_prefix_gate",
    "prefix_pooling_or_release_performed",
    "no_replacement_replicates", "variance_rule",
    "common_failure_masks_preserved", "pooling_status",
    "point_failure_class", "point_failure_reason",
    "point_failure_summary", "valid_fraction_assessed",
    "partial_imputation_results_retained",
    "coefficient_or_direction_in_failure_record"
  )
  published_metadata_fields <- c(
    "schema_version", "run_id", "created_at_utc",
    "freeze_contract_sha256", "coefficient_visibility",
    "completed_dataset_saved", "model_object_saved",
    "row_level_data_saved",
    "individual_probability_or_weight_saved",
    "independent_validation_status"
  )
  expected_fields <- c(
    "module", failure_fields, published_metadata_fields
  )
  expected_mi <- if (startsWith(module, "W2-")) "MI-C2" else "MI-C0"
  forbidden_result_fields <- c(
    "beta", "coefficient", "coefficients", "direction",
    "estimate", "estimates", "point", "replicates"
  )
  if (!xor(is_prefix, is_full) ||
      !identical(names(value), expected_fields) ||
      !identical(value$mi_object, expected_mi) ||
      any(tolower(names(value)) %in% forbidden_result_fields) ||
      !identical(value$requested_m, 50L) ||
      !identical(
        as.integer(value$replicate_indices),
        if (is_prefix) seq_len(250L) else seq_len(500L)
      ) ||
      !identical(
        as.integer(value$requested_replicate_indices),
        if (is_prefix) seq_len(250L) else 251:500
      ) ||
      length(value$executed_in_this_transaction) != 0L ||
      !(if (is_prefix) {
        length(value$prefix_sha256) == 1L &&
          is.na(value$prefix_sha256)
      } else {
        length(value$prefix_sha256) == 1L &&
          !is.na(value$prefix_sha256) &&
          grepl("^[0-9a-f]{64}$", value$prefix_sha256)
      }) ||
      length(value$literal_prefix_identity) != 1L ||
      !is.na(value$literal_prefix_identity) ||
      !is.list(value$results) || length(value$results) != 0L ||
      !is.data.frame(value$sample_anchors) ||
      nrow(value$sample_anchors) != 0L ||
      length(value$minimum_valid_replicate_fraction) != 1L ||
      !is.na(value$minimum_valid_replicate_fraction) ||
      !(if (is_prefix) {
        identical(value$prefix_gate, "STOP") &&
          length(value$full_gate) == 1L && is.na(value$full_gate)
      } else {
        identical(value$full_gate, "STOP") &&
          length(value$prefix_gate) == 1L &&
          is.na(value$prefix_gate)
      }) ||
      !identical(
        value$coefficient_blind_prefix_gate, is_prefix
      ) ||
      !identical(value$prefix_pooling_or_release_performed, FALSE) ||
      !identical(value$no_replacement_replicates, TRUE) ||
      !identical(value$variance_rule, "1/(B_valid-1)") ||
      !identical(value$common_failure_masks_preserved, TRUE) ||
      !identical(
        value$pooling_status,
        "POINT_NOT_ESTIMABLE_WITH_REASON"
      ) ||
      length(value$point_failure_class) != 1L ||
      is.na(value$point_failure_class) ||
      !nzchar(value$point_failure_class) ||
      length(value$point_failure_reason) != 1L ||
      is.na(value$point_failure_reason) ||
      !nzchar(value$point_failure_reason) ||
      !identical(value$valid_fraction_assessed, FALSE) ||
      !identical(value$partial_imputation_results_retained, FALSE) ||
      !identical(
        value$coefficient_or_direction_in_failure_record, FALSE
      )) {
    v45cv_stop(module, " point-failure record schema differs.")
  }
  v45cv_validate_failure_summary(
    value$point_failure_summary, FALSE,
    paste0(module, " point-failure")
  )
  expected_class <- if (
    nrow(value$point_failure_summary) == 1L
  ) {
    value$point_failure_summary$failure_class[[1L]]
  } else "MULTIPLE_REGISTERED_POINT_FAILURE_CLASSES"
  if (!identical(
        as.character(value$point_failure_class),
        as.character(expected_class)
      )) {
    v45cv_stop(module, " aggregate point-failure class differs.")
  }
  v45cv_stop(
    module,
    " is a valid restricted point-failure record; ",
    "independent result release is blocked."
  )
}

v45cv_validate_anchor_record <- function(value) {
  anchor <- value$anchor
  common_fields <- c(
    "gate", "tolerance", "failure_class", "failure_reason",
    "failure_summary", "per_imputation", "computed_v44_Qbar",
    "computed_v45_Qbar", "maximum_absolute_difference",
    "comparison_role", "Rao_Wu_SE_identity_required",
    "partial_imputation_results_retained",
    "coefficient_or_direction_in_failure_record"
  )
  identity_fields <- append(
    common_fields, "public_v44_Qbar", after = 2L
  )
  if (!is.list(anchor) ||
      length(anchor$gate) != 1L || is.na(anchor$gate) ||
      !anchor$gate %in% c("PASS", "FAIL") ||
      !identical(as.numeric(anchor$tolerance), 1e-8) ||
      !identical(
        anchor$comparison_role,
        "point_estimate_only_sidecar_gate"
      ) ||
      !identical(anchor$Rao_Wu_SE_identity_required, FALSE) ||
      !identical(anchor$partial_imputation_results_retained, FALSE)) {
    v45cv_stop("anchor-point status contract is invalid.")
  }
  v45cv_validate_failure_summary(
    anchor$failure_summary, TRUE, "anchor-point"
  )
  identity_payload <- function() {
    per <- anchor$per_imputation
    expected_per <- c(
      "imputation", "v44_beta", "v45_beta",
      "absolute_difference"
    )
    if (!identical(names(anchor), identity_fields) ||
        !identical(
          as.numeric(anchor$public_v44_Qbar),
          0.354509670529553
        ) ||
        !is.data.frame(per) ||
        !identical(names(per), expected_per) ||
        nrow(per) != 50L ||
        !identical(as.integer(per$imputation), seq_len(50L)) ||
        !is.numeric(per$v44_beta) || !is.numeric(per$v45_beta) ||
        !is.numeric(per$absolute_difference) ||
        !isTRUE(all.equal(
          per$absolute_difference,
          abs(per$v44_beta - per$v45_beta),
          tolerance = 0, check.attributes = FALSE
        ))) {
      v45cv_stop("anchor-point identity payload differs.")
    }
    per
  }
  if (identical(anchor$gate, "PASS")) {
    per <- identity_payload()
    finite <- all(is.finite(per$v44_beta)) &&
      all(is.finite(per$v45_beta))
    computed_v44 <- mean(per$v44_beta)
    computed_v45 <- mean(per$v45_beta)
    maximum_difference <- max(per$absolute_difference)
    if (!identical(anchor$failure_class, "") ||
        !identical(anchor$failure_reason, "") ||
        nrow(anchor$failure_summary) != 0L ||
        !finite ||
        maximum_difference > anchor$tolerance ||
        abs(computed_v44 - computed_v45) > anchor$tolerance ||
        abs(
          computed_v44 - anchor$public_v44_Qbar
        ) > anchor$tolerance ||
        abs(
          computed_v45 - anchor$public_v44_Qbar
        ) > anchor$tolerance ||
        !v45cv_num_equal(
          anchor$computed_v44_Qbar, computed_v44,
          tolerance = 1e-14
        ) ||
        !v45cv_num_equal(
          anchor$computed_v45_Qbar, computed_v45,
          tolerance = 1e-14
        ) ||
        !v45cv_num_equal(
          anchor$maximum_absolute_difference,
          maximum_difference, tolerance = 1e-14
        ) ||
        !identical(
          anchor$coefficient_or_direction_in_failure_record, FALSE
        )) {
      v45cv_stop("anchor-point PASS retained a failure record.")
    }
    return(invisible(TRUE))
  }
  if (length(anchor$failure_class) != 1L ||
      is.na(anchor$failure_class) ||
      !nzchar(anchor$failure_class) ||
      length(anchor$failure_reason) != 1L ||
      is.na(anchor$failure_reason) ||
      !nzchar(anchor$failure_reason)) {
    v45cv_stop("anchor-point FAIL reason is incomplete.")
  }
  registered_failure <- nrow(anchor$failure_summary) > 0L
  if (registered_failure) {
    expected_class <- if (nrow(anchor$failure_summary) == 1L) {
      anchor$failure_summary$failure_class[[1L]]
    } else "MULTIPLE_REGISTERED_POINT_FAILURE_CLASSES"
    if (!identical(
          as.character(anchor$failure_class),
          as.character(expected_class)
        ) ||
        !identical(names(anchor), common_fields) ||
        !is.data.frame(anchor$per_imputation) ||
        nrow(anchor$per_imputation) != 0L ||
        length(names(anchor$per_imputation)) != 0L ||
        !all(is.na(c(
          anchor$computed_v44_Qbar,
          anchor$computed_v45_Qbar,
          anchor$maximum_absolute_difference
        ))) ||
        !identical(
          anchor$coefficient_or_direction_in_failure_record, FALSE
        )) {
      v45cv_stop("anchor-point registered FAIL record differs.")
    }
  } else {
    per <- identity_payload()
    if (!anchor$failure_class %in% c(
          "ANCHOR_IDENTITY_MISMATCH", "ANCHOR_VALUE_INVALID"
        ) ||
        !identical(
          anchor$coefficient_or_direction_in_failure_record, TRUE
        )) {
      v45cv_stop("anchor-point identity FAIL record differs.")
    }
    finite <- all(is.finite(per$v44_beta)) &&
      all(is.finite(per$v45_beta))
    if ((anchor$failure_class == "ANCHOR_VALUE_INVALID" && finite) ||
        (anchor$failure_class == "ANCHOR_IDENTITY_MISMATCH" &&
         !finite)) {
      v45cv_stop("anchor-point identity failure class differs.")
    }
    if (finite) {
      computed_v44 <- mean(per$v44_beta)
      computed_v45 <- mean(per$v45_beta)
      maximum_difference <- max(per$absolute_difference)
      if (maximum_difference <= anchor$tolerance &&
          abs(computed_v44 - computed_v45) <= anchor$tolerance &&
          abs(
            computed_v44 - anchor$public_v44_Qbar
          ) <= anchor$tolerance &&
          abs(
            computed_v45 - anchor$public_v44_Qbar
          ) <= anchor$tolerance) {
        v45cv_stop("anchor-point identity FAIL has no failed criterion.")
      }
      if (!v45cv_num_equal(
            anchor$computed_v44_Qbar, computed_v44,
            tolerance = 1e-14
          ) ||
          !v45cv_num_equal(
            anchor$computed_v45_Qbar, computed_v45,
            tolerance = 1e-14
          ) ||
          !v45cv_num_equal(
            anchor$maximum_absolute_difference,
            maximum_difference, tolerance = 1e-14
          )) {
        v45cv_stop("anchor-point identity FAIL summaries differ.")
      }
    }
  }
  v45cv_stop(
    "anchor-point is a valid restricted FAIL record; ",
    "independent result release is blocked."
  )
}

v45cv_validate_recorded_pooling_status <- function(module, value) {
  if (identical(module, "anchor-point")) {
    return(v45cv_validate_anchor_record(value))
  }
  if (identical(
        value$pooling_status,
        "POINT_NOT_ESTIMABLE_WITH_REASON"
      )) {
    return(v45cv_validate_point_failure_record(module, value))
  }
  if (endsWith(module, "-prefix")) {
    if (!identical(
          value$pooling_status, "NOT_APPLICABLE_PREFIX"
        ) ||
        !identical(value$pooling_failure_class, "") ||
        !identical(value$pooling_failure_reason, "")) {
      v45cv_stop(
        module, " prefix pooling-status contract is invalid."
      )
    }
    return(invisible(TRUE))
  }
  if (endsWith(module, "-full")) {
    allowed <- c(
      "COMPLETE", "NOT_PERFORMED_FULL_GATE_STOP",
      "NOT_ESTIMABLE_WITH_REASON"
    )
    if (length(value$pooling_status) != 1L ||
        is.na(value$pooling_status) ||
        !value$pooling_status %in% allowed) {
      v45cv_stop(
        module, " full pooling-status contract is invalid."
      )
    }
    if (!identical(value$pooling_status, "COMPLETE")) {
      if (length(value$pooling_failure_class) != 1L ||
          is.na(value$pooling_failure_class) ||
          !nzchar(value$pooling_failure_class) ||
          length(value$pooling_failure_reason) != 1L ||
          is.na(value$pooling_failure_reason) ||
          !nzchar(value$pooling_failure_reason)) {
        v45cv_stop(
          module,
          " retained non-estimable pooling reason is incomplete."
        )
      }
      v45cv_stop(
        module, " is a valid restricted non-release record with ",
        "pooling_status=", value$pooling_status,
        " and failure_class=", value$pooling_failure_class,
        "; independent result release is blocked."
      )
    }
    if (!identical(value$pooling_failure_class, "") ||
        !identical(value$pooling_failure_reason, "")) {
      v45cv_stop(
        module, " COMPLETE pooling retained a failure reason."
      )
    }
    return(invisible(TRUE))
  }
  v45cv_stop("Unknown module suffix in pooling-status audit: ", module)
}

v45cv_regular_file <- function(path) {
  length(path) == 1L && !is.na(path) && nzchar(path) &&
    file.exists(path) && !dir.exists(path) && !nzchar(Sys.readlink(path))
}

v45cv_sha256_file <- function(path) {
  if (!v45cv_regular_file(path)) {
    v45cv_stop("SHA-256 requires a regular non-symlink file: ", path)
  }
  digest::digest(path, algo = "sha256", file = TRUE)
}

v45cv_alias <- function(path) {
  sub(
    paste0("^", root, "/?"), "",
    normalizePath(path, mustWork = FALSE)
  )
}

v45cv_safe_alias <- function(
    alias, allowed_prefix, regular = TRUE, must_exist = TRUE) {
  if (length(alias) != 1L || is.na(alias) || !nzchar(alias) ||
      startsWith(alias, "/")) {
    v45cv_stop("Unsafe path alias.")
  }
  pieces <- strsplit(alias, "/", fixed = TRUE)[[1L]]
  if (any(pieces %in% c("", ".", ".."))) {
    v45cv_stop("Unsafe path alias component: ", alias)
  }
  path <- file.path(root, alias)
  if (isTRUE(must_exist)) {
    if (isTRUE(regular) && !v45cv_regular_file(path)) {
      v45cv_stop("Required regular file is absent: ", alias)
    }
    if (!isTRUE(regular) && !dir.exists(path)) {
      v45cv_stop("Required directory is absent: ", alias)
    }
  }
  parent <- if (isTRUE(must_exist)) {
    normalizePath(path, mustWork = TRUE)
  } else {
    normalizePath(dirname(path), mustWork = TRUE)
  }
  allowed <- normalizePath(file.path(root, allowed_prefix), mustWork = TRUE)
  if (!identical(parent, allowed) &&
      !startsWith(parent, paste0(allowed, .Platform$file.sep))) {
    v45cv_stop("Path alias escapes its permitted root: ", alias)
  }
  path
}

v45cv_read_tsv <- function(path) {
  if (!v45cv_regular_file(path)) {
    v45cv_stop("TSV is absent or unsafe: ", path)
  }
  before <- v45cv_sha256_file(path)
  out <- utils::read.delim(
    path, stringsAsFactors = FALSE, check.names = FALSE,
    na.strings = character()
  )
  if (!identical(before, v45cv_sha256_file(path))) {
    v45cv_stop("TSV changed while it was read: ", path)
  }
  out
}

v45cv_read_yaml <- function(path) {
  if (!v45cv_regular_file(path)) {
    v45cv_stop("YAML is absent or unsafe: ", path)
  }
  before <- v45cv_sha256_file(path)
  out <- yaml::read_yaml(path)
  if (!identical(before, v45cv_sha256_file(path))) {
    v45cv_stop("YAML changed while it was read: ", path)
  }
  out
}

v45cv_num_equal <- function(x, y, tolerance = 1e-12) {
  x <- as.numeric(x)
  y <- as.numeric(y)
  if (length(x) != length(y) ||
      !identical(is.na(x), is.na(y)) ||
      !identical(is.finite(x), is.finite(y))) {
    return(FALSE)
  }
  finite <- is.finite(x) & is.finite(y)
  if (!any(finite)) return(TRUE)
  scale <- pmax(1, abs(x[finite]), abs(y[finite]))
  all(abs(x[finite] - y[finite]) <= tolerance * scale)
}

v45cv_atomic_write_yaml <- function(value, path) {
  temporary <- v45_charls_outcome_atomic_target(path)
  on.exit(if (file.exists(temporary)) unlink(temporary, force = TRUE),
          add = TRUE)
  yaml::write_yaml(value, temporary)
  v45_charls_outcome_atomic_promote(temporary, path)
}

v45cv_rehash_manifest <- function(
    manifest, label, access_column = NULL) {
  required <- c("asset_id", "path_alias", "bytes", "sha256")
  if (!is.data.frame(manifest) ||
      !all(required %in% names(manifest)) ||
      !nrow(manifest) || anyDuplicated(manifest$asset_id) ||
      anyNA(manifest[required]) ||
      any(!grepl("^[0-9a-f]{64}$", manifest$sha256))) {
    v45cv_stop(label, " manifest schema is invalid.")
  }
  if (!is.null(access_column) &&
      (!access_column %in% names(manifest) ||
       anyNA(manifest[[access_column]]))) {
    v45cv_stop(label, " manifest access field is invalid.")
  }
  pass <- vapply(seq_len(nrow(manifest)), function(index) {
    alias <- as.character(manifest$path_alias[[index]])
    allowed <- strsplit(alias, "/", fixed = TRUE)[[1L]][[1L]]
    if (!allowed %in% c(
          "R", "work_v45", "results", "derived_sensitive",
          "output", "renv", "config"
        )) {
      v45cv_stop(label, " contains an unauthorized path root: ", alias)
    }
    path <- v45cv_safe_alias(alias, allowed)
    identical(v45cv_sha256_file(path), manifest$sha256[[index]]) &&
      identical(
        as.numeric(file.info(path)$size),
        as.numeric(manifest$bytes[[index]])
      )
  }, logical(1))
  if (!all(pass)) {
    v45cv_stop(label, " manifest rehash failed for: ",
               paste(manifest$asset_id[!pass], collapse = "|"))
  }
  invisible(TRUE)
}

v45cv_forbidden_payload_audit <- function(object, module) {
  forbidden_names <- c(
    "participant_id", "community_id", "row_level_data",
    "person_level_data", "completed", "completed_data", "mids",
    "person", "persons", "person_period", "period_data",
    "fit", "fits", "model_object", "model_objects", "survey_design",
    "probability", "probabilities", "fitted_probability",
    "fitted_probabilities", "availability", "availability_factor",
    "availability_factors", "individual_probability",
    "individual_probabilities", "individual_weight",
    "individual_weights", "person_weight", "person_weights",
    "base_weight", "base_weights", "composite_weight",
    "composite_weights", "replicate_multiplier",
    "replicate_multipliers", "respondent", "respondents",
    "key_map", "key_index"
  )
  forbidden_classes <- c(
    "mids", "glm", "lm", "svyglm", "survey.design",
    "survey.design2", "v45_charls_outcome_restricted"
  )
  violations <- character()
  walk <- function(value, path = module) {
    if (inherits(value, forbidden_classes)) {
      violations <<- c(
        violations,
        paste0(path, "::class=", paste(class(value), collapse = "|"))
      )
    }
    value_names <- names(value)
    if (!is.null(value_names)) {
      hit <- tolower(value_names) %in% forbidden_names
      if (any(hit)) {
        violations <<- c(
          violations,
          paste0(path, "::name=", value_names[hit])
        )
      }
    }
    if (is.list(value)) {
      labels <- names(value)
      if (is.null(labels)) labels <- as.character(seq_along(value))
      for (index in seq_along(value)) {
        walk(value[[index]], paste0(path, "/", labels[[index]]))
      }
    }
    invisible(NULL)
  }
  walk(object)
  violations <- unique(violations)
  if (length(violations)) {
    v45cv_stop(
      module, " retained a forbidden row/fit/probability/weight payload: ",
      paste(violations, collapse = "; ")
    )
  }
  invisible(TRUE)
}

v45cv_metric_gate <- function(metric, value) {
  if (length(value) != 1L || !is.finite(value)) return("STOP")
  switch(
    metric,
    response_probability_p01 =
      if (value <= 0.01) "STOP" else
        if (value >= 0.05) "GO" else "CAUTION",
    availability_factor_p99 =
      if (value > 20) "STOP" else
        if (value <= 10) "GO" else "CAUTION",
    ESS_ratio =
      if (value < 0.30) "STOP" else
        if (value >= 0.50) "GO" else "CAUTION",
    maximum_absolute_SMD =
      if (value > 0.20) "STOP" else
        if (value <= 0.10) "GO" else "CAUTION",
    valid_replicate_fraction =
      if (value < 0.90) "STOP" else
        if (value >= 0.95) "GO" else "CAUTION",
    v45cv_stop("Unknown frozen diagnostic metric: ", metric)
  )
}

v45cv_replicate_names <- function(n) {
  sprintf("R%03d", seq_len(as.integer(n)))
}

v45cv_dfcom_by_column <- function(group) {
  columns <- names(group$point)
  if (!is.null(group$dfcom_by_column)) {
    value <- as.numeric(group$dfcom_by_column)
    names(value) <- names(group$dfcom_by_column)
    if (!identical(names(value), columns) ||
        any(!is.finite(value) | value <= 0)) {
      v45cv_stop(group$group_id, " has invalid dfcom_by_column.")
    }
    return(value)
  }
  value <- as.numeric(group$dfcom)
  if (length(value) != 1L || !is.finite(value) || value <= 0) {
    v45cv_stop(group$group_id, " lacks a valid dfcom contract.")
  }
  setNames(rep(value, length(columns)), columns)
}

v45cv_validate_group <- function(
    group, nominal_n, module, imputation,
    recorded_covariance_required = TRUE) {
  required <- c(
    "group_id", "point", "replicates", "common_valid_mask",
    "within_covariance", "valid_replicate_n",
    "valid_replicate_fraction", "valid_fraction_gate",
    "variance_denominator", "nominal_replicates",
    "failure_class_by_replicate", "scale_rule",
    "common_failure_mask", "covariance_computed",
    "coefficient_blind_prefix_eligible"
  )
  if (!is.list(group) || !all(required %in% names(group))) {
    v45cv_stop(module, "/imputation", imputation,
               " group schema is incomplete.")
  }
  point <- group$point
  replicates <- group$replicates
  if (!is.numeric(point) || !length(point) ||
      is.null(names(point)) || anyDuplicated(names(point)) ||
      any(!is.finite(point)) || !is.matrix(replicates) ||
      !identical(colnames(replicates), names(point)) ||
      !identical(rownames(replicates), v45cv_replicate_names(nominal_n)) ||
      !identical(dim(replicates),
                 c(as.integer(nominal_n), length(point)))) {
    v45cv_stop(module, "/imputation", imputation, "/",
               group$group_id, " point/replicate schema failed.")
  }
  valid <- apply(replicates, 1L, function(value) all(is.finite(value)))
  names(valid) <- rownames(replicates)
  valid_n <- sum(valid)
  if (valid_n < 2L) {
    v45cv_stop(module, "/imputation", imputation, "/",
               group$group_id, " has fewer than two common-valid columns.")
  }
  retained <- replicates[valid, , drop = FALSE]
  centered <- sweep(retained, 2L, point, FUN = "-")
  covariance <- crossprod(centered) / (valid_n - 1L)
  dimnames(covariance) <- list(names(point), names(point))
  fraction <- valid_n / nominal_n
  gate <- v45cv_metric_gate("valid_replicate_fraction", fraction)
  failure <- as.character(group$failure_class_by_replicate)
  if (length(failure) != nominal_n ||
      anyNA(failure) ||
      !identical(
        unname(as.logical(group$common_valid_mask)),
        unname(valid)
      ) ||
      !identical(names(group$common_valid_mask), names(valid)) ||
      !identical(as.integer(group$valid_replicate_n),
                 as.integer(valid_n)) ||
      !v45cv_num_equal(group$valid_replicate_fraction, fraction) ||
      !identical(as.character(group$valid_fraction_gate), gate) ||
      !identical(as.integer(group$nominal_replicates),
                 as.integer(nominal_n)) ||
      !identical(as.character(group$scale_rule), "1/(B_valid-1)") ||
      !isTRUE(group$common_failure_mask) ||
      any((nzchar(failure)) != !valid)) {
    v45cv_stop(module, "/imputation", imputation, "/",
               group$group_id,
               " independent mask/covariance reconstruction differs.")
  }
  if (isTRUE(recorded_covariance_required)) {
    if (!isTRUE(group$covariance_computed) ||
        isTRUE(group$coefficient_blind_prefix_eligible) ||
        !identical(as.integer(group$variance_denominator),
                   as.integer(valid_n - 1L)) ||
        !v45cv_num_equal(
          as.numeric(group$within_covariance),
          as.numeric(covariance)
        ) ||
        !identical(dimnames(group$within_covariance),
                   dimnames(covariance))) {
      v45cv_stop(module, "/imputation", imputation, "/",
                 group$group_id,
                 " recorded full covariance differs.")
    }
  } else {
    if (isTRUE(group$covariance_computed) ||
        !isTRUE(group$coefficient_blind_prefix_eligible) ||
        !all(is.na(group$within_covariance)) ||
        !identical(dim(group$within_covariance),
                   dim(covariance)) ||
        !identical(dimnames(group$within_covariance),
                   dimnames(covariance)) ||
        !is.na(group$variance_denominator)) {
      v45cv_stop(module, "/imputation", imputation, "/",
                 group$group_id,
                 " prefix retained covariance or lost its blind flag.")
    }
  }
  list(
    group_id = as.character(group$group_id),
    point = point,
    replicates = replicates,
    valid = valid,
    covariance = covariance,
    valid_n = valid_n,
    valid_fraction = fraction,
    gate = gate,
    dfcom_by_column = v45cv_dfcom_by_column(group),
    failure_n = sum(!valid)
  )
}

v45cv_validate_result_set <- function(
    module_object, nominal_n, module_label,
    recorded_covariance_required = TRUE) {
  if (!is.list(module_object$results) ||
      length(module_object$results) != 50L ||
      !identical(
        vapply(
          module_object$results, `[[`, integer(1), "imputation"
        ),
        seq_len(50L)
      )) {
    v45cv_stop(module_label, " does not contain exact MI 1:50.")
  }
  lapply(seq_len(50L), function(imputation) {
    result <- module_object$results[[imputation]]
    if (!is.list(result$groups) || !length(result$groups) ||
        is.null(names(result$groups)) ||
        anyDuplicated(names(result$groups))) {
      v45cv_stop(module_label, "/imputation", imputation,
                 " group container failed.")
    }
    groups <- lapply(names(result$groups), function(group_id) {
      value <- v45cv_validate_group(
        result$groups[[group_id]], nominal_n,
        module_label, imputation,
        recorded_covariance_required =
          recorded_covariance_required
      )
      if (!identical(value$group_id, group_id)) {
        v45cv_stop(module_label, "/imputation", imputation,
                   " group name/id differs.")
      }
      value
    })
    names(groups) <- names(result$groups)
    list(imputation = imputation, groups = groups)
  })
}

v45cv_validate_prefix_full <- function(
    prefix, full, module_label, include_w2_diagnostics = FALSE) {
  if (!identical(as.integer(prefix$replicate_indices), 1:250) ||
      !identical(as.integer(full$replicate_indices), 1:500)) {
    v45cv_stop(module_label, " replicate index contract failed.")
  }
  if (!is.null(prefix$prefix_gate) &&
      !as.character(prefix$prefix_gate) %in% c("GO", "CAUTION")) {
    v45cv_stop(module_label,
               " prefix gate is neither GO nor CAUTION.")
  }
  for (imputation in seq_len(50L)) {
    pre <- prefix$results[[imputation]]
    complete <- full$results[[imputation]]
    if (!identical(names(pre$groups), names(complete$groups))) {
      v45cv_stop(module_label, "/imputation", imputation,
                 " prefix/full group order differs.")
    }
    for (group_id in names(pre$groups)) {
      pre_group <- pre$groups[[group_id]]
      full_group <- complete$groups[[group_id]]
      if (!identical(pre_group$point, full_group$point) ||
          !identical(
            pre_group$replicates,
            full_group$replicates[1:250, , drop = FALSE]
          ) ||
          !identical(
            as.character(pre_group$failure_class_by_replicate),
            as.character(
              full_group$failure_class_by_replicate[1:250]
            )
          )) {
        v45cv_stop(module_label, "/imputation", imputation, "/",
                   group_id, " literal prefix identity failed.")
      }
    }
    if (isTRUE(include_w2_diagnostics)) {
      if (!identical(
            pre$response_point_diagnostic,
            complete$response_point_diagnostic
          ) ||
          !identical(
            pre$response_replicate_diagnostics,
            complete$response_replicate_diagnostics[
              1:250, , drop = FALSE
            ]
          )) {
        v45cv_stop(module_label, "/imputation", imputation,
                   " W2 response prefix identity failed.")
      }
    }
  }
  invisible(TRUE)
}

v45cv_pool_scalar <- function(Q, U, dfcom, scalar_id) {
  Q <- as.numeric(Q)
  U <- as.numeric(U)
  dfcom <- as.numeric(dfcom)
  if (length(Q) != 50L || length(U) != 50L ||
      any(!is.finite(Q)) || any(!is.finite(U) | U <= 0) ||
      length(dfcom) != 1L || !is.finite(dfcom) || dfcom <= 0) {
    v45cv_stop(scalar_id, " has invalid independent Rubin inputs.")
  }
  pooled <- mice::pool.scalar(
    Q = Q, U = U, n = dfcom + 1, k = 1,
    rule = "rubin1987"
  )
  standard_error <- sqrt(pooled$t)
  critical <- if (is.finite(pooled$df)) {
    stats::qt(0.975, df = pooled$df)
  } else {
    stats::qnorm(0.975)
  }
  statistic <- pooled$qbar / standard_error
  p_value <- if (is.finite(pooled$df)) {
    2 * stats::pt(abs(statistic), df = pooled$df,
                  lower.tail = FALSE)
  } else {
    2 * stats::pnorm(abs(statistic), lower.tail = FALSE)
  }
  data.frame(
    m = as.integer(pooled$m),
    estimate = pooled$qbar,
    standard_error = standard_error,
    ci_low = pooled$qbar - critical * standard_error,
    ci_high = pooled$qbar + critical * standard_error,
    p_value = p_value,
    within_variance = pooled$ubar,
    between_variance = pooled$b,
    total_variance = pooled$t,
    df = pooled$df,
    dfcom = dfcom,
    FMI = pooled$fmi,
    MCE = sqrt(pooled$b / pooled$m),
    MCE_fraction =
      sqrt(pooled$b / pooled$m) / standard_error,
    stringsAsFactors = FALSE
  )
}

v45cv_pool_multivariate <- function(Q, U, test_id) {
  Q <- as.matrix(Q)
  terms <- colnames(Q)
  if (!identical(nrow(Q), 50L) || ncol(Q) < 2L ||
      is.null(terms) || anyDuplicated(terms) ||
      any(!is.finite(Q)) || length(U) != 50L) {
    v45cv_stop(test_id, " has invalid independent joint-test inputs.")
  }
  U <- lapply(seq_along(U), function(index) {
    value <- as.matrix(U[[index]])
    if (!identical(dim(value), c(ncol(Q), ncol(Q))) ||
        !identical(rownames(value), terms) ||
        !identical(colnames(value), terms) ||
        any(!is.finite(value)) ||
        !v45cv_num_equal(value, t(value))) {
      v45cv_stop(test_id, "/U", index,
                 " has invalid within-imputation covariance.")
    }
    eigenvalues <- eigen(
      value, symmetric = TRUE, only.values = TRUE
    )$values
    tolerance <- .Machine$double.eps *
      max(1, length(terms), max(abs(eigenvalues)))
    if (min(eigenvalues) <= tolerance) {
      v45cv_stop(test_id, "/U", index,
                 " is not positive definite.")
    }
    value
  })
  Qbar <- colMeans(Q)
  Ubar <- Reduce("+", U) / length(U)
  between <- stats::cov(Q)
  dimnames(between) <- list(terms, terms)
  total <- Ubar + (1 + 1 / nrow(Q)) * between
  total <- (total + t(total)) / 2
  dimnames(total) <- list(terms, terms)
  eigenvalues <- eigen(
    total, symmetric = TRUE, only.values = TRUE
  )$values
  tolerance <- .Machine$double.eps *
    max(1, length(terms), max(abs(eigenvalues)))
  if (min(eigenvalues) <= tolerance) {
    v45cv_stop(test_id, " total covariance is singular/nonpositive.")
  }
  statistic <- as.numeric(crossprod(Qbar, solve(total, Qbar)))
  if (!is.finite(statistic) || statistic < -1e-10) {
    v45cv_stop(test_id, " produced an invalid Rubin-Wald statistic.")
  }
  list(
    test = data.frame(
      test_id = test_id,
      terms = paste(terms, collapse = ";"),
      m = 50L,
      df = ncol(Q),
      statistic = max(0, statistic),
      p_value = stats::pchisq(
        max(0, statistic), df = ncol(Q), lower.tail = FALSE
      ),
      stringsAsFactors = FALSE
    ),
    Qbar = Qbar,
    Ubar = Ubar,
    between = between,
    total = total
  )
}

v45cv_pool_module <- function(
    validated_results, scalar_map, joint_definitions,
    module, mi_object) {
  required_map <- c(
    "group_id", "column", "analysis_id", "term", "MCE_trigger"
  )
  if (!is.data.frame(scalar_map) ||
      !all(required_map %in% names(scalar_map)) ||
      anyDuplicated(paste(scalar_map$group_id, scalar_map$column)) ||
      anyDuplicated(paste(scalar_map$analysis_id, scalar_map$term))) {
    v45cv_stop(module, " scalar map is invalid.")
  }
  per <- do.call(rbind, lapply(seq_len(nrow(scalar_map)), function(index) {
    map <- scalar_map[index, , drop = FALSE]
    do.call(rbind, lapply(validated_results, function(result) {
      group <- result$groups[[map$group_id[[1L]]]]
      column <- as.character(map$column[[1L]])
      if (is.null(group) || !column %in% names(group$point)) {
        v45cv_stop(module, " scalar map references an absent column.")
      }
      data.frame(
        analysis_id = as.character(map$analysis_id[[1L]]),
        term = as.character(map$term[[1L]]),
        group_id = as.character(map$group_id[[1L]]),
        imputation = result$imputation,
        estimate = unname(group$point[[column]]),
        within_variance =
          unname(group$covariance[column, column]),
        dfcom = unname(group$dfcom_by_column[[column]]),
        valid_replicate_n = group$valid_n,
        valid_replicate_fraction = group$valid_fraction,
        valid_fraction_gate = group$gate,
        MCE_trigger = as.logical(map$MCE_trigger[[1L]]),
        stringsAsFactors = FALSE
      )
    }))
  }))
  rownames(per) <- NULL
  keys <- unique(per[c(
    "analysis_id", "term", "group_id", "MCE_trigger"
  )])
  pooled <- do.call(rbind, lapply(seq_len(nrow(keys)), function(index) {
    key <- keys[index, , drop = FALSE]
    use <- per$analysis_id == key$analysis_id[[1L]] &
      per$term == key$term[[1L]] &
      per$group_id == key$group_id[[1L]]
    value <- per[use, , drop = FALSE]
    value <- value[order(value$imputation), , drop = FALSE]
    if (!identical(value$imputation, seq_len(50L))) {
      v45cv_stop(module, " scalar lacks exact imputation order 1:50.")
    }
    result <- v45cv_pool_scalar(
      value$estimate, value$within_variance,
      min(value$dfcom),
      paste0(key$analysis_id[[1L]], "::", key$term[[1L]])
    )
    cbind(
      key,
      module = module,
      mi_object = mi_object,
      minimum_valid_replicate_fraction =
        min(value$valid_replicate_fraction),
      worst_valid_fraction_gate = if (
        any(value$valid_fraction_gate == "STOP")
      ) "STOP" else if (
        any(value$valid_fraction_gate == "CAUTION")
      ) "CAUTION" else "GO",
      result,
      stringsAsFactors = FALSE
    )
  }))
  rownames(pooled) <- NULL

  joint <- lapply(joint_definitions, function(definition) {
    group_id <- as.character(definition$group_id)
    columns <- as.character(definition$columns)
    Q <- do.call(rbind, lapply(validated_results, function(result) {
      group <- result$groups[[group_id]]
      if (is.null(group) || !all(columns %in% names(group$point))) {
        v45cv_stop(definition$test_id,
                   " references an absent joint-test column.")
      }
      unname(group$point[columns])
    }))
    colnames(Q) <- columns
    U <- lapply(validated_results, function(result) {
      result$groups[[group_id]]$covariance[
        columns, columns, drop = FALSE
      ]
    })
    value <- v45cv_pool_multivariate(Q, U, definition$test_id)
    value$test$module <- module
    value$test$mi_object <- mi_object
    value
  })
  names(joint) <- vapply(
    joint_definitions, `[[`, character(1), "test_id"
  )
  list(per_imputation = per, pooled_scalar = pooled, joints = joint)
}

v45cv_joint_release_table <- function(module_pools) {
  normalization <- c(
    v45_c_inconsistency_spline_a1_overall =
      "v45_c_inconsistency_spline_a1",
    v45_c_inconsistency_spline_joint_nonlinear =
      "v45_c_inconsistency_spline_joint",
    v45_c_time_heterogeneity_joint =
      "v45_c_time_heterogeneity_joint"
  )
  rows <- unlist(
    lapply(module_pools, `[[`, "joints"),
    recursive = FALSE
  )
  if (!length(rows)) {
    return(data.frame())
  }
  out <- do.call(rbind, lapply(rows, function(value) value$test))
  rownames(out) <- NULL
  if (!all(out$test_id %in% names(normalization))) {
    v45cv_stop("Unexpected multivariate joint-test ID.")
  }
  out$analysis_id <- unname(normalization[out$test_id])
  out
}

v45cv_validate_structurally_constant_balance_log <- function(
    diagnostic, valid, label) {
  count_column <- "structurally_constant_balance_columns"
  name_column <- "structurally_constant_balance_column_names"
  if (!is.data.frame(diagnostic) ||
      !all(c(count_column, name_column) %in% names(diagnostic)) ||
      length(valid) != nrow(diagnostic) ||
      anyNA(valid)) {
    v45cv_stop(label, " structural-constant balance log differs.")
  }
  valid <- as.logical(valid)
  counts <- suppressWarnings(as.numeric(diagnostic[[count_column]]))
  logged_names <- as.character(diagnostic[[name_column]])
  if (length(counts) != nrow(diagnostic) ||
      length(logged_names) != nrow(diagnostic) ||
      any(!is.na(counts[!valid])) ||
      any(!is.na(logged_names[!valid]))) {
    v45cv_stop(label, " structural-constant balance log differs.")
  }
  for (index in which(valid)) {
    count <- counts[[index]]
    logged <- logged_names[[index]]
    if (!is.finite(count) || count < 0 || count != floor(count) ||
        is.na(logged)) {
      v45cv_stop(label, " structural-constant balance log differs.")
    }
    names_at_row <- if (identical(logged, "")) {
      character()
    } else {
      strsplit(logged, "|", fixed = TRUE)[[1L]]
    }
    if (length(names_at_row) != as.integer(count) ||
        any(!nzchar(names_at_row)) ||
        anyDuplicated(names_at_row)) {
      v45cv_stop(label, " structural-constant balance log differs.")
    }
  }
  invisible(TRUE)
}

v45cv_validate_w2_diagnostics <- function(
    prefix, full, validated_full) {
  metrics <- c(
    "response_probability_p01", "availability_factor_p99",
    "ESS_ratio", "maximum_absolute_SMD"
  )
  status_columns <- c(
    response_probability_p01 = "response_probability_status",
    availability_factor_p99 = "availability_factor_status",
    ESS_ratio = "ESS_status",
    maximum_absolute_SMD = "maximum_absolute_SMD_status"
  )
  compact_columns <- c(
    metrics, "cap_p99", "cap_p97_5",
    "structurally_constant_balance_columns",
    "structurally_constant_balance_column_names",
    unname(status_columns), "overall_status"
  )
  replicate_columns <- c(
    compact_columns, "replicate", "response_fit_valid",
    "response_failure_class"
  )
  ipw_groups <- c(
    "W2_RESPONSE_SHARED", "W2_M12_ALL_VARIANTS",
    "W2_UNCAPPED_E0_W1", "W2_UNCAPPED_E0_W2",
    "W2_UNCAPPED_M12_D12"
  )
  point_rows <- list()
  replicate_rows <- list()
  for (imputation in seq_len(50L)) {
    raw <- full$results[[imputation]]
    independent <- validated_full[[imputation]]
    point <- raw$response_point_diagnostic
    replicate <- raw$response_replicate_diagnostics
    if (!is.data.frame(point) || nrow(point) != 1L ||
        !identical(names(point), compact_columns) ||
        !is.data.frame(replicate) || nrow(replicate) != 500L ||
        !identical(names(replicate), replicate_columns) ||
        !identical(
          as.character(replicate$replicate),
          v45cv_replicate_names(500L)
        )) {
      v45cv_stop("W2/imputation", imputation,
                 " diagnostic schema failed.")
    }
    v45cv_validate_structurally_constant_balance_log(
      point, TRUE, paste0("W2/imputation", imputation, "/point")
    )
    point_status <- vapply(metrics, function(metric) {
      v45cv_metric_gate(metric, point[[metric]][[1L]])
    }, character(1))
    point_overall <- if (any(point_status == "STOP")) {
      "STOP"
    } else if (any(point_status == "CAUTION")) {
      "CAUTION"
    } else "GO"
    recorded_point <- vapply(
      metrics,
      function(metric) as.character(
        point[[status_columns[[metric]]]][[1L]]
      ),
      character(1)
    )
    if (!identical(point_status, recorded_point) ||
        !identical(
          as.character(point$overall_status[[1L]]), point_overall
        ) ||
        identical(point_overall, "STOP")) {
      v45cv_stop("W2/imputation", imputation,
                 " point response/IPW gate differs or is STOP.")
    }
    point_rows[[imputation]] <- data.frame(
      imputation = imputation,
      metric = metrics,
      value = as.numeric(unlist(
        point[1L, metrics, drop = FALSE], use.names = FALSE
      )),
      status = unname(point_status),
      overall_status = point_overall,
      stringsAsFactors = FALSE
    )

    valid_response <- as.logical(replicate$response_fit_valid)
    if (length(valid_response) != 500L || anyNA(valid_response)) {
      v45cv_stop("W2/imputation", imputation,
                 " response validity vector is invalid.")
    }
    v45cv_validate_structurally_constant_balance_log(
      replicate, valid_response,
      paste0("W2/imputation", imputation, "/replicate")
    )
    recomputed_status <- matrix(
      NA_character_, nrow = 500L, ncol = length(metrics),
      dimnames = list(replicate$replicate, metrics)
    )
    for (row in seq_len(500L)) {
      if (isTRUE(valid_response[[row]])) {
        recomputed_status[row, ] <- vapply(
          metrics,
          function(metric) v45cv_metric_gate(
            metric, replicate[[metric]][[row]]
          ),
          character(1)
        )
        if (any(recomputed_status[row, ] == "STOP") ||
            nzchar(as.character(
              replicate$response_failure_class[[row]]
            ))) {
          v45cv_stop("W2/imputation", imputation, "/",
                     replicate$replicate[[row]],
                     " retained a STOP as response-valid.")
        }
      } else {
        recomputed_status[row, ] <- "STOP"
        if (!nzchar(as.character(
              replicate$response_failure_class[[row]]
            ))) {
          v45cv_stop("W2/imputation", imputation, "/",
                     replicate$replicate[[row]],
                     " invalid response lacks a failure class.")
        }
      }
    }
    for (metric in metrics) {
      if (!identical(
            recomputed_status[, metric],
            as.character(replicate[[status_columns[[metric]]]])
          )) {
        v45cv_stop("W2/imputation", imputation, "/",
                   metric, " replicate gate classification differs.")
      }
    }
    recomputed_overall <- apply(
      recomputed_status, 1L, function(value) {
        if (any(value == "STOP")) "STOP" else
          if (any(value == "CAUTION")) "CAUTION" else "GO"
      }
    )
    if (!identical(
          unname(recomputed_overall),
          as.character(replicate$overall_status)
        )) {
      v45cv_stop("W2/imputation", imputation,
                 " replicate overall gate differs.")
    }
    response_mask <-
      independent$groups[["W2_RESPONSE_SHARED"]]$valid
    if (!identical(unname(response_mask), valid_response)) {
      v45cv_stop("W2/imputation", imputation,
                 " shared response failure mask differs.")
    }
    for (group_id in setdiff(ipw_groups, "W2_RESPONSE_SHARED")) {
      group_mask <- independent$groups[[group_id]]$valid
      if (is.null(group_mask) || any(group_mask & !valid_response)) {
        v45cv_stop("W2/imputation", imputation, "/",
                   group_id,
                   " failed to propagate the response/IPW mask.")
      }
    }
    replicate_rows[[imputation]] <- data.frame(
      imputation = imputation,
      replicate = replicate$replicate,
      response_fit_valid = valid_response,
      overall_status = recomputed_overall,
      stringsAsFactors = FALSE
    )
  }
  point <- do.call(rbind, point_rows)
  replicate <- do.call(rbind, replicate_rows)
  if (any(point$overall_status == "STOP")) {
    v45cv_stop("A W2 point diagnostic is STOP.")
  }
  group_fractions <- do.call(rbind, lapply(
    validated_full, function(result) {
      do.call(rbind, lapply(names(result$groups), function(group_id) {
        data.frame(
          imputation = result$imputation,
          group_id = group_id,
          valid_replicate_fraction =
            result$groups[[group_id]]$valid_fraction,
          status = result$groups[[group_id]]$gate,
          stringsAsFactors = FALSE
        )
      }))
    }
  ))
  if (any(group_fractions$status == "STOP")) {
    v45cv_stop("At least one W2 full group has a STOP valid fraction.")
  }
  summary <- do.call(rbind, lapply(metrics, function(metric) {
    values <- point$value[point$metric == metric]
    data.frame(
      unit = "point",
      metric = metric,
      minimum = min(values),
      median = stats::median(values),
      maximum = max(values),
      GO_n = sum(point$status[point$metric == metric] == "GO"),
      CAUTION_n =
        sum(point$status[point$metric == metric] == "CAUTION"),
      STOP_n = sum(point$status[point$metric == metric] == "STOP"),
      stringsAsFactors = FALSE
    )
  }))
  response_summary <- data.frame(
    unit = "replicate",
    metric = "response_fit_and_uncapped_gate",
    minimum = NA_real_,
    median = NA_real_,
    maximum = NA_real_,
    GO_n = sum(replicate$overall_status == "GO"),
    CAUTION_n = sum(replicate$overall_status == "CAUTION"),
    STOP_n = sum(replicate$overall_status == "STOP"),
    stringsAsFactors = FALSE
  )
  list(
    point = point,
    replicate = replicate,
    group_fractions = group_fractions,
    public_summary = rbind(summary, response_summary)
  )
}

v45cv_expected_sample_anchors <- function() {
  data.frame(
    sample_id = c(
      "charls_primary_all_windows",
      "charls_w1_complete_three",
      "charls_w1_complete_three_no_trial_boundary",
      "charls_primary_adjacent_windows",
      "charls_w2_D2_supported",
      "charls_w2_landmark_R2",
      "charls_w1_w2_complete_three_R2"
    ),
    n = c(12555L, 12512L, 12235L, 12427L, 11869L, 8308L, 8245L),
    events_or_responses =
      c(1735L, 1722L, 1632L, 1539L, 8308L, 912L, 899L),
    period_rows =
      c(45503L, 45358L, 44456L, 44778L, NA, 23154L, 22984L),
    psu = c(433L, 433L, 432L, 432L, 420L, 420L, 420L),
    dfcom = c(432L, 432L, 431L, 431L, 419L, 419L, 419L),
    stringsAsFactors = FALSE
  )
}

v45cv_module_sample_ids <- function() {
  list(
    `anchor-point` = "charls_primary_all_windows",
    `trial-prefix` = "charls_w1_complete_three",
    `trial-full` = "charls_w1_complete_three",
    `inconsistency-prefix` = c(
      "charls_w1_complete_three",
      "charls_w1_complete_three_no_trial_boundary"
    ),
    `inconsistency-full` = c(
      "charls_w1_complete_three",
      "charls_w1_complete_three_no_trial_boundary"
    ),
    `adjacent-prefix` = c(
      "charls_primary_all_windows",
      "charls_primary_adjacent_windows"
    ),
    `adjacent-full` = c(
      "charls_primary_all_windows",
      "charls_primary_adjacent_windows"
    ),
    `timehet-prefix` = "charls_primary_all_windows",
    `timehet-full` = "charls_primary_all_windows",
    `W2-prefix` = c(
      "charls_w2_D2_supported", "charls_w2_landmark_R2",
      "charls_w1_w2_complete_three_R2"
    ),
    `W2-full` = c(
      "charls_w2_D2_supported", "charls_w2_landmark_R2",
      "charls_w1_w2_complete_three_R2"
    )
  )
}

v45cv_canonical_sample_table <- function(value) {
  required <- c(
    "sample_id", "imputation", "n", "events_or_responses",
    "period_rows", "psu", "dfcom"
  )
  if (!is.data.frame(value) ||
      !identical(names(value), required) ||
      anyNA(value[c(
        "sample_id", "imputation", "n",
        "events_or_responses", "psu", "dfcom"
      )])) {
    v45cv_stop("Sample-anchor table schema failed.")
  }
  out <- value[order(
    value$sample_id, value$imputation, method = "radix"
  ), , drop = FALSE]
  rownames(out) <- NULL
  out
}

v45cv_validate_recorded_sample_anchors <- function(restricted) {
  expected_values <- v45cv_expected_sample_anchors()
  module_samples <- v45cv_module_sample_ids()
  if (!identical(names(restricted), names(module_samples))) {
    v45cv_stop("Restricted module/sample-anchor order differs.")
  }
  recorded_all <- list()
  for (module in names(restricted)) {
    object <- restricted[[module]]
    recorded <- v45cv_canonical_sample_table(object$sample_anchors)
    nested <- if (module == "anchor-point") {
      object$sample_anchors
    } else {
      do.call(rbind, lapply(object$results, `[[`, "sample_anchors"))
    }
    nested <- v45cv_canonical_sample_table(nested)
    if (!identical(recorded, nested) ||
        !setequal(unique(recorded$sample_id),
                  module_samples[[module]]) ||
        any(table(recorded$sample_id) != 50L) ||
        any(!vapply(
          split(recorded$imputation, recorded$sample_id),
          identical, logical(1), y = seq_len(50L)
        ))) {
      v45cv_stop(module, " recorded sample anchors differ or are incomplete.")
    }
    for (sample_id in unique(recorded$sample_id)) {
      expected <- expected_values[
        expected_values$sample_id == sample_id, , drop = FALSE
      ]
      observed <- recorded[
        recorded$sample_id == sample_id, , drop = FALSE
      ]
      fields <- c(
        "n", "events_or_responses", "period_rows", "psu", "dfcom"
      )
      for (field in fields) {
        target <- expected[[field]][[1L]]
        if (is.na(target)) {
          if (!all(is.na(observed[[field]]))) {
            v45cv_stop(module, "/", sample_id, "/", field,
                       " should be NA.")
          }
        } else if (!all(as.numeric(observed[[field]]) == target)) {
          v45cv_stop(module, "/", sample_id, "/", field,
                     " differs from the frozen anchor.")
        }
      }
    }
    recorded_all[[module]] <- recorded
  }
  recorded_all
}

v45cv_sample_stats <- function(period, sample_id, imputation) {
  data.frame(
    sample_id = sample_id,
    imputation = as.integer(imputation),
    n = length(unique(as.character(period$participant_id))),
    events_or_responses =
      sum(as.integer(period$period_event) == 1L),
    period_rows = nrow(period),
    psu = length(unique(as.character(period$community_id))),
    dfcom =
      length(unique(as.character(period$community_id))) - 1L,
    stringsAsFactors = FALSE
  )
}

v45cv_parallel_map <- function(indices, function_value, label) {
  wrapper <- function(index) {
    tryCatch(
      list(ok = TRUE, value = function_value(index), error = ""),
      error = function(error) {
        list(
          ok = FALSE, value = NULL,
          error = paste(class(error), collapse = "|")
        )
      }
    )
  }
  result <- if (workers == 1L || .Platform$OS.type == "windows") {
    lapply(indices, wrapper)
  } else {
    parallel::mclapply(
      indices, wrapper, mc.cores = workers,
      mc.preschedule = FALSE, mc.set.seed = FALSE
    )
  }
  failed <- !vapply(result, `[[`, logical(1), "ok")
  if (any(failed)) {
    v45cv_stop(
      label, " failed for imputation(s): ",
      paste(indices[failed], collapse = ","),
      "; error classes: ",
      paste(unique(vapply(
        result[failed], `[[`, character(1), "error"
      )), collapse = "|")
    )
  }
  lapply(result, `[[`, "value")
}

v45cv_recompute_sample_anchors <- function(
    runner, mids_c0, mids_c2, context) {
  c0 <- v45cv_parallel_map(seq_len(50L), function(imputation) {
    completed <- mice::complete(mids_c0, action = imputation)
    person <- runner$v45c_prepare_person(
      completed, context$ledger, context$actual, context$v43, "MI-C0"
    )
    trial <- as.matrix(person[c(
      "pef_w1_trial1", "pef_w1_trial2", "pef_w1_trial3"
    )])
    storage.mode(trial) <- "double"
    complete_three <- apply(trial, 1L, function(value) {
      all(is.finite(value) & value >= 30 & value <= 890)
    })
    no_boundary <- complete_three &
      !apply(trial, 1L, function(value) {
        any(value == 30 | value == 890)
      })
    all_period <- runner$v45c_build_period(
      person, context$ledger, context$actual,
      rep(TRUE, nrow(person))
    )
    trial_period <- runner$v45c_build_period(
      person, context$ledger, context$actual, complete_three
    )
    boundary_period <- runner$v45c_build_period(
      person, context$ledger, context$actual, no_boundary
    )
    adjacent_period <- runner$v45c_build_period(
      person, context$ledger, context$actual,
      rep(TRUE, nrow(person)), adjacent = TRUE
    )
    out <- rbind(
      v45cv_sample_stats(
        all_period, "charls_primary_all_windows", imputation
      ),
      v45cv_sample_stats(
        trial_period, "charls_w1_complete_three", imputation
      ),
      v45cv_sample_stats(
        boundary_period,
        "charls_w1_complete_three_no_trial_boundary", imputation
      ),
      v45cv_sample_stats(
        adjacent_period,
        "charls_primary_adjacent_windows", imputation
      )
    )
    rm(
      completed, person, trial, all_period, trial_period,
      boundary_period, adjacent_period
    )
    out
  }, "MI-C0 structural anchor recomputation")

  c2 <- v45cv_parallel_map(seq_len(50L), function(imputation) {
    completed <- mice::complete(mids_c2, action = imputation)
    person <- runner$v45c_prepare_person(
      completed, context$ledger, context$actual, context$v43, "MI-C2"
    )
    respondent <- person$R_W2 == 1L
    complete_three <- respondent &
      person$pef_w1_valid_n == 3L &
      person$pef_w2_valid_n == 3L
    r2_period <- runner$v45c_build_period(
      person, context$ledger, context$actual, respondent,
      w2_landmark = TRUE
    )
    c3_period <- runner$v45c_build_period(
      person, context$ledger, context$actual, complete_three,
      w2_landmark = TRUE
    )
    out <- rbind(
      data.frame(
        sample_id = "charls_w2_D2_supported",
        imputation = as.integer(imputation),
        n = nrow(person),
        events_or_responses = sum(respondent),
        period_rows = NA_integer_,
        psu = length(unique(as.character(person$community_id))),
        dfcom =
          length(unique(as.character(person$community_id))) - 1L,
        stringsAsFactors = FALSE
      ),
      v45cv_sample_stats(
        r2_period, "charls_w2_landmark_R2", imputation
      ),
      v45cv_sample_stats(
        c3_period, "charls_w1_w2_complete_three_R2", imputation
      )
    )
    rm(completed, person, r2_period, c3_period)
    out
  }, "MI-C2 structural anchor recomputation")

  observed <- v45cv_canonical_sample_table(do.call(rbind, c(c0, c2)))
  expected <- v45cv_expected_sample_anchors()
  for (sample_id in expected$sample_id) {
    target <- expected[
      expected$sample_id == sample_id, , drop = FALSE
    ]
    value <- observed[
      observed$sample_id == sample_id, , drop = FALSE
    ]
    if (nrow(value) != 50L ||
        !identical(value$imputation, seq_len(50L))) {
      v45cv_stop(sample_id,
                 " independent sample anchor lacks exact m=50.")
    }
    for (field in c(
      "n", "events_or_responses", "period_rows", "psu", "dfcom"
    )) {
      expected_value <- target[[field]][[1L]]
      if (is.na(expected_value)) {
        if (!all(is.na(value[[field]]))) {
          v45cv_stop(sample_id, "/", field,
                     " independent anchor should be NA.")
        }
      } else if (!all(as.numeric(value[[field]]) == expected_value)) {
        v45cv_stop(sample_id, "/", field,
                   " independent anchor differs.")
      }
    }
  }
  observed
}

v45cv_recompute_anchor <- function(
    runner, mids_c0, context, recorded_anchor) {
  results <- v45cv_parallel_map(seq_len(50L), function(imputation) {
    # Deliberately assemble both implementations here rather than invoking
    # the runner's anchor wrapper.  This makes the validator sensitive to an
    # error in the wrapper's data/formula/fit composition.
    completed <- mice::complete(mids_c0, action = imputation)

    v44_person <- context$v43$attach_passive_variables(
      completed, context$ledger$spline_knots
    )
    v44_formula <- context$v43$model_formulas("E0", FALSE)$A1
    v44_fit <- context$v43$fit_one_survey_model(
      v44_person, context$ledger$person_period_skeleton,
      v44_formula, paste0("v44_validator_anchor_imp", imputation)
    )
    v44_beta <- unname(v44_fit$coefficients[["E0"]])

    v45_person <- runner$v45c_prepare_person(
      completed, context$ledger, context$actual,
      context$v43, "MI-C0"
    )
    v45_period <- runner$v45c_build_period(
      v45_person, context$ledger, context$actual,
      rep(TRUE, nrow(v45_person))
    )
    observed_anchor <- c(
      n = length(unique(as.character(v45_period$participant_id))),
      events = sum(as.integer(v45_period$period_event) == 1L),
      rows = nrow(v45_period),
      psu = length(unique(as.character(v45_period$community_id)))
    )
    if (!identical(
          as.integer(observed_anchor),
          c(12555L, 1735L, 45503L, 433L)
        )) {
      v45cv_stop(
        "Independent v45 legacy anchor sample failed in imputation ",
        imputation, "."
      )
    }
    v45_formula <- runner$v45c_formula("F_ADJACENT_E0_A1")
    v45_fit <- runner$v45c_fit_cloglog(
      v45_period, v45_period$weight_biomarker_w1,
      v45_formula, "E0",
      paste0("v45_validator_anchor_imp", imputation),
      point_survey = TRUE
    )
    v45_beta <- unname(v45_fit$coefficients[["E0"]])
    rm(
      completed, v44_person, v44_fit, v45_person, v45_period,
      v45_fit
    )
    list(
      imputation = as.integer(imputation),
      v44_beta = v44_beta,
      v45_beta = v45_beta
    )
  }, "independent v44/v45 dual-implementation anchor")
  v44 <- vapply(results, `[[`, numeric(1), "v44_beta")
  v45 <- vapply(results, `[[`, numeric(1), "v45_beta")
  tolerance <- 1e-8
  public_qbar <- 0.354509670529553
  if (any(abs(v44 - v45) > tolerance) ||
      abs(mean(v44) - mean(v45)) > tolerance ||
      abs(mean(v44) - public_qbar) > tolerance ||
      abs(mean(v45) - public_qbar) > tolerance) {
    v45cv_stop("Independent v44/v45 point anchor failed.")
  }
  recorded <- recorded_anchor$anchor$per_imputation
  if (!is.data.frame(recorded) || nrow(recorded) != 50L ||
      !identical(recorded$imputation, seq_len(50L)) ||
      !v45cv_num_equal(recorded$v44_beta, v44, tolerance = 1e-12) ||
      !v45cv_num_equal(recorded$v45_beta, v45, tolerance = 1e-12)) {
    v45cv_stop("Recorded and independently repeated anchor vectors differ.")
  }
  list(
    maximum_absolute_beta_difference = max(abs(v44 - v45)),
    absolute_v44_v45_Qbar_difference = abs(mean(v44) - mean(v45)),
    absolute_v44_public_Qbar_difference =
      abs(mean(v44) - public_qbar),
    absolute_v45_public_Qbar_difference =
      abs(mean(v45) - public_qbar),
    tolerance = tolerance,
    status = "PASS"
  )
}

v45cv_synthetic_group <- function(
    point, replicates, failure_class, dfcom,
    compute_covariance = TRUE) {
  valid <- apply(replicates, 1L, function(value) all(is.finite(value)))
  names(valid) <- rownames(replicates)
  retained <- replicates[valid, , drop = FALSE]
  centered <- sweep(retained, 2L, point, FUN = "-")
  covariance <- crossprod(centered) / (sum(valid) - 1L)
  dimnames(covariance) <- list(names(point), names(point))
  dfcom_by_column <- setNames(
    rep(as.numeric(dfcom), length(point)), names(point)
  )
  list(
    group_id = "SYNTHETIC",
    point = point,
    replicates = replicates,
    common_valid_mask = valid,
    within_covariance = if (isTRUE(compute_covariance)) {
      covariance
    } else {
      matrix(
        NA_real_, nrow(covariance), ncol(covariance),
        dimnames = dimnames(covariance)
      )
    },
    valid_replicate_n = sum(valid),
    valid_replicate_fraction = mean(valid),
    valid_fraction_gate =
      v45cv_metric_gate("valid_replicate_fraction", mean(valid)),
    variance_denominator = if (isTRUE(compute_covariance)) {
      sum(valid) - 1L
    } else NA_integer_,
    nominal_replicates = nrow(replicates),
    dfcom = min(dfcom_by_column),
    dfcom_by_column = dfcom_by_column,
    failure_class_by_replicate = failure_class,
    failure_summary = data.frame(),
    scale_rule = "1/(B_valid-1)",
    common_failure_mask = TRUE,
    covariance_computed = isTRUE(compute_covariance),
    coefficient_blind_prefix_eligible =
      !isTRUE(compute_covariance)
  )
}

v45cv_synthetic_transaction_test <- function(test_mode) {
  test_mode <- match.arg(
    test_mode, c("promotion_fault", "verify_failure", "success")
  )
  base <- tempfile(paste0("v45cv_transaction_", test_mode, "_"))
  dir.create(base, recursive = TRUE, showWarnings = FALSE)
  on.exit(
    if (dir.exists(base)) unlink(base, recursive = TRUE, force = TRUE),
    add = TRUE
  )
  synthetic_public <- file.path(base, "results")
  synthetic_qa <- file.path(base, "qa")
  synthetic_work <- file.path(base, "work")
  synthetic_state_dir <- file.path(synthetic_public, "synthetic_run")
  for (path in c(
    synthetic_public, synthetic_qa, synthetic_work,
    synthetic_state_dir
  )) {
    dir.create(path, recursive = TRUE, showWarnings = FALSE)
  }
  synthetic_state_path <- file.path(
    synthetic_state_dir, "module_state.tsv"
  )
  synthetic_current_path <- file.path(
    synthetic_public, "current.tsv"
  )
  synthetic_gate_path <- file.path(synthetic_work, "gate.yml")
  synthetic_manifest_path <- file.path(
    synthetic_public, "manifest.tsv"
  )
  synthetic_asset_path <- file.path(
    synthetic_public, "validation.tsv"
  )
  initial_state <- data.frame(
    record = "ORIGINAL_STATE", stringsAsFactors = FALSE
  )
  initial_current <- data.frame(
    record = "ORIGINAL_CURRENT",
    state_sha256 = "ORIGINAL_PLACEHOLDER",
    stringsAsFactors = FALSE
  )
  initial_gate <- list(
    status = "ORIGINAL_GATE",
    independent_validation = list()
  )
  v45_charls_outcome_atomic_write_tsv(
    initial_state, synthetic_state_path
  )
  v45_charls_outcome_atomic_write_tsv(
    initial_current, synthetic_current_path
  )
  v45cv_atomic_write_yaml(initial_gate, synthetic_gate_path)
  original_hashes <- c(
    state = v45cv_sha256_file(synthetic_state_path),
    current = v45cv_sha256_file(synthetic_current_path),
    gate = v45cv_sha256_file(synthetic_gate_path)
  )
  transaction_context <- list(
    public_root = synthetic_public,
    qa_root = synthetic_qa,
    work_root = synthetic_work,
    current_path = synthetic_current_path,
    gate_path = synthetic_gate_path,
    lock_path = file.path(
      synthetic_public, ".validation.lock"
    ),
    journal_path = file.path(
      synthetic_public, ".validation_transaction.tsv"
    )
  )
  assets <- list(
    validation = list(
      path = synthetic_asset_path,
      value = data.frame(
        check = "synthetic", status = "PASS",
        stringsAsFactors = FALSE
      ),
      type = "tsv"
    )
  )
  new_state <- data.frame(
    record = "NEW_STATE", stringsAsFactors = FALSE
  )
  new_current <- data.frame(
    record = "NEW_CURRENT", state_sha256 = "",
    stringsAsFactors = FALSE
  )
  new_gate <- list(
    status = "NEW_GATE",
    independent_validation = list()
  )
  callback_saw_gate_last <- FALSE
  verify_callback <- function() {
    gate <- v45cv_read_yaml(synthetic_gate_path)
    callback_saw_gate_last <<- isTRUE(
      identical(as.character(gate$status), "NEW_GATE") &&
        v45cv_regular_file(synthetic_asset_path) &&
        v45cv_regular_file(synthetic_manifest_path)
    )
    if (identical(test_mode, "verify_failure")) {
      v45cv_stop("synthetic terminal verification failure")
    }
    callback_saw_gate_last
  }
  fault_injector <- if (identical(
    test_mode, "promotion_fault"
  )) {
    function(phase) {
      if (identical(phase, "CURRENT_PROMOTED")) {
        v45cv_stop("synthetic current-promotion fault")
      }
      invisible(TRUE)
    }
  } else NULL
  outcome <- tryCatch({
    v45cv_commit_transaction(
      "synthetic_run", assets, new_state, synthetic_state_path,
      new_current, new_gate, include_manifest = TRUE,
      manifest_path = synthetic_manifest_path,
      verify_callback = verify_callback,
      transaction_context = transaction_context,
      fault_injector = fault_injector
    )
    TRUE
  }, error = function(error) FALSE)
  residue <- list.files(
    base, recursive = TRUE, all.files = TRUE,
    full.names = TRUE, include.dirs = TRUE
  )
  hidden_transaction_residue <- any(grepl(
    "\\.(staging|backup)$|validation_transaction\\.tsv$|validation\\.lock$",
    residue
  ))
  if (identical(test_mode, "success")) {
    return(
      isTRUE(outcome) &&
        callback_saw_gate_last &&
        v45cv_regular_file(synthetic_asset_path) &&
        v45cv_regular_file(synthetic_manifest_path) &&
        v45cv_read_tsv(synthetic_state_path)$record[[1L]] ==
          "NEW_STATE" &&
        v45cv_read_tsv(synthetic_current_path)$record[[1L]] ==
          "NEW_CURRENT" &&
        as.character(
          v45cv_read_yaml(synthetic_gate_path)$status
        ) == "NEW_GATE" &&
        !file.exists(transaction_context$journal_path) &&
        !dir.exists(transaction_context$lock_path) &&
        !hidden_transaction_residue
    )
  }
  identical(outcome, FALSE) &&
    (if (identical(test_mode, "verify_failure")) {
      callback_saw_gate_last
    } else {
      !callback_saw_gate_last
    }) &&
    identical(
      v45cv_sha256_file(synthetic_state_path),
      original_hashes[["state"]]
    ) &&
    identical(
      v45cv_sha256_file(synthetic_current_path),
      original_hashes[["current"]]
    ) &&
    identical(
      v45cv_sha256_file(synthetic_gate_path),
      original_hashes[["gate"]]
    ) &&
    !file.exists(synthetic_asset_path) &&
    !file.exists(synthetic_manifest_path) &&
    !file.exists(transaction_context$journal_path) &&
    !dir.exists(transaction_context$lock_path) &&
    !hidden_transaction_residue
}

v45cv_synthetic_stale_transaction_test <- function(test_mode) {
  test_mode <- match.arg(
    test_mode,
    c(
      "verifying_rollback", "verified_finalize",
      "owner_tamper", "orphan_journal"
    )
  )
  base <- tempfile(paste0("v45cv_stale_", test_mode, "_"))
  dir.create(base, recursive = TRUE, showWarnings = FALSE)
  on.exit(
    if (dir.exists(base)) unlink(base, recursive = TRUE, force = TRUE),
    add = TRUE
  )
  synthetic_public <- file.path(base, "results")
  synthetic_qa <- file.path(base, "qa")
  synthetic_work <- file.path(base, "work")
  synthetic_state_dir <- file.path(
    synthetic_public, "synthetic_stale_run"
  )
  for (path in c(
    synthetic_public, synthetic_qa, synthetic_work,
    synthetic_state_dir
  )) {
    dir.create(path, recursive = TRUE, showWarnings = FALSE)
  }
  context <- v45cv_validate_transaction_context(list(
    public_root = synthetic_public,
    qa_root = synthetic_qa,
    work_root = synthetic_work,
    current_path = file.path(synthetic_public, "current.tsv"),
    gate_path = file.path(synthetic_work, "gate.yml"),
    lock_path = file.path(synthetic_public, ".validation.lock"),
    journal_path = file.path(
      synthetic_public, ".validation_transaction.tsv"
    )
  ))
  state_path <- v45cv_transaction_path(file.path(
    synthetic_state_dir, "module_state.tsv"
  ))
  asset_path <- v45cv_transaction_path(file.path(
    synthetic_public, "validation.tsv"
  ))
  manifest_path <- v45cv_transaction_path(file.path(
    synthetic_public, "manifest.tsv"
  ))
  original_state <- data.frame(
    record = "ORIGINAL_STATE", stringsAsFactors = FALSE
  )
  original_current <- data.frame(
    record = "ORIGINAL_CURRENT", stringsAsFactors = FALSE
  )
  original_gate <- list(status = "ORIGINAL_GATE")
  new_state <- data.frame(
    record = "NEW_STATE", stringsAsFactors = FALSE
  )
  new_current <- data.frame(
    record = "NEW_CURRENT", stringsAsFactors = FALSE
  )
  new_gate <- list(status = "NEW_GATE")
  new_asset <- data.frame(
    record = "NEW_ASSET", stringsAsFactors = FALSE
  )
  new_manifest <- data.frame(
    record = "NEW_MANIFEST", stringsAsFactors = FALSE
  )
  v45_charls_outcome_atomic_write_tsv(original_state, state_path)
  v45_charls_outcome_atomic_write_tsv(
    original_current, context$current_path
  )
  v45cv_atomic_write_yaml(original_gate, context$gate_path)
  original_hashes <- c(
    state = v45cv_sha256_file(state_path),
    current = v45cv_sha256_file(context$current_path),
    gate = v45cv_sha256_file(context$gate_path)
  )
  transaction_id <- paste0(
    "synthetic_stale_", test_mode, "_pid2147483647"
  )
  dir.create(context$lock_path, showWarnings = FALSE)
  owner_path <- file.path(context$lock_path, "owner.tsv")
  owner <- data.frame(
    transaction_id = transaction_id,
    run_id = "synthetic_stale_run",
    pid = 2147483647L,
    host = v45cv_transaction_host(),
    acquired_at_utc = "2026-07-26T00:00:00Z",
    journal_path = context$journal_path,
    stringsAsFactors = FALSE
  )
  v45_charls_outcome_atomic_write_tsv(owner, owner_path)
  owner <- v45cv_validate_transaction_owner(
    v45cv_read_tsv(owner_path), context, transaction_id
  )
  owner_sha <- v45cv_sha256_file(owner_path)
  target_ids <- c(
    "validation", "manifest", "module_state",
    "current_pointer", "gate"
  )
  target_kind <- c(
    "ASSET", "MANIFEST", "MODULE_STATE",
    "CURRENT_POINTER", "GATE"
  )
  destination <- c(
    asset_path, manifest_path, state_path,
    context$current_path, context$gate_path
  )
  stage_path <- vapply(destination, function(path) {
    file.path(
      dirname(path),
      paste0(
        ".", basename(path), ".", transaction_id, ".staging"
      )
    )
  }, character(1))
  had_existing <- c("no", "no", "yes", "yes", "yes")
  original_sha <- c(
    "NONE", "NONE", unname(original_hashes)
  )
  backup_path <- vapply(seq_along(destination), function(index) {
    if (had_existing[[index]] == "no") {
      "NONE"
    } else {
      file.path(
        dirname(destination[[index]]),
        paste0(
          ".", basename(destination[[index]]), ".",
          transaction_id, ".backup"
        )
      )
    }
  }, character(1))
  for (index in which(had_existing == "yes")) {
    if (!file.copy(
          destination[[index]], backup_path[[index]],
          overwrite = FALSE
        )) {
      v45cv_stop("Synthetic stale backup construction failed.")
    }
  }
  v45_charls_outcome_atomic_write_tsv(new_asset, asset_path)
  v45_charls_outcome_atomic_write_tsv(
    new_manifest, manifest_path
  )
  v45_charls_outcome_atomic_write_tsv(new_state, state_path)
  v45_charls_outcome_atomic_write_tsv(
    new_current, context$current_path
  )
  v45cv_atomic_write_yaml(new_gate, context$gate_path)
  expected_sha <- vapply(
    destination, v45cv_sha256_file, character(1)
  )
  terminal_verified <- identical(test_mode, "verified_finalize")
  journal <- data.frame(
    journal_version = rep("v45cv_tx_v1", length(target_ids)),
    transaction_id = rep(transaction_id, length(target_ids)),
    run_id = rep("synthetic_stale_run", length(target_ids)),
    owner_pid = rep(2147483647L, length(target_ids)),
    owner_host = rep(
      v45cv_transaction_host(), length(target_ids)
    ),
    owner_sha256 = rep(owner_sha, length(target_ids)),
    phase = rep(
      if (terminal_verified) "VERIFIED" else "VERIFYING",
      length(target_ids)
    ),
    updated_at_utc = rep(
      "2026-07-26T00:00:00Z", length(target_ids)
    ),
    sequence = seq_along(target_ids),
    target_id = target_ids,
    target_kind = target_kind,
    destination_path = destination,
    stage_path = stage_path,
    expected_sha256 = expected_sha,
    had_existing = had_existing,
    original_sha256 = original_sha,
    backup_path = backup_path,
    backup_sha256 = ifelse(
      had_existing == "yes", original_sha, "NONE"
    ),
    stage_ready = rep("no", length(target_ids)),
    backup_ready = ifelse(
      had_existing == "yes", "yes", "no"
    ),
    promoted = rep("yes", length(target_ids)),
    gate_last = ifelse(target_ids == "gate", "yes", "no"),
    verified = rep(
      if (terminal_verified) "yes" else "no",
      length(target_ids)
    ),
    stringsAsFactors = FALSE
  )
  journal <- v45cv_write_transaction_journal(
    journal, context,
    if (terminal_verified) "VERIFIED" else "VERIFYING",
    owner
  )
  if (identical(test_mode, "owner_tamper")) {
    tampered_owner <- owner
    tampered_owner$run_id <- "tampered_synthetic_run"
    v45_charls_outcome_atomic_write_tsv(
      tampered_owner, owner_path
    )
    blocked <- inherits(try(
      v45cv_recover_stale_transaction(context),
      silent = TRUE
    ), "try-error")
    return(
      blocked &&
        v45cv_regular_file(context$journal_path) &&
        dir.exists(context$lock_path)
    )
  }
  if (identical(test_mode, "orphan_journal")) {
    unlink(context$lock_path, recursive = TRUE, force = TRUE)
    blocked <- inherits(try(
      v45cv_recover_stale_transaction(context),
      silent = TRUE
    ), "try-error")
    return(
      blocked &&
        v45cv_regular_file(context$journal_path) &&
        !dir.exists(context$lock_path)
    )
  }
  recovered <- !inherits(try(
    v45cv_recover_stale_transaction(context),
    silent = TRUE
  ), "try-error")
  transaction_residue <- any(file.exists(c(
    context$journal_path, context$lock_path,
    stage_path, backup_path[backup_path != "NONE"]
  )))
  if (identical(test_mode, "verifying_rollback")) {
    return(
      recovered &&
        identical(v45cv_sha256_file(state_path),
                  original_hashes[["state"]]) &&
        identical(v45cv_sha256_file(context$current_path),
                  original_hashes[["current"]]) &&
        identical(v45cv_sha256_file(context$gate_path),
                  original_hashes[["gate"]]) &&
        !file.exists(asset_path) &&
        !file.exists(manifest_path) &&
        !transaction_residue
    )
  }
  recovered &&
    identical(v45cv_sha256_file(state_path),
              expected_sha[[3L]]) &&
    identical(v45cv_sha256_file(context$current_path),
              expected_sha[[4L]]) &&
    identical(v45cv_sha256_file(context$gate_path),
              expected_sha[[5L]]) &&
    identical(v45cv_sha256_file(asset_path),
              expected_sha[[1L]]) &&
    identical(v45cv_sha256_file(manifest_path),
              expected_sha[[2L]]) &&
    !transaction_residue
}

v45cv_self_test <- function() {
  checks <- c()
  record <- function(name, value) {
    checks[[name]] <<- isTRUE(value)
  }
  utility <- v45_charls_outcome_synthetic_self_test()
  record("outcome_utility_self_test", all(utility$status == "PASS"))
  record(
    "frozen_runtime_and_worker_bound",
    identical(as.character(getRversion()), "4.5.1") &&
      workers >= 1L && workers <= 8L
  )

  point <- c(a = 0.1, b = -0.2)
  replicate <- cbind(
    a = point[["a"]] + sin(seq_len(250L)) / 100,
    b = point[["b"]] + cos(seq_len(250L)) / 100
  )
  rownames(replicate) <- v45cv_replicate_names(250L)
  failure <- rep("", 250L)
  group <- v45cv_synthetic_group(
    point, replicate, failure, 432,
    compute_covariance = FALSE
  )
  validated <- v45cv_validate_group(
    group, 250L, "SYNTHETIC", 1L,
    recorded_covariance_required = FALSE
  )
  record(
    "common_mask_covariance_Bvalid_minus_1",
    validated$valid_n == 250L &&
      validated$dfcom_by_column[["a"]] == 432
  )

  suffix <- cbind(
    a = point[["a"]] + sin(251:500) / 100,
    b = point[["b"]] + cos(251:500) / 100
  )
  rownames(suffix) <- sprintf("R%03d", 251:500)
  full_replicate <- rbind(replicate, suffix)
  full_group <- v45cv_synthetic_group(
    point, full_replicate, rep("", 500L), 432
  )
  prefix_object <- list(
    replicate_indices = 1:250,
    prefix_gate = "GO",
    results = lapply(seq_len(50L), function(index) {
      list(imputation = index, groups = list(SYNTHETIC = group))
    })
  )
  full_object <- list(
    replicate_indices = 1:500,
    results = lapply(seq_len(50L), function(index) {
      list(imputation = index, groups = list(SYNTHETIC = full_group))
    })
  )
  prefix_pass <- !inherits(try(
    v45cv_validate_prefix_full(
      prefix_object, full_object, "SYNTHETIC"
    ),
    silent = TRUE
  ), "try-error")
  full_object$results[[1L]]$groups$SYNTHETIC$replicates[1L, 1L] <-
    full_object$results[[1L]]$groups$SYNTHETIC$replicates[1L, 1L] +
    1e-6
  prefix_tamper_caught <- inherits(try(
    v45cv_validate_prefix_full(
      prefix_object, full_object, "SYNTHETIC"
    ),
    silent = TRUE
  ), "try-error")
  record(
    "literal_prefix_identity_and_tamper",
    prefix_pass && prefix_tamper_caught
  )

  Q <- seq(-0.1, 0.1, length.out = 50L)
  scalar <- v45cv_pool_scalar(
    Q, rep(0.04, 50L), 432, "SYNTHETIC_SCALAR"
  )
  Q_matrix <- cbind(a = Q, b = rev(Q) + 0.05)
  U <- replicate(
    50L,
    matrix(
      c(0.04, 0.002, 0.002, 0.03), 2L,
      dimnames = list(c("a", "b"), c("a", "b"))
    ),
    simplify = FALSE
  )
  joint <- v45cv_pool_multivariate(
    Q_matrix, U, "SYNTHETIC_JOINT"
  )
  record(
    "independent_scalar_and_multivariate_Rubin",
    scalar$m == 50L && is.finite(scalar$MCE_fraction) &&
      joint$test$df == 2L && is.finite(joint$test$statistic)
  )

  payload_caught <- inherits(try(
    v45cv_forbidden_payload_audit(
      list(probability = c(0.2, 0.8)), "SYNTHETIC"
    ),
    silent = TRUE
  ), "try-error")
  record("forbidden_probability_payload", payload_caught)
  record(
    "frozen_gate_boundaries",
    v45cv_metric_gate("response_probability_p01", 0.01) == "STOP" &&
      v45cv_metric_gate("response_probability_p01", 0.05) == "GO" &&
      v45cv_metric_gate("availability_factor_p99", 20) ==
        "CAUTION" &&
      v45cv_metric_gate("ESS_ratio", 0.30) == "CAUTION" &&
      v45cv_metric_gate("maximum_absolute_SMD", 0.20) ==
        "CAUTION" &&
      v45cv_metric_gate("valid_replicate_fraction", 0.90) ==
        "CAUTION"
  )
  structural_log <- data.frame(
    structurally_constant_balance_columns = c(1L, NA_integer_),
    structurally_constant_balance_column_names = c(
      "constant_column", NA_character_
    ),
    stringsAsFactors = FALSE
  )
  structural_log_pass <- !inherits(try(
    v45cv_validate_structurally_constant_balance_log(
      structural_log, c(TRUE, FALSE), "SYNTHETIC_W2"
    ),
    silent = TRUE
  ), "try-error")
  structural_log$
    structurally_constant_balance_columns[[1L]] <- 2L
  structural_log_tamper_caught <- inherits(try(
    v45cv_validate_structurally_constant_balance_log(
      structural_log, c(TRUE, FALSE), "SYNTHETIC_W2"
    ),
    silent = TRUE
  ), "try-error")
  record(
    "W2_structural_constant_log_and_tamper",
    structural_log_pass && structural_log_tamper_caught
  )
  record(
    "object_wide_m100_boundary",
    any(c(0.099999, 0.10) >= 0.10) &&
      !any(c(0.01, 0.099999) >= 0.10)
  )
  prefix_pooling_ok <- tryCatch({
    v45cv_validate_recorded_pooling_status(
      "trial-prefix",
      list(
        pooling_status = "NOT_APPLICABLE_PREFIX",
        pooling_failure_class = "",
        pooling_failure_reason = ""
      )
    )
    TRUE
  }, error = function(error) FALSE)
  full_nonestimable_blocked <- inherits(try(
    v45cv_validate_recorded_pooling_status(
      "trial-full",
      list(
        pooling_status = "NOT_ESTIMABLE_WITH_REASON",
        pooling_failure_class = "POOL_SCALAR_NOT_ESTIMABLE",
        pooling_failure_reason = "synthetic numerical failure"
      )
    ),
    silent = TRUE
  ), "try-error")
  record(
    "recorded_pooling_status_release_boundary",
    prefix_pooling_ok && full_nonestimable_blocked
  )
  point_failure_message <- tryCatch({
    v45cv_validate_recorded_pooling_status(
      "trial-prefix",
      list(
        module = "trial-prefix",
        mi_object = "MI-C0", requested_m = 50L,
        replicate_indices = seq_len(250L),
        requested_replicate_indices = seq_len(250L),
        executed_in_this_transaction = integer(),
        prefix_sha256 = NA_character_,
        literal_prefix_identity = NA,
        results = list(), sample_anchors = data.frame(),
        minimum_valid_replicate_fraction = NA_real_,
        prefix_gate = "STOP", full_gate = NA_character_,
        coefficient_blind_prefix_gate = TRUE,
        prefix_pooling_or_release_performed = FALSE,
        no_replacement_replicates = TRUE,
        variance_rule = "1/(B_valid-1)",
        common_failure_masks_preserved = TRUE,
        pooling_status = "POINT_NOT_ESTIMABLE_WITH_REASON",
        point_failure_class = "SYNTHETIC_POINT_FAILURE",
        point_failure_reason = "synthetic registered failure",
        point_failure_summary = data.frame(
          failure_class = "SYNTHETIC_POINT_FAILURE",
          affected_imputations = "2|5",
          affected_imputation_count = 2L,
          stringsAsFactors = FALSE
        ),
        valid_fraction_assessed = FALSE,
        partial_imputation_results_retained = FALSE,
        coefficient_or_direction_in_failure_record = FALSE,
        schema_version =
          "v45_1_charls_trial_prefix_restricted",
        run_id = "synthetic_run",
        created_at_utc = "2026-07-26T00:00:00Z",
        freeze_contract_sha256 = paste(rep("a", 64L), collapse = ""),
        coefficient_visibility = "RESTRICTED",
        completed_dataset_saved = FALSE,
        model_object_saved = FALSE,
        row_level_data_saved = FALSE,
        individual_probability_or_weight_saved = FALSE,
        independent_validation_status = "NOT_RUN"
      )
    )
    ""
  }, error = conditionMessage)
  record(
    "registered_point_failure_schema_then_release_block",
    grepl(
      "valid restricted point-failure record",
      point_failure_message, fixed = TRUE
    )
  )
  anchor_per <- data.frame(
    imputation = seq_len(50L),
    v44_beta = seq(0.30, 0.40, length.out = 50L),
    v45_beta = seq(0.30, 0.40, length.out = 50L) + 1e-4,
    stringsAsFactors = FALSE
  )
  anchor_per$absolute_difference <-
    abs(anchor_per$v44_beta - anchor_per$v45_beta)
  anchor_failure_message <- tryCatch({
    v45cv_validate_recorded_pooling_status(
      "anchor-point",
      list(anchor = list(
        gate = "FAIL", tolerance = 1e-8,
        public_v44_Qbar = 0.354509670529553,
        failure_class = "ANCHOR_IDENTITY_MISMATCH",
        failure_reason = "synthetic identity mismatch",
        failure_summary = data.frame(
          failure_class = character(),
          affected_imputations = character(),
          affected_imputation_count = integer(),
          stringsAsFactors = FALSE
        ),
        per_imputation = anchor_per,
        computed_v44_Qbar = mean(anchor_per$v44_beta),
        computed_v45_Qbar = mean(anchor_per$v45_beta),
        maximum_absolute_difference =
          max(anchor_per$absolute_difference),
        comparison_role = "point_estimate_only_sidecar_gate",
        Rao_Wu_SE_identity_required = FALSE,
        partial_imputation_results_retained = FALSE,
        coefficient_or_direction_in_failure_record = TRUE
      ))
    )
    ""
  }, error = conditionMessage)
  record(
    "anchor_fail_schema_then_release_block",
    grepl(
      "valid restricted FAIL record",
      anchor_failure_message, fixed = TRUE
    )
  )
  anchor_pass_per <- data.frame(
    imputation = seq_len(50L),
    v44_beta = rep(0.354509670529553, 50L),
    v45_beta = rep(0.354509670529553, 50L),
    absolute_difference = rep(0, 50L),
    stringsAsFactors = FALSE
  )
  anchor_pass_ok <- tryCatch({
    v45cv_validate_recorded_pooling_status(
      "anchor-point",
      list(anchor = list(
        gate = "PASS", tolerance = 1e-8,
        public_v44_Qbar = 0.354509670529553,
        failure_class = "", failure_reason = "",
        failure_summary = data.frame(
          failure_class = character(),
          affected_imputations = character(),
          affected_imputation_count = integer(),
          stringsAsFactors = FALSE
        ),
        per_imputation = anchor_pass_per,
        computed_v44_Qbar = 0.354509670529553,
        computed_v45_Qbar = 0.354509670529553,
        maximum_absolute_difference = 0,
        comparison_role = "point_estimate_only_sidecar_gate",
        Rao_Wu_SE_identity_required = FALSE,
        partial_imputation_results_retained = FALSE,
        coefficient_or_direction_in_failure_record = FALSE
      ))
    )
    TRUE
  }, error = function(error) FALSE)
  anchor_registered_failure_message <- tryCatch({
    v45cv_validate_recorded_pooling_status(
      "anchor-point",
      list(anchor = list(
        gate = "FAIL", tolerance = 1e-8,
        failure_class = "SYNTHETIC_POINT_SUPPORT",
        failure_reason = "synthetic registered anchor failure",
        failure_summary = data.frame(
          failure_class = "SYNTHETIC_POINT_SUPPORT",
          affected_imputations = "4",
          affected_imputation_count = 1L,
          stringsAsFactors = FALSE
        ),
        per_imputation = data.frame(),
        computed_v44_Qbar = NA_real_,
        computed_v45_Qbar = NA_real_,
        maximum_absolute_difference = NA_real_,
        comparison_role = "point_estimate_only_sidecar_gate",
        Rao_Wu_SE_identity_required = FALSE,
        partial_imputation_results_retained = FALSE,
        coefficient_or_direction_in_failure_record = FALSE
      ))
    )
    ""
  }, error = conditionMessage)
  record(
    "anchor_PASS_and_registered_FAIL_contracts",
    anchor_pass_ok &&
      grepl(
        "valid restricted FAIL record",
        anchor_registered_failure_message, fixed = TRUE
      )
  )
  record(
    "transaction_promotion_fault_full_rollback",
    v45cv_synthetic_transaction_test("promotion_fault")
  )
  record(
    "transaction_verify_failure_full_rollback",
    v45cv_synthetic_transaction_test("verify_failure")
  )
  record(
    "transaction_verified_commit_cleanup",
    v45cv_synthetic_transaction_test("success")
  )
  record(
    "dead_owner_VERIFYING_stale_rollback",
    v45cv_synthetic_stale_transaction_test(
      "verifying_rollback"
    )
  )
  record(
    "dead_owner_VERIFIED_stale_finalize",
    v45cv_synthetic_stale_transaction_test(
      "verified_finalize"
    )
  )
  record(
    "transaction_owner_tamper_fail_closed",
    v45cv_synthetic_stale_transaction_test("owner_tamper")
  )
  record(
    "orphan_journal_fail_closed",
    v45cv_synthetic_stale_transaction_test("orphan_journal")
  )
  report <- data.frame(
    check = names(checks),
    status = ifelse(unlist(checks), "PASS", "FAIL"),
    stringsAsFactors = FALSE
  )
  if (any(report$status != "PASS")) {
    v45cv_stop(
      "CHARLS outcome validator self-test failed: ",
      paste(report$check[report$status != "PASS"], collapse = "|")
    )
  }
  report
}

work_root <- file.path(root, "work_v45/charls_addendum_v45_1")
public_root <- file.path(
  root, "results/v45/charls_addendum_v45_1/outcome_execution"
)
qa_root <- file.path(root, "output/qa/v45/charls_addendum_v45_1")
contract_path <- file.path(
  root,
  paste0(
    "derived_sensitive/v45/charls_addendum_v45_1/",
    "charls_outcome_execution_contract_v45_1.rds"
  )
)
gate_path <- file.path(
  work_root, "charls_outcome_execution_gate_state_v45_1.yml"
)
current_path <- file.path(
  public_root, "charls_outcome_restricted_current.tsv"
)
release_paths <- list(
  validation = file.path(
    public_root, "charls_outcome_independent_validation_v45_1.tsv"
  ),
  object_gates = file.path(
    public_root, "charls_outcome_object_gate_summary_v45_1.tsv"
  ),
  results = file.path(
    public_root, "charls_outcome_released_results_v45_1.tsv"
  ),
  joints = file.path(
    public_root, "charls_outcome_released_joint_tests_v45_1.tsv"
  ),
  model_diagnostics = file.path(
    public_root, "charls_outcome_model_diagnostics_v45_1.tsv"
  ),
  w2_diagnostics = file.path(
    public_root, "charls_outcome_w2_diagnostics_v45_1.tsv"
  ),
  manifest = file.path(
    public_root, "charls_outcome_release_output_manifest_v45_1.tsv"
  ),
  m100 = file.path(
    public_root, "charls_outcome_m100_requirement_v45_1.tsv"
  ),
  m100_validation = file.path(
    public_root,
    "charls_outcome_m50_validation_m100_required_v45_1.tsv"
  ),
  m100_object_gates = file.path(
    public_root,
    "charls_outcome_m50_object_gate_summary_v45_1.tsv"
  ),
  m100_manifest = file.path(
    public_root,
    "charls_outcome_m100_checkpoint_manifest_v45_1.tsv"
  ),
  m100_qa = file.path(
    qa_root, "CHARLS_OUTCOME_M100_REQUIRED_QA_v45_1.md"
  ),
  qa = file.path(
    qa_root, "CHARLS_OUTCOME_INDEPENDENT_VALIDATION_QA_v45_1.md"
  )
)

v45cv_validation_check_ids <- function() {
  c(
    "freeze_contract_and_bound_inputs_rehashed",
    "restricted_current_state_and_11_module_hashes",
    "forbidden_row_fit_probability_weight_payload_absent",
    "exact_28_model_12_threshold_75_anchor_18_crosswalk",
    "recorded_sample_anchors_exact",
    "independent_sample_anchor_reconstruction",
    "five_literal_prefix_full_identities",
    "every_MI_group_common_mask_recomputed",
    "every_full_group_1_over_Bvalid_minus_1_covariance",
    "scalar_contrast_Rubin_recomputed_from_restricted_arrays",
    "three_multivariate_Rubin_Wald_tests_recomputed",
    "per_estimand_dfcom_matches_registry",
    "W2_response_IPW_gates_recomputed",
    "v44_v45_dual_implementation_anchor_and_Qbar",
    "object_wide_m50_MCE_gate"
  )
}

v45cv_verify_m100_required <- function() {
  if (!v45cv_regular_file(release_paths$m100_manifest) ||
      !v45cv_regular_file(gate_path) ||
      !v45cv_regular_file(current_path)) {
    v45cv_stop("CHARLS outcome M100 checkpoint bundle is incomplete.")
  }
  manifest <- v45cv_read_tsv(release_paths$m100_manifest)
  v45cv_rehash_manifest(
    manifest, "CHARLS outcome M100 checkpoint", "access"
  )
  expected_ids <- c(
    "validation", "object_gates", "m100_requirement", "qa",
    "module_state", "current_pointer"
  )
  if (!identical(
        names(manifest),
        c("asset_id", "path_alias", "bytes", "sha256", "access")
      ) ||
      !identical(manifest$asset_id, expected_ids) ||
      any(manifest$access != "PUBLIC_AGGREGATE_NO_ROW_LEVEL")) {
    v45cv_stop("M100 checkpoint manifest asset/access set differs.")
  }

  gate <- v45cv_read_yaml(gate_path)
  current <- v45cv_read_tsv(current_path)
  expected_current_columns <- c(
    "run_id", "state_path_alias", "state_sha256",
    "freeze_contract_sha256", "coefficient_visibility",
    "independent_validation_status"
  )
  if (nrow(current) != 1L ||
      !identical(names(current), expected_current_columns)) {
    v45cv_stop("M100 checkpoint current pointer schema differs.")
  }
  expected_aliases <- c(
    validation = v45cv_alias(release_paths$m100_validation),
    object_gates = v45cv_alias(release_paths$m100_object_gates),
    m100_requirement = v45cv_alias(release_paths$m100),
    qa = v45cv_alias(release_paths$m100_qa),
    module_state = current$state_path_alias[[1L]],
    current_pointer = v45cv_alias(current_path)
  )
  if (!identical(
        setNames(manifest$path_alias, manifest$asset_id),
        expected_aliases
      )) {
    v45cv_stop("M100 checkpoint manifest exact asset/path set differs.")
  }

  contract <- v45cv_load_contract()
  contract_sha <- v45cv_sha256_file(contract_path)
  independent <- gate$independent_validation
  affected_gate <- as.character(unlist(
    independent$affected_objects, use.names = FALSE
  ))
  if (!identical(as.character(independent$status), "M100_REQUIRED") ||
      !identical(
        as.character(independent$output_manifest_path_alias),
        v45cv_alias(release_paths$m100_manifest)
      ) ||
      !identical(
        as.character(independent$output_manifest_sha256),
        v45cv_sha256_file(release_paths$m100_manifest)
      ) ||
      !identical(
        as.character(independent$m100_requirement_path_alias),
        v45cv_alias(release_paths$m100)
      ) ||
      !identical(
        as.character(independent$aggregate_coefficient_release),
        "BLOCKED"
      ) ||
      as.character(gate$freeze$status) != "PASS" ||
      as.character(gate$freeze$contract_sha256) != contract_sha ||
      !v45cv_no(gate$restricted_outcome_execution_allowed) ||
      !v45cv_no(gate$new_coefficient_inspection_allowed) ||
      !v45cv_no(gate$response_or_outcome_result_release_allowed) ||
      !v45cv_yes(gate$m100_freeze_allowed) ||
      current$run_id[[1L]] != as.character(independent$run_id) ||
      current$freeze_contract_sha256[[1L]] != contract_sha ||
      current$independent_validation_status[[1L]] !=
        "M100_REQUIRED" ||
      current$coefficient_visibility[[1L]] != "RESTRICTED") {
    v45cv_stop("M100 checkpoint gate/current pointer no longer verifies.")
  }

  state_path <- v45cv_safe_alias(
    current$state_path_alias[[1L]],
    "results/v45/charls_addendum_v45_1/outcome_execution"
  )
  if (!identical(
        v45cv_sha256_file(state_path),
        current$state_sha256[[1L]]
      )) {
    v45cv_stop("M100 checkpoint restricted state hash differs.")
  }
  state <- v45cv_read_tsv(state_path)
  expected_state_columns <- c(
    "module", "status", "output_path_alias", "output_sha256",
    "completed_at", "coefficient_visibility",
    "independent_validation_status"
  )
  expected_modules <- c(
    "anchor-point",
    "trial-prefix", "trial-full",
    "inconsistency-prefix", "inconsistency-full",
    "adjacent-prefix", "adjacent-full",
    "timehet-prefix", "timehet-full",
    "W2-prefix", "W2-full"
  )
  if (!identical(names(state), expected_state_columns) ||
      !identical(state$module, expected_modules) ||
      any(state$status != "RESTRICTED_COMPLETE") ||
      any(state$independent_validation_status != "M100_REQUIRED") ||
      any(state$coefficient_visibility != "RESTRICTED") ||
      anyNA(state[c("output_path_alias", "output_sha256")]) ||
      any(!grepl("^[0-9a-f]{64}$", state$output_sha256))) {
    v45cv_stop("M100 checkpoint module-state schema/status differs.")
  }
  for (index in seq_len(nrow(state))) {
    path <- v45cv_safe_alias(
      state$output_path_alias[[index]],
      paste0(
        "derived_sensitive/v45/charls_addendum_v45_1/",
        "outcome_execution/m50"
      )
    )
    if (!identical(
          v45cv_sha256_file(path), state$output_sha256[[index]]
        )) {
      v45cv_stop(
        state$module[[index]],
        " restricted hash differs after the M100 checkpoint."
      )
    }
  }

  validation <- v45cv_read_tsv(release_paths$m100_validation)
  object_gates <- v45cv_read_tsv(release_paths$m100_object_gates)
  requirement <- v45cv_read_tsv(release_paths$m100)
  if (!identical(
        names(validation),
        c("check_id", "status", "observed", "expected")
      ) ||
      nrow(validation) != 15L ||
      !identical(
        validation$check_id, v45cv_validation_check_ids()
      ) ||
      any(validation$status[seq_len(14L)] != "PASS") ||
      validation$status[[15L]] != "M100_REQUIRED" ||
      !identical(
        names(object_gates),
        c(
          "object_id", "registered_scalar_n",
          "maximum_MCE_fraction", "m50_gate",
          "coefficient_release_allowed", "action_scope"
        )
      ) ||
      !identical(object_gates$object_id, c("MI-C0", "MI-C2")) ||
      !all(object_gates$m50_gate %in% c("PASS", "M100_REQUIRED")) ||
      !any(object_gates$m50_gate == "M100_REQUIRED") ||
      !identical(
        names(requirement),
        c(
          "object_id", "registered_scalar_n",
          "maximum_MCE_fraction", "m50_gate", "action_scope",
          "required_action", "selective_extension_allowed"
        )
      ) ||
      !nrow(requirement) ||
      any(requirement$m50_gate != "M100_REQUIRED") ||
      any(tolower(as.character(
        requirement$selective_extension_allowed
      )) != "false") ||
      any(requirement$required_action !=
          paste(
            "freeze fresh whole-object m100; rerun all",
            "registered scope from R001"
          ))) {
    v45cv_stop("M100 checkpoint aggregate table schema/status differs.")
  }
  affected <- object_gates$object_id[
    object_gates$m50_gate == "M100_REQUIRED"
  ]
  mce <- suppressWarnings(as.numeric(
    object_gates$maximum_MCE_fraction
  ))
  release_flag <- tolower(as.character(
    object_gates$coefficient_release_allowed
  ))
  requirement_index <- match(
    requirement$object_id, object_gates$object_id
  )
  if (any(!is.finite(mce)) ||
      !identical(mce >= 0.10,
                 object_gates$m50_gate == "M100_REQUIRED") ||
      !identical(
        release_flag,
        ifelse(object_gates$m50_gate == "PASS", "true", "false")
      ) ||
      !identical(requirement$object_id, affected) ||
      !identical(affected_gate, affected) ||
      anyNA(requirement_index) ||
      !identical(
        as.integer(requirement$registered_scalar_n),
        as.integer(object_gates$registered_scalar_n[requirement_index])
      ) ||
      !v45cv_num_equal(
        requirement$maximum_MCE_fraction,
        object_gates$maximum_MCE_fraction[requirement_index],
        tolerance = 0
      ) ||
      !identical(
        requirement$action_scope,
        object_gates$action_scope[requirement_index]
      )) {
    v45cv_stop("M100 affected-object boundary or MCE trigger differs.")
  }
  forbidden_requirement_fields <- c(
    "term", "beta", "coefficient", "direction", "HR", "CI_low",
    "CI_high", "P_value", "joint_test", "statistic"
  )
  if (any(tolower(names(requirement)) %in%
          tolower(forbidden_requirement_fields))) {
    v45cv_stop("M100 requirement exposes a prohibited result field.")
  }
  normal_release_files <- unlist(release_paths[c(
    "validation", "object_gates", "results", "joints",
    "model_diagnostics", "w2_diagnostics", "manifest", "qa"
  )], use.names = FALSE)
  if (any(file.exists(normal_release_files))) {
    v45cv_stop(
      "A coefficient-release asset exists beside the M100 checkpoint."
    )
  }
  if (nrow(contract$model_registry) != 28L) {
    v45cv_stop("M100 checkpoint frozen model registry drifted.")
  }
  cat("CHARLS V45.1 OUTCOME M100 CHECKPOINT VERIFY PASS\n")
  cat("run_id=", current$run_id[[1L]], "\n", sep = "")
  cat("affected_objects=", paste(affected, collapse = ","), "\n",
      sep = "")
  cat("aggregate_coefficient_release=BLOCKED\n")
  invisible(TRUE)
}

v45cv_verify_release <- function() {
  if (!v45cv_regular_file(release_paths$manifest) ||
      !v45cv_regular_file(gate_path) ||
      !v45cv_regular_file(current_path)) {
    v45cv_stop("CHARLS outcome release bundle is incomplete.")
  }
  manifest <- v45cv_read_tsv(release_paths$manifest)
  v45cv_rehash_manifest(manifest, "CHARLS outcome release", "access")
  expected_ids <- c(
    "validation", "object_gates", "results", "joints",
    "model_diagnostics", "w2_diagnostics", "qa",
    "module_state", "current_pointer"
  )
  m100_checkpoint_files <- unlist(release_paths[c(
    "m100", "m100_validation", "m100_object_gates",
    "m100_manifest", "m100_qa"
  )], use.names = FALSE)
  if (!identical(
        names(manifest),
        c("asset_id", "path_alias", "bytes", "sha256", "access")
      ) ||
      !identical(manifest$asset_id, expected_ids) ||
      any(manifest$access != "PUBLIC_AGGREGATE_NO_ROW_LEVEL") ||
      any(file.exists(m100_checkpoint_files))) {
    v45cv_stop("Release manifest contains an invalid access/M100 asset.")
  }
  gate <- v45cv_read_yaml(gate_path)
  current <- v45cv_read_tsv(current_path)
  expected_aliases <- c(
    validation = v45cv_alias(release_paths$validation),
    object_gates = v45cv_alias(release_paths$object_gates),
    results = v45cv_alias(release_paths$results),
    joints = v45cv_alias(release_paths$joints),
    model_diagnostics =
      v45cv_alias(release_paths$model_diagnostics),
    w2_diagnostics = v45cv_alias(release_paths$w2_diagnostics),
    qa = v45cv_alias(release_paths$qa),
    module_state = current$state_path_alias[[1L]],
    current_pointer = v45cv_alias(current_path)
  )
  if (!identical(
        setNames(manifest$path_alias, manifest$asset_id),
        expected_aliases
      )) {
    v45cv_stop("Release manifest exact asset/path set differs.")
  }
  contract <- v45cv_load_contract()
  contract_sha <- v45cv_sha256_file(contract_path)
  if (!identical(
        as.character(gate$independent_validation$status),
        "INDEPENDENT_VALIDATION_PASS"
      ) ||
      !identical(
        as.character(gate$independent_validation$output_manifest_sha256),
        v45cv_sha256_file(release_paths$manifest)
      ) ||
      !v45cv_yes(gate$new_coefficient_inspection_allowed) ||
      !v45cv_yes(gate$response_or_outcome_result_release_allowed) ||
      !v45cv_no(gate$restricted_outcome_execution_allowed) ||
      !v45cv_no(gate$m100_freeze_allowed) ||
      !identical(
        as.character(
          gate$independent_validation$aggregate_coefficient_release
        ),
        "AUTHORIZED"
      ) ||
      nrow(current) != 1L ||
      !identical(
        names(current),
        c(
          "run_id", "state_path_alias", "state_sha256",
          "freeze_contract_sha256", "coefficient_visibility",
          "independent_validation_status"
        )
      ) ||
      current$run_id[[1L]] !=
        gate$independent_validation$run_id ||
      current$freeze_contract_sha256[[1L]] != contract_sha ||
      as.character(gate$freeze$contract_sha256) != contract_sha ||
      as.character(
        gate$independent_validation$output_manifest_path_alias
      ) != v45cv_alias(release_paths$manifest) ||
      !identical(
        as.character(current$independent_validation_status),
        "INDEPENDENT_VALIDATION_PASS"
      ) ||
      !identical(
        as.character(current$coefficient_visibility),
        "AGGREGATE_RELEASED"
      )) {
    v45cv_stop("Released gate/current pointer no longer verifies.")
  }
  state_path <- v45cv_safe_alias(
    current$state_path_alias[[1L]],
    "results/v45/charls_addendum_v45_1/outcome_execution"
  )
  if (!identical(
        v45cv_sha256_file(state_path),
        current$state_sha256[[1L]]
      )) {
    v45cv_stop("Released restricted state hash no longer verifies.")
  }
  state <- v45cv_read_tsv(state_path)
  expected_modules <- c(
    "anchor-point",
    "trial-prefix", "trial-full",
    "inconsistency-prefix", "inconsistency-full",
    "adjacent-prefix", "adjacent-full",
    "timehet-prefix", "timehet-full",
    "W2-prefix", "W2-full"
  )
  if (!identical(
        names(state),
        c(
          "module", "status", "output_path_alias", "output_sha256",
          "completed_at", "coefficient_visibility",
          "independent_validation_status"
        )
      ) ||
      !identical(state$module, expected_modules) ||
      any(state$status != "RESTRICTED_COMPLETE") ||
      any(state$independent_validation_status !=
          "INDEPENDENT_VALIDATION_PASS") ||
      any(state$coefficient_visibility != "RESTRICTED")) {
    v45cv_stop("Released module-state schema/status differs.")
  }
  for (index in seq_len(nrow(state))) {
    path <- v45cv_safe_alias(
      state$output_path_alias[[index]],
      paste0(
        "derived_sensitive/v45/charls_addendum_v45_1/",
        "outcome_execution/m50"
      )
    )
    if (!identical(
          v45cv_sha256_file(path), state$output_sha256[[index]]
        )) {
      v45cv_stop(state$module[[index]],
                 " restricted hash differs postrelease.")
    }
  }
  validation <- v45cv_read_tsv(release_paths$validation)
  object_gates <- v45cv_read_tsv(release_paths$object_gates)
  results <- v45cv_read_tsv(release_paths$results)
  joints <- v45cv_read_tsv(release_paths$joints)
  model_diagnostics <-
    v45cv_read_tsv(release_paths$model_diagnostics)
  w2_diagnostics <- v45cv_read_tsv(release_paths$w2_diagnostics)
  if (!identical(
        names(validation),
        c("check_id", "status", "observed", "expected")
      ) ||
      nrow(validation) != 15L ||
      !identical(
        validation$check_id, v45cv_validation_check_ids()
      ) ||
      any(validation$status != "PASS") ||
      !identical(
        names(object_gates),
        c(
          "object_id", "registered_scalar_n",
          "maximum_MCE_fraction", "m50_gate",
          "coefficient_release_allowed", "action_scope"
        )
      ) ||
      !identical(object_gates$object_id, c("MI-C0", "MI-C2")) ||
      any(object_gates$m50_gate != "PASS") ||
      nrow(results) != 32L ||
      !identical(
        names(results),
        c(
          "analysis_id", "term", "module", "mi_object",
          "sample_id", "weight_variant", "n",
          "events_or_responses", "period_rows", "psu", "design_df",
          "beta", "standard_error", "HR", "CI_low", "CI_high",
          "P_value", "Rubin_df", "FMI", "MCE", "MCE_fraction",
          "minimum_valid_replicate_fraction", "diagnostic_status",
          "independent_validation_status"
        )
      ) ||
      any(results$independent_validation_status != "PASS") ||
      nrow(joints) != 3L ||
      !identical(
        names(joints),
        c(
          "analysis_id", "test_id", "terms", "module",
          "mi_object", "sample_id", "n", "events_or_responses",
          "period_rows", "psu", "design_df", "statistic",
          "test_df", "P_value", "independent_validation_status"
        )
      ) ||
      any(joints$independent_validation_status != "PASS") ||
      nrow(model_diagnostics) != 850L ||
      !identical(
        names(model_diagnostics),
        c(
          "module", "imputation", "group_id",
          "valid_replicate_n", "valid_replicate_fraction",
          "valid_fraction_gate", "failed_replicate_n",
          "minimum_dfcom", "maximum_dfcom", "covariance_rule"
        )
      ) ||
      nrow(w2_diagnostics) != 5L ||
      !identical(
        names(w2_diagnostics),
        c(
          "unit", "metric", "minimum", "median", "maximum",
          "GO_n", "CAUTION_n", "STOP_n"
        )
      )) {
    v45cv_stop("Released aggregate table schema/cardinality differs.")
  }
  forbidden_public <- c(
    "participant_id", "community_id", "completed", "mids", "fit",
    "probability", "availability_factor", "weight",
    "replicate_multiplier", "replicates", "point"
  )
  public_columns <- tolower(unique(c(
    names(validation), names(object_gates), names(results),
    names(joints), names(model_diagnostics), names(w2_diagnostics)
  )))
  if (any(public_columns %in% forbidden_public) ||
      nrow(contract$model_registry) != 28L) {
    v45cv_stop("Released tables contain forbidden columns or registry drift.")
  }
  cat("CHARLS V45.1 OUTCOME RELEASE VERIFY PASS\n")
  cat("run_id=", current$run_id[[1L]], "\n", sep = "")
  cat("aggregate_coefficient_release=VERIFIED\n")
  invisible(TRUE)
}

v45cv_verify_freeze <- function() {
  freeze_script <- file.path(
    root,
    "R/v45/charls_addendum_v45_1/",
    "11_freeze_charls_outcome_execution_v45_1.R"
  )
  output <- system2(
    file.path(R.home("bin"), "Rscript"),
    c("--vanilla", freeze_script, "--verify"),
    stdout = TRUE, stderr = TRUE
  )
  status <- attr(output, "status")
  if ((!is.null(status) && status != 0L) ||
      !any(grepl(
        "CHARLS V45.1 OUTCOME FREEZE VERIFY PASS",
        output, fixed = TRUE
      ))) {
    v45cv_stop(
      "CHARLS outcome freeze verification failed: ",
      paste(output, collapse = " | ")
    )
  }
  invisible(TRUE)
}

v45cv_load_contract <- function() {
  if (!v45cv_regular_file(contract_path)) {
    v45cv_stop("Frozen restricted outcome contract is absent.")
  }
  before <- v45cv_sha256_file(contract_path)
  contract <- readRDS(contract_path)
  if (!identical(before, v45cv_sha256_file(contract_path)) ||
      !identical(
        contract$contract_version,
        "v45_1_charls_outcome_execution"
      ) ||
      any(unlist(contract$governance) != 0L) ||
      !is.data.frame(contract$model_registry) ||
      nrow(contract$model_registry) != 28L ||
      anyDuplicated(contract$model_registry$analysis_id) ||
      !is.data.frame(contract$threshold_registry) ||
      nrow(contract$threshold_registry) != 12L ||
      !is.data.frame(contract$anchor_registry) ||
      nrow(contract$anchor_registry) != 75L ||
      !is.data.frame(contract$crosswalk) ||
      nrow(contract$crosswalk) != 18L) {
    v45cv_stop("Frozen outcome contract schema failed.")
  }
  for (field in c(
    "specification_manifest", "code_manifest", "input_manifest"
  )) {
    v45cv_rehash_manifest(contract[[field]], paste0("contract/", field))
  }
  contract
}

v45cv_load_runner_library <- function(contract) {
  runner_path <- file.path(
    root,
    "R/v45/charls_addendum_v45_1/",
    "12_run_charls_outcome_execution_v45_1.R"
  )
  runner_alias <- v45cv_alias(runner_path)
  code_row <- contract$code_manifest[
    contract$code_manifest$path_alias == runner_alias, , drop = FALSE
  ]
  if (nrow(code_row) != 1L ||
      !identical(
        v45cv_sha256_file(runner_path), code_row$sha256[[1L]]
      ) ||
      !any(grepl(
        "V45_CHARLS_OUTCOME_LIBRARY_ONLY",
        readLines(runner_path, warn = FALSE), fixed = TRUE
      ))) {
    v45cv_stop("Sealed runner code/library guard does not verify.")
  }
  runner <- new.env(parent = globalenv())
  old <- Sys.getenv(
    "V45_CHARLS_OUTCOME_LIBRARY_ONLY", unset = NA_character_
  )
  Sys.setenv(V45_CHARLS_OUTCOME_LIBRARY_ONLY = "yes")
  on.exit({
    if (is.na(old)) {
      Sys.unsetenv("V45_CHARLS_OUTCOME_LIBRARY_ONLY")
    } else {
      Sys.setenv(V45_CHARLS_OUTCOME_LIBRARY_ONLY = old)
    }
  }, add = TRUE)
  sys.source(runner_path, envir = runner)
  required <- c(
    "v45c_load_mids", "v45c_load_context",
    "v45c_prepare_person", "v45c_build_period",
    "v45c_formula", "v45c_fit_cloglog",
    "v45c_trial_scalar_map",
    "v45c_inconsistency_scalar_map",
    "v45c_inconsistency_joint_definitions",
    "v45c_adjacent_scalar_map", "v45c_timehet_scalar_map",
    "v45c_timehet_joint_definitions", "v45c_w2_scalar_map",
    "v45c_module_rows"
  )
  if (!all(vapply(
        required, exists, logical(1),
        envir = runner, inherits = FALSE
      ))) {
    v45cv_stop("Sealed runner library interface is incomplete.")
  }
  runner
}

v45cv_load_restricted_modules <- function(
    contract, expected_modules) {
  gate <- v45cv_read_yaml(gate_path)
  contract_sha <- v45cv_sha256_file(contract_path)
  if (!identical(as.character(gate$freeze$status), "PASS") ||
      !identical(
        as.character(gate$freeze$contract_sha256), contract_sha
      ) ||
      !v45cv_yes(gate$restricted_outcome_execution_allowed) ||
      !v45cv_no(gate$new_coefficient_inspection_allowed) ||
      !v45cv_no(gate$response_or_outcome_result_release_allowed)) {
    v45cv_stop("Outcome gate does not authorize independent validation.")
  }
  current_sha_before <- v45cv_sha256_file(current_path)
  current <- v45cv_read_tsv(current_path)
  expected_current <- c(
    "run_id", "state_path_alias", "state_sha256",
    "freeze_contract_sha256", "coefficient_visibility",
    "independent_validation_status"
  )
  if (nrow(current) != 1L ||
      !identical(names(current), expected_current) ||
      !grepl(
        "^charls_v45_1_outcome_m50_[0-9]{8}T[0-9]{6}_pid[0-9]+$",
        current$run_id[[1L]]
      ) ||
      current$freeze_contract_sha256[[1L]] != contract_sha ||
      current$coefficient_visibility[[1L]] != "RESTRICTED" ||
      current$independent_validation_status[[1L]] != "NOT_RUN") {
    v45cv_stop("Restricted current-run pointer is invalid.")
  }
  state_path <- v45cv_safe_alias(
    current$state_path_alias[[1L]],
    "results/v45/charls_addendum_v45_1/outcome_execution"
  )
  if (!identical(
        v45cv_sha256_file(state_path),
        current$state_sha256[[1L]]
      )) {
    v45cv_stop("Restricted module-state hash differs.")
  }
  state <- v45cv_read_tsv(state_path)
  expected_state <- c(
    "module", "status", "output_path_alias", "output_sha256",
    "completed_at", "coefficient_visibility",
    "independent_validation_status"
  )
  if (!identical(names(state), expected_state) ||
      !identical(state$module, expected_modules) ||
      any(state$status != "RESTRICTED_COMPLETE") ||
      any(state$coefficient_visibility != "RESTRICTED") ||
      any(state$independent_validation_status != "NOT_RUN") ||
      anyNA(state[c("output_path_alias", "output_sha256")]) ||
      any(!grepl("^[0-9a-f]{64}$", state$output_sha256))) {
    v45cv_stop("Restricted module state is incomplete or drifted.")
  }
  restricted <- setNames(lapply(seq_len(nrow(state)), function(index) {
    module <- state$module[[index]]
    path <- v45cv_safe_alias(
      state$output_path_alias[[index]],
      paste0(
        "derived_sensitive/v45/charls_addendum_v45_1/",
        "outcome_execution/m50"
      )
    )
    if (!identical(
          v45cv_sha256_file(path), state$output_sha256[[index]]
        )) {
      v45cv_stop(module, " restricted SHA-256 differs.")
    }
    value <- readRDS(path)
    expected_schema <- paste0(
      "v45_1_charls_", gsub("-", "_", module, fixed = TRUE),
      "_restricted"
    )
    if (!identical(value$schema_version, expected_schema) ||
        !identical(value$run_id, current$run_id[[1L]]) ||
        !identical(value$module, module) ||
        !identical(value$freeze_contract_sha256, contract_sha) ||
        !identical(value$coefficient_visibility, "RESTRICTED") ||
        !identical(value$independent_validation_status, "NOT_RUN") ||
        !identical(value$completed_dataset_saved, FALSE) ||
        !identical(value$model_object_saved, FALSE) ||
        !identical(value$row_level_data_saved, FALSE) ||
        !identical(
          value$individual_probability_or_weight_saved, FALSE
        )) {
      v45cv_stop(module, " restricted metadata schema failed.")
    }
    v45cv_validate_recorded_pooling_status(module, value)
    v45cv_forbidden_payload_audit(value, module)
    value
  }), state$module)
  if (!identical(
        v45cv_sha256_file(state_path),
        current$state_sha256[[1L]]
      ) ||
      !identical(v45cv_sha256_file(current_path),
                 current_sha_before)) {
    v45cv_stop("Restricted pointer/state changed during module loading.")
  }
  list(
    gate = gate, current = current, state = state,
    state_path = state_path, restricted = restricted
  )
}

v45cv_validate_execution_coverage <- function(
    contract, scalar, joints) {
  registry <- contract$model_registry
  response_id <- "v45_c_w2_obs_d2"
  executed <- unique(c(
    as.character(scalar$analysis_id),
    as.character(joints$analysis_id),
    response_id
  ))
  if (length(executed) != 28L ||
      !setequal(executed, registry$analysis_id)) {
    v45cv_stop(
      "Independent execution does not cover the exact 28-row registry; ",
      "missing=", paste(setdiff(registry$analysis_id, executed),
                        collapse = "|"),
      "; unexpected=", paste(setdiff(executed, registry$analysis_id),
                             collapse = "|")
    )
  }
  for (index in seq_len(nrow(scalar))) {
    row <- registry[
      registry$analysis_id == scalar$analysis_id[[index]],
      , drop = FALSE
    ]
    if (nrow(row) != 1L ||
        !is.finite(suppressWarnings(
          as.numeric(row$expected_dfcom[[1L]])
        )) ||
        !identical(
          as.numeric(scalar$dfcom[[index]]),
          as.numeric(row$expected_dfcom[[1L]])
        ) ||
        scalar$mi_object[[index]] != row$mi_object[[1L]]) {
      v45cv_stop(
        scalar$analysis_id[[index]], "::", scalar$term[[index]],
        " registry MI-object/dfcom contract differs."
      )
    }
  }
  data.frame(
    analysis_id = registry$analysis_id,
    execution_kind = ifelse(
      registry$analysis_id == response_id,
      "response_gate",
      ifelse(
        registry$analysis_id %in% joints$analysis_id,
        "multivariate_joint", "released_scalar"
      )
    ),
    status = "PASS",
    stringsAsFactors = FALSE
  )
}

v45cv_model_diagnostics <- function(validated_full) {
  do.call(rbind, lapply(names(validated_full), function(module) {
    do.call(rbind, lapply(validated_full[[module]], function(result) {
      do.call(rbind, lapply(names(result$groups), function(group_id) {
        group <- result$groups[[group_id]]
        data.frame(
          module = module,
          imputation = result$imputation,
          group_id = group_id,
          valid_replicate_n = group$valid_n,
          valid_replicate_fraction = group$valid_fraction,
          valid_fraction_gate = group$gate,
          failed_replicate_n = group$failure_n,
          minimum_dfcom = min(group$dfcom_by_column),
          maximum_dfcom = max(group$dfcom_by_column),
          covariance_rule = "1/(B_valid-1)",
          stringsAsFactors = FALSE
        )
      }))
    }))
  }))
}

v45cv_public_scalar <- function(
    scalar, registry, w2_overall_status) {
  index <- match(scalar$analysis_id, registry$analysis_id)
  if (anyNA(index)) {
    v45cv_stop("A pooled scalar is absent from the registry.")
  }
  meta <- registry[index, , drop = FALSE]
  data.frame(
    analysis_id = scalar$analysis_id,
    term = scalar$term,
    module = scalar$module,
    mi_object = scalar$mi_object,
    sample_id = meta$sample_id,
    weight_variant = meta$weight_variant,
    n = meta$expected_n,
    events_or_responses = meta$expected_events_or_responses,
    period_rows = meta$expected_period_rows,
    psu = meta$expected_psu,
    design_df = meta$expected_dfcom,
    beta = scalar$estimate,
    standard_error = scalar$standard_error,
    HR = exp(scalar$estimate),
    CI_low = exp(scalar$ci_low),
    CI_high = exp(scalar$ci_high),
    P_value = scalar$p_value,
    Rubin_df = scalar$df,
    FMI = scalar$FMI,
    MCE = scalar$MCE,
    MCE_fraction = scalar$MCE_fraction,
    minimum_valid_replicate_fraction =
      scalar$minimum_valid_replicate_fraction,
    diagnostic_status = ifelse(
      scalar$mi_object == "MI-C2",
      w2_overall_status,
      scalar$worst_valid_fraction_gate
    ),
    independent_validation_status = "PASS",
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
}

v45cv_public_joints <- function(joints, registry) {
  index <- match(joints$analysis_id, registry$analysis_id)
  if (anyNA(index)) {
    v45cv_stop("A joint test is absent from the registry.")
  }
  meta <- registry[index, , drop = FALSE]
  data.frame(
    analysis_id = joints$analysis_id,
    test_id = joints$test_id,
    terms = joints$terms,
    module = joints$module,
    mi_object = joints$mi_object,
    sample_id = meta$sample_id,
    n = meta$expected_n,
    events_or_responses = meta$expected_events_or_responses,
    period_rows = meta$expected_period_rows,
    psu = meta$expected_psu,
    design_df = meta$expected_dfcom,
    statistic = joints$statistic,
    test_df = joints$df,
    P_value = joints$p_value,
    independent_validation_status = "PASS",
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
}

v45cv_stage_write <- function(value, path, type) {
  if (type == "tsv") {
    v45_charls_outcome_atomic_write_tsv(value, path)
  } else if (type == "lines") {
    v45_charls_outcome_atomic_write_lines(value, path)
  } else if (type == "yaml") {
    v45cv_atomic_write_yaml(value, path)
  } else {
    v45cv_stop("Unknown staged asset type: ", type)
  }
  invisible(TRUE)
}

v45cv_transaction_host <- function() {
  value <- as.character(Sys.info()[["nodename"]])
  if (length(value) != 1L || is.na(value) || !nzchar(value)) {
    value <- "UNKNOWN_LOCAL_HOST"
  }
  value
}

v45cv_pid_alive <- function(pid) {
  pid <- suppressWarnings(as.integer(pid))
  if (length(pid) != 1L || is.na(pid) || pid < 1L) return(FALSE)
  isTRUE(tryCatch(
    tools::pskill(pid, 0L),
    error = function(error) FALSE
  ))
}

v45cv_default_transaction_context <- function() {
  list(
    public_root = public_root,
    qa_root = qa_root,
    work_root = work_root,
    current_path = current_path,
    gate_path = gate_path,
    lock_path = file.path(
      public_root, ".charls_outcome_validation.lock"
    ),
    journal_path = file.path(
      public_root, ".charls_outcome_validation_transaction.tsv"
    )
  )
}

v45cv_transaction_path <- function(path) {
  if (length(path) != 1L || is.na(path) || !nzchar(path)) {
    v45cv_stop("Transaction path is empty.")
  }
  parent <- normalizePath(dirname(path), mustWork = TRUE)
  file.path(parent, basename(path))
}

v45cv_validate_transaction_context <- function(context) {
  required <- c(
    "public_root", "qa_root", "work_root", "current_path",
    "gate_path", "lock_path", "journal_path"
  )
  if (!is.list(context) || !identical(names(context), required)) {
    v45cv_stop("Validation transaction context schema differs.")
  }
  for (field in c("public_root", "qa_root", "work_root")) {
    context[[field]] <- normalizePath(
      context[[field]], mustWork = TRUE
    )
  }
  for (field in c(
    "current_path", "gate_path", "lock_path", "journal_path"
  )) {
    context[[field]] <- v45cv_transaction_path(context[[field]])
  }
  if (!startsWith(
        context$current_path,
        paste0(context$public_root, .Platform$file.sep)
      ) ||
      !startsWith(
        context$gate_path,
        paste0(context$work_root, .Platform$file.sep)
      ) ||
      dirname(context$lock_path) != context$public_root ||
      dirname(context$journal_path) != context$public_root ||
      identical(context$lock_path, context$journal_path)) {
    v45cv_stop("Validation transaction context escapes its roots.")
  }
  context
}

v45cv_transaction_journal_columns <- function() {
  c(
    "journal_version", "transaction_id", "run_id",
    "owner_pid", "owner_host", "owner_sha256",
    "phase", "updated_at_utc", "sequence",
    "target_id", "target_kind", "destination_path",
    "stage_path", "expected_sha256", "had_existing",
    "original_sha256", "backup_path", "backup_sha256",
    "stage_ready", "backup_ready", "promoted",
    "gate_last", "verified"
  )
}

v45cv_validate_transaction_owner <- function(
    owner, context, expected_transaction_id = NULL) {
  expected <- c(
    "transaction_id", "run_id", "pid", "host",
    "acquired_at_utc", "journal_path"
  )
  pid <- if (is.data.frame(owner) && nrow(owner) == 1L &&
             "pid" %in% names(owner)) {
    suppressWarnings(as.integer(owner$pid[[1L]]))
  } else NA_integer_
  if (!is.data.frame(owner) || nrow(owner) != 1L ||
      !identical(names(owner), expected) ||
      is.na(owner$transaction_id[[1L]]) ||
      !nzchar(owner$transaction_id[[1L]]) ||
      is.na(owner$run_id[[1L]]) || !nzchar(owner$run_id[[1L]]) ||
      is.na(pid) || pid < 1L ||
      is.na(owner$host[[1L]]) || !nzchar(owner$host[[1L]]) ||
      is.na(owner$acquired_at_utc[[1L]]) ||
      !nzchar(owner$acquired_at_utc[[1L]]) ||
      !identical(
        as.character(owner$journal_path[[1L]]),
        context$journal_path
      ) ||
      (!is.null(expected_transaction_id) &&
       !identical(
         as.character(owner$transaction_id[[1L]]),
         as.character(expected_transaction_id)
       ))) {
    v45cv_stop("Validation transaction owner binding is invalid.")
  }
  owner$pid <- pid
  owner
}

v45cv_transaction_destination_allowed <- function(path, context) {
  path <- v45cv_transaction_path(path)
  roots <- c(
    context$public_root, context$qa_root, context$work_root
  )
  any(vapply(roots, function(root_value) {
    startsWith(path, paste0(root_value, .Platform$file.sep))
  }, logical(1)))
}

v45cv_validate_transaction_journal <- function(
    journal, context, owner = NULL) {
  required <- v45cv_transaction_journal_columns()
  if (!is.data.frame(journal) || !nrow(journal) ||
      !identical(names(journal), required) ||
      !identical(
        as.integer(journal$sequence), seq_len(nrow(journal))
      ) ||
      anyDuplicated(journal$target_id) ||
      anyDuplicated(journal$destination_path) ||
      anyDuplicated(journal$stage_path) ||
      anyNA(journal[required])) {
    v45cv_stop("Validation transaction journal schema differs.")
  }
  invariant <- c(
    "journal_version", "transaction_id", "run_id", "owner_pid",
    "owner_host", "owner_sha256", "phase", "updated_at_utc"
  )
  if (any(vapply(
        invariant,
        function(field) length(unique(journal[[field]])) != 1L,
        logical(1)
      )) ||
      !identical(unique(journal$journal_version), "v45cv_tx_v1") ||
      !grepl(
        "^[A-Za-z0-9_.-]+$",
        unique(journal$transaction_id)
      ) ||
      !grepl("^[0-9a-f]{64}$", unique(journal$owner_sha256)) ||
      !grepl("^[A-Z0-9_.-]+$", unique(journal$phase)) ||
      is.na(unique(journal$run_id)) ||
      !nzchar(unique(journal$run_id)) ||
      any(!grepl("^[A-Za-z0-9_.-]+$", journal$target_id)) ||
      any(!journal$target_kind %in% c(
        "ASSET", "MANIFEST", "MODULE_STATE",
        "CURRENT_POINTER", "GATE"
      )) ||
      any(!journal$had_existing %in% c("yes", "no")) ||
      any(!journal$stage_ready %in% c("yes", "no")) ||
      any(!journal$backup_ready %in% c("yes", "no")) ||
      any(!journal$promoted %in% c("yes", "no")) ||
      any(!journal$gate_last %in% c("yes", "no")) ||
      any(!journal$verified %in% c("yes", "no")) ||
      sum(journal$gate_last == "yes") != 1L ||
      journal$target_id[[nrow(journal)]] != "gate" ||
      journal$target_kind[[nrow(journal)]] != "GATE" ||
      journal$gate_last[[nrow(journal)]] != "yes" ||
      any(journal$gate_last[-nrow(journal)] != "no") ||
      any(journal$promoted == "yes" &
          journal$stage_ready == "yes") ||
      any(journal$had_existing == "yes" &
          journal$promoted == "yes" &
          journal$backup_ready != "yes") ||
      any(journal$backup_ready == "yes" &
          journal$backup_sha256 != journal$original_sha256) ||
      any(journal$verified == "yes" &
          journal$promoted != "yes") ||
      (unique(journal$phase) == "VERIFIED" &&
       any(journal$verified != "yes")) ||
      (unique(journal$phase) != "VERIFIED" &&
       any(journal$verified == "yes"))) {
    v45cv_stop("Validation transaction journal invariants differ.")
  }
  expected_fixed_kind <- c(
    manifest = "MANIFEST",
    module_state = "MODULE_STATE",
    current_pointer = "CURRENT_POINTER",
    gate = "GATE"
  )
  manifest_present <- "manifest" %in% journal$target_id
  required_fixed <- c("module_state", "current_pointer", "gate")
  required_index <- match(required_fixed, journal$target_id)
  expected_tail <- if (manifest_present) {
    c("manifest", required_fixed)
  } else required_fixed
  if (anyNA(required_index) ||
      !identical(
        tail(journal$target_id, length(expected_tail)),
        expected_tail
      ) ||
      any(journal$target_kind[required_index] !=
          expected_fixed_kind[required_fixed]) ||
      (manifest_present &&
       journal$target_kind[
         match("manifest", journal$target_id)
       ] != "MANIFEST") ||
      any(journal$target_kind[
        !journal$target_id %in% names(expected_fixed_kind)
      ] != "ASSET") ||
      any(journal$had_existing[
        journal$target_kind %in% c("ASSET", "MANIFEST")
      ] != "no") ||
      any(journal$had_existing[
        journal$target_kind %in%
          c("MODULE_STATE", "CURRENT_POINTER", "GATE")
      ] != "yes")) {
    v45cv_stop("Validation journal target-kind mapping differs.")
  }
  owner_pid <- suppressWarnings(as.integer(
    unique(journal$owner_pid)
  ))
  if (is.na(owner_pid) || owner_pid < 1L ||
      !identical(
        as.character(unique(journal$owner_host)),
        v45cv_transaction_host()
      )) {
    v45cv_stop("Validation transaction journal host/PID is invalid.")
  }
  for (index in seq_len(nrow(journal))) {
    destination <- v45cv_transaction_path(
      journal$destination_path[[index]]
    )
    stage <- v45cv_transaction_path(journal$stage_path[[index]])
    if (!identical(destination, journal$destination_path[[index]]) ||
        !identical(stage, journal$stage_path[[index]]) ||
        !v45cv_transaction_destination_allowed(
          destination, context
        ) ||
        dirname(stage) != dirname(destination) ||
        basename(stage) != paste0(
          ".", basename(destination), ".",
          journal$transaction_id[[index]], ".staging"
        ) ||
        identical(destination, context$journal_path) ||
        identical(destination, context$lock_path)) {
      v45cv_stop("Validation transaction journal path is unsafe.")
    }
    had_existing <- journal$had_existing[[index]] == "yes"
    if (had_existing) {
      backup <- v45cv_transaction_path(
        journal$backup_path[[index]]
      )
      if (!identical(backup, journal$backup_path[[index]]) ||
          dirname(backup) != dirname(destination) ||
          basename(backup) != paste0(
            ".", basename(destination), ".",
            journal$transaction_id[[index]], ".backup"
          ) ||
          !grepl(
            "^[0-9a-f]{64}$",
            journal$original_sha256[[index]]
          ) ||
          !journal$backup_sha256[[index]] %in%
            c("PENDING", journal$original_sha256[[index]])) {
        v45cv_stop("Validation transaction backup binding is invalid.")
      }
    } else if (
      journal$original_sha256[[index]] != "NONE" ||
      journal$backup_path[[index]] != "NONE" ||
      journal$backup_sha256[[index]] != "NONE" ||
      journal$backup_ready[[index]] != "no"
    ) {
      v45cv_stop("New transaction target retained a backup binding.")
    }
    expected <- journal$expected_sha256[[index]]
    if (!expected %in% "PENDING" &&
        !grepl("^[0-9a-f]{64}$", expected)) {
      v45cv_stop("Validation transaction expected SHA-256 is invalid.")
    }
    if (journal$stage_ready[[index]] == "yes" &&
        !grepl("^[0-9a-f]{64}$", expected)) {
      v45cv_stop("Ready transaction stage lacks an expected SHA-256.")
    }
  }
  if (!is.null(owner)) {
    owner <- v45cv_validate_transaction_owner(
      owner, context, unique(journal$transaction_id)
    )
    owner_path <- file.path(context$lock_path, "owner.tsv")
    if (!v45cv_regular_file(owner_path) ||
        !identical(
          unique(journal$owner_sha256),
          v45cv_sha256_file(owner_path)
        ) ||
        !identical(
          as.character(unique(journal$run_id)),
          as.character(owner$run_id[[1L]])
        ) ||
        !identical(
          owner_pid, as.integer(owner$pid[[1L]])
        ) ||
        !identical(
          as.character(unique(journal$owner_host)),
          as.character(owner$host[[1L]])
        )) {
      v45cv_stop("Validation journal is not bound to its lock owner.")
    }
  }
  journal
}

v45cv_write_transaction_journal <- function(
    journal, context, phase, owner = NULL) {
  journal$phase <- phase
  journal$updated_at_utc <-
    format(Sys.time(), "%Y-%m-%dT%H:%M:%SZ", tz = "UTC")
  v45cv_validate_transaction_journal(journal, context, owner)
  temporary <- v45_charls_outcome_atomic_target(
    context$journal_path
  )
  on.exit(
    if (file.exists(temporary)) unlink(temporary, force = TRUE),
    add = TRUE
  )
  utils::write.table(
    journal, temporary, sep = "\t", row.names = FALSE,
    col.names = TRUE, quote = TRUE, na = ""
  )
  v45cv_validate_transaction_journal(
    v45cv_read_tsv(temporary), context, owner
  )
  if (!file.rename(temporary, context$journal_path)) {
    v45cv_stop(
      "Atomic durable transaction-journal promotion failed."
    )
  }
  reread <- v45cv_read_tsv(context$journal_path)
  v45cv_validate_transaction_journal(reread, context, owner)
}

v45cv_read_transaction_journal <- function(context, owner = NULL) {
  if (!v45cv_regular_file(context$journal_path)) {
    v45cv_stop("Durable validation transaction journal is absent.")
  }
  v45cv_validate_transaction_journal(
    v45cv_read_tsv(context$journal_path), context, owner
  )
}

v45cv_transaction_file_sha <- function(path, allow_absent = FALSE) {
  if (!file.exists(path)) {
    if (isTRUE(allow_absent)) return(NA_character_)
    v45cv_stop("Transaction file is absent: ", path)
  }
  if (!v45cv_regular_file(path)) {
    v45cv_stop("Transaction path is not a regular file: ", path)
  }
  v45cv_sha256_file(path)
}

v45cv_transaction_remove <- function(path) {
  if (!file.exists(path)) return(invisible(TRUE))
  if (dir.exists(path) || nzchar(Sys.readlink(path))) {
    v45cv_stop("Refusing to remove an unsafe transaction path: ", path)
  }
  unlink(path, force = TRUE)
  if (file.exists(path)) {
    v45cv_stop("Could not remove transaction path: ", path)
  }
  invisible(TRUE)
}

v45cv_verify_transaction_destinations <- function(journal) {
  for (index in seq_len(nrow(journal))) {
    destination <- journal$destination_path[[index]]
    expected <- journal$expected_sha256[[index]]
    if (!grepl("^[0-9a-f]{64}$", expected) ||
        !v45cv_regular_file(destination) ||
        !identical(v45cv_sha256_file(destination), expected)) {
      v45cv_stop(
        "Verified transaction destination differs: ",
        journal$target_id[[index]]
      )
    }
  }
  invisible(TRUE)
}

v45cv_rollback_transaction <- function(context, owner = NULL) {
  journal <- v45cv_read_transaction_journal(context, owner)
  journal$verified <- "no"
  journal <- v45cv_write_transaction_journal(
    journal, context, "ROLLING_BACK", owner
  )
  for (index in rev(seq_len(nrow(journal)))) {
    destination <- journal$destination_path[[index]]
    stage <- journal$stage_path[[index]]
    expected <- journal$expected_sha256[[index]]
    current_sha <- v45cv_transaction_file_sha(
      destination, allow_absent = TRUE
    )
    if (journal$had_existing[[index]] == "yes") {
      original <- journal$original_sha256[[index]]
      backup <- journal$backup_path[[index]]
      backup_sha <- v45cv_transaction_file_sha(
        backup, allow_absent = TRUE
      )
      if (!is.na(backup_sha) && !identical(backup_sha, original)) {
        v45cv_stop(
          "Rollback backup SHA-256 differs: ",
          journal$target_id[[index]]
        )
      }
      if (is.na(backup_sha)) {
        if (is.na(current_sha) || !identical(current_sha, original)) {
          v45cv_stop(
            "Rollback lacks both original destination and backup: ",
            journal$target_id[[index]]
          )
        }
      } else if (!is.na(current_sha) &&
                 identical(current_sha, original)) {
        v45cv_transaction_remove(backup)
      } else {
        if (!is.na(current_sha) &&
            !identical(current_sha, expected)) {
          v45cv_stop(
            "Rollback destination has an unexpected SHA-256: ",
            journal$target_id[[index]]
          )
        }
        if (!is.na(current_sha)) {
          v45cv_transaction_remove(destination)
        }
        if (!file.rename(backup, destination) ||
            !identical(
              v45cv_transaction_file_sha(destination), original
            )) {
          v45cv_stop(
            "Rollback could not restore original destination: ",
            journal$target_id[[index]]
          )
        }
      }
      if (!identical(
            v45cv_transaction_file_sha(destination), original
          )) {
        v45cv_stop(
          "Rollback restoration verification failed: ",
          journal$target_id[[index]]
        )
      }
    } else if (!is.na(current_sha)) {
      if (!grepl("^[0-9a-f]{64}$", expected) ||
          !identical(current_sha, expected)) {
        v45cv_stop(
          "Rollback new destination has an unexpected SHA-256: ",
          journal$target_id[[index]]
        )
      }
      v45cv_transaction_remove(destination)
    }
    v45cv_transaction_remove(stage)
    journal$stage_ready[[index]] <- "no"
    journal$backup_ready[[index]] <- "no"
    journal$promoted[[index]] <- "no"
    journal <- v45cv_write_transaction_journal(
      journal, context,
      paste0("ROLLED_BACK_", journal$sequence[[index]]),
      owner
    )
  }
  for (index in seq_len(nrow(journal))) {
    destination <- journal$destination_path[[index]]
    if (journal$had_existing[[index]] == "yes") {
      if (!v45cv_regular_file(destination) ||
          !identical(
            v45cv_sha256_file(destination),
            journal$original_sha256[[index]]
          )) {
        v45cv_stop("Rollback final destination verification failed.")
      }
    } else if (file.exists(destination)) {
      v45cv_stop("Rollback left a newly promoted destination.")
    }
    if (journal$backup_path[[index]] != "NONE") {
      v45cv_transaction_remove(journal$backup_path[[index]])
    }
    v45cv_transaction_remove(journal$stage_path[[index]])
  }
  journal <- v45cv_write_transaction_journal(
    journal, context, "ROLLED_BACK", owner
  )
  v45cv_transaction_remove(context$journal_path)
  invisible(TRUE)
}

v45cv_finalize_verified_transaction <- function(
    context, owner = NULL) {
  journal <- v45cv_read_transaction_journal(context, owner)
  if (!identical(unique(journal$phase), "VERIFIED") ||
      any(journal$verified != "yes")) {
    v45cv_stop("Only a VERIFIED transaction may be finalized.")
  }
  v45cv_verify_transaction_destinations(journal)
  for (index in seq_len(nrow(journal))) {
    v45cv_transaction_remove(journal$stage_path[[index]])
    if (journal$backup_path[[index]] != "NONE") {
      backup <- journal$backup_path[[index]]
      if (file.exists(backup) &&
          !identical(
            v45cv_transaction_file_sha(backup),
            journal$original_sha256[[index]]
          )) {
        v45cv_stop("Verified transaction backup SHA-256 differs.")
      }
      v45cv_transaction_remove(backup)
    }
  }
  v45cv_verify_transaction_destinations(journal)
  v45cv_transaction_remove(context$journal_path)
  invisible(TRUE)
}

v45cv_recover_stale_transaction <- function(context) {
  lock_exists <- dir.exists(context$lock_path)
  if (file.exists(context$lock_path) && !lock_exists) {
    v45cv_stop("Validation transaction lock is not a directory.")
  }
  if (lock_exists && nzchar(Sys.readlink(context$lock_path))) {
    v45cv_stop("Validation transaction lock is an unsafe symlink.")
  }
  journal_exists <- file.exists(context$journal_path)
  if (journal_exists &&
      !v45cv_regular_file(context$journal_path)) {
    v45cv_stop("Validation transaction journal is unsafe.")
  }
  if (!lock_exists && !journal_exists) return(invisible(TRUE))
  if (journal_exists && !lock_exists) {
    v45cv_stop(
      "Owner-bound validation journal exists without its lock."
    )
  }
  owner <- NULL
  owner_path <- file.path(context$lock_path, "owner.tsv")
  owner_sha_before <- NA_character_
  if (lock_exists) {
    if (!v45cv_regular_file(owner_path)) {
      v45cv_stop("Stale validation lock lacks a safe owner record.")
    }
    owner <- v45cv_validate_transaction_owner(
      v45cv_read_tsv(owner_path), context
    )
    owner_sha_before <- v45cv_sha256_file(owner_path)
  }
  journal <- if (journal_exists) {
    v45cv_read_transaction_journal(context, owner)
  } else NULL
  owner_pid <- if (!is.null(owner)) {
    as.integer(owner$pid[[1L]])
  } else {
    as.integer(unique(journal$owner_pid))
  }
  owner_host <- if (!is.null(owner)) {
    as.character(owner$host[[1L]])
  } else {
    as.character(unique(journal$owner_host))
  }
  if (!identical(owner_host, v45cv_transaction_host())) {
    v45cv_stop("Cannot recover a transaction owned by another host.")
  }
  if (v45cv_pid_alive(owner_pid)) {
    v45cv_stop(
      "Another live validator owns the durable transaction journal."
    )
  }
  if (!is.null(journal)) {
    if (identical(unique(journal$phase), "VERIFIED")) {
      v45cv_finalize_verified_transaction(context, owner)
    } else {
      v45cv_rollback_transaction(context, owner)
    }
  }
  if (lock_exists) {
    if (!v45cv_regular_file(owner_path) ||
        !identical(
          v45cv_sha256_file(owner_path), owner_sha_before
        )) {
      v45cv_stop("Stale validation lock owner changed during recovery.")
    }
    unlink(context$lock_path, recursive = TRUE, force = TRUE)
    if (dir.exists(context$lock_path)) {
      v45cv_stop("Could not remove recovered stale validation lock.")
    }
  }
  if (file.exists(context$journal_path)) {
    v45cv_stop("Stale transaction recovery left a journal.")
  }
  invisible(TRUE)
}

v45cv_transaction_fault <- function(fault_injector, phase) {
  if (is.null(fault_injector)) return(invisible(TRUE))
  if (!is.function(fault_injector)) {
    v45cv_stop("Transaction fault injector is not a function.")
  }
  fault_injector(phase)
  invisible(TRUE)
}

v45cv_commit_transaction <- function(
    run_id, assets, state, state_path, current, gate,
    include_manifest = FALSE,
    manifest_path = release_paths$manifest,
    verify_callback,
    transaction_context = v45cv_default_transaction_context(),
    fault_injector = NULL) {
  if (!length(assets) || is.null(names(assets)) ||
      anyDuplicated(names(assets)) ||
      any(names(assets) %in% c(
        "manifest", "module_state", "current_pointer", "gate"
      )) ||
      !is.function(verify_callback)) {
    v45cv_stop("Release transaction assets are invalid.")
  }
  for (path in c(
    transaction_context$public_root,
    transaction_context$qa_root,
    transaction_context$work_root,
    dirname(state_path),
    dirname(transaction_context$current_path),
    dirname(transaction_context$gate_path),
    dirname(manifest_path),
    vapply(assets, function(value) dirname(value$path), character(1))
  )) {
    dir.create(path, recursive = TRUE, showWarnings = FALSE)
  }
  context <- v45cv_validate_transaction_context(
    transaction_context
  )
  state_path <- v45cv_transaction_path(state_path)
  manifest_path <- v45cv_transaction_path(manifest_path)
  if (!v45cv_transaction_destination_allowed(state_path, context) ||
      !v45cv_transaction_destination_allowed(manifest_path, context)) {
    v45cv_stop("Transaction state/manifest path escapes its roots.")
  }
  v45cv_recover_stale_transaction(context)
  transaction_id <- paste0(
    gsub("[^A-Za-z0-9_.-]", "_", run_id),
    "_validation_",
    format(Sys.time(), "%Y%m%dT%H%M%S"),
    "_pid", Sys.getpid(), "_",
    substr(digest::digest(
      list(Sys.time(), proc.time(), tempfile())
    ), 1L, 12L)
  )
  owner_path <- file.path(context$lock_path, "owner.tsv")
  acquiring_lock_path <- paste0(
    context$lock_path, ".", transaction_id, ".acquiring"
  )
  acquiring_owner_path <- file.path(
    acquiring_lock_path, "owner.tsv"
  )
  owner <- NULL
  owner_sha <- NA_character_
  journal_expected <- FALSE
  committed <- FALSE
  cleanup_completed <- FALSE
  lock_owned <- FALSE
  acquiring_lock_owned <- FALSE
  on.exit({
    cleanup_completed <- tryCatch({
      if (!lock_owned) {
        if (acquiring_lock_owned &&
            file.exists(acquiring_lock_path)) {
          unlink(
            acquiring_lock_path, recursive = TRUE, force = TRUE
          )
        }
        if (acquiring_lock_owned &&
            file.exists(acquiring_lock_path)) {
          v45cv_stop(
            "Could not remove provisional validation lock."
          )
        }
      } else {
        if (!dir.exists(context$lock_path) ||
            nzchar(Sys.readlink(context$lock_path))) {
          v45cv_stop(
            "Owned validation transaction lock disappeared or drifted."
          )
        }
        if (journal_expected ||
            file.exists(context$journal_path)) {
          if (!file.exists(context$journal_path)) {
            v45cv_stop(
              "Expected durable transaction journal disappeared."
            )
          }
          if (committed) {
            v45cv_finalize_verified_transaction(context, owner)
          } else {
            v45cv_rollback_transaction(context, owner)
          }
        }
      }
      TRUE
    }, error = function(error) {
      message("VALIDATION TRANSACTION RECOVERY FAILURE: ",
              conditionMessage(error))
      FALSE
    })
    if (cleanup_completed && lock_owned) {
      if (!dir.exists(context$lock_path) ||
          !v45cv_regular_file(owner_path) ||
          !identical(v45cv_sha256_file(owner_path), owner_sha)) {
        cleanup_completed <- FALSE
      } else {
        unlink(context$lock_path, recursive = TRUE, force = TRUE)
        cleanup_completed <- !dir.exists(context$lock_path)
      }
    }
    if (!cleanup_completed) {
      v45cv_stop(
        "Validation transaction did not reach a verified commit ",
        "or a fully verified rollback; journal/lock retained."
      )
    }
  }, add = TRUE)

  if (!dir.create(acquiring_lock_path, showWarnings = FALSE)) {
    v45cv_stop("Could not create a provisional validation lock.")
  }
  acquiring_lock_owned <- TRUE
  v45_charls_outcome_atomic_write_tsv(data.frame(
    transaction_id = transaction_id,
    run_id = run_id, pid = Sys.getpid(),
    host = v45cv_transaction_host(),
    acquired_at_utc =
      format(Sys.time(), "%Y-%m-%dT%H:%M:%SZ", tz = "UTC"),
    journal_path = context$journal_path,
    stringsAsFactors = FALSE
  ), acquiring_owner_path)
  owner <- v45cv_validate_transaction_owner(
    v45cv_read_tsv(acquiring_owner_path), context, transaction_id
  )
  owner_sha <- v45cv_sha256_file(acquiring_owner_path)
  if (file.exists(context$lock_path) ||
      !file.rename(acquiring_lock_path, context$lock_path)) {
    v45cv_stop("Another CHARLS outcome validator holds the release lock.")
  }
  acquiring_lock_owned <- FALSE
  lock_owned <- TRUE
  owner <- v45cv_validate_transaction_owner(
    v45cv_read_tsv(owner_path), context, transaction_id
  )
  if (!identical(v45cv_sha256_file(owner_path), owner_sha)) {
    v45cv_stop("Validation owner changed during atomic lock acquisition.")
  }

  asset_paths <- vapply(
    assets,
    function(value) v45cv_transaction_path(value$path),
    character(1)
  )
  if (any(!vapply(
        asset_paths,
        v45cv_transaction_destination_allowed,
        logical(1), context = context
      ))) {
    v45cv_stop("A release transaction asset escapes its roots.")
  }
  target_ids <- c(
    names(assets),
    if (isTRUE(include_manifest)) "manifest",
    "module_state", "current_pointer", "gate"
  )
  target_kind <- c(
    rep("ASSET", length(assets)),
    if (isTRUE(include_manifest)) "MANIFEST",
    "MODULE_STATE", "CURRENT_POINTER", "GATE"
  )
  destination <- c(
    unname(asset_paths),
    if (isTRUE(include_manifest)) manifest_path,
    state_path, context$current_path, context$gate_path
  )
  if (anyDuplicated(destination)) {
    v45cv_stop("Transaction destinations are not unique.")
  }
  new_target <- target_kind %in% c("ASSET", "MANIFEST")
  for (index in seq_along(destination)) {
    if (new_target[[index]] && file.exists(destination[[index]])) {
      v45cv_stop("Refusing to overwrite existing validation asset: ",
                 destination[[index]])
    }
    if (!new_target[[index]] &&
        !v45cv_regular_file(destination[[index]])) {
      v45cv_stop(
        "Transaction replacement target is absent or unsafe: ",
        destination[[index]]
      )
    }
  }
  stage_path <- vapply(destination, function(final) {
    file.path(
      dirname(final),
      paste0(
        ".", basename(final), ".", transaction_id, ".staging"
      )
    )
  }, character(1))
  had_existing <- ifelse(new_target, "no", "yes")
  original_sha <- vapply(seq_along(destination), function(index) {
    if (had_existing[[index]] == "yes") {
      v45cv_sha256_file(destination[[index]])
    } else "NONE"
  }, character(1))
  backup_path <- vapply(seq_along(destination), function(index) {
    if (had_existing[[index]] == "yes") {
      file.path(
        dirname(destination[[index]]),
        paste0(
          ".", basename(destination[[index]]), ".",
          transaction_id, ".backup"
        )
      )
    } else "NONE"
  }, character(1))
  for (path in c(
    stage_path, backup_path[backup_path != "NONE"]
  )) {
    if (file.exists(path)) {
      v45cv_stop("Transaction staging/backup path already exists.")
    }
  }
  journal <- data.frame(
    journal_version = rep("v45cv_tx_v1", length(target_ids)),
    transaction_id = rep(transaction_id, length(target_ids)),
    run_id = rep(as.character(run_id), length(target_ids)),
    owner_pid = rep(Sys.getpid(), length(target_ids)),
    owner_host = rep(v45cv_transaction_host(), length(target_ids)),
    owner_sha256 = rep(owner_sha, length(target_ids)),
    phase = rep("PLANNED", length(target_ids)),
    updated_at_utc = rep(
      format(Sys.time(), "%Y-%m-%dT%H:%M:%SZ", tz = "UTC"),
      length(target_ids)
    ),
    sequence = seq_along(target_ids),
    target_id = target_ids,
    target_kind = target_kind,
    destination_path = destination,
    stage_path = stage_path,
    expected_sha256 = rep("PENDING", length(target_ids)),
    had_existing = had_existing,
    original_sha256 = original_sha,
    backup_path = backup_path,
    backup_sha256 = ifelse(
      had_existing == "yes", "PENDING", "NONE"
    ),
    stage_ready = rep("no", length(target_ids)),
    backup_ready = rep("no", length(target_ids)),
    promoted = rep("no", length(target_ids)),
    gate_last = ifelse(target_ids == "gate", "yes", "no"),
    verified = rep("no", length(target_ids)),
    stringsAsFactors = FALSE
  )
  journal <- v45cv_write_transaction_journal(
    journal, context, "PLANNED", owner
  )
  journal_expected <- TRUE
  v45cv_transaction_fault(fault_injector, "PLANNED")

  stage_one <- function(target_id, value, type) {
    index <- match(target_id, journal$target_id)
    path <- journal$stage_path[[index]]
    v45cv_stage_write(value, path, type)
    journal$expected_sha256[[index]] <<- v45cv_sha256_file(path)
    journal$stage_ready[[index]] <<- "yes"
    phase <- paste0(
      "STAGED_",
      toupper(gsub("[^A-Za-z0-9]", "_", target_id))
    )
    journal <<- v45cv_write_transaction_journal(
      journal, context, phase, owner
    )
    v45cv_transaction_fault(fault_injector, phase)
    invisible(TRUE)
  }
  for (id in names(assets)) {
    stage_one(id, assets[[id]]$value, assets[[id]]$type)
  }
  stage_one("module_state", state, "tsv")
  state_index <- match("module_state", journal$target_id)
  current$state_sha256 <-
    journal$expected_sha256[[state_index]]
  stage_one("current_pointer", current, "tsv")

  manifest <- NULL
  if (isTRUE(include_manifest)) {
    manifest_source_ids <- c(
      names(assets), "module_state", "current_pointer"
    )
    manifest <- do.call(rbind, lapply(manifest_source_ids, function(id) {
      index <- match(id, journal$target_id)
      stage <- journal$stage_path[[index]]
      final <- journal$destination_path[[index]]
      data.frame(
        asset_id = id,
        path_alias = v45cv_alias(final),
        bytes = as.numeric(file.info(stage)$size),
        sha256 = v45cv_sha256_file(stage),
        access = "PUBLIC_AGGREGATE_NO_ROW_LEVEL",
        stringsAsFactors = FALSE
      )
    }))
    stage_one("manifest", manifest, "tsv")
    manifest_index <- match("manifest", journal$target_id)
    gate$independent_validation$output_manifest_path_alias <-
      v45cv_alias(manifest_path)
    gate$independent_validation$output_manifest_sha256 <-
      journal$expected_sha256[[manifest_index]]
  }
  stage_one("gate", gate, "yaml")
  if (any(journal$stage_ready != "yes") ||
      any(!grepl("^[0-9a-f]{64}$", journal$expected_sha256))) {
    v45cv_stop("Transaction did not stage every destination.")
  }
  journal <- v45cv_write_transaction_journal(
    journal, context, "STAGED", owner
  )
  v45cv_transaction_fault(fault_injector, "STAGED")

  for (index in seq_len(nrow(journal))) {
    id <- journal$target_id[[index]]
    final <- journal$destination_path[[index]]
    stage <- journal$stage_path[[index]]
    expected <- journal$expected_sha256[[index]]
    if (journal$had_existing[[index]] == "yes") {
      backup <- journal$backup_path[[index]]
      if (!file.copy(
            final, backup, overwrite = FALSE,
            copy.mode = TRUE, copy.date = TRUE
          ) ||
          !identical(
            v45cv_transaction_file_sha(backup),
            journal$original_sha256[[index]]
          )) {
        v45cv_stop("Could not create a verified transaction backup: ", id)
      }
      journal$backup_sha256[[index]] <-
        journal$original_sha256[[index]]
      journal$backup_ready[[index]] <- "yes"
      backup_phase <- paste0(
        toupper(gsub("[^A-Za-z0-9]", "_", id)),
        "_BACKUP_READY"
      )
      journal <- v45cv_write_transaction_journal(
        journal, context, backup_phase, owner
      )
      v45cv_transaction_fault(fault_injector, backup_phase)
      v45cv_transaction_remove(final)
    }
    if (!file.rename(stage, final) ||
        !identical(v45cv_transaction_file_sha(final), expected)) {
      v45cv_stop("Could not promote transaction target: ", id)
    }
    journal$stage_ready[[index]] <- "no"
    journal$promoted[[index]] <- "yes"
    phase <- switch(
      id,
      current_pointer = "CURRENT_PROMOTED",
      gate = "GATE_PROMOTED",
      paste0(
        toupper(gsub("[^A-Za-z0-9]", "_", id)),
        "_PROMOTED"
      )
    )
    journal <- v45cv_write_transaction_journal(
      journal, context, phase, owner
    )
    v45cv_transaction_fault(fault_injector, phase)
  }
  if (journal$target_id[[nrow(journal)]] != "gate" ||
      any(journal$promoted != "yes")) {
    v45cv_stop("Transaction did not preserve gate-last promotion.")
  }
  journal <- v45cv_write_transaction_journal(
    journal, context, "VERIFYING", owner
  )
  v45cv_transaction_fault(fault_injector, "VERIFYING")
  verification_error <- NULL
  verification_ok <- tryCatch({
    value <- verify_callback()
    if (!isTRUE(value)) {
      v45cv_stop("Terminal verify callback did not return TRUE.")
    }
    TRUE
  }, error = function(error) {
    verification_error <<- error
    FALSE
  })
  if (!verification_ok) {
    journal <- v45cv_write_transaction_journal(
      journal, context, "VERIFY_FAILED", owner
    )
    v45cv_stop(
      "Transactional terminal verification failed: ",
      conditionMessage(verification_error)
    )
  }
  v45cv_verify_transaction_destinations(journal)
  journal$verified <- "yes"
  journal <- v45cv_write_transaction_journal(
    journal, context, "VERIFIED", owner
  )
  committed <- TRUE
  invisible(manifest)
}

v45cv_main <- function() {
  options(
    survey.lonely.psu = "adjust",
    survey.adjust.domain.lonely = TRUE,
    survey.replicates.mse = TRUE,
    survey.multicore = FALSE
  )
  v45cv_verify_freeze()
  contract <- v45cv_load_contract()
  runner <- v45cv_load_runner_library(contract)
  expected_modules <- runner$v45c_module_rows()
  sealed <- v45cv_load_restricted_modules(
    contract, expected_modules
  )
  restricted <- sealed$restricted
  run_id <- sealed$current$run_id[[1L]]

  recorded_samples <-
    v45cv_validate_recorded_sample_anchors(restricted)
  pairs <- list(
    trial = c("trial-prefix", "trial-full"),
    inconsistency = c(
      "inconsistency-prefix", "inconsistency-full"
    ),
    adjacent = c("adjacent-prefix", "adjacent-full"),
    timehet = c("timehet-prefix", "timehet-full"),
    W2 = c("W2-prefix", "W2-full")
  )
  state_sha <- setNames(
    sealed$state$output_sha256, sealed$state$module
  )
  for (pair_id in names(pairs)) {
    pair <- pairs[[pair_id]]
    prefix <- restricted[[pair[[1L]]]]
    full <- restricted[[pair[[2L]]]]
    expected_mi <- if (pair_id == "W2") "MI-C2" else "MI-C0"
    if (prefix$mi_object != expected_mi ||
        full$mi_object != expected_mi ||
        prefix$requested_m != 50L ||
        full$requested_m != 50L ||
        !identical(prefix$replicate_indices, seq_len(250L)) ||
        !identical(full$replicate_indices, seq_len(500L)) ||
        !identical(
          prefix$executed_in_this_transaction, seq_len(250L)
        ) ||
        !identical(
          full$executed_in_this_transaction, 251:500
        ) ||
        !identical(full$prefix_sha256, state_sha[[pair[[1L]]]]) ||
        !isTRUE(full$literal_prefix_identity) ||
        !prefix$prefix_gate %in% c("GO", "CAUTION") ||
        !full$full_gate %in% c("GO", "CAUTION") ||
        !isTRUE(prefix$coefficient_blind_prefix_gate) ||
        !identical(prefix$prefix_pooling_or_release_performed, FALSE) ||
        !isTRUE(prefix$no_replacement_replicates) ||
        !isTRUE(full$no_replacement_replicates) ||
        prefix$variance_rule != "1/(B_valid-1)" ||
        full$variance_rule != "1/(B_valid-1)") {
      v45cv_stop(pair_id, " prefix/full transaction metadata failed.")
    }
  }

  validated_prefix <- list()
  validated_full <- list()
  for (pair_id in names(pairs)) {
    pair <- pairs[[pair_id]]
    validated_prefix[[pair_id]] <- v45cv_validate_result_set(
      restricted[[pair[[1L]]]], 250L, pair[[1L]],
      recorded_covariance_required = FALSE
    )
    validated_full[[pair_id]] <- v45cv_validate_result_set(
      restricted[[pair[[2L]]]], 500L, pair[[2L]],
      recorded_covariance_required = TRUE
    )
    v45cv_validate_prefix_full(
      restricted[[pair[[1L]]]],
      restricted[[pair[[2L]]]],
      pair_id,
      include_w2_diagnostics = pair_id == "W2"
    )
  }

  pools <- list(
    trial = v45cv_pool_module(
      validated_full$trial, runner$v45c_trial_scalar_map(),
      list(), "CHARLS_trial_summary", "MI-C0"
    ),
    inconsistency = v45cv_pool_module(
      validated_full$inconsistency,
      runner$v45c_inconsistency_scalar_map(),
      runner$v45c_inconsistency_joint_definitions(),
      "CHARLS_within_session_inconsistency", "MI-C0"
    ),
    adjacent = v45cv_pool_module(
      validated_full$adjacent,
      runner$v45c_adjacent_scalar_map(),
      list(), "CHARLS_adjacent_wave", "MI-C0"
    ),
    timehet = v45cv_pool_module(
      validated_full$timehet,
      runner$v45c_timehet_scalar_map(),
      runner$v45c_timehet_joint_definitions(),
      "CHARLS_time_heterogeneity", "MI-C0"
    ),
    W2 = v45cv_pool_module(
      validated_full$W2, runner$v45c_w2_scalar_map(),
      list(), "CHARLS_W2_landmark", "MI-C2"
    )
  )
  scalar <- dplyr::bind_rows(lapply(pools, `[[`, "pooled_scalar"))
  joints <- v45cv_joint_release_table(pools)
  if (nrow(scalar) != 32L || nrow(joints) != 3L ||
      any(!scalar$MCE_trigger) ||
      any(!is.finite(scalar$MCE_fraction))) {
    v45cv_stop("Independent scalar/joint pooling cardinality failed.")
  }

  w2 <- v45cv_validate_w2_diagnostics(
    restricted[["W2-prefix"]], restricted[["W2-full"]],
    validated_full$W2
  )
  w2_overall <- if (
    any(w2$point$status == "CAUTION") ||
    any(w2$replicate$overall_status == "CAUTION") ||
    any(w2$group_fractions$status == "CAUTION")
  ) "CAUTION" else "GO"

  invisible(v45cv_validate_execution_coverage(
    contract, scalar, joints
  ))
  allowed_samples <- c(
    v45cv_expected_sample_anchors()$sample_id,
    "charls_primary_all_vs_adjacent"
  )
  if (!all(contract$model_registry$sample_id %in% allowed_samples)) {
    v45cv_stop("The 28-row registry contains an unknown sample alias.")
  }

  mids_c0 <- runner$v45c_load_mids(root, contract, "MI-C0")
  mids_c2 <- runner$v45c_load_mids(root, contract, "MI-C2")
  context <- runner$v45c_load_context(root, contract)
  independently_recomputed_samples <-
    v45cv_recompute_sample_anchors(
      runner, mids_c0, mids_c2, context
    )
  anchor <- v45cv_recompute_anchor(
    runner, mids_c0, context, restricted[["anchor-point"]]
  )
  rm(mids_c0, mids_c2, context)
  invisible(gc(verbose = FALSE))

  object_gates <- do.call(rbind, lapply(
    c("MI-C0", "MI-C2"), function(object_id) {
      value <- scalar[scalar$mi_object == object_id, , drop = FALSE]
      maximum <- max(value$MCE_fraction)
      data.frame(
        object_id = object_id,
        registered_scalar_n = nrow(value),
        maximum_MCE_fraction = maximum,
        m50_gate = if (
          maximum >= 0.10
        ) "M100_REQUIRED" else "PASS",
        coefficient_release_allowed = maximum < 0.10,
        action_scope = if (object_id == "MI-C0") {
          "ALL_MI_C0_TRIAL_INCONSISTENCY_ADJACENT_TIMEHET"
        } else {
          "ALL_MI_C2_RESPONSE_IPW_AND_W2_OUTCOMES"
        },
        stringsAsFactors = FALSE
      )
    }
  ))
  m100_required <- any(object_gates$m50_gate == "M100_REQUIRED")

  model_diagnostics <- v45cv_model_diagnostics(validated_full)
  checks <- data.frame(
    check_id = v45cv_validation_check_ids(),
    status = c(
      rep("PASS", 14L),
      if (m100_required) "M100_REQUIRED" else "PASS"
    ),
    observed = c(
      "freeze --verify plus specification/code/input manifests",
      "11/11 restricted modules exact SHA-256",
      "none",
      "28|12|75|18",
      paste0(
        length(recorded_samples), " module tables; exact MI 1:50"
      ),
      paste0(
        nrow(independently_recomputed_samples),
        " coefficient-blind sample rows"
      ),
      "trial|inconsistency|adjacent|timehet|W2",
      paste0(nrow(model_diagnostics), " MI-by-group masks"),
      "all full groups independently reconstructed",
      paste0(nrow(scalar), " registered released scalars"),
      paste0(nrow(joints), " joint tests"),
      "all scalar dfcom values exact",
      paste0("overall=", w2_overall),
      paste0(
        "max_beta_diff=",
        format(
          anchor$maximum_absolute_beta_difference,
          digits = 6, scientific = TRUE
        ),
        "; max_Qbar_diff=",
        format(
          max(
            anchor$absolute_v44_v45_Qbar_difference,
            anchor$absolute_v44_public_Qbar_difference,
            anchor$absolute_v45_public_Qbar_difference
          ),
          digits = 6, scientific = TRUE
        )
      ),
      paste(
        object_gates$object_id,
        format(object_gates$maximum_MCE_fraction, digits = 6),
        object_gates$m50_gate,
        collapse = "; "
      )
    ),
    expected = c(
      "all frozen hashes unchanged",
      "exact state/module closure",
      "no forbidden persistence",
      "exact frozen registry cardinalities",
      "every module/sample/imputation exact",
      "seven sample definitions exact in all 50 imputations",
      "first 250 point/replicate/failure values exactly identical",
      "finite intersection mask for every registered group",
      "sum centered crossproducts divided by B_valid-1",
      "mice::pool.scalar with n=dfcom+1 and k=1",
      "common-mask covariance then large-sample Rubin-Wald",
      "actual domain PSU minus one per estimand",
      "frozen GO/CAUTION/STOP rules; no point STOP",
      "all 50 betas and both Qbar comparisons <=1e-8",
      "both MI objects maximum MCE fraction <0.10"
    ),
    stringsAsFactors = FALSE
  )

  now <- format(Sys.time(), "%Y-%m-%dT%H:%M:%SZ", tz = "UTC")
  next_state <- sealed$state
  next_current <- sealed$current
  next_gate <- sealed$gate
  next_gate$updated_at_utc <- now

  if (m100_required) {
    affected <- object_gates$object_id[
      object_gates$m50_gate == "M100_REQUIRED"
    ]
    requirement <- object_gates[
      object_gates$m50_gate == "M100_REQUIRED",
      c(
        "object_id", "registered_scalar_n",
        "maximum_MCE_fraction", "m50_gate", "action_scope"
      ),
      drop = FALSE
    ]
    requirement$required_action <-
      "freeze fresh whole-object m100; rerun all registered scope from R001"
    requirement$selective_extension_allowed <- FALSE
    m100_qa <- c(
      "# CHARLS v45.1 outcome independent validation",
      "",
      paste0("- Restricted run: `", run_id, "`."),
      "- Structural, prefix/full, covariance, pooling, W2, sample, and legacy-anchor checks passed.",
      paste0(
        "- Whole-object m=100 rerun required for: ",
        paste(affected, collapse = ", "), "."
      ),
      "- No coefficient, direction, HR, confidence interval, P value, or joint-test result was released.",
      "- Selective imputation extension or selective model upgrade is forbidden."
    )
    next_state$independent_validation_status <- "M100_REQUIRED"
    next_current$independent_validation_status <- "M100_REQUIRED"
    next_current$coefficient_visibility <- "RESTRICTED"
    next_gate$independent_validation <- list(
      status = "M100_REQUIRED",
      run_id = run_id,
      affected_objects = as.list(affected),
      aggregate_coefficient_release = "BLOCKED",
      m100_requirement_path_alias = v45cv_alias(release_paths$m100)
    )
    next_gate$restricted_outcome_execution_allowed <- "no"
    next_gate$new_coefficient_inspection_allowed <- "no"
    next_gate$response_or_outcome_result_release_allowed <- "no"
    next_gate$m100_freeze_allowed <- "yes"
    next_gate$next_authorized_step <-
      "freeze_fresh_whole_affected_MI_objects_at_m100"
    assets <- list(
      validation = list(
        path = release_paths$m100_validation,
        value = checks, type = "tsv"
      ),
      object_gates = list(
        path = release_paths$m100_object_gates,
        value = object_gates, type = "tsv"
      ),
      m100_requirement = list(
        path = release_paths$m100, value = requirement, type = "tsv"
      ),
      qa = list(
        path = release_paths$m100_qa,
        value = m100_qa, type = "lines"
      )
    )
    v45cv_commit_transaction(
      run_id, assets, next_state, sealed$state_path,
      next_current, next_gate, include_manifest = TRUE,
      manifest_path = release_paths$m100_manifest,
      verify_callback = v45cv_verify_m100_required
    )
    cat("CHARLS V45.1 OUTCOME VALIDATION M100 REQUIRED\n")
    cat("run_id=", run_id, "\n", sep = "")
    cat("affected_objects=", paste(affected, collapse = ","), "\n",
        sep = "")
    cat("aggregate_coefficient_release=BLOCKED\n")
    return(invisible(TRUE))
  }

  public_scalar <- v45cv_public_scalar(
    scalar, contract$model_registry, w2_overall
  )
  public_joints <- v45cv_public_joints(
    joints, contract$model_registry
  )
  qa <- c(
    "# CHARLS v45.1 outcome independent validation",
    "",
    paste0("- Restricted run: `", run_id, "`."),
    "- All 11 restricted modules and the frozen input/code closure matched their SHA-256 bindings.",
    "- Literal R001-R250 prefix identities were exact for all five replicate modules.",
    "- Every common mask, 1/(B_valid-1) covariance, scalar/contrast Rubin result, and multivariate Rubin-Wald test was independently recomputed.",
    "- All seven frozen sample definitions reproduced in every completed imputation.",
    "- The exact v44 and v45 point implementations reproduced each other and the public legacy Qbar within 1e-8.",
    paste0("- W2 response/IPW diagnostic state: **", w2_overall, "**."),
    "- Both MI-C0 and MI-C2 passed the object-wide m=50 MCE <0.10 rule.",
    "- Released files contain aggregate results and coefficient-blind diagnostics only; no completed data, identifiers, fitted objects, probabilities, person weights, or replicate coefficient arrays were exported."
  )
  next_state$independent_validation_status <-
    "INDEPENDENT_VALIDATION_PASS"
  next_current$independent_validation_status <-
    "INDEPENDENT_VALIDATION_PASS"
  next_current$coefficient_visibility <- "AGGREGATE_RELEASED"
  next_gate$independent_validation <- list(
    status = "INDEPENDENT_VALIDATION_PASS",
    run_id = run_id,
    restricted_module_n = 11L,
    registered_model_row_n = 28L,
    released_scalar_n = nrow(public_scalar),
    released_joint_test_n = nrow(public_joints),
    W2_diagnostic_status = w2_overall,
    aggregate_coefficient_release = "AUTHORIZED"
  )
  next_gate$restricted_outcome_execution_allowed <- "no"
  next_gate$new_coefficient_inspection_allowed <- "yes"
  next_gate$response_or_outcome_result_release_allowed <- "yes"
  next_gate$m100_freeze_allowed <- "no"
  next_gate$next_authorized_step <-
    "integrate_validated_CHARLS_v45_1_aggregate_results"
  assets <- list(
    validation = list(
      path = release_paths$validation, value = checks, type = "tsv"
    ),
    object_gates = list(
      path = release_paths$object_gates,
      value = object_gates, type = "tsv"
    ),
    results = list(
      path = release_paths$results,
      value = public_scalar, type = "tsv"
    ),
    joints = list(
      path = release_paths$joints,
      value = public_joints, type = "tsv"
    ),
    model_diagnostics = list(
      path = release_paths$model_diagnostics,
      value = model_diagnostics, type = "tsv"
    ),
    w2_diagnostics = list(
      path = release_paths$w2_diagnostics,
      value = w2$public_summary, type = "tsv"
    ),
    qa = list(path = release_paths$qa, value = qa, type = "lines")
  )
  v45cv_commit_transaction(
    run_id, assets, next_state, sealed$state_path,
    next_current, next_gate, include_manifest = TRUE,
    verify_callback = v45cv_verify_release
  )
  cat("CHARLS V45.1 OUTCOME INDEPENDENT VALIDATION PASS\n")
  cat("run_id=", run_id, "\n", sep = "")
  cat("aggregate_coefficient_release=AUTHORIZED\n")
  cat("W2_diagnostic_status=", w2_overall, "\n", sep = "")
  invisible(TRUE)
}

if (sys.nframe() == 0L) {
  if (mode == "self_test") {
    self_test <- v45cv_self_test()
    cat("CHARLS V45.1 OUTCOME VALIDATOR SELF-TEST PASS\n")
    cat("checks=", nrow(self_test), "\n", sep = "")
    cat("real_response_or_outcome_models_fitted=0\n")
    cat("restricted_or_public_outputs_read=0\n")
    cat("persistent_outputs_written=0\n")
    cat("synthetic_transaction_tempdirs_cleaned=7\n")
  } else if (mode == "verify") {
    if (!v45cv_regular_file(gate_path)) {
      v45cv_stop("CHARLS outcome gate is absent; cannot verify.")
    }
    verify_gate <- v45cv_read_yaml(gate_path)
    verify_status <- as.character(
      verify_gate$independent_validation$status
    )
    if (identical(verify_status, "INDEPENDENT_VALIDATION_PASS")) {
      v45cv_verify_release()
    } else if (identical(verify_status, "M100_REQUIRED")) {
      v45cv_verify_m100_required()
    } else {
      v45cv_stop(
        "No independently verifiable terminal outcome state: ",
        if (length(verify_status)) verify_status else "<missing>"
      )
    }
  } else {
    v45cv_main()
  }
}
