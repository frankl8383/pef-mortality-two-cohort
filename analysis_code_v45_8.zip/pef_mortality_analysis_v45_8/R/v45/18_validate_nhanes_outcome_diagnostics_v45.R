#!/usr/bin/env Rscript

# Independently validate and release aggregate v45 NHANES Stage 4b
# diagnostics. Participant-level data, completed imputations, fitted models,
# and unvalidated diagnostic coefficients are never published.

options(stringsAsFactors = FALSE, warn = 1)

stage4b_root <- function() {
  args <- commandArgs(trailingOnly = FALSE)
  file_arg <- grep("^--file=", args, value = TRUE)
  if (!length(file_arg)) return(normalizePath(getwd(), mustWork = TRUE))
  script <- sub("^--file=", "", file_arg[[1L]])
  normalizePath(file.path(dirname(script), "..", ".."), mustWork = TRUE)
}

root <- stage4b_root()
source(file.path(root, "R", "v45", "01_nhanes_common_utilities_v45.R"))
source(file.path(root, "R", "v45", "11_nhanes_outcome_utilities_v45.R"))
source(file.path(
  root, "R", "v45", "15_nhanes_outcome_diagnostics_utilities_v45.R"
))
v45_require_packages(root)

gate_yes <- function(x) {
  isTRUE(x) ||
    tolower(as.character(x)) %in% c("yes", "true", "1")
}
gate_no <- function(x) {
  identical(x, FALSE) ||
    tolower(as.character(x)) %in% c("no", "false", "0")
}
read_tsv <- function(path) {
  utils::read.delim(
    path, stringsAsFactors = FALSE, check.names = FALSE,
    na.strings = c("", "NA")
  )
}

freeze_script <- file.path(
  root, "R", "v45", "16_freeze_nhanes_outcome_diagnostics_v45.R"
)
freeze_verify <- system2(
  file.path(R.home("bin"), "Rscript"),
  c("--vanilla", freeze_script, "--verify"),
  stdout = TRUE, stderr = TRUE
)
freeze_status <- attr(freeze_verify, "status")
if (!is.null(freeze_status) && freeze_status != 0L) {
  stop(
    "Stage 4b diagnostic freeze verification failed: ",
    paste(freeze_verify, collapse = " | "), call. = FALSE
  )
}

public_root <- file.path(root, "results", "v45", "outcome_diagnostics")
current_path <- file.path(
  public_root, "v45_stage4b_restricted_current.tsv"
)
current_commit_path <- file.path(
  public_root, ".v45_stage4b_current_release_commit.tsv"
)
gate_path <- file.path(root, "work_v45", "gate_state_v45.yml")
manifest_path <- file.path(
  public_root, "v45_stage4b_release_output_manifest.tsv"
)
validation_path <- file.path(
  public_root, "v45_stage4b_independent_validation.tsv"
)
object_gate_path <- file.path(
  public_root, "v45_stage4b_object_gate_summary.tsv"
)
cycle_path <- file.path(
  public_root, "v45_nhanes_leave_one_cycle.tsv"
)
psu_path <- file.path(
  public_root, "v45_nhanes_leave_one_psu.tsv"
)
psu_summary_path <- file.path(
  public_root, "v45_nhanes_psu_influence_summary.tsv"
)
ph_path <- file.path(
  public_root, "v45_nhanes_ph_log_time.tsv"
)
nonestimable_path <- file.path(
  public_root, "v45_nhanes_diagnostic_estimability_summary.tsv"
)
structure_path <- file.path(
  public_root, "v45_nhanes_ph_structural_summary.tsv"
)
m100_path <- file.path(
  public_root, "v45_stage4b_m100_requirement.tsv"
)
qa_path <- file.path(
  root, "output", "qa", "v45",
  "V45_STAGE4B_NHANES_DIAGNOSTICS_INDEPENDENT_VALIDATION_QA.md"
)
release_aliases <- c(
  current =
    "results/v45/outcome_diagnostics/v45_stage4b_restricted_current.tsv",
  validation =
    "results/v45/outcome_diagnostics/v45_stage4b_independent_validation.tsv",
  object_gate =
    "results/v45/outcome_diagnostics/v45_stage4b_object_gate_summary.tsv",
  leave_cycle =
    "results/v45/outcome_diagnostics/v45_nhanes_leave_one_cycle.tsv",
  leave_PSU =
    "results/v45/outcome_diagnostics/v45_nhanes_leave_one_psu.tsv",
  PSU_summary =
    "results/v45/outcome_diagnostics/v45_nhanes_psu_influence_summary.tsv",
  PH = "results/v45/outcome_diagnostics/v45_nhanes_ph_log_time.tsv",
  estimability = paste0(
    "results/v45/outcome_diagnostics/",
    "v45_nhanes_diagnostic_estimability_summary.tsv"
  ),
  PH_structure =
    "results/v45/outcome_diagnostics/v45_nhanes_ph_structural_summary.tsv",
  QA = paste0(
    "output/qa/v45/",
    "V45_STAGE4B_NHANES_DIAGNOSTICS_INDEPENDENT_VALIDATION_QA.md"
  )
)

verify_release_mode <- "--verify" %in% commandArgs(trailingOnly = TRUE)
if (verify_release_mode) {
  if (!file.exists(manifest_path)) {
    stop("Stage 4b release manifest is absent.", call. = FALSE)
  }
  manifest <- read_tsv(manifest_path)
  exact_manifest_contract <-
    nrow(manifest) == length(release_aliases) &&
    identical(
      as.character(manifest$asset_id), names(release_aliases)
    ) &&
    identical(
      as.character(manifest$path_alias),
      unname(release_aliases)
    ) &&
    !anyDuplicated(manifest$asset_id) &&
    !anyDuplicated(manifest$path_alias)
  hashes_ok <- exact_manifest_contract &&
    all(vapply(seq_len(nrow(manifest)), function(i) {
      path <- file.path(root, manifest$path_alias[[i]])
      file.exists(path) && !dir.exists(path) &&
        identical(v45_sha256_file(path), manifest$sha256[[i]]) &&
        identical(
          as.numeric(file.info(path)$size),
          as.numeric(manifest$bytes[[i]])
        )
    }, logical(1)))
  gate <- yaml::read_yaml(gate_path)
  current <- read_tsv(current_path)
  if (
    !hashes_ok ||
    !identical(
      gate$stage4b_nhanes_outcome_diagnostics_execution$status,
      "INDEPENDENT_VALIDATION_PASS"
    ) ||
    !identical(
      gate$stage4b_nhanes_outcome_diagnostics_execution$
        output_manifest_sha256,
      v45_sha256_file(manifest_path)
    ) ||
    !gate_yes(gate$nhanes_diagnostic_aggregate_inspection_allowed) ||
    nrow(current) != 1L ||
    !identical(
      current$independent_validation_status[[1L]], "PASS"
    )
  ) {
    stop("Stage 4b released outputs no longer verify.", call. = FALSE)
  }
  cat("V45_STAGE4B_DIAGNOSTIC_RELEASE_VERIFY_PASS\n")
  quit(save = "no", status = 0L)
}

gate <- yaml::read_yaml(gate_path)
if (
  !identical(
    gate$stage4b_nhanes_outcome_diagnostics_freeze$status, "PASS"
  ) ||
  !identical(
    gate$stage4b_nhanes_outcome_diagnostics_execution$status,
    "RESTRICTED_COMPLETE"
  ) ||
  !gate_no(gate$nhanes_diagnostic_execution_allowed) ||
  !gate_no(gate$nhanes_diagnostic_aggregate_inspection_allowed)
) {
  stop("Stage 4b gates do not authorize independent validation.",
       call. = FALSE)
}
new_public_outputs <- c(
  manifest_path, validation_path, object_gate_path, cycle_path,
  psu_path, psu_summary_path, ph_path, nonestimable_path,
  structure_path, m100_path, qa_path, current_commit_path
)
if (any(file.exists(new_public_outputs))) {
  stop(
    "One or more Stage 4b validation/release outputs already exist; ",
    "refusing to overwrite preserved artifacts.", call. = FALSE
  )
}
if (!file.exists(current_path)) {
  stop("Stage 4b restricted-run pointer is absent.", call. = FALSE)
}
current <- read_tsv(current_path)
if (
  nrow(current) != 1L ||
  !identical(current$coefficient_visibility[[1L]], "RESTRICTED") ||
  !identical(current$independent_validation_status[[1L]], "NOT_RUN")
) {
  stop("Stage 4b restricted-run pointer is invalid.", call. = FALSE)
}
state_path <- file.path(root, current$state_path_alias[[1L]])
restricted_path <- file.path(
  root, current$restricted_output_path_alias[[1L]]
)
if (
  !file.exists(state_path) ||
  !identical(v45_sha256_file(state_path), current$state_sha256[[1L]]) ||
  !file.exists(restricted_path) ||
  !identical(
    v45_sha256_file(restricted_path),
    current$restricted_output_sha256[[1L]]
  )
) {
  stop("Stage 4b restricted state or output hash does not verify.",
       call. = FALSE)
}
state <- read_tsv(state_path)
if (
  nrow(state) != 1L ||
  !identical(state$status[[1L]], "RESTRICTED_COMPLETE") ||
  state$completed_imputations[[1L]] != 50L ||
  !identical(
    state$restricted_output_sha256[[1L]],
    current$restricted_output_sha256[[1L]]
  )
) {
  stop("Stage 4b execution state is incomplete.", call. = FALSE)
}
restricted <- readRDS(restricted_path)
contract <- readRDS(file.path(
  root, "derived_sensitive", "v45",
  "v45_nhanes_outcome_diagnostics_contract.rds"
))

recursive_names <- function(x) {
  out <- names(x)
  if (is.list(x)) {
    out <- c(out, unlist(lapply(x, recursive_names), use.names = FALSE))
  }
  unique(out)
}
forbidden_names <- c(
  "SEQN", "completed", "completed_data", "mids", "fit", "fits",
  "model_object", "participant_id", "person_level_data",
  "row_level_data"
)
no_row_level_or_fit <-
  !any(recursive_names(restricted) %in% forbidden_names) &&
  isFALSE(restricted$completed_dataset_saved) &&
  isFALSE(restricted$fitted_model_object_saved) &&
  isFALSE(restricted$row_level_data_saved) &&
  identical(restricted$coefficient_visibility, "RESTRICTED")
if (!no_row_level_or_fit) {
  stop("Restricted Stage 4b object retained a forbidden object.",
       call. = FALSE)
}

per_influence <- restricted$per_imputation_influence
pooled_influence <- restricted$pooled_influence
per_ph <- restricted$per_imputation_ph
pooled_ph <- restricted$pooled_ph
ph_structure <- restricted$ph_structure
structure_ok <-
  identical(
    restricted$schema_version,
    "v45_0_stage4b_diagnostics_restricted"
  ) &&
  identical(
    restricted$freeze_contract_sha256,
    v45_sha256_file(file.path(
      root, "derived_sensitive", "v45",
      "v45_nhanes_outcome_diagnostics_contract.rds"
    ))
  ) &&
  nrow(per_influence) == 9700L &&
  nrow(pooled_influence) == 194L &&
  nrow(per_ph) == 100L &&
  nrow(pooled_ph) == 2L &&
  nrow(ph_structure) == 100L
if (!structure_ok) {
  stop("Restricted Stage 4b schemas or counts failed.", call. = FALSE)
}

models <- names(contract$models)
expected_cycle_ids <- unlist(lapply(models, function(model_id) {
  paste0(model_id, "_leave_cycle_", contract$cycles)
}), use.names = FALSE)
expected_psu_ids <- unlist(lapply(models, function(model_id) {
  paste0(
    model_id, "_leave_PSU_", contract$design_psu_values
  )
}), use.names = FALSE)
expected_ph_ids <- paste0(models, "_E0_log_time")
cycle_per <- per_influence[
  per_influence$exclusion_type == "cycle", , drop = FALSE
]
psu_per <- per_influence[
  per_influence$exclusion_type == "PSU", , drop = FALSE
]
key_grid_ok <-
  nrow(cycle_per) == 300L &&
  nrow(psu_per) == 9400L &&
  setequal(unique(cycle_per$diagnostic_id), expected_cycle_ids) &&
  setequal(unique(psu_per$diagnostic_id), expected_psu_ids) &&
  setequal(unique(per_ph$diagnostic_id), expected_ph_ids) &&
  all(table(per_influence$diagnostic_id) == 50L) &&
  all(table(per_ph$diagnostic_id) == 50L) &&
  all(vapply(
    split(per_influence$imputation, per_influence$diagnostic_id),
    function(x) identical(sort(as.integer(x)), seq_len(50L)),
    logical(1)
  )) &&
  all(vapply(
    split(per_ph$imputation, per_ph$diagnostic_id),
    function(x) identical(sort(as.integer(x)), seq_len(50L)),
    logical(1)
  ))
if (!key_grid_ok) {
  stop("Stage 4b registered diagnostic grid is incomplete.",
       call. = FALSE)
}

allowed_status <- c("ESTIMABLE", "NOT_ESTIMABLE")
failure_registry_ok <-
  all(per_influence$estimability_status %in% allowed_status) &&
  all(per_ph$estimability_status %in% allowed_status) &&
  !any(c(
    per_influence$failure_class,
    per_ph$failure_class
  ) == "UNEXPECTED_IMPLEMENTATION_ERROR") &&
  all(
    per_influence$estimability_status == "ESTIMABLE" |
      per_influence$failure_class ==
        "NUMERICAL_OR_SUPPORT_FAILURE"
  ) &&
  all(
    per_ph$estimability_status == "ESTIMABLE" |
      per_ph$failure_class == "NUMERICAL_OR_SUPPORT_FAILURE"
  )
if (!failure_registry_ok) {
  stop("Stage 4b failure registry violates the frozen policy.",
       call. = FALSE)
}

cycle_df_expected <- c(E = 33, F = 33, G = 32)
cycle_estimable <- cycle_per$estimability_status == "ESTIMABLE"
psu_estimable <- psu_per$estimability_status == "ESTIMABLE"
ph_estimable <- per_ph$estimability_status == "ESTIMABLE"
design_anchor_ok <-
  all(ph_structure$status == "PASS") &&
  all(ph_structure$n == 6540L) &&
  all(ph_structure$events == 885L) &&
  all(ph_structure$design_strata == 45L) &&
  all(ph_structure$design_psu == 94L) &&
  all(ph_structure$minimum_followup_years == 1 / 12) &&
  all(ph_structure$proxy_columns == ph_structure$proxy_rank) &&
  all(ph_structure$proxy_columns ==
      ph_structure$expected_proxy_columns) &&
  all(
    cycle_per$design_df[cycle_estimable] ==
      unname(cycle_df_expected[
        cycle_per$excluded_unit[cycle_estimable]
      ])
  ) &&
  all(psu_per$design_df[psu_estimable] == 48) &&
  all(per_ph$design_df[ph_estimable] == 49)
if (!design_anchor_ok) {
  stop("Stage 4b design-df or PH structural anchors failed.",
       call. = FALSE)
}

independent_pool <- function(local) {
  local <- local[order(local$imputation), , drop = FALSE]
  valid <- local$estimability_status == "ESTIMABLE" &
    is.finite(local$estimate) &
    is.finite(local$within_variance) &
    local$within_variance > 0
  if (!all(valid)) {
    return(list(
      pool_status = "NOT_ESTIMABLE",
      valid_imputation_n = sum(valid),
      failed_imputation_n = sum(!valid),
      numeric = NULL
    ))
  }
  stable_fields <- c(
    "n", "events", "design_strata", "design_psu", "design_df"
  )
  if (any(vapply(stable_fields, function(field) {
    length(unique(local[[field]])) != 1L ||
      any(!is.finite(local[[field]]))
  }, logical(1)))) {
    stop("A diagnostic key has unstable design anchors.",
         call. = FALSE)
  }
  m <- nrow(local)
  qbar <- mean(local$estimate)
  ubar <- mean(local$within_variance)
  b <- stats::var(local$estimate)
  total <- ubar + (1 + 1 / m) * b
  lambda <- (1 + 1 / m) * b / total
  dfcom <- unique(local$design_df)
  tmp <- (1 - lambda) * (1 + dfcom) * dfcom
  df <- (m - 1) * tmp /
    ((dfcom + 3) * (m - 1) + lambda^2 * tmp)
  r <- (1 + 1 / m) * b / ubar
  fmi <- (r + 2 / (df + 3)) / (r + 1)
  se <- sqrt(total)
  critical <- stats::qt(0.975, df = df)
  statistic <- qbar / se
  p_value <- 2 * stats::pt(
    abs(statistic), df = df, lower.tail = FALSE
  )
  list(
    pool_status = "ESTIMABLE",
    valid_imputation_n = m,
    failed_imputation_n = 0L,
    numeric = c(
      m = m,
      estimate = qbar,
      standard_error = se,
      ci_low = qbar - critical * se,
      ci_high = qbar + critical * se,
      p_value = p_value,
      within_variance = ubar,
      between_variance = b,
      total_variance = total,
      df = df,
      complete_data_design_df = dfcom,
      fraction_missing_information = fmi,
      relative_efficiency = 1 / (1 + fmi / m),
      monte_carlo_error = sqrt(b / m),
      monte_carlo_error_fraction = sqrt(b / m) / se
    )
  )
}

compare_pool <- function(per, pooled, key_fields, label) {
  keys <- unique(per[key_fields])
  rows <- lapply(seq_len(nrow(keys)), function(i) {
    key <- keys[i, , drop = FALSE]
    use <- rep(TRUE, nrow(per))
    pooled_use <- rep(TRUE, nrow(pooled))
    for (field in key_fields) {
      value <- key[[field]][[1L]]
      use <- use & per[[field]] == value
      pooled_use <- pooled_use & pooled[[field]] == value
    }
    if (sum(pooled_use) != 1L) {
      stop(label, " pooled key is absent or duplicated.",
           call. = FALSE)
    }
    local <- per[use, , drop = FALSE]
    independent <- independent_pool(local)
    recorded <- pooled[pooled_use, , drop = FALSE]
    status_ok <-
      identical(
        recorded$pool_status[[1L]], independent$pool_status
      ) &&
      recorded$valid_imputation_n[[1L]] ==
        independent$valid_imputation_n &&
      recorded$failed_imputation_n[[1L]] ==
        independent$failed_imputation_n
    if (independent$pool_status == "ESTIMABLE") {
      fields <- names(independent$numeric)
      difference <- max(abs(
        unname(as.numeric(unlist(
          recorded[1L, fields], use.names = FALSE
        ))) -
          unname(independent$numeric)
      ))
      numeric_ok <- is.finite(difference) && difference <= 1e-10
    } else {
      fields <- c(
        "estimate", "standard_error", "ci_low", "ci_high",
        "p_value", "within_variance", "between_variance",
        "total_variance", "df", "fraction_missing_information",
        "relative_efficiency", "monte_carlo_error",
        "monte_carlo_error_fraction"
      )
      difference <- 0
      numeric_ok <- all(is.na(recorded[1L, fields]))
    }
    data.frame(
      diagnostic_id = key$diagnostic_id,
      maximum_absolute_difference = difference,
      status = if (status_ok && numeric_ok) "PASS" else "FAIL",
      stringsAsFactors = FALSE
    )
  })
  dplyr::bind_rows(rows)
}

influence_keys <- c(
  "diagnostic_id", "model_id", "exclusion_type",
  "excluded_unit", "term"
)
ph_keys <- c("diagnostic_id", "model_id", "term")
influence_pool_check <- compare_pool(
  per_influence, pooled_influence, influence_keys, "influence"
)
ph_pool_check <- compare_pool(per_ph, pooled_ph, ph_keys, "PH")
if (
  any(influence_pool_check$status != "PASS") ||
  any(ph_pool_check$status != "PASS")
) {
  stop("Independent Stage 4b Rubin pooling differs.",
       call. = FALSE)
}

released <- read_tsv(file.path(
  root, "results", "v45", "outcome_execution",
  "v45_nhanes_standard_pooled.tsv"
))
reference_check <- dplyr::bind_rows(lapply(models, function(model_id) {
  reference <- released[
    released$analysis_id == model_id & released$term == "E0",
    ,
    drop = FALSE
  ]
  local <- pooled_influence[
    pooled_influence$model_id == model_id, , drop = FALSE
  ]
  if (nrow(reference) != 1L || !nrow(local)) {
    stop("A full-model influence reference is absent.", call. = FALSE)
  }
  estimable <- local$pool_status == "ESTIMABLE"
  expected_delta <- local$estimate - reference$estimate[[1L]]
  expected_sign <- sign(local$estimate) !=
    sign(reference$estimate[[1L]])
  difference <- max(c(
    abs(
      local$reference_estimate -
        reference$estimate[[1L]]
    ),
    abs(local$delta_beta[estimable] - expected_delta[estimable]),
    abs(
      local$hazard_ratio[estimable] -
        exp(local$estimate[estimable])
    )
  ), na.rm = TRUE)
  sign_ok <- all(
    local$sign_reversal[estimable] == expected_sign[estimable]
  ) && all(is.na(local$sign_reversal[!estimable]))
  data.frame(
    model_id = model_id,
    maximum_absolute_difference = difference,
    sign_rule_exact = sign_ok,
    status = if (
      is.finite(difference) && difference <= 1e-12 && sign_ok
    ) "PASS" else "FAIL",
    stringsAsFactors = FALSE
  )
}))
if (any(reference_check$status != "PASS")) {
  stop("Influence reference/delta/sign validation failed.",
       call. = FALSE)
}

estimable_mce <- c(
  pooled_influence$monte_carlo_error_fraction[
    pooled_influence$pool_status == "ESTIMABLE"
  ],
  pooled_ph$monte_carlo_error_fraction[
    pooled_ph$pool_status == "ESTIMABLE"
  ]
)
safe_max <- function(x) {
  x <- as.numeric(x)
  x <- x[is.finite(x)]
  if (length(x)) max(x) else NA_real_
}
m100_required <- any(!is.finite(estimable_mce)) ||
  any(estimable_mce >= 0.10)
object_gate <- data.frame(
  module = c("influence", "PH", "MI-G_overall"),
  registered_pooled_rows = c(
    nrow(pooled_influence), nrow(pooled_ph),
    nrow(pooled_influence) + nrow(pooled_ph)
  ),
  not_estimable_rows = c(
    sum(pooled_influence$pool_status == "NOT_ESTIMABLE"),
    sum(pooled_ph$pool_status == "NOT_ESTIMABLE"),
    sum(pooled_influence$pool_status == "NOT_ESTIMABLE") +
      sum(pooled_ph$pool_status == "NOT_ESTIMABLE")
  ),
  maximum_monte_carlo_error_fraction = c(
    safe_max(
      pooled_influence$monte_carlo_error_fraction[
        pooled_influence$pool_status == "ESTIMABLE"
      ]
    ),
    safe_max(
      pooled_ph$monte_carlo_error_fraction[
        pooled_ph$pool_status == "ESTIMABLE"
      ]
    ),
    safe_max(estimable_mce)
  ),
  m50_gate = if (m100_required) "M100_REQUIRED" else "PASS",
  stringsAsFactors = FALSE
)
v45_atomic_write_tsv(object_gate, object_gate_path)

checks <- data.frame(
  check = c(
    "restricted_hash_and_schema",
    "no_row_level_or_fit_object_retained",
    "registered_key_grid_complete",
    "failure_registry_policy",
    "PH_and_design_df_structural_anchors",
    "influence_independent_Rubin_pooling",
    "PH_independent_Rubin_pooling",
    "full_model_reference_delta_and_sign_rules",
    "m50_Monte_Carlo_error_gate",
    "reused_anchor_A1_PH_hash_bound"
  ),
  status = c(
    if (structure_ok) "PASS" else "FAIL",
    if (no_row_level_or_fit) "PASS" else "FAIL",
    if (key_grid_ok) "PASS" else "FAIL",
    if (failure_registry_ok) "PASS" else "FAIL",
    if (design_anchor_ok) "PASS" else "FAIL",
    if (
      all(influence_pool_check$status == "PASS")
    ) "PASS" else "FAIL",
    if (all(ph_pool_check$status == "PASS")) "PASS" else "FAIL",
    if (all(reference_check$status == "PASS")) "PASS" else "FAIL",
    if (m100_required) "M100_REQUIRED" else "PASS",
    if (
      nrow(contract$reused_anchor_ph) == 1L &&
      identical(
        contract$reused_anchor_ph$test_id[[1L]],
        "v43_s3_nhanes_pn_e0_a1_log_time_supportive"
      )
    ) "PASS" else "FAIL"
  ),
  observed = c(
    "9700/194 influence; 100/2 new PH; exact restricted SHA",
    as.character(no_row_level_or_fit),
    "194 influence keys and 2 PH keys, each with 50 attempts",
    paste0(
      "NOT_ESTIMABLE pooled rows=",
      sum(c(
        pooled_influence$pool_status,
        pooled_ph$pool_status
      ) == "NOT_ESTIMABLE")
    ),
    "cycle df 33/33/32; PSU df 48; PH df 49; 100/100 structure PASS",
    paste0(
      "max difference=",
      max(influence_pool_check$maximum_absolute_difference)
    ),
    paste0(
      "max difference=",
      max(ph_pool_check$maximum_absolute_difference)
    ),
    paste0(
      "max difference=",
      max(reference_check$maximum_absolute_difference)
    ),
    paste0(
      "max MCE/SE=", safe_max(estimable_mce)
    ),
    contract$reused_anchor_ph$test_id[[1L]]
  ),
  expected = c(
    "exact restricted hash and registered schema",
    "no participant rows, completed data, mids, or fit objects",
    "all registered keys attempted in all 50 imputations",
    "no unexpected implementation error; true failures retained",
    "exact frozen structural values",
    "maximum absolute difference <=1e-10",
    "maximum absolute difference <=1e-10",
    "maximum absolute difference <=1e-12 and exact sign rule",
    "all estimable registered rows below 0.10",
    "exact hash-bound v43 supportive anchor row"
  ),
  stringsAsFactors = FALSE
)
v45_atomic_write_tsv(checks, validation_path)

if (m100_required) {
  requirement <- data.frame(
    object_id = "MI-G",
    maximum_monte_carlo_error_fraction =
      safe_max(estimable_mce),
    required_action = paste(
      "separately freeze and rerun the complete MI-G Stage 4 plus",
      "Stage 4b registered model set at m=100"
    ),
    selective_extension_forbidden = TRUE,
    stringsAsFactors = FALSE
  )
  v45_atomic_write_tsv(requirement, m100_path)
  qa <- c(
    "# V45 Stage 4b NHANES diagnostic validation",
    "",
    "- Restricted execution, registered-key completeness, and independent pooling checks passed.",
    "- At least one estimable registered diagnostic did not pass the frozen m=50 Monte Carlo-error gate.",
    "- No new diagnostic coefficient, interaction ratio, direction, confidence interval, or P value was released.",
    "- The entire MI-G Stage 4 plus Stage 4b registered model set requires a separately frozen m=100 rerun."
  )
  v45_atomic_write_lines(qa, qa_path)
  gate$updated_at <- format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")
  gate$stage4b_nhanes_outcome_diagnostics_execution <- list(
    status = "M100_REQUIRED",
    run_id = restricted$run_id,
    aggregate_release = "BLOCKED"
  )
  gate$nhanes_diagnostic_aggregate_inspection_allowed <- "no"
  gate$next_authorized_step <-
    "freeze_complete_MI_G_Stage4_and_Stage4b_m100"
  v45_atomic_write_yaml(gate, gate_path)
  cat("V45_STAGE4B_M100_REQUIRED\n")
  cat("aggregate_inspection=BLOCKED\n")
  quit(save = "no", status = 0L)
}

cycle_release <- pooled_influence[
  pooled_influence$exclusion_type == "cycle", , drop = FALSE
]
cycle_release$excluded_unit <- factor(
  cycle_release$excluded_unit, levels = contract$cycles
)
cycle_release <- cycle_release[
  order(cycle_release$model_id, cycle_release$excluded_unit),
  ,
  drop = FALSE
]
cycle_release$excluded_unit <- as.character(cycle_release$excluded_unit)
psu_release <- pooled_influence[
  pooled_influence$exclusion_type == "PSU", , drop = FALSE
]
psu_release$psu_order <- match(
  psu_release$excluded_unit, contract$design_psu_values
)
psu_release <- psu_release[
  order(psu_release$model_id, psu_release$psu_order),
  ,
  drop = FALSE
]
psu_release$psu_order <- NULL

psu_summary <- dplyr::bind_rows(lapply(models, function(model_id) {
  local <- psu_release[
    psu_release$model_id == model_id, , drop = FALSE
  ]
  all_estimable <- nrow(local) == 94L &&
    all(local$pool_status == "ESTIMABLE")
  per_local <- psu_per[psu_per$model_id == model_id, , drop = FALSE]
  if (all_estimable) {
    quantiles <- stats::quantile(
      local$estimate, probs = c(0.05, 0.50, 0.95),
      type = 7, names = FALSE
    )
    values <- c(
      minimum_beta = min(local$estimate),
      q05_beta = quantiles[[1L]],
      median_beta = quantiles[[2L]],
      q95_beta = quantiles[[3L]],
      maximum_beta = max(local$estimate),
      maximum_absolute_delta_beta = max(abs(local$delta_beta))
    )
  } else {
    values <- rep(NA_real_, 6L)
    names(values) <- c(
      "minimum_beta", "q05_beta", "median_beta", "q95_beta",
      "maximum_beta", "maximum_absolute_delta_beta"
    )
  }
  data.frame(
    model_id = model_id,
    registered_PSU_deletions = nrow(local),
    estimable_PSU_deletions =
      sum(local$pool_status == "ESTIMABLE"),
    reference_estimate = unique(local$reference_estimate),
    reference_hazard_ratio = unique(local$reference_hazard_ratio),
    minimum_beta = values[["minimum_beta"]],
    q05_beta = values[["q05_beta"]],
    median_beta = values[["median_beta"]],
    q95_beta = values[["q95_beta"]],
    maximum_beta = values[["maximum_beta"]],
    maximum_absolute_delta_beta =
      values[["maximum_absolute_delta_beta"]],
    sign_reversal_deletion_n = sum(
      local$sign_reversal %in% TRUE
    ),
    warning_fit_n = sum(nzchar(per_local$warnings)),
    unique_warning_message_n = length(unique(
      per_local$warnings[nzchar(per_local$warnings)]
    )),
    summary_status = if (
      all_estimable
    ) "PASS" else "NOT_FULLY_ESTIMABLE",
    quantile_definition = "R_type_7_on_94_pooled_beta_values",
    stringsAsFactors = FALSE
  )
}))

anchor <- contract$reused_anchor_ph
anchor_release <- data.frame(
  diagnostic_id = "v45_anchor_nhanes_a1_E0_log_time",
  model_id = "v45_anchor_nhanes_a1",
  source = "v43_exact_reuse_no_refit",
  term = "tt(E0)",
  m = anchor$m,
  estimate = anchor$estimate,
  standard_error = anchor$standard_error,
  ci_low = anchor$ci_low,
  ci_high = anchor$ci_high,
  p_value = anchor$p_value,
  df = anchor$df,
  monte_carlo_error_fraction = NA_real_,
  pool_status = "ESTIMABLE",
  gate_status = "PASS",
  time_interaction_ratio = anchor$exp_estimate,
  time_interaction_ratio_ci_low = anchor$exp_ci_low,
  time_interaction_ratio_ci_high = anchor$exp_ci_high,
  diagnostic_role = anchor$diagnostic_role,
  main_E0_reference_time_years = 1,
  exponentiated_effect_interpretation = paste(
    "multiplicative change in the E0 hazard ratio per one-unit",
    "increase in log(time); not an ordinary hazard ratio"
  ),
  stringsAsFactors = FALSE
)
new_ph_release <- data.frame(
  diagnostic_id = pooled_ph$diagnostic_id,
  model_id = pooled_ph$model_id,
  source = "v45_stage4b_new",
  term = pooled_ph$term,
  m = pooled_ph$m,
  estimate = pooled_ph$estimate,
  standard_error = pooled_ph$standard_error,
  ci_low = pooled_ph$ci_low,
  ci_high = pooled_ph$ci_high,
  p_value = pooled_ph$p_value,
  df = pooled_ph$df,
  monte_carlo_error_fraction =
    pooled_ph$monte_carlo_error_fraction,
  pool_status = pooled_ph$pool_status,
  gate_status = pooled_ph$gate_status,
  time_interaction_ratio = pooled_ph$time_interaction_ratio,
  time_interaction_ratio_ci_low =
    pooled_ph$time_interaction_ratio_ci_low,
  time_interaction_ratio_ci_high =
    pooled_ph$time_interaction_ratio_ci_high,
  diagnostic_role = "SUPPORTIVE_LOG_LINEAR_TIME_TREND",
  main_E0_reference_time_years = 1,
  exponentiated_effect_interpretation = paste(
    "multiplicative change in the E0 hazard ratio per one-unit",
    "increase in log(time); not an ordinary hazard ratio"
  ),
  stringsAsFactors = FALSE
)
ph_release <- dplyr::bind_rows(anchor_release, new_ph_release)

estimability_summary <- dplyr::bind_rows(
  lapply(
    list(influence = per_influence, PH = per_ph),
    function(data) {
      groups <- unique(data[c("model_id")])
      dplyr::bind_rows(lapply(seq_len(nrow(groups)), function(i) {
        model_id <- groups$model_id[[i]]
        local <- data[data$model_id == model_id, , drop = FALSE]
        data.frame(
          model_id = model_id,
          attempted_fit_rows = nrow(local),
          estimable_fit_rows = sum(
            local$estimability_status == "ESTIMABLE"
          ),
          numerical_or_support_failure_rows = sum(
            local$failure_class == "NUMERICAL_OR_SUPPORT_FAILURE"
          ),
          unique_failure_reason_n = length(unique(
            local$failure_reason[nzchar(local$failure_reason)]
          )),
          stringsAsFactors = FALSE
        )
      }))
    }
  ),
  .id = "module"
)
structure_summary <- dplyr::bind_rows(lapply(
  split(ph_structure, ph_structure$model_id), function(data) {
    data.frame(
      model_id = data$model_id[[1L]],
      imputations = length(unique(data$imputation)),
      n = unique(data$n),
      events = unique(data$events),
      minimum_followup_years = unique(data$minimum_followup_years),
      design_strata = unique(data$design_strata),
      design_psu = unique(data$design_psu),
      proxy_columns = unique(data$proxy_columns),
      proxy_rank = unique(data$proxy_rank),
      status = if (all(data$status == "PASS")) "PASS" else "FAIL",
      stringsAsFactors = FALSE
    )
  }
))

v45_atomic_write_tsv(cycle_release, cycle_path)
v45_atomic_write_tsv(psu_release, psu_path)
v45_atomic_write_tsv(psu_summary, psu_summary_path)
v45_atomic_write_tsv(ph_release, ph_path)
v45_atomic_write_tsv(estimability_summary, nonestimable_path)
v45_atomic_write_tsv(structure_summary, structure_path)

qa <- c(
  "# V45 Stage 4b NHANES diagnostics: independent validation",
  "",
  "- The frozen restricted run attempted all 9,800 registered fits.",
  "- The exact 194 influence keys and two newly fitted PH keys were each attempted in all 50 imputations.",
  "- Independent Rubin recomputation, full-model reference comparisons, sign rules, design degrees of freedom, PH structure, warning policy, and m=50 Monte Carlo-error gates passed.",
  "- The existing v43 anchor-A1 supportive log-time result was hash-bound and reused without refitting; G1 and G6a were newly fitted under the frozen Stage 4b contract.",
  "- Only aggregate diagnostic tables were released. No completed imputation, fitted model, participant identifier, or participant-level row was saved."
)
v45_atomic_write_lines(qa, qa_path)

final_current <- current
final_current$independent_validation_status <- "PASS"
final_current$coefficient_visibility <- "AGGREGATE_RELEASED"
v45_atomic_write_tsv(final_current, current_commit_path)

manifest <- dplyr::bind_rows(lapply(names(release_aliases), function(id) {
  alias <- release_aliases[[id]]
  path <- if (identical(id, "current")) {
    current_commit_path
  } else {
    file.path(root, alias)
  }
  data.frame(
    asset_id = id,
    path_alias = alias,
    bytes = as.numeric(file.info(path)$size),
    sha256 = v45_sha256_file(path),
    local_restricted = FALSE,
    stringsAsFactors = FALSE
  )
}))
v45_atomic_write_tsv(manifest, manifest_path)

gate <- yaml::read_yaml(gate_path)
gate$updated_at <- format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")
gate$stage4b_nhanes_outcome_diagnostics_execution <- list(
  status = "INDEPENDENT_VALIDATION_PASS",
  run_id = restricted$run_id,
  attempted_refits = 9800L,
  released_influence_rows = nrow(pooled_influence),
  released_PH_rows = nrow(ph_release),
  output_manifest_sha256 = v45_sha256_file(manifest_path)
)
gate$nhanes_diagnostic_execution_allowed <- "no"
gate$nhanes_diagnostic_aggregate_inspection_allowed <- "yes"
gate$next_authorized_step <- "run_CHARLS_production_MI_and_outcomes"
v45_atomic_write_yaml(gate, gate_path)
v45_atomic_write_tsv(final_current, current_path)
if (!identical(
  v45_sha256_file(current_path),
  manifest$sha256[manifest$asset_id == "current"]
)) {
  stop("Final Stage 4b current-pointer commit hash differs.",
       call. = FALSE)
}
cat("V45_STAGE4B_DIAGNOSTIC_INDEPENDENT_VALIDATION_PASS\n")
cat("run_id=", restricted$run_id, "\n", sep = "")
cat("aggregate_inspection=ALLOWED\n")
