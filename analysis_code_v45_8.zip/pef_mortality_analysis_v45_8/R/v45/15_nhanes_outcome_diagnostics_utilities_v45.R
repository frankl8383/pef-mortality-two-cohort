# Pure utilities for prespecified v45 NHANES influence and time diagnostics.

options(stringsAsFactors = FALSE)

v45_diag_models <- function() {
  list(
    v45_g1 = "E0",
    v45_g6a = c("E0", "L_FEV1", "L_RATIO")
  )
}

v45_diag_fatal_warning_patterns <- function() {
  c(
    "did not converge",
    "failed to converge",
    "algorithm did not converge",
    "infinite coefficient",
    "coefficient may be infinite",
    "singular",
    "computationally singular",
    "rank-deficient",
    "separation",
    "fitted probabilities numerically 0 or 1 occurred",
    "non-finite",
    "NA/NaN/Inf",
    "system is exactly singular",
    "logged event"
  )
}

v45_diag_assert_no_fatal_warning <- function(
    warnings, model_id,
    patterns = v45_diag_fatal_warning_patterns()) {
  warning_values <- unique(trimws(as.character(warnings)))
  warning_values <- warning_values[
    !is.na(warning_values) & nzchar(warning_values)
  ]
  fatal <- if (!length(warning_values)) {
    logical()
  } else {
    vapply(warning_values, function(value) {
      any(vapply(
        tolower(patterns), grepl, logical(1), x = tolower(value),
        fixed = TRUE
      ))
    }, logical(1))
  }
  if (any(fatal)) {
    stop(
      model_id, " produced a frozen fatal warning: ",
      paste(warning_values[fatal], collapse = "; "), call. = FALSE
    )
  }
  invisible(warning_values)
}

v45_diag_failure_class <- function(message) {
  value <- trimws(as.character(message))
  registered_patterns <- c(
    v45_diag_fatal_warning_patterns(),
    "invalid survey domain",
    "rank-deficient design matrix",
    "failed convergence/finite-covariance validation",
    "lacks E0",
    "lacks one tt(E0) term",
    "not enough",
    "zero events",
    "zero non-events",
    "infinite or missing values",
    "NA/NaN/Inf in foreign function call",
    "only one PSU",
    "lonely PSU"
  )
  registered <- any(vapply(
    tolower(registered_patterns), grepl, logical(1),
    x = tolower(value), fixed = TRUE
  ))
  if (registered) {
    "NUMERICAL_OR_SUPPORT_FAILURE"
  } else {
    "UNEXPECTED_IMPLEMENTATION_ERROR"
  }
}

v45_diag_safe_row <- function(fit_function, template) {
  out <- tryCatch(
    fit_function(),
    error = function(e) {
      template$estimability_status <- "NOT_ESTIMABLE"
      template$failure_class <- v45_diag_failure_class(
        conditionMessage(e)
      )
      template$failure_reason <- conditionMessage(e)
      template
    }
  )
  if (!is.data.frame(out) || nrow(out) != 1L) {
    stop(
      "A diagnostic fit did not return exactly one registry row.",
      call. = FALSE
    )
  }
  out
}

v45_diag_ph_formula <- function(model_id) {
  exposures <- v45_diag_models()[[model_id]]
  if (is.null(exposures)) {
    stop("Unknown diagnostic model: ", model_id, call. = FALSE)
  }
  a1 <- setdiff(v45_outcome_a1_terms(), "factor(cycle_label)")
  rhs <- c(
    exposures, "tt(E0)", a1,
    "survival::strata(design_strata)",
    "survival::cluster(design_psu)"
  )
  stats::as.formula(paste(
    "survival::Surv(followup_years, death) ~",
    paste(rhs, collapse = " + ")
  ))
}

v45_diag_ph_structural_check <- function(completed) {
  strata_cycle_n <- tapply(
    as.character(completed$cycle_label),
    as.character(completed$design_strata),
    function(x) length(unique(x))
  )
  expected_columns <- c(v45_g1 = 23L, v45_g6a = 25L)
  dplyr::bind_rows(lapply(names(v45_diag_models()), function(model_id) {
    formula <- v45_diag_ph_formula(model_id)
    terms_object <- stats::terms(
      formula, specials = c("tt", "strata", "cluster")
    )
    labels <- attr(terms_object, "term.labels")
    keep <- !grepl("tt\\(|strata\\(|cluster\\(", labels)
    proxy <- stats::as.formula(paste(
      "survival::Surv(followup_years, death) ~",
      paste(labels[keep], collapse = " + ")
    ))
    matrix <- stats::model.matrix(
      stats::delete.response(stats::terms(proxy)), data = completed
    )
    checks <- c(
      n = nrow(completed) == 6540L,
      events = sum(as.integer(completed$death) == 1L) == 885L,
      finite_positive_time = all(
        is.finite(completed$followup_years) &
          completed$followup_years >= 1 / 12
      ),
      exact_time_origin = isTRUE(all.equal(
        min(completed$followup_years), 1 / 12,
        tolerance = 1e-12, check.attributes = FALSE
      )),
      strata_are_cycle_specific = length(strata_cycle_n) == 45L &&
        max(strata_cycle_n) == 1L,
      design_psu = length(unique(completed$design_psu)) == 94L,
      proxy_columns = ncol(matrix) == expected_columns[[model_id]],
      proxy_full_rank = qr(matrix)$rank == ncol(matrix)
    )
    data.frame(
      model_id = model_id,
      n = nrow(completed),
      events = sum(as.integer(completed$death) == 1L),
      minimum_followup_years = min(completed$followup_years),
      design_strata = length(strata_cycle_n),
      maximum_cycles_per_stratum = max(strata_cycle_n),
      design_psu = length(unique(completed$design_psu)),
      proxy_columns = ncol(matrix),
      proxy_rank = qr(matrix)$rank,
      expected_proxy_columns = expected_columns[[model_id]],
      status = if (all(checks)) "PASS" else "FAIL",
      failed_checks = paste(names(checks)[!checks], collapse = ";"),
      stringsAsFactors = FALSE
    )
  }))
}

v45_diag_fit_ph_one <- function(completed, model_id, imputation) {
  formula <- v45_diag_ph_formula(model_id)
  required <- unique(all.vars(formula))
  if (
    nrow(completed) != 6540L ||
    sum(as.integer(completed$death) == 1L) != 885L ||
    any(!stats::complete.cases(completed[required])) ||
    any(!is.finite(completed$followup_years) |
        completed$followup_years < 1 / 12) ||
    any(!is.finite(completed$wtmec6yr) | completed$wtmec6yr <= 0) ||
    length(unique(completed$design_strata)) != 45L ||
    length(unique(completed$design_psu)) != 94L
  ) {
    stop(model_id, " PH diagnostic input contract failed.",
         call. = FALSE)
  }
  completed$.v45_analysis_weight <-
    as.numeric(completed$wtmec6yr) /
    mean(as.numeric(completed$wtmec6yr))
  captured <- v45_capture_model(
    survival::coxph(
      formula,
      data = completed,
      weights = .v45_analysis_weight,
      robust = TRUE,
      tt = function(x, t, ...) x * log(pmax(t, 1 / 12)),
      ties = "efron",
      na.action = stats::na.fail,
      singular.ok = FALSE,
      model = FALSE, x = FALSE, y = FALSE
    )
  )
  if (inherits(captured$value, "v45_model_error")) {
    stop(
      model_id, " PH diagnostic failed in imputation ", imputation,
      ": ", captured$value$error, call. = FALSE
    )
  }
  v45_diag_assert_no_fatal_warning(
    captured$warnings, paste0(model_id, "_ph_imp", imputation)
  )
  if (
    !identical(as.integer(captured$value$n), 6540L) ||
    !identical(as.integer(captured$value$nevent), 885L)
  ) {
    stop(model_id, " PH diagnostic silently changed n/events.",
         call. = FALSE)
  }
  checked <- v45_validate_cox_compact(
    captured$value, captured$warnings,
    paste0(model_id, "_ph_imp", imputation)
  )
  term <- grep("^tt\\(E0\\)$", names(checked$coefficients), value = TRUE)
  if (length(term) != 1L) {
    stop(model_id, " PH diagnostic lacks one tt(E0) term.",
         call. = FALSE)
  }
  data.frame(
    diagnostic_id = paste0(model_id, "_E0_log_time"),
    model_id = model_id,
    imputation = as.integer(imputation),
    term = term,
    estimate = unname(checked$coefficients[[term]]),
    within_variance = unname(checked$variance[term, term]),
    design_df = 49,
    n = nrow(completed),
    events = sum(as.integer(completed$death) == 1L),
    design_strata = length(unique(completed$design_strata)),
    design_psu = length(unique(completed$design_psu)),
    warnings = checked$warnings,
    estimability_status = "ESTIMABLE",
    failure_class = "",
    failure_reason = "",
    stringsAsFactors = FALSE
  )
}

v45_diag_fit_taylor_prebuilt <- function(
    merged, full_design, domain_index, formula, model_id) {
  domain_index <- as.logical(domain_index)
  if (
    length(domain_index) != nrow(merged) ||
    anyNA(domain_index) ||
    sum(domain_index) < 100L
  ) {
    stop(model_id, " received an invalid survey domain.", call. = FALSE)
  }
  domain <- droplevels(merged[domain_index, , drop = FALSE])
  matrix <- stats::model.matrix(
    stats::delete.response(stats::terms(formula)), data = domain
  )
  if (qr(matrix)$rank != ncol(matrix)) {
    stop(model_id, " has a rank-deficient design matrix.", call. = FALSE)
  }
  domain_design <- full_design[domain_index, ]
  domain_design$variables <- droplevels(domain_design$variables)
  captured <- v45_capture_model(
    survey::svycoxph(formula, design = domain_design)
  )
  if (inherits(captured$value, "v45_model_error")) {
    stop(model_id, " failed: ", captured$value$error, call. = FALSE)
  }
  v45_diag_assert_no_fatal_warning(captured$warnings, model_id)
  checked <- v45_validate_cox_compact(
    captured$value, captured$warnings, model_id
  )
  list(
    coefficients = checked$coefficients,
    variance = checked$variance,
    diagnostics = data.frame(
      model_id = model_id,
      n = nrow(domain),
      events = sum(as.integer(domain$death) == 1L),
      person_years = sum(as.numeric(domain$followup_years)),
      design_strata = length(unique(domain$design_strata)),
      design_psu = length(unique(domain$design_psu)),
      design_df = survey::degf(domain_design),
      matrix_columns = ncol(matrix),
      matrix_rank = qr(matrix)$rank,
      warnings = checked$warnings,
      stringsAsFactors = FALSE
    )
  )
}

v45_diag_fit_influence_one <- function(
    merged, full_design, domain_index, model_id, exclusion_type,
    excluded_unit, imputation) {
  exposures <- v45_diag_models()[[model_id]]
  fit <- v45_diag_fit_taylor_prebuilt(
    merged = merged,
    full_design = full_design,
    domain_index = domain_index,
    formula = v45_outcome_formula(exposures, "A1"),
    model_id = paste0(
      model_id, "_leave_", exclusion_type, "_",
      gsub("[^A-Za-z0-9]+", "_", excluded_unit),
      "_imp", imputation
    )
  )
  if (!"E0" %in% names(fit$coefficients)) {
    stop(model_id, " influence fit lacks E0.", call. = FALSE)
  }
  data.frame(
    diagnostic_id = paste0(
      model_id, "_leave_", exclusion_type, "_", excluded_unit
    ),
    model_id = model_id,
    exclusion_type = exclusion_type,
    excluded_unit = as.character(excluded_unit),
    imputation = as.integer(imputation),
    term = "E0",
    estimate = unname(fit$coefficients[["E0"]]),
    within_variance = unname(fit$variance["E0", "E0"]),
    design_df = as.numeric(fit$diagnostics$design_df[[1L]]),
    n = as.integer(fit$diagnostics$n[[1L]]),
    events = as.integer(fit$diagnostics$events[[1L]]),
    design_strata = as.integer(
      fit$diagnostics$design_strata[[1L]]
    ),
    design_psu = as.integer(fit$diagnostics$design_psu[[1L]]),
    warnings = fit$diagnostics$warnings[[1L]],
    estimability_status = "ESTIMABLE",
    failure_class = "",
    failure_reason = "",
    stringsAsFactors = FALSE
  )
}

v45_diag_pool_table <- function(per_imputation, key_fields) {
  keys <- unique(per_imputation[key_fields])
  rows <- lapply(seq_len(nrow(keys)), function(i) {
    key <- keys[i, , drop = FALSE]
    use <- rep(TRUE, nrow(per_imputation))
    for (field in key_fields) {
      use <- use & per_imputation[[field]] == key[[field]][[1L]]
    }
    local <- per_imputation[use, , drop = FALSE]
    local <- local[order(local$imputation), , drop = FALSE]
    if (
      nrow(local) != 50L ||
      !identical(local$imputation, seq_len(50L))
    ) {
      stop(
        "Diagnostic key does not contain all 50 imputations: ",
        paste(unlist(key), collapse = "/"), call. = FALSE
      )
    }
    valid <- local$estimability_status == "ESTIMABLE" &
      is.finite(local$estimate) &
      is.finite(local$within_variance) &
      local$within_variance > 0
    stable_fields <- c(
      "n", "events", "design_strata", "design_psu", "design_df"
    )
    if (all(valid) && any(vapply(stable_fields, function(field) {
      values <- local[[field]]
      any(!is.finite(values)) || length(unique(values)) != 1L
    }, logical(1)))) {
      stop(
        "Diagnostic key has unstable n/events/design anchors across MI: ",
        paste(unlist(key), collapse = "/"), call. = FALSE
      )
    }
    failed_classes <- sort(unique(
      local$failure_class[!valid & nzchar(local$failure_class)]
    ))
    failed_reasons <- sort(unique(
      local$failure_reason[!valid & nzchar(local$failure_reason)]
    ))
    if (all(valid)) {
      pooled <- v45_pool_scalar_qu(
        local$estimate, local$within_variance,
        complete_data_df = unique(local$design_df)
      )
      pooled$pool_status <- "ESTIMABLE"
    } else {
      pooled <- data.frame(
        m = sum(valid),
        estimate = NA_real_,
        standard_error = NA_real_,
        ci_low = NA_real_,
        ci_high = NA_real_,
        p_value = NA_real_,
        within_variance = NA_real_,
        between_variance = NA_real_,
        total_variance = NA_real_,
        df = NA_real_,
        complete_data_design_df = if (any(valid)) {
          min(local$design_df[valid])
        } else {
          NA_real_
        },
        fraction_missing_information = NA_real_,
        relative_efficiency = NA_real_,
        monte_carlo_error = NA_real_,
        monte_carlo_error_fraction = NA_real_,
        pool_status = "NOT_ESTIMABLE",
        stringsAsFactors = FALSE
      )
    }
    pooled$valid_imputation_n <- sum(valid)
    pooled$failed_imputation_n <- sum(!valid)
    pooled$failure_class_summary <- paste(
      failed_classes, collapse = ";"
    )
    pooled$unique_failure_reason_n <- length(failed_reasons)
    cbind(key, pooled)
  })
  dplyr::bind_rows(rows)
}

v45_diag_static_self_test <- function() {
  models <- v45_diag_models()
  formulas <- lapply(names(models), v45_diag_ph_formula)
  checks <- c(
    exact_models = identical(names(models), c("v45_g1", "v45_g6a")),
    g1_exposures = identical(models$v45_g1, "E0"),
    g6a_exposures = identical(
      models$v45_g6a, c("E0", "L_FEV1", "L_RATIO")
    ),
    both_have_tt = all(vapply(
      formulas,
      function(x) "tt(E0)" %in% attr(stats::terms(x), "term.labels"),
      logical(1)
    )),
    both_have_strata = all(vapply(
      formulas,
      function(x) any(grepl(
        "strata\\(design_strata\\)", attr(stats::terms(x), "term.labels")
      )),
      logical(1)
    )),
    both_have_cluster = all(vapply(
      formulas,
      function(x) any(grepl(
        "cluster\\(design_psu\\)", attr(stats::terms(x), "term.labels")
      )),
      logical(1)
    )),
    cycle_fixed_omitted = all(vapply(
      formulas,
      function(x) !any(grepl(
        "cycle_label", attr(stats::terms(x), "term.labels")
      )),
      logical(1)
    )),
    fatal_patterns_exact = identical(
      v45_diag_fatal_warning_patterns(),
      c(
        "did not converge", "failed to converge",
        "algorithm did not converge", "infinite coefficient",
        "coefficient may be infinite", "singular",
        "computationally singular", "rank-deficient", "separation",
        "fitted probabilities numerically 0 or 1 occurred",
        "non-finite", "NA/NaN/Inf", "system is exactly singular",
        "logged event"
      )
    ),
    fatal_classifier_registered = identical(
      v45_diag_failure_class("coefficient may be infinite"),
      "NUMERICAL_OR_SUPPORT_FAILURE"
    ),
    unexpected_classifier_fails = identical(
      v45_diag_failure_class("object xyz is unavailable"),
      "UNEXPECTED_IMPLEMENTATION_ERROR"
    )
  )
  data.frame(
    check = names(checks),
    status = ifelse(checks, "PASS", "FAIL"),
    stringsAsFactors = FALSE
  )
}
