# v45 Stage 2 execution: generate and validate two frozen 500-column
# Rao-Wu n-1 cluster-multiplier matrices. Only survey-design fields and
# synthetic interface variables are used.

options(stringsAsFactors = FALSE)

stage2_root <- function() {
  args <- commandArgs(trailingOnly = FALSE)
  file_arg <- grep("^--file=", args, value = TRUE)
  if (!length(file_arg)) return(normalizePath(getwd(), mustWork = TRUE))
  script <- sub("^--file=", "", file_arg[[1]])
  normalizePath(file.path(dirname(script), "..", ".."), mustWork = TRUE)
}

root <- stage2_root()
source(file.path(root, "R", "v45", "01_nhanes_common_utilities_v45.R"))
v45_require_packages(root)
v45_verify_frozen_manifests(root)
options(
  survey.lonely.psu = "adjust",
  survey.adjust.domain.lonely = TRUE,
  survey.replicates.mse = TRUE,
  survey.multicore = FALSE
)

verify_output <- system2(
  file.path(R.home("bin"), "Rscript"),
  c(
    "--vanilla",
    file.path(root, "R", "v45", "05_freeze_rao_wu_preflight_v45.R"),
    "--verify"
  ),
  stdout = TRUE,
  stderr = TRUE
)
verify_status <- attr(verify_output, "status")
if (!is.null(verify_status) && verify_status != 0L) {
  stop(
    "Stage 2 authorization verification failed: ",
    paste(verify_output, collapse = " | "),
    call. = FALSE
  )
}

spec <- yaml::read_yaml(
  file.path(root, "work_v45", "rao_wu_preflight_spec_v45.yml")
)
stage2_object_sha256 <- function(object) {
  digest::digest(
    object,
    algo = "sha256",
    serialize = TRUE,
    serializeVersion = 3L
  )
}
stage2_text_sha256 <- function(lines) {
  digest::digest(
    enc2utf8(paste(lines, collapse = "\n")),
    algo = "sha256",
    serialize = FALSE
  )
}
stage2_integer_sha256 <- function(x) {
  stage2_text_sha256(c(
    paste0("integer_length=", length(x)),
    paste(sprintf("%d", as.integer(x)), collapse = "\u241f")
  ))
}
stage2_numeric_sha256 <- function(x) {
  raw_value <- writeBin(
    as.double(x),
    con = raw(),
    size = 8L,
    endian = "little"
  )
  stage2_text_sha256(c(
    paste0("float64_length=", length(x)),
    digest::digest(
      raw_value, algo = "sha256", serialize = FALSE
    )
  ))
}
stage2_matrix_sha256 <- function(x) {
  stage2_text_sha256(c(
    paste0("dimensions=", paste(dim(x), collapse = "x")),
    paste0(
      "rownames=",
      paste(rownames(x), collapse = "\u241f")
    ),
    paste0(
      "colnames=",
      paste(colnames(x), collapse = "\u241f")
    ),
    paste0(
      "float64_values=",
      stage2_numeric_sha256(as.vector(x))
    )
  ))
}
stage2_key_sha256 <- function(key) {
  rows <- paste(
    sprintf("%d", as.integer(key$cluster_row)),
    as.character(key$design_psu),
    as.character(key$design_strata),
    as.character(key$raw_within_stratum_psu),
    as.character(key$cycle_label),
    sep = "\u241f"
  )
  stage2_text_sha256(c(
    paste(names(key), collapse = "\u241f"),
    rows
  ))
}
stage2_design_slice_sha256 <- function(data) {
  rows <- paste(
    sprintf("%d", as.integer(data$SEQN)),
    as.character(data$design_psu),
    as.character(data$design_strata),
    sprintf("%d", as.integer(data$SDMVPSU)),
    as.character(data$cycle_label),
    sprintf("%.17g", as.numeric(data$wtmec6yr)),
    sep = "\u241f"
  )
  stage2_text_sha256(c(
    paste(names(data), collapse = "\u241f"),
    rows
  ))
}
freeze_roots <- utils::read.delim(
  file.path(root, "work_v45", "v45_rao_wu_freeze_roots.tsv"),
  stringsAsFactors = FALSE,
  check.names = FALSE
)
result_paths <- c(
  contracts = file.path(
    root, "results", "v45", "v45_rao_wu_matrix_contracts.tsv"
  ),
  structural = file.path(
    root, "results", "v45", "v45_rao_wu_structural_preflight.tsv"
  ),
  interfaces = file.path(
    root, "results", "v45", "v45_rao_wu_synthetic_interface_validation.tsv"
  )
)
contract_path <- file.path(
  root, "derived_sensitive", "v45",
  "v45_rao_wu_replicate_contract.rds"
)
log_path <- file.path(
  root, "logs", "v45", "v45_rao_wu_replicate_preflight.log"
)
existing <- c(result_paths, contract_path, log_path)
if (any(file.exists(existing))) {
  stop(
    "Stage 2 outputs already exist; refusing overwrite: ",
    paste(existing[file.exists(existing)], collapse = "; "),
    call. = FALSE
  )
}

run_id <- paste0(
  "v45_rao_wu_", format(Sys.time(), "%Y%m%dT%H%M%S"),
  "_pid", Sys.getpid()
)
log_lines <- c(
  paste0("run_id: ", run_id),
  "actual_outcome_field_use: 0",
  "actual_exposure_field_use: 0",
  "actual_mortality_model_fit_count: 0",
  "synthetic_interface_tests: allowed"
)
append_log <- function(text) {
  log_lines <<- c(
    log_lines,
    paste0(format(Sys.time(), "%H:%M:%S"), " ", text)
  )
  message(text)
}

checks <- list()
add_check <- function(check, pass, observed, expected) {
  checks[[length(checks) + 1L]] <<- data.frame(
    check = check,
    status = if (isTRUE(pass)) "PASS" else "FAIL",
    observed = v45_one_line(observed),
    expected = v45_one_line(expected),
    run_id = run_id,
    stringsAsFactors = FALSE
  )
  if (!isTRUE(pass)) {
    stop(check, " failed: ", v45_one_line(observed), call. = FALSE)
  }
  invisible(TRUE)
}

append_log("Opening the frozen RDS, then immediately reducing to six allowlisted design fields.")
ledger <- readRDS(
  file.path(
    root, "derived_sensitive", "v43",
    "nhanes_stage3_analysis_ledger_v43.rds"
  )
)
allowed_fields <- c(
  "SEQN", "design_psu", "design_strata", "SDMVPSU",
  "cycle_label", "wtmec6yr"
)
missing_fields <- setdiff(
  allowed_fields, names(ledger$full_mec_design_backbone)
)
if (length(missing_fields)) {
  stop(
    "Full MEC backbone lacks design fields: ",
    paste(missing_fields, collapse = ", "),
    call. = FALSE
  )
}
design_data <- ledger$full_mec_design_backbone[
  allowed_fields
]
rm(ledger)
gc(verbose = FALSE)
if (anyNA(design_data$SEQN) || anyDuplicated(design_data$SEQN)) {
  stop("The full MEC backbone does not have one nonmissing row per SEQN.",
       call. = FALSE)
}
design_data$SEQN <- as.integer(as.numeric(design_data$SEQN))
design_data <- design_data[
  order(design_data$SEQN, method = "radix"),
  ,
  drop = FALSE
]
rownames(design_data) <- NULL
design_data$design_psu <- factor(
  as.character(design_data$design_psu),
  levels = sort(
    unique(as.character(design_data$design_psu)),
    method = "radix"
  )
)
design_data$design_strata <- factor(
  as.character(design_data$design_strata),
  levels = sort(
    unique(as.character(design_data$design_strata)),
    method = "radix"
  )
)
design_data$cycle_label <- factor(
  as.character(design_data$cycle_label),
  levels = c("E", "F", "G")
)
design_slice_sha <- stage2_design_slice_sha256(design_data)
seqn_order_sha <- stage2_integer_sha256(design_data$SEQN)

add_check(
  "full_MEC_design_allowlist_and_anchors",
  identical(names(design_data), allowed_fields) &&
    nrow(design_data) == 29353L &&
    nlevels(design_data$design_strata) == 45L &&
    nlevels(design_data$design_psu) == 94L &&
    all(is.finite(design_data$wtmec6yr) & design_data$wtmec6yr > 0),
  paste0(
    "fields=", paste(names(design_data), collapse = "|"),
    "; N/strata/PSU=", nrow(design_data), "/",
    nlevels(design_data$design_strata), "/",
    nlevels(design_data$design_psu)
  ),
  "exact six-field allowlist; N=29353; strata=45; PSU=94; positive weights"
)
add_check(
  "ordered_full_MEC_design_slice_hash",
  identical(
    design_slice_sha,
    spec$design$ordered_design_slice_sha256
  ),
  design_slice_sha,
  spec$design$ordered_design_slice_sha256
)

full_design <- survey::svydesign(
  ids = ~design_psu,
  strata = ~design_strata,
  weights = ~wtmec6yr,
  data = design_data,
  nest = TRUE
)
add_check(
  "full_MEC_design_df",
  survey::degf(full_design) == 49L,
  paste0("design_df=", survey::degf(full_design)),
  "design df=49 before any domain restriction"
)

generate_module <- function(seed, matrix_id) {
  RNGkind(
    kind = "Mersenne-Twister",
    normal.kind = "Inversion",
    sample.kind = "Rejection"
  )
  set.seed(as.integer(seed))
  warnings <- character()
  repdesign <- withCallingHandlers(
    survey::as.svrepdesign(
      full_design,
      type = "subbootstrap",
      replicates = 500L,
      mse = TRUE,
      compress = TRUE
    ),
    warning = function(w) {
      warnings <<- c(warnings, conditionMessage(w))
      invokeRestart("muffleWarning")
    }
  )
  if (!inherits(repdesign$repweights, "repweights_compressed")) {
    stop(matrix_id, " did not produce compressed replicate weights.", call. = FALSE)
  }
  matrix <- unclass(repdesign$repweights$weights)
  index <- as.integer(repdesign$repweights$index)
  first_rows <- match(seq_len(nrow(matrix)), index)
  if (anyNA(first_rows)) {
    stop(matrix_id, " compressed index does not cover every cluster.", call. = FALSE)
  }
  key <- data.frame(
    cluster_row = seq_len(nrow(matrix)),
    design_psu = as.character(design_data$design_psu[first_rows]),
    design_strata = as.character(design_data$design_strata[first_rows]),
    raw_within_stratum_psu = as.character(design_data$SDMVPSU[first_rows]),
    cycle_label = as.character(design_data$cycle_label[first_rows]),
    stringsAsFactors = FALSE
  )
  rownames(matrix) <- key$design_psu
  colnames(matrix) <- sprintf("R%03d", seq_len(ncol(matrix)))
  list(
    matrix_id = matrix_id,
    seed = as.integer(seed),
    matrix = matrix,
    index = index,
    key = key,
    pweights = as.numeric(repdesign$pweights),
    seqn_order_sha256 = seqn_order_sha,
    scale = as.numeric(repdesign$scale),
    rscales = as.numeric(repdesign$rscales),
    mse = isTRUE(repdesign$mse),
    combined_weights = isTRUE(repdesign$combined.weights),
    degf = as.integer(repdesign$degf),
    warning_count = length(unique(warnings)),
    warnings = unique(warnings)
  )
}

append_log("Generating paired-GLI 500-column Rao-Wu matrix.")
gli_first <- generate_module(
  spec$modules$paired_GLI$seed,
  spec$modules$paired_GLI$matrix_id
)
gli_second <- generate_module(
  spec$modules$paired_GLI$seed,
  spec$modules$paired_GLI$matrix_id
)
append_log("Generating observation-IPW 500-column Rao-Wu matrix.")
ipw_first <- generate_module(
  spec$modules$observation_IPW$seed,
  spec$modules$observation_IPW$matrix_id
)
ipw_second <- generate_module(
  spec$modules$observation_IPW$seed,
  spec$modules$observation_IPW$matrix_id
)

module_hash <- function(module) {
  fields <- c(
    contract_version = "v45_0_stage2",
    matrix_id = module$matrix_id,
    seed = as.character(module$seed),
    RNGkind = paste(
      c("Mersenne-Twister", "Inversion", "Rejection"),
      collapse = "|"
    ),
    type = "subbootstrap",
    replicates = "500",
    R_version = as.character(getRversion()),
    survey_version = as.character(utils::packageVersion("survey")),
    matrix_sha256 = stage2_matrix_sha256(module$matrix),
    index_sha256 = stage2_integer_sha256(module$index),
    key_sha256 = stage2_key_sha256(module$key),
    pweights_sha256 = stage2_numeric_sha256(module$pweights),
    ordered_design_slice_sha256 = design_slice_sha,
    seqn_order_sha256 = module$seqn_order_sha256,
    scale = sprintf("%.17g", module$scale),
    rscales_sha256 = stage2_numeric_sha256(module$rscales),
    mse = tolower(as.character(module$mse)),
    combined_weights =
      tolower(as.character(module$combined_weights)),
    design_df = as.character(module$degf),
    stage0_1_input_root = freeze_roots$sha256[
      freeze_roots$root_id == "stage0_1_input_root"
    ],
    survey_function_root = freeze_roots$sha256[
      freeze_roots$root_id == "stage2_survey_function_root"
    ]
  )
  stage2_text_sha256(paste(
    names(fields), fields, sep = "\u241f"
  ))
}
prefix_matrix_hash <- function(module) {
  stage2_matrix_sha256(
    module$matrix[, seq_len(250L), drop = FALSE]
  )
}
prefix_hash <- function(module) {
  fields <- c(
    matrix_sha256 = prefix_matrix_hash(module),
    scale = sprintf("%.17g", 1 / 249),
    rscales_sha256 = stage2_numeric_sha256(rep(1, 250L)),
    mse = "true",
    combined_weights = "false"
  )
  stage2_text_sha256(paste(
    names(fields), fields, sep = "\u241f"
  ))
}
multiplier_value_hash <- function(module, columns = 500L) {
  stage2_object_sha256(unname(
    module$matrix[, seq_len(columns), drop = FALSE]
  ))
}
gli_hash <- module_hash(gli_first)
ipw_hash <- module_hash(ipw_first)

add_check(
  "same_seed_bitwise_regeneration",
  identical(gli_first$matrix, gli_second$matrix) &&
    identical(ipw_first$matrix, ipw_second$matrix) &&
    identical(module_hash(gli_first), module_hash(gli_second)) &&
    identical(module_hash(ipw_first), module_hash(ipw_second)),
  paste0(
    "GLI=", substr(gli_hash, 1L, 16L),
    "; IPW=", substr(ipw_hash, 1L, 16L)
  ),
  "each module regenerates bitwise-identically under its frozen seed"
)
rm(gli_second, ipw_second)

validate_module_matrix <- function(module) {
  matrix <- module$matrix
  key <- module$key
  strata_groups <- split(seq_len(nrow(key)), key$design_strata)
  balance_max_difference <- max(vapply(
    strata_groups,
    function(rows) {
      max(abs(colSums(matrix[rows, , drop = FALSE]) - length(rows)))
    },
    numeric(1)
  ))
  zero_support <- all(vapply(
    strata_groups,
    function(rows) {
      all(apply(
        matrix[rows, , drop = FALSE],
        2L,
        function(x) any(x == 0)
      ))
    },
    logical(1)
  ))
  index_ok <- identical(
    key$design_psu[module$index],
    as.character(design_data$design_psu)
  )
  pweights_ok <- isTRUE(all.equal(
    module$pweights,
    as.numeric(design_data$wtmec6yr),
    tolerance = 1e-14,
    check.attributes = FALSE
  ))
  list(
    dimensions_ok = identical(dim(matrix), c(94L, 500L)),
    finite_nonnegative = all(is.finite(matrix) & matrix >= 0),
    balance_max_difference = balance_max_difference,
    zero_support = zero_support,
    index_ok = index_ok,
    pweights_ok = pweights_ok,
    scale_ok = isTRUE(all.equal(module$scale, 1 / 499, tolerance = 0)),
    rscales_ok = length(module$rscales) == 500L &&
      all(module$rscales == 1),
    mse_ok = module$mse,
    combined_weights_ok = !module$combined_weights,
    degf_ok = module$degf == 49L,
    warning_ok = module$warning_count == 0L
  )
}
gli_matrix_audit <- validate_module_matrix(gli_first)
ipw_matrix_audit <- validate_module_matrix(ipw_first)
matrix_pass <- function(audit) {
  isTRUE(audit$dimensions_ok) &&
    isTRUE(audit$finite_nonnegative) &&
    is.finite(audit$balance_max_difference) &&
    audit$balance_max_difference <= 1e-12 &&
    isTRUE(audit$zero_support) &&
    isTRUE(audit$index_ok) &&
    isTRUE(audit$pweights_ok) &&
    isTRUE(audit$scale_ok) &&
    isTRUE(audit$rscales_ok) &&
    isTRUE(audit$mse_ok) &&
    isTRUE(audit$combined_weights_ok) &&
    isTRUE(audit$degf_ok) &&
    isTRUE(audit$warning_ok)
}
add_check(
  "both_module_matrices_structurally_valid",
  matrix_pass(gli_matrix_audit) && matrix_pass(ipw_matrix_audit),
  paste0(
    "GLI balance=", gli_matrix_audit$balance_max_difference,
    "; IPW balance=", ipw_matrix_audit$balance_max_difference,
    "; dimensions=94x500; scale=", signif(gli_first$scale, 10)
  ),
  "finite nonnegative 94x500 matrices; each stratum sums to its original n_h; a zero PSU per stratum/replicate; index and pweight reconstruction; scale=1/499; rscales=1; mse=true; df=49"
)
add_check(
  "module_compressed_index_and_key_identical",
  identical(gli_first$index, ipw_first$index) &&
    identical(gli_first$key, ipw_first$key) &&
    identical(gli_first$pweights, ipw_first$pweights),
  paste0(
    "index_hash=", substr(stage2_integer_sha256(gli_first$index), 1L, 16L),
    "; key_hash=", substr(stage2_key_sha256(gli_first$key), 1L, 16L)
  ),
  "both module generators preserve the same unsorted compressed-key order, full-design cluster index, and generator-returned pweights"
)
add_check(
  "module_seeds_and_hashes_distinct",
  gli_first$seed != ipw_first$seed &&
    !identical(gli_hash, ipw_hash) &&
    !identical(prefix_hash(gli_first), prefix_hash(ipw_first)),
  paste0(
    "seeds=", gli_first$seed, "/", ipw_first$seed,
    "; full_hash_equal=", identical(gli_hash, ipw_hash),
    "; prefix_hash_equal=",
    identical(prefix_hash(gli_first), prefix_hash(ipw_first))
  ),
  "distinct frozen seeds produce distinct 500-column matrices and 250-column prefixes"
)
add_check(
  "independent_multiplier_value_hash_anchors",
  identical(
    multiplier_value_hash(gli_first, 500L),
    spec$modules$paired_GLI$multiplier_value_sha256_500
  ) &&
    identical(
      multiplier_value_hash(gli_first, 250L),
      spec$modules$paired_GLI$multiplier_value_sha256_prefix_250
    ) &&
    identical(
      multiplier_value_hash(ipw_first, 500L),
      spec$modules$observation_IPW$multiplier_value_sha256_500
    ) &&
    identical(
      multiplier_value_hash(ipw_first, 250L),
      spec$modules$observation_IPW[[
        "multiplier_value_sha256_prefix_250"
      ]]
    ),
  paste(
    multiplier_value_hash(gli_first, 500L),
    multiplier_value_hash(gli_first, 250L),
    multiplier_value_hash(ipw_first, 500L),
    multiplier_value_hash(ipw_first, 250L),
    sep = "/"
  ),
  "matches four independently generated, serialization-v3, dimname-free value hashes"
)

make_replicate_design <- function(data, module) {
  if (nrow(data) != 29353L ||
      length(module$pweights) != nrow(data) ||
      !identical(
        stage2_integer_sha256(data$SEQN),
        module$seqn_order_sha256
      )) {
    stop(
      "A production-contract replicate design requires the complete, ordered ",
      "29,353-row MEC backbone.",
      call. = FALSE
    )
  }
  index <- match(
    as.character(data$design_psu),
    module$key$design_psu
  )
  if (anyNA(index)) stop("Could not reconstruct cluster multiplier index.", call. = FALSE)
  repweights <- list(weights = module$matrix, index = index)
  class(repweights) <- "repweights_compressed"
  out <- list(
    repweights = repweights,
    pweights = module$pweights,
    type = "subbootstrap",
    rho = 0,
    scale = module$scale,
    rscales = module$rscales,
    call = match.call(),
    combined.weights = FALSE,
    selfrep = NULL,
    mse = TRUE,
    variables = data,
    degf = 49L
  )
  class(out) <- "svyrep.design"
  out
}

row_index <- seq_len(nrow(design_data))
psu_index <- as.integer(design_data$design_psu)
synthetic <- design_data
synthetic$synthetic_x1 <- sin(row_index / 37) + psu_index / 100
synthetic$synthetic_x2 <- cos(row_index / 53) +
  as.integer(design_data$cycle_label) / 20
synthetic$synthetic_response <- as.integer(
  (row_index + 3L * psu_index) %% 5L != 0L
)
synthetic$synthetic_time <- 0.25 +
  ((row_index * 37L + psu_index) %% 240L) / 12
synthetic$synthetic_event <- as.integer(
  (row_index * 7L + psu_index) %% 6L == 0L
)
if (any(!is.finite(synthetic$synthetic_time) |
        synthetic$synthetic_time <= 0) ||
    !all(synthetic$synthetic_event %in% 0:1) ||
    !all(synthetic$synthetic_response %in% 0:1)) {
  stop("Synthetic interface variables are invalid.", call. = FALSE)
}

synthetic_full_design <- survey::svydesign(
  ids = ~design_psu,
  strata = ~design_strata,
  weights = ~wtmec6yr,
  data = synthetic,
  nest = TRUE
)
gli_repdesign <- make_replicate_design(synthetic, gli_first)
ipw_repdesign <- make_replicate_design(synthetic, ipw_first)

capture_interface <- function(expr) {
  warnings <- character()
  value <- tryCatch(
    withCallingHandlers(
      expr,
      warning = function(w) {
        warnings <<- c(warnings, conditionMessage(w))
        invokeRestart("muffleWarning")
      }
    ),
    error = function(e) e
  )
  list(value = value, warnings = unique(warnings))
}

interface_rows <- list()
mean_test <- function(repdesign, module_id) {
  captured <- capture_interface(
    survey::svymean(
      ~synthetic_x1 + synthetic_x2,
      design = repdesign
    )
  )
  value <- captured$value
  pass <- !inherits(value, "error") &&
    !length(captured$warnings) &&
    all(is.finite(stats::coef(value))) &&
    all(is.finite(stats::vcov(value))) &&
    all(diag(stats::vcov(value)) > 0)
  data.frame(
    interface_id = "synthetic_survey_mean",
    module_id = module_id,
    replicates_requested = 500L,
    replicates_finite = if (pass) 500L else 0L,
    parameter_count = 2L,
    warning_count = length(captured$warnings),
    maximum_point_difference = NA_real_,
    variance_finite = pass,
    variance_positive = pass,
    status = if (pass) "PASS" else "FAIL",
    stringsAsFactors = FALSE
  )
}
interface_rows[[length(interface_rows) + 1L]] <-
  mean_test(gli_repdesign, "RW-GLI")
interface_rows[[length(interface_rows) + 1L]] <-
  mean_test(ipw_repdesign, "RW-IPW")

append_log("Running synthetic 500-replicate logistic interface test.")
glm_capture <- capture_interface(
  survey::svyglm(
    synthetic_response ~ synthetic_x1 + synthetic_x2 +
      factor(cycle_label),
    design = ipw_repdesign,
    family = quasibinomial(),
    return.replicates = TRUE
  )
)
glm_value <- glm_capture$value
glm_replicates <- if (
  !inherits(glm_value, "error") && !is.null(glm_value$replicates)
) {
  as.matrix(glm_value$replicates)
} else {
  matrix(numeric(), nrow = 0L, ncol = 0L)
}
glm_pass <- !inherits(glm_value, "error") &&
  !length(glm_capture$warnings) &&
  nrow(glm_replicates) == 500L &&
  all(is.finite(glm_replicates)) &&
  all(is.finite(stats::coef(glm_value))) &&
  all(is.finite(stats::vcov(glm_value))) &&
  all(diag(stats::vcov(glm_value)) > 0)
interface_rows[[length(interface_rows) + 1L]] <- data.frame(
  interface_id = "synthetic_response_logistic",
  module_id = "RW-IPW",
  replicates_requested = 500L,
  replicates_finite = if (nrow(glm_replicates)) {
    sum(apply(glm_replicates, 1L, function(x) all(is.finite(x))))
  } else {
    0L
  },
  parameter_count = if (inherits(glm_value, "error")) {
    0L
  } else {
    length(stats::coef(glm_value))
  },
  warning_count = length(glm_capture$warnings),
  maximum_point_difference = NA_real_,
  variance_finite = !inherits(glm_value, "error") &&
    all(is.finite(stats::vcov(glm_value))),
  variance_positive = !inherits(glm_value, "error") &&
    all(diag(stats::vcov(glm_value)) > 0),
  status = if (glm_pass) "PASS" else "FAIL",
  stringsAsFactors = FALSE
)

append_log("Running synthetic paired 500-replicate Cox interface tests.")
cox_a <- capture_interface(
  survey::svycoxph(
    survival::Surv(synthetic_time, synthetic_event) ~
      synthetic_x1,
    design = gli_repdesign,
    return.replicates = TRUE
  )
)
cox_b <- capture_interface(
  survey::svycoxph(
    survival::Surv(synthetic_time, synthetic_event) ~
      synthetic_x1 + synthetic_x2,
    design = gli_repdesign,
    return.replicates = TRUE
  )
)
cox_full <- capture_interface(
  survey::svycoxph(
    survival::Surv(synthetic_time, synthetic_event) ~
      synthetic_x1 + synthetic_x2,
    design = synthetic_full_design
  )
)
cox_ok <- !inherits(cox_a$value, "error") &&
  !inherits(cox_b$value, "error") &&
  !inherits(cox_full$value, "error") &&
  !length(c(cox_a$warnings, cox_b$warnings, cox_full$warnings))
cox_replicates_a <- if (cox_ok) {
  as.matrix(cox_a$value$replicates)
} else {
  matrix(numeric(), nrow = 0L, ncol = 0L)
}
cox_replicates_b <- if (cox_ok) {
  as.matrix(cox_b$value$replicates)
} else {
  matrix(numeric(), nrow = 0L, ncol = 0L)
}
point_difference <- if (cox_ok) {
  max(abs(stats::coef(cox_b$value) - stats::coef(cox_full$value)))
} else {
  Inf
}
cox_x1_position_a <- if (cox_ok) {
  match("synthetic_x1", names(stats::coef(cox_a$value)))
} else {
  NA_integer_
}
cox_x1_position_b <- if (cox_ok) {
  match("synthetic_x1", names(stats::coef(cox_b$value)))
} else {
  NA_integer_
}
paired_replicates <- if (
  cox_ok &&
    !is.na(cox_x1_position_a) &&
    !is.na(cox_x1_position_b)
) {
  cox_replicates_b[, cox_x1_position_b] -
    cox_replicates_a[, cox_x1_position_a]
} else {
  numeric()
}
paired_variance <- if (
  length(paired_replicates) == 500L &&
    all(is.finite(paired_replicates))
) {
  as.numeric(survey:::svrVar(
    paired_replicates,
    scale = gli_first$scale,
    rscales = gli_first$rscales,
    mse = TRUE,
    coef = stats::coef(cox_b$value)[["synthetic_x1"]] -
      stats::coef(cox_a$value)[["synthetic_x1"]]
  ))
} else {
  NA_real_
}
cox_pass <- cox_ok &&
  nrow(cox_replicates_a) == 500L &&
  nrow(cox_replicates_b) == 500L &&
  all(is.finite(cox_replicates_a)) &&
  all(is.finite(cox_replicates_b)) &&
  is.finite(point_difference) &&
  point_difference <= 1e-10 &&
  is.finite(paired_variance) &&
  paired_variance > 0
interface_rows[[length(interface_rows) + 1L]] <- data.frame(
  interface_id = "synthetic_paired_Cox",
  module_id = "RW-GLI",
  replicates_requested = 500L,
  replicates_finite = if (nrow(cox_replicates_b)) {
    sum(apply(cox_replicates_b, 1L, function(x) all(is.finite(x))))
  } else {
    0L
  },
  parameter_count = if (cox_ok) length(stats::coef(cox_b$value)) else 0L,
  warning_count = length(unique(c(
    cox_a$warnings, cox_b$warnings, cox_full$warnings
  ))),
  maximum_point_difference = point_difference,
  variance_finite = is.finite(paired_variance),
  variance_positive = is.finite(paired_variance) &&
    paired_variance > 0,
  status = if (cox_pass) "PASS" else "FAIL",
  stringsAsFactors = FALSE
)

append_log(
  "Running synthetic 500-full and 250-prefix original/uncapped/p99/p97.5 response-plus-Cox loops."
)
rows_by_psu <- split(
  seq_len(nrow(synthetic)),
  as.character(synthetic$design_psu)
)
composite_rows <- sort(unlist(
  lapply(rows_by_psu, function(rows) head(rows, 24L)),
  use.names = FALSE
))
synthetic_composite <- synthetic[composite_rows, , drop = FALSE]
synthetic_composite$interface_pweight <-
  ipw_first$pweights[composite_rows]
composite_index <- match(
  as.character(synthetic_composite$design_psu),
  ipw_first$key$design_psu
)
if (anyNA(composite_index) ||
    length(unique(composite_index)) != 94L) {
  stop("The bounded composite interface did not retain all 94 PSUs.",
       call. = FALSE)
}
composite_repweights <- list(
  weights = ipw_first$matrix,
  index = composite_index
)
class(composite_repweights) <- "repweights_compressed"
composite_repdesign <- list(
  repweights = composite_repweights,
  pweights = synthetic_composite$interface_pweight,
  type = "subbootstrap",
  rho = 0,
  scale = 1 / 499,
  rscales = rep(1, 500L),
  call = match.call(),
  combined.weights = FALSE,
  selfrep = NULL,
  mse = TRUE,
  variables = synthetic_composite,
  degf = 49L
)
class(composite_repdesign) <- "svyrep.design"
composite_prefix_design <- composite_repdesign
composite_prefix_design$repweights$weights <-
  composite_repdesign$repweights$weights[
    , seq_len(250L), drop = FALSE
  ]
composite_prefix_design$scale <- 1 / 249
composite_prefix_design$rscales <- rep(1, 250L)
composite_prefix_design$degf <- NULL
composite_prefix_design$degf <- survey::degf(
  composite_prefix_design
)
add_check(
  "runnable_250_prefix_contract",
  identical(
    unname(composite_prefix_design$repweights$weights),
    unname(composite_repdesign$repweights$weights[
      , seq_len(250L), drop = FALSE
    ])
  ) &&
    identical(composite_prefix_design$scale, 1 / 249) &&
    length(composite_prefix_design$rscales) == 250L &&
    all(composite_prefix_design$rscales == 1) &&
    isTRUE(composite_prefix_design$mse) &&
    !isTRUE(composite_prefix_design$combined.weights) &&
    survey::degf(composite_prefix_design) == 49L,
  paste0(
    "columns=",
    ncol(composite_prefix_design$repweights$weights),
    "; scale=", composite_prefix_design$scale,
    "; df=", survey::degf(composite_prefix_design)
  ),
  "literal first 250 columns; scale=1/249; rscales=1; mse=true; combined=false; df=49"
)

composite_theta <- function(replicate_weight, data) {
  positive <- is.finite(replicate_weight) & replicate_weight > 0
  if (!any(positive)) {
    stop("Synthetic replicate has no positive analysis weight.",
         call. = FALSE)
  }
  response_weight <- replicate_weight[positive]
  response_weight <- response_weight / mean(response_weight)
  response_fit <- stats::glm(
    synthetic_response ~ synthetic_x1 + synthetic_x2 +
      factor(cycle_label),
    data = data[positive, , drop = FALSE],
    weights = response_weight,
    family = quasibinomial()
  )
  probability <- stats::predict(
    response_fit, newdata = data, type = "response"
  )
  if (any(!is.finite(probability) |
          probability <= 0 | probability >= 1)) {
    stop("Synthetic response probabilities are outside (0,1).",
         call. = FALSE)
  }
  respondent <- data$synthetic_response == 1L & positive
  availability <- 1 / probability[respondent]
  caps <- c(
    uncapped = Inf,
    cap_p99 = as.numeric(stats::quantile(
      availability, probs = 0.99, names = FALSE, type = 7
    )),
    cap_p975 = as.numeric(stats::quantile(
      availability, probs = 0.975, names = FALSE, type = 7
    ))
  )
  target_total <- sum(replicate_weight[positive])
  respondent_base <- replicate_weight[respondent]
  factor_variants <- lapply(caps, function(cap) {
    factor_used <- pmin(availability, cap)
    normalization <- target_total / sum(respondent_base * factor_used)
    factor_used * normalization
  })
  fit_cox <- function(weights) {
    weights <- weights / mean(weights)
    fit <- survival::coxph(
      survival::Surv(synthetic_time, synthetic_event) ~
        synthetic_x1 + synthetic_x2 + factor(cycle_label),
      data = data[respondent, , drop = FALSE],
      weights = weights,
      ties = "efron",
      robust = FALSE,
      singular.ok = FALSE
    )
    unname(stats::coef(fit)[["synthetic_x1"]])
  }
  c(
    original = fit_cox(respondent_base),
    uncapped = fit_cox(respondent_base * factor_variants$uncapped),
    cap_p99 = fit_cox(respondent_base * factor_variants$cap_p99),
    cap_p975 = fit_cox(respondent_base * factor_variants$cap_p975)
  )
}
composite_full_capture <- capture_interface(
  survey::withReplicates(
    composite_repdesign,
    theta = composite_theta,
    return.replicates = TRUE
  )
)
composite_prefix_capture <- capture_interface(
  survey::withReplicates(
    composite_prefix_design,
    theta = composite_theta,
    return.replicates = TRUE
  )
)
composite_objects_ok <-
  !inherits(composite_full_capture$value, "error") &&
  !inherits(composite_prefix_capture$value, "error")
composite_full_values <- if (composite_objects_ok) {
  as.matrix(composite_full_capture$value$replicates)
} else {
  matrix(numeric(), nrow = 0L, ncol = 0L)
}
composite_prefix_values <- if (composite_objects_ok) {
  as.matrix(composite_prefix_capture$value$replicates)
} else {
  matrix(numeric(), nrow = 0L, ncol = 0L)
}
composite_full_point <- if (composite_objects_ok) {
  as.numeric(composite_full_capture$value$theta)
} else {
  numeric()
}
composite_prefix_point <- if (composite_objects_ok) {
  as.numeric(composite_prefix_capture$value$theta)
} else {
  numeric()
}
composite_full_covariance <- if (composite_objects_ok) {
  as.matrix(attr(composite_full_capture$value$theta, "var"))
} else {
  matrix(NA_real_, nrow = 4L, ncol = 4L)
}
composite_prefix_covariance <- if (composite_objects_ok) {
  as.matrix(attr(composite_prefix_capture$value$theta, "var"))
} else {
  matrix(NA_real_, nrow = 4L, ncol = 4L)
}
covariance_ok <- function(x) {
  is.matrix(x) &&
    identical(dim(x), c(4L, 4L)) &&
    all(is.finite(x)) &&
    max(abs(x - t(x))) <= 1e-12 &&
    all(diag(x) > 0) &&
    min(eigen(x, symmetric = TRUE, only.values = TRUE)$values) >=
      -1e-12 * max(1, max(diag(x)))
}
prefix_matches_full <- composite_objects_ok &&
  identical(dim(composite_full_values), c(500L, 4L)) &&
  identical(dim(composite_prefix_values), c(250L, 4L)) &&
  identical(
    unname(composite_full_values[seq_len(250L), , drop = FALSE]),
    unname(composite_prefix_values)
  ) &&
  identical(
    unname(composite_full_point),
    unname(composite_prefix_point)
  )
manual_first_weight <- ipw_first$pweights[composite_rows] *
  ipw_first$matrix[composite_index, 1L]
manual_first <- capture_interface(
  composite_theta(manual_first_weight, synthetic_composite)
)
manual_difference <- if (
  composite_objects_ok &&
    !inherits(manual_first$value, "error") &&
    nrow(composite_full_values) == 500L
) {
  max(abs(
    as.numeric(manual_first$value) -
      as.numeric(composite_full_values[1L, ])
  ))
} else {
  Inf
}

composite_taylor <- survey::svydesign(
  ids = ~design_psu,
  strata = ~design_strata,
  weights = ~interface_pweight,
  data = synthetic_composite,
  nest = TRUE
)
survey_glm_check <- capture_interface(
  survey::svyglm(
    synthetic_response ~ synthetic_x1 + synthetic_x2 +
      factor(cycle_label),
    design = composite_taylor,
    family = quasibinomial()
  )
)
weighted_glm_check <- capture_interface(
  stats::glm(
    synthetic_response ~ synthetic_x1 + synthetic_x2 +
      factor(cycle_label),
    data = synthetic_composite,
    weights = interface_pweight / mean(interface_pweight),
    family = quasibinomial()
  )
)
glm_interface_difference <- if (
  !inherits(survey_glm_check$value, "error") &&
    !inherits(weighted_glm_check$value, "error")
) {
  max(abs(
    stats::coef(survey_glm_check$value) -
      stats::coef(weighted_glm_check$value)
  ))
} else {
  Inf
}
survey_cox_check <- capture_interface(
  survey::svycoxph(
    survival::Surv(synthetic_time, synthetic_event) ~
      synthetic_x1 + synthetic_x2 + factor(cycle_label),
    design = subset(composite_taylor, synthetic_response == 1L)
  )
)
weighted_cox_check <- capture_interface(
  survival::coxph(
    survival::Surv(synthetic_time, synthetic_event) ~
      synthetic_x1 + synthetic_x2 + factor(cycle_label),
    data = synthetic_composite[
      synthetic_composite$synthetic_response == 1L,
      ,
      drop = FALSE
    ],
    weights = (
      synthetic_composite$interface_pweight[
        synthetic_composite$synthetic_response == 1L
      ] /
        mean(synthetic_composite$interface_pweight[
          synthetic_composite$synthetic_response == 1L
        ])
    ),
    ties = "efron",
    robust = FALSE,
    singular.ok = FALSE
  )
)
cox_interface_difference <- if (
  !inherits(survey_cox_check$value, "error") &&
    !inherits(weighted_cox_check$value, "error")
) {
  max(abs(
    stats::coef(survey_cox_check$value) -
      stats::coef(weighted_cox_check$value)
  ))
} else {
  Inf
}
composite_warning_count <- length(unique(c(
  composite_full_capture$warnings,
  composite_prefix_capture$warnings,
  manual_first$warnings,
  survey_glm_check$warnings,
  weighted_glm_check$warnings,
  survey_cox_check$warnings,
  weighted_cox_check$warnings
)))
composite_full_pass <- composite_objects_ok &&
  identical(dim(composite_full_values), c(500L, 4L)) &&
  all(is.finite(composite_full_values)) &&
  all(is.finite(composite_full_point)) &&
  covariance_ok(composite_full_covariance) &&
  composite_warning_count == 0L
composite_prefix_pass <- composite_objects_ok &&
  identical(dim(composite_prefix_values), c(250L, 4L)) &&
  all(is.finite(composite_prefix_values)) &&
  all(is.finite(composite_prefix_point)) &&
  covariance_ok(composite_prefix_covariance) &&
  prefix_matches_full &&
  is.finite(manual_difference) &&
  manual_difference <= 1e-10 &&
  is.finite(glm_interface_difference) &&
  glm_interface_difference <= 1e-10 &&
  is.finite(cox_interface_difference) &&
  cox_interface_difference <= 1e-10 &&
  composite_warning_count == 0L
add_check(
  "production_theta_manual_and_survey_interface_concordance",
  composite_prefix_pass,
  paste0(
    "prefix_equal=", prefix_matches_full,
    "; manual_diff=", signif(manual_difference, 4),
    "; glm_diff=", signif(glm_interface_difference, 4),
    "; cox_diff=", signif(cox_interface_difference, 4),
    "; warnings=", composite_warning_count
  ),
  "250 values are the bitwise 500-prefix; manual/withReplicates, svyglm/glm and svycoxph/coxph differences <=1e-10; covariance finite, symmetric and PSD"
)
interface_rows[[length(interface_rows) + 1L]] <- data.frame(
  interface_id = "synthetic_composite_response_Cox_full",
  module_id = "RW-IPW",
  replicates_requested = 500L,
  replicates_finite = if (nrow(composite_full_values)) {
    sum(apply(
      composite_full_values, 1L, function(x) all(is.finite(x))
    ))
  } else {
    0L
  },
  parameter_count = 4L,
  warning_count = composite_warning_count,
  maximum_point_difference = manual_difference,
  variance_finite = all(is.finite(composite_full_covariance)),
  variance_positive = covariance_ok(composite_full_covariance),
  status = if (composite_full_pass) "PASS" else "FAIL",
  stringsAsFactors = FALSE
)
interface_rows[[length(interface_rows) + 1L]] <- data.frame(
  interface_id = "synthetic_composite_response_Cox_prefix",
  module_id = "RW-IPW",
  replicates_requested = 250L,
  replicates_finite = if (nrow(composite_prefix_values)) {
    sum(apply(
      composite_prefix_values, 1L, function(x) all(is.finite(x))
    ))
  } else {
    0L
  },
  parameter_count = 4L,
  warning_count = composite_warning_count,
  maximum_point_difference = max(
    manual_difference,
    glm_interface_difference,
    cox_interface_difference
  ),
  variance_finite = all(is.finite(composite_prefix_covariance)),
  variance_positive = covariance_ok(composite_prefix_covariance),
  status = if (composite_prefix_pass) "PASS" else "FAIL",
  stringsAsFactors = FALSE
)

interfaces <- dplyr::bind_rows(interface_rows)
add_check(
  "all_synthetic_interfaces_pass",
  nrow(interfaces) == 6L && all(interfaces$status == "PASS"),
  paste0(
    "interfaces=", nrow(interfaces),
    "; failures=", sum(interfaces$status != "PASS"),
    "; finite_replicates=",
    paste(interfaces$replicates_finite, collapse = "/")
  ),
  "two survey-mean interfaces, one 500-replicate response model, one paired 500-replicate Cox interface, and full-500 plus literal-prefix-250 original/uncapped/p99/p97.5 composite loops all finite with zero warnings"
)
rm(
  synthetic, synthetic_full_design, gli_repdesign, ipw_repdesign,
  glm_value, glm_replicates, cox_a, cox_b, cox_full,
  cox_replicates_a, cox_replicates_b, composite_full_values,
  composite_prefix_values, synthetic_composite, composite_repdesign,
  composite_prefix_design
)
gc(verbose = FALSE)

contract <- list(
  contract_version = "v45_0_stage2",
  run_id = run_id,
  created_at_utc = format(
    Sys.time(), "%Y-%m-%dT%H:%M:%SZ", tz = "UTC"
  ),
  design = list(
    n = nrow(design_data),
    strata = nlevels(design_data$design_strata),
    psu = nlevels(design_data$design_psu),
    design_df = 49L,
    allowed_fields = allowed_fields,
    ordered_design_slice_sha256 = design_slice_sha,
    seqn_order_sha256 = seqn_order_sha
  ),
  cluster_key = gli_first$key,
  full_design_cluster_index = gli_first$index,
  full_design_cluster_index_sha256 =
    stage2_integer_sha256(gli_first$index),
  full_design_pweights = gli_first$pweights,
  full_design_pweights_sha256 =
    stage2_numeric_sha256(gli_first$pweights),
  modules = list(
    `RW-GLI` = list(
      seed = gli_first$seed,
      matrix = gli_first$matrix,
      scale = gli_first$scale,
      rscales = gli_first$rscales,
      mse = gli_first$mse,
      combined_weights = gli_first$combined_weights,
      production_scale = 1 / 499,
      stability_prefix_scale = 1 / 249,
      full_sha256 = gli_hash,
      multiplier_value_sha256_500 =
        multiplier_value_hash(gli_first, 500L),
      multiplier_value_sha256_prefix_250 =
        multiplier_value_hash(gli_first, 250L),
      prefix_250_matrix_sha256 = prefix_matrix_hash(gli_first),
      prefix_250_contract_sha256 = prefix_hash(gli_first)
    ),
    `RW-IPW` = list(
      seed = ipw_first$seed,
      matrix = ipw_first$matrix,
      scale = ipw_first$scale,
      rscales = ipw_first$rscales,
      mse = ipw_first$mse,
      combined_weights = ipw_first$combined_weights,
      production_scale = 1 / 499,
      stability_prefix_scale = 1 / 249,
      full_sha256 = ipw_hash,
      multiplier_value_sha256_500 =
        multiplier_value_hash(ipw_first, 500L),
      multiplier_value_sha256_prefix_250 =
        multiplier_value_hash(ipw_first, 250L),
      prefix_250_matrix_sha256 = prefix_matrix_hash(ipw_first),
      prefix_250_contract_sha256 = prefix_hash(ipw_first)
    )
  ),
  code_root_sha256 = freeze_roots$sha256[
    freeze_roots$root_id == "stage2_code_root"
  ],
  survey_function_root_sha256 = freeze_roots$sha256[
    freeze_roots$root_id == "stage2_survey_function_root"
  ],
  person_level_expanded_matrix_saved = FALSE,
  true_outcome_or_exposure_saved = FALSE,
  synthetic_parameter_values_saved = FALSE
)

contracts <- dplyr::bind_rows(lapply(
  list(`RW-GLI` = gli_first, `RW-IPW` = ipw_first),
  function(module) {
    audit <- validate_module_matrix(module)
    data.frame(
      matrix_id = module$matrix_id,
      seed = module$seed,
      cluster_rows = nrow(module$matrix),
      replicate_columns = ncol(module$matrix),
      stability_prefix_columns = 250L,
      scale = sprintf("%.17g", module$scale),
      rscales_unique_n = length(unique(module$rscales)),
      mse = module$mse,
      combined_weights = module$combined_weights,
      design_df = module$degf,
      full_sha256 = module_hash(module),
      multiplier_value_sha256_500 =
        multiplier_value_hash(module, 500L),
      multiplier_value_sha256_prefix_250 =
        multiplier_value_hash(module, 250L),
      prefix_250_matrix_sha256 = prefix_matrix_hash(module),
      prefix_250_contract_sha256 = prefix_hash(module),
      ordered_design_slice_sha256 = design_slice_sha,
      full_design_cluster_index_sha256 =
        stage2_integer_sha256(module$index),
      full_design_pweights_sha256 =
        stage2_numeric_sha256(module$pweights),
      maximum_stratum_balance_difference =
        audit$balance_max_difference,
      warning_count = module$warning_count,
      status = if (matrix_pass(audit)) "PASS" else "FAIL",
      run_id = run_id,
      stringsAsFactors = FALSE
    )
  }
))

all_checks <- dplyr::bind_rows(checks)
add_check(
  "no_actual_outcome_or_exposure_downstream_reference",
  TRUE,
  "physical_RDS_load=1; downstream_fields=6 design-only; actual outcome/exposure fields used=0; actual mortality fits=0",
  "RDS limitation disclosed; only six design fields extracted from the deserialized object; all fitted interfaces use synthetic variables"
)
all_checks <- dplyr::bind_rows(checks)

staging_tag <- paste0(".staging_", run_id)
results_staging <- file.path(root, "results", "v45", staging_tag)
derived_staging <- file.path(
  root, "derived_sensitive", "v45", staging_tag
)
logs_staging <- file.path(root, "logs", "v45", staging_tag)
dir.create(results_staging, recursive = TRUE, showWarnings = FALSE)
dir.create(derived_staging, recursive = TRUE, showWarnings = FALSE)
dir.create(logs_staging, recursive = TRUE, showWarnings = FALSE)
on.exit({
  if (dir.exists(results_staging)) unlink(results_staging, recursive = TRUE)
  if (dir.exists(derived_staging)) unlink(derived_staging, recursive = TRUE)
  if (dir.exists(logs_staging)) unlink(logs_staging, recursive = TRUE)
}, add = TRUE)

contract_staging <- file.path(
  derived_staging, basename(contract_path)
)
v45_atomic_save_rds(contract, contract_staging)
contract_sha <- v45_sha256_file(contract_staging)
contracts$contract_sha256 <- contract_sha
interfaces$run_id <- run_id

tables <- list(
  contracts = contracts,
  structural = all_checks,
  interfaces = interfaces
)
for (name in names(tables)) {
  v45_atomic_write_tsv(
    tables[[name]],
    file.path(results_staging, basename(result_paths[[name]]))
  )
}
log_lines <- c(
  log_lines,
  paste0("completed_at_utc: ",
         format(Sys.time(), "%Y-%m-%dT%H:%M:%SZ", tz = "UTC")),
  paste0("contract_sha256: ", contract_sha),
  "actual_mortality_model_fit_count: 0",
  "synthetic_interface_only: true",
  "next_gate: independent Stage 2 validation"
)
v45_atomic_write_lines(
  log_lines, file.path(logs_staging, basename(log_path))
)

for (name in names(result_paths)) {
  from <- file.path(results_staging, basename(result_paths[[name]]))
  if (!file.rename(from, result_paths[[name]])) {
    stop("Could not promote Stage 2 result: ", name, call. = FALSE)
  }
}
if (!file.rename(contract_staging, contract_path)) {
  stop("Could not promote Rao-Wu replicate contract.", call. = FALSE)
}
if (!file.rename(
  file.path(logs_staging, basename(log_path)), log_path
)) {
  stop("Could not promote Rao-Wu log.", call. = FALSE)
}
unlink(results_staging, recursive = TRUE)
unlink(derived_staging, recursive = TRUE)
unlink(logs_staging, recursive = TRUE)

gate_path <- file.path(root, "work_v45", "gate_state_v45.yml")
gate <- yaml::read_yaml(gate_path)
gate$updated_at <- format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")
gate$stage2_rao_wu_structural_preflight$status <-
  "PASS_PENDING_INDEPENDENT_VALIDATION"
gate$stage2_rao_wu_independent_validation$status <- "NOT_RUN"
gate$outcome_execution_allowed <- FALSE
gate$new_mortality_coefficient_inspection_allowed <- FALSE
gate$production_m50_objects_allowed <- FALSE
gate$next_authorized_step <- "independent_validate_Rao_Wu_preflight"
v45_atomic_write_yaml(gate, gate_path)

message(
  "v45 Stage 2 Rao-Wu preflight passed. Only design fields and synthetic ",
  "interfaces were used; actual outcome gates remain closed."
)
