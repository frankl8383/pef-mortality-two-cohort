# v45 Stage 0: freeze the authoritative predecessor, row-level inputs, code,
# runtime, and blind-result gates before the formal structural preflight.
#
# Usage:
#   Rscript --vanilla R/v45/00_freeze_and_manifest_v45.R --freeze
#   Rscript --vanilla R/v45/00_freeze_and_manifest_v45.R --verify

options(stringsAsFactors = FALSE)

script_root <- function() {
  args <- commandArgs(trailingOnly = FALSE)
  file_arg <- grep("^--file=", args, value = TRUE)
  if (!length(file_arg)) return(normalizePath(getwd(), mustWork = TRUE))
  script <- sub("^--file=", "", file_arg[[1]])
  normalizePath(file.path(dirname(script), "..", ".."), mustWork = TRUE)
}

root <- script_root()
source(file.path(root, "R", "v45", "01_nhanes_common_utilities_v45.R"))
source(file.path(root, "R", "v45", "02_gli_functions_v45.R"))
runtime <- v45_require_packages(root)

relative_path <- function(path) {
  normalized_root <- paste0(normalizePath(root, mustWork = TRUE), "/")
  normalized <- normalizePath(path, mustWork = FALSE)
  if (startsWith(normalized, normalized_root)) {
    substring(normalized, nchar(normalized_root) + 1L)
  } else {
    normalized
  }
}

file_record <- function(
    asset_id, layer, cohort, role, path, restricted, required,
    authorized_purpose, immutable = TRUE) {
  exists <- file.exists(path) && !dir.exists(path)
  info <- if (exists) file.info(path) else NULL
  data.frame(
    asset_id = asset_id,
    layer = layer,
    cohort = cohort,
    role = role,
    path_private = normalizePath(path, mustWork = FALSE),
    path_alias = if (restricted) {
      paste0("LOCAL_RESTRICTED/", basename(path))
    } else {
      relative_path(path)
    },
    restricted = restricted,
    required = required,
    exists = exists,
    regular_file = exists,
    bytes = if (exists) as.numeric(info$size) else NA_real_,
    mtime_utc = if (exists) {
      format(info$mtime, "%Y-%m-%dT%H:%M:%SZ", tz = "UTC")
    } else {
      NA_character_
    },
    sha256 = if (exists) v45_sha256_file(path) else NA_character_,
    authorized_purpose = authorized_purpose,
    immutable = immutable,
    stringsAsFactors = FALSE
  )
}

manifest_root_hash <- function(dat, columns) {
  dat <- dat[do.call(order, dat[intersect(c("asset_id", "path_alias"), names(dat))]), , drop = FALSE]
  payload <- apply(dat[columns], 1L, function(x) paste(x, collapse = "\u241f"))
  digest::digest(paste(payload, collapse = "\n"), algo = "sha256", serialize = FALSE)
}

validate_archive_manifest <- function(
    manifest_path, asset_root, layer, asset_prefix, extra_columns = character()) {
  manifest <- utils::read.csv(
    manifest_path, stringsAsFactors = FALSE, check.names = FALSE
  )
  required <- c("path", "bytes", "sha256")
  if (!all(required %in% names(manifest)) || anyDuplicated(manifest$path)) {
    stop("Invalid predecessor manifest: ", manifest_path, call. = FALSE)
  }
  rows <- lapply(seq_len(nrow(manifest)), function(i) {
    path <- file.path(asset_root, manifest$path[[i]])
    exists <- file.exists(path) && !dir.exists(path)
    bytes <- if (exists) as.numeric(file.info(path)$size) else NA_real_
    sha <- if (exists) v45_sha256_file(path) else NA_character_
    pass <- exists &&
      identical(bytes, as.numeric(manifest$bytes[[i]])) &&
      identical(tolower(sha), tolower(as.character(manifest$sha256[[i]])))
    data.frame(
      asset_id = paste0(asset_prefix, "::", manifest$path[[i]]),
      layer = layer,
      role = "manifest_member",
      path_alias = paste0(asset_prefix, "/", manifest$path[[i]]),
      source_manifest_path = relative_path(manifest_path),
      expected_bytes = as.numeric(manifest$bytes[[i]]),
      current_bytes = bytes,
      expected_sha256 = as.character(manifest$sha256[[i]]),
      current_sha256 = sha,
      status = if (pass) "PASS" else "FAIL",
      immutable = TRUE,
      stringsAsFactors = FALSE
    )
  })
  out <- dplyr::bind_rows(rows)
  if (any(out$status != "PASS")) {
    stop("Predecessor manifest validation failed: ", manifest_path, call. = FALSE)
  }
  out
}

build_predecessor_manifest <- function() {
  archive_root <- file.path(
    root, "output", "code_archive", "PEF_mortality_v44_2_code_candidate"
  )
  archive_manifest <- file.path(archive_root, "MANIFEST.csv")
  submission_root <- file.path(
    root, "output", "submission_v44_2",
    "BMC_Pulmonary_Medicine_PEF_v44_2_candidate"
  )
  submission_manifest <- file.path(submission_root, "MANIFEST.csv")
  archive_rows <- validate_archive_manifest(
    archive_manifest, archive_root, "predecessor_code_archive",
    "V44_2_CODE_ARCHIVE"
  )
  submission_rows <- validate_archive_manifest(
    submission_manifest, submission_root, "predecessor_submission_candidate",
    "V44_2_SUBMISSION"
  )

  formal <- utils::read.csv(
    file.path(root, "results", "v44_2", "baseline_manifest_v44_2.csv"),
    stringsAsFactors = FALSE, check.names = FALSE
  )
  live_paths <- c(
    "work_v44/baseline_characteristics_spec_v44_2.yml",
    "R/v44/06_baseline_characteristics_v44_2.R",
    "results/v44_2/table1_baseline_characteristics_source_v44_2.csv"
  )
  drift_rows <- lapply(live_paths, function(rel) {
    expected <- formal[formal$path == rel, , drop = FALSE]
    if (nrow(expected) != 1L) {
      stop("Formal v44.2 manifest lacks live-drift row: ", rel, call. = FALSE)
    }
    path <- file.path(root, rel)
    current_sha <- v45_sha256_file(path)
    current_bytes <- as.numeric(file.info(path)$size)
    drift <- !identical(
      tolower(current_sha),
      tolower(as.character(expected$sha256[[1]]))
    )
    data.frame(
      asset_id = paste0("V44_2_LIVE::", rel),
      layer = "live_working_copy",
      role = "registered_live_drift",
      path_alias = rel,
      source_manifest_path =
        "results/v44_2/baseline_manifest_v44_2.csv",
      expected_bytes = as.numeric(expected$bytes[[1]]),
      current_bytes = current_bytes,
      expected_sha256 = as.character(expected$sha256[[1]]),
      current_sha256 = current_sha,
      status = if (drift) {
        "LIVE_WORKING_COPY_DRIFT_DO_NOT_OVERWRITE"
      } else {
        "LIVE_WORKING_COPY_MATCHES_FORMAL_DO_NOT_OVERWRITE"
      },
      immutable = FALSE,
      stringsAsFactors = FALSE
    )
  })
  dplyr::bind_rows(archive_rows, submission_rows, dplyr::bind_rows(drift_rows))
}

build_input_manifest <- function() {
  assets <- list(
    c("NHANES_STAGE3_LEDGER", "NHANES", "row_level_ledger",
      "derived_sensitive/v43/nhanes_stage3_analysis_ledger_v43.rds", "MI-B/MI-G/MI-S construction"),
    c("CHARLS_STAGE3_LEDGER", "CHARLS", "row_level_ledger",
      "derived_sensitive/v43/charls_stage3_analysis_ledger_v43.rds", "future CHARLS v45 modules"),
    c("CHARLS_W1_WEIGHT_DONOR", "CHARLS", "restricted_two_field_donor",
      "derived_sensitive/charls/charls_core_harmonized_provisional.rds", "participant_id and weight_kg_w1 only"),
    c("NHANES_E0_SCALE", "NHANES", "aggregate_scale",
      "results/v43/nhanes_e0_scale_v43.csv", "frozen E0/E0b provenance"),
    c("V43_NHANES_CODE_AUTHORITY", "NHANES", "code_authority",
      "output/code_archive/PEF_mortality_v44_2_code_candidate/R/v43/05_nhanes_stage3_primary_mortality.R", "inherited MI-B and passive-BMI helpers"),
    c("LEGACY_GLI_IMPLEMENTATION", "NHANES", "code_authority",
      "R/nhanes/07_nhanes_v0_5_gli_lln_prism_lock.R", "GLI numerical concordance"),
    c("V43_RUNTIME_LOCK", "BOTH", "environment_lock",
      "work_v43/renv.lock", "inherited R package versions"),
    c("V43_NHANES_MI_VALIDATION", "NHANES", "aggregate_validation",
      "results/v43/stage3_preflight_validation_v43.csv", "MI-B signature provenance")
  )
  dplyr::bind_rows(lapply(assets, function(asset) {
    restricted <- grepl("^derived_sensitive/", asset[[4]])
    file_record(
      asset_id = asset[[1]], layer = "input", cohort = asset[[2]],
      role = asset[[3]], path = file.path(root, asset[[4]]),
      restricted = restricted, required = TRUE,
      authorized_purpose = asset[[5]], immutable = TRUE
    )
  }))
}

build_code_manifest <- function() {
  paths <- c(
    "output/qa/V45_0_LITERATURE_INFORMED_REVISION_AND_ANALYSIS_PLAN_20260723.md",
    "work_v45/analysis_spec_v45.yml",
    "work_v45/v45_analysis_registry.tsv",
    "work_v45/v45_estimand_registry.tsv",
    "work_v45/v45_seed_ledger.tsv",
    "work_v45/v45_fatal_warning_whitelist.yml",
    "work_v45/v45_decision_log.md",
    "work_v45/v45_deviation_log.md",
    "R/v45/00_freeze_and_manifest_v45.R",
    "R/v45/01_nhanes_common_utilities_v45.R",
    "R/v45/02_gli_functions_v45.R",
    "R/v45/03_nhanes_mi_preflight_v45.R",
    "R/v45/04_validate_structural_preflight_v45.R"
  )
  dplyr::bind_rows(lapply(paths, function(rel) {
    file_record(
      asset_id = paste0("V45_CODE::", rel),
      layer = "code_authorization", cohort = "BOTH",
      role = if (grepl("^R/", rel)) "executable_code" else "frozen_specification",
      path = file.path(root, rel), restricted = FALSE, required = TRUE,
      authorized_purpose = "v45 Stage 0-1 freeze and no-coefficient structural preflight",
      immutable = TRUE
    )
  }))
}

function_body_sha <- function(fun) {
  digest::digest(
    paste(c(deparse(formals(fun)), deparse(body(fun))), collapse = "\n"),
    algo = "sha256", serialize = FALSE
  )
}

build_runtime_manifest <- function() {
  packages <- c(
    "digest", "dplyr", "haven", "mice", "readr", "rspiro",
    "survey", "survival", "tibble", "tidyr", "yaml"
  )
  package_rows <- lapply(packages, function(pkg) {
    package_path <- find.package(pkg)
    description_path <- file.path(package_path, "DESCRIPTION")
    md5_path <- file.path(package_path, "MD5")
    data.frame(
      component = pkg,
      kind = "R_package",
      version = as.character(utils::packageVersion(pkg)),
      source = package_path,
      sha256 = v45_sha256_file(description_path),
      secondary_sha256 = if (file.exists(md5_path)) {
        v45_sha256_file(md5_path)
      } else {
        NA_character_
      },
      notes = "DESCRIPTION SHA-256; secondary hash is installed-package MD5 index when present",
      stringsAsFactors = FALSE
    )
  })
  rspiro_rows <- lapply(v45_rspiro_function_names(), function(name) {
    fun <- getExportedValue("rspiro", name)
    data.frame(
      component = paste0("rspiro::", name),
      kind = "R_function_body",
      version = as.character(utils::packageVersion("rspiro")),
      source = "rspiro namespace",
      sha256 = function_body_sha(fun),
      secondary_sha256 = NA_character_,
      notes = "formals plus deparsed body",
      stringsAsFactors = FALSE
    )
  })
  soft_versions <- extSoftVersion()
  blas_version <- if ("BLAS" %in% names(soft_versions)) {
    soft_versions[["BLAS"]]
  } else {
    NA_character_
  }
  lapack_version <- if ("LAPACK" %in% names(soft_versions)) {
    soft_versions[["LAPACK"]]
  } else {
    NA_character_
  }
  platform <- data.frame(
    component = c("R", "platform", "timezone", "locale", "BLAS", "LAPACK"),
    kind = c(
      "runtime", "runtime", "runtime", "runtime",
      "linear_algebra", "linear_algebra"
    ),
    version = c(
      as.character(getRversion()), R.version$platform,
      Sys.timezone(), Sys.getlocale(),
      blas_version, lapack_version
    ),
    source = c(
      R.home(), R.version$arch, "Asia/Shanghai", "process locale",
      "extSoftVersion", "extSoftVersion"
    ),
    sha256 = NA_character_,
    secondary_sha256 = NA_character_,
    notes = "frozen runtime metadata",
    stringsAsFactors = FALSE
  )
  dplyr::bind_rows(platform, dplyr::bind_rows(package_rows), dplyr::bind_rows(rspiro_rows))
}

build_source_hash_manifest <- function() {
  v43 <- v45_load_v43_nhanes_functions(root)
  legacy <- v45_load_legacy_gli_functions(root)
  functions <- list(
    "v43::make_mi_input" = v43$make_mi_input,
    "v43::freeze_mi_specification" = v43$freeze_mi_specification,
    "v43::run_mi_checked" = v43$run_mi_checked,
    "v43::reconstruct_released_nhanes_bmi" =
      v43$reconstruct_released_nhanes_bmi,
    "v43::attach_passive_variables" = v43$attach_passive_variables,
    "legacy::fill_gli_global" = legacy$fill_gli_global,
    "legacy::fill_gli2012" = legacy$fill_gli2012,
    "v45::v45_compute_gli" = v45_compute_gli,
    "v45::v45_make_mi_b" = v45_make_mi_b,
    "v45::v45_make_mi_g" = v45_make_mi_g,
    "v45::v45_make_mi_s" = v45_make_mi_s
  )
  data.frame(
    asset_id = names(functions),
    layer = "function_contract",
    sha256 = vapply(functions, function_body_sha, character(1)),
    hash_rule = "SHA-256 of formals plus deparsed body",
    stringsAsFactors = FALSE
  )
}

required_output_paths <- c(
  predecessor = file.path(root, "work_v45", "v45_predecessor_manifest.tsv"),
  input_private = file.path(root, "work_v45", "v45_input_manifest_private.tsv"),
  input_public = file.path(root, "work_v45", "v45_input_manifest_public.tsv"),
  code = file.path(root, "work_v45", "v45_code_authorization_manifest.tsv"),
  runtime = file.path(root, "work_v45", "v45_runtime_manifest.tsv"),
  source = file.path(root, "work_v45", "v45_source_hash_manifest.tsv"),
  roots = file.path(root, "work_v45", "v45_freeze_roots.tsv"),
  validation = file.path(root, "results_v45_stage0_placeholder")
)
required_output_paths[["validation"]] <-
  file.path(root, "results", "v45", "v45_stage0_freeze_validation.tsv")
session_path <- file.path(root, "logs", "v45", "session_info_v45.txt")

build_all <- function() {
  predecessor <- build_predecessor_manifest()
  inputs <- build_input_manifest()
  code <- build_code_manifest()
  runtime_manifest <- build_runtime_manifest()
  source <- build_source_hash_manifest()
  if (any(!inputs$exists) || any(!code$exists)) {
    stop("One or more required v45 input/code assets are absent.", call. = FALSE)
  }
  input_columns <- c(
    "asset_id", "layer", "cohort", "role", "path_alias", "restricted",
    "required", "bytes", "sha256", "authorized_purpose", "immutable"
  )
  code_columns <- input_columns
  roots <- data.frame(
    root_id = c(
      "predecessor_manifest_root", "input_manifest_root",
      "code_manifest_root", "runtime_manifest_root",
      "source_function_root", "seed_ledger", "analysis_spec"
    ),
    sha256 = c(
      manifest_root_hash(
        predecessor,
        c("asset_id", "layer", "path_alias", "expected_sha256",
          "current_sha256", "status")
      ),
      manifest_root_hash(inputs, input_columns),
      manifest_root_hash(code, code_columns),
      manifest_root_hash(
        runtime_manifest,
        c("component", "kind", "version", "sha256", "secondary_sha256")
      ),
      manifest_root_hash(source, c("asset_id", "layer", "sha256")),
      v45_sha256_file(file.path(root, "work_v45", "v45_seed_ledger.tsv")),
      v45_sha256_file(file.path(root, "work_v45", "analysis_spec_v45.yml"))
    ),
    stringsAsFactors = FALSE
  )
  list(
    predecessor = predecessor,
    inputs = inputs,
    code = code,
    runtime = runtime_manifest,
    source = source,
    roots = roots
  )
}

validate_built <- function(objects) {
  checks <- data.frame(
    check = c(
      "archive_and_submission_manifests_complete",
      "live_drift_registered_do_not_overwrite",
      "all_private_inputs_present",
      "all_v45_code_present",
      "runtime_rspiro_0_5",
      "runtime_mice_3_19_0",
      "source_function_hashes_complete",
      "all_root_hashes_well_formed",
      "outcome_execution_remains_blocked"
    ),
    status = c(
      if (all(objects$predecessor$status[
        objects$predecessor$layer != "live_working_copy"
      ] == "PASS")) "PASS" else "FAIL",
      if (all(grepl(
        "DO_NOT_OVERWRITE$",
        objects$predecessor$status[
          objects$predecessor$layer == "live_working_copy"
        ]
      ))) "PASS" else "FAIL",
      if (all(objects$inputs$exists & objects$inputs$regular_file)) "PASS" else "FAIL",
      if (all(objects$code$exists & objects$code$regular_file)) "PASS" else "FAIL",
      if (identical(
        objects$runtime$version[
          objects$runtime$component == "rspiro" &
            objects$runtime$kind == "R_package"
        ],
        "0.5"
      )) "PASS" else "FAIL",
      if (identical(
        objects$runtime$version[
          objects$runtime$component == "mice" &
            objects$runtime$kind == "R_package"
        ],
        "3.19.0"
      )) "PASS" else "FAIL",
      if (nrow(objects$source) == 11L &&
          all(grepl("^[0-9a-f]{64}$", objects$source$sha256))) "PASS" else "FAIL",
      if (all(grepl("^[0-9a-f]{64}$", objects$roots$sha256))) "PASS" else "FAIL",
      "PASS"
    ),
    detail = c(
      paste0(
        "registered predecessor rows=", nrow(objects$predecessor),
        "; non-live failures=",
        sum(objects$predecessor$layer != "live_working_copy" &
              objects$predecessor$status != "PASS")
      ),
      paste0(
        "registered live rows=",
        sum(objects$predecessor$layer == "live_working_copy")
      ),
      paste0("private input rows=", nrow(objects$inputs)),
      paste0("code/specification rows=", nrow(objects$code)),
      "rspiro package and exported calculation functions frozen",
      "inherited v43 mice runtime located without activating root placeholder lock",
      paste0("pure helper functions=", nrow(objects$source)),
      paste0("root hashes=", nrow(objects$roots)),
      "no mortality model was fitted; all coefficient/result gates remain false"
    ),
    stringsAsFactors = FALSE
  )
  if (any(checks$status != "PASS")) {
    stop("Stage 0 freeze validation failed.", call. = FALSE)
  }
  checks
}

update_gate_after_freeze <- function() {
  path <- file.path(root, "work_v45", "gate_state_v45.yml")
  gate <- yaml::read_yaml(path)
  gate$updated_at <- format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")
  gate$stage0_predecessor_and_source_freeze$status <- "PASS"
  gate$stage1_mi_object_structural_preflight$status <- "NOT_RUN"
  gate$stage1_independent_validation$status <- "NOT_RUN"
  gate$outcome_execution_allowed <- FALSE
  gate$new_mortality_coefficient_inspection_allowed <- FALSE
  gate$production_m50_objects_allowed <- FALSE
  gate$next_authorized_step <- "no_model_structural_preflight"
  v45_atomic_write_yaml(gate, path)
}

mode_args <- commandArgs(trailingOnly = TRUE)
mode <- if ("--verify" %in% mode_args) "verify" else "freeze"
objects <- build_all()
checks <- validate_built(objects)

if (identical(mode, "verify")) {
  missing <- required_output_paths[!file.exists(required_output_paths)]
  if (length(missing)) {
    stop("Frozen manifests are absent: ", paste(missing, collapse = ", "), call. = FALSE)
  }
  recorded <- list(
    predecessor = utils::read.delim(required_output_paths[["predecessor"]],
                                    check.names = FALSE),
    inputs = utils::read.delim(required_output_paths[["input_private"]],
                              check.names = FALSE),
    code = utils::read.delim(required_output_paths[["code"]],
                            check.names = FALSE),
    runtime = utils::read.delim(required_output_paths[["runtime"]],
                               check.names = FALSE),
    source = utils::read.delim(required_output_paths[["source"]],
                              check.names = FALSE),
    roots = utils::read.delim(required_output_paths[["roots"]],
                             check.names = FALSE)
  )
  same_fields <- function(recorded_data, current_data, fields, key) {
    recorded_data <- recorded_data[order(recorded_data[[key]]), fields, drop = FALSE]
    current_data <- current_data[order(current_data[[key]]), fields, drop = FALSE]
    recorded_character <- lapply(recorded_data, function(x) {
      out <- as.character(x)
      out[is.na(x)] <- NA_character_
      out[!is.na(out) & !nzchar(out)] <- NA_character_
      out
    })
    current_character <- lapply(current_data, function(x) {
      out <- as.character(x)
      out[is.na(x)] <- NA_character_
      out[!is.na(out) & !nzchar(out)] <- NA_character_
      out
    })
    identical(recorded_character, current_character)
  }
  comparisons <- c(
    predecessor = same_fields(
      recorded$predecessor, objects$predecessor,
      c(
        "asset_id", "layer", "role", "path_alias", "expected_bytes",
        "current_bytes", "expected_sha256", "current_sha256", "status",
        "immutable"
      ),
      "asset_id"
    ),
    inputs = same_fields(
      recorded$inputs, objects$inputs,
      c(
        "asset_id", "layer", "cohort", "role", "path_private",
        "path_alias", "restricted", "required", "exists", "regular_file",
        "bytes", "mtime_utc", "sha256", "authorized_purpose", "immutable"
      ),
      "asset_id"
    ),
    code = same_fields(
      recorded$code, objects$code,
      c(
        "asset_id", "layer", "cohort", "role", "path_private",
        "path_alias", "restricted", "required", "exists", "regular_file",
        "bytes", "mtime_utc", "sha256", "authorized_purpose", "immutable"
      ),
      "asset_id"
    ),
    runtime = same_fields(
      recorded$runtime, objects$runtime,
      c(
        "component", "kind", "version", "source", "sha256",
        "secondary_sha256", "notes"
      ),
      "component"
    ),
    source = same_fields(
      recorded$source, objects$source,
      c("asset_id", "layer", "sha256", "hash_rule"),
      "asset_id"
    ),
    roots = same_fields(
      recorded$roots, objects$roots,
      c("root_id", "sha256"),
      "root_id"
    )
  )
  if (!all(comparisons)) {
    stop(
      "Frozen v45 manifests no longer match current assets: ",
      paste(names(recorded)[!comparisons], collapse = ", "),
      call. = FALSE
    )
  }
  message("v45 Stage 0 frozen manifests verify exactly.")
} else {
  existing <- c(required_output_paths, session_path)
  existing <- existing[file.exists(existing)]
  if (length(existing)) {
    stop(
      "Stage 0 freeze outputs already exist; use --verify: ",
      paste(existing, collapse = "; "),
      call. = FALSE
    )
  }
  freeze_id <- paste0(
    "v45_freeze_", format(Sys.time(), "%Y%m%dT%H%M%S"),
    "_pid", Sys.getpid()
  )
  frozen_at <- format(Sys.time(), "%Y-%m-%dT%H:%M:%SZ", tz = "UTC")
  for (name in names(objects)) {
    objects[[name]]$freeze_id <- freeze_id
    objects[[name]]$frozen_at_utc <- frozen_at
  }
  checks$freeze_id <- freeze_id
  checks$frozen_at_utc <- frozen_at
  public_inputs <- objects$inputs[
    c(
      "asset_id", "layer", "cohort", "role", "path_alias", "restricted",
      "required", "exists", "regular_file", "bytes", "mtime_utc", "sha256",
      "authorized_purpose", "immutable", "freeze_id", "frozen_at_utc"
    )
  ]
  v45_atomic_write_tsv(objects$predecessor, required_output_paths[["predecessor"]])
  v45_atomic_write_tsv(objects$inputs, required_output_paths[["input_private"]])
  v45_atomic_write_tsv(public_inputs, required_output_paths[["input_public"]])
  v45_atomic_write_tsv(objects$code, required_output_paths[["code"]])
  v45_atomic_write_tsv(objects$runtime, required_output_paths[["runtime"]])
  v45_atomic_write_tsv(objects$source, required_output_paths[["source"]])
  v45_atomic_write_tsv(objects$roots, required_output_paths[["roots"]])
  v45_atomic_write_tsv(checks, required_output_paths[["validation"]])
  session_lines <- c(
    paste0("freeze_id: ", freeze_id),
    paste0("frozen_at_utc: ", frozen_at),
    capture.output(sessionInfo()),
    paste0(".libPaths(): ", paste(.libPaths(), collapse = " | "))
  )
  v45_atomic_write_lines(session_lines, session_path)
  update_gate_after_freeze()
  message("v45 Stage 0 predecessor/source/code/runtime freeze passed.")
}
