# v45 Stage 3 production multiple-imputation runner.
#
# Run one frozen object per process:
#   Rscript --vanilla R/v45/09_run_production_mi_v45.R --object=MI-B --m=50
#
# No outcome model is fitted and no completed dataset is persisted.

options(stringsAsFactors = FALSE)

stage3_root <- function() {
  args <- commandArgs(trailingOnly = FALSE)
  file_arg <- grep("^--file=", args, value = TRUE)
  if (!length(file_arg)) return(normalizePath(getwd(), mustWork = TRUE))
  script <- sub("^--file=", "", file_arg[[1]])
  normalizePath(file.path(dirname(script), "..", ".."), mustWork = TRUE)
}

parse_single_argument <- function(name) {
  values <- grep(
    paste0("^--", name, "="),
    commandArgs(trailingOnly = TRUE),
    value = TRUE
  )
  if (length(values) != 1L) {
    stop("Exactly one --", name, "=... argument is required.", call. = FALSE)
  }
  sub(paste0("^--", name, "="), "", values[[1]])
}

main_body <- function() {
root <- stage3_root()
source(file.path(root, "R", "v45", "01_nhanes_common_utilities_v45.R"))
source(file.path(root, "R", "v45", "02_gli_functions_v45.R"))
source(file.path(root, "R", "v45", "legacy_gli_reference_pure_v45.R"))
source(file.path(root, "R", "v45", "production_mi_hashes_v45.R"))
v45_prepend_frozen_library(root)
stage3_packages <- c(
  "digest", "dplyr", "haven", "mice", "readr", "rspiro",
  "tibble", "tidyr", "yaml"
)
missing_stage3_packages <- stage3_packages[
  !vapply(stage3_packages, requireNamespace, logical(1), quietly = TRUE)
]
if (length(missing_stage3_packages) ||
    !identical(as.character(utils::packageVersion("mice")), "3.19.0") ||
    !identical(as.character(utils::packageVersion("rspiro")), "0.5")) {
  stop(
    "Stage 3 production-MI package runtime is incomplete or drifted: ",
    paste(missing_stage3_packages, collapse = ", "),
    call. = FALSE
  )
}
v45_verify_frozen_manifests(root)

object_id <- toupper(parse_single_argument("object"))
m_argument <- parse_single_argument("m")
if (!identical(m_argument, "50")) {
  stop(
    "Stage 3 authorizes only --m=50. Any m=100 promotion requires a ",
    "separately frozen model-stage runner and MCE authorization.",
    call. = FALSE
  )
}
requested_m <- as.integer(m_argument)
if (!object_id %in% c("MI-B", "MI-G", "MI-S")) {
  stop("--object must be exactly MI-B, MI-G, or MI-S.", call. = FALSE)
}
m_label <- paste0("m", requested_m)

verify_output <- system2(
  file.path(R.home("bin"), "Rscript"),
  c(
    "--vanilla",
    file.path(root, "R", "v45", "08_freeze_production_mi_v45.R"),
    "--verify"
  ),
  stdout = TRUE,
  stderr = TRUE
)
verify_status <- attr(verify_output, "status")
if (!is.null(verify_status) && verify_status != 0L) {
  stop(
    "Stage 3 production-MI freeze no longer verifies: ",
    v45_one_line(verify_output),
    call. = FALSE
  )
}

gate_path <- file.path(root, "work_v45", "gate_state_v45.yml")
gate <- yaml::read_yaml(gate_path)
if (!identical(gate$stage3_production_mi_freeze$status, "PASS") ||
    !identical(gate$outcome_execution_allowed, FALSE) ||
    !identical(
      gate$new_mortality_coefficient_inspection_allowed, FALSE
    )) {
  stop("Global gate does not authorize production MI execution.", call. = FALSE)
}
if (!isTRUE(gate$production_m50_objects_allowed)) {
  stop("Production m=50 objects are not authorized.", call. = FALSE)
}

run_id <- paste0(
  "v45_", gsub("-", "", tolower(object_id)), "_", m_label, "_",
  format(Sys.time(), "%Y%m%dT%H%M%S"), "_pid", Sys.getpid()
)
private_parent <- file.path(
  root, "derived_sensitive", "v45", "production_mi", object_id, m_label
)
result_parent <- file.path(
  root, "results", "v45", "production_mi", object_id, m_label
)
private_staging <- file.path(private_parent, paste0(".staging_", run_id))
result_staging <- file.path(result_parent, paste0(".staging_", run_id))
private_final <- file.path(private_parent, run_id)
result_final <- file.path(result_parent, run_id)
current_pointer <- file.path(
  root, "results", "v45", "production_mi",
  paste0(gsub("-", "_", object_id), "_", m_label, "_current.tsv")
)
if (file.exists(current_pointer) || dir.exists(private_final) ||
    dir.exists(result_final) || dir.exists(private_staging) ||
    dir.exists(result_staging)) {
  stop("A current or same-run production object already exists; refusing overwrite.",
       call. = FALSE)
}
lock_parent <- file.path(
  root, "derived_sensitive", "v45", "production_mi"
)
dir.create(lock_parent, recursive = TRUE, showWarnings = FALSE)
execution_lock <- file.path(lock_parent, ".stage3_production_execution.lock")
if (!dir.create(execution_lock, showWarnings = FALSE)) {
  stop(
    "Another Stage 3 production-MI process holds the global execution lock.",
    call. = FALSE
  )
}
on.exit(
  if (dir.exists(execution_lock)) unlink(execution_lock, recursive = TRUE),
  add = TRUE
)
dir.create(private_staging, recursive = TRUE, showWarnings = FALSE)
dir.create(result_staging, recursive = TRUE, showWarnings = FALSE)
transaction_committed <- FALSE
failure_recorded <- FALSE
on.exit({
  if (!transaction_committed && !failure_recorded) {
    try({
      dir.create(failure_dir, recursive = TRUE, showWarnings = FALSE)
      v45_atomic_write_tsv(
        data.frame(
          run_id = run_id,
          object_id = object_id,
          requested_m = requested_m,
          status = "FAIL_NO_MIDS_SAVED",
          error_class = "unhandled_stage3_error",
          error_message = v45_one_line(geterrmessage()),
          checkpoint_rows = 0L,
          failed_at_utc =
            format(Sys.time(), "%Y-%m-%dT%H:%M:%SZ", tz = "UTC"),
          stringsAsFactors = FALSE
        ),
        file.path(failure_dir, paste0(run_id, "_failure.tsv"))
      )
      gate_unhandled <- yaml::read_yaml(gate_path)
      if (requested_m == 50L) {
        if (is.null(
          gate_unhandled$stage3_production_mi_execution$objects
        )) {
          gate_unhandled$stage3_production_mi_execution$objects <- list()
        }
        gate_unhandled$stage3_production_mi_execution$objects[[object_id]] <-
          list(status = "FAIL_NO_MIDS_SAVED", run_id = run_id)
        gate_unhandled$stage3_production_mi_execution$status <- "FAILED"
      } else {
        if (is.null(
          gate_unhandled$stage3_production_mi_m100_execution$objects
        )) {
          gate_unhandled$stage3_production_mi_m100_execution$objects <- list()
        }
        gate_unhandled$stage3_production_mi_m100_execution$objects[[object_id]] <-
          list(status = "FAIL_NO_MIDS_SAVED", run_id = run_id)
        gate_unhandled$stage3_production_mi_m100_execution$status <- "FAILED"
      }
      gate_unhandled$outcome_execution_allowed <- FALSE
      gate_unhandled$new_mortality_coefficient_inspection_allowed <- FALSE
      gate_unhandled$next_authorized_step <- paste0(
        "review_production_MI_failure_", gsub("-", "_", object_id),
        "_", m_label
      )
      v45_atomic_write_yaml(gate_unhandled, gate_path)
    }, silent = TRUE)
  }
  if (dir.exists(private_staging)) unlink(private_staging, recursive = TRUE)
  if (dir.exists(result_staging)) unlink(result_staging, recursive = TRUE)
  if (!transaction_committed) {
    if (dir.exists(private_final)) unlink(private_final, recursive = TRUE)
    if (dir.exists(result_final)) unlink(result_final, recursive = TRUE)
    if (file.exists(current_pointer)) unlink(current_pointer)
  }
}, add = TRUE)

log_lines <- c(
  paste0("run_id: ", run_id),
  paste0("object_id: ", object_id),
  paste0("requested_m: ", requested_m),
  paste0(
    "started_at_utc: ",
    format(Sys.time(), "%Y-%m-%dT%H:%M:%SZ", tz = "UTC")
  ),
  "mortality_model_fit_count: 0",
  "coefficient_export_count: 0",
  "completed_dataset_persistence_count: 0",
  "new_mortality_result_visibility: BLOCKED"
)
append_log <- function(...) {
  text <- paste0(...)
  log_lines <<- c(
    log_lines,
    paste0(format(Sys.time(), "%H:%M:%S"), " ", text)
  )
  message(text)
}

failure_dir <- file.path(
  root, "results", "v45", "production_mi", "failures"
)
record_failure <- function(error, checkpoint_diagnostics = NULL) {
  failure_recorded <<- TRUE
  dir.create(failure_dir, recursive = TRUE, showWarnings = FALSE)
  failure <- data.frame(
    run_id = run_id,
    object_id = object_id,
    requested_m = requested_m,
    status = "FAIL_NO_MIDS_SAVED",
    error_class = paste(class(error), collapse = "|"),
    error_message = v45_one_line(conditionMessage(error)),
    checkpoint_rows = if (is.null(checkpoint_diagnostics)) {
      0L
    } else {
      nrow(checkpoint_diagnostics)
    },
    failed_at_utc = format(Sys.time(), "%Y-%m-%dT%H:%M:%SZ", tz = "UTC"),
    stringsAsFactors = FALSE
  )
  v45_atomic_write_tsv(
    failure, file.path(failure_dir, paste0(run_id, "_failure.tsv"))
  )
  if (!is.null(checkpoint_diagnostics) && nrow(checkpoint_diagnostics)) {
    v45_atomic_write_tsv(
      checkpoint_diagnostics,
      file.path(
        failure_dir, paste0(run_id, "_checkpoint_diagnostics.tsv")
      )
    )
  }
  if (dir.exists(private_staging)) unlink(private_staging, recursive = TRUE)
  if (dir.exists(result_staging)) unlink(result_staging, recursive = TRUE)
  gate_failure <- yaml::read_yaml(gate_path)
  if (requested_m == 50L) {
    if (is.null(gate_failure$stage3_production_mi_execution$objects)) {
      gate_failure$stage3_production_mi_execution$objects <- list()
    }
    gate_failure$stage3_production_mi_execution$objects[[object_id]] <-
      list(status = "FAIL_NO_MIDS_SAVED", run_id = run_id)
    gate_failure$stage3_production_mi_execution$status <- "FAILED"
  } else {
    if (is.null(
      gate_failure$stage3_production_mi_m100_execution$objects
    )) {
      gate_failure$stage3_production_mi_m100_execution$objects <- list()
    }
    gate_failure$stage3_production_mi_m100_execution$objects[[object_id]] <-
      list(status = "FAIL_NO_MIDS_SAVED", run_id = run_id)
    gate_failure$stage3_production_mi_m100_execution$status <- "FAILED"
  }
  gate_failure$outcome_execution_allowed <- FALSE
  gate_failure$new_mortality_coefficient_inspection_allowed <- FALSE
  gate_failure$next_authorized_step <-
    paste0("review_production_MI_failure_", gsub("-", "_", object_id))
  v45_atomic_write_yaml(gate_failure, gate_path)
  invisible(failure)
}

input_contract_path <- file.path(
  root, "derived_sensitive", "v45", "v45_production_mi_input_contract.rds"
)
input_contracts <- readRDS(input_contract_path)
if (!identical(
      unname(input_contracts$RNGkind),
      c("Mersenne-Twister", "Inversion", "Rejection")
    ) ||
    !identical(input_contracts$R_version, as.character(getRversion()))) {
  stop("Frozen production-MI runtime/RNG contract is invalid.", call. = FALSE)
}
RNGkind(
  kind = "Mersenne-Twister",
  normal.kind = "Inversion",
  sample.kind = "Rejection"
)
if (!identical(
      RNGkind(),
      c("Mersenne-Twister", "Inversion", "Rejection")
    )) {
  stop("Could not establish the frozen production-MI RNGkind.", call. = FALSE)
}
expected <- input_contracts$objects[[object_id]]
if (is.null(expected)) stop("Frozen object input contract is absent.", call. = FALSE)

append_log("Reconstructing the frozen object from the authorized ledger.")
ledger <- v45_read_nhanes_ledger(root)
v43 <- v45_load_v43_nhanes_functions(root)
required_v43 <- c(
  "run_mi_convergence_schedule", "mice_chain_convergence",
  "mice_chain_trace", "format_mice_convergence_failures",
  "validate_nhanes_passive_bmi_state"
)
missing_v43 <- required_v43[
  !vapply(required_v43, exists, logical(1), envir = v43, inherits = FALSE)
]
if (length(missing_v43)) {
  stop(
    "Frozen v43 environment lacks production functions: ",
    paste(missing_v43, collapse = ", "),
    call. = FALSE
  )
}
object <- switch(
  object_id,
  `MI-B` = v45_make_mi_b(ledger, v43),
  `MI-G` = v45_make_mi_g(ledger, v43, seed = 450201L),
  `MI-S` = v45_make_mi_s(ledger, v43, seed = 450301L)
)
rm(ledger)
invisible(gc(verbose = FALSE))

data_contract <- v45_canonical_data_frame_contract(object$data)
specification <- object$specification
ids <- v45_as_num(as.character(object$data$SEQN))
current_contract <- list(
  denominator_n = nrow(object$data),
  canonical_data_sha256 = data_contract$sha256,
  column_contract_sha256 =
    v45_canonical_data_frame_contract(data_contract$columns)$sha256,
  missing_contract_sha256 = v45_canonical_data_frame_contract(data.frame(
    column_index = seq_along(object$data),
    column_name = names(object$data),
    missing_n = vapply(object$data, function(x) sum(is.na(x)), integer(1)),
    stringsAsFactors = FALSE
  ))$sha256,
  ordered_id_sha256_canonical =
    v45_canonical_array_sha256(as.integer(ids)),
  specification_sha256_canonical =
    v45_canonical_object_sha256(specification),
  method_sha256 =
    v45_canonical_named_character_sha256(specification$method),
  predictor_matrix_sha256 =
    v45_canonical_array_sha256(specification$predictor_matrix),
  where_sha256 = v45_canonical_array_sha256(specification$where),
  visit_sequence_sha256 =
    v45_canonical_vector_contract(specification$visit_sequence)$values_sha256,
  seed = as.integer(specification$seed),
  initial_m = as.integer(specification$initial_m),
  maximum_m = as.integer(specification$maximum_m),
  convergence_checkpoints =
    as.integer(specification$convergence_iteration_checkpoints)
)
contract_fields <- names(current_contract)
contract_ok <- vapply(contract_fields, function(name) {
  identical(current_contract[[name]], expected[[name]])
}, logical(1))
if (!all(contract_ok)) {
  error <- simpleError(paste0(
    "Frozen input contract mismatch: ",
    paste(contract_fields[!contract_ok], collapse = ", ")
  ))
  record_failure(error)
  stop(conditionMessage(error), call. = FALSE)
}
if (requested_m == 50L && requested_m != specification$initial_m) {
  stop("Requested m does not match the frozen initial m.", call. = FALSE)
}
if (requested_m == 100L && requested_m != specification$maximum_m) {
  stop("Requested m does not match the frozen maximum m.", call. = FALSE)
}
if (object_id == "MI-B" &&
    !identical(
      v45_mi_signature_v43_nhanes(specification),
      "f02674d75f213a424cbcc4f1617a89c6cfbc8258af45c64d779ca3fb5153e685"
    )) {
  stop("MI-B inherited signature drifted.", call. = FALSE)
}
if (object_id == "MI-S") {
  forbidden <- v45_forbidden_mi_s_fields(names(object$data))
  active_nonpassive <- setdiff(
    names(specification$method)[nzchar(specification$method)], "bmi"
  )
  if (length(forbidden) || nzchar(specification$method[["R_A"]]) ||
      !all(
        specification$predictor_matrix[active_nonpassive, "R_A"] == 1
      )) {
    stop("MI-S measurement exclusion or fixed-response contract failed.",
         call. = FALSE)
  }
}

append_log(
  "Starting ", object_id, " ", m_label,
  " at frozen checkpoints 20 -> 40 -> 80. No outcome model will be fitted."
)
started_elapsed <- proc.time()[["elapsed"]]
schedule <- tryCatch(
  withCallingHandlers(
    v43$run_mi_convergence_schedule(
      object$data,
      specification,
      m = requested_m,
      imputation_id = object_id,
      mi_run = m_label
    ),
    warning = function(w) {
      stop(
        "Unexpected warning escaped the frozen MICE warning gate: ",
        conditionMessage(w),
        call. = FALSE
      )
    }
  ),
  error = function(e) {
    checkpoint <- if (
      inherits(e, "stage3_mice_convergence_error") &&
        !is.null(e$checkpoint_diagnostics)
    ) {
      e$checkpoint_diagnostics
    } else {
      NULL
    }
    record_failure(e, checkpoint)
    stop(e)
  }
)
elapsed_seconds <- proc.time()[["elapsed"]] - started_elapsed
imp <- schedule$imp
final_convergence <- schedule$final_convergence
checkpoint_diagnostics <- schedule$checkpoint_diagnostics
selected_maxit <- as.integer(schedule$selected_maxit)
required_convergence_fields <- c(
  "parameter", "hard_gate", "pass"
)
if (!is.data.frame(final_convergence) || !nrow(final_convergence) ||
    !all(required_convergence_fields %in% names(final_convergence))) {
  error <- simpleError(
    "The selected convergence table is empty or lacks required fields."
  )
  record_failure(error, checkpoint_diagnostics)
  stop(conditionMessage(error), call. = FALSE)
}
hard_convergence_rows <- final_convergence$hard_gate %in% TRUE
variation_rows <- final_convergence$parameter ==
  "final_between_imputation_variation"
append_log(
  "MICE completed at selected checkpoint ", selected_maxit,
  " in ", round(elapsed_seconds, 1), " seconds."
)

logged_event_n <- if (is.null(imp$loggedEvents)) 0L else nrow(imp$loggedEvents)
where_values_exact <- is.matrix(imp$where) &&
  is.matrix(specification$where) &&
  identical(typeof(imp$where), "logical") &&
  identical(dim(imp$where), dim(specification$where)) &&
  identical(unname(imp$where), unname(specification$where))
where_dimnames_normalized_to_input <- identical(
  dimnames(imp$where), dimnames(imp$data)
)
structural_checks <- c(
  class_is_mids = inherits(imp, "mids"),
  requested_m_exact = identical(as.integer(imp$m), requested_m),
  selected_iteration_exact =
    identical(as.integer(imp$iteration), selected_maxit),
  selected_checkpoint_allowed =
    selected_maxit %in% specification$convergence_iteration_checkpoints,
  logged_events_zero = logged_event_n == 0L,
  method_exact = identical(imp$method, specification$method),
  predictor_matrix_exact =
    identical(imp$predictorMatrix, specification$predictor_matrix),
  where_cell_values_exact = where_values_exact,
  where_dimnames_normalized_to_input =
    where_dimnames_normalized_to_input,
  visit_sequence_exact =
    identical(as.character(imp$visitSequence),
              as.character(specification$visit_sequence)),
  input_data_exact =
    identical(
      v45_canonical_data_frame_contract(imp$data)$sha256,
      expected$canonical_data_sha256
    ),
  hard_convergence_rows_present = any(hard_convergence_rows),
  selected_hard_convergence_pass =
    any(hard_convergence_rows) &&
      all(final_convergence$pass[hard_convergence_rows] %in% TRUE),
  final_variation_rows_present = any(variation_rows),
  final_variation_pass =
    any(variation_rows) &&
      all(final_convergence$pass[variation_rows] %in% TRUE)
)
if (!all(structural_checks)) {
  error <- simpleError(paste0(
    "Post-MICE structural contract failed: ",
    paste(names(structural_checks)[!structural_checks], collapse = ", ")
  ))
  record_failure(error, checkpoint_diagnostics)
  stop(conditionMessage(error), call. = FALSE)
}

append_log("Auditing all completed datasets transiently; none will be saved.")
bmi_audit_value <- v45_passive_bmi_audit(imp, object$data, v43)
if (!isTRUE(bmi_audit_value$pass)) {
  error <- simpleError("Passive BMI audit failed.")
  record_failure(error, checkpoint_diagnostics)
  stop(conditionMessage(error), call. = FALSE)
}

observed_change_n <- 0L
response_change_n <- 0L
completed_structure_failure_n <- 0L
gli_audit <- data.frame()
gli_hashes <- data.frame()
observed_height <- !is.na(object$data$height_cm)
missing_height <- !observed_height
gli_reference_observed <- NULL
imputed_height_values <- if (object_id == "MI-G") {
  matrix(
    NA_real_, nrow = sum(missing_height), ncol = requested_m
  )
} else {
  NULL
}
imputed_gli_values <- if (object_id == "MI-G") {
  matrix(
    NA_real_, nrow = sum(missing_height), ncol = requested_m
  )
} else {
  NULL
}
gli_all_finite <- TRUE
gli_observed_max_difference <- 0

for (chain in seq_len(requested_m)) {
  completed <- mice::complete(imp, action = chain)
  for (name in names(object$data)) {
    structure_ok <- identical(
      class(completed[[name]]), class(object$data[[name]])
    ) && (
      !is.factor(object$data[[name]]) ||
        (
          identical(
            levels(completed[[name]]), levels(object$data[[name]])
          ) &&
            identical(
              is.ordered(completed[[name]]),
              is.ordered(object$data[[name]])
            )
        )
    )
    completed_structure_failure_n <-
      completed_structure_failure_n + as.integer(!structure_ok)
    observed <- !is.na(object$data[[name]])
    changed <- if (is.factor(object$data[[name]]) ||
                   is.character(object$data[[name]])) {
      as.character(completed[[name]][observed]) !=
        as.character(object$data[[name]][observed])
    } else {
      completed[[name]][observed] != object$data[[name]][observed]
    }
    observed_change_n <- observed_change_n + sum(
      is.na(changed) | changed
    )
  }
  if (object_id == "MI-S") {
    response_changed <-
      as.character(completed$R_A) != as.character(object$data$R_A)
    response_change_n <- response_change_n + sum(
      is.na(response_changed) | response_changed
    )
  }
  if (object_id == "MI-G") {
    gli <- v45_compute_gli(completed)
    gli_hashes <- dplyr::bind_rows(
      gli_hashes,
      data.frame(
        object_id = object_id,
        imputation = chain,
        gli_canonical_sha256 =
          v45_canonical_data_frame_contract(gli)$sha256,
        stringsAsFactors = FALSE
      )
    )
    gli_all_finite <- gli_all_finite &&
      all(is.finite(as.matrix(gli)))
    if (chain == 1L) {
      gli_reference_observed <- gli[observed_height, , drop = FALSE]
    } else {
      difference <- abs(
        as.matrix(gli[observed_height, , drop = FALSE]) -
          as.matrix(gli_reference_observed)
      )
      gli_observed_max_difference <- max(
        gli_observed_max_difference, difference
      )
    }
    imputed_height_values[, chain] <- completed$height_cm[missing_height]
    imputed_gli_values[, chain] <-
      gli$gli_global2022_z_fev1[missing_height]
    rm(gli)
  }
  rm(completed)
  if (chain %% 5L == 0L || chain == requested_m) {
    invisible(gc(verbose = FALSE))
  }
}
if (observed_change_n != 0L || response_change_n != 0L ||
    completed_structure_failure_n != 0L) {
  error <- simpleError(paste0(
    "Observed-value preservation failed: observed_changes=",
    observed_change_n, "; response_changes=", response_change_n,
    "; structure_failures=", completed_structure_failure_n
  ))
  record_failure(error, checkpoint_diagnostics)
  stop(conditionMessage(error), call. = FALSE)
}

if (object_id == "MI-G") {
  legacy <- v45_validate_gli_against_pure_reference(
    object$data[observed_height, , drop = FALSE]
  )
  first_missing <- which(missing_height)[[1]]
  perturb_before <- mice::complete(imp, action = 1L)[
    first_missing, , drop = FALSE
  ]
  perturb_after <- perturb_before
  perturb_after$height_cm <- perturb_after$height_cm + 0.1
  gli_before <- v45_compute_gli(perturb_before)
  gli_after <- v45_compute_gli(perturb_after)
  dependency_fields <- c(
    "gli_global2022_z_fev1", "gli_global2022_z_fvc",
    "gli_global2022_z_fev1_fvc", "gli2012_z_fev1",
    "gli2012_z_fvc", "gli2012_z_fev1_fvc"
  )
  dependency_differences <- vapply(
    dependency_fields,
    function(name) abs(gli_before[[name]] - gli_after[[name]]),
    numeric(1)
  )
  height_varying_rows <- sum(apply(
    imputed_height_values, 1L, function(x) length(unique(x)) > 1L
  ))
  gli_varying_rows <- sum(apply(
    imputed_gli_values, 1L, function(x) length(unique(x)) > 1L
  ))
  gli_audit <- dplyr::bind_rows(
    data.frame(
      check = "all_completed_GLI_fields_finite",
      observed = paste0("imputations=", requested_m),
      threshold = "all finite",
      status = if (gli_all_finite) "PASS" else "FAIL",
      stringsAsFactors = FALSE
    ),
    data.frame(
      check = "observed_height_GLI_invariant_across_imputations",
      observed = sprintf("%.17g", gli_observed_max_difference),
      threshold = "exactly 0",
      status = if (gli_observed_max_difference == 0) "PASS" else "FAIL",
      stringsAsFactors = FALSE
    ),
    data.frame(
      check = "legacy_GLI_concordance_on_observed_height",
      observed = sprintf(
        "fields=%d; max_difference=%.17g",
        legacy$fields_compared, legacy$maximum_absolute_difference
      ),
      threshold = sprintf("%.17g", legacy$tolerance),
      status = if (legacy$pass) "PASS" else "FAIL",
      stringsAsFactors = FALSE
    ),
    data.frame(
      check = "explicit_completed_height_dependency",
      observed = paste(
        names(dependency_differences),
        sprintf("%.17g", dependency_differences),
        sep = "=",
        collapse = ";"
      ),
      threshold = "all six fields change after +0.1 cm",
      status = if (all(dependency_differences > 0)) "PASS" else "FAIL",
      stringsAsFactors = FALSE
    ),
    data.frame(
      check = "imputed_height_and_GLI_between_imputation_variation",
      observed = paste0(
        "height_rows=", height_varying_rows, "/", sum(missing_height),
        "; GLI_rows=", gli_varying_rows, "/", sum(missing_height)
      ),
      threshold = "at least one varying row for height and passive GLI",
      status = if (
        height_varying_rows > 0L && gli_varying_rows > 0L
      ) "PASS" else "FAIL",
      stringsAsFactors = FALSE
    ),
    data.frame(
      check = "GLI_not_persisted_in_mids_FCS",
      observed = paste0(
        "GLI_columns=", sum(grepl("^gli|^L_", names(imp$data)))
      ),
      threshold = "0",
      status = if (
        !any(grepl("^gli|^L_", names(imp$data)))
      ) "PASS" else "FAIL",
      stringsAsFactors = FALSE
    )
  )
  if (!all(gli_audit$status == "PASS")) {
    error <- simpleError(paste0(
      "MI-G passive GLI audit failed: ",
      paste(gli_audit$check[gli_audit$status != "PASS"], collapse = ", ")
    ))
    record_failure(error, checkpoint_diagnostics)
    stop(conditionMessage(error), call. = FALSE)
  }
  rm(
    gli_reference_observed, imputed_height_values, imputed_gli_values,
    perturb_before, perturb_after, gli_before, gli_after
  )
  invisible(gc(verbose = FALSE))
}

trace <- v43$mice_chain_trace(
  imp, final_convergence, object$data, specification, object_id
)
category_trace <- attr(imp, "category_trace", exact = TRUE)
if (is.null(category_trace)) {
  category_trace <- data.frame(
    variable = character(), category_level = character(),
    iteration = integer(), chain = integer(), missing_n = integer(),
    value = numeric(), stringsAsFactors = FALSE
  )
}

component_hashes <- data.frame(
  component = c(
    "canonical_source_input_data",
    "canonical_column_types_factor_levels_and_ordered_flags",
    "canonical_frozen_specification",
    "canonical_ordered_participant_ids",
    "canonical_imputation_payload", "canonical_chain_mean",
    "canonical_chain_variance", "canonical_categorical_trace",
    "canonical_final_convergence",
    "canonical_checkpoint_diagnostics", "canonical_released_trace",
    "mids_method", "mids_predictor_matrix", "mids_where",
    "mids_visit_sequence", "mids_last_seed_value"
  ),
  sha256 = c(
    expected$canonical_data_sha256,
    expected$column_contract_sha256,
    v45_canonical_object_sha256(specification),
    v45_canonical_array_sha256(as.integer(ids)),
    v45_canonical_imputation_payload_sha256(imp),
    v45_canonical_array_sha256(imp$chainMean),
    v45_canonical_array_sha256(imp$chainVar),
    v45_canonical_data_frame_contract(category_trace)$sha256,
    v45_canonical_data_frame_contract(final_convergence)$sha256,
    v45_canonical_data_frame_contract(checkpoint_diagnostics)$sha256,
    v45_canonical_data_frame_contract(trace)$sha256,
    v45_canonical_named_character_sha256(imp$method),
    v45_canonical_array_sha256(imp$predictorMatrix),
    v45_canonical_array_sha256(imp$where),
    v45_canonical_vector_contract(
      as.character(imp$visitSequence)
    )$values_sha256,
    v45_canonical_array_sha256(as.integer(imp$lastSeedValue))
  ),
  hash_rule = c(
    "canonical_data_frame_v1",
    rep("canonical_type_explicit_v1", 15L)
  ),
  stringsAsFactors = FALSE
)
if (any(!grepl("^[0-9a-f]{64}$", component_hashes$sha256))) {
  error <- simpleError("One or more production component hashes are invalid.")
  record_failure(error, checkpoint_diagnostics)
  stop(conditionMessage(error), call. = FALSE)
}

bmi_audit <- data.frame(
  object_id = object_id,
  requested_m = requested_m,
  bmi_missing_n = bmi_audit_value$bmi_missing_n,
  observed_bmi_n = bmi_audit_value$observed_bmi_n,
  observed_bmi_change_n = bmi_audit_value$observed_bmi_change_n,
  maximum_identity_difference =
    bmi_audit_value$maximum_identity_difference,
  invalid_completed_parent_n =
    bmi_audit_value$invalid_completed_parent_n,
  all_observed_field_change_n = observed_change_n,
  response_change_n = response_change_n,
  completed_structure_failure_n = completed_structure_failure_n,
  status = "PASS",
  stringsAsFactors = FALSE
)
structural <- data.frame(
  check = names(structural_checks),
  status = ifelse(structural_checks, "PASS", "FAIL"),
  run_id = run_id,
  stringsAsFactors = FALSE
)

attr(imp, "v45_production_metadata") <- list(
  contract_version = "v45_0_stage3",
  run_id = run_id,
  object_id = object_id,
  requested_m = requested_m,
  selected_maxit = selected_maxit,
  generation_status = "GENERATED_AWAITING_INDEPENDENT_VALIDATION",
  mortality_model_fit_count = 0L,
  coefficient_export_count = 0L,
  completed_dataset_persistence_count = 0L,
  component_hashes_before_file_save = component_hashes
)
mids_name <- paste0(object_id, "_", m_label, ".mids.rds")
mids_staging_path <- file.path(private_staging, mids_name)
v45_atomic_save_rds(imp, mids_staging_path)
mids_sha <- v45_sha256_file(mids_staging_path)
component_hashes <- dplyr::bind_rows(
  component_hashes,
  data.frame(
    component = "final_mids_file",
    sha256 = mids_sha,
    hash_rule = "SHA-256 of restricted xz-compressed RDS bytes",
    stringsAsFactors = FALSE
  )
)

private_relative <- file.path(
  "derived_sensitive", "v45", "production_mi",
  object_id, m_label, run_id, mids_name
)
result_relative <- file.path(
  "results", "v45", "production_mi",
  object_id, m_label, run_id
)
run_manifest <- data.frame(
  run_id = run_id,
  object_id = object_id,
  requested_m = requested_m,
  selected_maxit = selected_maxit,
  elapsed_seconds = round(elapsed_seconds, 3),
  denominator_n = nrow(object$data),
  event_anchor_n = expected$event_anchor_n,
  response_anchor_n = expected$response_anchor_n,
  hard_convergence_rows = sum(final_convergence$hard_gate %in% TRUE),
  failed_hard_convergence_rows = sum(
    final_convergence$hard_gate %in% TRUE &
      !(final_convergence$pass %in% TRUE)
  ),
  warning_count = 0L,
  logged_event_count = logged_event_n,
  mortality_model_fit_count = 0L,
  coefficient_export_count = 0L,
  completed_dataset_persistence_count = 0L,
  mids_path_alias = private_relative,
  mids_bytes = as.numeric(file.info(mids_staging_path)$size),
  mids_sha256 = mids_sha,
  result_path_alias = result_relative,
  status = "GENERATED_AWAITING_INDEPENDENT_VALIDATION",
  completed_at_utc =
    format(Sys.time(), "%Y-%m-%dT%H:%M:%SZ", tz = "UTC"),
  stringsAsFactors = FALSE
)

append_log("Writing aggregate diagnostics and restricted mids transaction.")
v45_atomic_write_tsv(
  run_manifest, file.path(result_staging, "run_manifest.tsv")
)
v45_atomic_write_tsv(
  component_hashes, file.path(result_staging, "component_hashes.tsv")
)
v45_atomic_write_tsv(
  structural, file.path(result_staging, "structural_checks.tsv")
)
v45_atomic_write_tsv(
  checkpoint_diagnostics,
  file.path(result_staging, "checkpoint_diagnostics.tsv")
)
v45_atomic_write_tsv(
  final_convergence, file.path(result_staging, "final_convergence.tsv")
)
v45_atomic_write_tsv(
  trace, file.path(result_staging, "released_chain_trace.tsv")
)
v45_atomic_write_tsv(
  bmi_audit, file.path(result_staging, "passive_bmi_audit.tsv")
)
if (object_id == "MI-G") {
  v45_atomic_write_tsv(
    gli_audit, file.path(result_staging, "passive_gli_audit.tsv")
  )
  v45_atomic_write_tsv(
    gli_hashes, file.path(result_staging, "passive_gli_hashes.tsv")
  )
}
append_log("Transaction is complete and awaiting independent validation.")
v45_atomic_write_lines(
  c(
    log_lines,
    paste0(
      "completed_at_utc: ",
      format(Sys.time(), "%Y-%m-%dT%H:%M:%SZ", tz = "UTC")
    ),
    "status: GENERATED_AWAITING_INDEPENDENT_VALIDATION"
  ),
  file.path(result_staging, "run.log")
)

if (!file.rename(private_staging, private_final)) {
  stop("Could not atomically publish the restricted MI run directory.",
       call. = FALSE)
}
if (!file.rename(result_staging, result_final)) {
  stop("Could not atomically publish the aggregate MI run directory.",
       call. = FALSE)
}
pointer <- data.frame(
  object_id = object_id,
  requested_m = requested_m,
  run_id = run_id,
  run_manifest_path_alias =
    file.path(result_relative, "run_manifest.tsv"),
  mids_path_alias = private_relative,
  mids_sha256 = mids_sha,
  status = "GENERATED_AWAITING_INDEPENDENT_VALIDATION",
  stringsAsFactors = FALSE
)
v45_atomic_write_tsv(pointer, current_pointer)

gate_success <- yaml::read_yaml(gate_path)
object_gate_value <- list(
  status = "GENERATED_AWAITING_INDEPENDENT_VALIDATION",
  m = requested_m,
  run_id = run_id,
  selected_maxit = selected_maxit,
  mids_sha256 = mids_sha
)
if (requested_m == 50L) {
  if (is.null(gate_success$stage3_production_mi_execution$objects)) {
    gate_success$stage3_production_mi_execution$objects <- list()
  }
  gate_success$stage3_production_mi_execution$objects[[object_id]] <-
    object_gate_value
  all_m50_pointers <- file.exists(file.path(
    root, "results", "v45", "production_mi",
    paste0(c("MI_B", "MI_G", "MI_S"), "_m50_current.tsv")
  ))
  gate_success$stage3_production_mi_execution$status <- if (
    all(all_m50_pointers)
  ) {
    "GENERATED_ALL_AWAITING_INDEPENDENT_VALIDATION"
  } else {
    "IN_PROGRESS"
  }
  gate_success$next_authorized_step <- if (
    identical(
      gate_success$stage3_production_mi_execution$status,
      "GENERATED_ALL_AWAITING_INDEPENDENT_VALIDATION"
    )
  ) {
    "independently_validate_production_m50_MI_objects"
  } else {
    "continue_remaining_production_m50_MI_objects"
  }
} else {
  if (is.null(gate_success$stage3_production_mi_m100_execution$objects)) {
    gate_success$stage3_production_mi_m100_execution$objects <- list()
  }
  gate_success$stage3_production_mi_m100_execution$objects[[object_id]] <-
    object_gate_value
  gate_success$stage3_production_mi_m100_execution$status <-
    "GENERATED_AWAITING_INDEPENDENT_VALIDATION"
  gate_success$next_authorized_step <- paste0(
    "independently_validate_", gsub("-", "_", object_id),
    "_m100_then_rerun_complete_registered_model_family"
  )
}
gate_success$outcome_execution_allowed <- FALSE
gate_success$new_mortality_coefficient_inspection_allowed <- FALSE
gate_success$updated_at <- format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")
v45_atomic_write_yaml(gate_success, gate_path)
transaction_committed <- TRUE

message(
  object_id, " ", m_label,
  " generated and awaiting independent validation. No outcome model was fitted."
)
}

main <- function() {
  withCallingHandlers(
    main_body(),
    warning = function(w) {
      stop(
        "Stage 3 production-MI warning promoted to fatal error: ",
        conditionMessage(w),
        call. = FALSE
      )
    }
  )
}

main()
