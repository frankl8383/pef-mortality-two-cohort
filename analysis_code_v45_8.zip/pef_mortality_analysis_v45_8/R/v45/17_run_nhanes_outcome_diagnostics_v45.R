#!/usr/bin/env Rscript

# Execute the frozen v45 NHANES leave-cycle, leave-PSU, and supportive
# proportional-hazards diagnostics.
#
# Coefficient-bearing intermediates remain restricted until the independent
# validator releases aggregate diagnostic tables. No completed imputation,
# fitted model, or participant-level row is persisted.

options(stringsAsFactors = FALSE, warn = 1)

stage4b_root <- function() {
  args <- commandArgs(trailingOnly = FALSE)
  file_arg <- grep("^--file=", args, value = TRUE)
  if (!length(file_arg)) return(normalizePath(getwd(), mustWork = TRUE))
  script <- sub("^--file=", "", file_arg[[1L]])
  normalizePath(file.path(dirname(script), "..", ".."), mustWork = TRUE)
}

root <- stage4b_root()
source(file.path(root, "R", "v45", "01_nhanes_common_utilities_v45.R"))
source(file.path(root, "R", "v45", "02_gli_functions_v45.R"))
source(file.path(root, "R", "v45", "11_nhanes_outcome_utilities_v45.R"))
source(file.path(
  root, "R", "v45", "15_nhanes_outcome_diagnostics_utilities_v45.R"
))
v45_require_packages(root)
options(
  survey.lonely.psu = "adjust",
  survey.adjust.domain.lonely = TRUE,
  survey.multicore = FALSE
)

args <- commandArgs(trailingOnly = TRUE)
arg_value <- function(prefix, default = NULL) {
  hit <- grep(paste0("^", prefix, "="), args, value = TRUE)
  if (!length(hit)) return(default)
  sub(paste0("^", prefix, "="), "", tail(hit, 1L))
}
workers <- suppressWarnings(as.integer(arg_value("--workers", "4")))
if (!is.finite(workers) || workers < 1L || workers > 8L) {
  stop("--workers must be an integer from 1 to 8.", call. = FALSE)
}
workers <- min(workers, max(1L, parallel::detectCores() - 1L))

gate_yes <- function(x) {
  isTRUE(x) ||
    tolower(as.character(x)) %in% c("yes", "true", "1")
}
gate_no <- function(x) {
  identical(x, FALSE) ||
    tolower(as.character(x)) %in% c("no", "false", "0")
}
read_tsv <- function(path) {
  utils::read.delim(
    path, stringsAsFactors = FALSE, check.names = FALSE,
    na.strings = c("", "NA")
  )
}

freeze_script <- file.path(
  root, "R", "v45", "16_freeze_nhanes_outcome_diagnostics_v45.R"
)
freeze_verify <- system2(
  file.path(R.home("bin"), "Rscript"),
  c("--vanilla", freeze_script, "--verify"),
  stdout = TRUE, stderr = TRUE
)
freeze_status <- attr(freeze_verify, "status")
if (!is.null(freeze_status) && freeze_status != 0L) {
  stop(
    "Stage 4b diagnostic freeze verification failed: ",
    paste(freeze_verify, collapse = " | "), call. = FALSE
  )
}

gate_path <- file.path(root, "work_v45", "gate_state_v45.yml")
gate <- yaml::read_yaml(gate_path)
if (
  !identical(
    gate$stage4b_nhanes_outcome_diagnostics_freeze$status, "PASS"
  ) ||
  !gate_yes(gate$nhanes_diagnostic_execution_allowed) ||
  !gate_no(gate$nhanes_diagnostic_aggregate_inspection_allowed) ||
  !identical(
    gate$stage4_nhanes_outcome_execution$status,
    "INDEPENDENT_VALIDATION_PASS"
  )
) {
  stop("Stage 4b semantic gates do not authorize execution.",
       call. = FALSE)
}

contract_path <- file.path(
  root, "derived_sensitive", "v45",
  "v45_nhanes_outcome_diagnostics_contract.rds"
)
contract <- readRDS(contract_path)
if (
  !identical(contract$contract_version, "v45_0_stage4b") ||
  contract$diagnostic_model_fit_count != 0L ||
  contract$diagnostic_coefficient_export_count != 0L ||
  !identical(contract$expected$total_refits, 9800L) ||
  !identical(length(contract$design_psu_values), 94L)
) {
  stop("Stage 4b restricted contract is invalid.", call. = FALSE)
}

public_root <- file.path(root, "results", "v45", "outcome_diagnostics")
restricted_root <- file.path(
  root, "derived_sensitive", "v45", "outcome_diagnostics"
)
log_root <- file.path(root, "logs", "v45", "outcome_diagnostics")
dir.create(public_root, recursive = TRUE, showWarnings = FALSE)
dir.create(restricted_root, recursive = TRUE, showWarnings = FALSE)
dir.create(log_root, recursive = TRUE, showWarnings = FALSE)
current_path <- file.path(
  public_root, "v45_stage4b_restricted_current.tsv"
)
if (file.exists(current_path)) {
  stop(
    "A Stage 4b restricted-run pointer already exists; refusing to overwrite.",
    call. = FALSE
  )
}

run_id_arg <- arg_value("--run-id", NULL)
if (!is.null(run_id_arg) && !grepl(
  "^v45_nhanes_outcome_diagnostics_m50_[0-9]{8}T[0-9]{6}_pid[0-9]+$",
  run_id_arg
)) {
  stop("Unsafe or invalid --run-id.", call. = FALSE)
}
run_id <- if (!is.null(run_id_arg)) {
  run_id_arg
} else {
  paste0(
    "v45_nhanes_outcome_diagnostics_m50_",
    format(Sys.time(), "%Y%m%dT%H%M%S"), "_pid", Sys.getpid()
  )
}
run_dir <- file.path(restricted_root, run_id)
state_dir <- file.path(public_root, run_id)
dir.create(run_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(state_dir, recursive = TRUE, showWarnings = FALSE)
restricted_path <- file.path(run_dir, "diagnostics_restricted.rds")
state_path <- file.path(state_dir, "execution_state.tsv")
log_path <- file.path(log_root, paste0(run_id, ".log"))
if (file.exists(restricted_path)) {
  stop("Restricted diagnostic output already exists.", call. = FALSE)
}

log_lines <- c(
  paste0("run_id: ", run_id),
  "coefficient_visibility: restricted",
  "row_level_output: forbidden",
  paste0("workers: ", workers)
)
append_log <- function(text) {
  line <- paste0(
    format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z"), " ", text
  )
  log_lines <<- c(log_lines, line)
  v45_atomic_write_lines(log_lines, log_path)
  message(text)
}
state <- data.frame(
  run_id = run_id,
  status = "RUNNING",
  expected_refits = 9800L,
  completed_imputations = 0L,
  restricted_output_path_alias = NA_character_,
  restricted_output_sha256 = NA_character_,
  coefficient_visibility = "RESTRICTED",
  independent_validation_status = "NOT_RUN",
  stringsAsFactors = FALSE
)
v45_atomic_write_tsv(state, state_path)

pointer_path <- file.path(
  root, "results", "v45", "production_mi", "MI_G_m50_current.tsv"
)
pointer <- read_tsv(pointer_path)
mids_path <- file.path(root, pointer$mids_path_alias[[1L]])
if (
  nrow(pointer) != 1L ||
  !identical(pointer$object_id[[1L]], "MI-G") ||
  pointer$requested_m[[1L]] != 50L ||
  !identical(pointer$status[[1L]], "INDEPENDENT_VALIDATION_PASS") ||
  !identical(
    pointer$mids_sha256[[1L]],
    "41bcc3e5fbfd8f19501682e93354856ffc06adf6e426937327e07138d17733d3"
  ) ||
  !identical(v45_sha256_file(mids_path), pointer$mids_sha256[[1L]])
) {
  stop("MI-G m=50 no longer matches the frozen diagnostic input.",
       call. = FALSE)
}
mig <- readRDS(mids_path)
if (mig$m != 50L) {
  stop("Stage 4b requires the exact MI-G m=50 object.",
       call. = FALSE)
}
ledger <- v45_read_nhanes_ledger(root)
v43 <- v45_load_v43_nhanes_functions(root)
design_data <- v45_outcome_design_data(ledger)

influence_template <- function(
    model_id, exclusion_type, excluded_unit, imputation) {
  data.frame(
    diagnostic_id = paste0(
      model_id, "_leave_", exclusion_type, "_", excluded_unit
    ),
    model_id = model_id,
    exclusion_type = exclusion_type,
    excluded_unit = as.character(excluded_unit),
    imputation = as.integer(imputation),
    term = "E0",
    estimate = NA_real_,
    within_variance = NA_real_,
    design_df = NA_real_,
    n = NA_integer_,
    events = NA_integer_,
    design_strata = NA_integer_,
    design_psu = NA_integer_,
    warnings = "",
    estimability_status = "NOT_ESTIMABLE",
    failure_class = "",
    failure_reason = "",
    stringsAsFactors = FALSE
  )
}

ph_template <- function(model_id, imputation) {
  data.frame(
    diagnostic_id = paste0(model_id, "_E0_log_time"),
    model_id = model_id,
    imputation = as.integer(imputation),
    term = "tt(E0)",
    estimate = NA_real_,
    within_variance = NA_real_,
    design_df = NA_real_,
    n = NA_integer_,
    events = NA_integer_,
    design_strata = NA_integer_,
    design_psu = NA_integer_,
    warnings = "",
    estimability_status = "NOT_ESTIMABLE",
    failure_class = "",
    failure_reason = "",
    stringsAsFactors = FALSE
  )
}

run_one_imputation <- function(i) {
  message("Stage 4b imputation ", i, "/50 started.")
  completed <- v45_prepare_mig_completed(
    mice::complete(mig, action = i), ledger, v43
  )
  structure <- v45_diag_ph_structural_check(completed)
  if (nrow(structure) != 2L || any(structure$status != "PASS")) {
    stop(
      "PH structural contract failed before diagnostic fitting in ",
      "imputation ", i, ".", call. = FALSE
    )
  }
  merged <- v45_merge_completed_design(design_data, completed)
  full_design <- v45_make_taylor_design(merged)
  common_domain <- merged$analysis_domain
  influence <- vector(
    "list", length(contract$cycles) * length(contract$models) +
      length(contract$design_psu_values) * length(contract$models)
  )
  position <- 0L
  for (cycle in contract$cycles) {
    domain <- common_domain &
      as.character(merged$cycle_label) != cycle
    for (model_id in names(contract$models)) {
      position <- position + 1L
      influence[[position]] <- v45_diag_safe_row(
        function() v45_diag_fit_influence_one(
          merged = merged,
          full_design = full_design,
          domain_index = domain,
          model_id = model_id,
          exclusion_type = "cycle",
          excluded_unit = cycle,
          imputation = i
        ),
        influence_template(model_id, "cycle", cycle, i)
      )
    }
  }
  for (psu in contract$design_psu_values) {
    domain <- common_domain &
      as.character(merged$design_psu) != psu
    for (model_id in names(contract$models)) {
      position <- position + 1L
      influence[[position]] <- v45_diag_safe_row(
        function() v45_diag_fit_influence_one(
          merged = merged,
          full_design = full_design,
          domain_index = domain,
          model_id = model_id,
          exclusion_type = "PSU",
          excluded_unit = psu,
          imputation = i
        ),
        influence_template(model_id, "PSU", psu, i)
      )
    }
  }
  influence <- dplyr::bind_rows(influence)
  ph <- dplyr::bind_rows(lapply(names(contract$models), function(model_id) {
    v45_diag_safe_row(
      function() v45_diag_fit_ph_one(completed, model_id, i),
      ph_template(model_id, i)
    )
  }))
  if (
    nrow(influence) != contract$expected$influence_per_imputation ||
    nrow(ph) != contract$expected$ph_per_imputation
  ) {
    stop("Per-imputation diagnostic row count drifted.", call. = FALSE)
  }
  message("Stage 4b imputation ", i, "/50 finished.")
  structure$imputation <- i
  list(influence = influence, ph = ph, structure = structure)
}

append_log(paste0(
  "Restricted diagnostic execution started: 50 imputations, ",
  "196 fits per imputation."
))
wrapper <- function(i) {
  tryCatch(
    list(ok = TRUE, value = run_one_imputation(i), error = ""),
    error = function(e) list(
      ok = FALSE, value = NULL, error = conditionMessage(e)
    )
  )
}
results <- if (workers == 1L) {
  lapply(seq_len(50L), wrapper)
} else {
  parallel::mclapply(
    seq_len(50L), wrapper, mc.cores = workers,
    mc.preschedule = FALSE, mc.set.seed = FALSE
  )
}
failed <- !vapply(results, `[[`, logical(1), "ok")
if (any(failed)) {
  stop(
    "Stage 4b failed for imputation(s) ",
    paste(which(failed), collapse = ", "), ": ",
    paste(
      vapply(results[failed], `[[`, character(1), "error"),
      collapse = " | "
    ),
    call. = FALSE
  )
}
values <- lapply(results, `[[`, "value")
per_influence <- dplyr::bind_rows(lapply(values, `[[`, "influence"))
per_ph <- dplyr::bind_rows(lapply(values, `[[`, "ph"))
ph_structure <- dplyr::bind_rows(lapply(values, `[[`, "structure"))
rm(results, values, mig)
invisible(gc(verbose = FALSE))

if (
  nrow(per_influence) != 9700L ||
  nrow(per_ph) != 100L ||
  nrow(ph_structure) != 100L ||
  !identical(sort(unique(per_influence$imputation)), seq_len(50L)) ||
  !identical(sort(unique(per_ph$imputation)), seq_len(50L)) ||
  any(ph_structure$status != "PASS")
) {
  stop("Complete diagnostic row counts or imputation indices drifted.",
       call. = FALSE)
}
unexpected_failure <- c(
  per_influence$failure_class,
  per_ph$failure_class
) == "UNEXPECTED_IMPLEMENTATION_ERROR"
if (any(unexpected_failure)) {
  stop(
    "At least one registered diagnostic encountered an unexpected ",
    "implementation error; the complete run is blocked.", call. = FALSE
  )
}

summarize_keys <- function(data, key_fields) {
  finite_min <- function(x) {
    x <- as.numeric(x)
    x <- x[is.finite(x)]
    if (length(x)) min(x) else NA_real_
  }
  finite_max <- function(x) {
    x <- as.numeric(x)
    x <- x[is.finite(x)]
    if (length(x)) max(x) else NA_real_
  }
  keys <- unique(data[key_fields])
  dplyr::bind_rows(lapply(seq_len(nrow(keys)), function(i) {
    key <- keys[i, , drop = FALSE]
    use <- rep(TRUE, nrow(data))
    for (field in key_fields) {
      use <- use & data[[field]] == key[[field]][[1L]]
    }
    local <- data[use, , drop = FALSE]
    cbind(
      key,
      data.frame(
        minimum_n = finite_min(local$n),
        maximum_n = finite_max(local$n),
        minimum_events = finite_min(local$events),
        maximum_events = finite_max(local$events),
        minimum_design_strata = finite_min(local$design_strata),
        maximum_design_strata = finite_max(local$design_strata),
        minimum_design_psu = finite_min(local$design_psu),
        maximum_design_psu = finite_max(local$design_psu),
        minimum_design_df = finite_min(local$design_df),
        maximum_design_df = finite_max(local$design_df),
        warning_fit_n = sum(nzchar(local$warnings)),
        unique_warning_message_n = length(unique(
          local$warnings[nzchar(local$warnings)]
        )),
        stringsAsFactors = FALSE
      )
    )
  }))
}

influence_keys <- c(
  "diagnostic_id", "model_id", "exclusion_type",
  "excluded_unit", "term"
)
ph_keys <- c("diagnostic_id", "model_id", "term")
pooled_influence <- v45_diag_pool_table(
  per_influence, influence_keys
)
pooled_ph <- v45_diag_pool_table(per_ph, ph_keys)
pooled_influence <- dplyr::left_join(
  pooled_influence,
  summarize_keys(per_influence, influence_keys),
  by = influence_keys
)
pooled_ph <- dplyr::left_join(
  pooled_ph,
  summarize_keys(per_ph, ph_keys),
  by = ph_keys
)

released <- read_tsv(file.path(
  root, "results", "v45", "outcome_execution",
  "v45_nhanes_standard_pooled.tsv"
))
reference <- dplyr::bind_rows(lapply(
  names(contract$models), function(model_id) {
    row <- released[
      released$analysis_id == model_id & released$term == "E0",
      ,
      drop = FALSE
    ]
    if (nrow(row) != 1L) {
      stop("Released full-model reference row is not unique.",
           call. = FALSE)
    }
    data.frame(
      model_id = model_id,
      reference_estimate = row$estimate[[1L]],
      reference_hazard_ratio = exp(row$estimate[[1L]]),
      stringsAsFactors = FALSE
    )
  }
))
pooled_influence <- dplyr::left_join(
  pooled_influence, reference, by = "model_id"
)
pooled_influence$delta_beta <-
  pooled_influence$estimate - pooled_influence$reference_estimate
pooled_influence$sign_reversal <-
  sign(pooled_influence$estimate) !=
    sign(pooled_influence$reference_estimate)
pooled_influence$hazard_ratio <- exp(pooled_influence$estimate)
pooled_influence$hazard_ratio_ci_low <- exp(pooled_influence$ci_low)
pooled_influence$hazard_ratio_ci_high <- exp(pooled_influence$ci_high)
pooled_influence$gate_status <- ifelse(
  pooled_influence$pool_status == "NOT_ESTIMABLE",
  "NOT_ESTIMABLE",
  ifelse(
    pooled_influence$monte_carlo_error_fraction < 0.10,
    "PASS", "M100_REQUIRED"
  )
)
pooled_ph$time_interaction_ratio <- exp(pooled_ph$estimate)
pooled_ph$time_interaction_ratio_ci_low <- exp(pooled_ph$ci_low)
pooled_ph$time_interaction_ratio_ci_high <- exp(pooled_ph$ci_high)
pooled_ph$gate_status <- ifelse(
  pooled_ph$pool_status == "NOT_ESTIMABLE",
  "NOT_ESTIMABLE",
  ifelse(
    pooled_ph$monte_carlo_error_fraction < 0.10,
    "PASS", "M100_REQUIRED"
  )
)

restricted <- list(
  schema_version = "v45_0_stage4b_diagnostics_restricted",
  run_id = run_id,
  created_at_utc = format(
    Sys.time(), tz = "UTC", format = "%Y-%m-%dT%H:%M:%SZ"
  ),
  freeze_contract_sha256 = v45_sha256_file(contract_path),
  coefficient_visibility = "RESTRICTED",
  completed_dataset_saved = FALSE,
  fitted_model_object_saved = FALSE,
  row_level_data_saved = FALSE,
  per_imputation_influence = per_influence,
  pooled_influence = pooled_influence,
  per_imputation_ph = per_ph,
  pooled_ph = pooled_ph,
  ph_structure = ph_structure
)
v45_atomic_save_rds(restricted, restricted_path)
restricted_alias <- substring(restricted_path, nchar(root) + 2L)
restricted_sha <- v45_sha256_file(restricted_path)
state$status <- "RESTRICTED_COMPLETE"
state$completed_imputations <- 50L
state$restricted_output_path_alias <- restricted_alias
state$restricted_output_sha256 <- restricted_sha
v45_atomic_write_tsv(state, state_path)
current <- data.frame(
  run_id = run_id,
  state_path_alias = substring(state_path, nchar(root) + 2L),
  state_sha256 = v45_sha256_file(state_path),
  restricted_output_path_alias = restricted_alias,
  restricted_output_sha256 = restricted_sha,
  coefficient_visibility = "RESTRICTED",
  independent_validation_status = "NOT_RUN",
  stringsAsFactors = FALSE
)
v45_atomic_write_tsv(current, current_path)

gate <- yaml::read_yaml(gate_path)
gate$updated_at <- format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")
gate$stage4b_nhanes_outcome_diagnostics_execution <- list(
  status = "RESTRICTED_COMPLETE",
  run_id = run_id,
  refits = 9800L,
  influence_per_imputation_rows = nrow(per_influence),
  PH_per_imputation_rows = nrow(per_ph),
  numerical_or_support_failure_rows = sum(c(
    per_influence$failure_class,
    per_ph$failure_class
  ) == "NUMERICAL_OR_SUPPORT_FAILURE"),
  restricted_output_sha256 = restricted_sha
)
gate$nhanes_diagnostic_execution_allowed <- "no"
gate$nhanes_diagnostic_aggregate_inspection_allowed <- "no"
gate$next_authorized_step <-
  "independently_validate_NHANES_outcome_diagnostics"
v45_atomic_write_yaml(gate, gate_path)
append_log(paste0(
  "Restricted execution completed; SHA-256=", restricted_sha,
  ". Aggregate inspection remains blocked."
))
cat("V45_STAGE4B_DIAGNOSTIC_RESTRICTED_COMPLETE\n")
cat("run_id=", run_id, "\n", sep = "")
cat("aggregate_inspection=BLOCKED_PENDING_INDEPENDENT_VALIDATION\n")
