# PEF mortality analysis plan: V45.7 reviewer-motivated addendum

## Status and trigger

This addendum was frozen before inspecting any new V45.7 coefficient. It was
triggered by an independent, history-blinded review of the V45.6 formal upload
files on 29 July 2026. It does not replace the V45 analysis hierarchy.

The frozen V45.6 submission archive is:

- `output/submission_package_v45_6_FINAL_2026-07-29.zip`
- SHA-256:
  `c3db3a67ef179e87a5a81a0dfdb90ed55aafc509a9d5bf039b234fce695b1dd5`

V45.6 remains unchanged. All work under this addendum is versioned as V45.7.

## Scientific question

The original NHANES GLI comparison used the A1 adjustment set throughout.
The review asked whether the conditional PEF association is also present after
the broader A2 health and functional-status adjustment used in the primary
cohort adjustment ladder.

This is a reviewer-motivated sensitivity analysis. It is not a new primary
analysis, does not alter the original A1 estimand, and will be reported
regardless of direction or statistical significance.

## Frozen data object and population

- Imputation object: validated `MI-G`, `m=50`.
- Required object hash:
  `41bcc3e5fbfd8f19501682e93354856ffc06adf6e426937327e07138d17733d3`.
- Population: the existing NHANES GLI common sample.
- Expected sample anchors: 6,540 participants and 885 deaths.
- Survey design anchors: 45 strata, 94 PSUs, complete-data design df 49.
- Replication: the existing frozen 500-column paired-GLI Rao-Wu matrix.
- No cohort, exposure, outcome, imputation, knot, or reference-equation
  definition will be changed.

## Frozen model set

The outcome is all-cause mortality represented by
`Surv(followup_years, death)`.

The four fitted models are:

1. `A1-separate`: lower PEF plus A1 covariates.
2. `A1-conditional`: lower PEF, lower GLI FEV1 z score, lower GLI FEV1/FVC
   z score, plus A1 covariates.
3. `A2-separate`: lower PEF plus A2 covariates.
4. `A2-conditional`: lower PEF, lower GLI FEV1 z score, lower GLI FEV1/FVC
   z score, plus A2 covariates.

A2 contains all A1 terms and adds:

- self-reported emphysema or chronic bronchitis;
- ever asthma;
- the prespecified NHANES function/health proxy count.

The focal term is lower PEF (`E0`) in every model.

## Frozen contrasts and reporting

Two paired log-coefficient contrasts will use the same 500 Rao-Wu replicates
within every imputation:

1. `A2-conditional minus A2-separate`, reported as a ratio of PEF hazard
   ratios. This describes attenuation after adding the two GLI indices under
   A2 adjustment.
2. `A2-conditional minus A1-conditional`, reported as a ratio of PEF hazard
   ratios. This describes attenuation after adding the broader health and
   functional-status covariates to the conditional model.

The A1 estimates must reproduce the frozen V45 release within numerical
tolerance before any new A2 result is released. New P values are descriptive.
No additional multiplicity correction is assigned because this is one
reviewer-motivated sensitivity question and inference will be based on effect
size and uncertainty rather than significance status.

The manuscript will not describe the A2 result as causal, mechanistic,
independent physiological information, or demonstrated incremental
prediction.

## Structural and outcome firewalls

Before fitting:

- verify the V45.6 archive hash;
- verify the MI-G pointer, object hash, `m=50`, ordered participant IDs, and
  required A2 fields;
- verify the frozen Rao-Wu matrix identity and dimensions;
- build all four model matrices without reading or printing coefficients;
- require full rank, finite values, identical analysis membership, and the
  expected sample/design anchors.

The execution script will write a restricted aggregate RDS and will not print
coefficients. A separate validation script will independently:

- recheck all frozen inputs and script hashes;
- verify 50 imputations and at least 90% valid replicate fits per imputation;
- reproduce the A1 released estimates;
- verify pooling, confidence intervals, hazard-ratio transformations, and
  paired contrasts;
- release only aggregate, disclosure-safe tables after all gates pass.

Any failed gate stops release. No participant-level or completed-imputation
data will be written.

## CHARLS nonconsecutive-interval decision rule

The existing adjacent-window restriction is the prespecified supporting check.
Before adding another CHARLS model, the current observation-path analyses will
be audited against the review concern.

An additional model will be run only if it provides a distinct estimand or
tests an assumption not already covered by:

- the adjacent-window restriction;
- the paired adjacent/all coefficient contrast;
- the joint end-wave interaction test; and
- the reported counts and grouped-time approximation.

No new model will be added solely to increase the number of sensitivity
analyses. If no technically coherent, survey- and MI-compatible validation
offers distinct information, V45.7 will instead strengthen the mathematical
description and explicitly state why the existing adjacent-window result is
the relevant robustness check.

## Other V45.7 corrections

The following mechanical corrections are authorized:

- change the source-data workbook README version label from V45.3 to V45.7;
- remove the manual page break from the main DOCX;
- update tables, supplement, source data, STROBE locations, and submission
  package only as required by the released V45.7 result;
- retain separate TIFF figure files and the minimal public GitHub package.

Ethics and funding declarations remain unchanged unless the authors provide a
new institutional determination or a funder role that must be declared.
